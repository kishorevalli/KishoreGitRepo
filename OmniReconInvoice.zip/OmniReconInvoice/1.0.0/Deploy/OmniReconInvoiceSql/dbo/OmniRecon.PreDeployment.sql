﻿/*
 Pre-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be executed before the build script.	
 Use SQLCMD syntax to include a file in the pre-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the pre-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

USE S0OMNIXX
GO

IF NOT EXISTS (
  SELECT * 
  FROM   sys.columns 
  WHERE  object_id = OBJECT_ID(N'[dbo].[StoreMarket]') 
         AND name = 'IsETicketEnabled'
)
BEGIN

	ALTER TABLE StoreMarket ADD IsETicketEnabled bit 
END


USE [S0OMNIRI]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PosInstOrderMap]') AND type in (N'U'))
ALTER TABLE [dbo].[PosInstOrderMap] DROP CONSTRAINT IF EXISTS [FK_PosInstOrderMap_MapLevel]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PosInstOrderMap]') AND type in (N'U'))
ALTER TABLE [dbo].[PosInstOrderMap] DROP CONSTRAINT IF EXISTS [FK_PosInstOrderMap_MapCriteria]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PosInstOrderMap]') AND type in (N'U'))
ALTER TABLE [dbo].[PosInstOrderMap] DROP CONSTRAINT IF EXISTS [FK_PosInstOrderMap_ExclusionType]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExclusionType]') AND type in (N'U'))
ALTER TABLE [dbo].[ExclusionType] DROP CONSTRAINT IF EXISTS [FK_ExclusionType_MapLevel]
GO
/****** Object:  Table [dbo].[PosInstOrderMap]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[PosInstOrderMap]
GO
/****** Object:  Table [dbo].[ExclusionType]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[ExclusionType]
GO
/****** Object:  Table [dbo].[MapLevel]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[MapLevel]
GO
/****** Object:  Table [dbo].[StgPosLineItemTransaction]    Script Date: 11/7/2018 9:04:24 AM ******/
DROP TABLE IF EXISTS [dbo].[StgPosLineItemTransaction]
GO
/****** Object:  Table [dbo].[StgPosInstOrderMap]    Script Date: 11/7/2018 9:04:24 AM ******/
DROP TABLE IF EXISTS [dbo].[StgPosInstOrderMap]
GO
/****** Object:  Table [dbo].[StgPosInstOrderItemMap]    Script Date: 11/7/2018 9:04:24 AM ******/
DROP TABLE IF EXISTS [dbo].[StgPosInstOrderItemMap]
GO
/****** Object:  Table [dbo].[StgPosInstOrderInvoice]    Script Date: 11/7/2018 9:04:24 AM ******/
DROP TABLE IF EXISTS [dbo].[StgPosInstOrderInvoice]
GO
/****** Object:  Table [dbo].[StgMapLog]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[StgMapLog]
GO
/****** Object:  Table [dbo].[StgInstFeedDiscrepancy]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[StgInstFeedDiscrepancy]
GO
/****** Object:  Table [dbo].[PosInstOrderSummary]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[PosInstOrderSummary]
GO
/****** Object:  Table [dbo].[PosInstOrderItemMap]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[PosInstOrderItemMap]
GO
/****** Object:  Table [dbo].[PosInstOrderInvoice]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[PosInstOrderInvoice]
GO
/****** Object:  Table [dbo].[PosETicketSummary]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[PosETicketSummary]
GO
/****** Object:  Table [dbo].[MapLog]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[MapLog]
GO
/****** Object:  Table [dbo].[MapInterval]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[MapInterval]
GO
/****** Object:  Table [dbo].[MapCriteria]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[MapCriteria]
GO
/****** Object:  Table [dbo].[InstFeedDiscrepancy]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[InstFeedDiscrepancy]
GO
/****** Object:  Table [dbo].[ETicketInterval]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[ETicketInterval]
GO
/****** Object:  Table [dbo].[SystemLog]    Script Date: 11/7/2018 9:04:25 AM ******/
DROP TABLE IF EXISTS [dbo].[SystemLog]
GO
/****** Object:  Table [dbo].[StgETicketSummary]    Script Date: 11/12/2018 9:01:02 AM ******/
DROP TABLE IF EXISTS [dbo].[StgETicketSummary]
GO
/****** Object:  Table [dbo].[ETicketSummary]    Script Date: 11/12/2018 9:01:03 AM ******/
DROP TABLE IF EXISTS [dbo].[ETicketSummary]
GO

DROP TABLE IF EXISTS [dbo].[ETicketStatus]
GO

DROP TABLE IF EXISTS [dbo].[InvoiceFeeRate]
GO

DROP TABLE IF EXISTS [dbo].[PublishETicket]
GO

DROP TABLE IF EXISTS [dbo].[PublishETicketHistory]
GO