﻿CREATE TABLE [dbo].[SystemLog] (
    [LogId]        INT           IDENTITY (1, 1) NOT NULL,
    [LogDate]      DATETIME      NOT NULL,
    [LogThread]    VARCHAR (255) NOT NULL,
    [LogLevel]     VARCHAR (50)  NOT NULL,
    [Logger]       VARCHAR (255) NOT NULL,
    [Method]       VARCHAR (255) NOT NULL,
    [LogMessage]   VARCHAR (MAX) NULL,
    [LogException] VARCHAR (MAX) NULL,
    [MachineName]  VARCHAR (255) NULL,
    CONSTRAINT [PK_SystemLog] PRIMARY KEY CLUSTERED ([LogId] ASC)
);

