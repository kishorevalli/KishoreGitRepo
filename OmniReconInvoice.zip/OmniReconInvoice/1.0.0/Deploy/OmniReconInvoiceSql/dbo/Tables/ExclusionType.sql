﻿CREATE TABLE [dbo].[ExclusionType] (
    [Id]    INT          IDENTITY (1, 1) NOT NULL,
    [Type]  VARCHAR (50) NOT NULL,
    [Level] CHAR (5)     NOT NULL,
    CONSTRAINT [PK_ExclusionType] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ExclusionType_MapLevel] FOREIGN KEY ([Level]) REFERENCES [dbo].[MapLevel] ([Level])
);



