CREATE TABLE [dbo].[PosInstOrderInvoice] (
    [InstOrderId]                     BIGINT          NOT NULL,
    [InstDeliveryId]                  BIGINT          NOT NULL,
    [PosStoreNumber]                  INT             NOT NULL,
    [PosTransactionDate]              DATE            NOT NULL,
    [PosNonAlcoholSales]              DECIMAL (18, 2) NOT NULL,
    [PosAlcoholSales]                 DECIMAL (18, 2) NOT NULL,
    [PosSalesBeforeTax]               DECIMAL (18, 2) NOT NULL,
    [PosSalesTax]                     DECIMAL (18, 2) NOT NULL,
    [PosBottleDeposit]                DECIMAL (18, 2) NOT NULL,
    [PosCouponValue]                  DECIMAL (18, 2) NOT NULL,
    [PosSalesIncludingTax]            DECIMAL (18, 2) NOT NULL,
    [PosTenderAmount]                 DECIMAL (18, 2) NOT NULL,
    [QualifiedPosNonAlcoholSales]     DECIMAL (18, 2) NOT NULL,
    [QualifiedPosAlcoholSales]        DECIMAL (18, 2) NOT NULL,
    [QualifiedPosSalesBeforeTax]      DECIMAL (18, 2) NOT NULL,
    [QualifiedPosSalesTax]            DECIMAL (18, 2) NOT NULL,
    [QualifiedPosBottleDeposit]       DECIMAL (18, 2) NOT NULL,
    [QualifiedPosCouponValue]         DECIMAL (18, 2) NOT NULL,
    [QualifiedPosSalesIncludingTax]   DECIMAL (18, 2) NOT NULL,
    [PosAdjPreTaxNonAlcoholSales]     DECIMAL (18, 2) NOT NULL,
    [PosAdjPreTaxAlcoholSales]        DECIMAL (18, 2) NOT NULL,
    [PosAdjSalesTax]                  DECIMAL (18, 2) NOT NULL,
    [PosAdjSalesIncludingTax]         DECIMAL (18, 2) NOT NULL,
    [InstOnlineRevenue]               DECIMAL (18, 2) NOT NULL,
    [InstPreTaxNonAlcoholSales]       DECIMAL (18, 2) NOT NULL,
    [InstPreTaxAlcoholSales]          DECIMAL (18, 2) NOT NULL,
    [InstSalesTax]                    DECIMAL (18, 2) NOT NULL,
    [InstBottleDeposit]               DECIMAL (18, 2) NOT NULL,
    [InstGMV]                         DECIMAL (18, 2) NOT NULL,
    [InstAdjOnlineRevenue]            DECIMAL (18, 2) NOT NULL,
    [InstAdjPreTaxNonAlcoholSales]    DECIMAL (18, 2) NOT NULL,
    [InstAdjPreTaxAlcoholSales]       DECIMAL (18, 2) NOT NULL,
    [InstAdjSalesTax]                 DECIMAL (18, 2) NOT NULL,
    [InstAdjBottleDeposit]            DECIMAL (18, 2) NOT NULL,
    [InstAdjGMV]                      DECIMAL (18, 2) NOT NULL,
    [CalculatedSpreadAmount]          DECIMAL (18, 2) NOT NULL,
    [CalculatedSpreadPercentage]      DECIMAL (9, 2)  NOT NULL,
    [FeePercentage]                   DECIMAL (18, 2) NOT NULL,
    [FlatAlcoholFee]                  DECIMAL (18, 2) NOT NULL,
    [CalculateNonAlcoholFee]          DECIMAL (18, 2) NOT NULL,
    [TotalFee]                        DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxGap]                  DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxPlan2TaxGap]          DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxPlan2TaxGap]          DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxGap]                  DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxableSalesGap]         DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxPlan2TaxableSalesGap] DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxPlan2TaxableSalesGap] DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxableSalesGap]         DECIMAL (18, 2) NOT NULL,
    [ETicketSummaryId]                DECIMAL (25)    NULL,
    [InvoiceFeeRateId]                INT             NULL,
    [AnyItemExclusion]                BIT             NOT NULL,
    [AnyPosAdj]                       BIT             NOT NULL,
    [AnyInstAdj]                      BIT             NOT NULL,
    [IsByPassCheckOut]                BIT             NOT NULL,
    [StoreFront]                      CHAR (1)        NOT NULL,
    [DeliveryModel]                   VARCHAR (100)   NOT NULL,
    [State]                           VARCHAR (50)    NOT NULL,
    [LastUpdatedBy]                   VARCHAR (50)    NOT NULL,
    [LastUpdatedDate]                 DATETIME        NOT NULL,
    CONSTRAINT [FK_PosInstOrderInvoice_ETicketSummary] FOREIGN KEY ([ETicketSummaryId]) REFERENCES [dbo].[ETicketSummary] ([Id]),
    CONSTRAINT [FK_PosInstOrderInvoice_InvoiceFeeRate] FOREIGN KEY ([InvoiceFeeRateId]) REFERENCES [dbo].[InvoiceFeeRate] ([Id])
);
















GO
CREATE NONCLUSTERED INDEX [IX_PosInstOrderInvoice_InstOrderIdInstDeliveryId]
    ON [dbo].[PosInstOrderInvoice]([InstOrderId] ASC, [InstDeliveryId] ASC);

