﻿CREATE TABLE [dbo].[PublishETicketHistory] (
    [Id]                  BIGINT          NULL,
    [StoreNumber]         INT             NULL,
    [FromTransactionDate] DATETIME        NULL,
    [ToTransactionDate]   DATETIME        NULL,
    [TransmissionDate]    DATETIME        NULL,
    [NonTaxableSalesGap]  DECIMAL (18, 2) NULL,
    [TaxableSalesGap]     DECIMAL (18, 2) NULL,
    [StateAndLocalTaxGap] DECIMAL (18, 2) NULL,
    [FoodAndLocalTaxGap]  DECIMAL (18, 2) NULL,
    [FoodTaxGap]          DECIMAL (18, 2) NULL,
    [StateTax]            DECIMAL (18, 2) NULL,
    [StateAndLocalTax]    DECIMAL (18, 2) NULL,
    [FoodAndLocalTax]     DECIMAL (18, 2) NULL,
    [FoodTax]             DECIMAL (18, 2) NULL,
    [IsETicketGenerated]  BIT             NULL,
    [ETicketXml]          XML             NULL,
    [MQMessageId]         VARCHAR (500)   NULL,
    [LastUpdatedDate]     DATETIME        NULL,
    [LastUpdatedBy]       VARCHAR (50)    NULL
);

