﻿CREATE TABLE [dbo].[MapLevel] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [Level]       CHAR (5)      NOT NULL,
    [Description] VARCHAR (200) NULL,
    CONSTRAINT [PK_MapLevel_Level] PRIMARY KEY CLUSTERED ([Level] ASC)
);







