﻿CREATE TABLE [dbo].[PublishETicket] (
    [Id]                  BIGINT          NOT NULL,
    [StoreNumber]         INT             NOT NULL,
    [FromTransactionDate] DATETIME        NOT NULL,
    [ToTransactionDate]   DATETIME        NOT NULL,
    [TransmissionDate]    DATETIME        NOT NULL,
    [NonTaxableSalesGap]  DECIMAL (18, 2) NOT NULL,
    [TaxableSalesGap]     DECIMAL (18, 2) NOT NULL,
    [StateAndLocalTaxGap] DECIMAL (18, 2) NOT NULL,
    [FoodAndLocalTaxGap]  DECIMAL (18, 2) NOT NULL,
    [FoodTaxGap]          DECIMAL (18, 2) NOT NULL,
    [StateTax]            DECIMAL (18, 2) NOT NULL,
    [StateAndLocalTax]    DECIMAL (18, 2) NOT NULL,
    [FoodAndLocalTax]     DECIMAL (18, 2) NOT NULL,
    [FoodTax]             DECIMAL (18, 2) NOT NULL,
    [IsETicketGenerated]  BIT             CONSTRAINT [DF_PublishETicket_IsETicketGenerated] DEFAULT ((0)) NOT NULL,
    [ETicketXml]          XML             NULL,
    [MQMessageId]         VARCHAR (500)   NULL,
    [LastUpdatedDate]     DATETIME        NOT NULL,
    [LastUpdatedBy]       VARCHAR (50)    NOT NULL,
    CONSTRAINT [PK_PublishETicket_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

