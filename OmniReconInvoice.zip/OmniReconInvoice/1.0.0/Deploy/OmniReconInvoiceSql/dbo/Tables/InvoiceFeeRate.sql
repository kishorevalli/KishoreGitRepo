﻿CREATE TABLE [dbo].[InvoiceFeeRate] (
    [Id]                     INT             IDENTITY (1, 1) NOT NULL,
    [State]                  VARCHAR (25)    NOT NULL,
    [Market]                 VARCHAR (25)    NOT NULL,
    [DeliveryModel]          VARCHAR (50)    NULL,
    [FromOrdersCount]        INT             NOT NULL,
    [ToOrdersCount]          INT             NOT NULL,
    [FlatAlcoholFee]         DECIMAL (18, 2) NOT NULL,
    [FlatAlcoholFeeDiscount] DECIMAL (18, 2) NOT NULL,
    [MarkupPercentDiscount]  DECIMAL (18, 2) NOT NULL,
    CONSTRAINT [PK_InvoiceFeeRates_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

