﻿CREATE TABLE [dbo].[StgInstFeedDiscrepancy] (
    [InstOrderId]                BIGINT          NULL,
    [InstDeliveryId]             BIGINT          NULL,
    [InstOrderedDateEst]         DATETIME        NULL,
    [InstDeliveredDateEst]       DATETIME        NULL,
    [InstStoreLocation]          INT             NULL,
    [InstRefereneCode]           INT             NULL,
    [InstGTIN]                   BIGINT          NULL,
    [InstUnit]                   VARCHAR (10)    NULL,
    [InstQty]                    DECIMAL (9, 2)  NULL,
    [InstOnlinePrice]            DECIMAL (18, 2) NULL,
    [InstOnlineRevenue]          DECIMAL (18, 2) NULL,
    [InstAlcoholFlag]            VARCHAR (5)     NULL,
    [InstBottleDeposit]          DECIMAL (18, 2) NULL,
    [InstPriceSource]            VARCHAR (50)    NULL,
    [FeedLoadDate]               DATE            NULL,
    [FeedStoreNumber]            INT             NULL,
    [FeedRRC]                    INT             NULL,
    [FeedScanCode]               BIGINT          NULL,
    [FeedCostUnit]               VARCHAR (10)    NULL,
    [FeedMarkUpPriceRounded]     DECIMAL (18, 2) NULL,
    [FeedUnitPrice]              DECIMAL (18, 2) NULL,
    [FeedMarkUpSalePriceRounded] DECIMAL (18, 2) NULL,
    [FeedSalePrice]              DECIMAL (18, 2) NULL,
    [FeedBogo]                   VARCHAR (5)     NULL,
    [FeedPromoGroupId]           INT             NULL,
    [FeedPromoStartDate]         DATE            NULL,
    [FeedPromoEndDate]           DATE            NULL,
    [FeedAlcoholFlag]            VARCHAR (5)     NULL,
    [FeedBottleDeposit]          DECIMAL (18, 2) NULL,
    [Type]                       VARCHAR (100)   NULL,
    [MapCriteriaId]              INT             NULL,
    [LastUpdatedBy]              VARCHAR (50)    NULL,
    [LastUpdatedDate]            DATETIME        NULL
);





