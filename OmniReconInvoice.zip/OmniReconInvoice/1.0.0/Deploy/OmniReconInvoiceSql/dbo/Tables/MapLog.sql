﻿CREATE TABLE [dbo].[MapLog] (
    [InstOrderId]             BIGINT          NULL,
    [InstDeliveryId]          BIGINT          NULL,
    [InstStoreLocation]       INT             NULL,
    [InstTransactionDateTime] DATETIME        NULL,
    [InstTransactionAmt]      DECIMAL (18, 2) NULL,
    [InstOrderedDate]         DATETIME        NULL,
    [InstDeliveryDate]        DATETIME        NULL,
    [InstItemId]              INT             NULL,
    [InstGTIN]                BIGINT          NULL,
    [InstQty]                 INT             NULL,
    [InstUnit]                VARCHAR (5)     NULL,
    [InstOnlinePrice]         DECIMAL (18, 2) NULL,
    [InstBottleDeposit]       DECIMAL (9, 2)  NULL,
    [InstGMV]                 DECIMAL (18, 2) NULL,
    [PosFacilityId]           INT             NULL,
    [PosTransactionDate]      DATE            NULL,
    [PosTransactionTM]        INT             NULL,
    [PosTransactionNumber]    INT             NULL,
    [PosItemId]               INT             NULL,
    [PosSalesVolume]          DECIMAL (9, 2)  NULL,
    [PosSalesVolumeIndicator] VARCHAR (5)     NULL,
    [PosUnitPrice]            DECIMAL (18, 2) NULL,
    [PosSalesType]            INT             NULL,
    [PosSalesAmount]          DECIMAL (18, 2) NULL,
    [PosBottleDeposit]        DECIMAL (9, 2)  NULL,
    [PosTenderAmount]         DECIMAL (18, 2) NULL,
    [SpreadPercentage]        DECIMAL (18, 3) NULL,
    [Reason]                  VARCHAR (50)    NOT NULL,
    [Severity]                VARCHAR (15)    NOT NULL,
    [Type]                    VARCHAR (50)    NOT NULL,
    [Level]                   CHAR (5)        NOT NULL,
    [LastUpdatedBy]           VARCHAR (50)    NOT NULL,
    [LastUpdatedDate]         DATETIME        NOT NULL
);




GO

CREATE INDEX [IX_MapLog_LevelType] ON [dbo].[MapLog] ([Level], [Type])
