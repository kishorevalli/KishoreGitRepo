﻿CREATE TABLE [dbo].[StgPosInstOrderMap] (
    [InstOrderId]                    BIGINT          NULL,
    [InstDeliveryId]                 BIGINT          NULL,
    [InstOrderSplit]                 BIT             NULL,
    [InstOlogStoreLocation]          INT             NULL,
    [InstOlogTransactionDateTime]    DATETIME        NULL,
    [InstOlogTransactionDateEST]     DATE            NULL,
    [InstOlogTransactionDateTimeEST] DATETIME        NULL,
    [InstOlogTransactionAmt]         DECIMAL (18, 2) NULL,
    [PosFacilityId]                  INT             NULL,
    [PosTransactionDate]             DATE            NULL,
    [PosTransactionTM]               INT             NULL,
    [PosTransactionNumber]           INT             NULL,
    [PosTransactionDateTime]         DATETIME        NULL,
    [PosTenderAmount]                DECIMAL (18, 2) NULL,
    [PosTotalSalesIncludingTax]      DECIMAL (18, 2) NULL,
    [PosSalesBeforeTax]              DECIMAL (18, 2) NULL,
    [PosSalesTax]                    DECIMAL (18, 2) NULL,
    [PosNonAlcoholSales]             DECIMAL (18, 2) NULL,
    [PosAlcoholSales]                DECIMAL (18, 2) NULL,
    [PosBottleDeposit]               DECIMAL (9, 2)  NULL,
    [PosCouponValue]                 DECIMAL (9, 2)  NULL,
    [IsByPassCheckOut]               BIT             NULL,
    [MapLevel]                       CHAR (5)        NULL,
    [ExclusionTypeId]                INT             NULL,
    [MapCriteriaId]                  INT             NULL,
    [LastUpdatedBy]                  VARCHAR (50)    NULL,
    [LastUpdatedDate]                DATETIME        NULL
);



