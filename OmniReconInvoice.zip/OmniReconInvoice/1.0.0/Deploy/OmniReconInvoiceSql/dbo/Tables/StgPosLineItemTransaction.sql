﻿CREATE TABLE [dbo].[StgPosLineItemTransaction] (
    [FacilityId]                         INT             NOT NULL,
    [TransactionDate]                    DATETIME        NULL,
    [TransactionTM]                      INT             NULL,
    [TransactionNumber]                  INT             NULL,
    [BusinessDate]                       DATETIME        NULL,
    [LineNumber]                         INT             NULL,
    [ItemId]                             INT             NULL,
    [ItemDescription]                    VARCHAR (250)   NULL,
    [Quantity]                           INT             NULL,
    [SalesVolume]                        DECIMAL (10, 3) NULL,
    [VolumeIndicator]                    CHAR (1)        NULL,
    [GTIN]                               BIGINT          NULL,
    [Void]                               VARCHAR (5)     NULL,
    [Ringcode]                           INT             NULL,
    [RingTM]                             INT             NULL,
    [TaxPlan1]                           BIT             NULL,
    [TaxPlan2]                           BIT             NULL,
    [TaxPlan3]                           BIT             NULL,
    [TaxPlan4]                           BIT             NULL,
    [NetAmount]                          DECIMAL (18, 2) NULL,
    [SalesAmount]                        DECIMAL (18, 2) NULL,
    [NonTaxableSales]                    DECIMAL (18, 2) NULL,
    [CouponValue]                        DECIMAL (18, 2) NULL,
    [TenderAmount]                       DECIMAL (18, 2) NULL,
    [TenderAmountOther]                  DECIMAL (18, 2) NULL,
    [TotalSalesIncludingTax]             DECIMAL (18, 2) NULL,
    [SalesType]                          INT             NULL,
    [RefundSalesFound]                   VARCHAR (3)     NULL,
    [TaxPlan1Amount]                     DECIMAL (18, 2) NULL,
    [TaxPlan2Amount]                     DECIMAL (18, 2) NULL,
    [TaxPlan3Amount]                     DECIMAL (18, 2) NULL,
    [TaxPlan4Amount]                     DECIMAL (18, 2) NULL,
    [TotalTax]                           DECIMAL (18, 2) NULL,
    [TaxableAmount]                      DECIMAL (18, 2) NULL,
    [TaxableSalesTaxPlan1Amount]         DECIMAL (18, 2) NULL,
    [TaxableSalesTaxPlan2Amount]         DECIMAL (18, 2) NULL,
    [TaxableSalesTaxPlan3Amount]         DECIMAL (18, 2) NULL,
    [TaxableSalesTaxPlan1TaxPlan2Amount] DECIMAL (18, 2) NULL,
    [TaxableSalesTaxPlan3TaxPlan2Amount] DECIMAL (18, 2) NULL,
    [AlcoholSales]                       DECIMAL (18, 2) NULL,
    [NonAlcoholSales]                    DECIMAL (18, 2) NULL,
    [TaxableAlcoholSales]                DECIMAL (18, 2) NULL,
    [TaxableNonAlcoholSales]             DECIMAL (18, 2) NULL,
    [NonTaxableAlcoholSales]             DECIMAL (18, 2) NULL,
    [NonTaxableNonAlcoholSales]          DECIMAL (18, 2) NULL,
    [TaxAlcoholSales]                    DECIMAL (18, 2) NULL,
    [TaxNonAlcoholSales]                 DECIMAL (18, 2) NULL,
    [BottleDeposit]                      DECIMAL (9, 2)  NULL,
    [AlcoholFlag]                        BIT             NULL,
    [LiquorCode]                         VARCHAR (3)     NULL,
    [TerminalNumber]                     INT             NULL,
    [TerminalTypeCode]                   VARCHAR (25)    NULL,
    [CardTypeCode]                       VARCHAR (25)    NULL,
    [GTINCheckDigit]                     BIGINT          NULL,
    [TaxPlan1Tax]                        DECIMAL (18, 2) NULL,
    [TaxPlan1TaxPlan2Tax]                DECIMAL (18, 2) NULL,
    [TaxPlan3TaxPlan2Tax]                DECIMAL (18, 2) NULL,
    [TaxPlan3Tax]                        DECIMAL (18, 2) NULL,
    [TenderTypeId]                       SMALLINT        NULL,
    [MaskedAccountString]                VARCHAR (20)    NULL
);


GO
CREATE NONCLUSTERED INDEX [IX_PosLineItemTransactionStaging_TenderTypeId]
    ON [dbo].[StgPosLineItemTransaction]([TenderTypeId] ASC)
    INCLUDE([FacilityID], [TransactionDate], [TransactionTM], [TransactionNumber], [BusinessDate], [LineNumber], [ItemId], [ItemDescription], [Quantity], [SalesVolume], [VolumeIndicator], [GTIN], [Void], [Ringcode], [RingTM], [TaxPlan1], [TaxPlan2], [TaxPlan3], [TaxPlan4], [NetAmount], [SalesAmount], [NonTaxableSales], [CouponValue], [TenderAmount], [TenderAmountOther], [TotalSalesIncludingTax], [SalesType], [RefundSalesFound], [TaxPlan1Amount], [TaxPlan2Amount], [TaxPlan3Amount], [TaxPlan4Amount], [TotalTax], [TaxableAmount], [TaxableSalesTaxPlan1Amount], [TaxableSalesTaxPlan2Amount], [TaxableSalesTaxPlan3Amount], [TaxableSalesTaxPlan1TaxPlan2Amount], [TaxableSalesTaxPlan3TaxPlan2Amount], [AlcoholSales], [NonAlcoholSales], [TaxableAlcoholSales], [TaxableNonAlcoholSales], [NonTaxableAlcoholSales], [NonTaxableNonAlcoholSales], [TaxAlcoholSales], [TaxNonAlcoholSales], [BottleDeposit], [AlcoholFlag], [LiquorCode], [TerminalNumber], [TerminalTypeCode], [CardTypeCode], [GTINCheckDigit], [TaxPlan1Tax], [TaxPlan1TaxPlan2Tax], [TaxPlan3TaxPlan2Tax], [TaxPlan3Tax], [MaskedAccountString]);


GO
CREATE NONCLUSTERED INDEX [IX_PosLineItemTransactionStaging_TransactionTenderTypeId]
    ON [dbo].[StgPosLineItemTransaction]([TransactionDate] ASC, [TenderTypeId] ASC)
    INCLUDE([FacilityID], [TransactionTM], [TransactionNumber], [BusinessDate], [LineNumber], [ItemId], [ItemDescription], [Quantity], [SalesVolume], [VolumeIndicator], [GTIN], [Void], [Ringcode], [RingTM], [TaxPlan1], [TaxPlan2], [TaxPlan3], [TaxPlan4], [NetAmount], [SalesAmount], [NonTaxableSales], [CouponValue], [TenderAmount], [TenderAmountOther], [TotalSalesIncludingTax], [SalesType], [RefundSalesFound], [TaxPlan1Amount], [TaxPlan2Amount], [TaxPlan3Amount], [TaxPlan4Amount], [TotalTax], [TaxableAmount], [TaxableSalesTaxPlan1Amount], [TaxableSalesTaxPlan2Amount], [TaxableSalesTaxPlan3Amount], [TaxableSalesTaxPlan1TaxPlan2Amount], [TaxableSalesTaxPlan3TaxPlan2Amount], [AlcoholSales], [NonAlcoholSales], [TaxableAlcoholSales], [TaxableNonAlcoholSales], [NonTaxableAlcoholSales], [NonTaxableNonAlcoholSales], [TaxAlcoholSales], [TaxNonAlcoholSales], [BottleDeposit], [AlcoholFlag], [LiquorCode], [TerminalNumber], [TerminalTypeCode], [CardTypeCode], [GTINCheckDigit], [TaxPlan1Tax], [TaxPlan1TaxPlan2Tax], [TaxPlan3TaxPlan2Tax], [TaxPlan3Tax], [MaskedAccountString]);

