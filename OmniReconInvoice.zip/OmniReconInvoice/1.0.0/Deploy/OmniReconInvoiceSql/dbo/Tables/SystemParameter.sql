﻿CREATE TABLE [dbo].[SystemParameter] (
    [Id]             INT           IDENTITY (1, 1) NOT NULL,
    [KeyName]        VARCHAR (255) NOT NULL,
    [ParameterValue] VARCHAR (500) NOT NULL,
    [Description]    VARCHAR (500) NULL,
    CONSTRAINT [PK_SystemParameter] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 80)
);

