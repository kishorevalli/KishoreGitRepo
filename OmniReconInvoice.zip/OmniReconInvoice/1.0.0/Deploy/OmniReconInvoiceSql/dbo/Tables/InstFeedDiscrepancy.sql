﻿CREATE TABLE [dbo].[InstFeedDiscrepancy] (
    [InstOrderId]                BIGINT          NOT NULL,
    [InstDeliveryId]             BIGINT          NOT NULL,
    [InstOrderedDateEst]         DATETIME        NOT NULL,
    [InstDeliveredDateEst]       DATETIME        NOT NULL,
    [InstStoreLocation]          INT             NOT NULL,
    [InstRefereneCode]           INT             NOT NULL,
    [InstGTIN]                   BIGINT          NOT NULL,
    [InstUnit]                   VARCHAR (10)    NOT NULL,
    [InstQty]                    DECIMAL (9, 2)  NOT NULL,
    [InstOnlinePrice]            DECIMAL (18, 2) NOT NULL,
    [InstOnlineRevenue]          DECIMAL (18, 2) NOT NULL,
    [InstAlcoholFlag]            VARCHAR (5)     NOT NULL,
    [InstBottleDeposit]          DECIMAL (18, 2) NOT NULL,
    [InstPriceSource]            VARCHAR (50)    NOT NULL,
    [FeedLoadDate]               DATE            NOT NULL,
    [FeedStoreNumber]            INT             NOT NULL,
    [FeedRRC]                    INT             NOT NULL,
    [FeedScanCode]               BIGINT          NOT NULL,
    [FeedCostUnit]               VARCHAR (10)    NOT NULL,
    [FeedMarkUpPriceRounded]     DECIMAL (18, 2) NOT NULL,
    [FeedUnitPrice]              DECIMAL (18, 2) NOT NULL,
    [FeedMarkUpSalePriceRounded] DECIMAL (18, 2) NOT NULL,
    [FeedSalePrice]              DECIMAL (18, 2) NOT NULL,
    [FeedBogo]                   VARCHAR (5)     NOT NULL,
    [FeedPromoGroupId]           INT             NOT NULL,
    [FeedPromoStartDate]         DATE            NOT NULL,
    [FeedPromoEndDate]           DATE            NOT NULL,
    [FeedAlcoholFlag]            VARCHAR (5)     NOT NULL,
    [FeedBottleDeposit]          DECIMAL (18, 2) NOT NULL,
    [Type]                       VARCHAR (100)   NOT NULL,
    [MapCriteriaId]              INT             NOT NULL,
    [LastUpdatedBy]              VARCHAR (50)    NOT NULL,
    [LastUpdatedDate]            DATETIME        NOT NULL
);










GO
CREATE NONCLUSTERED INDEX [IX_NC_InstFeedDiscrepancy_OrderIdDeliveryId]
    ON [dbo].[InstFeedDiscrepancy]([InstOrderid] ASC, [InstDeliveryid] ASC);

