﻿CREATE TABLE [dbo].[SystemValues] (
    [Id]          BIGINT        IDENTITY (1, 1) NOT NULL,
    [KeyName]     VARCHAR (255) NOT NULL,
    [Value]       VARCHAR (MAX) NOT NULL,
    [Description] VARCHAR (500) NULL,
    CONSTRAINT [PK_SystemValues_t] PRIMARY KEY CLUSTERED ([Id] ASC)
);



