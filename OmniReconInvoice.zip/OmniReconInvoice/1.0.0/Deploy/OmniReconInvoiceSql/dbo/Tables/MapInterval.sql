﻿CREATE TABLE [dbo].[MapInterval] (
    [Daily]     BIT            NOT NULL,
    [DateRange] BIT            NOT NULL,
    [FromDate]  DATETIME       NULL,
    [ToDate]    DATETIME       NULL,
    [Orders]    BIT            NULL,
    [OrderIds]  VARCHAR (2000) NOT NULL,
    CONSTRAINT [chk_MapInterval_Any] CHECK ([Daily]=(1) AND [Orders]=(0) AND [DateRange]=(0) OR [Daily]=(0) AND [Orders]=(1) AND [DateRange]=(0) OR [Daily]=(0) AND [Orders]=(0) AND [DateRange]=(1)),
    CONSTRAINT [chk_MapInterval_Daily] CHECK ([Daily]=(1) AND [DateRange]=(0) AND [Orders]=(0) OR [Daily]=(0)),
    CONSTRAINT [chk_MapInterval_DateRange] CHECK ([Daily]=(0) AND [Orders]=(0) AND [DateRange]=(1) AND [FromDate] IS NOT NULL AND [ToDate] IS NOT NULL OR [DateRange]=(0)),
    CONSTRAINT [chk_MapInterval_Weekly] CHECK ([Daily]=(0) AND [Orders]=(1) AND [DateRange]=(0) AND [OrderIds] IS NOT NULL OR [Orders]=(0))
);



