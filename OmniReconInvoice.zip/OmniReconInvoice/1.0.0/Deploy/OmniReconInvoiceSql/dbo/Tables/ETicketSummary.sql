﻿CREATE TABLE [dbo].[ETicketSummary] (
    [Id]                              DECIMAL (25)    NOT NULL,
    [StoreNumber]                     INT             NOT NULL,
    [TransactionDate]                 DATETIME        NOT NULL,
    [InstTaxPlan1Tax]                 DECIMAL (18, 2) NOT NULL,
    [InstTaxPlan1TaxPlan2Tax]         DECIMAL (18, 2) NOT NULL,
    [InstTaxPlan3TaxPlan2Tax]         DECIMAL (18, 2) NOT NULL,
    [InstTaxPlan3Tax]                 DECIMAL (18, 2) NOT NULL,
    [InstSalesBeforeTax]              DECIMAL (18, 2) NOT NULL,
    [InstGMV]                         DECIMAL (18, 2) NOT NULL,
    [PosTaxPlan1Tax]                  DECIMAL (18, 2) NOT NULL,
    [PosTaxPlan1TaxPlan2Tax]          DECIMAL (18, 2) NOT NULL,
    [PosTaxPlan3TaxPlan2Tax]          DECIMAL (18, 2) NOT NULL,
    [PosTaxPlan3Tax]                  DECIMAL (18, 2) NOT NULL,
    [PosSalesBeforeTax]               DECIMAL (18, 2) NOT NULL,
    [PosTotalSalesIncludingTax]       DECIMAL (18, 2) NOT NULL,
    [SalesBeforeTaxGap]               DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxGap]                  DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxPlan2TaxGap]          DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxPlan2TaxGap]          DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxGap]                  DECIMAL (18, 2) NOT NULL,
    [NonTaxableSalesGap]              DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxableSalesGap]         DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxPlan2TaxableSalesGap] DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxPlan2TaxableSalesGap] DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxableSalesGap]         DECIMAL (18, 2) NOT NULL,
    [PublishETicketId]                BIGINT          NULL,
    [LastUpdatedDate]                 DATETIME        NOT NULL,
    [LastUpdatedBy]                   VARCHAR (50)    NOT NULL,
    CONSTRAINT [PK_ETicketSummary_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);



