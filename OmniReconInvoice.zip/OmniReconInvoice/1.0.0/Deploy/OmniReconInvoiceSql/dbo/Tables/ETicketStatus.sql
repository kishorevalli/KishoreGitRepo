﻿CREATE TABLE [dbo].[ETicketStatus] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [Status]      VARCHAR (15)  NULL,
    [Description] VARCHAR (100) NULL,
    CONSTRAINT [PK_ETicketStatus_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);

