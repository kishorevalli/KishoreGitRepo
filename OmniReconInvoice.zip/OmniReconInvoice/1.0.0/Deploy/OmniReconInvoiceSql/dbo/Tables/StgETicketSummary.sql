﻿CREATE TABLE [dbo].[StgETicketSummary] (
    [Id]                              DECIMAL (25)    NULL,
    [StoreNumber]                     INT             NULL,
    [TransactionDate]                 DATETIME        NULL,
    [InstTaxPlan1Tax]                 DECIMAL (18, 2) NULL,
    [InstTaxPlan1TaxPlan2Tax]         DECIMAL (18, 2) NULL,
    [InstTaxPlan3TaxPlan2Tax]         DECIMAL (18, 2) NULL,
    [InstTaxPlan3Tax]                 DECIMAL (18, 2) NULL,
    [InstSalesBeforeTax]              DECIMAL (18, 2) NULL,
    [InstGMV]                         DECIMAL (18, 2) NULL,
    [PosTaxPlan1Tax]                  DECIMAL (18, 2) NULL,
    [PosTaxPlan1TaxPlan2Tax]          DECIMAL (18, 2) NULL,
    [PosTaxPlan3TaxPlan2Tax]          DECIMAL (18, 2) NULL,
    [PosTaxPlan3Tax]                  DECIMAL (18, 2) NULL,
    [PosSalesBeforeTax]               DECIMAL (18, 2) NULL,
    [PosTotalSalesIncludingTax]       DECIMAL (18, 2) NULL,
    [SalesBeforeTaxGap]               DECIMAL (18, 2) NULL,
    [TaxPlan1TaxGap]                  DECIMAL (18, 2) NULL,
    [TaxPlan1TaxPlan2TaxGap]          DECIMAL (18, 2) NULL,
    [TaxPlan3TaxPlan2TaxGap]          DECIMAL (18, 2) NULL,
    [TaxPlan3TaxGap]                  DECIMAL (18, 2) NULL,
    [NonTaxableSalesGap]              DECIMAL (18, 2) NULL,
    [TaxPlan1TaxableSalesGap]         DECIMAL (18, 2) NULL,
    [TaxPlan1TaxPlan2TaxableSalesGap] DECIMAL (18, 2) NULL,
    [TaxPlan3TaxPlan2TaxableSalesGap] DECIMAL (18, 2) NULL,
    [TaxPlan3TaxableSalesGap]         DECIMAL (18, 2) NULL,
    [PublishETicketId]                BIGINT          NULL,
    [LastUpdatedDate]                 DATETIME        NULL,
    [LastUpdatedBy]                   VARCHAR (50)    NULL
);



