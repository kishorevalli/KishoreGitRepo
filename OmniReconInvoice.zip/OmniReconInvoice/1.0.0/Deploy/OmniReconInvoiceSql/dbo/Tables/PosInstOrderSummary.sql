﻿CREATE TABLE [dbo].[PosInstOrderSummary] (
    [InstOrderId]                     BIGINT          NOT NULL,
    [InstDeliveryId]                  BIGINT          NOT NULL,
    [IsMappedItemsGroup]              BIT             NOT NULL,
    [InstOnlineRevenue]               DECIMAL (18, 2) NOT NULL,
    [InstPreTaxNonAlcoholSales]       DECIMAL (18, 2) NOT NULL,
    [InstPreTaxAlcoholSales]          DECIMAL (18, 2) NOT NULL,
    [InstSalesTax]                    DECIMAL (18, 2) NOT NULL,
    [InstBottleDeposit]               DECIMAL (9, 2)  NOT NULL,
    [InstGMV]                         DECIMAL (18, 2) NOT NULL,
    [InstAdjOnlineRevenue]            DECIMAL (18, 2) NOT NULL,
    [InstAdjPreTaxNonAlcoholSales]    DECIMAL (18, 2) NOT NULL,
    [InstAdjPreTaxAlcoholSales]       DECIMAL (18, 2) NOT NULL,
    [InstAdjSalesTax]                 DECIMAL (18, 2) NOT NULL,
    [InstAdjBottleDeposit]            DECIMAL (9, 2)  NOT NULL,
    [InstAdjGMV]                      DECIMAL (18, 2) NOT NULL,
    [InstTaxPlan1Tax]                 DECIMAL (18, 2) NOT NULL,
    [InstTaxPlan1TaxPlan2Tax]         DECIMAL (18, 2) NOT NULL,
    [InstTaxPlan3TaxPlan2Tax]         DECIMAL (18, 2) NOT NULL,
    [InstTaxPlan3Tax]                 DECIMAL (18, 2) NOT NULL,
    [PosFacilityId]                   INT             NOT NULL,
    [PosTransactionDate]              DATETIME        NULL,
    [PosTransactionTM]                INT             NOT NULL,
    [PosTransactionNumber]            INT             NOT NULL,
    [PosSalesAmount]                  DECIMAL (18, 2) NOT NULL,
    [PosPreTaxNonAlcoholSales]        DECIMAL (18, 2) NOT NULL,
    [PosPreTaxAlcoholSales]           DECIMAL (18, 2) NOT NULL,
    [PosBottleDeposit]                DECIMAL (18, 2) NOT NULL,
    [PosTotalTax]                     DECIMAL (18, 2) NOT NULL,
    [PosTotalSalesIncludingTax]       DECIMAL (18, 2) NOT NULL,
    [PosAdjSalesAmount]               DECIMAL (18, 2) NOT NULL,
    [PosAdjPreTaxNonAlcoholSales]     DECIMAL (18, 2) NOT NULL,
    [PosAdjPreTaxAlcoholSales]        DECIMAL (18, 2) NOT NULL,
    [PosAdjTotalTax]                  DECIMAL (18, 2) NOT NULL,
    [PosAdjTotalSalesIncludingTax]    DECIMAL (18, 2) NOT NULL,
    [PosTaxPlan1Tax]                  DECIMAL (18, 2) NOT NULL,
    [PosTaxPlan1TaxPlan2Tax]          DECIMAL (18, 2) NOT NULL,
    [PosTaxPlan3TaxPlan2Tax]          DECIMAL (18, 2) NOT NULL,
    [PosTaxPlan3Tax]                  DECIMAL (18, 2) NOT NULL,
    [TotalTaxGap]                     DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxGap]                  DECIMAL (18, 2) NULL,
    [TaxPlan1TaxPlan2TaxGap]          DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxPlan2TaxGap]          DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxGap]                  DECIMAL (18, 2) NOT NULL,
    [NonTaxableSalesGap]              DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxableSalesGap]         DECIMAL (18, 2) NOT NULL,
    [TaxPlan1TaxPlan2TaxableSalesGap] DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxPlan2TaxableSalesGap] DECIMAL (18, 2) NOT NULL,
    [TaxPlan3TaxableSalesGap]         DECIMAL (18, 2) NOT NULL,
    [SpreadAmount]                    DECIMAL (18, 2) NOT NULL,
    [SpreadPercentage]                DECIMAL (18, 3) NOT NULL,
    [LastUpdatedBy]                   VARCHAR (50)    NOT NULL,
    [LastUpdatedDate]                 DATETIME        NOT NULL
);








GO

CREATE INDEX [IX_PosInstOrderSummary_InstOrderIdInstDeliveryId] ON [dbo].[PosInstOrderSummary] ([InstOrderId], [InstDeliveryId])
