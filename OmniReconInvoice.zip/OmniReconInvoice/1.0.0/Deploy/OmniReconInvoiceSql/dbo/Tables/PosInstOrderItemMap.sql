﻿CREATE TABLE [dbo].[PosInstOrderItemMap] (
    [InstOrderID]                  BIGINT          NOT NULL,
    [InstDeliveryID]               BIGINT          NOT NULL,
    [InstStoreLocation]            INT             NOT NULL,
    [InstOrderedDateEst]           DATETIME        NULL,
    [InstDeliveryDateEst]          DATETIME        NULL,
    [InstReferenceCode]            INT             NULL,
    [InstGTIN]                     BIGINT          NULL,
    [InstItemName]                 VARCHAR (500)   NULL,
    [InstIsAlcohol]                BIT             NULL,
    [InstPriceSource]              VARCHAR (50)    NULL,
    [InstQty]                      DECIMAL (18, 2) NULL,
    [InstUnit]                     VARCHAR (15)    NULL,
    [InstOnlinePrice]              DECIMAL (18, 2) NULL,
    [InstOnlineRevenue]            DECIMAL (18, 2) NULL,
    [InstSalesTax]                 DECIMAL (18, 2) NULL,
    [InstBottleDeposit]            DECIMAL (9, 2)  NULL,
    [InstGMV]                      DECIMAL (18, 2) NULL,
    [InstAdjIsAlcohol]             BIT             NULL,
    [InstAdjQty]                   DECIMAL (18, 2) NULL,
    [InstAdjUnit]                  VARCHAR (15)    NULL,
    [InstAdjOnlinePrice]           DECIMAL (18, 2) NULL,
    [InstAdjOnlineRevenue]         DECIMAL (18, 2) NULL,
    [InstAdjSalesTax]              DECIMAL (18, 2) NULL,
    [InstAdjBottleDeposit]         DECIMAL (9, 2)  NULL,
    [InstAdjGMV]                   DECIMAL (18, 2) NULL,
    [InstTaxPlan1Tax]              DECIMAL (18, 2) NULL,
    [InstTaxPlan1TaxPlan2Tax]      DECIMAL (18, 2) NULL,
    [InstTaxPlan3TaxPlan2Tax]      DECIMAL (18, 2) NULL,
    [InstTaxPlan3Tax]              DECIMAL (18, 2) NULL,
    [PosFacilityId]                INT             NULL,
    [PosTransactionDate]           DATETIME        NULL,
    [PosTransactionTM]             INT             NULL,
    [PosTransactionNumber]         INT             NULL,
    [PosItemId]                    INT             NULL,
    [PosGTIN]                      BIGINT          NULL,
    [PosItemName]                  VARCHAR (500)   NULL,
    [PosSalesType]                 INT             NULL,
    [PosIsAlcohol]                 BIT             NULL,
    [PosSalesVolume]               DECIMAL (10, 3) NULL,
    [PosSalesVolumeIndicator]      VARCHAR (5)     NULL,
    [PosSalesAmount]               DECIMAL (18, 2) NULL,
    [PosTotalTax]                  DECIMAL (18, 2) NULL,
    [PosTotalSalesIncludingTax]    DECIMAL (18, 2) NULL,
    [PosAdjSalesVolume]            DECIMAL (10, 3) NULL,
    [PosAdjSalesVolumeIndicator]   VARCHAR (5)     NULL,
    [PosAdjSalesAmount]            DECIMAL (18, 2) NULL,
    [PosAdjTotalTax]               DECIMAL (18, 2) NULL,
    [PosAdjTotalSalesIncludingTax] DECIMAL (18, 2) NULL,
    [PosTaxPlan1Tax]               DECIMAL (18, 2) NULL,
    [PosTaxPlan1TaxPlan2Tax]       DECIMAL (18, 2) NULL,
    [PosTaxPlan3TaxPlan2Tax]       DECIMAL (18, 2) NULL,
    [PosTaxPlan3Tax]               DECIMAL (18, 2) NULL,
    [SpreadAmount]                 DECIMAL (18, 2) NULL,
    [SpreadPercentage]             DECIMAL (18, 3) NULL,
    [ExclusionTypeId]              INT             NULL,
    [MapCriteriaId]                INT             NOT NULL,
    [LastUpdatedBy]                VARCHAR (50)    NOT NULL,
    [LastUpdatedDate]              DATETIME        NOT NULL
);












GO

CREATE INDEX [IX_PosInstOrderItemMap_InstOrderIdInstDeliveryId] ON [dbo].[PosInstOrderItemMap] ([InstOrderID], [InstDeliveryID])
