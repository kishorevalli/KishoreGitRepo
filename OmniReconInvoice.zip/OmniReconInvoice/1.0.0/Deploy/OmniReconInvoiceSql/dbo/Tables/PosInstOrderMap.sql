﻿CREATE TABLE [dbo].[PosInstOrderMap] (
    [InstOrderId]                    BIGINT          NOT NULL,
    [InstDeliveryId]                 BIGINT          NOT NULL,
    [InstOrderSplit]                 BIT             NOT NULL,
    [InstOlogStoreLocation]          INT             NOT NULL,
    [InstOlogTransactionDateTime]    DATETIME        NULL,
    [InstOlogTransactionDateEST]     DATE            NULL,
    [InstOlogTransactionDateTimeEST] DATETIME        NULL,
    [InstOlogTransactionAmt]         DECIMAL (18, 2) NOT NULL,
    [PosFacilityId]                  INT             NOT NULL,
    [PosTransactionDate]             DATE            NULL,
    [PosTransactionTM]               INT             NOT NULL,
    [PosTransactionNumber]           INT             NOT NULL,
    [PosTransactionDateTime]         DATETIME        NULL,
    [PosTenderAmount]                DECIMAL (18, 2) NOT NULL,
    [PosTotalSalesIncludingTax]      DECIMAL (18, 2) NOT NULL,
    [PosSalesBeforeTax]              DECIMAL (18, 2) NOT NULL,
    [PosSalesTax]                    DECIMAL (18, 2) NOT NULL,
    [PosNonAlcoholSales]             DECIMAL (18, 2) NOT NULL,
    [PosAlcoholSales]                DECIMAL (18, 2) NOT NULL,
    [PosBottleDeposit]               DECIMAL (9, 2)  NOT NULL,
    [PosCouponValue]                 DECIMAL (9, 2)  NOT NULL,
    [IsByPassCheckOut]               BIT             NOT NULL,
    [MapLevel]                       CHAR (5)        NOT NULL,
    [ExclusionTypeId]                INT             NOT NULL,
    [ETicketStatusId]                INT             NULL,
    [MapCriteriaId]                  INT             NOT NULL,
    [LastUpdatedBy]                  VARCHAR (50)    NOT NULL,
    [LastUpdatedDate]                DATETIME        NOT NULL,
    CONSTRAINT [FK_PosInstOrderMap_ETicketStatus] FOREIGN KEY ([ETicketStatusId]) REFERENCES [dbo].[ETicketStatus] ([Id]),
    CONSTRAINT [FK_PosInstOrderMap_ExclusionType] FOREIGN KEY ([ExclusionTypeId]) REFERENCES [dbo].[ExclusionType] ([Id]),
    CONSTRAINT [FK_PosInstOrderMap_MapCriteria] FOREIGN KEY ([MapCriteriaId]) REFERENCES [dbo].[MapCriteria] ([Id]),
    CONSTRAINT [FK_PosInstOrderMap_MapLevel] FOREIGN KEY ([MapLevel]) REFERENCES [dbo].[MapLevel] ([Level])
);


GO
CREATE NONCLUSTERED INDEX [IX_PosInstOrderMap_MapLevel]
    ON [dbo].[PosInstOrderMap]([MapLevel] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_PosInstOrderMap_InstOrderIdInstDeliveryId]
    ON [dbo].[PosInstOrderMap]([InstOrderId] ASC, [InstDeliveryId] ASC);


GO