﻿CREATE TABLE [dbo].[MapCriteria] (
    [Id]       INT           NOT NULL,
    [Criteria] VARCHAR (100) NOT NULL,
    CONSTRAINT [PK_MapCriteria] PRIMARY KEY CLUSTERED ([Id] ASC)
);





