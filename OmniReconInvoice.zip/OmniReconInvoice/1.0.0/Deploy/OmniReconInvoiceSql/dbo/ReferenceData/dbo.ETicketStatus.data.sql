SET IDENTITY_INSERT [dbo].[ETicketStatus] ON
INSERT INTO [dbo].[ETicketStatus] ([Id], [Status], [Description]) VALUES (1, N'Summary', N'Creates summary of the ETicket by TransationDate & StoreNumber')
INSERT INTO [dbo].[ETicketStatus] ([Id], [Status], [Description]) VALUES (2, N'Generate', N'Generates the Eticket for all the ETicket Summary Records')
INSERT INTO [dbo].[ETicketStatus] ([Id], [Status], [Description]) VALUES (3, N'Publish', N'Publishes the Etickets')
SET IDENTITY_INSERT [dbo].[ETicketStatus] OFF
