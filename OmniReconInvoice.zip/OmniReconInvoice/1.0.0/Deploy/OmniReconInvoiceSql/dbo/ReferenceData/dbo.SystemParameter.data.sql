TRUNCATE TABLE [dbo].[SystemParameter]
SET IDENTITY_INSERT [dbo].[SystemParameter] ON
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (1, N'POSEticketMQQueueManager-Development', N'L47AMQLB2', N'Queue Manager name')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (2, N'POSEticketMQQueueManager-Test', N'L47AMQLB1', N'Queue Manager name')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (3, N'POSEticketMQQueueManager-Staging', N'SOMNIBA01', N'Queue Manager')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (4, N'POSEticketMQQueueManager-Production', N'POMNIBA01', N'Queue Manager')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (5, N'POSEticketMQQueue-Development', N'A.EAI.CREATESALESTRANSACTION', N'Queue Name for CreateSalesTransaction')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (6, N'POSEticketMQQueue-Test', N'A.EAI.CREATESALESTRANSACTION', N'Queue Name for CreateSalesTransaction')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (7, N'POSEticketMQQueue-Staging', N'EAI.CREATESALESTRANSACTION', N'Queue Name for CreateSalesTransaction')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (8, N'POSEticketMQQueue-Production', N'EAI.CREATESALESTRANSACTION', N'Queue Name for CreateSalesTransaction')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (9, N'JobMachineIdentifier-Development', N'DOMNIBA01', N'Job machine Identifier')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (10, N'JobMachineIdentifier-Test', N'TOMNIBA01', N'Job machine Identifier')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (11, N'JobMachineIdentifier-Staging', N'SOMNIBA02', N'Job machine Identifier')
INSERT INTO [dbo].[SystemParameter] ([Id], [KeyName], [ParameterValue], [Description]) VALUES (12, N'JobMachineIdentifier-Production', N'POMNIBA02', N'Job machine Identifier')
SET IDENTITY_INSERT [dbo].[SystemParameter] OFF
