SET IDENTITY_INSERT [dbo].[MapLevel] ON
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (1, N'ORDMP', N'Order Level Map complete for order')
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (2, N'DISCP', N'Discrepancy Checks Complete')
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (3, N'ITMAP', N'Item Level Map complete for order')
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (4, N'ORSUM', N'Summary level of the Order ')
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (5, N'INVCP', N'Invoice of the order is compelete')
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (6, N'FEECP', N'Fee applied for Invoices')
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (7, N'UNMAP', N'Order Unmapped')
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (8, N'TMPIT', N'Temporary Level for processing Item level Orders')
INSERT INTO [dbo].[MapLevel] ([Id], [Level], [Description]) VALUES (9, N'TMPIN', N'Temporary Level for processing Invoice level Orders')
SET IDENTITY_INSERT [dbo].[MapLevel] OFF