SET IDENTITY_INSERT [dbo].[InvoiceFeeRate] ON
INSERT INTO [dbo].[InvoiceFeeRate] ([Id], [State], [Market], [DeliveryModel], [FromOrdersCount], [ToOrdersCount], [FlatAlcoholFee], [FlatAlcoholFeeDiscount], [MarkupPercentDiscount]) VALUES (1, N'FLORIDA', N'Tampa', N'Publix Curb Side', 1, 5000, CAST(1.55 AS Decimal(18, 2)), CAST(0.00 AS Decimal(18, 2)), CAST(0.00 AS Decimal(18, 2)))
INSERT INTO [dbo].[InvoiceFeeRate] ([Id], [State], [Market], [DeliveryModel], [FromOrdersCount], [ToOrdersCount], [FlatAlcoholFee], [FlatAlcoholFeeDiscount], [MarkupPercentDiscount]) VALUES (2, N'FLORIDA', N'Tampa', N'Publix Curb Side', 5001, 999999, CAST(1.55 AS Decimal(18, 2)), CAST(0.20 AS Decimal(18, 2)), CAST(0.00 AS Decimal(18, 2)))
SET IDENTITY_INSERT [dbo].[InvoiceFeeRate] OFF
