TRUNCATE TABLE [dbo].[SystemValues]
SET IDENTITY_INSERT [dbo].[SystemValues] ON
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (1, N'MaxDegreeOfParallelismForMapOLogTLogToPos', N'200', N'Max parallelism for processing')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (2, N'NoOfDaysAdditionalPOSTransactionsData', N'5', N'No of additional previous days Pos Transactions needs to be retreived for Mapping.  This will be used mostly for Returns Pos Inst Order Mapping')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (3, N'SushiChineseFamilyGroup', N'251001,412002', N'These family groups will be excluded from POS Transactions, as they are Sushi & Chinese')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (4, N'PanamaCityStores', N'481,1241', N'These are panamacity stores for 1% license fee calculation')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (5, N'MinimumAcceptableSpreadPercentage', N'9.5', N'Minimum Acceptable spread pecerntage for order')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (6, N'MaximumAcceptableSpreadPercentage', N'999', N'Maximum Acceptable spread pecerntage for order')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (7, N'QueryCommandTimeout', N'21600', N'The total Amount to time for the command to exec')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (7, N'QueryCommandTimeout', N'21600', N'The total Amount to time for the command to exec')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (8, N'LiveDateToAdjustSalesTax', N'2018-08-01', N'Incase of any discreapncies, the sales tax for Instcart will get adjusted, only for the orders after the live date')
INSERT INTO [dbo].[SystemValues] ([Id], [KeyName], [Value], [Description]) VALUES (9, N'MinHistoryDateForItemFeed', N'30', N'Min no. of days from Today for Item Feed data available in History')
SET IDENTITY_INSERT [dbo].[SystemValues] OFF