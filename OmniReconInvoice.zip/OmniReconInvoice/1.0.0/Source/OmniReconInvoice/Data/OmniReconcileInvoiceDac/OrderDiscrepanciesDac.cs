﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Data.SqlClient;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Data;
using Dapper;
using FastMember;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public class OrderDiscrepanciesDac : CommonDac, IOrderDiscrepanciesDac
    {
        readonly static log4net.ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public async Task<IEnumerable<MappedOrderDTO>> GetMappedOrdersForDiscrepancy(string orderlevel)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<MappedOrderDTO>(OmniReconQueries.qryGetMappedOrdersForDiscrepancy,
                                                                                    new { @MapLevel = orderlevel },
                                                                                    commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItem(DateTime loaddate, int storenumber, int itemid)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetPriceUomDisrecpancyByItemFromHistory,
                                                                                         new { @LoadDate = loaddate, @StoreNumber = storenumber, @ItemId = itemid },
                                                                                         commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }
        }

        public async Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItem(DateTime loaddate, int storenumber, int itemid, bool archive)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_ARCH_Connection)
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetPriceUomDisrecpancyByItemFromHistoryArchive,
                                                                                         new { @LoadDate = loaddate, @StoreNumber = storenumber, @ItemId = itemid },
                                                                                         commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }

        }

        public async Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByScanCode(DateTime loaddate, int storenumber, Int64 scancode)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection) // From OMNI
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetPriceUomDisrecpancyByScanCodeFromHistory,
                                                                                         new { @LoadDate = loaddate, @StoreNumber = storenumber, @ScanCode = scancode },
                                                                                         commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }
        }

        public async Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByScanCode(DateTime loaddate, int storenumber, Int64 scancode, bool archive)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_ARCH_Connection) // From Archive
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetPriceUomDisrecpancyByScanCodeFromHistoryArchive,
                                                                                         new { @LoadDate = loaddate, @StoreNumber = storenumber, @ScanCode = scancode },
                                                                                         commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }
        }

        public async Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItemGTINScanCode(DateTime loaddate, int storenumber, Int64 scancode)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection) // From OMNI
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetPriceUomDisrecpancyFromHistoryByItemGTINScanCode,
                                                                                         new { @LoadDate = loaddate, @StoreNumber = storenumber, @ScanCode = scancode },
                                                                                        commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }
        }

        public async Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItemGTINScanCode(DateTime loaddate, int storenumber, Int64 scancode, bool archive)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_ARCH_Connection) // From Archive
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetPriceUomDisrecpancyFromHistoryByItemGTINScanCodeArchive,
                                                                                         new { @LoadDate = loaddate, @StoreNumber = storenumber, @ScanCode = scancode },
                                                                                        commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }
        }

        public async Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCode(DateTime loaddate, int storenumber, Int64 scancode)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection) // From OMNI
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCode,
                                                                                         new { @LoadDate = loaddate, @StoreNumber = storenumber, @ScanCode = scancode },
                                                                                        commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }
        }

        public async Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCode(DateTime loaddate, int storenumber, Int64 scancode, bool archive)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_ARCH_Connection) // From Archive
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCodeArchive,
                                                                                         new { @LoadDate = loaddate, @StoreNumber = storenumber, @ScanCode = scancode },
                                                                                        commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }
        }

        public async Task<bool> ValidateLoadDateExistsInHistory(DateTime loaddate)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection) // From OMNI
            {
                var result = await conn.ExecuteScalarAsync<bool>(OmniReconQueries.qryValidateLoadDateExists, new { @LoadDate = loaddate }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task PushDiscrepancyDataStagingTomain()
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.ExecuteAsync(OmniReconQueries.qryPushDiscrepancyDataStagingTomain, commandTimeout: CommandTimeOut);
            }
        }

        public async Task<IEnumerable<ItemDataHistoryDTO>> GetHistoryDataByStore(int storeid, DateTime loaddate)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection) // From OMNI
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetHistoryDataByStore,
                                                                                         new { @StoreNumber = storeid, @LoadDate = loaddate },
                                                                                            commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<IEnumerable<ItemDataHistoryDTO>> GetHistoryDataByStoreFromArchive(int storeid, DateTime loaddate)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_ARCH_Connection) // From Archive
            {
                var result = await conn.QueryAsync<ItemDataHistoryDTO>(OmniReconQueries.qryGetHistoryDataByStoreFromArchive,
                                                                                         new { @StoreNumber = storeid, @LoadDate = loaddate },
                                                                                        commandTimeout: CommandTimeOut);
                return result;
            }
        }

    }
}
