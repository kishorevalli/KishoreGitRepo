﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Data.SqlClient;
using Dapper;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public class OrderAggregatedDac : CommonDac, IOrderAggregatedDac
    {
        public async Task<bool> CheckItemExclusionAppliedForOrder(long instOrderId, long instDeliveryId)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.ExecuteScalarAsync<bool>(OmniReconQueries.qryCheckItemExclusionAppliedForOrder, new { @OrderId = instOrderId, @DeliveryId = instDeliveryId }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<IEnumerable<PosInstOrderSummaryDTO>> GetOrderSummaryDetails(Int64 instOrderId, Int64 deliveryId)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<PosInstOrderSummaryDTO>(OmniReconQueries.qryGetOrderSummaryDetails, new { @OrderId = instOrderId, @DeliveryId = deliveryId }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task MoveInvoiceOrdersStgToMain(string maplevel, string tmplevel, string itmLevel, int etickestatus)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.ExecuteAsync(OmniReconQueries.qryMoveInvoiceOrdersStgToMain, new { @MapLevel = maplevel, @TMPLEVEL = tmplevel, @ITMLEVEL = itmLevel, @ETicketStatus = etickestatus }, commandTimeout: CommandTimeOut);
            }
        }
    }
}
