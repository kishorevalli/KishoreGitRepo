﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public class OmniReconQueries
    {

        internal static string qryGetBypassCheckoutOrdersByOrderId = @"
         SELECT 
		 plit.FacilityId
        ,plit.TransactionDate
        ,plit.TransactionTM
        ,plit.TransactionNumber
        ,plit.TransactionDate + CAST(DATEADD(HOUR, (TransactionTM/100)%100, DATEADD(MINUTE, (TransactionTM%100), CAST('00:00'as TIME(2)))) as datetime) as TransactionTime
        ,plit.TenderAmount
        ,plit.TotalSalesIncludingTax + plit.CouponValue as TotalSalesIncludingTax
        ,plit.SalesAmount as SalesBeforeTax
        ,plit.TotalTax as SalesTax
        ,plit.NonAlcoholSales
        ,plit.AlcoholSales
        ,plit.BottleDeposit
		,plit.CouponValue
		,plit.MaskedAccountString
        FROM StgPosLineItemTransaction plit
        WHERE TenderTypeId IN (83, 86)
        AND MaskedAccountString in ({0})
        ";

        internal static string qryGetBypassCheckoutOrdersByDateRange = @"
         SELECT 
		 plit.FacilityId
        ,plit.TransactionDate
        ,plit.TransactionTM
        ,plit.TransactionNumber
        ,plit.TransactionDate + CAST(DATEADD(HOUR, (TransactionTM/100)%100, DATEADD(MINUTE, (TransactionTM%100), CAST('00:00'as TIME(2)))) as datetime) as TransactionTime
        ,plit.TenderAmount
        ,plit.TotalSalesIncludingTax + plit.CouponValue as TotalSalesIncludingTax
        ,plit.SalesAmount as SalesBeforeTax
        ,plit.TotalTax as SalesTax
        ,plit.NonAlcoholSales
        ,plit.AlcoholSales
        ,plit.BottleDeposit
		,plit.CouponValue
		,plit.MaskedAccountString
        FROM StgPosLineItemTransaction plit
        WHERE TenderTypeId IN (83, 86)
        AND TransactionDate BETWEEN @FromDate AND @ToDate
        ";

        internal static string qryGetOLogOrdersByDateRange = @"
        SELECT distinct olog.OrderId
        ,olog.DeliveryId
        ,olog.StoreLocation
        ,olog.TransactionDateTime
        --,DATEADD(mi,DateDiff(mi,0,olog.TransactionDateTimeConvertedToEST),0) as TransactionDateTimeEST
        ,olog.TransactionDateTimeConvertedToEST as TransactionDateTimeEST
        ,olog.TransactionDateConvertedToEST as TransactionDateEST
        ,olog.TransactionAmt
        ,olog.FileVersionIndicator  
        ,ISNULL(tlog.StoreLocation, 0) as TLogStoreLocation
        FROM S0OMNIXX.dbo.Inst_Olog olog (NOLOCK) 
        LEFT JOIN S0OMNIXX.dbo.Inst_TLog tlog (NOLOCK)  on olog.OrderID = tlog.OrderID
        AND olog.DeliveryID = tlog.DeliveryID
        WHERE TransactionDateConvertedToEST BETWEEN @FromDate AND @ToDate
		AND NOT EXISTS ( SELECT TOP 1 InstOrderId
						 FROM S0OMNIRI.dbo.PosInstOrderMap piom
						 WHERE ISNULL(piom.InstOrderId, 0) = ISNULL(olog.OrderId, 0)
						 AND ISNULL(piom.InstDeliveryId, 0) = ISNULL(olog.DeliveryId, 0)
						 AND piom.InstOlogStoreLocation = olog.StoreLocation
						 AND piom.InstOlogTransactionDateTime = olog.TransactionDateTime
						 AND piom.InstOlogTransactionAmt = olog.TransactionAmt
                         AND piom.MapLevel  IN ( @InvoiceLevel, @FeeLevel)
					   )
        ";

        internal static string qryGetOLogOrdersByOrderIds = @"
        SELECT DISTINCT olog.OrderId
        ,olog.DeliveryId
        ,olog.StoreLocation
        ,olog.TransactionDateTime
        --,DATEADD(mi,DateDiff(mi,0,olog.TransactionDateTimeConvertedToEST),0) as TransactionDateTimeEST
        ,olog.TransactionDateTimeConvertedToEST as TransactionDateTimeEST
        ,olog.TransactionDateConvertedToEST as TransactionDateEST
        ,olog.TransactionAmt  
        ,olog.FileVersionIndicator  
        ,ISNULL(tlog.StoreLocation, 0) as TLogStoreLocation
        FROM S0OMNIXX.dbo.Inst_OLog olog(NOLOCK)
        LEFT JOIN S0OMNIXX.dbo.Inst_TLog tlog (NOLOCK)  on olog.OrderID = tlog.OrderID
        AND olog.DeliveryID = tlog.DeliveryID
        WHERE olog.OrderID IN ({0})
		AND NOT EXISTS ( SELECT TOP 1 piom.InstOrderId
						 FROM S0OMNIRI.dbo.PosInstOrderMap piom
						 WHERE ISNULL(piom.InstOrderId, 0) = ISNULL(olog.OrderId, 0)
						 AND ISNULL(piom.InstDeliveryId, 0) = ISNULL(olog.DeliveryId, 0)
						 AND piom.MapLevel IN ( @InvoiceLevel, @FeeLevel)
						)
        ";

        internal static string qryGetMapInterval = @"
        SELECT Daily, DateRange, FromDate, ToDate, Orders, OrderIds
        FROM MapInterval
        ";
        internal static string qryGetQueryTimeOut = @"SELECT Value FROM SystemValues  WHERE KeyName = 'QueryCommandTimeout'";

        internal static string qryGetStoreMarket = @"SELECT StoreNumber, Market, State, SalesDay, DeliveryModel, IsEticketEnabled FROM S0OMNIXX.dbo.StoreMarket";

        internal static string qryGetStoreTaxRates = @"SELECT STORE_ID as StoreNumber
	    ,TAX_PLAN_1 as TaxPlan1
	    ,TAX_PLAN_2 as TaxPlan2
	    ,TAX_PLAN_3 as TaxPlan3 
	    ,EffectiveDate
	    ,TerminationDate
	    FROM S0OMNIXX.dbo.POS_TAX_PLAN_RATE
        ";

        internal static string qryGetSystemMessages = @"SELECT Id, [Key], Message FROM SystemMessage";

        internal static string qryGetSystemParamteres = @"SELECT Id, [KeyName], ParameterValue FROM SystemParameter";

        internal static string qryGetSystemValues = @"SELECT KeyName, Value FROM SYSTEMVALUES";

        internal static string qryLoadPosTransactions = @"
		 SELECT [FacilityID]
        ,[TransactionDate]
        ,[TransactionTM]
        ,[TransactionNumber]
        ,[BusinessDate]
        ,[LineNumber]
        ,[ItemId]
        ,[ItemDescription]
        ,[Quantity]
        ,[SalesVolume]
        ,[VolumeIndicator]
        ,[GTIN]
        ,[Void]
        ,[Ringcode]
        ,[RingTM]
        ,[TaxPlan1]
        ,[TaxPlan2]
        ,[TaxPlan3]
        ,[TaxPlan4]
        ,[NetAmount]
        ,[SalesAmount]
        ,[NonTaxableSales]
        ,[CouponValue]
        ,[TenderAmount]
        ,[TenderAmountOther]
        ,[TotalSalesIncludingTax]
        ,[SalesType]
        ,[RefundSalesFound]
        ,[TaxPlan1Amount]
        ,[TaxPlan2Amount]
        ,[TaxPlan3Amount]
        ,[TaxPlan4Amount]
        ,[TotalTax]
        ,[TaxableAmount]
        ,[TaxableSalesTaxPlan1Amount]
        ,[TaxableSalesTaxPlan2Amount]
        ,[TaxableSalesTaxPlan3Amount]
        ,[TaxableSalesTaxPlan1TaxPlan2Amount]
        ,[TaxableSalesTaxPlan3TaxPlan2Amount]
        ,[AlcoholSales]
        ,[NonAlcoholSales]
        ,[TaxableAlcoholSales]
        ,[TaxableNonAlcoholSales]
        ,[NonTaxableAlcoholSales]
        ,[NonTaxableNonAlcoholSales]
        ,[TaxAlcoholSales]
        ,[TaxNonAlcoholSales]
        ,[BottleDeposit]
        ,[AlcoholFlag]
        ,[LiquorCode]
        ,[TerminalNumber]
        ,[TerminalTypeCode]
        ,[CardTypeCode]
        ,[GTINCheckDigit]
        ,[TaxPlan1Tax]
        ,[TaxPlan1TaxPlan2Tax]
        ,[TaxPlan3TaxPlan2Tax]
        ,[TaxPlan3Tax]
        ,[TenderTypeId]
        ,[MaskedAccountString]
        FROM S0OMNIXX.dbo.PosLineItemTransaction plit
        WHERE TransactionDate BETWEEN @FromDate AND @ToDate
        AND LineNumber = 0
		AND NOT EXISTS ( SELECT TOP 1 PosFacilityId, PosTransactionDate, PosTransactionTM, PosTransactionNumber
			  			 FROM S0OMNIRI.dbo.PosInstOrderMap piom
						 WHERE piom.PosFacilityId  = plit.FacilityId
						 AND piom.PosTransactionDate = plit.TransactionDate
						 AND piom.PosTransactionTM = plit.TransactionTM
						 AND piom.PosTransactionNumber = plit.TransactionNumber
                         AND piom.MapLevel = 'UNMAP'
					   )
        ";

        internal static string qryTruncateTable = @"TRUNCATE TABLE {0}";

        internal static string qryGetPosTransactionsToMapOlog = @"
         SELECT 
		 plit.FacilityId
        ,plit.TransactionDate
        ,plit.TransactionTM
        ,plit.TransactionNumber
        ,plit.TransactionDate + CAST(DATEADD(HOUR, (TransactionTM/100)%100, DATEADD(MINUTE, (TransactionTM%100), CAST('00:00'as TIME(2)))) as datetime) as TransactionTime
        ,plit.TenderAmount
        ,plit.TotalSalesIncludingTax + plit.CouponValue as TotalSalesIncludingTax
        ,plit.SalesAmount as SalesBeforeTax
        ,plit.TotalTax as SalesTax
        ,plit.NonAlcoholSales
        ,plit.AlcoholSales
        ,plit.BottleDeposit
		,plit.CouponValue
		,plit.MaskedAccountString
        FROM StgPosLineItemTransaction plit
        WHERE (TenderTypeId NOT IN (83, 86) OR TenderTypeId IS NULL) 
        ";

        internal static string qryGetMappedOrdersForDiscrepancy = @"
		SELECT
        distinct piom.InstOrderId as OrderId, piom.InstDeliveryId as DeliveryId, tlog.StoreLocation as StoreNumber, tlog.OrderedDateEST as OrderedDate
        FROM S0OMNIRI.dbo.PosInstOrderMap piom
		INNER JOIN S0OMNIXX.dbo.Inst_Tlog tlog ON piom.InstOrderId = tlog.OrderID
		AND piom.InstDeliveryId = tlog.DeliveryID
        WHERE MapLevel = @MapLevel
		AND InstOrderID <> 0
        AND ExclusionTypeId = 0
		ORDER BY tlog.OrderedDateEST
        ";

        internal static string qryGetTLogOrderItems = @"
		 SELECT 
         OrderID, DeliveryID, OrderedDate, DeliveryDate, OrderedDateConvertedToEST as OrderedDateTimeEST, DeliveryDateConvertedToEST as DeliveryDateTimeEST, StoreLocation, ReferenceCode, GTIN, Item as ItemName,
         Unit, Qty, InstacartOnlinePrice as InstOnlinePrice, InstacartOnlineRevenue as InstOnlineRevenue, SalesTax , BottleDeposit, GMV, IsAlcoholic, PriceSource, IsPickup, FileVersionIndicator 
        FROM Inst_TLog
        WHERE OrderId = @OrderId
        AND  DeliveryId = @DeliveryId
        ";

        internal static string qryGetPriceUomDisrecpancyByItemFromHistory = @"
        SELECT
		 IDEH.ITEM_LOAD_DATE
		,IDEH.STORE_IDENTIFIER
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED 
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,0 as SALES_DAY
        FROM ITEM_DATA_EXPORT_HISTORY IDEH
        WHERE ITEM_LOAD_DATE = @LoadDate
        AND STORE_IDENTIFIER = @StoreNumber
        AND RETAILER_REFERENCE_CODE = @ItemId
        ";

        internal static string qryGetPriceUomDisrecpancyByItemFromHistoryArchive = @"
        SELECT
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER 
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED 
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,0 as SALES_DAY
        FROM ITEM_DATA_EXPORT_HISTORY_ARCH IDEH
        WHERE ITEM_LOAD_DATE = @LoadDate
        AND STORE_IDENTIFIER = @StoreNumber
        AND RETAILER_REFERENCE_CODE = @ItemId
        ";

        internal static string qryGetPriceUomDisrecpancyByScanCodeFromHistory = @"
        SELECT
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER 
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED 
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,0 as SALES_DAY
        FROM ITEM_DATA_EXPORT_HISTORY IDEH
        WHERE ITEM_LOAD_DATE = @LoadDate
        AND STORE_IDENTIFIER = @StoreNumber
        AND SCAN_CODE = @ScanCode        
        ";

        internal static string qryGetPriceUomDisrecpancyByScanCodeFromHistoryArchive = @"
        SELECT
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER 
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED 
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,0 as SALES_DAY
        FROM ITEM_DATA_EXPORT_HISTORY_ARCH IDEH
        WHERE ITEM_LOAD_DATE = @LoadDate
        AND STORE_IDENTIFIER = @StoreNumber
        AND SCAN_CODE = @ScanCode
        ";

        internal static string qryGetPriceUomDisrecpancyFromHistoryByItemGTINScanCode = @"
        SELECT 
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER 
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED 
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,0 as SALES_DAY
        FROM ITEM_DATA_EXPORT_HISTORY IDEH
        WHERE ITEM_LOAD_DATE = @LoadDate
        AND STORE_IDENTIFIER = @StoreNumber
        AND EXISTS ( SELECT TOP 1 IG.ItemId 
			         FROM ItemGTIN IG 
			         WHERE IG.GTINCheckDigit = @ScanCode
			         AND GETDATE() BETWEEN EffectiveDate AND TerminationDate
			         AND IG.ItemId = IDEH.RETAILER_REFERENCE_CODE
			        )
        ";

        internal static string qryGetPriceUomDisrecpancyFromHistoryByItemGTINScanCodeArchive = @"
        SELECT 
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER 
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED  
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,0 as SALES_DAY
        FROM ITEM_DATA_EXPORT_HISTORY_ARCH IDEH
        WHERE ITEM_LOAD_DATE = @LoadDate
        AND STORE_IDENTIFIER = @StoreNumber
        AND EXISTS ( SELECT TOP 1 IG.ItemId 
			         FROM S0OMNIXX.dbo.ItemGTIN IG 
			         WHERE IG.GTINCheckDigit = @ScanCode
			         AND GETDATE() BETWEEN EffectiveDate AND TerminationDate
			         AND IG.ItemId = IDEH.RETAILER_REFERENCE_CODE
			        )
        ";

        internal static string qryGetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCode = @"
        SELECT  TOP 1 
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER 
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED  
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,0 as SALES_DAY
        FROM ITEM_DATA_EXPORT_HISTORY IDEH
        INNER JOIN S0OMNIXX.dbo.StoreMarket SM ON IDEH.STORE_IDENTIFIER = SM.StoreNumber
        WHERE ITEM_LOAD_DATE = @LoadDate
        AND EXISTS ( SELECT TOP 1 SM1.StoreNumber
			         FROM S0OMNIXX.dbo.StoreMarket SM1
			         WHERE StoreNumber = @StoreNumber
			         AND SM.Market = SM1.Market
			         AND SM.SalesDay = SM1.SalesDay
		           ) 
        AND EXISTS ( SELECT TOP 1 IG.ItemId 
			         FROM S0OMNIXX.dbo.ItemGTIN IG 
			         WHERE IG.GTINCheckDigit = @ScanCode
			         AND GETDATE() BETWEEN EffectiveDate AND TerminationDate
			         AND IG.ItemId = IDEH.RETAILER_REFERENCE_CODE
			        )
        ";

        internal static string qryGetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCodeArchive = @"
        SELECT TOP 1  
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER 
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED 
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,0 as SALES_DAY
        FROM ITEM_DATA_EXPORT_HISTORY_ARCH IDEH
        INNER JOIN S0OMNIXX.dbo.StoreMarket SM ON IDEH.STORE_IDENTIFIER = SM.StoreNumber
        WHERE ITEM_LOAD_DATE = @LoadDate
        AND EXISTS ( SELECT TOP 1 SM1.StoreNumber
			         FROM S0OMNIXX.dbo.StoreMarket SM1
			         WHERE StoreNumber = @StoreNumber
			         AND SM.Market = SM1.Market
			         AND SM.SalesDay = SM1.SalesDay
		           ) 
        AND EXISTS ( SELECT TOP 1 IG.ItemId 
			         FROM S0OMNIXX.dbo.ItemGTIN IG 
			         WHERE IG.GTINCheckDigit = @ScanCode
			         AND GETDATE() BETWEEN EffectiveDate AND TerminationDate
			         AND IG.ItemId = IDEH.RETAILER_REFERENCE_CODE
			        )        
        ";

        internal static string qryValidateLoadDateExists = @"
        SELECT TOP 1 1
        FROM S0OMNIXX.dbo.ITEM_DATA_EXPORT_HISTORY 
        WHERE ITEM_LOAD_DATE = @LoadDate        
        ";

        internal static string qryPushDiscrepancyDataStagingTomain = @"
        DELETE ioipd 
        FROM InstFeedDiscrepancy ioipd
        WHERE EXISTS (
				        SELECT TOP 1 InstOrderid
				        FROM StgInstFeedDiscrepancy ioipds
				        WHERE ioipd.InstOrderid = ioipds.InstOrderid
			          )

        INSERT INTO InstFeedDiscrepancy(
        InstOrderId, InstDeliveryId, InstOrderedDateEst, InstDeliveredDateEst, InstStoreLocation, InstRefereneCode, InstGTIN, InstUnit, InstQty, InstOnlinePrice, InstOnlineRevenue, InstAlcoholFlag, InstPriceSource,
		InstBottleDeposit, FeedLoadDate, FeedStoreNumber, FeedRRC, FeedScanCode, FeedCostUnit, FeedUnitPrice, FeedMarkUpPriceRounded, FeedSalePrice, FeedMarkUpSalePriceRounded, FeedBogo, FeedPromoGroupId, FeedPromoStartDate,
		FeedPromoEndDate, FeedAlcoholFlag, FeedBottleDeposit, MapCriteriaId, [Type], LastUpdatedBy, LastUpdatedDate)
        SELECT 
        InstOrderId, InstDeliveryId, InstOrderedDateEst, InstDeliveredDateEst, InstStoreLocation, InstRefereneCode, InstGTIN, InstUnit, InstQty, InstOnlinePrice, InstOnlineRevenue, InstAlcoholFlag, InstPriceSource,
		InstBottleDeposit, FeedLoadDate, FeedStoreNumber, FeedRRC, FeedScanCode, FeedCostUnit, FeedUnitPrice, FeedMarkUpPriceRounded, FeedSalePrice, FeedMarkUpSalePriceRounded, FeedBogo, FeedPromoGroupId, FeedPromoStartDate,
		FeedPromoEndDate, FeedAlcoholFlag, FeedBottleDeposit, MapCriteriaId, [Type], LastUpdatedBy, LastUpdatedDate
        FROM StgInstFeedDiscrepancy
        ";

        internal static string qryGetPosInstOrdersMapped = @"

        UPDATE PosInstOrderMap 
        SET MapLevel = @TempLevel        
        WHERE ExclusionTypeId = 0
        AND MapLevel = @Type
        AND MapLevel NOT IN ( @InvLevel, @FeeLevel)

        SELECT
         InstOrderID, InstDeliveryID, InstOrderSplit, InstOlogStoreLocation, InstOlogTransactionDateTime, InstOlogTransactionDateEST, InstOlogTransactionDateTimeEST, InstOlogTransactionAmt, PosFacilityId, PosTransactionDate, 
		 PosTransactionTM, PosTransactionNumber, PosTransactionDateTime, PosTenderAmount, PosTotalSalesIncludingTax, PosSalesBeforeTax, PosSalesTax, PosNonAlcoholSales, PosAlcoholSales, PosBottleDeposit, PosCouponValue, IsByPassCheckOut, 
		 MapLevel, ExclusionTypeId, MapCriteriaId, LastUpdatedBy, LastUpdatedDate
        FROM PosInstOrderMap 
        WHERE MapLevel = @TempLevel     

        ";

        internal static string qryUpdateMapLevelOnMappedOrders = @"
        UPDATE PosInstOrderMap
        SET MapLevel = @ToMapLevel
        WHERE MapLevel = @FromMapLevel
		AND InstOrderID <> 0
        AND ExclusionTypeId = 0

        ";

        internal static string qryMoveStgPosInstOrderMapToMain = @"
        DELETE piom
        FROM PosInstOrderMap piom
        WHERE EXISTS ( SELECT TOP 1 InstOrderId FROM StgPosInstOrderMap spiom WHERE piom.InstOrderID = spiom.InstOrderID )
        AND piom.MapLevel NOT IN (@InvLevel, @FeeLevel)

        -- Delete the order from child tables, order might be reprocessing.
        DELETE piom
        FROM PosInstOrderItemMap piom
        WHERE EXISTS (  SELECT TOP 1 InstOrderId FROM StgPosInstOrderMap spiom 
                        WHERE piom.InstOrderID = spiom.InstOrderID
                        AND NOT EXISTS ( 
                                            SELECT TOP 1 InstOrderId FROM PosInstOrderMap piom 
                                            WHERE spiom.InstOrderId = piom.InstOrderId
                                            AND spiom.InstDeliveryId = piom.InstDeliveryId
                                            AND piom.MapLevel IN (@InvLevel, @FeeLevel)
                                        )
                      )

        DELETE piom
        FROM PosInstOrderSummary piom
        WHERE EXISTS (  SELECT TOP 1 InstOrderId FROM StgPosInstOrderMap spiom 
                        WHERE piom.InstOrderID = spiom.InstOrderID
                        AND NOT EXISTS ( 
                                            SELECT TOP 1 InstOrderId FROM PosInstOrderMap piom 
                                            WHERE spiom.InstOrderId = piom.InstOrderId
                                            AND spiom.InstDeliveryId = piom.InstDeliveryId
                                            AND piom.MapLevel IN (@InvLevel, @FeeLevel)
                                        )
                      )

        DELETE piom
        FROM PosInstOrderInvoice piom
        WHERE EXISTS (  SELECT TOP 1 InstOrderId FROM StgPosInstOrderMap spiom 
                        WHERE piom.InstOrderID = spiom.InstOrderID
                        AND NOT EXISTS ( 
                                            SELECT TOP 1 InstOrderId FROM PosInstOrderMap piom 
                                            WHERE spiom.InstOrderId = piom.InstOrderId
                                            AND spiom.InstDeliveryId = piom.InstDeliveryId
                                            AND piom.MapLevel IN (@InvLevel, @FeeLevel)
                                        )
                      )

		UPDATE piom
		SET piom.InstOrderSplit = 1
		FROM StgPosInstOrderMap piom
		WHERE piom.InstOrderId <> 0
		AND EXISTS (	
						SELECT OrderId
						FROM S0OMNIXX.dbo.Inst_OLog olog
						WHERE (OrderID IS NOT NULL or OrderID <> 0)
						AND piom.InstOrderID = olog.OrderID
						GROUP BY OrderID 
						HAVING Count(*) > 1
					 )

		 INSERT INTO PosInstOrderMap (
		 InstOrderId, InstDeliveryId, InstOrderSplit, InstOlogStoreLocation, InstOlogTransactionDateTime, InstOlogTransactionDateEST, InstOlogTransactionDateTimeEST, InstOlogTransactionAmt, 
		 PosFacilityId, PosTransactionDate, PosTransactionTM, PosTransactionNumber, PosTransactionDateTime, PosTenderAmount, PosTotalSalesIncludingTax, PosSalesBeforeTax, PosSalesTax, 
		 PosNonAlcoholSales, PosAlcoholSales, PosBottleDeposit, PosCouponValue, IsByPassCheckOut, MapLevel, ExclusionTypeId,  MapCriteriaId, LastUpdatedBy, LastUpdatedDate)
        SELECT 
		 InstOrderId, InstDeliveryId, InstOrderSplit, InstOlogStoreLocation, InstOlogTransactionDateTime, InstOlogTransactionDateEST, InstOlogTransactionDateTimeEST, InstOlogTransactionAmt, 
		 PosFacilityId, PosTransactionDate, PosTransactionTM, PosTransactionNumber, PosTransactionDateTime, PosTenderAmount, PosTotalSalesIncludingTax, PosSalesBeforeTax, PosSalesTax, 
		 PosNonAlcoholSales, PosAlcoholSales, PosBottleDeposit, PosCouponValue, IsByPassCheckOut, MapLevel, ExclusionTypeId, MapCriteriaId, LastUpdatedBy, LastUpdatedDate
		 FROM StgPosInstOrderMap  spiom
         WHERE NOT EXISTS ( SELECT TOP 1 InstOrderId FROM PosInstOrderMap piom 
                            WHERE spiom.InstOrderId = piom.InstOrderId
                            AND spiom.InstDeliveryId = piom.InstDeliveryId
                            AND  piom.MapLevel IN (@InvLevel, @FeeLevel)
                           )
        ";

        internal static string qryGetItemAttributes = @"
        SELECT Itemid, DepartmentNo, SubDepartmentNo, CategoryNo, FamilyGroup
        FROM ItemAttribute
        WHERE GETDATE() BETWEEN ApprovalDate AND TerminationDate 
        ";

        internal static string qryGetPosLineTransactions = @"
        SELECT 
        pos.FacilityID
        ,pos.TransactionDate
        ,pos.TransactionTM
        ,pos.TransactionNumber
        ,pos.LineNumber
        ,pos.ItemId
        ,pos.GTIN
        ,pos.ItemDescription as ItemName
        ,pos.SalesVolume
        ,CASE WHEN pos.VolumeIndicator = 'U' THEN 'each' ELSE 'lb' END as VolumeIndicator
        ,pos.GTINCheckDigit
        ,pos.NetAmount	
        ,pos.SalesAmount	
        ,(ISNULL(pos.TaxPlan1Amount,0) + ISNULL(pos.TaxPlan2Amount,0) + ISNULL(pos.TaxPlan3Amount,0))  as TotalTax	
        ,pos.BottleDeposit	
        ,pos.SalesAmount + (ISNULL(pos.TaxPlan1Amount,0) + ISNULL(pos.TaxPlan2Amount,0) + ISNULL(pos.TaxPlan3Amount,0)) as TotalSalesIncludingTax	
        ,CASE WHEN (pos.TaxPlan1 = 1 OR pos.TaxPlan2 = 1 OR pos.TaxPlan3 = 1)  THEN pos.SalesAmount ELSE 0 END as TaxableAmount	
        ,CASE WHEN (pos.TaxPlan1 = 0 AND pos.TaxPlan2 = 0 AND pos.TaxPlan3 = 0)  THEN pos.SalesAmount ELSE 0 END as NonTaxableSales	
        ,pos.TaxableAlcoholSales	
        ,pos.TaxableNonAlcoholSales	
        ,pos.NonTaxableAlcoholSales	
        ,pos.NonTaxableNonAlcoholSales
        ,pos.TaxPlan1Amount	
        ,pos.TaxPlan2Amount	
        ,pos.TaxPlan3Amount	
        ,pos.TaxPlan4Amount	
        ,CASE WHEN TaxPlan1 = 1  AND TaxPlan2 = 0 AND TaxPlan3 = 0 THEN TaxPlan1Amount ELSE 0 END as TaxPlan1Tax
        ,CASE WHEN TaxPlan1 = 1 AND TaxPlan2 = 1 AND TaxPlan3 = 0 THEN TaxPlan1Amount + TaxPlan2Amount ELSE 0 END as TaxPlan1TaxPlan2Tax 
        ,CASE WHEN TaxPlan1 = 0 AND TaxPlan2 = 1 AND TaxPlan3 = 1 THEN TaxPlan3Amount + TaxPlan2Amount ELSE 0 END  as TaxPlan3TaxPlan2Tax 
        ,CASE WHEN TaxPlan1 = 0 AND TaxPlan2 = 0 AND TaxPlan3 = 1 THEN TaxPlan3Amount ELSE 0 END as TaxPlan3Tax
        ,TaxPlan1
        ,TaxPlan2
        ,TaxPlan3
        ,SalesType
        ,Alcoholflag
        FROM PosLineItemTransaction pos
        WHERE pos.FacilityID = @FacilityId
        and pos.TransactionDate = @TransactionDate
        and pos.TransactionTM = @TransactionTM
        and pos.TransactionNumber = @TransactionNumber
        AND pos.LineNumber > 0
        and pos.ItemId <> 0
        --and pos.SalesType <> 7
        ";


        internal static string qryGetCreditReturnsData = @"
		 --declare @FromDate as Date, @ToDate as Date
   --      SELECT @FromDate = '2018-06-23',  @ToDate = '2018-08-23'

		IF OBJECT_ID('tempdb..#tmpCreditReturns') IS NOT NULL DROP TABLE #tmpCreditReturns
		CREATE TABLE #tmpCreditReturns (OrderId bigint, DeliveryId bigint, ExclusionTypeId int)

		-- Cancelled Orders
		INSERT INTO #tmpCreditReturns
        SELECT cr.OrderId, cr.DeliveryId, 1 as ExclusionTypeId -- 1 - Cancelled
        FROM InstCreditReturns cr
        INNER JOIN Inst_OLog olog ON cr.OrderId = cr.OrderId
        AND cr.DeliveryID = olog.DeliveryID
        WHERE Cancellationflag = 'Y'
        AND olog.OrderID IS NOT NULL
		AND TransactionDateConvertedToEST BETWEEN @FromDate AND @ToDate
        GROUP BY cr.OrderId, cr.DeliveryId
        HAVING count( Cancellationflag) = 1

         -- Orders with fully redelivered
		--INSERT INTO #tmpCreditReturns
  --      SELECT q1.OrderId, q1.DeliveryId, 2 as ExclusionTypeId -- 2 - FullyRedelivered
  --      FROM 
	 --       (
		--        SELECT tlog.OrderId, tlog.DeliveryId, COUNT(*) as TotalItems
		--        FROM Inst_Tlog tlog
		--        INNER JOIN Inst_OLog olog ON tlog.OrderId = olog.OrderId
		--        AND tlog.DeliveryID = olog.DeliveryID
		--        WHERE  olog.OrderID IS NOT NULL
		--		AND TransactionDateConvertedToEST BETWEEN @FromDate AND @ToDate
		--        GROUP BY tlog.OrderId, tlog.DeliveryId
	 --       ) as q1
  --      INNER JOIN 
	 --       (
		--        SELECT tlog.OrderId, tlog.DeliveryId, COUNT(IsRedelivered) as TotalRedeliveredItems
		--        FROM Inst_TLog tlog
		--        INNER JOIN Inst_OLog olog ON tlog.OrderId = olog.OrderId
		--        AND tlog.DeliveryID = olog.DeliveryID
		--        WHERE  olog.OrderID IS NOT NULL
		--		AND TransactionDateConvertedToEST BETWEEN @FromDate AND @ToDate
		--        AND tlog.IsRedelivered = 'true'
		--        GROUP BY tlog.OrderID, tlog.DeliveryId
	 --       )q2 ON q1.OrderID = q2.OrderID
  --      AND q1.DeliveryID = q2.DeliveryID
  --      AND q1.TotalItems = q2.TotalRedeliveredItems
		--AND NOT EXISTS (SELECT TOP 1 OrderId FROM #tmpCreditReturns WHERE OrderId = q1.OrderId)

        -- Orders thats does not have TLog
		INSERT INTO #tmpCreditReturns
        SELECT OrderId, DeliveryId, 3 as ExclusionTypeId -- 3 - OlogDoesNotTlog
        FROM Inst_OLog olog
        WHERE olog.OrderID IS NOT NULL
		AND TransactionDateConvertedToEST BETWEEN @FromDate AND @ToDate
		AND NOT EXISTS ( SELECT TOP 1 OrderID
				           FROM Inst_TLog tlog 
				           WHERE tlog.OrderID = olog.OrderID)
		AND NOT EXISTS (SELECT TOP 1 OrderId FROM #tmpCreditReturns WHERE OrderId = olog.OrderId)

        -- Orders with 0 GMV for all items in Tlog
		INSERT INTO #tmpCreditReturns
        SELECT tlog.OrderId, tlog.DeliveryId, 4 as ExclusionTypeId -- 4 - OrdersWithZeroGMV
        FROM Inst_TLog tlog
        INNER JOIN Inst_OLog olog ON tlog.OrderId = olog.OrderId
        AND tlog.DeliveryID = olog.DeliveryID
        WHERE  olog.OrderID IS NOT NULL
		AND TransactionDateConvertedToEST BETWEEN @FromDate AND @ToDate
		AND NOT EXISTS (SELECT TOP 1 OrderId FROM #tmpCreditReturns WHERE OrderId = tlog.OrderId)
        GROUP BY tlog.OrderId, tlog.DeliveryId
        HAVING SUM(GMV) = 0

		SELECT OrderId, DeliveryId, ExclusionTypeId FROM #tmpCreditReturns
         ";

        internal static string qryMoveStgMapLogToMain = @"

 
        DELETE ml
        FROM MapLog ml
        WHERE EXISTS (SELECT TOP 1 * 
				        FROM StgMapLog  sml
				        WHERE ISNULL(ml.InstOrderId, 0) = ISNULL(sml.InstOrderId, 0)
				        AND ISNULL(ml.InstDeliveryId, 0) = ISNULL(sml.InstDeliveryId, 0)
				        AND ml.InstStoreLocation = sml.InstStoreLocation
				        AND ml.InstTransactionDateTime = sml.InstTransactionDateTime
				        AND ml.InstTransactionAmt = sml.InstTransactionAmt
				        AND ml.[Type] = sml.[Type]
				        )
        AND ml.[Type] = 'OLOG'
 
        DELETE ml
        FROM MapLog ml
        WHERE EXISTS (SELECT TOP 1 * 
				        FROM StgMapLog  sml
				        WHERE ISNULL(ml.InstOrderId, 0) = ISNULL(sml.InstOrderId, 0)
				        AND ISNULL(ml.InstDeliveryId, 0) = ISNULL(sml.InstDeliveryId, 0)
				        AND ml.InstStoreLocation = sml.InstStoreLocation
				        AND ml.InstOrderedDate = sml.InstOrderedDate
				        AND ml.InstDeliveryDate = sml.InstDeliveryDate
				        AND ISNULL(ml.InstItemId,0) = ISNULL(sml.InstItemId, 0)
				        AND ISNULL(ml.InstGTIN, 0)  = ISNULL(sml.InstGTIN, 0)
				        AND ISNULL(ml.InstGMV, 0)  = ISNULL(sml.InstGMV, 0)
				        AND ml.[Type] = sml.[Type]
				        )
        AND ml.[Type] = 'TLOG'
 
        DELETE ml
        FROM MapLog ml
        WHERE EXISTS (SELECT TOP 1 * 
				        FROM StgMapLog  sml
				        WHERE ml.PosFacilityId = sml.PosFacilityId
				        AND ml.PosTransactionDate = sml.PosTransactionDate
				        AND ml.PosTransactionTM = sml.PosTransactionTM
				        AND ml.PosTransactionNumber = sml.PosTransactionNumber
				        AND ml.PosTenderAmount = sml.PosTenderAmount
				        AND ml.PosItemId = sml.PosItemId
				        AND ml.PosSalesAmount = sml.PosSalesAmount
				        AND ml.[Type] = sml.[Type]
				        )
        AND ml.[Type] = 'POS'

        DELETE ml
        FROM MapLog ml
        WHERE EXISTS (SELECT TOP 1 * 
				        FROM StgMapLog  sml
				        WHERE ml.PosFacilityId = sml.PosFacilityId
				        AND ml.PosTransactionDate = sml.PosTransactionDate
				        AND ml.PosTransactionTM = sml.PosTransactionTM
				        AND ml.PosTransactionNumber = sml.PosTransactionNumber
				        AND ISNULL(ml.InstOrderId, 0) = ISNULL(sml.InstOrderId, 0)
				        AND ISNULL(ml.InstDeliveryId, 0) = ISNULL(sml.InstDeliveryId, 0)
						AND ( 
								ISNULL(ml.InstItemId, 0) = ISNULL(sml.InstItemId, 0) OR 
								ISNULL(ml.InstGTIN, 0) = ISNULL(sml.InstGTIN, 0) OR
								ISNULL(ml.PosItemId, 0) = ISNULL(sml.PosItemId, 0) 
							)
				        AND ml.[Type] = sml.[Type]
				        )
        AND ml.[Type] IN ( 'PosInstItemMap')

        DELETE ml
        FROM MapLog ml
        WHERE EXISTS (SELECT TOP 1 * 
				        FROM StgMapLog  sml
				        WHERE ml.PosFacilityId = sml.PosFacilityId
				        AND ml.PosTransactionDate = sml.PosTransactionDate
				        AND ml.PosTransactionTM = sml.PosTransactionTM
				        AND ml.PosTransactionNumber = sml.PosTransactionNumber
				        AND ISNULL(ml.InstOrderId, 0) = ISNULL(sml.InstOrderId, 0)
				        AND ISNULL(ml.InstDeliveryId, 0) = ISNULL(sml.InstDeliveryId, 0)
				        AND ml.[Type] = sml.[Type]
				        )
        AND ml.[Type] IN ( 'PosInstSummary')

        INSERT INTO MapLog( 
        InstOrderId, InstDeliveryId, InstStoreLocation, InstTransactionDateTime, InstTransactionAmt, InstOrderedDate, InstDeliveryDate, InstItemId, InstGTIN, InstQty, InstUnit, InstOnlinePrice,
        InstBottleDeposit, InstGMV, PosFacilityId, PosTransactionDate, PosTransactionTM, PosTransactionNumber, PosItemId, PosSalesVolume, PosSalesVolumeIndicator, PosUnitPrice, PosSalesType,
		PosSalesAmount, PosBottleDeposit, PosTenderAmount, SpreadPercentage, Reason, Severity, [Type], [Level], LastUpdatedBy, LastUpdatedDate )
        SELECT 		
        InstOrderId, InstDeliveryId, InstStoreLocation, InstTransactionDateTime, InstTransactionAmt, InstOrderedDate, InstDeliveryDate, InstItemId, InstGTIN, InstQty, InstUnit, InstOnlinePrice,
        InstBottleDeposit, InstGMV, PosFacilityId, PosTransactionDate, PosTransactionTM, PosTransactionNumber, PosItemId, PosSalesVolume, PosSalesVolumeIndicator, PosUnitPrice, PosSalesType,
		PosSalesAmount, PosBottleDeposit, PosTenderAmount, SpreadPercentage, Reason, Severity, [Type], [Level], LastUpdatedBy, LastUpdatedDate
        FROM StgMapLog
        ";

        internal static string qryLogUnmappedPosAtOrderLevel = @"
		DELETE mlog 
		FROM MapLog mlog 
		WHERE EXISTS ( SELECT TOP 1 piom.PosFacilityId, piom.PosTransactionDate, piom.PosTransactionTM, piom.PosTransactionNumber
						   FROM PosInstOrderMap piom
						   WHERE mlog.PosFacilityID = piom.PosFacilityId
						   AND mlog.PosTransactionDate = piom.PosTransactionDate
						   AND mlog.PosTransactionTM = piom.PosTransactionTM
						   AND mlog.PosTransactionNumber = piom.PosTransactionNumber
						 )  

		INSERT INTO MapLog( PosFacilityId, PosTransactionDate, PosTransactionTM, PosTransactionNumber, PosTenderAmount, Reason, Severity, [Type], [Level], LastUpdatedBy, LastUpdatedDate )
		SELECT split.FacilityId, split.TransactionDate, split.TransactionTM, split.TransactionNumber, split.TenderAmount, @Reason, @Severity, @Type, @Level, @LastUpdatedBy, @LastUpdatedDate 
		FROM StgPosLineItemTransaction split
		WHERE NOT EXISTS ( SELECT TOP 1 piom.PosFacilityId, piom.PosTransactionDate, piom.PosTransactionTM, piom.PosTransactionNumber
						   FROM PosInstOrderMap piom
						   WHERE split.FacilityID = piom.PosFacilityId
						   AND split.TransactionDate = piom.PosTransactionDate
						   AND split.TransactionTM = piom.PosTransactionTM
						   AND split.TransactionNumber = piom.PosTransactionNumber
						 )   
		AND split.TransactionDate BETWEEN @FromDate AND @ToDate
        ";

        internal static string qryGetCreditRetursForOrder = @"
		SELECT OrderId, DeliveryId, ItemId, ItemUpc, ItemRrc as RRC, StoreNumber, RefundQty, RefundAmount, RefundTaxAmount, PrePostDelivery, Redeliveryflag, Cancellationflag
		FROM InstCreditReturns 
		WHERE OrderId = @OrderId
        AND DeliveryId = @DeliveryId
        ";

        internal static string qryGetDiscrepanciesForOrder = @"
        SELECT 
        InstOrderid, InstDeliveryid, InstOrderedDateEst, InstDeliveredDateEst, InstStoreLocation, InstRefereneCode, InstGTIN, InstUnit, InstQty, InstOnlinePrice, InstOnlineRevenue, InstAlcoholFlag,
		InstBottleDeposit, InstPriceSource, FeedLoadDate, FeedStoreNumber, FeedRRC, FeedScanCode, FeedCostUnit, FeedMarkUpPriceRounded, FeedUnitPrice, FeedMarkUpSalePriceRounded, FeedSalePrice,
		FeedBogo, FeedPromoGroupId, FeedPromoStartDate, FeedPromoEndDate, FeedAlcoholFlag, FeedBottleDeposit, [Type], MapCriteriaId, LastUpdatedBy, LastUpdatedDate
        FROM InstFeedDiscrepancy
        WHERE InstOrderid = @OrderId
        AND InstDeliveryId = @DeliveryId
        ";

        internal static string qryMoveMappedOrderItemsStagingToMain = @"
        DELETE pioim
        FROM PosInstOrderItemMap pioim
        WHERE EXISTS ( SELECT TOP 1 InstOrderId FROM StgPosInstOrderItemMap pioims WHERE pioim.InstOrderID = pioims.InstOrderID)

         INSERT INTO PosInstOrderItemMap (
			InstOrderID, InstDeliveryID, InstStoreLocation, InstOrderedDateEst, InstDeliveryDateEst, InstReferenceCode, InstGTIN, InstItemName, InstIsAlcohol, InstQty, InstUnit, InstOnlinePrice, 
			InstOnlineRevenue, InstSalesTax, InstBottleDeposit, InstGMV, InstAdjIsAlcohol, InstPriceSource, InstAdjQty, InstAdjUnit, InstAdjOnlinePrice, InstAdjOnlineRevenue, InstAdjSalesTax,
			InstAdjBottleDeposit, InstAdjGMV, InstTaxPlan1Tax, InstTaxPlan1TaxPlan2Tax, InstTaxPlan3TaxPlan2Tax, InstTaxPlan3Tax, PosFacilityId, PosTransactionDate, PosTransactionTM, 
			PosTransactionNumber, PosItemId, PosGTIN, PosItemName, PosSalesType, PosIsAlcohol, PosSalesVolume, PosSalesVolumeIndicator, PosSalesAmount, PosTotalTax, PosTotalSalesIncludingTax, 
			PosAdjSalesVolume, PosAdjSalesVolumeIndicator, PosAdjSalesAmount, PosAdjTotalTax, PosAdjTotalSalesIncludingTax, PosTaxPlan1Tax, PosTaxPlan1TaxPlan2Tax, PosTaxPlan3TaxPlan2Tax, 
			PosTaxPlan3Tax, SpreadAmount, SpreadPercentage, ExclusionTypeId, MapCriteriaId, LastUpdatedBy, LastUpdatedDate
        )
        SELECT
			InstOrderID, InstDeliveryID, InstStoreLocation, InstOrderedDateEst, InstDeliveryDateEst, InstReferenceCode, InstGTIN, InstItemName, InstIsAlcohol, InstQty, InstUnit, InstOnlinePrice, 
			InstOnlineRevenue, InstSalesTax, InstBottleDeposit, InstGMV, InstAdjIsAlcohol, InstPriceSource, InstAdjQty, InstAdjUnit, InstAdjOnlinePrice, InstAdjOnlineRevenue, InstAdjSalesTax,
			InstAdjBottleDeposit, InstAdjGMV, InstTaxPlan1Tax, InstTaxPlan1TaxPlan2Tax, InstTaxPlan3TaxPlan2Tax, InstTaxPlan3Tax, PosFacilityId, PosTransactionDate, PosTransactionTM, 
			PosTransactionNumber, PosItemId, PosGTIN, PosItemName, PosSalesType, PosIsAlcohol, PosSalesVolume, PosSalesVolumeIndicator, PosSalesAmount, PosTotalTax, PosTotalSalesIncludingTax, 
			PosAdjSalesVolume, PosAdjSalesVolumeIndicator, PosAdjSalesAmount, PosAdjTotalTax, PosAdjTotalSalesIncludingTax, PosTaxPlan1Tax, PosTaxPlan1TaxPlan2Tax, PosTaxPlan3TaxPlan2Tax, 
			PosTaxPlan3Tax, SpreadAmount, SpreadPercentage, ExclusionTypeId, MapCriteriaId, LastUpdatedBy, LastUpdatedDate
        FROM StgPosInstOrderItemMap
 
 		UPDATE piom
		SET MapLevel = @MapLevel
		FROM PosInstOrderMap piom
		INNER JOIN StgPosInstOrderItemMap pioims ON pioims.InstOrderID = piom.InstOrderID 
		AND pioims.InstDeliveryId = piom.InstDeliveryId
        WHERE MapLevel = @TMPLEVEL

        ";

        internal static string qryDeleteOrderSummaryByOrderId = @"
        DELETE pios
        FROM PosInstOrderSummary pios
        WHERE EXISTS ( SELECT TOP 1 InstOrderId 
                       FROM StgPosInstOrderItemMap spioim
                       WHERE spioim.InstOrderId = pios.InstOrderId
                        AND spioim.InstDeliveryId = pios.InstDeliveryId             
                      )
        ";

        internal static string qryGetOrderSummaryDetails = @"
  		SELECT 
			InstOrderId, InstDeliveryId, IsMappedItemsGroup, InstOnlineRevenue, InstPreTaxNonAlcoholSales, InstPreTaxAlcoholSales, InstSalesTax, InstBottleDeposit, InstGMV, InstAdjOnlineRevenue, 
			InstAdjSalesTax, InstAdjPreTaxNonAlcoholSales, InstAdjPreTaxAlcoholSales, InstAdjBottleDeposit, InstAdjGMV, InstTaxPlan1Tax, InstTaxPlan1TaxPlan2Tax, InstTaxPlan3TaxPlan2Tax, InstTaxPlan3Tax, 
			PosFacilityId, PosTransactionDate, PosTransactionTM, PosTransactionNumber, PosSalesAmount, PosPreTaxNonAlcoholSales, PosPreTaxAlcoholSales,PosBottleDeposit, PosTotalTax, PosTotalSalesIncludingTax, 
			PosAdjSalesAmount, PosAdjPreTaxNonAlcoholSales, PosAdjPreTaxAlcoholSales, PosAdjTotalTax, PosAdjTotalSalesIncludingTax, PosTaxPlan1Tax, PosTaxPlan1TaxPlan2Tax, PosTaxPlan3TaxPlan2Tax, PosTaxPlan3Tax, 
			TotalTaxGap, TaxPlan1TaxGap, TaxPlan1TaxPlan2TaxGap, TaxPlan3TaxPlan2TaxGap, TaxPlan3TaxGap, NonTaxableSalesGap, TaxPlan1TaxableSalesGap, TaxPlan1TaxPlan2TaxableSalesGap, TaxPlan3TaxPlan2TaxableSalesGap, 
			TaxPlan3TaxableSalesGap, SpreadAmount, SpreadPercentage, LastUpdatedBy, LastUpdatedDate
		FROM PosInstOrderSummary
		WHERE InstOrderId = @OrderId
		AND InstDeliveryId = @DeliveryId
        ";


        internal static string qryMoveInvoiceOrdersStgToMain = @"
        DELETE pioi
        FROM PosInstOrderInvoice pioi
        WHERE EXISTS ( SELECT TOP 1 InstOrderId
                       FROM StgPosInstOrderInvoice spioi
                        WHERE spioi.InstOrderId = pioi.InstOrderId
                        AND spioi.InstDeliveryId = pioi.InstDeliveryId
                      )
        
		INSERT INTO ETicketSummary (
		Id, StoreNumber, TransactionDate, InstTaxPlan1Tax, InstTaxPlan1TaxPlan2Tax, InstTaxPlan3TaxPlan2Tax, InstTaxPlan3Tax, InstSalesBeforeTax, InstGMV, PosTaxPlan1Tax, 
		PosTaxPlan1TaxPlan2Tax, PosTaxPlan3TaxPlan2Tax, PosTaxPlan3Tax, PosSalesBeforeTax, PosTotalSalesIncludingTax, SalesBeforeTaxGap, TaxPlan1TaxGap, TaxPlan1TaxPlan2TaxGap,
		TaxPlan3TaxPlan2TaxGap, TaxPlan3TaxGap, NonTaxableSalesGap, TaxPlan1TaxableSalesGap, TaxPlan1TaxPlan2TaxableSalesGap, TaxPlan3TaxPlan2TaxableSalesGap, TaxPlan3TaxableSalesGap,
		LastUpdatedDate, LastUpdatedBy )
		SELECT
		Id, StoreNumber, TransactionDate, InstTaxPlan1Tax, InstTaxPlan1TaxPlan2Tax, InstTaxPlan3TaxPlan2Tax, InstTaxPlan3Tax, InstSalesBeforeTax, InstGMV, PosTaxPlan1Tax, 
		PosTaxPlan1TaxPlan2Tax, PosTaxPlan3TaxPlan2Tax, PosTaxPlan3Tax, PosSalesBeforeTax, PosTotalSalesIncludingTax, SalesBeforeTaxGap, TaxPlan1TaxGap, TaxPlan1TaxPlan2TaxGap,
		TaxPlan3TaxPlan2TaxGap, TaxPlan3TaxGap, NonTaxableSalesGap, TaxPlan1TaxableSalesGap, TaxPlan1TaxPlan2TaxableSalesGap, TaxPlan3TaxPlan2TaxableSalesGap, TaxPlan3TaxableSalesGap,
		LastUpdatedDate, LastUpdatedBy
		FROM StgETicketSummary

        INSERT INTO PosInstOrderInvoice(
				InstOrderId, InstDeliveryId, PosStoreNumber, PosTransactionDate, PosNonAlcoholSales, PosAlcoholSales, PosSalesBeforeTax, PosSalesTax, PosBottleDeposit, PosCouponValue, PosSalesIncludingTax,
				PosTenderAmount, QualifiedPosNonAlcoholSales, QualifiedPosAlcoholSales, QualifiedPosSalesBeforeTax, QualifiedPosSalesTax, QualifiedPosBottleDeposit, QualifiedPosCouponValue, 
				QualifiedPosSalesIncludingTax, PosAdjPreTaxNonAlcoholSales, PosAdjPreTaxAlcoholSales, PosAdjSalesTax, PosAdjSalesIncludingTax, InstOnlineRevenue, InstPreTaxNonAlcoholSales, 
				InstPreTaxAlcoholSales, InstGMV, InstSalesTax, InstBottleDeposit, InstAdjOnlineRevenue, InstAdjPreTaxNonAlcoholSales, InstAdjPreTaxAlcoholSales, InstAdjGMV, InstAdjSalesTax, 
				InstAdjBottleDeposit, FeePercentage, CalculatedSpreadAmount, CalculatedSpreadPercentage, FlatAlcoholFee, CalculateNonAlcoholFee, TotalFee, TaxPlan1TaxGap, 
				TaxPlan1TaxPlan2TaxGap, TaxPlan3TaxPlan2TaxGap, TaxPlan3TaxGap, TaxPlan1TaxableSalesGap, TaxPlan1TaxPlan2TaxableSalesGap, TaxPlan3TaxPlan2TaxableSalesGap, TaxPlan3TaxableSalesGap, 
				ETicketSummaryId, AnyItemExclusion, AnyPosAdj, AnyInstAdj, IsByPassCheckOut, StoreFront, DeliveryModel, [State], LastUpdatedBy, LastUpdatedDate
	        )
        SELECT 
				InstOrderId, InstDeliveryId, PosStoreNumber, PosTransactionDate, PosNonAlcoholSales, PosAlcoholSales, PosSalesBeforeTax, PosSalesTax, PosBottleDeposit, PosCouponValue, PosSalesIncludingTax,
				PosTenderAmount, QualifiedPosNonAlcoholSales, QualifiedPosAlcoholSales, QualifiedPosSalesBeforeTax, QualifiedPosSalesTax, QualifiedPosBottleDeposit, QualifiedPosCouponValue, 
				QualifiedPosSalesIncludingTax, PosAdjPreTaxNonAlcoholSales, PosAdjPreTaxAlcoholSales, PosAdjSalesTax, PosAdjSalesIncludingTax, InstOnlineRevenue, InstPreTaxNonAlcoholSales, 
				InstPreTaxAlcoholSales, InstGMV, InstSalesTax, InstBottleDeposit, InstAdjOnlineRevenue, InstAdjPreTaxNonAlcoholSales, InstAdjPreTaxAlcoholSales, InstAdjGMV, InstAdjSalesTax, 
				InstAdjBottleDeposit, FeePercentage, CalculatedSpreadAmount, CalculatedSpreadPercentage, FlatAlcoholFee, CalculateNonAlcoholFee, TotalFee, TaxPlan1TaxGap, 
				TaxPlan1TaxPlan2TaxGap, TaxPlan3TaxPlan2TaxGap, TaxPlan3TaxGap, TaxPlan1TaxableSalesGap, TaxPlan1TaxPlan2TaxableSalesGap, TaxPlan3TaxPlan2TaxableSalesGap, TaxPlan3TaxableSalesGap, 
				ETicketSummaryId, AnyItemExclusion, AnyPosAdj, AnyInstAdj, IsByPassCheckOut, StoreFront, DeliveryModel, [State], LastUpdatedBy, LastUpdatedDate
		FROM StgPosInstOrderInvoice  

 		UPDATE piom
		SET MapLevel = @MapLevel
        ,ETicketStatusId = @ETicketStatus
		FROM PosInstOrderMap piom
		INNER JOIN StgPosInstOrderInvoice spioi ON spioi.InstOrderId = piom.InstOrderId
		AND spioi.InstDeliveryId = piom.InstDeliveryId
        WHERE MapLevel = @TMPLEVEL


 		UPDATE piom
		SET MapLevel = @ITMLEVEL
		FROM PosInstOrderMap piom
        WHERE MapLevel = @TMPLEVEL
    
        ";

        internal static string qryGetItemIdForGTIN = @"
        SELECT TOP 1 ItemId
        FROM ItemGTIN 
        WHERE GTINCheckDigit = @GTIN
        ";

        internal static string qryGetStoreDetails = @"
         SELECT StoreNumber, IsAlcoholEnabled, IsLiquorEnabled, MarkupPercent, IsSpecialtyEnabled, IsB2BEnabled, B2B_MarkupPercent, IsBypassCheckoutEnabled 
         FROM Stores_t        
        ";

        internal static string qryGetUnmappedOlogOrdersFromRecon = @"
        SELECT distinct olog.OrderId
        ,olog.DeliveryId
        ,olog.StoreLocation
        ,olog.TransactionDateTime
        ,DATEADD(mi,DateDiff(mi,0,olog.TransactionDateTimeConvertedToEST),0) as TransactionDateTimeEST
        ,olog.TransactionDateConvertedToEST as TransactionDateEST
        ,olog.TransactionAmt
        ,olog.FileVersionIndicator  
        ,ISNULL(tlog.StoreLocation, 0) as TLogStoreLocation
        FROM S0OMNIXX.dbo.Inst_Olog olog (NOLOCK) 
        LEFT JOIN S0OMNIXX.dbo.Inst_TLog tlog (NOLOCK)  on olog.OrderID = tlog.OrderID
        AND olog.DeliveryID = tlog.DeliveryID
        WHERE TransactionDateConvertedToEST BETWEEN @FromDate AND @ToDate
		AND EXISTS ( SELECT TOP 1 InstOrderId
						 FROM S0OMNIRI.dbo.MapLog ml
						 WHERE ISNULL(ml.InstOrderId, 0) = ISNULL(olog.OrderId, 0)
						 AND ISNULL(ml.InstDeliveryId, 0) = ISNULL(olog.DeliveryId, 0)
						 AND ml.InstStoreLocation = olog.StoreLocation
						 AND ml.InstTransactionDateTime = olog.TransactionDateTime
						 AND ml.InstTransactionAmt = olog.TransactionAmt
						 AND ml.Level = @UnMapLevel
						 AND ml.Type = @LogType
					   )
        ";

        internal static string qryGetUnmappedPosOrdersFromRecon = @"
		 SELECT [FacilityID]
        ,[TransactionDate]
        ,[TransactionTM]
        ,[TransactionNumber]
        ,[BusinessDate]
        ,[LineNumber]
        ,[ItemId]
        ,[ItemDescription]
        ,[Quantity]
        ,[SalesVolume]
        ,[VolumeIndicator]
        ,[GTIN]
        ,[Void]
        ,[Ringcode]
        ,[RingTM]
        ,[TaxPlan1]
        ,[TaxPlan2]
        ,[TaxPlan3]
        ,[TaxPlan4]
        ,[NetAmount]
        ,[SalesAmount]
        ,[NonTaxableSales]
        ,[CouponValue]
        ,[TenderAmount]
        ,[TenderAmountOther]
        ,[TotalSalesIncludingTax]
        ,[SalesType]
        ,[RefundSalesFound]
        ,[TaxPlan1Amount]
        ,[TaxPlan2Amount]
        ,[TaxPlan3Amount]
        ,[TaxPlan4Amount]
        ,[TotalTax]
        ,[TaxableAmount]
        ,[TaxableSalesTaxPlan1Amount]
        ,[TaxableSalesTaxPlan2Amount]
        ,[TaxableSalesTaxPlan3Amount]
        ,[TaxableSalesTaxPlan1TaxPlan2Amount]
        ,[TaxableSalesTaxPlan3TaxPlan2Amount]
        ,[AlcoholSales]
        ,[NonAlcoholSales]
        ,[TaxableAlcoholSales]
        ,[TaxableNonAlcoholSales]
        ,[NonTaxableAlcoholSales]
        ,[NonTaxableNonAlcoholSales]
        ,[TaxAlcoholSales]
        ,[TaxNonAlcoholSales]
        ,[BottleDeposit]
        ,[AlcoholFlag]
        ,[LiquorCode]
        ,[TerminalNumber]
        ,[TerminalTypeCode]
        ,[CardTypeCode]
        ,[GTINCheckDigit]
        ,[TaxPlan1Tax]
        ,[TaxPlan1TaxPlan2Tax]
        ,[TaxPlan3TaxPlan2Tax]
        ,[TaxPlan3Tax]
        ,[TenderTypeId]
        ,[MaskedAccountString]
        FROM S0OMNIXX.dbo.PosLineItemTransaction plit
        WHERE TransactionDate BETWEEN @FromDate AND @ToDate
        AND LineNumber = 0
		AND EXISTS ( SELECT TOP 1 PosFacilityId, PosTransactionDate, PosTransactionTM, PosTransactionNumber
			  		 FROM S0OMNIRI.dbo.MapLog ml
					 WHERE ml.PosFacilityId  = plit.FacilityId
					 AND ml.PosTransactionDate = plit.TransactionDate
					 AND ml.PosTransactionTM = plit.TransactionTM
					 AND ml.PosTransactionNumber = plit.TransactionNumber
					 AND ml.[Type] = 'Pos'
					 AND ml.[Level] = 'O'
				   )        
        ";

        internal static string qryUpdateBypssOrdersWithDeliveryId = @"
		UPDATE spiom
		SET spiom.InstDeliveryId = ior.DeliveryId
		FROM S0OMNIRI.dbo.StgPosInstOrderMap spiom
		INNER JOIN S0OMNISG.dbo.InstOrder ior ON spiom.InstOrderId = ior.OrderId                        
        ";


        internal static string qryCheckItemExclusionAppliedForOrder = @"
        ;WITH AnyExclusion
        AS
        (
	        SELECT COUNT( InstOrderId) as ExclusionCount
	        FROM PosInstOrderItemMap
	        WHERE InstOrderID = @OrderId	
	        AND InstDeliveryID = @DeliveryId 
	        AND ExclusionTypeId <> 0
        )
        SELECT CASE WHEN ExclusionCount > 0 THEN 1 ELSE 0 END
        FROM AnyExclusion
        ";

        internal static string qryGetItemGTIN = @"
 		SELECT GTINCheckDigit, ItemId
		FROM S0OMNIXX.dbo.ItemGTIN
		WHERE GETDATE() BETWEEN EffectiveDate AND TerminationDate
		AND ItemId IS NOT NULL
        ";

        internal static string qryGetHistoryDataByStore = @"
		SELECT
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED 
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,SM.SalesDay as SALES_DAY
	    FROM S0OMNIXX.dbo.ITEM_DATA_EXPORT_HISTORY IDEH
		INNER JOIN S0OMNIXX.dbo.StoreMarket SM ON IDEH.STORE_IDENTIFIER = sm.StoreNumber
		WHERE IDEH.ITEM_LOAD_DATE = @LoadDate
        AND IDEH.STORE_IDENTIFIER = @StoreNumber
        ";

        internal static string qryGetHistoryDataByStoreFromArchive = @"
		SELECT
		 IDEH.ITEM_LOAD_DATE 
		,IDEH.STORE_IDENTIFIER
        ,IDEH.RETAILER_REFERENCE_CODE 
        ,IDEH.SCAN_CODE 
        ,IDEH.COST_UNIT 
        ,IDEH.UNIT_RETAIL_PRICE 
        ,IDEH.MARKUP_PRICE_ROUNDED 
        ,IDEH.UNIT_SALE_PRICE
        ,IDEH.MARKUP_SALE_PRICE_ROUNDED 
        ,IDEH.BOGO 
        ,IDEH.PROMOTION_GROUP_ID 
        ,IDEH.BOGO_START_DATE 
        ,IDEH.BOGO_END_DATE 
        ,IDEH.ALCOHOLIC  
		,IDEH.BOTTLE_DEPOSIT 
        ,SM.SalesDay as SALES_DAY
	    FROM S0OMNIXX_ARCH.dbo.ITEM_DATA_EXPORT_HISTORY_ARCH IDEH
		INNER JOIN S0OMNIXX.dbo.StoreMarket SM ON IDEH.STORE_IDENTIFIER = sm.StoreNumber
		WHERE IDEH.ITEM_LOAD_DATE = @LoadDate
        AND IDEH.STORE_IDENTIFIER = @StoreNumber
        ";

        internal static string qryGetStoreFrontForOrder = @"
		SELECT TOP 1 ISNULL(FileVersionIndicator, 'R') as StoreFront
		FROM S0OMNIXX.dbo.Inst_TLog
		WHERE OrderID = @OrderId
		AND DeliveryID = @DeliveryId
        ";

        internal static string qryGetInvoiceDataByWeeks = @"
	    SELECT
	    pioi.InstOrderId, pioi.InstDeliveryId, pioi.PosStoreNumber, pioi.PosTransactionDate, pioi.PosNonAlcoholSales, pioi.PosAlcoholSales, pioi.PosSalesBeforeTax, pioi.PosSalesTax, pioi.PosBottleDeposit, 
	    pioi.PosCouponValue, pioi.PosSalesIncludingTax, pioi.PosTenderAmount, pioi.QualifiedPosNonAlcoholSales, pioi.QualifiedPosAlcoholSales, pioi.QualifiedPosSalesBeforeTax, pioi.QualifiedPosSalesTax, 
	    pioi.QualifiedPosBottleDeposit, pioi.QualifiedPosCouponValue, pioi.QualifiedPosSalesIncludingTax, pioi.PosAdjPreTaxNonAlcoholSales, pioi.PosAdjPreTaxAlcoholSales, pioi.PosAdjSalesTax,
	    pioi.PosAdjSalesIncludingTax, pioi.InstOnlineRevenue, pioi.InstPreTaxNonAlcoholSales, pioi.InstPreTaxAlcoholSales, pioi.InstSalesTax, pioi.InstBottleDeposit, pioi.InstGMV, pioi.InstAdjOnlineRevenue, 
	    pioi.InstAdjPreTaxNonAlcoholSales, pioi.InstAdjPreTaxAlcoholSales, pioi.InstAdjSalesTax, pioi.InstAdjBottleDeposit, pioi.InstAdjGMV, pioi.FeePercentage, pioi.CalculatedSpreadAmount, 
	    pioi.CalculatedSpreadPercentage, pioi.FlatAlcoholFee, pioi.CalculateNonAlcoholFee, pioi.TotalFee, pioi.TaxPlan1TaxGap, pioi.TaxPlan1TaxPlan2TaxGap, pioi.TaxPlan3TaxPlan2TaxGap, 
	    pioi.TaxPlan3TaxGap, pioi.TaxPlan1TaxableSalesGap, pioi.TaxPlan1TaxPlan2TaxableSalesGap, pioi.TaxPlan3TaxPlan2TaxableSalesGap, pioi.TaxPlan3TaxableSalesGap, pioi.ETicketSummaryId, pioi.AnyItemExclusion, 
	    pioi.AnyPosAdj, pioi.AnyInstAdj, pioi.IsByPassCheckOut, pioi.StoreFront, pioi.DeliveryModel, pioi.[State], pioi.LastUpdatedBy, pioi.LastUpdatedDate
	    FROM PosInstOrderInvoice pioi
	    INNER JOIN PosInstOrderMap piom ON pioi.InstOrderId = piom.InstOrderId
	    AND pioi.InstDeliveryId = piom.InstDeliveryId
	    WHERE piom.MapLevel = @InvLevel
        ";

        internal static string qryGetInvoiceFeeRate = @"
        ;WITH InstOrdersByDate
        AS
        (
            SELECT 
            CAST(DATEADD(dd, -(DATEPART(dw, pioi.PosTransactionDate)-1), pioi.PosTransactionDate) as date) [WeekStart]
            ,CAST(DATEADD(dd, 7-(DATEPART(dw, pioi.PosTransactionDate)), pioi.PosTransactionDate) as date) [WeekEnd]
            ,Count(Distinct pioi.InstOrderId) as OrderCountByDate
            FROM PosInstOrderInvoice pioi
            INNER JOIN PosInstOrderMap piom ON pioi.InstOrderId = piom.InstOrderId
            AND pioi.InstDeliveryId = piom.InstDeliveryId
            WHERE piom.MapLevel =  @InvLevel
            GROUP BY pioi.PosTransactionDate
        ),
        TotalInstOrders
        AS
        (
            SELECT WeekStart, WeekEnd, SUM(OrderCountByDate) as TotalOrderCount
            FROM InstOrdersByDate 
            GROUP BY WeekStart, WeekEnd
        )
        SELECT tio.WeekStart, tio.WeekEnd, ifr.id as InvoiceFeeRateId, ifr.[State], ifr.Market, ifr.DeliveryModel, ifr.FlatAlcoholFee, ifr.FlatAlcoholFeeDiscount, ifr.MarkupPercentDiscount
        FROM TotalInstOrders tio
        INNER JOIN InvoiceFeeRate ifr ON tio.TotalOrderCount BETWEEN ifr.FromOrdersCount AND ifr.ToOrdersCount
        ";

        internal static string qryUpdateInvoiceOrdersFeeDetails = @"
		UPDATE pioi
	    SET pioi.TotalFee = spioi.TotalFee
	    ,pioi.FlatAlcoholFee = spioi.FlatAlcoholFee
	    ,pioi.FeePercentage = spioi.FeePercentage
	    ,pioi.CalculateNonAlcoholFee = spioi.CalculateNonAlcoholFee
		,pioi.InvoiceFeeRateId = spioi.InvoiceFeeRateId
	    FROM PosInstOrderInvoice pioi
	    INNER JOIN StgPosInstOrderInvoice spioi ON pioi.InstOrderId = spioi.InstOrderId
	    AND pioi.InstDeliveryId = spioi.InstDeliveryId
	    WHERE spioi.TotalFee <> 0

	    UPDATE piom
	    SET piom.MapLevel = @FeeLevel
	    FROM PosInstOrderMap piom
	    INNER JOIN StgPosInstOrderInvoice spioi ON piom.InstOrderId = spioi.InstOrderId
	    AND piom.InstDeliveryId = spioi.InstDeliveryId
	    WHERE piom.MapLevel = @InvLevel
        AND spioi.TotalFee <> 0
        ";

        internal static string qryGetETicketSummaryData = @"
	    SELECT 
	    ets.Id, ets.StoreNumber, ets.TransactionDate, ets.InstTaxPlan1Tax, ets.InstTaxPlan1TaxPlan2Tax, ets.InstTaxPlan3TaxPlan2Tax, ets.InstTaxPlan3Tax, ets.InstSalesBeforeTax, ets.InstGMV,
	    ets.PosTaxPlan1Tax, ets.PosTaxPlan1TaxPlan2Tax, ets.PosTaxPlan3TaxPlan2Tax, ets.PosTaxPlan3Tax, ets.PosSalesBeforeTax, ets.PosTotalSalesIncludingTax, ets.SalesBeforeTaxGap, ets.TaxPlan1TaxGap,
	    ets.TaxPlan1TaxPlan2TaxGap, ets.TaxPlan3TaxPlan2TaxGap, ets.TaxPlan3TaxGap, ets.NonTaxableSalesGap, ets.TaxPlan1TaxableSalesGap, ets.TaxPlan1TaxPlan2TaxableSalesGap,
	    ets.TaxPlan3TaxPlan2TaxableSalesGap, ets.TaxPlan3TaxableSalesGap, ets.PublishETicketId, ets.LastUpdatedDate, ets.LastUpdatedBy
	    FROM S0OMNIRI.dbo.ETicketSummary ets
	    INNER JOIN S0OMNIXX.dbo.StoreMarket sm ON ets.StoreNumber = sm.StoreNumber
	    WHERE sm.IsEticketEnabled = 1
	    AND ets.PublishETicketId IS NULL                        
        ";

        internal static string qryUpdateSummaryETicketId = @"
	    UPDATE ets
	    SET ets.PublishETicketId = stg.PublishETicketId
	    FROM ETicketSummary ets
	    INNER JOIN StgETicketSummary stg ON ets.Id = stg.Id

        UPDATE piom
        SET ETicketStatusId = @EticketStatusId
        FROM PosInstOrderMap piom
        INNER JOIN PosInstOrderInvoice pioi ON pioi.InstOrderId = piom.InstOrderId
        AND pioi.InstDeliveryId = piom.InstDeliveryId 
        INNER JOIN StgETicketSummary sets ON sets.Id = pioi.ETicketSummaryId 

        ";

        internal static string qryUpdatePosETicketDataXml = @"
        UPDATE PublishETicket
        SET IsETicketGenerated = 1
        ,ETicketXml = @xml
        ,MQMessageId = @MQMessageId
        ,LastUpdatedDate = @LastUpdatedDate
        ,LastUpdatedBy = @LastUpdatedBy
        WHERE Id = @EticketId
        ";

        internal static string qryPushPublishedETicketsToHistory = @"
	    INSERT INTO PublishETicketHistory(
	    Id, StoreNumber, FromTransactionDate, ToTransactionDate, TransmissionDate, NonTaxableSalesGap, TaxableSalesGap, StateAndLocalTaxGap, FoodAndLocalTaxGap, FoodTaxGap, StateTax, StateAndLocalTax,
	    FoodAndLocalTax, FoodTax, IsETicketGenerated, ETicketXml, MQMessageId, LastUpdatedDate, LastUpdatedBy)
	    SELECT 
	    Id, StoreNumber, FromTransactionDate, ToTransactionDate, TransmissionDate, NonTaxableSalesGap, TaxableSalesGap, StateAndLocalTaxGap, FoodAndLocalTaxGap, FoodTaxGap, StateTax, StateAndLocalTax,
	    FoodAndLocalTax, FoodTax, IsETicketGenerated, ETicketXml, MQMessageId, LastUpdatedDate, LastUpdatedBy
	    FROM PublishETicket   
        WHERE  IsETicketGenerated = 1

        UPDATE piom
        SET ETicketStatusId = @EticketStatusId
        FROM PosInstOrderMap piom
        INNER JOIN PosInstOrderInvoice pioi ON pioi.InstOrderId = piom.InstOrderId
        AND pioi.InstDeliveryId = piom.InstDeliveryId 
        INNER JOIN ETicketSummary sets ON sets.Id = pioi.ETicketSummaryId 
        INNER JOIN PublishETicket pet ON pet.Id = sets.PublishETicketId
        WHERE pet.IsETicketGenerated = 1


        DELETE FROM PublishETicket WHERE IsETicketGenerated = 1                  
        ";

        internal static string qryGetPosETicketData = @"--declare @FromDate as datetime, @ToDate as datetime, @ETicketType as varchar(10)
        --select @FromDate = '2017-03-01', @Todate = '2017-03-10', @ETicketType = 'REGULAR'

        DECLARE @DateTime as DateTime, @Date as Date, @Time as Time(0), @strTime as varchar(8)
        SET @DateTime = GETDATE()
        SELECT @Date = @DateTime, @Time = @DateTime

        SELECT @strTime = @Time

        IF OBJECT_ID('tempdb..#PosETicketGenerate') IS NOT NULL DROP TABLE #PosETicketGenerate; 
        CREATE TABLE #PosETicketGenerate(
        [Id] [int] NULL,
        [Type] [varchar](10) NULL,
        [StoreNumber] [int] NULL,
        [FromTransactionDate] [datetime] NULL,
        [ToTransactionDate] [datetime] NULL,
        [TransmissionDate] [datetime] NULL,
        [NonTaxableSalesGap] [decimal](18, 2) NULL,
        [TaxableSalesGap] [decimal](18, 2) NULL,
        [StateAndLocalTaxGap] [decimal](18, 2) NULL,
        [FoodAndLocalTaxGap] [decimal](18, 2) NULL,
        [FoodTaxGap] [decimal](18, 2) NULL,
        --Added by Praveen
        	StateTax [decimal](18, 2) NULL,
        	StateAndLocalTax [decimal](18, 2) NULL,
        	FoodAndLocalTax [decimal](18, 2) NULL,
        	FoodTax [decimal](18, 2) NULL
        )

        INSERT INTO #PosETicketGenerate
        SELECT 
         Id
        ,[Type]
        ,StoreNumber
        ,FromTransactionDate
        ,ToTransactionDate
        ,TransmissionDate
        ,NonTaxableSalesGap
        ,TaxableSalesGap
        ,StateAndLocalTaxGap
        ,FoodAndLocalTaxGap
        ,FoodTaxGap
        --Added by Praveen
        ,StateTax
        ,StateAndLocalTax
        ,FoodAndLocalTax
        ,FoodTax
        FROM PosETicketGenerate
        WHERE eTicketGenerated = 0
        AND ( NonTaxableSalesGap <> 0 
        		OR TaxableSalesGap <> 0 
        		OR StateAndLocalTaxGap <> 0 
        		OR FoodAndLocalTaxGap <> 0 
        		OR FoodTaxGap <> 0 )
        --AND [Type] = @ETicketType

        ---- CreateSales Transaction XML for All Stores
        SELECT StoreNumber, Id as EticketId
        FROM #PosETicketGenerate


        ---- Headers for All Stores 
        ;WITH Header
        AS 
        (
        	SELECT 
        		MessageVersion, ServiceName, ProviderName, ServiceVersion
        	,@Date as CreationDate, @Date as SendDate, IssuingIdentifier, ReplyToService
        	,ReplyToProvider, ReplyToURI, CorrelationID, MessageID 
        	FROM 
        			( 
        				SELECT Keyname, value FROM PosETicketRecord
        				WHERE RecordType = 'HEADER'
        			) posRecord
        	PIVOT(
        				MIN(Value)
        				FOR Keyname IN (	MessageVersion, ServiceName, ProviderName, ServiceVersion
        								,CreationDate, SendDate, IssuingIdentifier, ReplyToService
        								,ReplyToProvider, ReplyToURI, CorrelationID, MessageID
        							)
        		) AS PivotTable
        )
        SELECT StoreNumber, MessageVersion, ServiceName, ProviderName, ServiceVersion, CAST(pos.TransmissionDate as DATE) as CreationDate, CAST(pos.TransmissionDate as DATE) as SendDate, IssuingIdentifier, ReplyToService 
        ,ReplyToProvider, ReplyToURI, CorrelationID, pos.Id as MessageID
        FROM Header 
        CROSS APPLY #PosETicketGenerate pos



        -- SalesTicket Query
        ;WITH SalesTicket
        AS (
        		SELECT 
        		 Operationcode, TicketNumber, Date, Time
        		,Cashier, POSNumber, StoreNumber
        		FROM 
        				( 
        					SELECT Keyname, value FROM PosETicketRecord
        					WHERE RecordType = 'SALESTICKET'
        				) posRecord
        		PIVOT(
        				 MIN(Value)
        				 FOR Keyname IN (	 Operationcode, TicketNumber, Date, Time
        									,Cashier, POSNumber, StoreNumber
        								)
        		) AS PivotTable
        ) 
        SELECT '04' as OperationCode,  pos.Id as TicketNumber, CAST(CAST(pos.TransmissionDate as DATE) as varchar(10)) as [Date], CAST( CAST(pos.TransmissionDate as TIME(0)) as varchar(8)) as [Time], st.Cashier, st.POSNumber, pos.StoreNumber
        FROM #PosETicketGenerate pos
        CROSS APPLY SalesTicket st


        -- GTINSale Query

        ;WITH GTINSale 
        AS (
        	SELECT 
        	 Operationcode, GTINCode, DepartmentNumber, Quantity
        	,Price, Amount
        	FROM 
        			( 
        				SELECT Keyname, value FROM PosETicketRecord
        				WHERE RecordType = 'GTINSale'
        			) posRecord
        	PIVOT(
        			 MIN(Value)
        			 FOR Keyname IN ( Operationcode, GTINCode, DepartmentNumber, Quantity
        							  ,Price, Amount
        							)
        	) AS PivotTable
        )
        SELECT saLkp.StoreNumber, gtin.OperationCode, saLkp.LUValue as GTINCode, gtin.DepartmentNumber, gtin.Quantity, REPLACE(saLkp.Amount,'.','')  as Price, REPLACE( saLkp.Amount,'.','') as Amount, TicketNumber
        FROM GTINSale gtin
        CROSS APPLY 
        (
        	SELECT sa.StoreNumber, PosLkp.LUValue, sa.Amount, sa.LUKey, sa.TicketNumber
        	FROM 
        	(
        		SELECT StoreNumber, LUKey, Amount, TicketNumber
        		FROM 
        		(	
        			SELECT  StoreNumber, NonTaxableSalesGap, TaxableSalesGap, StateAndLocalTaxGap, FoodAndLocalTaxGap, FoodTaxGap,StateTax,StateAndLocalTax,FoodAndLocalTax,FoodTax, Id as TicketNumber
        			FROM #PosETicketGenerate 
        		) p
        		UNPIVOT
        		(
        			Amount 
        			FOR LUKey IN ( NonTaxableSalesGap, TaxableSalesGap, StateAndLocalTaxGap, FoodAndLocalTaxGap, FoodTaxGap,StateTax,StateAndLocalTax,FoodAndLocalTax,FoodTax )
        		) unpvt
        		WHERE unpvt.Amount <> 0
        	)sa 
        	INNER JOIN PosETicketLookUpCodes PosLkp ON sa.LUKey = PosLkp.LUKey
        ) saLkp

        -- TenderAmount Query
        ; WITH Tender
        AS
        (
        	SELECT TenderNumber, TenderAmount
        	FROM 
        			( 
        				SELECT Keyname, value FROM PosETicketRecord
        				WHERE RecordType = 'Tender'
        			) posRecord
        	PIVOT(
        			 MIN(Value)
        			 FOR Keyname IN ( TenderNumber, TenderAmount )
        	) AS PivotTable
        )
        SELECT TndrLkp.StoreNumber, Tndr.TenderNumber, REPLACE(TndrLkp.TotalAmount,'.','')  as TenderAmount, TicketNumber
        FROM Tender Tndr
        CROSS APPLY 
        (
        	SELECT sa.StoreNumber, sa.TotalAmount, TicketNumber
        	FROM 
        	(
        		SELECT StoreNumber, TicketNumber, SUM(Amount) as TotalAmount
        		FROM 
        		(	
        			SELECT  StoreNumber, NonTaxableSalesGap, TaxableSalesGap, StateAndLocalTaxGap, FoodAndLocalTaxGap, FoodTaxGap ,StateTax,StateAndLocalTax,FoodAndLocalTax,FoodTax, Id as TicketNumber
        			FROM #PosETicketGenerate
        		) p
        		UNPIVOT
        		(
        			Amount
        			FOR LUKey IN ( NonTaxableSalesGap, TaxableSalesGap, StateAndLocalTaxGap, FoodAndLocalTaxGap, FoodTaxGap,StateTax,StateAndLocalTax,FoodAndLocalTax,FoodTax  )
        		) unpvt
        		WHERE unpvt.Amount <> 0
        		GROUP BY StoreNumber, TicketNumber
        	)sa 
        ) TndrLkp";

    }
}
