﻿using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Data.SqlClient;
using Dapper;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using FastMember;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public class MapPosInstOrderDac : CommonDac, IMapPosInstOrderDac
    {
        public async Task<List<PosTransactionDTO>> GetBypassCheckoutOrders(string orderIds)
        {
            var query = string.Format(OmniReconQueries.qryGetBypassCheckoutOrdersByOrderId, orderIds);
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<PosTransactionDTO>(query, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task<List<PosTransactionDTO>> GetBypassCheckoutOrders(DateTime ordersFromDt, DateTime ordersToDt)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<PosTransactionDTO>(OmniReconQueries.qryGetBypassCheckoutOrdersByDateRange, new { @FromDate = ordersFromDt, @ToDate = ordersToDt }, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task<IEnumerable<InstCreditReturnOrdersDTO>> GetCreditReturnsData(DateTime minTxnDate, DateTime maxTxnDate)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<InstCreditReturnOrdersDTO>(OmniReconQueries.qryGetCreditReturnsData,
                                                                             new { @FromDate = minTxnDate, @ToDate = maxTxnDate }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<List<InstOLogDTO>> GetOLogOrders(string orderIds, string invoicelevel, string feelevel)
        {
            var query = string.Format(OmniReconQueries.qryGetOLogOrdersByOrderIds, orderIds);
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<InstOLogDTO>(query, new { @InvoiceLevel = invoicelevel, @FeeLevel = feelevel }, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task<List<InstOLogDTO>> GetOLogOrders(DateTime ordersFromDt, DateTime ordersToDt, string invoicelevel, string feelevel)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<InstOLogDTO>(OmniReconQueries.qryGetOLogOrdersByDateRange, new { @FromDate = ordersFromDt, @ToDate = ordersToDt, @InvoiceLevel = invoicelevel, @FeeLevel = feelevel }, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task<MapIntervalDTO> GetMapInterval()
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<MapIntervalDTO>(OmniReconQueries.qryGetMapInterval, commandTimeout: CommandTimeOut);
                return result.FirstOrDefault();
            }
        }

        public async Task<List<PosTransactionDTO>> GetPosTransactionsToMapOlog()
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<PosTransactionDTO>(OmniReconQueries.qryGetPosTransactionsToMapOlog, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task<bool> PushMappedOrdersStagingToMain(string invlevel, string feelevel)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.ExecuteAsync(OmniReconQueries.qryMoveStgPosInstOrderMapToMain, new { @InvLevel = invlevel, @FeeLevel = feelevel }, commandTimeout: CommandTimeOut);
            }
            return true;
        }

        public async Task LoadPosTransactions(DateTime posOrdersMinDt, DateTime maxTxnDate)
        {
            // Query S0OMNI-XX to get the PoslineitemTransactions

            using (var omniconn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var poslinetxns = omniconn.ExecuteReader(OmniReconQueries.qryLoadPosTransactions,
                                                                            new { @FromDate = posOrdersMinDt, @ToDate = maxTxnDate }, commandTimeout: CommandTimeOut);
                // Bulk Insert S0OMNI-RI the POS transactions data
                using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
                {
                    await conn.OpenAsync();

                    //insert into temp table
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                    {

                        bulkCopy.DestinationTableName = "StgPosLineItemTransaction";
                        bulkCopy.BatchSize = 50000;
                        bulkCopy.BulkCopyTimeout = CommandTimeOut;
                        bulkCopy.WriteToServer(poslinetxns);
                    }
                }
            }
        }

        public async Task LoadUnMappedPosTransactions(DateTime posOrdersMinDt, DateTime maxTxnDate)
        {

            using (var omniconn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                // Query S0OMNI-XX to get the PoslineitemTransactions
                var poslinetxns = omniconn.ExecuteReader(OmniReconQueries.qryGetUnmappedPosOrdersFromRecon,
                                                                        new { @FromDate = posOrdersMinDt, @ToDate = maxTxnDate }, commandTimeout: CommandTimeOut);
                // Bulk Insert S0OMNI-RI the POS transactions data
                using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
                {
                    await conn.OpenAsync();

                    //insert into temp table
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                    {

                        bulkCopy.DestinationTableName = "StgPosLineItemTransaction";
                        bulkCopy.BatchSize = 50000;
                        bulkCopy.BulkCopyTimeout = CommandTimeOut;
                        bulkCopy.WriteToServer(poslinetxns);
                    }
                }
            }
        }

        public async Task LogUnmappedPosAtOrderLevel(DateTime minTxnDate, DateTime maxTxnDate, DateTime lastupdatedDate, string lastupdatedBy, string reason, string severity, string type, string level)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.ExecuteAsync(OmniReconQueries.qryLogUnmappedPosAtOrderLevel,
                                        new
                                        {
                                            @FromDate = minTxnDate,
                                            @ToDate = maxTxnDate,
                                            @LastUpdatedBy = lastupdatedBy,
                                            @LastUpdatedDate = lastupdatedDate,
                                            @Reason = reason,
                                            @Severity = severity,
                                            @Type = type,
                                            @Level = level
                                        },
                                        commandTimeout: CommandTimeOut);
            }
        }

        public async Task<List<InstOLogDTO>> GetUnmappedOlogOrdersFromRecon(DateTime fromdate, DateTime todate, string maplevel, string logtype)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<InstOLogDTO>(OmniReconQueries.qryGetUnmappedOlogOrdersFromRecon,
                                                                        new { @FromDate = fromdate, @ToDate = todate, @UnMapLevel = maplevel, @LogType = logtype }, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task UpdateBypssOrdersWithDeliveryId()
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.ExecuteAsync(OmniReconQueries.qryUpdateBypssOrdersWithDeliveryId, commandTimeout: CommandTimeOut);
            }
        }
    }
}
