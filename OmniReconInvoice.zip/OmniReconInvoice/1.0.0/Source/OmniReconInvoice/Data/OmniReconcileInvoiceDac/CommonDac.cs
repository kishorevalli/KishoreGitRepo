﻿using Dapper;
using FastMember;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public class CommonDac : BaseDac, ICommonDac
    {
        public async Task<List<SystemValuesDTO>> GetSystemValues()
        {

            using (var conn = (SqlConnection)S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<SystemValuesDTO>(OmniReconQueries.qryGetSystemValues, commandTimeout: CommandTimeOut);
                return result.ToList();
            }

        }

        public async Task<IEnumerable<StoreTaxRateDTO>> GetStoreTaxRates()
        {
            using (var conn = (SqlConnection)S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<StoreTaxRateDTO>(OmniReconQueries.qryGetStoreTaxRates, commandTimeout: CommandTimeOut);
                return result;

            }
        }

        public async Task<string> GetSystemMessage(string Key)
        {
            var message = string.Empty;
            var CacheKey = "OMNISystemMessages";

            using (var conn = (SqlConnection)S0OMNIRI_Connection)
            {
                var OmniSystemMessages = (List<SystemMessageDTO>)MemoryCache.Default[CacheKey];

                if (OmniSystemMessages == null)
                {
                    OmniSystemMessages = (List<SystemMessageDTO>)await conn.QueryAsync<SystemMessageDTO>(OmniReconQueries.qryGetSystemMessages, commandTimeout: CommandTimeOut);
                    MemoryCache.Default.Add(CacheKey, OmniSystemMessages, DateTime.Now.AddDays(1));
                }

                if (OmniSystemMessages.Any(key => key.Key.ToLower() == Key.ToLower()))
                {
                    return OmniSystemMessages.FirstOrDefault(key => key.Key.ToLower() == Key.ToLower()).Message;
                }
                else return message;
            }
        }

        public async Task<IEnumerable<SystemMessageDTO>> GetSystemMessages()
        {
            var message = string.Empty;
            var CacheKey = "OMNISystemMessages";

            using (var conn = (SqlConnection)S0OMNIRI_Connection)
            {
                var OmniSystemMessages = (IEnumerable<SystemMessageDTO>)MemoryCache.Default[CacheKey];

                if (OmniSystemMessages == null)
                {
                    OmniSystemMessages = await conn.QueryAsync<SystemMessageDTO>(OmniReconQueries.qryGetSystemMessages, commandTimeout: CommandTimeOut);
                    MemoryCache.Default.Add(CacheKey, OmniSystemMessages, DateTime.Now.AddDays(1));
                }

                return OmniSystemMessages;
            }
        }

        public async Task<IEnumerable<SystemParameterDTO>> GetSystemParamteres()
        {
            var message = string.Empty;
            var CacheKey = "OMNISystemParameters";

            using (var conn = (SqlConnection)S0OMNIRI_Connection)
            {
                var OmniSystemParameters = (IEnumerable<SystemParameterDTO>)MemoryCache.Default[CacheKey];

                if (OmniSystemParameters == null)
                {
                    OmniSystemParameters = await conn.QueryAsync<SystemParameterDTO>(OmniReconQueries.qryGetSystemParamteres, commandTimeout: CommandTimeOut);
                    MemoryCache.Default.Add(CacheKey, OmniSystemParameters, DateTime.Now.AddDays(1));
                }

                return OmniSystemParameters;
            }
        }

        public async Task<IEnumerable<StoreMarketDTO>> GetStoreMarket()
        {
            using (var conn = (SqlConnection)S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<StoreMarketDTO>(OmniReconQueries.qryGetStoreMarket, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<bool> BulkCopy<T>(IEnumerable<T> collection, string[] objMembers, string tablename)
        {
            // Bulk Insert S0OMNI-RI the POS transactions data
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.OpenAsync();

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                {
                    using (var reader = ObjectReader.Create(collection, objMembers))
                    {
                        bulkCopy.BulkCopyTimeout = CommandTimeOut;
                        bulkCopy.BatchSize = 50000;
                        bulkCopy.DestinationTableName = tablename;
                        await bulkCopy.WriteToServerAsync(reader);
                    }
                }
            }
            return true;
        }

        public async Task<bool> TruncateTable(string tablename)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.ExecuteAsync(string.Format(OmniReconQueries.qryTruncateTable, tablename), commandTimeout: CommandTimeOut);
            }
            return true;
        }

        public async Task<bool> MoveStgMapLogToMain()
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.ExecuteAsync(OmniReconQueries.qryMoveStgMapLogToMain, commandTimeout: CommandTimeOut);
            }
            return true;
        }

        public async Task<List<InstTLogDTO>> GetTLogOrderItems(long orderid)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<InstTLogDTO>(OmniReconQueries.qryGetTLogOrderItems, new { @OrderId = orderid }, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task<List<PosInstOrderMapDTO>> GetPosInstMappedOrders(string type, string tmplevel, string invlevel, string feelevel)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<PosInstOrderMapDTO>(OmniReconQueries.qryGetPosInstOrdersMapped, new { @Type = type, @TempLevel = tmplevel, @InvLevel = invlevel, @FeeLevel = feelevel }, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task<IEnumerable<StoreDTO>> GetStoreDetails()
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<StoreDTO>(OmniReconQueries.qryGetStoreDetails, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<List<InstTLogDTO>> GetTLogOrderItems(long orderid, long deliveryid)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<InstTLogDTO>(OmniReconQueries.qryGetTLogOrderItems, new { @OrderId = orderid, @DeliveryId = deliveryid }, commandTimeout: CommandTimeOut);
                return result.ToList();
            }
        }

        public async Task<IDictionary<long, int>> GetItemGTIN()
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync(OmniReconQueries.qryGetItemGTIN, commandTimeout: CommandTimeOut);
                return result.ToDictionary(row => (long)row.GTINCheckDigit, row => (int)row.ItemId);
            }
        }

        public async Task UpdateMapLevelOnMappedOrders(string fromMaplevel, string toMapLevel)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.ExecuteAsync(OmniReconQueries.qryUpdateMapLevelOnMappedOrders, new { @FromMapLevel = fromMaplevel, @ToMapLevel = toMapLevel }, commandTimeout: CommandTimeOut);
            }
        }

        public async Task<string> GetStoreFrontForOrder(long orderid, long deliveryid)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.ExecuteScalarAsync<string>(OmniReconQueries.qryGetStoreFrontForOrder, new { @OrderId = orderid, @DeliveryId = deliveryid }, commandTimeout: CommandTimeOut);
                return result;
            }
        }
    }
}
