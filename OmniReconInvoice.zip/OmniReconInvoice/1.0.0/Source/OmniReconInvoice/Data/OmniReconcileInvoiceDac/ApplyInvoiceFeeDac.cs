﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public class ApplyInvoiceFeeDac : CommonDac, IApplyInvoiceFeeDac
    {
        public async Task<IEnumerable<PosInstOrderInvoiceDTO>> GetInvoiceDataByWeeks(string invlevel)
        {
            using (var conn = (SqlConnection)S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<PosInstOrderInvoiceDTO>(OmniReconQueries.qryGetInvoiceDataByWeeks, new { @InvLevel = invlevel }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<IEnumerable<InvoiceFeeRateDTO>> GetInvoiceFeeRate(string invlevel)
        {
            using (var conn = (SqlConnection)S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<InvoiceFeeRateDTO>(OmniReconQueries.qryGetInvoiceFeeRate, new { @InvLevel = invlevel }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task UpdateInvoiceOrdersFeeDetails(string invlevel, string feelevel)
        {
            using (var conn = (SqlConnection)S0OMNIRI_Connection)
            {
                await conn.ExecuteAsync(OmniReconQueries.qryUpdateInvoiceOrdersFeeDetails, new { @InvLevel = invlevel, @FeeLevel = feelevel }, commandTimeout: CommandTimeOut);
            }
        }
    }
}
