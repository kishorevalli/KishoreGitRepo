﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Data.SqlClient;
using Dapper;
using System.Linq;
using FastMember;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public class MapPosInstOrderItemDac : CommonDac, IMapPosInstOrderItemDac
    {
        public async Task<IEnumerable<InstCreditReturnsDTO>> GetCreditRetursForOrder(long orderid, long deliveryid)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.QueryAsync<InstCreditReturnsDTO>(OmniReconQueries.qryGetCreditRetursForOrder, new { @Orderid = orderid, @DeliveryId = deliveryid }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<int> GetItemIdForGTIN(long gtin)
        {
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                var result = await conn.ExecuteScalarAsync<int>(OmniReconQueries.qryGetItemIdForGTIN, new { @GTIN = gtin }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<List<PosLineItemTransactionDTO>> GetPosLineTransactions(IEnumerable<PosInstOrderMapDTO> posInstOrders)
        {
            var posTxns = new List<PosLineItemTransactionDTO>();
            using (var conn = (SqlConnection)base.S0OMNIXX_Connection)
            {
                if (posInstOrders != null && posInstOrders.Any())
                {
                    foreach (var txn in posInstOrders)
                    {
                        var result = await conn.QueryAsync<PosLineItemTransactionDTO>(OmniReconQueries.qryGetPosLineTransactions,
                            new
                            {
                                @FacilityId = txn.PosFacilityId,
                                @TransactionDate = txn.PosTransactionDate,
                                @TransactionTM = txn.PosTransactionTM,
                                @TransactionNumber = txn.PosTransactionNumber,
                            }, commandTimeout: CommandTimeOut);

                        if (result != null && result.Any())
                        {
                            posTxns.AddRange(result.ToList());
                        }
                    }
                }
                return posTxns;
            }
        }

        public async Task<IEnumerable<ItemAttributeDTO>> GetItemAttributes()
        {
            using (var conn = (SqlConnection)base.S0OMNISG_Connection)  // Omni Scan GO
            {
                var result = await conn.QueryAsync<ItemAttributeDTO>(OmniReconQueries.qryGetItemAttributes, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<IEnumerable<InstFeedDiscrepancyDTO>> GetDiscrepanciesForOrder(long orderid, long deliveryid)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<InstFeedDiscrepancyDTO>(OmniReconQueries.qryGetDiscrepanciesForOrder, new { @OrderId = orderid, @DeliveryId = deliveryid }, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<bool> MoveMappedOrderItemsStagingToMain(string maplevel, string tmpLevel)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.ExecuteAsync(OmniReconQueries.qryMoveMappedOrderItemsStagingToMain, new { @MapLevel = maplevel, @TMPLEVEL = tmpLevel }, commandTimeout: CommandTimeOut);
            }
            return true;
        }

        public async Task<bool> DeleteOrderSummaryByOrderId()
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.ExecuteAsync(OmniReconQueries.qryDeleteOrderSummaryByOrderId, commandTimeout: CommandTimeOut);
            }
            return true;
        }
    }
}
