﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MongoDB.Driver;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public class PosEticketDac : CommonDac, IPosEticketDac
    {
        public async Task<IEnumerable<ETicketSummaryDTO>> GetETicketSummaryData()
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.QueryAsync<ETicketSummaryDTO>(OmniReconQueries.qryGetETicketSummaryData, commandTimeout: CommandTimeOut);
                return result;
            }
        }

        public async Task<IEnumerable<CreateSalesTransactionXML1>> GetPosETicketData()
        {
            IEnumerable<CreateSalesTransactionXML1> result = null;

            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                using (var multi = await conn.QueryMultipleAsync(OmniReconQueries.qryGetPosETicketData, commandTimeout: CommandTimeOut))
                {
                    var xmlForAllStores = multi.Read<CreateSalesTransactionXML1>().ToList();
                    var salesTxns = xmlForAllStores.Select(x => new SalesTransactionDTO { StoreNumber = x.StoreNumber, EticketId = x.EticketId }).ToList();
                    var headers = multi.Read<HeaderDTO>().ToList();
                    var salesTicketList = multi.Read<SalesTicketDTO>().ToList();
                    var GTINSaleList = multi.Read<GTINSaleDTO>().ToList();
                    var tenderlist = multi.Read<TenderDTO>().ToList();

                    salesTicketList = multi.MapChild(salesTicketList, GTINSaleList, saleticket => new { saleticket.StoreNumber, saleticket.TicketNumber }, gtin => new { gtin.StoreNumber, gtin.TicketNumber }, (saleticket, gtin) =>
                    {
                        saleticket.GTINSale = gtin.ToList();
                    }).ToList();

                    salesTicketList = multi.MapChild(salesTicketList, tenderlist, saleticket => new { saleticket.StoreNumber, saleticket.TicketNumber }, tndr => new { tndr.StoreNumber, tndr.TicketNumber }, (saleticket, tndr) =>
                    {
                        saleticket.Tender = tndr.FirstOrDefault();
                    }).ToList();

                    //salesTxns = multi.MapChild(salesTxns, salesTicketList, txn => txn.StoreNumber, saleticket => saleticket.StoreNumber, (txn, saleticket) =>
                    //{
                    //    txn.SalesTicket = saleticket.FirstOrDefault();
                    //}).ToList();

                    salesTxns = multi.MapChild(salesTxns, salesTicketList, txn => txn.StoreNumber, saleticket => saleticket.StoreNumber, (txn, saleticket) =>
                    {
                        //txn.SalesTicket = saleticket.FirstOrDefault();
                        txn.SalesTicket = saleticket.Where(a => a.TicketNumber == txn.EticketId).ToList().FirstOrDefault();
                    }).ToList();

                    //salesTxns = multi.MapChild<SalesTransactionDTO, SalesTicketDTO, Tuple<int, int>>(salesTxns, salesTicketList, txn => new Tuple<int, int>(txn.StoreNumber, txn.EticketId), saleticket => new Tuple<int, int>(saleticket.StoreNumber, saleticket.TicketNumber), (txn, saleticket) =>
                    //{
                    //    txn.SalesTicket = saleticket.FirstOrDefault();
                    //}).ToList();

                    //xmlForAllStores = multi.MapChild(xmlForAllStores, headers, xml => xml.StoreNumber, hdr => hdr.StoreNumber, (xml, hdr) =>
                    //{
                    //    xml.Header = hdr.FirstOrDefault();
                    //}).ToList();

                    xmlForAllStores = multi.MapChild(xmlForAllStores, headers, xml => xml.StoreNumber, hdr => hdr.StoreNumber, (xml, hdr) =>
                    {
                        xml.Header = hdr.Where(a => a.MessageID == xml.EticketId.ToString()).ToList().FirstOrDefault();
                    }).ToList();

                    //xmlForAllStores = multi.MapChild(xmlForAllStores, salesTxns, xml => xml.StoreNumber, txn => txn.StoreNumber, (xml, txn) =>
                    //{
                    //    xml.SalesTransaction = txn.FirstOrDefault();
                    //}).ToList();

                    xmlForAllStores = multi.MapChild(xmlForAllStores, salesTxns, xml => xml.StoreNumber, txn => txn.StoreNumber, (xml, txn) =>
                    {
                        xml.SalesTransaction = txn.Where(a => a.SalesTicket.TicketNumber == xml.EticketId).ToList().FirstOrDefault();
                    }).ToList();

                    result = xmlForAllStores;

                }
            }

            return result;
        }

        public async Task PushPublishedETicketsToHistory(int eTicketstatus)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.ExecuteAsync(OmniReconQueries.qryPushPublishedETicketsToHistory, new { @EticketStatusId = eTicketstatus }, commandTimeout: CommandTimeOut);
            }
        }

        public async Task UpdatePosETicketDataXml(long eticketid, string xmlstring, string mqmessageid, DateTime lastupdateddate, string lastupdatedby)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(OmniReconQueries.qryUpdatePosETicketDataXml, new
                {
                    @EticketId = eticketid,
                    @xml = xmlstring,
                    @MQMessageId = mqmessageid,
                    @LastUpdatedDate = lastupdateddate,
                    @LastUpdatedBy = lastupdatedby
                }, commandTimeout: CommandTimeOut);
                conn.Dispose();
            }
        }

        public async Task UpdateSummaryETicketId(int eTicketstatus)
        {
            using (var conn = (SqlConnection)base.S0OMNIRI_Connection)
            {
                var result = await conn.ExecuteAsync(OmniReconQueries.qryUpdateSummaryETicketId, new { @EticketStatusId = eTicketstatus }, commandTimeout: CommandTimeOut);
            }
        }
    }
}


