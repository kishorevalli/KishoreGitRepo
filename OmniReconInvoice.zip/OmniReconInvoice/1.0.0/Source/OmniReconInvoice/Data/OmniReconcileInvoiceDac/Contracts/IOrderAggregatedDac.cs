﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public interface IOrderAggregatedDac : ICommonDac
    {
        Task<IEnumerable<PosInstOrderSummaryDTO>> GetOrderSummaryDetails(Int64 instOrderId, Int64 deliveryId);
        Task<bool> CheckItemExclusionAppliedForOrder(Int64 instOrderId, Int64 instDeliveryId);
        Task MoveInvoiceOrdersStgToMain(string maplevel, string tmplevel, string itmLevel, int etickestatus);
    }
}
