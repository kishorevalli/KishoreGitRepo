﻿using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public interface IMapPosInstOrderItemDac : ICommonDac
    {
        Task<List<PosLineItemTransactionDTO>> GetPosLineTransactions(IEnumerable<PosInstOrderMapDTO> posInstOrders);
        Task<int> GetItemIdForGTIN(long gtin);
        Task<IEnumerable<InstCreditReturnsDTO>> GetCreditRetursForOrder(long orderid, long deliveryid);
        Task<IEnumerable<ItemAttributeDTO>> GetItemAttributes();
        Task<IEnumerable<InstFeedDiscrepancyDTO>> GetDiscrepanciesForOrder(long orderid, long deliveryid);
        Task<bool> MoveMappedOrderItemsStagingToMain(string maplevel, string tmpLevel);
        Task<bool> DeleteOrderSummaryByOrderId();
    }
}
