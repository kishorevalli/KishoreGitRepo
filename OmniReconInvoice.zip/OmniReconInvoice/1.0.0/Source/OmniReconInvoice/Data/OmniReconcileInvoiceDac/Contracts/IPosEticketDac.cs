﻿using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public interface IPosEticketDac : ICommonDac
    {
        Task<IEnumerable<CreateSalesTransactionXML1>> GetPosETicketData();
        Task UpdatePosETicketDataXml(long eticketid, string xmlstring, string mqmessageid, DateTime lastupdateddate, string lastupdatedby);
        Task<IEnumerable<ETicketSummaryDTO>> GetETicketSummaryData();
        Task UpdateSummaryETicketId(int eTicketstatus);
        Task PushPublishedETicketsToHistory(int eTicketstatus);
    }
}
