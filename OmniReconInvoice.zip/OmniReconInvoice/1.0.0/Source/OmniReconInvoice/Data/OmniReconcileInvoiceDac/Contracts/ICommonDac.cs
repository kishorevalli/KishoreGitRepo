﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;


namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public interface ICommonDac
    {
        Task<List<SystemValuesDTO>> GetSystemValues();
        Task<IEnumerable<SystemMessageDTO>> GetSystemMessages();
        Task<IEnumerable<SystemParameterDTO>> GetSystemParamteres();
        Task<IEnumerable<StoreMarketDTO>> GetStoreMarket();
        Task<IEnumerable<StoreTaxRateDTO>> GetStoreTaxRates();
        Task<bool> BulkCopy<T>(IEnumerable<T> collection, string[] objMembers, string tablename);
        Task<bool> TruncateTable(string tablename);
        Task<bool> MoveStgMapLogToMain();
        Task<List<InstTLogDTO>> GetTLogOrderItems(long orderid, long deliveryid);
        Task<List<PosInstOrderMapDTO>> GetPosInstMappedOrders(string type, string tmplevel, string invlevel, string feelevel);
        Task<IEnumerable<StoreDTO>> GetStoreDetails();
        Task<IDictionary<long, int>> GetItemGTIN();
        Task UpdateMapLevelOnMappedOrders(string fromMaplevel, string toMapLevel);
        Task<string> GetStoreFrontForOrder(long orderid, long deliveryid);
    }
}
