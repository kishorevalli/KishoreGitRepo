﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public interface IOrderDiscrepanciesDac : ICommonDac
    {
        Task<IEnumerable<MappedOrderDTO>> GetMappedOrdersForDiscrepancy(string orderlevel);
        Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItem(DateTime loaddate, int storenumber, int itemid);
        Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItem(DateTime loaddate, int storenumber, int itemid, bool archive);
        Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByScanCode(DateTime loaddate, int storenumber, Int64 scancode);
        Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByScanCode(DateTime loaddate, int storenumber, Int64 scancode, bool archive);
        Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItemGTINScanCode(DateTime loaddate, int storenumber, Int64 scancode);
        Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItemGTINScanCode(DateTime loaddate, int storenumber, Int64 scancode, bool archive);
        Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCode(DateTime loaddate, int storenumber, Int64 scancode);
        Task<ItemDataHistoryDTO> GetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCode(DateTime loaddate, int storenumber, Int64 scancode, bool archive);
        Task<bool> ValidateLoadDateExistsInHistory(DateTime loaddate);
        Task PushDiscrepancyDataStagingTomain();
        Task<IEnumerable<ItemDataHistoryDTO>> GetHistoryDataByStore(int storeid, DateTime loaddate);
        Task<IEnumerable<ItemDataHistoryDTO>> GetHistoryDataByStoreFromArchive(int storeid, DateTime loaddate);

    }
}
