﻿using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public interface IApplyInvoiceFeeDac : ICommonDac
    {
        Task<IEnumerable<PosInstOrderInvoiceDTO>> GetInvoiceDataByWeeks(string invlevel);
        Task<IEnumerable<InvoiceFeeRateDTO>> GetInvoiceFeeRate(string invlevel);
        Task UpdateInvoiceOrdersFeeDetails(string invlevel, string feelevel);
    }
}
