﻿using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceDac
{
    public interface IMapPosInstOrderDac : ICommonDac
    {
        Task<List<PosTransactionDTO>> GetBypassCheckoutOrders(string orderIds);
        Task<List<PosTransactionDTO>> GetBypassCheckoutOrders(DateTime ordersFromDt, DateTime ordersToDt);
        Task<List<InstOLogDTO>> GetOLogOrders(string orderIds, string invoicelevel, string feelevel);
        Task<List<InstOLogDTO>> GetOLogOrders(DateTime ordersFromDt, DateTime ordersToDt, string invoicelevel, string feelevel);
        Task<MapIntervalDTO> GetMapInterval();
        Task<bool> PushMappedOrdersStagingToMain(string invlevel, string feelevel);
        Task<List<PosTransactionDTO>> GetPosTransactionsToMapOlog();
        Task LoadPosTransactions(DateTime posOrdersMinDt, DateTime maxTxnDate);
        Task LoadUnMappedPosTransactions(DateTime posOrdersMinDt, DateTime maxTxnDate);
        Task<IEnumerable<InstCreditReturnOrdersDTO>> GetCreditReturnsData(DateTime minTxnDate, DateTime maxTxnDate);
        Task LogUnmappedPosAtOrderLevel(DateTime minTxnDate, DateTime maxTxnDate, DateTime lastupdatedDate, string lastupdatedBy, string reason, string severity, string type, string level);
        Task<List<InstOLogDTO>> GetUnmappedOlogOrdersFromRecon(DateTime fromdate, DateTime todate, string maplevel, string logtype);
        Task UpdateBypssOrdersWithDeliveryId();
    }
}
