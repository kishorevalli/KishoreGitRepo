﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class PosInstOrderSummaryDTO
    {
        public Int64 InstOrderId { get; set; }
        public Int64 InstDeliveryId { get; set; }
        public bool IsMappedItemsGroup { get; set; }
        public decimal InstOnlineRevenue { get; set; }
        public decimal InstPreTaxNonAlcoholSales { get; set; }
        public decimal InstPreTaxAlcoholSales { get; set; }
        public decimal InstSalesTax { get; set; }
        public decimal InstBottleDeposit { get; set; }
        public decimal InstGMV { get; set; }
        public decimal InstAdjOnlineRevenue { get; set; }
        public decimal InstAdjPreTaxNonAlcoholSales { get; set; }
        public decimal InstAdjPreTaxAlcoholSales { get; set; }
        public decimal InstAdjSalesTax { get; set; }
        public decimal InstAdjBottleDeposit { get; set; }
        public decimal InstAdjGMV { get; set; }
        public decimal InstTaxPlan1Tax { get; set; }
        public decimal InstTaxPlan1TaxPlan2Tax { get; set; }
        public decimal InstTaxPlan3TaxPlan2Tax { get; set; }
        public decimal InstTaxPlan3Tax { get; set; }
        public int PosFacilityId { get; set; }
        public DateTime PosTransactionDate { get; set; }
        public int PosTransactionTM { get; set; }
        public int PosTransactionNumber { get; set; }
        public decimal PosSalesAmount { get; set; }
        public decimal PosPreTaxNonAlcoholSales { get; set; }
        public decimal PosPreTaxAlcoholSales { get; set; }
        public decimal PosBottleDeposit { get; set; }
        public decimal PosTotalTax { get; set; }
        public decimal PosTotalSalesIncludingTax { get; set; }
        public decimal PosAdjSalesAmount { get; set; }
        public decimal PosAdjPreTaxNonAlcoholSales { get; set; }
        public decimal PosAdjPreTaxAlcoholSales { get; set; }
        public decimal PosAdjTotalTax { get; set; }
        public decimal PosAdjTotalSalesIncludingTax { get; set; }
        public decimal PosTaxPlan1Tax { get; set; }
        public decimal PosTaxPlan1TaxPlan2Tax { get; set; }
        public decimal PosTaxPlan3TaxPlan2Tax { get; set; }
        public decimal PosTaxPlan3Tax { get; set; }
        public decimal TotalTaxGap { get; set; }
        public decimal TaxPlan1TaxGap { get; set; }
        public decimal TaxPlan1TaxPlan2TaxGap { get; set; }
        public decimal TaxPlan3TaxPlan2TaxGap { get; set; }
        public decimal TaxPlan3TaxGap { get; set; }
        public decimal NonTaxableSalesGap { get; set; }
        public decimal TaxPlan1TaxableSalesGap { get; set; }
        public decimal TaxPlan1TaxPlan2TaxableSalesGap { get; set; }
        public decimal TaxPlan3TaxPlan2TaxableSalesGap { get; set; }
        public decimal TaxPlan3TaxableSalesGap { get; set; }
        public decimal SpreadAmount { get; set; }
        public decimal SpreadPercentage { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }

    }
}
