﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class MappedOrderDTO
    {
        public long OrderId { get; set; }
        public long DeliveryId { get; set; }
        public int StoreNumber { get; set; }
        public DateTime OrderedDate { get; set; }
    }
}
