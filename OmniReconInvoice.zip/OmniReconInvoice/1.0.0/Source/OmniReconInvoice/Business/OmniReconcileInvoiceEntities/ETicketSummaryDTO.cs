﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class ETicketSummaryDTO
    {
        public decimal Id { get; set; }
        public int StoreNumber { get; set; }
        public DateTime TransactionDate { get; set; }
        public decimal InstTaxPlan1Tax { get; set; }
        public decimal InstTaxPlan1TaxPlan2Tax { get; set; }
        public decimal InstTaxPlan3TaxPlan2Tax { get; set; }
        public decimal InstTaxPlan3Tax { get; set; }
        public decimal InstSalesBeforeTax { get; set; }
        public decimal InstGMV { get; set; }
        public decimal PosTaxPlan1Tax { get; set; }
        public decimal PosTaxPlan1TaxPlan2Tax { get; set; }
        public decimal PosTaxPlan3TaxPlan2Tax { get; set; }
        public decimal PosTaxPlan3Tax { get; set; }
        public decimal PosSalesBeforeTax { get; set; }
        public decimal PosTotalSalesIncludingTax { get; set; }
        public decimal SalesBeforeTaxGap { get; set; }
        public decimal TaxPlan1TaxGap { get; set; }
        public decimal TaxPlan1TaxPlan2TaxGap { get; set; }
        public decimal TaxPlan3TaxPlan2TaxGap { get; set; }
        public decimal TaxPlan3TaxGap { get; set; }
        public decimal NonTaxableSalesGap { get; set; }
        public decimal TaxPlan1TaxableSalesGap { get; set; }
        public decimal TaxPlan1TaxPlan2TaxableSalesGap { get; set; }
        public decimal TaxPlan3TaxPlan2TaxableSalesGap { get; set; }
        public decimal TaxPlan3TaxableSalesGap { get; set; }
        public long? PublishETicketId { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}
