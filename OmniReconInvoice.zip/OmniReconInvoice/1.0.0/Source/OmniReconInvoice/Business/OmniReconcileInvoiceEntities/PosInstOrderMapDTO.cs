﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class PosInstOrderMapDTO
    {
        public Int64 InstOrderId { get; set; }
        public Int64 InstDeliveryId { get; set; }
        public bool InstOrderSplit { get; set; }
        public int InstOlogStoreLocation { get; set; }
        public DateTime? InstOlogTransactionDateTime { get; set; }
        public DateTime? InstOlogTransactionDateEST { get; set; }
        public DateTime? InstOlogTransactionDateTimeEST { get; set; }
        public decimal InstOlogTransactionAmt { get; set; }
        public int PosFacilityId { get; set; }
        public DateTime? PosTransactionDate { get; set; }
        public int PosTransactionTM { get; set; }
        public int PosTransactionNumber { get; set; }
        public DateTime? PosTransactionDateTime { get; set; }
        public decimal PosTenderAmount { get; set; }
        public decimal PosTotalSalesIncludingTax { get; set; }
        public decimal PosSalesBeforeTax { get; set; }
        public decimal PosSalesTax { get; set; }
        public decimal PosNonAlcoholSales { get; set; }
        public decimal PosAlcoholSales { get; set; }
        public decimal PosBottleDeposit { get; set; }
        public decimal PosCouponValue { get; set; }
        public bool IsByPassCheckOut { get; set; }
        public string MapLevel { get; set; }
        public int ExclusionTypeId { get; set; }
        public int MapCriteriaId { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
    }
}
