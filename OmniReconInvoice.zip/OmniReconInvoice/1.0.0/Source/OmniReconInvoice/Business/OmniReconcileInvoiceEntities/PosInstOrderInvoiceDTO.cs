﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class PosInstOrderInvoiceDTO
    {
        public Int64 InstOrderId { get; set; }
        public Int64 InstDeliveryId { get; set; }
        public int PosStoreNumber { get; set; }
        public DateTime PosTransactionDate { get; set; }
        public decimal PosNonAlcoholSales { get; set; }
        public decimal PosAlcoholSales { get; set; }
        public decimal PosSalesBeforeTax { get; set; }
        public decimal PosSalesTax { get; set; }
        public decimal PosBottleDeposit { get; set; }
        public decimal PosCouponValue { get; set; }
        public decimal PosSalesIncludingTax { get; set; }
        public decimal PosTenderAmount { get; set; }
        public decimal QualifiedPosNonAlcoholSales { get; set; }
        public decimal QualifiedPosAlcoholSales { get; set; }
        public decimal QualifiedPosSalesBeforeTax { get; set; }
        public decimal QualifiedPosSalesTax { get; set; }
        public decimal QualifiedPosBottleDeposit { get; set; }
        public decimal QualifiedPosCouponValue { get; set; }
        public decimal QualifiedPosSalesIncludingTax { get; set; }
        public decimal PosAdjPreTaxNonAlcoholSales { get; set; }
        public decimal PosAdjPreTaxAlcoholSales { get; set; }
        public decimal PosAdjSalesTax { get; set; }
        public decimal PosAdjSalesIncludingTax { get; set; }
        public decimal InstOnlineRevenue { get; set; }
        public decimal InstPreTaxNonAlcoholSales { get; set; }
        public decimal InstPreTaxAlcoholSales { get; set; }
        public decimal InstSalesTax { get; set; }
        public decimal InstBottleDeposit { get; set; }
        public decimal InstGMV { get; set; }
        public decimal InstAdjOnlineRevenue { get; set; }
        public decimal InstAdjPreTaxNonAlcoholSales { get; set; }
        public decimal InstAdjPreTaxAlcoholSales { get; set; }
        public decimal InstAdjSalesTax { get; set; }
        public decimal InstAdjBottleDeposit { get; set; }
        public decimal InstAdjGMV { get; set; }
        public decimal CalculatedSpreadAmount { get; set; }
        public decimal CalculatedSpreadPercentage { get; set; }
        public decimal FeePercentage { get; set; }
        public decimal FlatAlcoholFee { get; set; }
        public decimal CalculateNonAlcoholFee { get; set; }
        public decimal TotalFee { get; set; }
        public decimal TaxPlan1TaxGap { get; set; }
        public decimal TaxPlan1TaxPlan2TaxGap { get; set; }
        public decimal TaxPlan3TaxPlan2TaxGap { get; set; }
        public decimal TaxPlan3TaxGap { get; set; }
        public decimal TaxPlan1TaxableSalesGap { get; set; }
        public decimal TaxPlan1TaxPlan2TaxableSalesGap { get; set; }
        public decimal TaxPlan3TaxPlan2TaxableSalesGap { get; set; }
        public decimal TaxPlan3TaxableSalesGap { get; set; }
        public decimal ETicketSummaryId { get; set; }
        public int InvoiceFeeRateId { get; set; }
        public bool AnyItemExclusion { get; set; }
        public bool AnyPosAdj { get; set; }
        public bool AnyInstAdj { get; set; }
        public bool IsByPassCheckOut { get; set; }
        public string StoreFront { get; set; }
        public string DeliveryModel { get; set; }
        public string State { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
    }
}
