﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class ItemDataHistoryDTO
    {
        public DateTime ITEM_LOAD_DATE { get; set; }
        public int STORE_IDENTIFIER { get; set; }
        public int RETAILER_REFERENCE_CODE { get; set; }
        public long SCAN_CODE { get; set; }
        public string COST_UNIT { get; set; }
        public decimal UNIT_RETAIL_PRICE { get; set; }
        public decimal MARKUP_PRICE_ROUNDED { get; set; }
        public decimal UNIT_SALE_PRICE { get; set; }
        public decimal MARKUP_SALE_PRICE_ROUNDED { get; set; }
        public string BOGO { get; set; }
        public int PROMOTION_GROUP_ID { get; set; }
        public DateTime BOGO_START_DATE { get; set; }
        public DateTime BOGO_END_DATE { get; set; }
        public string ALCOHOLIC { get; set; }
        public decimal BOTTLE_DEPOSIT { get; set; }
        public int SALES_DAY { get; set; }
    }
}
