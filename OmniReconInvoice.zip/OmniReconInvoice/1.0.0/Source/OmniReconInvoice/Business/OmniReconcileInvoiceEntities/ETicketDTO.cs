﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class ETicketDTO
    {
        public long Id { get; set; }
        public int StoreNumber { get; set; }
        public DateTime FromTransactionDate { get; set; }
        public DateTime ToTransactionDate { get; set; }
        public DateTime TransmissionDate { get; set; }
        public decimal NonTaxableSalesGap { get; set; }
        public decimal TaxableSalesGap { get; set; }
        public decimal StateAndLocalTaxGap { get; set; }
        public decimal FoodAndLocalTaxGap { get; set; }
        public decimal FoodTaxGap { get; set; }
        public decimal StateTax { get; set; }
        public decimal StateAndLocalTax { get; set; }
        public decimal FoodAndLocalTax { get; set; }
        public decimal FoodTax { get; set; }
        public bool IsETicketGenerated { get; set; }
        public string ETicketXml { get; set; }
        public string MQMessageId { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}
