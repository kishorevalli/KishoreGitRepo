﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class StoreMarketDTO
    {
        public int StoreNumber { get; set; }
        public string Market { get; set; }
        public string State { get; set; }
        public int SalesDay { get; set; }
        public string DeliveryModel { get; set; }
        public bool IsEticketEnabled { get; set; }
    }
}
