﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class InvoiceFeeRateDTO
    {
        public DateTime WeekStart { get; set; }
        public DateTime WeekEnd { get; set; }
        public int InvoiceFeeRateId { get; set; }
        public string State { get; set; }
        public string Market { get; set; }
        public string DeliveryModel { get; set; }
        public decimal FlatAlcoholFee { get; set; }
        public decimal FlatAlcoholFeeDiscount { get; set; }
        public decimal MarkupPercentDiscount { get; set; }
    }
}
