﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public enum MapLogReasonEnum
    {
        CancelledOrer = 1,
        FullyRedeliveredOrder = 2,
        ReturnedOrder = 3,
        OlogDoesNotTlog = 4,
        OrdersWithZeroGMV = 5,
        CancelledItem = 6,
        ReturnedItem = 7,
        RedeliveredItem = 8,
        NonMerchandiseItem = 9,
        OrderItemsWithZeroGMV = 10,
        PosItemWithNoTLog = 11,
        BottleDeposit = 12,
        StoreCoupon = 13,
        SpreadNotInRange = 14,
        AlcoholAdjWhenDoesNotMatchPos = 15,
        BottleDepositAdjWhenDoesNotMatchPos = 16,
        InstPriceAdjWhenLessThanPos = 17,
        PosQtyAdjWhenLessThanInst = 18,
        InstRevenueAdjWhenQtyTimesPriceDoesNotMatch = 19,
        NoMapFoundTLogGTIN = 20,
        UnMappedOLog = 21,
        UnMappedPos = 22
    }
}

