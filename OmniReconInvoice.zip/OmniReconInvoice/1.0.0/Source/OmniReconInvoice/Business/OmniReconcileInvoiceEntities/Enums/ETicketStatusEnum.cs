﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public enum ETicketStatusEnum
    {
        Summary = 1,
        Generate = 2,
        Publish = 3
    }
}
