﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public enum MapLevelEnum
    {
        ORDMP = 1, // Order Level Map
        DISCP = 2, // Discrepancy check
        ITMAP = 3, // Item Level Map
        ORSUM = 4, // Order Summary - Aggregated total
        INVCP = 5, // Invoice Level
        FEECP = 6, // Fee Update Complete
        UNMAP = 7, // Unmapped Order
        TMPIT = 8, // Temporary Level for processing Item level Orders
        TMPIN = 9  // Temporary Level for processing Invoice level Orders

    }
}
