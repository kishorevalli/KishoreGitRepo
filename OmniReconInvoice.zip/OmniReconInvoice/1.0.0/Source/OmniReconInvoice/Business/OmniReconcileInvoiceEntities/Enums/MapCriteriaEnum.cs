﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public enum MapCriteriaEnum
    {
        MapWithStoreDateTimeAmount = 100,
        MapWithStoreDateTimeAmountWithVariance = 101,
        MapWithStoreDateAmount = 102,
        MapWithTLogStoreDateTimeAmount = 103,
        MapWithTLogStoreDateTimeAmountWithVariance = 104,
        MapWithTLogStoreDateAmount = 105,
        MapWithDateTimeAmount = 106,
        MapWithDateTimeAmountWithVariance = 107,
        MapWithReturnedAmountDate = 108,
        MapWithDateAmount = 109,
        MapWithReturnedStoreAmountDate = 110,
        NoMapFound = 111,
        MaskedAccountString = 112,
        MatchInstItemDataByScanCode = 200,
        MatchInstItemDataByItem = 201,
        MatchInstItemDataByItemGTINScanCode = 202,
        MatchInstItemDataByItemGTINMarketScanCode = 203,
        MapWithGTIN = 300,
        ExactMatchType2 = 301,
        MapWithItem = 302,
        MapWithItemOfGTIN = 303,
        NoMapFoundGTIN = 304,
        UnMappedPos = 305,
    }
}


