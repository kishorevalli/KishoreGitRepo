﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public enum MapLogTypeEnum
    {
        OLog = 1,
        TLog = 2,
        Pos = 3,
        PosInstItemMap = 4,
        PosInstItemSpread = 5,
        PosInstSummary = 6
    }
}
