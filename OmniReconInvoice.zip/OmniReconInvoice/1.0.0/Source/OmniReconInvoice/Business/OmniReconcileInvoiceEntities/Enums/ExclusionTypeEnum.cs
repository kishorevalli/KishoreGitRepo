﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public enum ExclusionTypeEnum
    {
        None = 0,
        Cancelled = 1,
        FullyRedelivered = 2,
        ReturnedOrder = 3,
        OlogDoesNotTlog = 4,
        OrdersWithZeroGMV = 5,
        CancelledItem = 6,
        ReturnedItem = 7,
        RedeliveredItem = 8,
        NonMerchandiseItem = 9,
        OrderItemsWithZeroGMV = 10,
        PosItemWithNoTLog = 11,
        BottleDeposit = 12,
        StoreCoupon = 13,
        SpreadNotInRange = 14

    }
}


