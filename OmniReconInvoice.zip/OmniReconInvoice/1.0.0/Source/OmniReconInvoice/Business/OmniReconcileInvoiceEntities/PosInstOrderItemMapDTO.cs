﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class PosInstOrderItemMapDTO
    {
        public Int64 InstOrderId { get; set; }
        public Int64 InstDeliveryId { get; set; }
        public int InstStoreLocation { get; set; }
        public DateTime? InstOrderedDateEst { get; set; }
        public DateTime? InstDeliveryDateEst { get; set; }
        public int InstReferenceCode { get; set; }
        public Int64 InstGTIN { get; set; }
        public string InstItemName { get; set; }
        public bool InstIsAlcohol { get; set; }
        public string InstPriceSource { get; set; }
        public decimal InstQty { get; set; }
        public string InstUnit { get; set; }
        public decimal InstOnlinePrice { get; set; }
        public decimal InstOnlineRevenue { get; set; }
        public decimal InstSalesTax { get; set; }
        public decimal InstBottleDeposit { get; set; }
        public decimal InstGMV { get; set; }
        public bool InstAdjIsAlcohol { get; set; }
        public decimal InstAdjQty { get; set; }
        public string InstAdjUnit { get; set; }
        public decimal InstAdjOnlinePrice { get; set; }
        public decimal InstAdjOnlineRevenue { get; set; }
        public decimal InstAdjSalesTax { get; set; }
        public decimal InstAdjBottleDeposit { get; set; }
        public decimal InstAdjGMV { get; set; }
        public decimal InstTaxPlan1Tax { get; set; }
        public decimal InstTaxPlan1TaxPlan2Tax { get; set; }
        public decimal InstTaxPlan3TaxPlan2Tax { get; set; }
        public decimal InstTaxPlan3Tax { get; set; }
        public int PosFacilityId { get; set; }
        public DateTime? PosTransactionDate { get; set; }
        public int PosTransactionTM { get; set; }
        public int PosTransactionNumber { get; set; }
        public int PosItemId { get; set; }
        public Int64 PosGTIN { get; set; }
        public string PosItemName { get; set; }
        public int SalesType { get; set; }
        public bool PosIsAlcohol { get; set; }
        public decimal PosSalesVolume { get; set; }
        public string PosSalesVolumeIndicator { get; set; }
        public decimal PosSalesAmount { get; set; }
        public decimal PosTotalTax { get; set; }
        public decimal PosTotalSalesIncludingTax { get; set; }
        public decimal PosAdjSalesVolume { get; set; }
        public decimal PosAdjSalesVolumeIndicator { get; set; }
        public decimal PosAdjSalesAmount { get; set; }
        public decimal PosAdjTotalTax { get; set; }
        public decimal PosAdjTotalSalesIncludingTax { get; set; }
        public decimal PosTaxPlan1Tax { get; set; }
        public decimal PosTaxPlan1TaxPlan2Tax { get; set; }
        public decimal PosTaxPlan3TaxPlan2Tax { get; set; }
        public decimal PosTaxPlan3Tax { get; set; }
        public decimal SpreadAmount { get; set; }
        public decimal SpreadPercentage { get; set; }
        public int ExclusionTypeId { get; set; }
        public int MapCriteriaId { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
    }
}
