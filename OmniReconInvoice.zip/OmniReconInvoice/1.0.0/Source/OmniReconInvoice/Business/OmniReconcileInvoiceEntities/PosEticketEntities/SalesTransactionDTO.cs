﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class SalesTransactionDTO
    {
        [XmlIgnoreAttribute]
        public int StoreNumber { get; set; }
        [XmlIgnoreAttribute]
        public long EticketId { get; set; }
        public SalesTicketDTO SalesTicket { get; set; }
    }
}
