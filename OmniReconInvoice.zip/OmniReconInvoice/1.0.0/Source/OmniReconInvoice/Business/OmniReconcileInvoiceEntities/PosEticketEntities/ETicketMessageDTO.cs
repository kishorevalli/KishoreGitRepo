﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class ETicketMessageDTO
    {
        public int Id { get; set; }
        public string XmlString { get; set; }
        public string MQMessageId { get; set; }
    }
}
