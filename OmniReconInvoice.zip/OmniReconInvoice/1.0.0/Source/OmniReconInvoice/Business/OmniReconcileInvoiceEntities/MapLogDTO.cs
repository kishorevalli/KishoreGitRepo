﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class MapLogDTO
    {
        public Int64 InstOrderId { get; set; }
        public Int64 InstDeliveryId { get; set; }
        public int InstStoreLocation { get; set; }
        public DateTime? InstTransactionDateTime { get; set; }
        public decimal InstTransactionAmt { get; set; }
        public DateTime? InstOrderedDate { get; set; }
        public DateTime? InstDeliveryDate { get; set; }
        public int InstItemId { get; set; }
        public Int64 InstGTIN { get; set; }
        public decimal InstQty { get; set; }
        public string InstUnit { get; set; }
        public decimal InstOnlinePrice { get; set; }
        public decimal InstBottleDeposit { get; set; }
        public decimal InstGMV { get; set; }
        public int PosFacilityId { get; set; }
        public DateTime? PosTransactionDate { get; set; }
        public int PosTransactionTM { get; set; }
        public int PosTransactionNumber { get; set; }
        public int PosItemId { get; set; }
        public decimal PosSalesVolume { get; set; }
        public string PosSalesVolumeIndicator { get; set; }
        public decimal PosUnitPrice { get; set; }
        public int PosSalesType { get; set; }
        public decimal PosSalesAmount { get; set; }
        public decimal PosBottleDeposit { get; set; }
        public decimal PosTenderAmount { get; set; }
        public decimal SpreadPercentage { get; set; }
        public string Reason { get; set; }
        public string Severity { get; set; }
        public string Type { get; set; }
        public string Level { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
    }
}
