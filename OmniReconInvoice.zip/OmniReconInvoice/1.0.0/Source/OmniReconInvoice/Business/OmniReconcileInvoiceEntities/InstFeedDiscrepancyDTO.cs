﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceEntities
{
    public class InstFeedDiscrepancyDTO
    {
        public Int64 InstOrderId { get; set; }
        public Int64 InstDeliveryId { get; set; }
        public DateTime InstOrderedDateEst { get; set; }
        public DateTime InstDeliveredDateEst { get; set; }
        public int InstStoreLocation { get; set; }
        public int InstRefereneCode { get; set; }
        public Int64 InstGTIN { get; set; }
        public string InstUnit { get; set; }
        public decimal InstQty { get; set; }
        public decimal InstOnlinePrice { get; set; }
        public decimal InstOnlineRevenue { get; set; }
        public string InstAlcoholFlag { get; set; }
        public decimal InstBottleDeposit { get; set; }
        public string InstPriceSource { get; set; }
        public DateTime FeedLoadDate { get; set; }
        public int FeedStoreNumber { get; set; }
        public int FeedRRC { get; set; }
        public Int64 FeedScanCode { get; set; }
        public string FeedCostUnit { get; set; }
        public decimal FeedMarkUpPriceRounded { get; set; }
        public decimal FeedUnitPrice { get; set; }
        public decimal FeedMarkUpSalePriceRounded { get; set; }
        public decimal FeedSalePrice { get; set; }
        public string FeedBogo { get; set; }
        public int FeedPromoGroupId { get; set; }
        public DateTime FeedPromoStartDate { get; set; }
        public DateTime FeedPromoEndDate { get; set; }
        public string FeedAlcoholFlag { get; set; }
        public decimal FeedBottleDeposit { get; set; }
        public string Type { get; set; }
        public int MapCriteriaId { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
    }
}
