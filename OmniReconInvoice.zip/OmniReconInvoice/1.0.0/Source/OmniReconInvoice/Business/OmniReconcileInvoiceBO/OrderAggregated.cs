﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Transactions;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;


namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{


    public class OrderAggregated : Common, IOrderAggregated
    {
        static IOrderAggregatedDac _dac;
        public OrderAggregated(IOrderAggregatedDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public static List<PosInstOrderMapDTO> PosInstMappedOrders { get; set; }

        public async Task GenerateAggregatedOrderTotals()
        {
            var maxparallelism = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismForMapOLogTLogToPos);
            var transOptions = new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted, Timeout = TransactionManager.MaximumTimeout };

            var aggrOrder = new AggregateOrder(_dac, jobname);
            AggregateOrder.InvoiceOrders = new ConcurrentQueue<PosInstOrderInvoiceDTO>();
            AggregateOrder.AggregatedOrders = new ConcurrentQueue<PosInstAggregatedOrderDTO>();


            await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderInvoice);
            await _dac.TruncateTable(Constants.BulkCopyTables.StgETicketSummary);
            PosInstMappedOrders = await _dac.GetPosInstMappedOrders(MapLevelEnum.ITMAP.ToString(), MapLevelEnum.TMPIN.ToString(), MapLevelEnum.INVCP.ToString(), MapLevelEnum.FEECP.ToString());

            var distinctMappedOrders = PosInstMappedOrders.Select(o => new { OrderId = o.InstOrderId, DeliveryId = o.InstDeliveryId }).Distinct();
            logBO.Info(jobname + "- Generate Invoices for Orders:" + distinctMappedOrders.Count() + "- Start");

            foreach (var ord in distinctMappedOrders)
            {
                var ordsummary = _dac.GetOrderSummaryDetails(ord.OrderId, ord.DeliveryId).Result;
                var storefront = _dac.GetStoreFrontForOrder(ord.OrderId, ord.DeliveryId).Result;
                if (ordsummary != null && ordsummary.Count() > 0)
                {
                    AggregateOrder.ConvertOrderSummaryToInvoice(ordsummary, ord.OrderId, ord.DeliveryId, PosInstMappedOrders, storefront);
                }
            }
            AggregateOrder.CreateETicketsByStoreDate();
            logBO.Info(jobname + "- Generate Invoices for Orders:" + distinctMappedOrders.Count() + "- End");

            using (var scope = new TransactionScope(TransactionScopeOption.Required, transOptions, TransactionScopeAsyncFlowOption.Enabled))
            {
                await _dac.BulkCopy(AggregateOrder.CreateETicketsByStoreDate(), new ETicketSummaryDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgETicketSummary);
                await _dac.BulkCopy(AggregateOrder.InvoiceOrders.DequeueItems(0), new PosInstOrderInvoiceDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgPosInstOrderInvoice);
                await _dac.MoveInvoiceOrdersStgToMain(MapLevelEnum.INVCP.ToString(), MapLevelEnum.TMPIN.ToString(), MapLevelEnum.ITMAP.ToString(), (int)ETicketStatusEnum.Summary);
                await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderInvoice);

                scope.Complete();
            }
        }
    }
}

