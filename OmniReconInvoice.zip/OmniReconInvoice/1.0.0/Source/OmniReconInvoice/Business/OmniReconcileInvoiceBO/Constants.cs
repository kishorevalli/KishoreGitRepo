﻿namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class Constants
    {
        public enum JobReturnCode
        {
            Successful = 0,    //Job and/or step completed with no errors.
            Warning = 4,       //4 = Warning. Job and/or step completed with cautions.
            Failure = 8,       //8 = Failure. Job and/or step completed with one or more errors.
            Severe = 12       //12 = Severe failure. Job and/or step did not complete due to a severe error.
        }

        public static class JobCode
        {
            public static string OMNIRI_ORDER_LEVEL_MAP = "OMNIRI{0}01";
            public static string OMNIRI_INST_POS_PRICE_UOM_DISCREPANCIES = "OMNIRI{0}02";
            public static string OMNIRI_ITEM_LEVEL_MAP = "OMNIRI{0}03";
            public static string OMNIRI_ORDER_AGGREGATED_TOTAL = "OMNIRI{0}04";
            public static string OMNIRI_INVOICE_FEE = "OMNIRI{0}05";
            public static string OMNI_TO_POS_ETICKET_GENERATE = "OMRI{0}06";
            public static string OMNI_TO_POS_ETICKET_PUBLISH = "OMRI{0}07";
        }

        public static class SystemValues
        {

            public static string MaxDegreeOfParallelismForMapOLogTLogToPos = "MaxDegreeOfParallelismForMapOLogTLogToPos";
            public static string NoOfDaysAdditionalPOSTransactionsData = "NoOfDaysAdditionalPOSTransactionsData";
            public static string SushiChineseFamilyGroup = "SushiChineseFamilyGroup";
            public static string PanamaCityStores = "PanamaCityStores";
            public static string MinimumAcceptableSpreadPercentage = "MinimumAcceptableSpreadPercentage";
            public static string MaximumAcceptableSpreadPercentage = "MaximumAcceptableSpreadPercentage";
            public static string LiveDateToAdjustSalesTax = "LiveDateToAdjustSalesTax";
            public static string MinHistoryDateForItemFeed = "MinHistoryDateForItemFeed";
        }

        public static class JobArgs
        {
            public const string Generate = "GENERATE";
            public const string Publish = "PUBLISH";
        }

        public static class SystemParameters
        {
            public static string POSEticketMQQueueManager = "POSEticketMQQueueManager";
            public static string POSEticketMQQueue = "POSEticketMQQueue";
            public static string JobMachineIdentifier = "JobMachineIdentifier";
        }

        public static class BulkCopyTables
        {
            public static string StgInstFeedDiscrepancy = "StgInstFeedDiscrepancy";
            public static string StgPosInstOrderMap = "StgPosInstOrderMap";
            public static string StgMapLog = "StgMapLog";
            public static string StgPosInstOrderItemMap = "StgPosInstOrderItemMap";
            public static string PosInstOrderSummary = "PosInstOrderSummary";
            public static string StgPosInstOrderInvoice = "StgPosInstOrderInvoice";
            public static string StgPosLineItemTransaction = "StgPosLineItemTransaction";
            public static string StgETicketSummary = "StgETicketSummary";
            public static string PublishETicket = "PublishETicket";
        }
    }
}