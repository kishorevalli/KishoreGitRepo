﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Data.SqlTypes;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public abstract class OrderSummary : MapTLogPosAbstract
    {
        protected OrderSummary(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public static void GetSummaryDetails(IEnumerable<PosInstOrderItemMapDTO> mappedDetails, PosInstOrderMapDTO posordermap)
        {
            var summaryrecords = CreateSummaryRecord(mappedDetails);
            //ApplyInstacartLiability(mappedDetails, summaryrecords);
            ApplySummaryAdjustments(mappedDetails, posordermap, summaryrecords);

            foreach (var order in summaryrecords)
            {
                TaxSpreadCalculation.CalculateSpreadForSummary(order);
            }

            SummaryPosInstOrders.Enqueue(summaryrecords);
        }

        static List<PosInstOrderSummaryDTO> CreateSummaryRecord(IEnumerable<PosInstOrderItemMapDTO> mappedDetails)
        {
            var result = new List<PosInstOrderSummaryDTO>();

            // This creates header for mapped records.  Consider only records which +ve spread for Tax Gap.
            if (mappedDetails != null)
            {

                // Group all mapped records
                result = mappedDetails.Where(m => m.PosFacilityId != 0 && m.PosTransactionNumber != 0 && m.PosTransactionTM != 0 && m.PosTransactionDate != null && m.InstGMV != 0 && m.ExclusionTypeId == 0)
                    .GroupBy(p => new { p.InstOrderId, p.InstDeliveryId, p.PosFacilityId, p.PosTransactionDate, p.PosTransactionTM, p.PosTransactionNumber },
                                    (key, grp) => new PosInstOrderSummaryDTO
                                    {
                                        InstOrderId = key.InstOrderId,
                                        InstDeliveryId = key.InstDeliveryId,
                                        IsMappedItemsGroup = true,
                                        InstOnlineRevenue = grp.Sum(i => i.InstOnlineRevenue),
                                        InstPreTaxAlcoholSales = grp.Where(t => t.InstIsAlcohol).Sum(i => (i.InstOnlineRevenue)),
                                        InstPreTaxNonAlcoholSales = grp.Where(t => !t.InstIsAlcohol).Sum(i => (i.InstOnlineRevenue)),
                                        InstSalesTax = grp.Sum(i => i.InstSalesTax),
                                        InstBottleDeposit = grp.Sum(i => i.InstBottleDeposit),
                                        InstGMV = grp.Sum(i => i.InstGMV),
                                        InstAdjOnlineRevenue = grp.Any(s => s.InstAdjOnlineRevenue != 0 || s.InstAdjIsAlcohol) ? (grp.Sum(i => (i.InstAdjOnlineRevenue != 0 ? i.InstAdjOnlineRevenue : i.InstOnlineRevenue))) : 0,
                                        InstAdjPreTaxAlcoholSales = grp.Any(s => s.InstAdjOnlineRevenue != 0 || s.InstAdjIsAlcohol) ? (grp.Where(t => t.InstAdjIsAlcohol).Sum(i => (i.InstAdjOnlineRevenue != 0 ? i.InstAdjOnlineRevenue : i.InstOnlineRevenue))) : 0,
                                        InstAdjPreTaxNonAlcoholSales = grp.Any(s => s.InstAdjOnlineRevenue != 0 || s.InstAdjIsAlcohol) ? (grp.Where(t => !t.InstAdjIsAlcohol).Sum(i => (i.InstAdjOnlineRevenue != 0 ? i.InstAdjOnlineRevenue : i.InstOnlineRevenue))) : 0,
                                        InstAdjSalesTax = grp.Any(s => s.InstAdjSalesTax != 0) ? (grp.Sum(i => (i.InstAdjSalesTax != 0 ? i.InstAdjSalesTax : i.InstSalesTax))) : 0,
                                        InstAdjBottleDeposit = grp.Any(s => s.InstAdjBottleDeposit != 0 || s.InstAdjIsAlcohol) ? (grp.Sum(i => (i.InstAdjBottleDeposit != 0 ? i.InstAdjBottleDeposit : i.InstBottleDeposit))) : 0,
                                        InstAdjGMV = grp.Any(s => s.InstAdjGMV != 0 || s.InstAdjIsAlcohol) ? (grp.Sum(i => (i.InstAdjGMV != 0 ? i.InstAdjGMV : i.InstGMV))) : 0,
                                        InstTaxPlan1Tax = grp.Sum(i => i.InstTaxPlan1Tax),
                                        InstTaxPlan1TaxPlan2Tax = grp.Sum(i => i.InstTaxPlan1TaxPlan2Tax),
                                        InstTaxPlan3TaxPlan2Tax = grp.Sum(i => i.InstTaxPlan3TaxPlan2Tax),
                                        InstTaxPlan3Tax = grp.Sum(i => i.InstTaxPlan3Tax),
                                        PosFacilityId = key.PosFacilityId,
                                        PosTransactionDate = (DateTime)key.PosTransactionDate,
                                        PosTransactionTM = key.PosTransactionTM,
                                        PosTransactionNumber = key.PosTransactionNumber,
                                        PosSalesAmount = grp.Sum(i => i.PosSalesAmount),
                                        PosPreTaxNonAlcoholSales = grp.Where(t => !t.PosIsAlcohol).Sum(i => i.PosSalesAmount),
                                        PosPreTaxAlcoholSales = grp.Where(t => t.PosIsAlcohol).Sum(i => i.PosSalesAmount),
                                        PosTotalTax = grp.Sum(i => i.PosTotalTax),
                                        PosTotalSalesIncludingTax = grp.Sum(i => i.PosTotalSalesIncludingTax),
                                        PosAdjSalesAmount = grp.Sum(i => (i.PosAdjSalesAmount != 0 ? i.PosAdjSalesAmount : i.PosSalesAmount)),
                                        PosAdjPreTaxNonAlcoholSales = grp.Any(s => s.PosAdjSalesAmount != 0) ? (grp.Where(t => !t.PosIsAlcohol).Sum(i => (i.PosAdjSalesAmount != 0 ? i.PosAdjSalesAmount : i.PosSalesAmount))) : 0,
                                        PosAdjPreTaxAlcoholSales = grp.Any(s => s.PosAdjSalesAmount != 0) ? (grp.Where(t => t.PosIsAlcohol).Sum(i => (i.PosAdjSalesAmount != 0 ? i.PosAdjSalesAmount : i.PosSalesAmount))) : 0,
                                        PosAdjTotalTax = grp.Any(s => s.PosAdjTotalTax != 0) ? (grp.Sum(i => (i.PosAdjTotalTax != 0 ? i.PosAdjTotalTax : i.PosTotalTax))) : 0,
                                        PosAdjTotalSalesIncludingTax = grp.Any(s => s.PosAdjTotalSalesIncludingTax != 0) ? (grp.Sum(i => (i.PosAdjTotalSalesIncludingTax != 0 ? i.PosAdjTotalSalesIncludingTax : i.PosTotalSalesIncludingTax))) : 0,
                                        PosTaxPlan1Tax = grp.Sum(i => i.PosTaxPlan1Tax),
                                        PosTaxPlan1TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan1TaxPlan2Tax),
                                        PosTaxPlan3TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan3TaxPlan2Tax),
                                        PosTaxPlan3Tax = grp.Sum(i => i.PosTaxPlan3Tax),
                                        LastUpdatedDate = DateTime.Now,
                                        LastUpdatedBy = Environment.UserName
                                    }).ToList();


                // Group all  UnMapped records - TLog Records
                var unmappedTLog = mappedDetails.Where(m => m.PosFacilityId == 0 && m.ExclusionTypeId == 0)
                 .GroupBy(p => new { p.InstOrderId, p.InstDeliveryId },
                             (key, grp) => new PosInstOrderSummaryDTO
                             {
                                 InstOrderId = key.InstOrderId,
                                 InstDeliveryId = key.InstDeliveryId,
                                 IsMappedItemsGroup = false,
                                 InstOnlineRevenue = grp.Sum(i => i.InstOnlineRevenue),
                                 InstPreTaxAlcoholSales = grp.Where(t => t.InstIsAlcohol).Sum(i => (i.InstOnlineRevenue)),
                                 InstPreTaxNonAlcoholSales = grp.Where(t => !t.InstIsAlcohol).Sum(i => (i.InstOnlineRevenue)),
                                 InstSalesTax = grp.Sum(i => i.InstSalesTax),
                                 InstBottleDeposit = grp.Sum(i => i.InstBottleDeposit),
                                 InstGMV = grp.Sum(i => i.InstGMV),
                                 PosTransactionDate = (DateTime)SqlDateTime.MinValue,
                                 LastUpdatedDate = DateTime.Now,
                                 LastUpdatedBy = Environment.UserName
                             }).FirstOrDefault();


                // If unmapped TLog exists then, rollup both Inst and Pos (if exists).  Otherwise only unmapped Pos can be ignored.
                if (unmappedTLog != null)
                {
                    // Group all umapped records - Pos.  Check for InstStoreLocation = 0, as for Unmapped records, only delivery Id is populated in Previous step in ItemLevelTransactionHelper
                    var unamppedPos = mappedDetails.Where(m => m.InstStoreLocation == 0 && m.ExclusionTypeId == 0)
                                       .GroupBy(p => new { p.PosFacilityId, p.PosTransactionDate, p.PosTransactionTM, p.PosTransactionNumber },
                                                       (key, grp) => new PosInstOrderSummaryDTO
                                                       {
                                                           PosFacilityId = key.PosFacilityId,
                                                           PosTransactionDate = (DateTime)key.PosTransactionDate,
                                                           PosTransactionTM = key.PosTransactionTM,
                                                           PosTransactionNumber = key.PosTransactionNumber,
                                                           PosSalesAmount = grp.Sum(i => i.PosSalesAmount),
                                                           PosPreTaxNonAlcoholSales = grp.Where(t => !t.PosIsAlcohol).Sum(i => i.PosSalesAmount),
                                                           PosPreTaxAlcoholSales = grp.Where(t => t.PosIsAlcohol).Sum(i => i.PosSalesAmount),
                                                           PosTotalTax = grp.Sum(i => i.PosTotalTax),
                                                           PosTotalSalesIncludingTax = grp.Sum(i => i.PosTotalSalesIncludingTax),
                                                           PosTaxPlan1Tax = grp.Sum(i => i.PosTaxPlan1Tax),
                                                           PosTaxPlan1TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan1TaxPlan2Tax),
                                                           PosTaxPlan3TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan3TaxPlan2Tax),
                                                           PosTaxPlan3Tax = grp.Sum(i => i.PosTaxPlan3Tax),
                                                           LastUpdatedDate = DateTime.Now,
                                                           LastUpdatedBy = Environment.UserName
                                                       }).ToList();


                    if (unamppedPos != null && unamppedPos.Count > 0 && unmappedTLog != null)
                    {
                        for (int i = 0; i < unamppedPos.Count; i++)
                        {
                            // map Tlog to only one unmapped Pos, for every other remaining unmapped Pos add only OrderId, DeliveryId.
                            if (i == 0)
                            {
                                unamppedPos[i].InstOrderId = unmappedTLog.InstOrderId;
                                unamppedPos[i].InstDeliveryId = unmappedTLog.InstDeliveryId;
                                unamppedPos[i].IsMappedItemsGroup = false;
                                unamppedPos[i].InstOnlineRevenue = unmappedTLog.InstOnlineRevenue;
                                unamppedPos[i].InstPreTaxNonAlcoholSales = unmappedTLog.InstPreTaxNonAlcoholSales;
                                unamppedPos[i].InstPreTaxAlcoholSales = unmappedTLog.InstPreTaxAlcoholSales;
                                unamppedPos[i].InstSalesTax = unmappedTLog.InstSalesTax;
                                unamppedPos[i].InstBottleDeposit = unmappedTLog.InstBottleDeposit;
                                unamppedPos[i].InstGMV = unmappedTLog.InstGMV;

                                //Evaluate % for each Tax Bracket in POS
                                if (unamppedPos[i].PosTotalTax != 0)
                                {
                                    var taxplan1per = Math.Round((unamppedPos[i].PosTaxPlan1Tax / unamppedPos[i].PosTotalTax), 2, MidpointRounding.AwayFromZero);
                                    var taxplan12per = Math.Round((unamppedPos[i].PosTaxPlan1TaxPlan2Tax / unamppedPos[i].PosTotalTax), 2, MidpointRounding.AwayFromZero);
                                    var taxplan32per = Math.Round((unamppedPos[i].PosTaxPlan3TaxPlan2Tax / unamppedPos[i].PosTotalTax), 2, MidpointRounding.AwayFromZero);
                                    var taxplan3per = Math.Round((unamppedPos[i].PosTaxPlan3Tax / unamppedPos[i].PosTotalTax), 2, MidpointRounding.AwayFromZero);


                                    unamppedPos[i].InstTaxPlan1Tax = Math.Round((unmappedTLog.InstSalesTax * taxplan1per), 2, MidpointRounding.AwayFromZero);
                                    unamppedPos[i].InstTaxPlan1TaxPlan2Tax = Math.Round((unmappedTLog.InstSalesTax * taxplan12per), 2, MidpointRounding.AwayFromZero);
                                    unamppedPos[i].InstTaxPlan3TaxPlan2Tax = Math.Round((unmappedTLog.InstSalesTax * taxplan32per), 2, MidpointRounding.AwayFromZero);
                                    unamppedPos[i].InstTaxPlan3Tax = Math.Round((unmappedTLog.InstSalesTax * taxplan3per), 2, MidpointRounding.AwayFromZero);

                                    if (taxplan1per == 0 && taxplan12per == 0 && taxplan32per == 0 && taxplan3per == 0)
                                        unamppedPos[i].InstTaxPlan1Tax = unmappedTLog.InstSalesTax;
                                }
                                else if (unmappedTLog.InstSalesTax > 0) unamppedPos[i].InstTaxPlan1Tax = unmappedTLog.InstSalesTax;


                            }
                            else
                            {
                                unamppedPos[i].InstOrderId = unmappedTLog.InstOrderId;
                                unamppedPos[i].InstDeliveryId = unmappedTLog.InstDeliveryId;
                                unamppedPos[i].IsMappedItemsGroup = false;
                            }
                        }
                        result.AddRange(unamppedPos);
                    }
                    else if (result != null && result.Count > 0)
                    {
                        unmappedTLog.PosTransactionDate = result.FirstOrDefault().PosTransactionDate;
                        unmappedTLog.PosFacilityId = result.FirstOrDefault().PosFacilityId;
                        unmappedTLog.PosTransactionNumber = result.FirstOrDefault().PosTransactionNumber;
                        unmappedTLog.PosTransactionTM = result.FirstOrDefault().PosTransactionTM;
                        unmappedTLog.InstTaxPlan1Tax = unmappedTLog.InstSalesTax;
                        result.Add(unmappedTLog);
                    }
                }
            }
            return result;
        }

        //static void ApplyInstacartLiability(IEnumerable<PosInstOrderItemMapDTO> mappedDetails, List<PosInstOrderSummaryDTO> result)
        //{
        //    // Add Instacart Liability to the Mapped Group Record.
        //    // If no, mapped group found , add the liability to the first found record.
        //    if (result != null && result.Count > 0)
        //    {
        //        var instliability = mappedDetails.Where(p => p.ExclusionTypeId == (int)ExclusionTypeEnum.ReturnedInstacartLiability).Sum(m => m.PosSalesAmount);
        //        var summaryRec = result.FirstOrDefault(m => m.IsMappedItemsGroup);

        //        if (summaryRec != null)
        //        {
        //            result.FirstOrDefault(m => m.IsMappedItemsGroup).InstReturnedLiability = instliability;
        //        }
        //        else
        //            result.FirstOrDefault().InstReturnedLiability = instliability;
        //    }
        //}

        static void ApplySummaryAdjustments(IEnumerable<PosInstOrderItemMapDTO> mappedDetails, PosInstOrderMapDTO posinstorder, List<PosInstOrderSummaryDTO> result)
        {
            if (result != null && result.Count > 0)
            {

                var summaryRec = result.FirstOrDefault(m => m.IsMappedItemsGroup);

                if (summaryRec != null)
                {
                    // Evaulate BottleDeposit only for Mapped Records.
                    AdjInstBottleDepositWhenDoesNotMatchPos.AdjustBottleDepositForOrderSummary(mappedDetails, posinstorder, summaryRec);
                }
            }
        }
    }
}
