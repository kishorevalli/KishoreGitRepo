﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class AdjInstRevenueWhenQtyTimesPriceDoesNotMatch : AdjustmentAbstract
    {
        public AdjInstRevenueWhenQtyTimesPriceDoesNotMatch(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override void AdjustPosInstItems(PosLineItemTransactionDTO postxn, InstTLogDTO tlogRecord, PosInstOrderItemMapDTO mappeditem, InstFeedDiscrepancyDTO discrepancy)
        {
            if (discrepancy != null)
            {
                var feedprice = discrepancy.FeedMarkUpSalePriceRounded != 0 ? discrepancy.FeedMarkUpSalePriceRounded : discrepancy.FeedMarkUpPriceRounded;
                var liveDateToAdjSalesTax = SystemValues.GetValue<DateTime>(Constants.SystemValues.LiveDateToAdjustSalesTax);

                // Adjust Revenue if InstQt * Price < Reveune
                var nonbogogVariance = 0.02m; var bogoVariance = 0.05m;

                var calculatedNonBogoRevenue = Math.Round((tlogRecord.Qty * tlogRecord.InstOnlinePrice), 2, MidpointRounding.AwayFromZero);
                var calculatedBogoRevenue = Math.Round(((tlogRecord.Qty * tlogRecord.InstOnlinePrice) / 2), 2, MidpointRounding.AwayFromZero);


                if ((tlogRecord.InstOnlineRevenue <= (calculatedNonBogoRevenue - nonbogogVariance)) && tlogRecord.GMV != 0 &&
                    discrepancy.FeedBogo.Trim().ToUpper().Equals("FALSE") && feedprice == tlogRecord.InstOnlinePrice)
                {
                    mappeditem.InstAdjOnlineRevenue = calculatedNonBogoRevenue;   //NON - BOGO 

                    if (postxn.TransactionDate >= liveDateToAdjSalesTax)
                    {
                        mappeditem.InstAdjSalesTax = Math.Round((mappeditem.InstAdjOnlineRevenue * (GetTaxRateForStore(postxn) / 100)), 2, MidpointRounding.AwayFromZero);
                    }

                    mappeditem.InstAdjGMV = mappeditem.InstAdjOnlineRevenue + mappeditem.InstAdjSalesTax;
                    mappeditem.ExclusionTypeId = (int)ExclusionTypeEnum.None;

                    // Recalcualte spread.
                    TaxSpreadCalculation.ApplyRules(postxn, mappeditem);
                    MapTLogPosAbstract.MapLog.LogOrderMap(postxn, tlogRecord, discrepancy, MapLogReasonEnum.InstRevenueAdjWhenQtyTimesPriceDoesNotMatch, MapLogTypeEnum.PosInstItemMap, MapLevelEnum.ITMAP, MapLogSeverityEnum.Exception);
                }
                else if (tlogRecord.InstOnlineRevenue <= (calculatedBogoRevenue - bogoVariance) && tlogRecord.GMV != 0 &&
                     discrepancy.FeedBogo.Trim().ToUpper().Equals("TRUE") && feedprice == tlogRecord.InstOnlinePrice)
                {
                    mappeditem.InstAdjOnlineRevenue = calculatedBogoRevenue; //BOGO 

                    if (postxn.TransactionDate >= liveDateToAdjSalesTax)
                    {
                        mappeditem.InstAdjSalesTax = Math.Round((mappeditem.InstAdjOnlineRevenue * (GetTaxRateForStore(postxn) / 100)), 2, MidpointRounding.AwayFromZero);
                    }

                    mappeditem.InstAdjGMV = mappeditem.InstAdjOnlineRevenue + mappeditem.InstAdjSalesTax;
                    mappeditem.ExclusionTypeId = (int)ExclusionTypeEnum.None;

                    // Recalcualte spread.
                    TaxSpreadCalculation.ApplyRules(postxn, mappeditem);
                    MapTLogPosAbstract.MapLog.LogOrderMap(postxn, tlogRecord, discrepancy, MapLogReasonEnum.InstRevenueAdjWhenQtyTimesPriceDoesNotMatch, MapLogTypeEnum.PosInstItemMap, MapLevelEnum.ITMAP, MapLogSeverityEnum.Exception);
                }
            }
        }
    }
}
