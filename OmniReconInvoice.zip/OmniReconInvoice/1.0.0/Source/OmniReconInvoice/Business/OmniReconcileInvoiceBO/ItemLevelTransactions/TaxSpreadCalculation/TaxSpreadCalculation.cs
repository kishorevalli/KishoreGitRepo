﻿using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public abstract class TaxSpreadCalculation : MapTLogPosAbstract
    {
        public delegate void PosInstTaxPlan(PosLineItemTransactionDTO postxn, PosInstOrderItemMapDTO tlog);

        public static List<PosInstTaxPlan> TaxRules { get; set; }
        internal static List<int> PanamacityStores;

        protected TaxSpreadCalculation(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {

        }

        public static void TaxPlan1Rule(PosLineItemTransactionDTO postxn, PosInstOrderItemMapDTO result)
        {
            var instSalesTax = (result.InstAdjSalesTax != 0 ? result.InstAdjSalesTax : result.InstSalesTax);
            var posSalesTax = (result.PosAdjTotalTax != 0 ? result.PosAdjTotalTax : result.PosTotalTax);

            // TaxPlan1, TaxPlan2, TaxPlan3 => 1, 0, 0
            if (postxn.TaxPlan1 == true && postxn.TaxPlan2 == false && postxn.TaxPlan3 == false)
            {
                result.InstTaxPlan1Tax = instSalesTax;
                result.PosTaxPlan1Tax = posSalesTax;
            }
        }

        public static void TaxPlan1TaxPlan2Rule(PosLineItemTransactionDTO postxn, PosInstOrderItemMapDTO result)
        {
            var instSalesTax = (result.InstAdjSalesTax != 0 ? result.InstAdjSalesTax : result.InstSalesTax);
            var posSalesTax = (result.PosAdjTotalTax != 0 ? result.PosAdjTotalTax : result.PosTotalTax);

            var instGMV = (result.InstAdjGMV != 0 ? result.InstAdjGMV : result.InstGMV);
            var instBottleDeposit = (result.InstAdjBottleDeposit != 0 ? result.InstAdjBottleDeposit : result.InstBottleDeposit);

            var instOnlinRevenue = instGMV - instSalesTax - instBottleDeposit;

            // TaxPlan1, TaxPlan2, TaxPlan3 => 1, 1, 0
            if (postxn.TaxPlan1 == true && postxn.TaxPlan2 == true && postxn.TaxPlan3 == false)
            {
                result.PosTaxPlan1TaxPlan2Tax = posSalesTax;

                if (PanamacityStores.Any(x => x == result.PosFacilityId))
                {
                    var taxrate = StoreTaxRates.FirstOrDefault(s => s.StoreNumber == result.PosFacilityId);
                    var panamacityTax = (instOnlinRevenue * taxrate.TaxPlan2) / 100;

                    result.InstSalesTax = instSalesTax + panamacityTax;
                    result.InstTaxPlan1TaxPlan2Tax = instSalesTax + panamacityTax;
                    result.InstOnlineRevenue = instOnlinRevenue - panamacityTax;
                }
                else
                {
                    result.InstTaxPlan1TaxPlan2Tax = instSalesTax;
                }
            }
        }

        public static void TaxPlan3TaxPlan2Rule(PosLineItemTransactionDTO postxn, PosInstOrderItemMapDTO result)
        {
            var instSalesTax = (result.InstAdjSalesTax != 0 ? result.InstAdjSalesTax : result.InstSalesTax);
            var posSalesTax = (result.PosAdjTotalTax != 0 ? result.PosAdjTotalTax : result.PosTotalTax);

            // TaxPlan1, TaxPlan2, TaxPlan3 => 0, 1, 1
            if (postxn.TaxPlan1 == false && postxn.TaxPlan2 == true && postxn.TaxPlan3 == true)
            {
                result.InstTaxPlan3TaxPlan2Tax = instSalesTax;
                result.PosTaxPlan3TaxPlan2Tax = posSalesTax;
            }
        }

        public static void TaxPlan3Rule(PosLineItemTransactionDTO postxn, PosInstOrderItemMapDTO result)
        {
            var instSalesTax = (result.InstAdjSalesTax != 0 ? result.InstAdjSalesTax : result.InstSalesTax);
            var posSalesTax = (result.PosAdjTotalTax != 0 ? result.PosAdjTotalTax : result.PosTotalTax);

            // TaxPlan1, TaxPlan2, TaxPlan3 => 0, 0, 1
            if (postxn.TaxPlan1 == false && postxn.TaxPlan2 == false && postxn.TaxPlan3 == true)
            {
                result.InstTaxPlan3Tax = instSalesTax;
                result.PosTaxPlan3Tax = posSalesTax;
            }
        }

        public static void TaxPlan2Rule(PosLineItemTransactionDTO postxn, PosInstOrderItemMapDTO result)
        {
            var instSalesTax = (result.InstAdjSalesTax != 0 ? result.InstAdjSalesTax : result.InstSalesTax);
            var posSalesTax = (result.PosAdjTotalTax != 0 ? result.PosAdjTotalTax : result.PosTotalTax);

            // TaxPlan1, TaxPlan2, TaxPlan3 => 0, 1, 0
            if (postxn.TaxPlan1 == false && postxn.TaxPlan2 == true && postxn.TaxPlan3 == false)
            {
                result.PosTaxPlan3TaxPlan2Tax = posSalesTax;

                if (PanamacityStores.Any(x => x == result.PosFacilityId))
                {
                    var taxrate = StoreTaxRates.FirstOrDefault(s => s.StoreNumber == result.PosFacilityId);
                    var panamacityTax = (instSalesTax * taxrate.TaxPlan2) / 100;

                    result.InstSalesTax = result.InstSalesTax + panamacityTax;
                    result.InstTaxPlan3TaxPlan2Tax = instSalesTax + panamacityTax;
                    result.InstOnlineRevenue = result.InstOnlineRevenue - panamacityTax;
                }
            }
        }

        public static void NoTaxPlanRule(PosLineItemTransactionDTO postxn, PosInstOrderItemMapDTO result)
        {
            var instSalesTax = (result.InstAdjSalesTax != 0 ? result.InstAdjSalesTax : result.InstSalesTax);
            var posSalesTax = (result.PosAdjTotalTax != 0 ? result.PosAdjTotalTax : result.PosTotalTax);

            // TaxPlan1, TaxPlan2, TaxPlan3 => 0, 0, 0
            if (postxn.TaxPlan1 == false && postxn.TaxPlan2 == false && postxn.TaxPlan3 == false)
            {
                if (posSalesTax > 0) result.PosTaxPlan1Tax = posSalesTax; // This will never execute.
                if (instSalesTax > 0) result.InstTaxPlan1Tax = instSalesTax;
            }
        }


        public static void BuildRules()
        {
            TaxRules = new List<PosInstTaxPlan>();
            TaxRules.Add(TaxPlan1Rule);
            TaxRules.Add(TaxPlan1TaxPlan2Rule);
            TaxRules.Add(TaxPlan3TaxPlan2Rule);
            TaxRules.Add(TaxPlan3Rule);
            TaxRules.Add(TaxPlan2Rule);
            TaxRules.Add(NoTaxPlanRule);

        }

        public static void ApplyRules(PosLineItemTransactionDTO postxn, PosInstOrderItemMapDTO result)
        {
            foreach (var rule in TaxRules)
            {
                rule.Invoke(postxn, result);
            }

            CalculateSpread(result);
        }

        internal static void CalculateSpread(PosInstOrderItemMapDTO result)
        {

            // Spread Calculation
            var instSalesTax = (result.InstAdjOnlineRevenue != 0 ? result.InstAdjSalesTax : result.InstSalesTax);
            var instGMV = (result.InstAdjGMV != 0 ? result.InstAdjGMV : result.InstGMV);
            var instBottleDeposit = (result.InstAdjBottleDeposit != 0 ? result.InstAdjBottleDeposit : result.InstBottleDeposit);

            var instOnlinRevenue = instGMV - instSalesTax - instBottleDeposit;
            var posSalesAmount = result.PosAdjSalesAmount != 0 ? result.PosAdjSalesAmount : result.PosSalesAmount;

            result.SpreadAmount = instOnlinRevenue - posSalesAmount;
            result.SpreadPercentage = Math.Round((posSalesAmount != 0 ? ((result.SpreadAmount / posSalesAmount) * 100) : 0), 3, MidpointRounding.AwayFromZero);
        }

        internal static void CalculateSpreadForSummary(PosInstOrderSummaryDTO order)
        {
            // The tax gap should be correct, as the correct/adjusted tax has been considered for Tax at item Level.
            var instSalesTax = (order.InstAdjSalesTax != 0 ? order.InstAdjSalesTax : order.InstSalesTax);
            var posSalesTax = (order.PosAdjTotalTax != 0 ? order.PosAdjTotalTax : order.PosTotalTax);

            order.TotalTaxGap = instSalesTax - posSalesTax;
            order.TaxPlan1TaxGap = order.InstTaxPlan1Tax - order.PosTaxPlan1Tax;
            order.TaxPlan1TaxPlan2TaxGap = order.InstTaxPlan1TaxPlan2Tax - order.PosTaxPlan1TaxPlan2Tax;
            order.TaxPlan3TaxPlan2TaxGap = order.InstTaxPlan3TaxPlan2Tax - order.PosTaxPlan3TaxPlan2Tax;
            order.TaxPlan3TaxGap = order.InstTaxPlan3Tax - order.PosTaxPlan3Tax;

            order.TaxPlan1TaxableSalesGap = CalculateTaxPlanAmount(order.TaxPlan1TaxGap, "TaxPlan1", order.PosFacilityId);
            order.TaxPlan1TaxPlan2TaxableSalesGap = CalculateTaxPlanAmount(order.TaxPlan1TaxPlan2TaxGap, "TaxPlan1TaxPlan2", order.PosFacilityId);
            order.TaxPlan3TaxPlan2TaxableSalesGap = CalculateTaxPlanAmount(order.TaxPlan3TaxPlan2TaxGap, "TaxPlan3TaxPlan2", order.PosFacilityId);
            order.TaxPlan3TaxableSalesGap = CalculateTaxPlanAmount(order.TaxPlan3TaxGap, "TaxPlan3", order.PosFacilityId);


            // While grouping/rollup of the item level to order summary, the total has been consideered based on adjustement 
            // and hence spread has to be recalculated.
            // Spread Calculation
            var instGMV = (order.InstAdjGMV != 0 ? order.InstAdjGMV : order.InstGMV);
            var instBottleDeposit = (order.InstAdjBottleDeposit != 0 ? order.InstAdjBottleDeposit : order.InstBottleDeposit);

            var instOnlinRevenue = instGMV - instSalesTax - instBottleDeposit;
            var posSalesAmount = order.PosAdjSalesAmount != 0 ? order.PosAdjSalesAmount : order.PosSalesAmount;

            order.SpreadAmount = instOnlinRevenue - posSalesAmount;
            order.SpreadPercentage = Math.Round((posSalesAmount != 0 ? ((order.SpreadAmount / posSalesAmount) * 100) : 0), 3, MidpointRounding.AwayFromZero);
        }

        internal static void CalculateSpreadForInvoice(PosInstAggregatedOrderDTO order)
        {
            // While grouping/rollup of the order summary line items to Invoice level, the total has been consideered based on adjustement 
            // and hence spread has to be recalculated.
            // Spread Calculation
            var instSalesTax = (order.InstAdjSalesTax != 0 ? order.InstAdjSalesTax : order.InstSalesTax);
            var instGMV = (order.InstAdjGMV != 0 ? order.InstAdjGMV : order.InstGMV);
            var instBottleDeposit = (order.InstAdjBottleDeposit != 0 ? order.InstAdjBottleDeposit : order.InstBottleDeposit);

            var instOnlinRevenue = instGMV - instSalesTax - instBottleDeposit;
            var posSalesAmount = order.QualifiedPosSalesBeforeTax;

            order.CalculatedSpreadAmount = instOnlinRevenue - posSalesAmount;
            order.CalculatedSpreadPercentage = Math.Round((posSalesAmount != 0 ? ((order.CalculatedSpreadAmount / posSalesAmount) * 100) : 0), 3, MidpointRounding.AwayFromZero);


        }
    }
}
