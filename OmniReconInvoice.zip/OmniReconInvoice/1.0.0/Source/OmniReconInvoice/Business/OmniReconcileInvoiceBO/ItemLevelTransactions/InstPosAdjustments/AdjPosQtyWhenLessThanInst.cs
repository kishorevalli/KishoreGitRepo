﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    class AdjPosQtyWhenLessThanInst : AdjustmentAbstract
    {
        public AdjPosQtyWhenLessThanInst(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override void AdjustPosInstItems(PosLineItemTransactionDTO postxn, InstTLogDTO tlogRecord, PosInstOrderItemMapDTO mappeditem, InstFeedDiscrepancyDTO discrepancy)
        {
            if (mappeditem.InstQty < mappeditem.PosSalesVolume)
            {
                mappeditem.PosAdjSalesVolume = mappeditem.InstQty;
                mappeditem.PosAdjSalesAmount = Math.Round((mappeditem.PosSalesAmount / mappeditem.PosSalesVolume) * mappeditem.PosAdjSalesVolume, 2, MidpointRounding.AwayFromZero);
                mappeditem.PosAdjTotalTax = Math.Round((mappeditem.PosAdjSalesAmount * GetTaxRateForStore(postxn)) / 100, 2, MidpointRounding.AwayFromZero);
                mappeditem.PosAdjTotalSalesIncludingTax = mappeditem.PosAdjSalesAmount + mappeditem.PosAdjTotalTax;
                mappeditem.ExclusionTypeId = (int)ExclusionTypeEnum.None; // recalculate the Spread and remove exclusion.

                // Recalcualte spread.
                TaxSpreadCalculation.ApplyRules(postxn, mappeditem);
                ApplyItemExclusion.ExcludeSpreadNotInRangeItems(mappeditem); // Spread exclusion should happen after Qty Adjustment 
                MapTLogPosAbstract.MapLog.LogOrderMap(postxn, tlogRecord, new InstFeedDiscrepancyDTO(), MapLogReasonEnum.PosQtyAdjWhenLessThanInst, MapLogTypeEnum.PosInstItemMap, MapLevelEnum.ITMAP, MapLogSeverityEnum.Exception);
            }
        }
    }
}
