﻿using System.Collections.Generic;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Threading.Tasks;
using System;
using System.Linq;
using System.Collections.Concurrent;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;
using System.Transactions;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class ItemLevelTransactionsHelper : Common
    {
        readonly IMapPosInstOrderItemDac _dac;
        static MapTLogPosAbstract applyitemexclusion;

        public ItemLevelTransactionsHelper(IMapPosInstOrderItemDac dac, string jobname, int maxparalleism) : base(dac, jobname)
        {
            _dac = dac;
            MaxParallelism = maxparalleism;
        }

        public IEnumerable<PosInstOrderMapDTO> AggregatedOlogOrders { get; private set; }
        public IEnumerable<PosInstOrderMapDTO> MappedOLogToPosOrders { get; private set; }
        public int MaxParallelism { get; private set; }

        protected internal void ConfigurePosInstItemMapScenarios()
        {
            applyitemexclusion = new ApplyItemExclusion(_dac, jobname);
            MapTLogPosAbstract gtinscenario = new ExactMatchGTIN(_dac, jobname);
            MapTLogPosAbstract gtintype2scenario = new ExactMatchType2(_dac, jobname);
            MapTLogPosAbstract itemscenario = new ExactMatchItem(_dac, jobname);
            MapTLogPosAbstract itemgtinscneario = new ExactMatchItemGTIN(_dac, jobname);
            MapTLogPosAbstract nomatchscenario = new NoMatchGTIN(_dac, jobname);

            applyitemexclusion.SetNextMatchScenario(gtinscenario);
            gtinscenario.SetNextMatchScenario(gtintype2scenario);
            gtintype2scenario.SetNextMatchScenario(itemscenario);
            itemscenario.SetNextMatchScenario(itemgtinscneario);
            itemgtinscneario.SetNextMatchScenario(nomatchscenario);
        }

        protected internal async Task PrepareMappingDataAsync()
        {
            logBO.Info(jobname + "- Prepare Mapping Data for Item Level Transactions - Start");
            MappedOLogToPosOrders = await _dac.GetPosInstMappedOrders(MapLevelEnum.DISCP.ToString(), MapLevelEnum.TMPIT.ToString(), MapLevelEnum.INVCP.ToString(), MapLevelEnum.FEECP.ToString());
            AggregatedOlogOrders = MappedOLogToPosOrders.Where(ol => ol.InstOrderId != 0)
                                                        .GroupBy(o => new { o.InstOrderId, o.InstDeliveryId },
                                (key, grp) => new PosInstOrderMapDTO
                                {
                                    InstOrderId = key.InstOrderId,
                                    InstDeliveryId = key.InstDeliveryId,
                                    InstOlogTransactionAmt = grp.Sum(o => o.InstOlogTransactionAmt),
                                    PosTenderAmount = grp.Sum(o => o.PosTenderAmount),
                                    PosTotalSalesIncludingTax = grp.Sum(o => o.PosTotalSalesIncludingTax),
                                    PosSalesBeforeTax = grp.Sum(o => o.PosSalesBeforeTax),
                                    PosSalesTax = grp.Sum(o => o.PosSalesTax),
                                    PosNonAlcoholSales = grp.Sum(o => o.PosNonAlcoholSales),
                                    PosAlcoholSales = grp.Sum(o => o.PosAlcoholSales),
                                    PosBottleDeposit = grp.Sum(o => o.PosBottleDeposit)
                                });

            logBO.Info(jobname + "- Prepare Mapping Data for Item Level Transactions - End");
        }

        protected internal async Task ProcessItemMap()
        {

            var sync = new object();
            //var mappedPosInstOrderItems = new ConcurrentQueue<PosInstOrderItemMapDTO>();
            //var summaryPosInstOrder = new ConcurrentQueue<List<PosInstOrderSummaryDTO>>();

            logBO.Info(jobname + "- Process Item Level Transactions - Start");
            try
            {
                await _dac.TruncateTable(Constants.BulkCopyTables.StgMapLog);
                await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderItemMap);


                applyitemexclusion.ConfigurePosInstAdjustmentScenarios();
                await MapTLogPosAbstract.Initialize();
                var distinctAggregatedOrders = AggregatedOlogOrders.Select(o => new { OrderId = o.InstOrderId, DeliveryId = o.InstDeliveryId }).Distinct();

                //Parallel.ForEach(
                //distinctAggregatedOrders,
                //new ParallelOptions { MaxDegreeOfParallelism = MaxParallelism },
                //ordr =>
                distinctAggregatedOrders.AsParallel()
                .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                .WithMergeOptions(ParallelMergeOptions.NotBuffered)
                .WithDegreeOfParallelism(MaxParallelism)
                .ForAll(
                ordr =>
                {
                    var mappedDetails = new ConcurrentQueue<PosInstOrderItemMapDTO>();
                    var posInstOrders = MappedOLogToPosOrders.Where(o => o.InstOrderId == ordr.OrderId && o.InstDeliveryId == ordr.DeliveryId);
                    var tlogsForOrder = _dac.GetTLogOrderItems(ordr.OrderId, ordr.DeliveryId).Result;
                    var posTxnsForOrder = _dac.GetPosLineTransactions(posInstOrders).Result;
                    var creditreturnsForOrder = _dac.GetCreditRetursForOrder(ordr.OrderId, ordr.DeliveryId).Result;
                    var discreapancies = _dac.GetDiscrepanciesForOrder(ordr.OrderId, ordr.DeliveryId).Result;


                    var grpTlogForOrder = MapTLogPosAbstract.GroupTLogOrders(tlogsForOrder);
                    var grpPosForOrder = MapTLogPosAbstract.GroupPosLineItemTransaction(posTxnsForOrder);
                    //ApplyItemExclusion.ExcludePosItems(grpPosForOrder); // Exclude Non-Merchandie & SushiChinese Items

                    if (grpTlogForOrder.Any())
                    {
                        //foreach (var item in grpTlogForOrder)
                        //{
                        Parallel.ForEach(
                        grpTlogForOrder,
                        new ParallelOptions { MaxDegreeOfParallelism = grpTlogForOrder.Count },
                        item =>
                        {
                            var posinstmappedItem = applyitemexclusion.MapTlogPosItems(grpPosForOrder, item, creditreturnsForOrder, discreapancies);

                            mappedDetails.Enqueue(posinstmappedItem.Result);
                            MapTLogPosAbstract.MappedPosInstOrderItems.Enqueue(posinstmappedItem.Result);
                            //}
                        });

                        // Check if any Tlog is unmapped, then find pos which is unmapped. Combine both unmapped tlog & pos to a unmapped header.
                        // else if all Tlog items got mapped, then add pos items to map table by having pos items as excluded.

                        var unmappedPos = grpPosForOrder.Where(p => !p.IsPosMapped);
                        if (unmappedPos != null)
                        {
                            // If all TLog records got mapped then, unmapped Pos can be excluded.  Otherwise Pos should be included.

                            var isUnmappedPosExclusionApplied = grpTlogForOrder.Any(t => !t.IsTlogMapped);

                            foreach (var p in unmappedPos)
                            {

                                ExclusionTypeEnum extypeid;
                                if (p.ExclusionType == ExclusionTypeEnum.None)
                                    extypeid = (isUnmappedPosExclusionApplied ? ExclusionTypeEnum.None : ExclusionTypeEnum.PosItemWithNoTLog);
                                else
                                    extypeid = p.ExclusionType;

                                var unmappedpos = MapTLogPosAbstract.MapPosInstItem(p,
                                                          new InstTLogDTO
                                                          {
                                                              OrderId = ordr.OrderId,
                                                              DeliveryId = ordr.DeliveryId,
                                                              ExclusionTypeId = extypeid
                                                          }
                                                          , (int)MapCriteriaEnum.UnMappedPos);
                                mappedDetails.Enqueue(unmappedpos);
                                MapTLogPosAbstract.MappedPosInstOrderItems.Enqueue(unmappedpos);
                            }
                        }
                    }

                    OrderSummary.GetSummaryDetails(mappedDetails.DequeueItems(0), posInstOrders.FirstOrDefault());
                    var tmp = _dac.BulkCopy(MapTLogPosAbstract.MappedPosInstOrderItems.DequeueItems(500), new PosInstOrderItemMapDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgPosInstOrderItemMap).Result;
                    var tmp1 = _dac.BulkCopy(MapTLogPosAbstract.MapLog.DequeueItems(500), new MapLogDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgMapLog).Result;

                });

                await MapTLogPosAbstract.InsertMappedOrderItemDetails();

            }
            catch (AggregateException ex)
            {
                foreach (var inrecep in ex.InnerExceptions)
                    logBO.Error(jobname + "- " + inrecep);

                throw;
            }

            logBO.Info(jobname + "- Process Item Level Transactions - End");
        }

    }
}