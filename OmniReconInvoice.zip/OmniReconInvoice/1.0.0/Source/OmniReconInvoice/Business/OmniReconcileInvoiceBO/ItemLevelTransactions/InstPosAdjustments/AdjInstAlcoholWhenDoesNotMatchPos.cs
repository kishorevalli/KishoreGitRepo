﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class AdjInstAlcoholWhenDoesNotMatchPos : AdjustmentAbstract
    {
        public AdjInstAlcoholWhenDoesNotMatchPos(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override void AdjustPosInstItems(PosLineItemTransactionDTO postxn, InstTLogDTO tlogRecord, PosInstOrderItemMapDTO mappeditem, InstFeedDiscrepancyDTO discrepancy)
        {
            if (discrepancy != null)
            {
                if (tlogRecord.IsAlcoholic.ToUpper() != discrepancy.FeedAlcoholFlag.ToUpper())
                {
                    mappeditem.InstAdjIsAlcohol = (discrepancy.FeedAlcoholFlag != null && discrepancy.FeedAlcoholFlag.ToUpper().Equals("TRUE") ? true : false);
                    MapTLogPosAbstract.MapLog.LogOrderMap(postxn, tlogRecord, discrepancy, MapLogReasonEnum.AlcoholAdjWhenDoesNotMatchPos, MapLogTypeEnum.PosInstItemMap, MapLevelEnum.ITMAP, MapLogSeverityEnum.Exception);
                }
            }
        }
    }
}
