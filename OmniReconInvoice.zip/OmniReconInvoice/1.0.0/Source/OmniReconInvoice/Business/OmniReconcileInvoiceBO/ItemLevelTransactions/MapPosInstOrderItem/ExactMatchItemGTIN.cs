﻿using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class ExactMatchItemGTIN : MapTLogPosAbstract
    {
        public ExactMatchItemGTIN(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<PosInstOrderItemMapDTO> MapTlogPosItems(List<PosLineItemTransactionDTO> postxns, InstTLogDTO tlogRecord, IEnumerable<InstCreditReturnsDTO> creditreturnitems, IEnumerable<InstFeedDiscrepancyDTO> discrepancies)
        {


            if (tlogRecord.GTIN != 0 && !tlogRecord.GTIN.IsType2Upc())
            {
                var itemid = await _dac.GetItemIdForGTIN(tlogRecord.GTIN);

                if (itemid != 0 && postxns.Any() && postxns.Any(p => p.ItemId == itemid))
                {
                    var grpPos = postxns.FirstOrDefault(t => t.ItemId == itemid);
                    var postxn = new PosLineItemTransactionDTO();

                    foreach (var p in postxns)
                    {
                        if (p.ItemId == itemid)
                        {
                            p.IsPosMapped = true;
                            postxn = p;
                            break;
                        }
                    }
                    tlogRecord.IsTlogMapped = true;
                    var mappeditem = MapPosInstItem(grpPos, tlogRecord, (int)MapCriteriaEnum.MapWithItemOfGTIN);

                    // Calcualte Spread Before Adjustment. This is required to use Price Adjusment only when Spread is not in Acceptable Range.
                    TaxSpreadCalculation.ApplyRules(postxn, mappeditem);
                    ApplyItemExclusion.ExcludeSpreadNotInRangeItems(mappeditem);

                    var discrepancy = discrepancies.FirstOrDefault(d => (d.FeedRRC == postxn.ItemId || d.FeedScanCode == tlogRecord.GTIN || d.FeedRRC == tlogRecord.ReferenceCode));
                    foreach (var adj in Adjustments)
                    {
                        ((AdjustmentAbstract)adj).AdjustPosInstItems(postxn, tlogRecord, mappeditem, discrepancy);
                    }

                    return mappeditem;
                }
            }

            return await nextmatchscenario.MapTlogPosItems(postxns, tlogRecord, creditreturnitems, discrepancies);
        }
    }
}