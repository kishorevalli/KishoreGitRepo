﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class AdjInstBottleDepositWhenDoesNotMatchPos : AdjustmentAbstract
    {
        public AdjInstBottleDepositWhenDoesNotMatchPos(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override void AdjustPosInstItems(PosLineItemTransactionDTO postxn, InstTLogDTO tlogRecord, PosInstOrderItemMapDTO mappeditem, InstFeedDiscrepancyDTO discrepancy)
        {
            if (discrepancy != null)
            {
                if (tlogRecord.BottleDeposit < discrepancy.FeedBottleDeposit)
                {
                    var instgmv = mappeditem.InstAdjGMV != 0 ? mappeditem.InstAdjGMV : mappeditem.InstGMV;

                    mappeditem.InstAdjBottleDeposit = discrepancy.FeedBottleDeposit;
                    mappeditem.InstAdjGMV = instgmv + discrepancy.FeedBottleDeposit;
                    MapTLogPosAbstract.MapLog.LogOrderMap(postxn, tlogRecord, discrepancy, MapLogReasonEnum.BottleDepositAdjWhenDoesNotMatchPos, MapLogTypeEnum.PosInstItemMap, MapLevelEnum.ITMAP, MapLogSeverityEnum.Exception);
                }
            }
        }

        public static void AdjustBottleDepositForOrderSummary(IEnumerable<PosInstOrderItemMapDTO> mappedDetails, PosInstOrderMapDTO posordermap, PosInstOrderSummaryDTO ordersummary)
        {
            var posBottleDeposit = posordermap.PosBottleDeposit;
            var instBottleDeposit = mappedDetails.Sum(i => i.InstBottleDeposit);

            ordersummary.PosBottleDeposit = posBottleDeposit;

            if (instBottleDeposit < posBottleDeposit)
            {
                var instgmv = ordersummary.InstAdjGMV != 0 ? ordersummary.InstAdjGMV : ordersummary.InstGMV;
                ordersummary.InstAdjBottleDeposit = posBottleDeposit;
                ordersummary.InstAdjGMV = instgmv + posBottleDeposit;
                MapTLogPosAbstract.MapLog.LogOrderMap(ordersummary, MapLogReasonEnum.BottleDepositAdjWhenDoesNotMatchPos, MapLogTypeEnum.PosInstSummary, MapLevelEnum.ORSUM, MapLogSeverityEnum.Exception);
            }
        }
    }
}
