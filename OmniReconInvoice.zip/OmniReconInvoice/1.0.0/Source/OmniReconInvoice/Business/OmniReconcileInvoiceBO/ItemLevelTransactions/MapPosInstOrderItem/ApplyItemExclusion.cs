﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class ApplyItemExclusion : MapTLogPosAbstract
    {
        public ApplyItemExclusion(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<PosInstOrderItemMapDTO> MapTlogPosItems(List<PosLineItemTransactionDTO> postxns, InstTLogDTO tlogRecord, IEnumerable<InstCreditReturnsDTO> creditreturnitems, IEnumerable<InstFeedDiscrepancyDTO> discrepancies)
        {
            if (creditreturnitems.Any(i => i.OrderId == tlogRecord.OrderId && i.DeliveryId == tlogRecord.DeliveryId && i.RRC == tlogRecord.ReferenceCode))
            {
                var retItem = creditreturnitems.FirstOrDefault(i => i.OrderId == tlogRecord.OrderId && i.DeliveryId == tlogRecord.DeliveryId && i.RRC == tlogRecord.ReferenceCode);

                if (retItem.CancellationFlag.ToUpper().Equals("Y"))
                {
                    tlogRecord.ExclusionTypeId = ExclusionTypeEnum.CancelledItem;
                    MapLog.LogOrderMap(tlogRecord, MapLogReasonEnum.CancelledItem, MapLogTypeEnum.TLog, MapLevelEnum.ITMAP, MapLogSeverityEnum.Warning);
                }
                else if (retItem.ReDeliveryFlag.ToUpper().Equals("Y"))
                {
                    tlogRecord.ExclusionTypeId = ExclusionTypeEnum.RedeliveredItem;
                    MapLog.LogOrderMap(tlogRecord, MapLogReasonEnum.RedeliveredItem, MapLogTypeEnum.TLog, MapLevelEnum.ITMAP, MapLogSeverityEnum.Warning);
                }
                if (retItem.RefundAmount > 0 && retItem.CancellationFlag.ToUpper().Equals("N"))
                {
                    tlogRecord.ExclusionTypeId = ExclusionTypeEnum.ReturnedItem;
                    MapLog.LogOrderMap(tlogRecord, MapLogReasonEnum.ReturnedItem, MapLogTypeEnum.TLog, MapLevelEnum.ITMAP, MapLogSeverityEnum.Warning);
                }
            }

            if (tlogRecord.GMV == 0)
            {
                tlogRecord.ExclusionTypeId = ExclusionTypeEnum.OrderItemsWithZeroGMV;
                MapLog.LogOrderMap(tlogRecord, MapLogReasonEnum.OrderItemsWithZeroGMV, MapLogTypeEnum.TLog, MapLevelEnum.ITMAP, MapLogSeverityEnum.Warning);
            }

            return await nextmatchscenario.MapTlogPosItems(postxns, tlogRecord, creditreturnitems, discrepancies);
        }

        public static void ExcludePosItems(List<PosLineItemTransactionDTO> postxns)
        {
            var sushichineesefamilgrp = SystemValues.GetValue<string>(Constants.SystemValues.SushiChineseFamilyGroup);

            foreach (var p in postxns)
            {
                if (p.SalesType == 1 || p.SalesType == 9)// Bottle Deposit
                {
                    p.ExclusionType = ExclusionTypeEnum.BottleDeposit;
                    MapLog.LogOrderMap(p, MapLogReasonEnum.BottleDeposit, MapLogTypeEnum.Pos, MapLevelEnum.ITMAP, MapLogSeverityEnum.Warning);
                }

                if (p.SalesType == 7)// Bottle Deposit
                {
                    p.ExclusionType = ExclusionTypeEnum.StoreCoupon;
                    MapLog.LogOrderMap(p, MapLogReasonEnum.StoreCoupon, MapLogTypeEnum.Pos, MapLevelEnum.ITMAP, MapLogSeverityEnum.Warning);
                }


                if (p.ItemId > 0 && p.SalesType == 4 && !ItemAttributes.Any(i => i.ItemId == p.ItemId && sushichineesefamilgrp.Contains(i.FamilyGroup.ToString())))
                {
                    p.ExclusionType = ExclusionTypeEnum.NonMerchandiseItem;
                    MapLog.LogOrderMap(p, MapLogReasonEnum.NonMerchandiseItem, MapLogTypeEnum.Pos, MapLevelEnum.ITMAP, MapLogSeverityEnum.Warning);
                }
            }

            //return postxns;
        }

        public static void ExcludeSpreadNotInRangeItems(PosInstOrderItemMapDTO result)
        {
            var minSprdPer = SystemValues.GetValue<decimal>(Constants.SystemValues.MinimumAcceptableSpreadPercentage);
            var maxSprdPer = SystemValues.GetValue<decimal>(Constants.SystemValues.MaximumAcceptableSpreadPercentage);

            if (result.ExclusionTypeId == (int)ExclusionTypeEnum.None && !(result.SpreadPercentage > minSprdPer && result.SpreadPercentage < maxSprdPer))
            {
                result.ExclusionTypeId = (int)ExclusionTypeEnum.SpreadNotInRange;
                MapLog.LogOrderMap(result, MapLogReasonEnum.SpreadNotInRange, MapLogTypeEnum.PosInstItemSpread, MapLevelEnum.ITMAP, MapLogSeverityEnum.Exception);
            }
        }

    }
}
