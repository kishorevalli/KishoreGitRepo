﻿using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Caching;
using System.Collections;
using System.Collections.Concurrent;
using System.Data.SqlTypes;
using System.Transactions;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public abstract class MapTLogPosAbstract : Common
    {
        protected static ItemGtinDTO itemgtinColl;
        protected static IMapPosInstOrderItemDac _dac;

        protected MapTLogPosAbstract nextmatchscenario;
        private static string _jobname = string.Empty;

        public abstract Task<PosInstOrderItemMapDTO> MapTlogPosItems(List<PosLineItemTransactionDTO> postxns, InstTLogDTO tlogRecord, IEnumerable<InstCreditReturnsDTO> creditreturnitems, IEnumerable<InstFeedDiscrepancyDTO> discrepancies);

        public static ArrayList Adjustments { get; set; }
        internal static ConcurrentQueue<MapLogDTO> MapLog { get; set; }
        protected static IEnumerable<ItemAttributeDTO> ItemAttributes { get; set; }

        internal static ConcurrentQueue<List<PosInstOrderSummaryDTO>> SummaryPosInstOrders { get; set; }
        internal static ConcurrentQueue<PosInstOrderItemMapDTO> MappedPosInstOrderItems { get; set; }

        protected MapTLogPosAbstract(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {

            _dac = dac;
            _jobname = jobname;
        }

        protected internal void ConfigurePosInstAdjustmentScenarios()
        {
            Adjustments = new ArrayList();

            // Note: Always Qty Adjustment should be first. Once Qty Adjustment is done, spread exclusion is done. 
            // However after Qty Exclusion, there is no further Spread Exclusion Required.

            Adjustments.Add(new AdjPosQtyWhenLessThanInst(_dac, jobname)); // Order is important here.
            Adjustments.Add(new AdjInstRevenueWhenQtyTimesPriceDoesNotMatch(_dac, jobname)); // Order is important here.
            Adjustments.Add(new AdjInstPriceWhenLessThanPos(_dac, jobname));
            Adjustments.Add(new AdjInstBottleDepositWhenDoesNotMatchPos(_dac, jobname));    // Order is important here.
            Adjustments.Add(new AdjInstAlcoholWhenDoesNotMatchPos(_dac, jobname));

            //Adjustments.Add(new AdjPosPriceWhenUnitDoesNotMatchInst(_dac, jobname)); // Not required, as it is covered in Qty Adjustment.

        }

        public void SetNextMatchScenario(MapTLogPosAbstract nextMatch)
        {
            this.nextmatchscenario = nextMatch;
        }

        public static async Task Initialize()
        {
            var strPanamacityStores = SystemValues.GetValue<string>(Constants.SystemValues.PanamaCityStores);
            if (!string.IsNullOrEmpty(strPanamacityStores))
            {
                TaxSpreadCalculation.PanamacityStores = strPanamacityStores.Split(',').ToList().Select(int.Parse).ToList();
            }

            ItemAttributes = await _dac.GetItemAttributes();

            TaxSpreadCalculation.BuildRules();

            MapLog = new ConcurrentQueue<MapLogDTO>();
            SummaryPosInstOrders = new ConcurrentQueue<List<PosInstOrderSummaryDTO>>();
            MappedPosInstOrderItems = new ConcurrentQueue<PosInstOrderItemMapDTO>();

        }

        protected static string GetDeliveryModelForStore(int storenumber)
        {
            var store = StoreMarket.FirstOrDefault(s => s.StoreNumber == storenumber);

            if (store != null)
                return string.IsNullOrEmpty(store.DeliveryModel) ? string.Empty : store.DeliveryModel;

            return string.Empty;
        }

        internal static PosInstOrderItemMapDTO MapPosInstItem(PosLineItemTransactionDTO postxn, InstTLogDTO tlog, int mapcriteria)
        {
            var deliverymodel = (postxn == null ? GetDeliveryModelForStore(tlog.StoreLocation) : GetDeliveryModelForStore(postxn.FacilityId));
            var fileversion = string.IsNullOrEmpty(tlog.FileVersionIndicator) ? string.Empty : tlog.FileVersionIndicator.Trim();

            var result = new PosInstOrderItemMapDTO
            {
                InstOrderId = tlog.OrderId,
                InstDeliveryId = tlog.DeliveryId,
                InstStoreLocation = tlog.StoreLocation,
                InstOrderedDateEst = tlog.OrderedDateTimeEST,
                InstDeliveryDateEst = tlog.DeliveryDateTimeEST,
                InstReferenceCode = tlog.ReferenceCode,
                InstGTIN = tlog.GTIN,
                InstItemName = tlog.ItemName,
                InstUnit = tlog.Unit,
                InstQty = tlog.Qty,
                InstOnlinePrice = tlog.InstOnlinePrice,
                InstOnlineRevenue = tlog.InstOnlineRevenue,
                InstBottleDeposit = tlog.BottleDeposit,
                InstSalesTax = tlog.SalesTax,
                InstGMV = tlog.GMV,
                InstIsAlcohol = (tlog.IsAlcoholic != null && tlog.IsAlcoholic.Trim().ToUpper().Equals("TRUE") ? true : false),
                InstPriceSource = tlog.PriceSource,
                ExclusionTypeId = (int)tlog.ExclusionTypeId,
                PosFacilityId = postxn.FacilityId,
                PosTransactionDate = postxn.TransactionDate,
                PosTransactionTM = postxn.TransactionTM,
                PosTransactionNumber = postxn.TransactionNumber,
                PosItemId = postxn.ItemId,
                PosGTIN = postxn.GTINCheckDigit,
                PosItemName = postxn.ItemName,
                PosSalesVolume = postxn.SalesVolume,
                PosSalesVolumeIndicator = postxn.VolumeIndicator,
                PosSalesAmount = postxn.SalesAmount,
                PosTotalTax = postxn.TotalTax,
                PosTotalSalesIncludingTax = postxn.TotalSalesIncludingTax,
                PosTaxPlan1Tax = postxn.TaxPlan1Tax,
                PosTaxPlan1TaxPlan2Tax = postxn.TaxPlan1TaxPlan2Tax,
                PosTaxPlan3TaxPlan2Tax = postxn.TaxPlan3TaxPlan2Tax,
                PosTaxPlan3Tax = postxn.TaxPlan3Tax,
                PosIsAlcohol = postxn.Alcoholflag,
                MapCriteriaId = mapcriteria,
                LastUpdatedBy = Environment.UserName,
                LastUpdatedDate = DateTime.Now
            };

            return result;
        }

        internal static List<InstTLogDTO> GroupTLogOrders(List<InstTLogDTO> tlogsForOrder)
        {
            var tlogItems = new List<InstTLogDTO>();

            if (tlogsForOrder.Any())
            {
                var itemids = tlogsForOrder.Where(i => i.ReferenceCode != 0).GroupBy(t => t.ReferenceCode).Where(grp => grp.Count() > 1).Select(g => g.Key);
                tlogItems = tlogsForOrder.Where(t => !itemids.Any(i => i == t.ReferenceCode)).ToList(); // Select items which are not grouped

                if (itemids.Any())
                {
                    var tloggrpItems = tlogsForOrder.Where(t => itemids.Any(i => i == t.ReferenceCode))
                                                    .GroupBy(g => new { g.OrderId, g.DeliveryId, g.StoreLocation, g.ReferenceCode, g.GTIN, g.ItemName, g.OrderedDateTimeEST, g.DeliveryDateTimeEST, g.Unit, g.IsAlcoholic },
                                                    (key, grp) => new InstTLogDTO
                                                    {
                                                        OrderId = key.OrderId,
                                                        DeliveryId = key.DeliveryId,
                                                        OrderedDateTimeEST = key.OrderedDateTimeEST,
                                                        DeliveryDateTimeEST = key.DeliveryDateTimeEST,
                                                        StoreLocation = key.StoreLocation,
                                                        ReferenceCode = key.ReferenceCode,
                                                        Unit = key.Unit,
                                                        GTIN = key.GTIN,
                                                        ItemName = key.ItemName,
                                                        IsAlcoholic = key.IsAlcoholic,
                                                        Qty = grp.Sum(i => i.Qty),
                                                        InstOnlinePrice = grp.Average(i => i.InstOnlinePrice),
                                                        InstOnlineRevenue = grp.Sum(i => i.InstOnlineRevenue),
                                                        SalesTax = grp.Sum(i => i.SalesTax),
                                                        BottleDeposit = grp.Sum(i => i.BottleDeposit),
                                                        GMV = grp.Sum(i => i.GMV)
                                                    }).ToList();
                    tlogItems.AddRange(tloggrpItems);
                }
            }
            return tlogItems;
        }

        internal static List<PosLineItemTransactionDTO> GroupPosLineItemTransaction(List<PosLineItemTransactionDTO> posTxnsForOrder)
        {
            var result = new List<PosLineItemTransactionDTO>();

            if (posTxnsForOrder != null && posTxnsForOrder.Any())
            {
                ApplyItemExclusion.ExcludePosItems(posTxnsForOrder);     // Exclude Non-Merchandie & SushiChinese Items

                var exclusionTxns = posTxnsForOrder.Where(txn => txn.ExclusionType != ExclusionTypeEnum.None).ToList();

                result = posTxnsForOrder.Where(txn => txn.ExclusionType == ExclusionTypeEnum.None)
                                    .GroupBy(p => new { p.ItemId, p.GTIN, p.GTINCheckDigit, p.FacilityId, p.TransactionDate, p.TransactionNumber, p.TransactionTM },
                                     (key, grp) => new PosLineItemTransactionDTO
                                     {
                                         FacilityId = key.FacilityId,
                                         TransactionDate = key.TransactionDate,
                                         TransactionTM = key.TransactionTM,
                                         TransactionNumber = key.TransactionNumber,
                                         ItemId = key.ItemId,
                                         GTIN = key.GTIN,
                                         GTINCheckDigit = key.GTINCheckDigit,
                                         SalesVolume = grp.Sum(i => i.SalesVolume),
                                         SalesAmount = grp.Sum(i => i.SalesAmount),
                                         TotalTax = grp.Sum(i => i.TotalTax),
                                         BottleDeposit = grp.Sum(i => i.BottleDeposit),
                                         TotalSalesIncludingTax = grp.Sum(i => i.TotalSalesIncludingTax),
                                         TaxableAmount = grp.Sum(i => i.TaxableAmount),
                                         NonTaxableSales = grp.Sum(i => i.NonTaxableSales),
                                         TaxableAlcoholSales = grp.Sum(i => i.TaxableAlcoholSales),
                                         TaxableNonAlcoholSales = grp.Sum(i => i.TaxableNonAlcoholSales),
                                         NonTaxableAlcoholSales = grp.Sum(i => i.NonTaxableAlcoholSales),
                                         NonTaxableNonAlcoholSales = grp.Sum(i => i.NonTaxableNonAlcoholSales),
                                         TaxPlan1Amount = grp.Sum(i => i.TaxPlan1Amount),
                                         TaxPlan2Amount = grp.Sum(i => i.TaxPlan2Amount),
                                         TaxPlan3Amount = grp.Sum(i => i.TaxPlan3Amount),
                                         TaxPlan1Tax = grp.Sum(i => i.TaxPlan1Tax),
                                         TaxPlan1TaxPlan2Tax = grp.Sum(i => i.TaxPlan1TaxPlan2Tax),
                                         TaxPlan3TaxPlan2Tax = grp.Sum(i => i.TaxPlan3TaxPlan2Tax),
                                         TaxPlan3Tax = grp.Sum(i => i.TaxPlan3Tax)
                                     }).ToList();



                foreach (var txn in result)
                {

                    var key = posTxnsForOrder.FirstOrDefault(t => t.FacilityId == txn.FacilityId &&
                                                                  t.TransactionDate == txn.TransactionDate &&
                                                                  t.TransactionTM == txn.TransactionTM &&
                                                                  t.TransactionNumber == txn.TransactionNumber &&
                                                                  t.ItemId == txn.ItemId &&
                                                                  t.LineNumber != 0
                                                             );
                    txn.ItemName = key.ItemName;
                    txn.TaxPlan1 = key.TaxPlan1;
                    txn.TaxPlan2 = key.TaxPlan2;
                    txn.TaxPlan3 = key.TaxPlan3;
                    txn.Alcoholflag = key.Alcoholflag;
                    txn.VolumeIndicator = key.VolumeIndicator;
                    txn.SalesType = key.SalesType;
                }

                if (exclusionTxns != null && exclusionTxns.Count > 0)
                    result.AddRange(exclusionTxns);
            }

            return result;
        }

        internal static async Task InsertMappedOrderItemDetails()
        {
            var transOptions = new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted, Timeout = TransactionManager.MaximumTimeout };
            using (var scope = new TransactionScope(TransactionScopeOption.Required, transOptions, TransactionScopeAsyncFlowOption.Enabled))
            {
                logBO.Info(_jobname + "- Insert Map Log - Start");
                await _dac.BulkCopy(MapTLogPosAbstract.MapLog.DequeueItems(0), new MapLogDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgMapLog);
                await _dac.MoveStgMapLogToMain();
                await _dac.TruncateTable(Constants.BulkCopyTables.StgMapLog);
                logBO.Info(_jobname + "- Insert Map Log - End");


                logBO.Info(_jobname + "- Insert Order Item Map  - Start");
                await _dac.BulkCopy(MapTLogPosAbstract.MappedPosInstOrderItems.DequeueItems(0), new PosInstOrderItemMapDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgPosInstOrderItemMap);
                await _dac.MoveMappedOrderItemsStagingToMain(MapLevelEnum.ITMAP.ToString(), MapLevelEnum.TMPIT.ToString());
                logBO.Info(_jobname + "- Insert Order Item Map - End");


                logBO.Info(_jobname + "- Insert Order Summary - Start");
                await _dac.DeleteOrderSummaryByOrderId();
                await _dac.BulkCopy(MapTLogPosAbstract.SummaryPosInstOrders.DequeueItems(0), new PosInstOrderSummaryDTO().GetPropertyMembers(), Constants.BulkCopyTables.PosInstOrderSummary);
                await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderItemMap);
                logBO.Info(_jobname + "- Insert Order Summary - End");

                scope.Complete();
            }
        }


        #region "Private Methods"
        protected static decimal CalculateTaxPlanAmount(decimal taxgapTotalTax, string taxplanType, int storenumber)
        {
            var result = default(decimal);
            var currentdate = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));

            var storeTaxRate = StoreTaxRates.FirstOrDefault(s => s.StoreNumber == storenumber && (currentdate >= s.EffectiveDate && currentdate <= s.TerminationDate));

            if (storeTaxRate == null) return result;

            result = CalculateAmount(taxgapTotalTax, taxplanType, storeTaxRate);
            return result;
        }

        static decimal CalculateAmount(decimal taxgapTotalTax, string taxplanType, StoreTaxRateDTO storeTaxRate)
        {
            var result = default(decimal);

            switch (taxplanType)
            {
                case "TaxPlan1":
                    {
                        result = storeTaxRate.TaxPlan1 > 0 ? Math.Round(taxgapTotalTax / (storeTaxRate.TaxPlan1 / 100), 2) : 0;
                        break;
                    }
                case "TaxPlan1TaxPlan2":
                    {
                        result = storeTaxRate.TaxPlan1 + storeTaxRate.TaxPlan2 > 0 ? Math.Round(taxgapTotalTax / ((storeTaxRate.TaxPlan1 + storeTaxRate.TaxPlan2) / 100), 2) : 0;
                        break;
                    }
                case "TaxPlan3TaxPlan2":
                    {
                        result = storeTaxRate.TaxPlan3 + storeTaxRate.TaxPlan2 > 0 ? Math.Round(taxgapTotalTax / ((storeTaxRate.TaxPlan3 + storeTaxRate.TaxPlan2) / 100), 2) : 0;
                        break;
                    }
                case "TaxPlan3":
                    {
                        result = storeTaxRate.TaxPlan3 > 0 ? Math.Round(taxgapTotalTax / (storeTaxRate.TaxPlan3 / 100), 2) : 0;
                        break;
                    }

                default:
                    throw new Exception("Unexpected Case");
            }

            return result;
        }
        #endregion

    }
}
