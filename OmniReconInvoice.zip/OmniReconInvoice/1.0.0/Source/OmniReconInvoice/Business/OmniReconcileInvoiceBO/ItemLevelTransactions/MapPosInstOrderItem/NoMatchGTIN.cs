﻿using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class NoMatchGTIN : MapTLogPosAbstract
    {
        public NoMatchGTIN(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<PosInstOrderItemMapDTO> MapTlogPosItems(List<PosLineItemTransactionDTO> postxns, InstTLogDTO tlogRecord, IEnumerable<InstCreditReturnsDTO> creditreturnitems, IEnumerable<InstFeedDiscrepancyDTO> discrepancies)
        {
            tlogRecord.IsTlogMapped = false;
            MapLog.LogOrderMap(tlogRecord, MapLogReasonEnum.NoMapFoundTLogGTIN, MapLogTypeEnum.TLog, MapLevelEnum.ITMAP, MapLogSeverityEnum.Warning);
            return await Task.FromResult(MapPosInstItem(new PosLineItemTransactionDTO(), tlogRecord, (int)MapCriteriaEnum.NoMapFoundGTIN));
        }
    }
}