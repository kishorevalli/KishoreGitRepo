﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    class AdjInstPriceWhenLessThanPos : AdjustmentAbstract
    {
        public AdjInstPriceWhenLessThanPos(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override void AdjustPosInstItems(PosLineItemTransactionDTO postxn, InstTLogDTO tlogRecord, PosInstOrderItemMapDTO mappeditem, InstFeedDiscrepancyDTO discrepancy)
        {
            if (discrepancy != null)
            {
                var feedprice = discrepancy.FeedMarkUpSalePriceRounded != 0 ? discrepancy.FeedMarkUpSalePriceRounded : discrepancy.FeedMarkUpPriceRounded;

                // Adjust price discrepancy only if spread is not in acceptable range.
                if (mappeditem.InstOnlinePrice < feedprice)     //&& mappeditem.ExclusionTypeId == (int)ExclusionTypeEnum.SpreadNotInRange
                {
                    var liveDateToAdjSalesTax = SystemValues.GetValue<DateTime>(Constants.SystemValues.LiveDateToAdjustSalesTax);


                    var bogoVariance = 0.03m;
                    var calculatedBogoRevenue = Math.Round(((tlogRecord.Qty * feedprice) / 2), 2, MidpointRounding.AwayFromZero);

                    mappeditem.InstAdjOnlinePrice = feedprice;

                    if (tlogRecord.InstOnlineRevenue <= (calculatedBogoRevenue - bogoVariance) && tlogRecord.GMV != 0 &&
                        discrepancy.FeedBogo.Trim().ToUpper().Equals("TRUE"))
                    {
                        mappeditem.InstAdjOnlineRevenue = (mappeditem.InstQty / 2) * mappeditem.InstAdjOnlinePrice;
                    }
                    else
                    {
                        mappeditem.InstAdjOnlineRevenue = mappeditem.InstQty * mappeditem.InstAdjOnlinePrice;
                    }

                    if (postxn.TransactionDate >= liveDateToAdjSalesTax)
                    {
                        mappeditem.InstAdjSalesTax = Math.Round((mappeditem.InstAdjOnlineRevenue * (GetTaxRateForStore(postxn) / 100)), 2, MidpointRounding.AwayFromZero);
                    }


                    mappeditem.InstAdjGMV = mappeditem.InstAdjOnlineRevenue + mappeditem.InstAdjSalesTax;
                    mappeditem.ExclusionTypeId = (int)ExclusionTypeEnum.None;

                    // Recalcualte spread.
                    TaxSpreadCalculation.ApplyRules(postxn, mappeditem);
                    MapTLogPosAbstract.MapLog.LogOrderMap(postxn, tlogRecord, discrepancy, MapLogReasonEnum.InstPriceAdjWhenLessThanPos, MapLogTypeEnum.PosInstItemMap, MapLevelEnum.ITMAP, MapLogSeverityEnum.Exception);
                }
            }
            else if (mappeditem.ExclusionTypeId == (int)ExclusionTypeEnum.SpreadNotInRange)
            {
                // If there is no price discrepancy, but still spread not in range.  We Accept the -Ve & lower spread.
                // This might due to price changes by ordered date vs delivery date (for Wednesday/ thursday store)

                mappeditem.ExclusionTypeId = (int)ExclusionTypeEnum.None;
            }

        }
    }
}
