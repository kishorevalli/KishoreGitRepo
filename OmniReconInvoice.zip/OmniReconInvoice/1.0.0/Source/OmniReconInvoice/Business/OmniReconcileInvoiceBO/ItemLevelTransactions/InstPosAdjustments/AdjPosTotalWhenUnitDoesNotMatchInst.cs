﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    class AdjPosPriceWhenUnitDoesNotMatchInst : AdjustmentAbstract
    {
        public AdjPosPriceWhenUnitDoesNotMatchInst(IMapPosInstOrderItemDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override void AdjustPosInstItems(PosLineItemTransactionDTO postxn, InstTLogDTO tlogRecord, PosInstOrderItemMapDTO mappeditem, InstFeedDiscrepancyDTO discrepancy)
        {
            if (!mappeditem.InstUnit.ToUpper().Equals(mappeditem.PosSalesVolumeIndicator.ToUpper()))
            {
                if (discrepancy != null)
                {
                    var feedprice = discrepancy.FeedMarkUpSalePriceRounded != 0 ? discrepancy.FeedMarkUpSalePriceRounded : discrepancy.FeedMarkUpPriceRounded;

                    mappeditem.PosAdjSalesVolume = mappeditem.InstAdjQty;
                    mappeditem.PosAdjSalesAmount = Math.Round(feedprice * mappeditem.PosAdjSalesVolume, 2, MidpointRounding.AwayFromZero);
                    mappeditem.PosAdjTotalTax = Math.Round((mappeditem.PosAdjSalesAmount * GetTaxRateForStore(postxn)) / 100, 2, MidpointRounding.AwayFromZero);
                    mappeditem.PosTotalSalesIncludingTax = mappeditem.PosAdjSalesAmount + mappeditem.PosAdjTotalTax;

                    // MapTLogPosAbstract.MapLog.LogOrderMap(postxn, tlogRecord, discrepancy, MapLogReasonEnum., MapLogTypeEnum.PosInstItemMap.ToString(), MapLevelEnum.I.ToString(), MapLogSeverityEnum.Exception.ToString());
                }
            }

        }
    }
}
