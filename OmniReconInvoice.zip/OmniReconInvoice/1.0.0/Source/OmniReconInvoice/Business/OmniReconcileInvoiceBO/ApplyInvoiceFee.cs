﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Transactions;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class ApplyInvoiceFee : Common, IApplyInvoiceFee
    {
        readonly IApplyInvoiceFeeDac _dac;

        public ApplyInvoiceFee(IApplyInvoiceFeeDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public async Task ApplyFeeRules()
        {
            var transOptions = new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted, Timeout = TransactionManager.MaximumTimeout };

            await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderInvoice);

            logBO.Info(jobname + "- Get GetInvoiceFeeRate, GetInvoiceDataByWeeks - Start");

            var invoicefeerates = await _dac.GetInvoiceFeeRate(MapLevelEnum.INVCP.ToString());
            var invoicedata = await _dac.GetInvoiceDataByWeeks(MapLevelEnum.INVCP.ToString());


            logBO.Info(jobname + "- Get GetInvoiceFeeRate, GetInvoiceDataByWeeks - End");

            logBO.Info(jobname + "- Apply Invoice Fee Rates to the orders and calculate fee - Start");
            AggregatedInvoiceOrder.BuildRules();
            foreach (var inv in invoicedata)
            {
                var feerate = invoicefeerates.FirstOrDefault(i => i.State.Trim().ToUpper().Equals(inv.State.Trim().ToUpper()) &&
                                                                  (inv.PosTransactionDate >= i.WeekStart && inv.PosTransactionDate <= i.WeekEnd)
                                                            );

                if (feerate != null)
                {
                    AggregatedInvoiceOrder.ApplyFeeRules(inv, feerate);
                    inv.InvoiceFeeRateId = feerate.InvoiceFeeRateId;
                }

            }
            logBO.Info(jobname + "- Apply Invoice Fee Rates to the orders and calculate fee - End");


            logBO.Info(jobname + "- Update the Invoice Fee rates - Start");
            using (var scope = new TransactionScope(TransactionScopeOption.Required, transOptions, TransactionScopeAsyncFlowOption.Enabled))
            {
                await _dac.BulkCopy(invoicedata, new PosInstOrderInvoiceDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgPosInstOrderInvoice);
                await _dac.UpdateInvoiceOrdersFeeDetails(MapLevelEnum.INVCP.ToString(), MapLevelEnum.FEECP.ToString());
                await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderInvoice);
                scope.Complete();
            }
            logBO.Info(jobname + "- Update the Invoice Fee rates - End");

        }
    }
}
