﻿using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class AggregatedInvoiceOrder : Common
    {
        public AggregatedInvoiceOrder(ICommonDac dac, string jobname) : base(dac, jobname)
        {
        }

        public delegate void InvoiceFee(PosInstOrderInvoiceDTO order, InvoiceFeeRateDTO feerate);

        public static List<InvoiceFee> FeeRules { get; set; }


        public static void FeeForNonAlcoholMerchandiseItems(PosInstOrderInvoiceDTO order, InvoiceFeeRateDTO feerate)
        {
            var store = Stores.FirstOrDefault(s => s.StoreNumber == order.PosStoreNumber);
            if (store != null)
            {
                order.FeePercentage = store.MarkupPercent - feerate.MarkupPercentDiscount;
                order.CalculateNonAlcoholFee = Math.Round((store.MarkupPercent * order.QualifiedPosNonAlcoholSales) / 100, 2, MidpointRounding.AwayFromZero);
            }

        }

        public static void FeeForAlcoholPurcahse(PosInstOrderInvoiceDTO order, InvoiceFeeRateDTO feerate)
        {
            order.FlatAlcoholFee = feerate.FlatAlcoholFee - feerate.FlatAlcoholFeeDiscount;
        }



        public static void BuildRules()
        {
            FeeRules = new List<InvoiceFee>();
            FeeRules.Add(FeeForNonAlcoholMerchandiseItems);
            FeeRules.Add(FeeForAlcoholPurcahse);
        }

        public static void ApplyFeeRules(PosInstOrderInvoiceDTO invoiceorder, InvoiceFeeRateDTO feerate)
        {
            foreach (var rule in FeeRules)
            {
                rule(invoiceorder, feerate);
            }

            invoiceorder.TotalFee = invoiceorder.CalculateNonAlcoholFee + invoiceorder.FlatAlcoholFee;
        }
    }
}
