﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class MatchInstItemDataByItem : DiscrepancyAbstract
    {
        public MatchInstItemDataByItem(IOrderDiscrepanciesDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task MatchInstItemData(InstTLogDTO request)
        {
            var itemid = 0;

            ItemDataHistoryDTO history = null;
            var loaddate = ((DateTime)request.OrderedDateTimeEST).AddDays(-1).Date;


            if (request.GTIN.IsType2Upc())
                itemid = request.GTIN.ItemIdForType2();
            else if (request.ReferenceCode != 0)
                itemid = request.ReferenceCode;

            if (itemid != 0 && ItemDataHistory != null && ItemDataHistory.Count() > 0)
            {
                history = ItemDataHistory.FirstOrDefault(i => i.RETAILER_REFERENCE_CODE == request.ReferenceCode
                                                              && i.ITEM_LOAD_DATE == loaddate);

                if (history != null && history.RETAILER_REFERENCE_CODE != 0)
                    DiscrepancyRules.Validate(request, history, (int)MapCriteriaEnum.MatchInstItemDataByItem);
                else
                    await nextmatchScenario.MatchInstItemData(request);
            }
            else
                await nextmatchScenario.MatchInstItemData(request);
        }
    }
}
