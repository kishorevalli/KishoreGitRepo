﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public abstract class DiscrepancyRules : DiscrepancyAbstract
    {
        protected DiscrepancyRules(IOrderDiscrepanciesDac dac, string jobname) : base(dac, jobname)
        {
        }

        public delegate bool DiscrepancyRule(InstTLogDTO tlog, ItemDataHistoryDTO history, ref string type);

        public static List<DiscrepancyRule> Rules { get; set; }

        public static void BuildRules()
        {
            Rules = new List<DiscrepancyRule>();
            Rules.Add(UnitPriceMismatch);
            Rules.Add(SalePriceMismatch);
            Rules.Add(AlcoholFlagMismatch);
            Rules.Add(BottleDepositMismatch);
            Rules.Add(NonBogoItemTlogRevenueMisMatch);
            Rules.Add(BogoItemTlogRevenueMisMatch);

        }

        public static void Validate(InstTLogDTO tlog, ItemDataHistoryDTO history, int mapcriteiraid)
        {
            var builder = new StringBuilder();
            foreach (var rule in Rules)
            {
                var str = string.Empty;
                if (!rule.Invoke(tlog, history, ref str))
                {
                    builder.Append(str);
                }
            }

            if (!string.IsNullOrEmpty(builder.ToString()))
            {
                var itemdata = new InstFeedDiscrepancyDTO
                {
                    InstOrderId = tlog.OrderId,
                    InstDeliveryId = tlog.DeliveryId,
                    InstOrderedDateEst = (DateTime)tlog.OrderedDateTimeEST,
                    InstDeliveredDateEst = (DateTime)tlog.DeliveryDateTimeEST,
                    InstStoreLocation = tlog.StoreLocation,
                    InstRefereneCode = tlog.ReferenceCode,
                    InstGTIN = tlog.GTIN,
                    InstUnit = tlog.Unit,
                    InstQty = tlog.Qty,
                    InstOnlinePrice = tlog.InstOnlinePrice,
                    InstOnlineRevenue = tlog.InstOnlineRevenue,
                    InstAlcoholFlag = tlog.IsAlcoholic.Trim(),
                    InstBottleDeposit = tlog.BottleDeposit,
                    InstPriceSource = tlog.PriceSource.Trim(),
                    FeedLoadDate = history.ITEM_LOAD_DATE,
                    FeedStoreNumber = history.STORE_IDENTIFIER,
                    FeedRRC = history.RETAILER_REFERENCE_CODE,
                    FeedScanCode = history.SCAN_CODE,
                    FeedCostUnit = history.COST_UNIT,
                    FeedAlcoholFlag = history.ALCOHOLIC,
                    FeedBogo = history.BOGO,
                    FeedBottleDeposit = history.BOTTLE_DEPOSIT,
                    FeedPromoStartDate = history.BOGO_START_DATE,
                    FeedPromoEndDate = history.BOGO_END_DATE,
                    FeedPromoGroupId = history.PROMOTION_GROUP_ID,
                    FeedUnitPrice = history.UNIT_RETAIL_PRICE,
                    FeedMarkUpPriceRounded = history.MARKUP_PRICE_ROUNDED,
                    FeedSalePrice = history.UNIT_SALE_PRICE,
                    FeedMarkUpSalePriceRounded = history.MARKUP_SALE_PRICE_ROUNDED,
                    LastUpdatedDate = DateTime.Now,
                    LastUpdatedBy = Environment.UserName,
                    Type = builder.ToString(),
                    MapCriteriaId = mapcriteiraid
                };

                DiscrepancyQueue.Enqueue(itemdata);
            }
        }

        public static bool UnitPriceMismatch(InstTLogDTO tlog, ItemDataHistoryDTO history, ref string type)
        {
            if ((tlog.InstOnlinePrice < history.MARKUP_PRICE_ROUNDED) && history.MARKUP_SALE_PRICE_ROUNDED == 0)
            {
                type = "UnitPrice;";
                return false;
            }
            return true;
        }
        public static bool SalePriceMismatch(InstTLogDTO tlog, ItemDataHistoryDTO history, ref string type)
        {
            if ((tlog.InstOnlinePrice < history.MARKUP_SALE_PRICE_ROUNDED) && history.MARKUP_SALE_PRICE_ROUNDED != 0)
            {
                type = "SalePrice;";
                return false;
            }
            return true;
        }

        public static bool AlcoholFlagMismatch(InstTLogDTO tlog, ItemDataHistoryDTO history, ref string type)
        {
            if (tlog.IsAlcoholic != null && (tlog.IsAlcoholic.ToUpper().Trim() != history.ALCOHOLIC.ToUpper().Trim()))
            {
                type = "AlcoholFlag;";
                return false;
            }
            return true;
        }
        public static bool BottleDepositMismatch(InstTLogDTO tlog, ItemDataHistoryDTO history, ref string type)
        {
            if (tlog.BottleDeposit != history.BOTTLE_DEPOSIT)
            {
                type = "BottleDeposit;";
                return false;
            }
            return true;
        }
        public static bool NonBogoItemTlogRevenueMisMatch(InstTLogDTO tlog, ItemDataHistoryDTO history, ref string type)
        {
            var variance = 0.02m;
            var calculatedNonBogoRevenue = Math.Round((tlog.Qty * tlog.InstOnlinePrice), 2, MidpointRounding.AwayFromZero);

            if (tlog.InstOnlineRevenue <= (calculatedNonBogoRevenue - variance) && tlog.GMV != 0 && history.BOGO.Trim().ToUpper().Equals("FALSE"))
            {
                type = "NonBogo-TlogRevenue;";
                return false;
            }
            return true;
        }
        public static bool BogoItemTlogRevenueMisMatch(InstTLogDTO tlog, ItemDataHistoryDTO history, ref string type)
        {
            var variance = 0.10m;
            var calculatedBogoRevenue = Math.Round(((tlog.Qty * tlog.InstOnlinePrice) / 2), 2, MidpointRounding.AwayFromZero);

            if (tlog.InstOnlineRevenue <= (calculatedBogoRevenue - variance) && tlog.GMV != 0 && history.BOGO.Trim().ToUpper().Equals("TRUE"))
            {
                type = "Bogo-TlogRevenue;";
                return false;
            }
            return true;
        }
    }
}
