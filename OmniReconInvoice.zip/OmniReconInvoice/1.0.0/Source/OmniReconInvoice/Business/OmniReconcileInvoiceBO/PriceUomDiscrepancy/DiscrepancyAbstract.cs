﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Collections.Concurrent;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public abstract class DiscrepancyAbstract : Common
    {
        protected IOrderDiscrepanciesDac _dac;
        protected DiscrepancyAbstract nextmatchScenario;

        public abstract Task MatchInstItemData(InstTLogDTO request);

        protected DiscrepancyAbstract(IOrderDiscrepanciesDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }


        public void SetNextMatchScenario(DiscrepancyAbstract nextMatch)
        {
            this.nextmatchScenario = nextMatch;
        }

        public static IEnumerable<ItemDataHistoryDTO> ItemDataHistory { get; set; }
        public static IDictionary<long, int> ItemGTIN { get; private set; }

        public static ConcurrentQueue<InstFeedDiscrepancyDTO> DiscrepancyQueue { get; set; }


        public static bool IsArchiveDate { get; set; }


        //public static void MapInstOrderItemData(InstTLogDTO tlog, ItemDataHistoryDTO history)
        //{
        //    var type = string.Empty;
        //    InstFeedDiscrepancyDTO itemdata = null;

        //    if (history != null)
        //    {
        //        //if ((tlog.InstOnlinePrice != history.MARKUP_PRICE_ROUNDED) && history.MARKUP_SALE_PRICE_ROUNDED == 0) type += "Unit Price;";
        //        //if ((tlog.InstOnlinePrice != history.MARKUP_SALE_PRICE_ROUNDED) && history.MARKUP_SALE_PRICE_ROUNDED != 0) type += "Sale Price;";
        //        ////if (tlog.Unit != null && (tlog.Unit.Substring(0, 2).ToUpper().Trim() != history.COST_UNIT.ToUpper().Trim())) type += "Cost Unit;";
        //        //if (tlog.Qty * tlog.InstOnlinePrice != tlog.InstOnlineRevenue && history.BOGO.Trim().ToUpper().Equals("FALSE")) type += "Less Revenue - Non Bogo Item;";
        //        //if (tlog.BottleDeposit != history.BOTTLE_DEPOSIT) type += "Bottle Deposit;";
        //        //if (tlog.IsAlcoholic != null && (tlog.IsAlcoholic.ToUpper().Trim() != history.ALCOHOLIC.ToUpper().Trim())) type += "Alcohol Flag;";

        //        //if (((tlog.InstOnlinePrice != history.MARKUP_PRICE_ROUNDED) && history.MARKUP_SALE_PRICE_ROUNDED == 0) ||
        //        //   ((tlog.InstOnlinePrice != history.MARKUP_SALE_PRICE_ROUNDED) && history.MARKUP_SALE_PRICE_ROUNDED != 0) ||
        //        //   //(tlog.Unit != null && (tlog.Unit.Substring(0, 2).ToUpper().Trim() != history.COST_UNIT.ToUpper().Trim())) ||
        //        //   (tlog.BottleDeposit != history.BOTTLE_DEPOSIT) ||
        //        //   (tlog.IsAlcoholic != null && (tlog.IsAlcoholic.ToUpper().Trim() != history.ALCOHOLIC.ToUpper().Trim()))
        //        //)
        //        //if (!DiscrepancyRules.ApplyRules(tlog, history))
        //        //{
        //        //    itemdata = new InstFeedDiscrepancyDTO
        //        //    {
        //        //        InstOrderId = tlog.OrderId,
        //        //        InstDeliveryId = tlog.DeliveryId,
        //        //        InstOrderedDateEst = (DateTime)tlog.OrderedDateTimeEST,
        //        //        InstDeliveredDateEst = (DateTime)tlog.DeliveryDateTimeEST,
        //        //        InstStoreLocation = tlog.StoreLocation,
        //        //        InstRefereneCode = tlog.ReferenceCode,
        //        //        InstGTIN = tlog.GTIN,
        //        //        InstUnit = tlog.Unit,
        //        //        InstQty = tlog.Qty,
        //        //        InstOnlinePrice = tlog.InstOnlinePrice,
        //        //        InstAlcoholFlag = tlog.IsAlcoholic.Trim(),
        //        //        InstBottleDeposit = tlog.BottleDeposit,
        //        //        InstPriceSource = tlog.PriceSource.Trim(),
        //        //        FeedLoadDate = history.ITEM_LOAD_DATE,
        //        //        FeedStoreNumber = history.STORE_IDENTIFIER,
        //        //        FeedRRC = history.RETAILER_REFERENCE_CODE,
        //        //        FeedScanCode = history.SCAN_CODE,
        //        //        FeedCostUnit = history.COST_UNIT,
        //        //        FeedAlcoholFlag = history.ALCOHOLIC,
        //        //        FeedBogo = history.BOGO,
        //        //        FeedBottleDeposit = history.BOTTLE_DEPOSIT,
        //        //        FeedPromoStartDate = history.BOGO_START_DATE,
        //        //        FeedPromoEndDate = history.BOGO_END_DATE,
        //        //        FeedPromoGroupId = history.PROMOTION_GROUP_ID,
        //        //        FeedUnitPrice = history.MARKUP_PRICE_ROUNDED,
        //        //        FeedSalePrice = history.MARKUP_SALE_PRICE_ROUNDED,
        //        //        LastUpdatedDate = DateTime.Now,
        //        //        LastUpdatedBy = Environment.UserName,
        //        //        Type = type
        //        //    };

        //        //    DiscrepancyQueue.Enqueue(itemdata);
        //        //}
        //    }

        //}

        internal async Task GetHistoryDataByStore(int storeid, DateTime loaddate)
        {

            var minhistorydate = SystemValues.GetValue<int>(Constants.SystemValues.MinHistoryDateForItemFeed);

            ItemDataHistory = await GetHistoryData(storeid, loaddate, minhistorydate);

            // if store data is not avialable, then below code is executed to get the data from another store with same market and state
            if (ItemDataHistory == null || ItemDataHistory.Count() == 0)
            {
                var storeidMarket = StoreMarket.FirstOrDefault(s => s.StoreNumber == storeid);

                var sameMarketSores = StoreMarket.Where(s => !string.IsNullOrEmpty(s.Market) &&
                                                             s.Market.Trim().ToUpper().Equals(storeidMarket.Market.Trim().ToUpper()) &&
                                                             s.State.Trim().ToUpper().Equals(storeidMarket.State.Trim().ToUpper()) &&
                                                             s.SalesDay == storeidMarket.SalesDay
                                                        );

                foreach (var str in sameMarketSores)
                {
                    ItemDataHistory = await GetHistoryData(str.StoreNumber, loaddate, minhistorydate);

                    if (ItemDataHistory != null && ItemDataHistory.Count() > 0)
                    {
                        break;
                    }
                }

            }
        }

        private async Task<IEnumerable<ItemDataHistoryDTO>> GetHistoryData(int storeid, DateTime loaddate, int minhistorydate)
        {
            if (loaddate.Date < DateTime.Now.AddDays(-minhistorydate).Date)
            {
                IsArchiveDate = true;
                return await _dac.GetHistoryDataByStoreFromArchive(storeid, loaddate);
            }
            else
            {
                IsArchiveDate = false;
                return await _dac.GetHistoryDataByStore(storeid, loaddate);
            }
        }

        internal async Task Initialize()
        {
            ItemGTIN = await _dac.GetItemGTIN();
            DiscrepancyQueue = new ConcurrentQueue<InstFeedDiscrepancyDTO>();
            DiscrepancyRules.BuildRules();
        }

    }
}
