﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class MatchInstItemDataByItemGTINScanCode : DiscrepancyAbstract
    {
        public MatchInstItemDataByItemGTINScanCode(IOrderDiscrepanciesDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task MatchInstItemData(InstTLogDTO request)
        {
            ItemDataHistoryDTO history = null;
            var loaddate = ((DateTime)request.OrderedDateTimeEST).AddDays(-1).Date;

            if (request.GTIN != 0 && ItemDataHistory != null && ItemDataHistory.Count() > 0)
            {
                var itemId = ItemGTIN.FirstOrDefault(i => i.Key == request.GTIN).Value;
                history = ItemDataHistory.FirstOrDefault(h => h.RETAILER_REFERENCE_CODE == itemId
                                                                 && h.ITEM_LOAD_DATE == loaddate);

                if (history != null && history.RETAILER_REFERENCE_CODE != 0)
                    DiscrepancyRules.Validate(request, history, (int)MapCriteriaEnum.MatchInstItemDataByItemGTINScanCode);
                else
                    await nextmatchScenario.MatchInstItemData(request);
            }
            else
                await nextmatchScenario.MatchInstItemData(request);
        }
    }
}
