﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class MatchInstItemDataByScanCode : DiscrepancyAbstract
    {
        public MatchInstItemDataByScanCode(IOrderDiscrepanciesDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task MatchInstItemData(InstTLogDTO request)
        {
            ItemDataHistoryDTO history = null;
            var loaddate = ((DateTime)request.OrderedDateTimeEST).AddDays(-1).Date;

            if (request.GTIN != 0 && !request.GTIN.IsType2Upc() && ItemDataHistory != null && ItemDataHistory.Count() > 0)
            {
                history = ItemDataHistory.FirstOrDefault(h => h.SCAN_CODE == request.GTIN
                                                                && h.ITEM_LOAD_DATE == loaddate);
                if (history != null && history.RETAILER_REFERENCE_CODE != 0)
                    DiscrepancyRules.Validate(request, history, (int)MapCriteriaEnum.MatchInstItemDataByScanCode);
                else
                    await nextmatchScenario.MatchInstItemData(request);
            }
            else
                await nextmatchScenario.MatchInstItemData(request);
        }
    }
}
