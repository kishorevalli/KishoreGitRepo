﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class MatchInstItemDataByItemGTINMarketScanCode : DiscrepancyAbstract
    {
        public MatchInstItemDataByItemGTINMarketScanCode(IOrderDiscrepanciesDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task MatchInstItemData(InstTLogDTO request)
        {
            ItemDataHistoryDTO history = null;
            var loaddate = ((DateTime)request.OrderedDateTimeEST).AddDays(-1).Date;

            if (request.GTIN != 0)
            {
                // Logic to get the history -- can be improvised further.
                if (IsArchiveDate)
                    history = await _dac.GetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCode(loaddate, request.StoreLocation, request.GTIN, IsArchiveDate);
                else
                    history = await _dac.GetPriceUomDisrecpancyFromHistoryByItemGTINMarketScanCode(loaddate, request.StoreLocation, request.GTIN);


                //if (history != null && history.RETAILER_REFERENCE_CODE != 0)
                //    logBO.Info(jobname + "- MatchInstItemDataByItemGTINMarketScanCode OrderId:" + request.OrderId + " loadate:" + loaddate + " storelocation: " + request.StoreLocation + " GTIN:" + request.GTIN + " Archive:" + IsArchiveDate + " History Store" + history.STORE_IDENTIFIER);

                //else
                //    logBO.Info(jobname + "- MatchInstItemDataByItemGTINMarketScanCode OrderId:" + request.OrderId + " loadate:" + loaddate + " storelocation: " + request.StoreLocation + " GTIN:" + request.GTIN + " Archive:" + IsArchiveDate);




                if (history != null && history.RETAILER_REFERENCE_CODE != 0)
                    DiscrepancyRules.Validate(request, history, (int)MapCriteriaEnum.MatchInstItemDataByItemGTINMarketScanCode);
            }
        }
    }
}
