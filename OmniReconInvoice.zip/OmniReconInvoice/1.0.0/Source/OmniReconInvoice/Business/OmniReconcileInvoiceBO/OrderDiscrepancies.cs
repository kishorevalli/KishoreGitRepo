﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;
using System.Collections.Concurrent;
using System.Data.SqlTypes;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class OrderDiscrepancies : Common, IOrderDiscrepancies
    {
        readonly IOrderDiscrepanciesDac _dac;


        public OrderDiscrepancies(IOrderDiscrepanciesDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }
        public async Task CheckDiscrepancies()
        {

            var maxparallelism = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismForMapOLogTLogToPos);
            DiscrepancyAbstract mapInstItemDataByScanCode = new MatchInstItemDataByScanCode(_dac, jobname);
            DiscrepancyAbstract mapInstItemDataByItem = new MatchInstItemDataByItem(_dac, jobname);
            DiscrepancyAbstract mapInstItemDataByItemGTINScanCode = new MatchInstItemDataByItemGTINScanCode(_dac, jobname);
            DiscrepancyAbstract mapInstItemDataByItemGTINMarketScanCode = new MatchInstItemDataByItemGTINMarketScanCode(_dac, jobname);

            mapInstItemDataByScanCode.SetNextMatchScenario(mapInstItemDataByItem);
            mapInstItemDataByItem.SetNextMatchScenario(mapInstItemDataByItemGTINScanCode);
            mapInstItemDataByItemGTINScanCode.SetNextMatchScenario(mapInstItemDataByItemGTINMarketScanCode);

            try
            {
                await _dac.TruncateTable(Constants.BulkCopyTables.StgInstFeedDiscrepancy);

                logBO.Info(jobname + "- Load Mapped Orders & ItemGTIN - Start");
                var ordersTsk = _dac.GetMappedOrdersForDiscrepancy(MapLevelEnum.ORDMP.ToString());
                var tsk = mapInstItemDataByScanCode.Initialize();

                Task.WaitAll(ordersTsk, tsk);
                logBO.Info(jobname + "- Load Mapped Orders & ItemGTIN - End");

                var orders = ordersTsk.Result;


                if (orders != null)
                {
                    var distinctOrderedDates = orders.Select(o => o.OrderedDate).Distinct();
                    logBO.Info(jobname + "- Run Discreapancy Check for Orders - Start");

                    foreach (var dt in distinctOrderedDates)
                    {
                        var distinctStores = orders.Where(d => d.OrderedDate.Equals(dt)).Select(o => o.StoreNumber).Distinct().OrderBy(s => s);

                        foreach (var strId in distinctStores)
                        {
                            var strOrders = orders.Where(m => m.OrderedDate == dt && m.StoreNumber == strId).Select(o => new { o.OrderId, o.DeliveryId });

                            DiscrepancyAbstract.ItemDataHistory = null;  // Re Initialize the History Data For Store.
                            await mapInstItemDataByScanCode.GetHistoryDataByStore(strId, dt.AddDays(-1).Date);

                            if (DiscrepancyAbstract.ItemDataHistory != null && DiscrepancyAbstract.ItemDataHistory.Count() > 0)
                            {
                                Parallel.ForEach(strOrders, new ParallelOptions { MaxDegreeOfParallelism = maxparallelism },
                                ord =>
                                {
                                    var tlogitemsforOrder = _dac.GetTLogOrderItems(ord.OrderId, ord.DeliveryId).Result;
                                    if (tlogitemsforOrder != null && tlogitemsforOrder.Count > 0)
                                    {
                                        foreach (var item in tlogitemsforOrder)
                                        {
                                            mapInstItemDataByScanCode.MatchInstItemData(item).Wait();
                                        }
                                    }
                                });
                            }
                        }

                        await _dac.BulkCopy(DiscrepancyAbstract.DiscrepancyQueue.DequeueItems(0), new InstFeedDiscrepancyDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgInstFeedDiscrepancy);
                        logBO.Info(jobname + "- Discreapancy Check for " + dt.ToString("yyyy - MM - dd") + " OrderedDate - Complete ");
                    }

                    logBO.Info(jobname + "- Run Discreapancy Check for Orders - End");
                }
            }
            catch (AggregateException ex)
            {
                foreach (var inrecep in ex.InnerExceptions)

                    logBO.Error(jobname + "- " + inrecep);

                throw;
            }

            logBO.Info(jobname + "- Bulk Load and Push Discrepancy Data - Start");
            await _dac.PushDiscrepancyDataStagingTomain();
            await _dac.UpdateMapLevelOnMappedOrders(MapLevelEnum.ORDMP.ToString(), MapLevelEnum.DISCP.ToString());
            await _dac.TruncateTable(Constants.BulkCopyTables.StgInstFeedDiscrepancy);

            logBO.Info(jobname + "- Bulk Load and Push Discrepancy Data - End");

        }
    }
}
