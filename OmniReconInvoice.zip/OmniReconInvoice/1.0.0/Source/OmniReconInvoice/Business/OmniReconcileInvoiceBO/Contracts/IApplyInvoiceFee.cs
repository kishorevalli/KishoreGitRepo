﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public interface IApplyInvoiceFee
    {
        Task ApplyFeeRules();
    }
}
