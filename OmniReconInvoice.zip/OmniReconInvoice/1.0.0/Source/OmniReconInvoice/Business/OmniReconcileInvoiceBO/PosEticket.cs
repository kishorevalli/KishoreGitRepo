﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceBusiness;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using IBM.WMQ;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;
using System.Transactions;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness

{
    public class PosEticket : Common, IPosEticket
    {
        readonly IPosEticketDac _dac;
        static DateTime tranmissionDateTime;


        public PosEticket(IPosEticketDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
            tranmissionDateTime = DateTime.Now;
        }

        public async Task ProcessEticket(string eTicketType)
        {
            switch (eTicketType)
            {
                case Constants.JobArgs.Generate:
                    {
                        await GenerateETicketData();
                        break;
                    }
                case Constants.JobArgs.Publish:
                    {
                        await RetreiveETickets();
                        break;
                    }

                default:
                    throw new Exception("Unexpected Case");
            }
        }

        async Task GenerateETicketData()
        {
            logBO.Info(jobname + "- Generate ETicket Data - Start");

            var transOptions = new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted, Timeout = TransactionManager.MaximumTimeout };
            var eticketsummary = new List<ETicketSummaryDTO>();
            var etickets = new List<ETicketDTO>();

            await _dac.TruncateTable(Constants.BulkCopyTables.StgETicketSummary);
            var eTicketEnabledStores = StoreMarket.Where(s => s.IsEticketEnabled);
            var eticketSummaryData = await _dac.GetETicketSummaryData();

            foreach (var str in eTicketEnabledStores)
            {
                var summary = eticketSummaryData.Where(t => t.StoreNumber == str.StoreNumber && t.TransactionDate.Date <= OmniExtensions.lastWeekEnd.Date).ToList();

                if (summary != null && summary.Count > 0)
                {
                    var tkt = summary.GroupBy(s => new { s.StoreNumber },
                                (key, grp) => new ETicketDTO
                                {
                                    StoreNumber = key.StoreNumber,
                                    FromTransactionDate = grp.Min(i => i.TransactionDate),
                                    ToTransactionDate = grp.Max(i => i.TransactionDate),
                                    TransmissionDate = DateTime.Now,
                                    NonTaxableSalesGap = grp.Sum(i => i.NonTaxableSalesGap),
                                    TaxableSalesGap = grp.Sum(i => i.TaxPlan1TaxableSalesGap),
                                    StateAndLocalTaxGap = grp.Sum(i => i.TaxPlan1TaxPlan2TaxableSalesGap),
                                    FoodAndLocalTaxGap = grp.Sum(i => i.TaxPlan3TaxPlan2TaxableSalesGap),
                                    FoodTaxGap = grp.Sum(i => i.TaxPlan3TaxableSalesGap),
                                    StateTax = grp.Sum(i => i.TaxPlan1TaxGap),
                                    StateAndLocalTax = grp.Sum(i => i.TaxPlan1TaxPlan2TaxGap),
                                    FoodAndLocalTax = grp.Sum(i => i.TaxPlan3TaxPlan2TaxGap),
                                    FoodTax = grp.Sum(i => i.TaxPlan3TaxGap),
                                    LastUpdatedBy = Environment.UserName,
                                    LastUpdatedDate = DateTime.Now
                                }).FirstOrDefault();

                    tkt.Id = Convert.ToInt64(string.Format("{0}{1}", DateTime.Now.ToString("yyMMddHHmm"), str.StoreNumber.ToString("0000")));

                    foreach (var itm in summary)
                    {
                        itm.PublishETicketId = tkt.Id;
                    }

                    etickets.Add(tkt);
                    eticketsummary.AddRange(summary);
                }
            }
            using (var scope = new TransactionScope(TransactionScopeOption.Required, transOptions, TransactionScopeAsyncFlowOption.Enabled))
            {

                await _dac.BulkCopy(eticketsummary, new ETicketSummaryDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgETicketSummary);
                await _dac.BulkCopy(etickets, new ETicketDTO().GetPropertyMembers(), Constants.BulkCopyTables.PublishETicket);
                await _dac.UpdateSummaryETicketId((int)ETicketStatusEnum.Generate);
                await _dac.TruncateTable(Constants.BulkCopyTables.StgETicketSummary);
            }
            logBO.Info(jobname + "- Generate ETicket Data - End");
        }

        public async Task RetreiveETickets()
        {

            var salestxn = await _dac.GetPosETicketData();
            if (salestxn != null && salestxn.Count() > 0)
            {
                await PublishETicket(salestxn);
                await _dac.PushPublishedETicketsToHistory((int)ETicketStatusEnum.Publish);
            }
            else
            {
                logBO.Info(jobname + "- There are NO E-Tickets to Publish ETicket");
            }

            logBO.Info(jobname + "- Generate " + " ETicket - End");

        }


        #region "Private Methods"
        async Task PublishETicket(IEnumerable<CreateSalesTransactionXML1> salestxn)
        {
            try
            {
                var mqManger = SystemParameters.GetValue(Constants.SystemParameters.POSEticketMQQueueManager);
                var mqQueue = SystemParameters.GetValue(Constants.SystemParameters.POSEticketMQQueue);

                logBO.Info(jobname + "- Connecting to MQ Manager " + mqManger);
                using (var queueManager = new MQQueueManager(mqManger))
                {
                    logBO.Info(jobname + "- Connection to MQ Manager " + mqManger + " Successful");


                    logBO.Info(jobname + "- Accessing to MQ Queue " + mqQueue);
                    var queue = queueManager.AccessQueue(mqQueue, MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING + MQC.MQOO_INQUIRE);
                    logBO.Info(jobname + "- Access to MQ Queue " + mqQueue + " Successful");


                    var pmo = new MQPutMessageOptions();// { Options = MQC.MQPMO_NEW_MSG_ID };   //+ MQC.MQPMO_SYNCPOINT 

                    foreach (var item in salestxn)
                    {
                        var message = new MQMessage { Format = MQC.MQFMT_STRING };


                        logBO.Info(jobname + "- Publish ETicket for Store " + item.StoreNumber + " - Start");

                        message.WriteString(item.SerializeToBytes());
                        queue.Put(message, pmo);

                        //logBO.Info(jobname + "- MessageId:" + message.MessageId.GetHexString());

                        logBO.Info(jobname + "- Publish ETicket for Store " + item.StoreNumber + " - End");

                        if (MQC.MQCC_OK != pmo.CompletionCode)
                        {
                            logBO.Error(jobname + "- MQQueue CompletionCode:" + pmo.CompletionCode + " - MQQueue ReasonCode:" + pmo.ReasonCode + " - MQQueue ReasonName:" + pmo.ReasonName);
                        }

                        logBO.Info(jobname + "- Update ETicket Xml for Store " + item.StoreNumber + " - Start");
                        await _dac.UpdatePosETicketDataXml(item.EticketId, item.Serialize(), message.MessageId.GetHexString(), DateTime.Now, Environment.UserName);
                        logBO.Info(jobname + "- Update ETicket Xml for Store " + item.StoreNumber + " - End");
                    }
                    //queueManager.Commit();
                }
            }
            catch (MQException mqEx)
            {
                logBO.Error(jobname + "- MQQueue CompletionCode:" + mqEx.CompletionCode + " - MQQueue ReasonCode:" + mqEx.ReasonCode + " - MQQueue ReasonName:" + mqEx.Reason);
                logBO.Error(jobname + "- MQException:" + mqEx);
                throw;
            }
        }
        #endregion
    }
}
