﻿using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public abstract class MapOrderPosAbstract : Common
    {
        protected MapOrderPosAbstract nextmatchScenario;
        protected int mapNearestMinutes = 3;
        protected IMapPosInstOrderDac _dac;
        public abstract Task<PosInstOrderMapDTO> MapOLogOrderAsync(InstOLogDTO request, List<PosTransactionDTO> posTransactions);

        protected MapOrderPosAbstract(IMapPosInstOrderDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public static IEnumerable<InstCreditReturnOrdersDTO> CreditReturns { get; set; }

        public static ConcurrentQueue<MapLogDTO> MapLog { get; set; }

        public void SetNextMatchScenario(MapOrderPosAbstract nextMatch)
        {
            this.nextmatchScenario = nextMatch;
        }

        protected static PosInstOrderMapDTO MapPosInstOrder(PosTransactionDTO posTrans, InstOLogDTO order, int mapcriteriaId)
        {
            var maporder = new PosInstOrderMapDTO();

            var deliverymodel = (posTrans == null ? StoreMarket.GetDeliveryModelForStore(order.StoreLocation) : StoreMarket.GetDeliveryModelForStore(posTrans.FacilityId));
            var fileversion = string.IsNullOrEmpty(order.FileVersionIndicator) ? string.Empty : order.FileVersionIndicator.Trim();


            if (posTrans == null)
            {
                maporder = new PosInstOrderMapDTO
                {
                    InstOrderId = order.OrderId,
                    InstDeliveryId = order.DeliveryId,
                    InstOlogStoreLocation = order.StoreLocation,
                    InstOlogTransactionDateTime = order.TransactionDateTime,
                    InstOlogTransactionDateEST = order.TransactionDateEST,
                    InstOlogTransactionDateTimeEST = order.TransactionDateTimeEST,
                    InstOlogTransactionAmt = order.TransactionAmt,
                    IsByPassCheckOut = false,
                    MapCriteriaId = mapcriteriaId,
                    ExclusionTypeId = (int)order.ExclusionType,
                    MapLevel = MapLevelEnum.UNMAP.ToString(),
                    LastUpdatedBy = Environment.UserName,
                    LastUpdatedDate = DateTime.Now
                };
            }
            else
            {
                maporder = new PosInstOrderMapDTO
                {
                    InstOrderId = order.OrderId,
                    InstDeliveryId = order.DeliveryId,
                    InstOlogStoreLocation = order.StoreLocation,
                    InstOlogTransactionDateTime = order.TransactionDateTime,
                    InstOlogTransactionDateEST = order.TransactionDateEST,
                    InstOlogTransactionDateTimeEST = order.TransactionDateTimeEST,
                    InstOlogTransactionAmt = order.TransactionAmt,
                    PosFacilityId = posTrans.FacilityId,
                    PosTransactionDate = posTrans.TransactionDate,
                    PosTransactionTM = posTrans.TransactionTM,
                    PosTransactionNumber = posTrans.TransactionNumber,
                    PosTransactionDateTime = posTrans.TransactionTime,
                    PosTenderAmount = posTrans.TenderAmount,
                    PosTotalSalesIncludingTax = posTrans.TotalSalesIncludingTax,
                    PosSalesBeforeTax = posTrans.SalesBeforeTax,
                    PosSalesTax = posTrans.SalesTax,
                    PosNonAlcoholSales = posTrans.NonAlcoholSales,
                    PosAlcoholSales = posTrans.AlcoholSales,
                    PosBottleDeposit = posTrans.BottleDeposit,
                    IsByPassCheckOut = false,
                    MapCriteriaId = mapcriteriaId,
                    ExclusionTypeId = (int)order.ExclusionType,
                    MapLevel = MapLevelEnum.ORDMP.ToString(),
                    LastUpdatedBy = Environment.UserName,
                    LastUpdatedDate = DateTime.Now

                };
            }

            return maporder;
        }

        public static Task<PosInstOrderMapDTO> MapBypassCheckoutOrders(PosTransactionDTO postxn)
        {
            Int64 orderId = Int64.TryParse(postxn.MaskedAccountString, out orderId) ? orderId : 0;

            if (postxn != null)
            {
                return Task.FromResult(new PosInstOrderMapDTO
                {
                    InstOrderId = orderId,
                    InstDeliveryId = 0,
                    PosFacilityId = postxn.FacilityId,
                    PosTransactionDate = postxn.TransactionDate,
                    PosTransactionTM = postxn.TransactionTM,
                    PosTransactionNumber = postxn.TransactionNumber,
                    PosTransactionDateTime = postxn.TransactionTime,
                    PosTenderAmount = postxn.TenderAmount,
                    PosTotalSalesIncludingTax = postxn.TotalSalesIncludingTax,
                    PosSalesBeforeTax = postxn.SalesBeforeTax,
                    PosSalesTax = postxn.SalesTax,
                    PosNonAlcoholSales = postxn.NonAlcoholSales,
                    PosAlcoholSales = postxn.AlcoholSales,
                    PosBottleDeposit = postxn.BottleDeposit,
                    IsByPassCheckOut = true,
                    LastUpdatedBy = Environment.UserName,
                    LastUpdatedDate = DateTime.Now,
                    MapCriteriaId = (int)MapCriteriaEnum.MaskedAccountString,
                    MapLevel = MapLevelEnum.ORDMP.ToString(),
                });
            }

            return null;
        }
    }
}