﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class Order : IntervalAbstract
    {
        static string orderIds;

        public Order(IMapPosInstOrderDac dac, string jobname, string _orderIds) : base(dac, jobname)
        {
            orderIds = _orderIds;
        }

        protected internal override async Task<List<PosTransactionDTO>> GetBypassCheckoutOrders()
        {
            logBO.Info(jobname + "- Get BypassCheckout Orders - Order - Start");
            var result = await _dac.GetBypassCheckoutOrders(orderIds);
            logBO.Info(jobname + "- Get BypassCheckout Orders - Order - End");

            return result;
        }

        protected internal override async Task<List<InstOLogDTO>> GetOlogOrdersToMap()
        {
            logBO.Info(jobname + "- Get OLog Orders - Orders - Start");
            var result = await _dac.GetOLogOrders(orderIds, MapLevelEnum.INVCP.ToString(), MapLevelEnum.FEECP.ToString());
            logBO.Info(jobname + "- Get OLog Orders - Orders - End");

            return result;
        }

        protected internal override Task LogUnmappedPos(DateTime minTxnDate, DateTime maxTxnDate)
        {
            return Task.FromResult(0);
        }
    }
}
