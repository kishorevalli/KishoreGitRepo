﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class DateRange : IntervalAbstract
    {
        static DateTime fromdate, todate;

        public DateRange(IMapPosInstOrderDac dac, string jobname, DateTime _fromdate, DateTime _todate) : base(dac, jobname)
        {
            fromdate = _fromdate;
            todate = _todate;
        }

        protected internal override async Task<List<PosTransactionDTO>> GetBypassCheckoutOrders()
        {
            logBO.Info(jobname + "- Get BypassCheckout Orders - DateRange - Start");
            var result = await _dac.GetBypassCheckoutOrders(fromdate, todate);
            logBO.Info(jobname + "- Get BypassCheckout Orders - DateRange - End");

            return result;
        }

        protected internal override async Task<List<InstOLogDTO>> GetOlogOrdersToMap()
        {
            var ologorders = new List<InstOLogDTO>();

            logBO.Info(jobname + "- Get Get OLog Orders & Get Unmapped Olog Orders from Recon - DateRange - Start");

            ologorders = await _dac.GetOLogOrders(fromdate, todate, MapLevelEnum.INVCP.ToString(), MapLevelEnum.FEECP.ToString());
            var unmappedOrders = await _dac.GetUnmappedOlogOrdersFromRecon(fromdate, todate, MapLevelEnum.UNMAP.ToString(), MapLogTypeEnum.OLog.ToString());

            if (ologorders != null && ologorders.Count > 0)
            {
                ologorders.AddRange(unmappedOrders);
            }
            else if (unmappedOrders != null && unmappedOrders.Count > 0)
            {
                ologorders = unmappedOrders;
            }

            logBO.Info(jobname + "- Get Get OLog Orders & Get Unmapped Olog Orders from Recon - DateRange - End");

            return ologorders;
        }

        protected internal override async Task LogUnmappedPos(DateTime minTxnDate, DateTime maxTxnDate)
        {
            logBO.Info(jobname + "- Log Unmapped Pos at Order Level - DateRange - Start");
            await _dac.LogUnmappedPosAtOrderLevel(minTxnDate, maxTxnDate, DateTime.Now, Environment.UserName, MapLogReasonEnum.UnMappedPos.ToString(), MapLogSeverityEnum.Warning.ToString(), MapLogTypeEnum.Pos.ToString(), MapLevelEnum.UNMAP.ToString());
            logBO.Info(jobname + "- Log Unmapped Pos at Order Level - DateRange - End");
        }
    }
}
