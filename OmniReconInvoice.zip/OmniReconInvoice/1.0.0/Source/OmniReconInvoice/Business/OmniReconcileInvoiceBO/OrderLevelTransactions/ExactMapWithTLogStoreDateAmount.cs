﻿using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class ExactMapWithTLogStoreDateAmount : MapOrderPosAbstract
    {
        public ExactMapWithTLogStoreDateAmount(IMapPosInstOrderDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<PosInstOrderMapDTO> MapOLogOrderAsync(InstOLogDTO request, List<PosTransactionDTO> posTransactions)
        {
            // TO DO take minutes from Syetem values
            var posTrans = posTransactions.Where(trans => trans.TransactionDate == request.TransactionDateEST &&
                                           trans.TenderAmount == request.TransactionAmt && !trans.IsPosMapped &&
                                           trans.FacilityId == request.TLogStoreLocation);

            if (posTrans == null || !posTrans.Any())
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);

            var posStoreState = StoreMarket.GetStateForStore(posTrans.FirstOrDefault().FacilityId);
            var ologStoreState = StoreMarket.GetStateForStore(request.StoreLocation);

            if (posTrans != null && posTrans.Count() == 1)//&& posStoreState == ologStoreState
            {

                var result = MapPosInstOrder(posTrans.FirstOrDefault(), request, (int)MapCriteriaEnum.MapWithDateTimeAmount);

                foreach (var trans in posTransactions)
                {
                    if (trans.TransactionDate == request.TransactionDateEST &&
                        trans.TenderAmount == request.TransactionAmt &&
                         trans.FacilityId == request.TLogStoreLocation)
                    {
                        trans.IsPosMapped = true;
                        break;
                    }
                }
                return result;
            }

            return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);
        }
    }
}