﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class ExactMapWithDateTimeAmountWithVariance : MapOrderPosAbstract
    {
        public ExactMapWithDateTimeAmountWithVariance(IMapPosInstOrderDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<PosInstOrderMapDTO> MapOLogOrderAsync(InstOLogDTO request, List<PosTransactionDTO> posTransactions)
        {
            // TO DO take minutes from Syetem values
            var posTrans = posTransactions.Where(trans => trans.TransactionDate == request.TransactionDateEST &&
                                                (trans.TransactionTime >= request.TransactionDateTimeEST.AddSeconds(-30) &&
                                                        trans.TransactionTime <= request.TransactionDateTimeEST.AddSeconds(30)) &&
                                           trans.TenderAmount == request.TransactionAmt && !trans.IsPosMapped);

            if (posTrans == null || !posTrans.Any())
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);

            var posStoreState = StoreMarket.GetStateForStore(posTrans.FirstOrDefault().FacilityId);
            var ologStoreState = StoreMarket.GetStateForStore(request.StoreLocation);

            if (posTrans != null && posTrans.Count() == 1) //&& posStoreState == ologStoreState
            {
                var result = MapPosInstOrder(posTrans.FirstOrDefault(), request, (int)MapCriteriaEnum.MapWithDateTimeAmount);

                foreach (var trans in posTransactions)
                {
                    if (trans.TransactionDate == request.TransactionDateEST &&
                    (trans.TransactionTime >= request.TransactionDateTimeEST.AddSeconds(-30) &&
                            trans.TransactionTime <= request.TransactionDateTimeEST.AddSeconds(30)) &&
                         trans.TenderAmount == request.TransactionAmt)
                    {
                        trans.IsPosMapped = true;
                        break;
                    }
                }

                return result;
            }

            return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);
        }
    }
}
