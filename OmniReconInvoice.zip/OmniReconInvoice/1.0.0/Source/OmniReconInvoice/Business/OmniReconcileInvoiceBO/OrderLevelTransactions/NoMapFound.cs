﻿using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class NoMapFound : MapOrderPosAbstract
    {
        public NoMapFound(IMapPosInstOrderDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<PosInstOrderMapDTO> MapOLogOrderAsync(InstOLogDTO request, List<PosTransactionDTO> posTransactions)
        {
            MapLog.LogOrderMap(request, MapLogReasonEnum.UnMappedOLog, MapLogTypeEnum.OLog, MapLevelEnum.UNMAP, MapLogSeverityEnum.Warning);
            return await Task.FromResult(MapPosInstOrder(null, request, (int)MapCriteriaEnum.NoMapFound));
        }
    }
}