﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class Daily : IntervalAbstract
    {
        static DateTime ordersFromDt, ordersToDt;

        public Daily(IMapPosInstOrderDac dac, string jobname) : base(dac, jobname)
        {
            if (OmniExtensions.today.Day == 1)
            {
                ordersFromDt = OmniExtensions.lastMonthStart;
                ordersToDt = OmniExtensions.lastMonthEnd;
            }
            else
            {
                ordersFromDt = OmniExtensions.thisMonthStart;
                ordersToDt = OmniExtensions.thisMonthEnd;
            }
        }

        protected internal override async Task<List<PosTransactionDTO>> GetBypassCheckoutOrders()
        {
            logBO.Info(jobname + "- Get BypassCheckout Orders - Daily - Start");
            var result = await _dac.GetBypassCheckoutOrders(ordersFromDt, ordersToDt);
            logBO.Info(jobname + "- Get BypassCheckout Orders - Daily - End");

            return result;
        }

        protected internal override async Task<List<InstOLogDTO>> GetOlogOrdersToMap()
        {
            var ologorders = new List<InstOLogDTO>();

            logBO.Info(jobname + "- Get OLog Orders & Get Unmapped Olog Orders from Recon - Daily - Start");
            ologorders = await _dac.GetOLogOrders(ordersFromDt, ordersToDt, MapLevelEnum.INVCP.ToString(), MapLevelEnum.FEECP.ToString());
            var unmappedOrders = await _dac.GetUnmappedOlogOrdersFromRecon(ordersFromDt, ordersToDt, MapLevelEnum.UNMAP.ToString(), MapLogTypeEnum.OLog.ToString());

            if (ologorders != null && ologorders.Count > 0)
            {
                ologorders.AddRange(unmappedOrders);
            }
            else if (unmappedOrders != null && unmappedOrders.Count > 0)
            {
                ologorders = unmappedOrders;
            }

            logBO.Info(jobname + "- Get OLog Orders & Get Unmapped Olog Orders from Recon - Daily - End");

            return ologorders;

        }

        protected internal override async Task LogUnmappedPos(DateTime minTxnDate, DateTime maxTxnDate)
        {
            logBO.Info(jobname + "- Log Unmapped Pos at Order Level - Daily - Start");
            await _dac.LogUnmappedPosAtOrderLevel(minTxnDate, maxTxnDate, DateTime.Now, Environment.UserName, MapLogReasonEnum.UnMappedPos.ToString(), MapLogSeverityEnum.Warning.ToString(), MapLogTypeEnum.Pos.ToString(), MapLevelEnum.UNMAP.ToString());
            logBO.Info(jobname + "- Log Unmapped Pos at Order Level - Daily - End");
        }
    }
}
