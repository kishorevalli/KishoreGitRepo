﻿using System.Collections.Generic;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System.Threading.Tasks;
using System;
using System.Linq;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;
using System.Collections.Concurrent;
using System.Transactions;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class OrderLevelTransactionsHelper : Common
    {
        readonly IMapPosInstOrderDac _dac;
        MapOrderPosAbstract appplyCreditReturnsExclusion;
        static int _maxparallelism;


        public OrderLevelTransactionsHelper(IMapPosInstOrderDac dac, string jobname, int maxparallelism) : base(dac, jobname)
        {
            _dac = dac;
            _maxparallelism = maxparallelism;
        }

        public async Task RetreiveBypassOrdersFromPosTransactions(IntervalAbstract interval)
        {
            logBO.Info(jobname + "- Get BypassCheckout orders based on MapInterval - Start");
            var bypassOrders = await interval.GetBypassCheckoutOrders();
            logBO.Info(jobname + "- Get BypassCheckout orders based on MapInterval - End");

            await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderMap);

            if (bypassOrders != null && bypassOrders.Count > 0)
            {
                logBO.Info(jobname + "- Insert BypassChecout Transactions - Start");
                var mappedorders = new ConcurrentQueue<PosInstOrderMapDTO>();

                Parallel.ForEach(bypassOrders, new ParallelOptions { MaxDegreeOfParallelism = _maxparallelism },
                ordr =>
                {
                    var mapord = MapOrderPosAbstract.MapBypassCheckoutOrders(ordr).Result;
                    if (mapord != null)
                        mappedorders.Enqueue(mapord);
                });
                await _dac.BulkCopy(mappedorders.DequeueItems(0), new PosInstOrderMapDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgPosInstOrderMap);
                await _dac.UpdateBypssOrdersWithDeliveryId();
                await _dac.PushMappedOrdersStagingToMain(MapLevelEnum.INVCP.ToString(), MapLevelEnum.FEECP.ToString());
                await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderMap);

                logBO.Info(jobname + "- Insert BypassChecout Transactions - End");
            }
        }

        protected internal void ConfigureMappingScenarios(IEnumerable<InstCreditReturnOrdersDTO> creditReturns)
        {
            MapOrderPosAbstract.CreditReturns = creditReturns;

            appplyCreditReturnsExclusion = new ApplyCreditReturnsExclusion(_dac, jobname);
            MapOrderPosAbstract storeDateTimeAmountScenario = new ExactMapWithStoreDateTimeAmount(_dac, jobname);
            MapOrderPosAbstract storeDateAmountScenarioWithVariance = new ExactMapWithStoreDateTimeAmountWithVariance(_dac, jobname);
            MapOrderPosAbstract storeDateAmountScenario = new ExactMapWithStoreDateAmount(_dac, jobname);
            MapOrderPosAbstract tlogstoreDateTimeAmountScenario = new ExactMapWithTLogStoreDateTimeAmount(_dac, jobname);
            MapOrderPosAbstract tlogstoreDateAmountScenarioWithVariance = new ExactMapWithTLogStoreDateTimeAmountWithVariance(_dac, jobname);
            MapOrderPosAbstract tlogstoreDateAmountScenario = new ExactMapWithTLogStoreDateAmount(_dac, jobname);
            MapOrderPosAbstract dateTimeAmountScenario = new ExactMapWithDateTimeAmount(_dac, jobname);
            MapOrderPosAbstract dateTimeAmountScenarioWithVariance = new ExactMapWithDateTimeAmountWithVariance(_dac, jobname);
            MapOrderPosAbstract dateAmountScenario = new ExactMapWithDateAmount(_dac, jobname);
            MapOrderPosAbstract returnedStoreAmountDateScenario = new ExactMapWithReturnedStoreAmountDate(_dac, jobname);
            MapOrderPosAbstract returnedAmountDateScenario = new ExactMapWithReturnedAmountDate(_dac, jobname);
            MapOrderPosAbstract noMapScenario = new NoMapFound(_dac, jobname);

            appplyCreditReturnsExclusion.SetNextMatchScenario(storeDateTimeAmountScenario);
            storeDateTimeAmountScenario.SetNextMatchScenario(storeDateAmountScenarioWithVariance);
            storeDateAmountScenarioWithVariance.SetNextMatchScenario(storeDateAmountScenario);
            storeDateAmountScenario.SetNextMatchScenario(tlogstoreDateTimeAmountScenario);

            tlogstoreDateTimeAmountScenario.SetNextMatchScenario(tlogstoreDateAmountScenarioWithVariance);
            tlogstoreDateAmountScenarioWithVariance.SetNextMatchScenario(tlogstoreDateAmountScenario);
            tlogstoreDateAmountScenario.SetNextMatchScenario(dateTimeAmountScenario);

            dateTimeAmountScenario.SetNextMatchScenario(dateTimeAmountScenarioWithVariance);
            dateTimeAmountScenarioWithVariance.SetNextMatchScenario(dateAmountScenario);
            dateAmountScenario.SetNextMatchScenario(returnedStoreAmountDateScenario);

            returnedStoreAmountDateScenario.SetNextMatchScenario(returnedAmountDateScenario);
            returnedAmountDateScenario.SetNextMatchScenario(noMapScenario);
        }


        protected internal async Task ProcessAndInsertDataAsync(List<InstOLogDTO> ologOrdersToProcess, List<PosTransactionDTO> posTransactions)
        {
            var mappedorders = new ConcurrentQueue<PosInstOrderMapDTO>();

            try
            {
                MapOrderPosAbstract.MapLog = new ConcurrentQueue<MapLogDTO>();

                await _dac.TruncateTable(Constants.BulkCopyTables.StgMapLog);
                await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderMap);

                Parallel.ForEach(ologOrdersToProcess, new ParallelOptions { MaxDegreeOfParallelism = _maxparallelism },
                ordr =>
                {
                    var mpOrdr = appplyCreditReturnsExclusion.MapOLogOrderAsync(ordr, posTransactions).Result;
                    if (mpOrdr != null)
                    {
                        mpOrdr.LastUpdatedDate = DateTime.Now;
                        mpOrdr.LastUpdatedBy = Environment.UserName;
                        mappedorders.Enqueue(mpOrdr);
                    }
                });


                var transOptions = new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted, Timeout = TransactionManager.MaximumTimeout };
                using (var scope = new TransactionScope(TransactionScopeOption.Required, transOptions, TransactionScopeAsyncFlowOption.Enabled))
                {
                    logBO.Info(jobname + "- Insert Map Log - Start");
                    await _dac.BulkCopy(MapOrderPosAbstract.MapLog.DequeueItems(0), new MapLogDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgMapLog);
                    await _dac.MoveStgMapLogToMain();
                    await _dac.TruncateTable(Constants.BulkCopyTables.StgMapLog);
                    logBO.Info(jobname + "- Insert Map Log - End");


                    logBO.Info(jobname + "- Insert Order Map - Start");
                    await _dac.BulkCopy(mappedorders.DequeueItems(0), new PosInstOrderMapDTO().GetPropertyMembers(), Constants.BulkCopyTables.StgPosInstOrderMap);
                    await _dac.PushMappedOrdersStagingToMain(MapLevelEnum.INVCP.ToString(), MapLevelEnum.FEECP.ToString());
                    await _dac.TruncateTable(Constants.BulkCopyTables.StgPosInstOrderMap);
                    logBO.Info(jobname + "- Insert Order Map - End");

                    scope.Complete();
                }
            }
            catch (AggregateException ex)
            {
                foreach (var inrecep in ex.InnerExceptions)

                    logBO.Error(jobname + "- " + inrecep);

                throw;
            }
        }
    }
}