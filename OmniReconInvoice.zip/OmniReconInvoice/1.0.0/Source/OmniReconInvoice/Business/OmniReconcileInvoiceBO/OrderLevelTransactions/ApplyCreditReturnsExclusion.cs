﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class ApplyCreditReturnsExclusion : MapOrderPosAbstract
    {
        public ApplyCreditReturnsExclusion(IMapPosInstOrderDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<PosInstOrderMapDTO> MapOLogOrderAsync(InstOLogDTO request, List<PosTransactionDTO> posTransactions)
        {

            if (CreditReturns.Any(c => c.OrderId != 0 && c.DeliveryId != 0 && c.OrderId == request.OrderId && c.DeliveryId == request.DeliveryId))
            {
                var crRet = CreditReturns.FirstOrDefault(c => c.OrderId == request.OrderId && c.DeliveryId == request.DeliveryId);
                request.ExclusionType = (ExclusionTypeEnum)crRet.ExclusionTypeId;
                MapLog.LogOrderMap(request, (MapLogReasonEnum)crRet.ExclusionTypeId, MapLogTypeEnum.OLog, MapLevelEnum.ORDMP, MapLogSeverityEnum.Warning);
            }

            if (request.TransactionAmt < 0)
            {
                request.ExclusionType = ExclusionTypeEnum.ReturnedOrder;
                MapLog.LogOrderMap(request, MapLogReasonEnum.ReturnedOrder, MapLogTypeEnum.OLog, MapLevelEnum.ORDMP, MapLogSeverityEnum.Warning);
            }
            return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);
        }
    }
}

