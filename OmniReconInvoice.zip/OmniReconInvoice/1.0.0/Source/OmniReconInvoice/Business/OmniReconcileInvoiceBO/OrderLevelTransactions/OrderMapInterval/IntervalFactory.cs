﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class IntervalFactory : Common
    {
        readonly IMapPosInstOrderDac _dac;
        readonly string _jobname;


        public IntervalFactory(IMapPosInstOrderDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
            _jobname = jobname;
        }

        public IntervalAbstract GetIntervalType(MapIntervalDTO type)
        {
            IntervalAbstract result = null;

            if (type.Orders)
                result = new Order(_dac, _jobname, type.OrderIds);

            if (type.Daily)
                result = new Daily(_dac, _jobname);

            if (type.DateRange)
                result = new DateRange(_dac, _jobname, type.FromDate, type.ToDate);

            return result;
        }
    }
}
