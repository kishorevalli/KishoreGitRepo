﻿using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    internal class ExactMapWithStoreDateTimeAmount : MapOrderPosAbstract
    {
        public ExactMapWithStoreDateTimeAmount(IMapPosInstOrderDac dac, string jobname) : base(dac, jobname)
        {
        }
        public override async Task<PosInstOrderMapDTO> MapOLogOrderAsync(InstOLogDTO request, List<PosTransactionDTO> posTransactions)
        {
            // TO DO take minutes from Syetem values
            var posTrans = posTransactions.Where(trans => trans.FacilityId == request.StoreLocation &&
                                           trans.TransactionDate == request.TransactionDateEST &&
                                           Convert.ToDateTime(request.TransactionDateTimeEST.ToString("MM/dd/yyyy HH:mm")) == trans.TransactionTime &&
                                           trans.TenderAmount == request.TransactionAmt && !trans.IsPosMapped);

            if (posTrans == null || !posTrans.Any())
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);

            if (posTrans != null && posTrans.Count() == 1)
            {

                var result = MapPosInstOrder(posTrans.FirstOrDefault(), request, (int)MapCriteriaEnum.MapWithStoreDateTimeAmount);

                foreach (var trans in posTransactions)
                {
                    if (trans.FacilityId == request.StoreLocation &&
                        trans.TransactionDate == request.TransactionDateEST &&
                        Convert.ToDateTime(request.TransactionDateTimeEST.ToString("MM/dd/yyyy HH:mm")) == trans.TransactionTime &&
                        trans.TenderAmount == request.TransactionAmt)
                    {
                        trans.IsPosMapped = true;
                        break;
                    }
                }

                return result;
            }

            return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);
        }
    }
}