﻿using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public static class LogReconInvoice
    {
        public static void LogOrderMap(this ConcurrentQueue<MapLogDTO> maplog, InstTLogDTO request, MapLogReasonEnum reason, MapLogTypeEnum logtype, MapLevelEnum loglevel, MapLogSeverityEnum severity)
        {
            maplog.Enqueue(new MapLogDTO
            {
                InstOrderId = request.OrderId,
                InstDeliveryId = request.DeliveryId,
                InstStoreLocation = request.StoreLocation,
                InstOrderedDate = request.OrderedDate,
                InstDeliveryDate = request.DeliveryDate,
                InstItemId = request.ReferenceCode,
                InstGTIN = request.GTIN,
                InstOnlinePrice = request.InstOnlinePrice,
                InstQty = request.Qty,
                InstUnit = request.Unit,
                InstGMV = request.GMV,
                Reason = reason.ToString(),
                Severity = severity.ToString(),
                Level = loglevel.ToString(),
                Type = logtype.ToString(),
                LastUpdatedBy = Environment.UserName,
                LastUpdatedDate = DateTime.Now

            });
        }

        public static void LogOrderMap(this ConcurrentQueue<MapLogDTO> maplog, PosInstOrderSummaryDTO request, MapLogReasonEnum reason, MapLogTypeEnum logtype, MapLevelEnum loglevel, MapLogSeverityEnum severity)
        {
            maplog.Enqueue(new MapLogDTO
            {
                InstOrderId = request.InstOrderId,
                InstDeliveryId = request.InstDeliveryId,
                InstBottleDeposit = request.InstBottleDeposit,
                PosFacilityId = request.PosFacilityId,
                PosTransactionDate = request.PosTransactionDate,
                PosTransactionTM = request.PosTransactionTM,
                PosTransactionNumber = request.PosTransactionTM,
                PosBottleDeposit = request.PosBottleDeposit,
                Reason = reason.ToString(),
                Severity = severity.ToString(),
                Level = loglevel.ToString(),
                Type = logtype.ToString(),
                LastUpdatedBy = Environment.UserName,
                LastUpdatedDate = DateTime.Now

            });
        }

        public static void LogOrderMap(this ConcurrentQueue<MapLogDTO> maplog, PosLineItemTransactionDTO request, MapLogReasonEnum reason, MapLogTypeEnum logtype, MapLevelEnum loglevel, MapLogSeverityEnum severity)
        {
            maplog.Enqueue(new MapLogDTO
            {
                PosFacilityId = request.FacilityId,
                PosTransactionDate = request.TransactionDate,
                PosTransactionTM = request.TransactionTM,
                PosTransactionNumber = request.TransactionTM,
                PosItemId = request.ItemId,
                PosSalesType = request.SalesType,
                PosSalesAmount = request.SalesAmount,
                PosSalesVolume = request.SalesVolume,
                PosSalesVolumeIndicator = request.VolumeIndicator,
                Reason = reason.ToString(),
                Severity = severity.ToString(),
                Level = loglevel.ToString(),
                Type = logtype.ToString(),
                LastUpdatedBy = Environment.UserName,
                LastUpdatedDate = DateTime.Now
            });
        }

        public static void LogOrderMap(this ConcurrentQueue<MapLogDTO> maplog, PosInstOrderItemMapDTO positm, MapLogReasonEnum reason, MapLogTypeEnum logtype, MapLevelEnum loglevel, MapLogSeverityEnum severity)
        {
            maplog.Enqueue(new MapLogDTO
            {
                InstOrderId = positm.InstOrderId,
                InstDeliveryId = positm.InstDeliveryId,
                InstStoreLocation = positm.InstStoreLocation,
                InstItemId = positm.InstReferenceCode,
                InstGTIN = positm.InstGTIN,
                InstGMV = positm.InstGMV,
                PosFacilityId = positm.PosFacilityId,
                PosTransactionDate = positm.PosTransactionDate,
                PosTransactionTM = positm.PosTransactionTM,
                PosTransactionNumber = positm.PosTransactionTM,
                PosItemId = positm.PosItemId,
                PosSalesAmount = positm.PosSalesAmount,
                PosSalesVolume = positm.PosSalesVolume,
                SpreadPercentage = positm.SpreadPercentage,
                Reason = reason.ToString(),
                Severity = severity.ToString(),
                Level = loglevel.ToString(),
                Type = logtype.ToString(),
                LastUpdatedBy = Environment.UserName,
                LastUpdatedDate = DateTime.Now
            });
        }

        public static void LogOrderMap(this ConcurrentQueue<MapLogDTO> maplog, PosLineItemTransactionDTO postxn, InstTLogDTO tlogRecord, InstFeedDiscrepancyDTO itmdata, MapLogReasonEnum reason, MapLogTypeEnum logtype, MapLevelEnum loglevel, MapLogSeverityEnum severity)
        {
            maplog.Enqueue(new MapLogDTO
            {
                InstOrderId = tlogRecord.OrderId,
                InstDeliveryId = tlogRecord.DeliveryId,
                InstStoreLocation = tlogRecord.StoreLocation,
                InstOrderedDate = tlogRecord.OrderedDate,
                InstDeliveryDate = tlogRecord.DeliveryDate,
                InstItemId = tlogRecord.ReferenceCode,
                InstQty = tlogRecord.Qty,
                InstGTIN = tlogRecord.GTIN,
                InstGMV = tlogRecord.GMV,
                InstBottleDeposit = tlogRecord.BottleDeposit,
                PosFacilityId = postxn.FacilityId,
                PosTransactionDate = postxn.TransactionDate,
                PosTransactionTM = postxn.TransactionTM,
                PosTransactionNumber = postxn.TransactionTM,
                PosItemId = postxn.ItemId,
                PosSalesType = postxn.SalesType,
                PosSalesAmount = postxn.SalesAmount,
                PosSalesVolume = postxn.SalesVolume,
                PosBottleDeposit = itmdata.FeedBottleDeposit,
                PosUnitPrice = itmdata.FeedMarkUpSalePriceRounded != 0 ? itmdata.FeedMarkUpSalePriceRounded : itmdata.FeedMarkUpPriceRounded,
                PosSalesVolumeIndicator = postxn.VolumeIndicator,
                Reason = reason.ToString(),
                Severity = severity.ToString(),
                Level = loglevel.ToString(),
                Type = logtype.ToString(),
                LastUpdatedBy = Environment.UserName,
                LastUpdatedDate = DateTime.Now

            });
        }

        public static void LogOrderMap(this ConcurrentQueue<MapLogDTO> maplog, InstOLogDTO request, MapLogReasonEnum reason, MapLogTypeEnum logtype, MapLevelEnum loglevel, MapLogSeverityEnum severity)
        {
            maplog.Enqueue(new MapLogDTO
            {
                InstOrderId = request.OrderId,
                InstDeliveryId = request.DeliveryId,
                InstStoreLocation = request.StoreLocation,
                InstTransactionAmt = request.TransactionAmt,
                InstTransactionDateTime = request.TransactionDateTime,
                Reason = reason.ToString(),
                Severity = severity.ToString(),
                Level = loglevel.ToString(),
                Type = logtype.ToString(),
                LastUpdatedBy = Environment.UserName,
                LastUpdatedDate = DateTime.Now

            });
        }
    }
}
