﻿using Publix.S0OMNIRI.OmniReconInvoiceEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using System.Collections.Concurrent;

namespace Publix.S0OMNIRI.OmniReconInvoiceBusiness
{
    public class AggregateOrder : Common
    {
        static IOrderAggregatedDac _dac;
        public AggregateOrder(IOrderAggregatedDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        //static ConcurrentQueue<PosInstOrderInvoiceDTO> _InvoiceOrders;
        //public static ConcurrentQueue<PosInstOrderInvoiceDTO> InvoiceOrders
        //{
        //    get
        //    {
        //        if (_InvoiceOrders == null)
        //            return new ConcurrentQueue<PosInstOrderInvoiceDTO>();

        //        return _InvoiceOrders;
        //    }
        //    set { _InvoiceOrders = value; }
        //}

        //static ConcurrentQueue<PosInstAggregatedOrderDTO> _AggregatedOrders;
        //public static ConcurrentQueue<PosInstAggregatedOrderDTO> AggregatedOrders
        //{
        //    get
        //    {
        //        if (_AggregatedOrders == null)
        //            return new ConcurrentQueue<PosInstAggregatedOrderDTO>();

        //        return _AggregatedOrders;
        //    }
        //    set { _AggregatedOrders = value; }
        //}

        public static ConcurrentQueue<PosInstOrderInvoiceDTO> InvoiceOrders { get; set; }
        public static ConcurrentQueue<PosInstAggregatedOrderDTO> AggregatedOrders { get; set; }

        public static void ConvertOrderSummaryToInvoice(IEnumerable<PosInstOrderSummaryDTO> ordsummary, Int64 orderid, Int64 deliveryid, List<PosInstOrderMapDTO> posinstMappedOrders, string storefront)
        {
            var mapordr = posinstMappedOrders.Where(m => m.InstOrderId == orderid && m.InstDeliveryId == deliveryid).ToList();

            var mappedorders = mapordr.GroupBy(m => new { m.InstOrderId, m.InstDeliveryId, m.PosFacilityId, m.PosTransactionDate, m.IsByPassCheckOut },
                                (key, grp) => new PosInstOrderMapDTO
                                {
                                    InstOrderId = key.InstOrderId,
                                    InstDeliveryId = key.InstDeliveryId,
                                    PosTransactionDate = key.PosTransactionDate,
                                    PosFacilityId = key.PosFacilityId,
                                    IsByPassCheckOut = key.IsByPassCheckOut,
                                    PosNonAlcoholSales = grp.Sum(i => i.PosNonAlcoholSales),
                                    PosAlcoholSales = grp.Sum(i => i.PosAlcoholSales),
                                    PosSalesBeforeTax = grp.Sum(i => i.PosSalesBeforeTax),
                                    PosSalesTax = grp.Sum(i => i.PosSalesTax),
                                    PosBottleDeposit = grp.Sum(i => i.PosBottleDeposit),
                                    PosCouponValue = grp.Sum(i => i.PosCouponValue),
                                    PosTotalSalesIncludingTax = grp.Sum(i => i.PosTotalSalesIncludingTax),
                                    PosTenderAmount = grp.Sum(i => i.PosTenderAmount),
                                });

            foreach (var ord in mappedorders)
            {

                var summary = ordsummary.Where(os =>
                                                os.InstOrderId == ord.InstOrderId &&
                                                os.InstDeliveryId == ord.InstDeliveryId &&
                                                os.PosFacilityId == ord.PosFacilityId &&
                                                os.PosTransactionDate == ord.PosTransactionDate
                                         )
                                        .GroupBy(p => new { p.InstOrderId, p.InstDeliveryId, p.PosFacilityId, p.PosTransactionDate },
                                        (key, grp) => new PosInstAggregatedOrderDTO
                                        {
                                            InstOrderId = key.InstOrderId,
                                            InstDeliveryId = key.InstDeliveryId,
                                            PosStoreNumber = key.PosFacilityId,
                                            PosTransactionDate = key.PosTransactionDate,
                                            PosNonAlcoholSales = ord.PosNonAlcoholSales,
                                            PosAlcoholSales = ord.PosAlcoholSales,
                                            PosSalesBeforeTax = ord.PosSalesBeforeTax,
                                            PosSalesTax = ord.PosSalesTax,
                                            PosBottleDeposit = ord.PosBottleDeposit,
                                            PosCouponValue = ord.PosCouponValue,
                                            PosSalesIncludingTax = ord.PosTotalSalesIncludingTax,
                                            PosTenderAmount = ord.PosTenderAmount,
                                            QualifiedPosNonAlcoholSales = CalculateQualifiedPosNonAlcoholSales(grp, ord),
                                            QualifiedPosAlcoholSales = CalculateQualifiedPosAlcoholSales(grp, ord),
                                            QualifiedPosSalesBeforeTax = grp.Sum(i => (i.PosAdjSalesAmount != 0 ? i.PosAdjSalesAmount : i.PosSalesAmount)),
                                            QualifiedPosSalesTax = grp.Sum(i => (i.PosAdjTotalTax != 0 ? i.PosAdjTotalTax : i.PosTotalTax)),
                                            QualifiedPosBottleDeposit = ord.PosBottleDeposit,
                                            QualifiedPosCouponValue = ord.PosCouponValue,
                                            QualifiedPosSalesIncludingTax = grp.Sum(i => (i.PosAdjTotalSalesIncludingTax != 0 ? i.PosAdjTotalSalesIncludingTax : i.PosTotalSalesIncludingTax)),
                                            PosAdjPreTaxNonAlcoholSales = grp.Sum(i => i.PosAdjPreTaxNonAlcoholSales),
                                            PosAdjPreTaxAlcoholSales = grp.Sum(i => i.PosAdjPreTaxAlcoholSales),
                                            PosAdjSalesTax = grp.Sum(i => i.PosAdjTotalTax),
                                            PosAdjSalesIncludingTax = grp.Sum(i => i.PosAdjTotalSalesIncludingTax),
                                            PosTaxPlan1Tax = grp.Sum(i => i.PosTaxPlan1Tax),
                                            PosTaxPlan1TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan1TaxPlan2Tax),
                                            PosTaxPlan3TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan3TaxPlan2Tax),
                                            PosTaxPlan3Tax = grp.Sum(i => i.PosTaxPlan3Tax),
                                            InstOnlineRevenue = grp.Sum(i => i.InstOnlineRevenue),
                                            InstPreTaxAlcoholSales = grp.Sum(i => i.InstPreTaxAlcoholSales),
                                            InstPreTaxNonAlcoholSales = grp.Sum(i => i.InstPreTaxNonAlcoholSales),
                                            InstSalesTax = grp.Sum(i => i.InstSalesTax),
                                            InstGMV = grp.Sum(i => i.InstGMV),
                                            InstBottleDeposit = grp.Sum(i => i.InstBottleDeposit),
                                            InstAdjOnlineRevenue = grp.Any(s => s.InstAdjOnlineRevenue != 0) ? (grp.Sum(i => (i.InstAdjOnlineRevenue != 0 ? i.InstAdjOnlineRevenue : i.InstOnlineRevenue))) : 0,
                                            InstAdjPreTaxAlcoholSales = grp.Any(s => s.InstAdjPreTaxAlcoholSales != 0) ? (grp.Sum(i => (i.InstAdjPreTaxAlcoholSales != 0 ? i.InstAdjPreTaxAlcoholSales : i.InstPreTaxAlcoholSales))) : 0,
                                            InstAdjPreTaxNonAlcoholSales = grp.Any(s => s.InstAdjPreTaxNonAlcoholSales != 0) ? (grp.Sum(i => (i.InstAdjPreTaxNonAlcoholSales != 0 ? i.InstAdjPreTaxNonAlcoholSales : i.InstPreTaxNonAlcoholSales))) : 0,
                                            InstAdjSalesTax = grp.Any(s => s.InstAdjSalesTax != 0) ? (grp.Sum(i => (i.InstAdjSalesTax != 0 ? i.InstAdjSalesTax : i.InstSalesTax))) : 0,
                                            InstAdjGMV = grp.Any(s => s.InstAdjGMV != 0) ? (grp.Sum(i => (i.InstAdjGMV != 0 ? i.InstAdjGMV : i.InstGMV))) : 0,
                                            InstAdjBottleDeposit = grp.Any(s => s.InstAdjBottleDeposit != 0) ? (grp.Sum(i => (i.InstAdjBottleDeposit != 0 ? i.InstAdjBottleDeposit : i.InstBottleDeposit))) : 0,
                                            InstTaxPlan1Tax = grp.Sum(i => i.InstTaxPlan1Tax),
                                            InstTaxPlan1TaxPlan2Tax = grp.Sum(i => i.InstTaxPlan1TaxPlan2Tax),
                                            InstTaxPlan3TaxPlan2Tax = grp.Sum(i => i.InstTaxPlan3TaxPlan2Tax),
                                            InstTaxPlan3Tax = grp.Sum(i => i.InstTaxPlan3Tax),
                                            CalculatedSpreadAmount = grp.Average(i => i.SpreadAmount),
                                            CalculatedSpreadPercentage = grp.Average(i => i.SpreadPercentage),
                                            TaxPlan1TaxGap = grp.Sum(i => i.TaxPlan1TaxGap),
                                            TaxPlan1TaxPlan2TaxGap = grp.Sum(i => i.TaxPlan1TaxPlan2TaxGap),
                                            TaxPlan3TaxPlan2TaxGap = grp.Sum(i => i.TaxPlan3TaxPlan2TaxGap),
                                            TaxPlan3TaxGap = grp.Sum(i => i.TaxPlan3TaxGap),
                                            TaxPlan1TaxableSalesGap = grp.Sum(i => i.TaxPlan1TaxableSalesGap),
                                            TaxPlan1TaxPlan2TaxableSalesGap = grp.Sum(i => i.TaxPlan1TaxPlan2TaxableSalesGap),
                                            TaxPlan3TaxPlan2TaxableSalesGap = grp.Sum(i => i.TaxPlan3TaxPlan2TaxableSalesGap),
                                            TaxPlan3TaxableSalesGap = grp.Sum(i => i.TaxPlan3TaxableSalesGap),
                                            IsByPassCheckOut = ord.IsByPassCheckOut,
                                            State = StoreMarket.GetStateForStore(key.PosFacilityId),
                                            LastUpdatedBy = Environment.UserName,
                                            LastUpdatedDate = DateTime.Now,
                                            StoreFront = storefront.Trim(),
                                            DeliveryModel = string.Empty,
                                        }).ToList();


                foreach (var order in summary)
                {
                    TaxSpreadCalculation.CalculateSpreadForInvoice(order);

                    order.AnyItemExclusion = _dac.CheckItemExclusionAppliedForOrder(order.InstOrderId, order.InstDeliveryId).Result;
                    order.AnyPosAdj = order.PosAdjSalesIncludingTax != 0 ? true : false;
                    order.AnyInstAdj = order.InstAdjGMV != 0 ? true : false;

                    order.SalesBeforeTaxGap = (order.InstGMV - (order.InstTaxPlan1Tax + order.InstTaxPlan1TaxPlan2Tax + order.InstTaxPlan3TaxPlan2Tax + order.InstTaxPlan3Tax)) -
                                                   (order.QualifiedPosSalesIncludingTax - (order.PosTaxPlan1Tax + order.PosTaxPlan1TaxPlan2Tax + order.PosTaxPlan3TaxPlan2Tax + order.PosTaxPlan3Tax));

                    order.NonTaxableSalesGap = ((order.InstGMV - (order.InstTaxPlan1Tax + order.InstTaxPlan1TaxPlan2Tax + order.InstTaxPlan3TaxPlan2Tax + order.InstTaxPlan3Tax)) -
                                                   (order.QualifiedPosSalesIncludingTax - (order.PosTaxPlan1Tax + order.PosTaxPlan1TaxPlan2Tax + order.PosTaxPlan3TaxPlan2Tax + order.PosTaxPlan3Tax))) -
                                                   (order.TaxPlan1TaxGap + order.TaxPlan1TaxPlan2TaxGap + order.TaxPlan3TaxPlan2TaxGap + order.TaxPlan3TaxGap);


                    InvoiceOrders.Enqueue(CreateInvoiceForOrder(order));
                    AggregatedOrders.Enqueue(order);
                }
            }
        }

        public static List<ETicketSummaryDTO> CreateETicketsByStoreDate()
        {
            var etickets =
               AggregatedOrders.GroupBy(a => new { a.PosStoreNumber, a.PosTransactionDate },
                 (key, grp) => new ETicketSummaryDTO
                 {
                     StoreNumber = key.PosStoreNumber,
                     TransactionDate = key.PosTransactionDate,
                     InstTaxPlan1Tax = grp.Sum(i => i.InstTaxPlan1Tax),
                     InstTaxPlan1TaxPlan2Tax = grp.Sum(i => i.InstTaxPlan1TaxPlan2Tax),
                     InstTaxPlan3TaxPlan2Tax = grp.Sum(i => i.InstTaxPlan3TaxPlan2Tax),
                     InstTaxPlan3Tax = grp.Sum(i => i.InstTaxPlan3Tax),
                     InstSalesBeforeTax = grp.Sum(i => (i.InstAdjOnlineRevenue != 0 ? i.InstAdjOnlineRevenue : i.InstOnlineRevenue)),
                     InstGMV = grp.Sum(i => (i.InstAdjGMV != 0 ? i.InstAdjGMV : i.InstGMV)),
                     PosTaxPlan1Tax = grp.Sum(i => i.PosTaxPlan1Tax),
                     PosTaxPlan1TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan1TaxPlan2Tax),
                     PosTaxPlan3TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan3TaxPlan2Tax),
                     PosTaxPlan3Tax = grp.Sum(i => i.PosTaxPlan3Tax),
                     PosSalesBeforeTax = grp.Sum(i => i.QualifiedPosSalesBeforeTax),
                     PosTotalSalesIncludingTax = grp.Sum(i => i.QualifiedPosSalesIncludingTax),
                     SalesBeforeTaxGap = grp.Sum(i => i.SalesBeforeTaxGap),
                     TaxPlan1TaxGap = grp.Sum(i => i.TaxPlan1TaxGap),
                     TaxPlan1TaxPlan2TaxGap = grp.Sum(i => i.TaxPlan1TaxPlan2TaxGap),
                     TaxPlan3TaxPlan2TaxGap = grp.Sum(i => i.TaxPlan3TaxPlan2TaxGap),
                     TaxPlan3TaxGap = grp.Sum(i => i.TaxPlan3TaxGap),
                     NonTaxableSalesGap = grp.Sum(i => i.NonTaxableSalesGap),
                     TaxPlan1TaxableSalesGap = grp.Sum(i => i.TaxPlan1TaxableSalesGap),
                     TaxPlan1TaxPlan2TaxableSalesGap = grp.Sum(i => i.TaxPlan1TaxPlan2TaxableSalesGap),
                     TaxPlan3TaxableSalesGap = grp.Sum(i => i.TaxPlan3TaxableSalesGap),
                     TaxPlan3TaxPlan2TaxableSalesGap = grp.Sum(i => i.TaxPlan3TaxPlan2TaxableSalesGap),
                     LastUpdatedBy = Environment.UserName,
                     LastUpdatedDate = DateTime.Now
                 }).ToList();

            foreach (var tkt in etickets.OrderBy(s => s.StoreNumber).ThenBy(t => t.TransactionDate))
            {
                tkt.Id = Convert.ToDecimal(string.Format("{0}{1}{2}", DateTime.Now.ToString("ddHHmmffff"), tkt.TransactionDate.ToString("yyMMdd"), tkt.StoreNumber.ToString("0000")));

                var invords = InvoiceOrders.Where(i => i.PosStoreNumber == tkt.StoreNumber && i.PosTransactionDate == tkt.TransactionDate).ToList();
                foreach (var inv in invords)
                {
                    inv.ETicketSummaryId = tkt.Id;
                }
            }
            return etickets;
        }

        static PosInstOrderInvoiceDTO CreateInvoiceForOrder(PosInstAggregatedOrderDTO a)
        {
            var invoice = new PosInstOrderInvoiceDTO
            {
                InstOrderId = a.InstOrderId,
                InstDeliveryId = a.InstDeliveryId,
                PosStoreNumber = a.PosStoreNumber,
                PosTransactionDate = a.PosTransactionDate,
                PosNonAlcoholSales = a.PosNonAlcoholSales,
                PosAlcoholSales = a.PosAlcoholSales,
                PosSalesBeforeTax = a.PosSalesBeforeTax,
                PosSalesTax = a.PosSalesTax,
                PosBottleDeposit = a.PosBottleDeposit,
                PosCouponValue = a.PosCouponValue,
                PosSalesIncludingTax = a.PosSalesIncludingTax,
                PosTenderAmount = a.PosTenderAmount,
                QualifiedPosNonAlcoholSales = a.QualifiedPosNonAlcoholSales,
                QualifiedPosAlcoholSales = a.QualifiedPosAlcoholSales,
                QualifiedPosSalesBeforeTax = a.QualifiedPosSalesBeforeTax,
                QualifiedPosSalesTax = a.QualifiedPosSalesTax,
                QualifiedPosBottleDeposit = a.QualifiedPosBottleDeposit,
                QualifiedPosCouponValue = a.QualifiedPosCouponValue,
                QualifiedPosSalesIncludingTax = a.QualifiedPosSalesIncludingTax,
                PosAdjPreTaxNonAlcoholSales = a.PosAdjPreTaxNonAlcoholSales,
                PosAdjPreTaxAlcoholSales = a.PosAdjPreTaxAlcoholSales,
                PosAdjSalesTax = a.PosAdjSalesTax,
                PosAdjSalesIncludingTax = a.PosAdjSalesIncludingTax,
                InstOnlineRevenue = a.InstOnlineRevenue,
                InstPreTaxAlcoholSales = a.InstPreTaxAlcoholSales,
                InstPreTaxNonAlcoholSales = a.InstPreTaxNonAlcoholSales,
                InstSalesTax = a.InstSalesTax,
                InstGMV = a.InstGMV,
                InstBottleDeposit = a.InstBottleDeposit,
                InstAdjOnlineRevenue = a.InstAdjOnlineRevenue,
                InstAdjPreTaxAlcoholSales = a.InstAdjPreTaxAlcoholSales,
                InstAdjPreTaxNonAlcoholSales = a.InstAdjPreTaxNonAlcoholSales,
                InstAdjSalesTax = a.InstAdjSalesTax,
                InstAdjGMV = a.InstAdjGMV,
                InstAdjBottleDeposit = a.InstAdjBottleDeposit,
                CalculatedSpreadAmount = a.CalculatedSpreadAmount,
                CalculatedSpreadPercentage = a.CalculatedSpreadPercentage,
                TaxPlan1TaxGap = a.TaxPlan1TaxGap,
                TaxPlan1TaxPlan2TaxGap = a.TaxPlan1TaxPlan2TaxGap,
                TaxPlan3TaxPlan2TaxGap = a.TaxPlan3TaxPlan2TaxGap,
                TaxPlan3TaxGap = a.TaxPlan3TaxGap,
                TaxPlan1TaxableSalesGap = a.TaxPlan1TaxableSalesGap,
                TaxPlan1TaxPlan2TaxableSalesGap = a.TaxPlan1TaxPlan2TaxableSalesGap,
                TaxPlan3TaxPlan2TaxableSalesGap = a.TaxPlan3TaxPlan2TaxableSalesGap,
                TaxPlan3TaxableSalesGap = a.TaxPlan3TaxableSalesGap,
                IsByPassCheckOut = a.IsByPassCheckOut,
                StoreFront = a.StoreFront,
                DeliveryModel = a.DeliveryModel,
                State = a.State,
                LastUpdatedBy = Environment.UserName,
                LastUpdatedDate = DateTime.Now
            };

            return invoice;
        }

        static decimal CalculateQualifiedPosAlcoholSales(IEnumerable<PosInstOrderSummaryDTO> grp, PosInstOrderMapDTO instor)
        {

            var grpCouponValue = instor.PosCouponValue;
            var grpBottleDepsoit = instor.PosBottleDeposit;
            var pretaxAlcoholSales = grp.Sum(i => (i.PosAdjPreTaxAlcoholSales != 0 ? i.PosAdjPreTaxAlcoholSales : i.PosPreTaxAlcoholSales));
            var pretaxNonAlcoholSales = grp.Sum(i => (i.PosAdjPreTaxNonAlcoholSales != 0 ? i.PosAdjPreTaxNonAlcoholSales : i.PosPreTaxNonAlcoholSales));

            if ((pretaxNonAlcoholSales + grpCouponValue - grpBottleDepsoit) < 0)
            {
                if ((pretaxAlcoholSales + grpCouponValue - grpBottleDepsoit) > 0)
                {
                    return pretaxAlcoholSales + grpCouponValue - grpBottleDepsoit;
                }
            }

            return pretaxAlcoholSales;
        }

        static decimal CalculateQualifiedPosNonAlcoholSales(IEnumerable<PosInstOrderSummaryDTO> grp, PosInstOrderMapDTO instor)
        {
            var grpCouponValue = instor.PosCouponValue;
            var grpBottleDepsoit = instor.PosBottleDeposit;
            var pretaxNonAlcoholSales = grp.Sum(i => (i.PosAdjPreTaxNonAlcoholSales != 0 ? i.PosAdjPreTaxNonAlcoholSales : i.PosPreTaxNonAlcoholSales));

            if ((pretaxNonAlcoholSales + grpCouponValue - grpBottleDepsoit) < 0)
            {
                return pretaxNonAlcoholSales + grpCouponValue - grpBottleDepsoit;
            }

            return pretaxNonAlcoholSales;
        }

    }
}
