﻿using log4net;
using log4net.Appender;
using log4net.Repository.Hierarchy;
using Publix.S0OMNIRI.OmniReconInvoiceBusiness;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;
using System;
using Unity;
using Unity.Lifetime;
using Unity.Resolution;

namespace OmniReconcilPostEticket
{
    class Program
    {
        readonly static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static IUnityContainer unityContainer = new UnityContainer();

        static int Main(string[] args)
        {
            var returnCode = Constants.JobReturnCode.Warning;
            var jobname = string.Empty;
            var eTicketType = string.Empty;
            try
            {
                eTicketType = args[0];//"ETICKET";//new argument name for e-ticket

                switch (eTicketType)
                {
                    case Constants.JobArgs.Generate:
                        {
                            jobname = Constants.JobCode.OMNI_TO_POS_ETICKET_GENERATE;
                            break;
                        }
                    case Constants.JobArgs.Publish:
                        {
                            jobname = Constants.JobCode.OMNI_TO_POS_ETICKET_PUBLISH;
                            break;
                        }
                    default:
                        {
                            log.Info("Invalid ETicket Type");
                            break;
                        }
                }

                jobname = OmniExtensions.GetJobNameWithEnv(jobname);

                ActivateLogOptions();
                log.Info(jobname + "- Start Batch");

                //Register Types
                RegisterTypeToUnity();

                // Create Business Instances 
                IPosEticket bo = unityContainer.Resolve<PosEticket>(new ResolverOverride[] { new ParameterOverride("jobname", jobname) });
                bo.ProcessEticket(eTicketType).Wait();
                returnCode = Constants.JobReturnCode.Successful;
            }
            catch (Exception ex)
            {
                returnCode = Constants.JobReturnCode.Severe;
                log.Error(jobname + "- Error", ex);
            }
            finally
            {
                log.Info(jobname + "- End Batch");
            }

            return (int)returnCode;
        }


        static void ActivateLogOptions()
        {
            var hierarchy = LogManager.GetRepository() as Hierarchy;
            if (hierarchy != null && hierarchy.Configured)
            {
                foreach (IAppender appender in hierarchy.GetAppenders())
                {
                    if (appender.Name == "AdoNetAppender")
                    {
                        var adoNetAppender = (AdoNetAppender)appender;
                        adoNetAppender.ConnectionStringName = string.Format("{0}-S0OMNIRI", Environment.GetEnvironmentVariable("PublixEnvironment"));
                        adoNetAppender.ActivateOptions();
                    }
                }
            }
        }

        /// <summary>
        /// Type registrations
        /// </summary>
        public static void RegisterTypeToUnity()
        {
            // register data objects
            using (var hierarchicalLifetimeManager = new HierarchicalLifetimeManager())
            {
                // register data objects
                unityContainer.RegisterType<IPosEticketDac, PosEticketDac>(hierarchicalLifetimeManager);
            }

            unityContainer.RegisterInstance<ILog>(log);
        }
    }
}
