﻿using log4net;
using log4net.Appender;
using log4net.Repository.Hierarchy;
using Publix.S0OMNIRI.OmniReconInvoiceBusiness;
using Publix.S0OMNIRI.OmniReconInvoiceDac;
using Publix.S0OMNIRI.OmniReconInvoiceUtilities;
using System;
using Unity;
using Unity.Lifetime;
using Unity.Resolution;

namespace Publix.S0OMNIRI.OmniReconAggregateTotal
{
    class Program
    {
        readonly static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static IUnityContainer unityContainer = new UnityContainer();
        static int Main()
        {
            var returnCode = Constants.JobReturnCode.Warning;
            var jobname = string.Empty;
            try
            {
                jobname = OmniExtensions.GetJobNameWithEnv(Constants.JobCode.OMNIRI_ORDER_AGGREGATED_TOTAL);

                ActivateLogOptions();
                log.Info(jobname + "- Start Batch");

                //Register Types
                RegisterTypeToUnity();

                // Create Business Instances 
                IOrderAggregated bo = unityContainer.Resolve<OrderAggregated>(new ResolverOverride[] { new ParameterOverride("jobname", jobname) });
                bo.GenerateAggregatedOrderTotals().Wait(); 

                returnCode = Constants.JobReturnCode.Successful;
            }
            catch (Exception ex)
            {
                returnCode = Constants.JobReturnCode.Severe;
                log.Error(jobname + "- Error", ex);
            }
            finally
            {
                log.Info(jobname + "- End Batch");
            }

            return (int)returnCode;
        }

        private static void ActivateLogOptions()
        {
            var hierarchy = LogManager.GetRepository() as Hierarchy;
            if (hierarchy != null && hierarchy.Configured)
            {
                foreach (IAppender appender in hierarchy.GetAppenders())
                {
                    if (appender.Name == "AdoNetAppender")
                    {
                        var adoNetAppender = (AdoNetAppender)appender;
                        adoNetAppender.ConnectionStringName = string.Format("{0}-S0OMNIRI", Environment.GetEnvironmentVariable("PublixEnvironment"));
                        adoNetAppender.ActivateOptions();
                    }
                }
            }
        }
        public static void RegisterTypeToUnity()
        {
            //register data objects
            using (var hierarchicalLifetimeManager = new HierarchicalLifetimeManager())
            {
                //register data objects
                unityContainer.RegisterType<IOrderAggregatedDac, OrderAggregatedDac>(hierarchicalLifetimeManager);
            }
            unityContainer.RegisterInstance<ILog>(log);
        }
    }
}
