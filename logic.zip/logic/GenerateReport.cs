﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using System.Data;
using Publix.S0OMNIXX.OmniItemDataEntities;
using ClosedXML.Excel;
using System.Configuration;
using System.IO;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class GenerateReport : Common, IGenerateReport
    {
        private readonly IGenerateReportDac _dac;
        public static string baseDirectory = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-ReportsPath"];
        public GenerateReport(IGenerateReportDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
        }

        public async Task GenerateExcelReport()
        {
            List<string> reports = await _dac.GetReportType();
            foreach (string report in reports)
            {
                var reportdtos = await _dac.GetReportsByName(report);
                DataSet ds = new DataSet();
                ds.DataSetName = report;
                foreach (ReportsDTO reportdto in reportdtos)
                {
                    var dta = await _dac.RunQuery(reportdto.Query);
                    dta.TableName = reportdto.SheetName;
                    if (dta.Rows.Count > 0)
                    {
                        ds.Tables.Add(dta);
                    }
                }
                if (ds.Tables.Count > 0)
                {
                    await GenerateExcel(ds, reportdtos.First().Template, reportdtos.First().NotificationId);
                }
            }
        }



        private async Task GenerateExcel(DataSet ds, string template, int notificationId)
        {


            logBO.Info(jobname + " - Generating Excel Report - Start");

            using (XLWorkbook wb = new XLWorkbook(baseDirectory + template))
            {
                for (int i = 0; i < ds.Tables.Count; i++)
                {
                    IXLWorksheet workSheet = wb.Worksheet(ds.Tables[i].TableName);
                    int NumberOfLastRow = workSheet.LastRowUsed().RowNumber();
                    IXLCell CellForNewData = workSheet.Cell(NumberOfLastRow + 1, 1);
                    CellForNewData.InsertData(ds.Tables[i]);
                }
                string filename = baseDirectory + ds.DataSetName + System.DateTime.Now.Month + System.DateTime.Now.Day + System.DateTime.Now.Year + ".xlsx";
                wb.SaveAs(filename);
                logBO.Info(jobname + " - Generating Excel Report - End");

                List<EmailNotificationDetailsDTO> notificationdetails = await _dac.GetNotificationDetails(notificationId);

                if (notificationdetails.Count > 0)
                {

                    string serviceUrl = ConfigurationManager.AppSettings[notificationdetails[0].EnvironMent + "-EmailServiceUrl"];

                    logBO.Info(jobname + " - Send Email - Start");
                    if (Environment.GetEnvironmentVariable("PublixEnvironment").ToUpper() == "Production".ToUpper() && notificationdetails[0].EnvironMent.ToUpper() == "Production".ToUpper())
                        PublishEmailMessage.CreateandSendMessage(notificationdetails[0].ToAddress, notificationdetails[0].CcAddress, notificationdetails[0].BccAddress, notificationdetails[0].Subject, notificationdetails[0].Message, serviceUrl, new string[] { filename });

                    else
                        PublishEmailMessage.CreateandSendMessage(notificationdetails[0].ToAddress, notificationdetails[0].CcAddress, notificationdetails[0].BccAddress, notificationdetails[0].Subject, notificationdetails[0].Message, serviceUrl, new string[] { filename });
                    logBO.Info(jobname + " - Send Email - End");
                }

                if (File.Exists(filename))
                {
                    logBO.Info(jobname + " - Delete Report - Start");
                    File.Delete(filename);
                    logBO.Info(jobname + " - Delete Report - End");
                }

            }

        }
    }
}
