﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ApplyTrackInventoryOverride : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;
        public ApplyTrackInventoryOverride(IItemDataRefreshDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {
            var itemdet = ItemDetails.FirstOrDefault(i => i.ItemId == itemData.RETAILER_REFERENCE_CODE);

            if (itemdet != null)
            {

                if (itemData.EXCLUDE_FROM_FILE && itemdet.TrackInventory == "N" && itemData.UNIT_RETAIL_PRICE != 0)
                    itemData.EXCLUDE_FROM_FILE = false;
            }
        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            throw new NotImplementedException();
        }
    }
}
