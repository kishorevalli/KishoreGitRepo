﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ApplyMarkupPrices : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;
        protected static List<int> panamacityStores;
        protected static IEnumerable<StoreTaxRateDTO> storeTaxRates;

        public ApplyMarkupPrices(IItemDataRefreshDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
            panamacityStores = SystemValues.GetValue<String>(Constants.SystemValues.PanamaCityStores).Split(',').ToList().Select(int.Parse).ToList();
            storeTaxRates = dac.GetStoreTaxRates().Result;
        }

        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {
            var itemDictry = new Dictionary<ItemKeyDTO, ItemDataDTO>();
            itemDictry.Add(new ItemKeyDTO { StoreNumber = itemData.STORE_IDENTIFIER, GTIN = itemData.SCAN_CODE, ItemId = itemData.RETAILER_REFERENCE_CODE }, itemData);

            var item = new KeyValuePair<ItemKeyDTO, ItemDataDTO>();
            var taxrate = storeTaxRates.FirstOrDefault(s => s.StoreNumber == storenumber);
            var IsAlcoholic = false;

            item = itemDictry.FirstOrDefault();
            item = ApplyMarkUpPrice(storenumber, item);
            item.Value.MARKUP_PRICE_ROUNDED = ApplyRoundingForMarkUpPrice(item.Value.MARKUP_PRICE, item.Value.MARKUP_PRICE_ROUNDED);
            item.Value.MARKUP_SALE_PRICE_ROUNDED = ApplyRoundingForMarkUpSalePrice(item.Value.MARKUP_SALE_PRICE, item.Value.MARKUP_SALE_PRICE_ROUNDED);
            item.Value.MARKUP_PRICE_ROUNDED = ApplyRoundingForMarkUpPriceMeatAndProduceItems(item.Value.MARKUP_PRICE, item.Value.MARKUP_PRICE_ROUNDED, item.Value.FAM_CODE);
            item.Value.MARKUP_SALE_PRICE_ROUNDED = ApplyRoundingForSalePriceMeatAndProduceItems(item.Value.MARKUP_SALE_PRICE, item.Value.MARKUP_SALE_PRICE_ROUNDED, item.Value.FAM_CODE);


            if (panamacityStores.Any(x => x == storenumber))
            {
                //not checking for null, because job20 will run prior to this job and it will get all items from pims
                Boolean.TryParse(ItemDetails.FirstOrDefault(i => i.ItemId == itemData.RETAILER_REFERENCE_CODE).Alcoholic, out IsAlcoholic);

                if (!IsAlcoholic)
                {
                    item.Value.MARKUP_PRICE_ROUNDED = Math.Round(((taxrate.TaxPlan2 / 100) * item.Value.MARKUP_PRICE_ROUNDED) + item.Value.MARKUP_PRICE_ROUNDED, 2, MidpointRounding.AwayFromZero);
                    item.Value.MARKUP_SALE_PRICE_ROUNDED = Math.Round(((taxrate.TaxPlan2 / 100) * item.Value.MARKUP_SALE_PRICE_ROUNDED) + item.Value.MARKUP_SALE_PRICE_ROUNDED, 2, MidpointRounding.AwayFromZero);
                }
            }



            if (ProcessingStores.FirstOrDefault(p => p.StoreNumber == storenumber).IsB2BEnabled)
            {
                item.Value.B2B_MARKUP_PRICE_ROUNDED = ApplyRoundingForMarkUpPrice(item.Value.B2B_MARKUP_PRICE, item.Value.B2B_MARKUP_PRICE_ROUNDED);
                item.Value.B2B_MARKUP_SALE_PRICE_ROUNDED = ApplyRoundingForMarkUpSalePrice(item.Value.B2B_MARKUP_SALE_PRICE, item.Value.B2B_MARKUP_SALE_PRICE_ROUNDED);
                item.Value.B2B_MARKUP_PRICE_ROUNDED = ApplyRoundingForMarkUpPriceMeatAndProduceItems(item.Value.B2B_MARKUP_PRICE, item.Value.B2B_MARKUP_PRICE_ROUNDED, item.Value.FAM_CODE);
                item.Value.B2B_MARKUP_SALE_PRICE_ROUNDED = ApplyRoundingForSalePriceMeatAndProduceItems(item.Value.B2B_MARKUP_SALE_PRICE, item.Value.B2B_MARKUP_SALE_PRICE_ROUNDED, item.Value.FAM_CODE);

                if (panamacityStores.Any(x => x == storenumber))
                {
                    if (!IsAlcoholic)
                    {
                        item.Value.B2B_MARKUP_PRICE_ROUNDED = Math.Round(((taxrate.TaxPlan2 / 100) * item.Value.B2B_MARKUP_PRICE_ROUNDED) + item.Value.B2B_MARKUP_PRICE_ROUNDED, 2, MidpointRounding.AwayFromZero);
                        item.Value.B2B_MARKUP_SALE_PRICE_ROUNDED = Math.Round(((taxrate.TaxPlan2 / 100) * item.Value.B2B_MARKUP_SALE_PRICE_ROUNDED) + item.Value.B2B_MARKUP_SALE_PRICE_ROUNDED, 2, MidpointRounding.AwayFromZero);
                    }
                }

            }


            itemData = item.Value;
        }

        KeyValuePair<ItemKeyDTO, ItemDataDTO> ApplyMarkUpPrice(int storenumber, KeyValuePair<ItemKeyDTO, ItemDataDTO> item)
        {
            var strinfo = ProcessingStores.FirstOrDefault(p => p.StoreNumber == storenumber);

            Decimal markupPercent = strinfo.MarkupPercent;
            Decimal b2bMarkupPercent = strinfo.B2B_MarkupPercent;

            item.Value.MARKUP_PERCENT = strinfo.MarkupPercent;
            item.Value.MARKUP_PRICE = Math.Round(((markupPercent / 100) * item.Value.UNIT_RETAIL_PRICE) + item.Value.UNIT_RETAIL_PRICE, 2, MidpointRounding.AwayFromZero);
            item.Value.MARKUP_SALE_PRICE = Math.Round(((markupPercent / 100) * item.Value.UNIT_SALE_PRICE) + item.Value.UNIT_SALE_PRICE, 2, MidpointRounding.AwayFromZero);
            item.Value.MARKUP_PRICE_ROUNDED = Math.Round(((markupPercent / 100) * item.Value.UNIT_RETAIL_PRICE) + item.Value.UNIT_RETAIL_PRICE, 2, MidpointRounding.AwayFromZero);
            item.Value.MARKUP_SALE_PRICE_ROUNDED = Math.Round(((markupPercent / 100) * item.Value.UNIT_SALE_PRICE) + item.Value.UNIT_SALE_PRICE, 2, MidpointRounding.AwayFromZero);

            if (strinfo.IsB2BEnabled)
            {
                item.Value.B2B_MARKUP_PERCENT = strinfo.B2B_MarkupPercent;
                item.Value.B2B_MARKUP_PRICE = Math.Round(((b2bMarkupPercent / 100) * item.Value.UNIT_RETAIL_PRICE) + item.Value.UNIT_RETAIL_PRICE, 2, MidpointRounding.AwayFromZero);
                item.Value.B2B_MARKUP_SALE_PRICE = Math.Round(((b2bMarkupPercent / 100) * item.Value.UNIT_SALE_PRICE) + item.Value.UNIT_SALE_PRICE, 2, MidpointRounding.AwayFromZero);
                item.Value.B2B_MARKUP_PRICE_ROUNDED = Math.Round(((b2bMarkupPercent / 100) * item.Value.UNIT_RETAIL_PRICE) + item.Value.UNIT_RETAIL_PRICE, 2, MidpointRounding.AwayFromZero);
                item.Value.B2B_MARKUP_SALE_PRICE_ROUNDED = Math.Round(((b2bMarkupPercent / 100) * item.Value.UNIT_SALE_PRICE) + item.Value.UNIT_SALE_PRICE, 2, MidpointRounding.AwayFromZero);
            }

            return item;
        }


        #region "Private Methods"


        //Apply rounding for Markup_Price
        private static decimal ApplyRoundingForMarkUpPrice(decimal itemMarkupPrice, decimal itemMarkupPriceRounded)
        {

            var lastDigitvalue = itemMarkupPrice.lastDigitvalue(); // Double.Parse(salePrice.ToString().Last().ToString());
            decimal last2Digits = itemMarkupPrice.last2Digits();

            var markupPrice = itemMarkupPrice;

            //.50 through .99
            if ((markupPrice > 0.49m) && (markupPrice < 1.00m))
            {
                if (lastDigitvalue == 0)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                if (lastDigitvalue == 2 || lastDigitvalue == 4 || lastDigitvalue == 6 || lastDigitvalue == 8)
                { itemMarkupPriceRounded = itemMarkupPrice + 0.01m; }
                if (lastDigitvalue == 1 || lastDigitvalue == 3 || lastDigitvalue == 5 || lastDigitvalue == 7)
                { itemMarkupPriceRounded = itemMarkupPrice; }

            }

            //$1.00 - $1.99
            if ((itemMarkupPrice > 0.99m) && (itemMarkupPrice < 2.00m))
            {
                if ((itemMarkupPrice == 1.00m) || (itemMarkupPrice == 1.01m))
                { itemMarkupPriceRounded = 0.99m; }
                else if (lastDigitvalue == 0)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                else if ((lastDigitvalue == 1) || (lastDigitvalue == 2) || (lastDigitvalue == 3) || (lastDigitvalue == 4))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.05m - (lastDigitvalue / 100)); }
                else if ((lastDigitvalue == 6) || (lastDigitvalue == 7) || (lastDigitvalue == 8))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.09m - (lastDigitvalue / 100)); }
            }


            //$2.00 - $4.99
            if ((itemMarkupPrice > 1.99m) && (itemMarkupPrice < 5.00m))
            {
                if ((itemMarkupPrice > 1.99m) && (itemMarkupPrice < 2.02m))
                { itemMarkupPriceRounded = 1.99m; }
                else if (lastDigitvalue == 0)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                else if ((lastDigitvalue == 1) || (lastDigitvalue == 2) || (lastDigitvalue == 3) || (lastDigitvalue == 4))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.05m - (lastDigitvalue / 100)); }
                else if ((lastDigitvalue == 6) || (lastDigitvalue == 7) || (lastDigitvalue == 8))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.09m - (lastDigitvalue / 100)); }
                if ((itemMarkupPrice > 2.99m) && (itemMarkupPrice < 3.03m))
                { itemMarkupPriceRounded = 2.99m; }
                if ((itemMarkupPrice > 3.99m) && (itemMarkupPrice < 4.04m))
                { itemMarkupPriceRounded = 3.99m; }

            }

            //////////////////////////////////////////////////
            //$5.00 - $9.99
            if ((itemMarkupPrice > 4.99m) && (itemMarkupPrice < 10.00m))
            {

                if (last2Digits == 0)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                else if ((last2Digits >= 0.01m) && (last2Digits < 0.05m))
                { itemMarkupPriceRounded = itemMarkupPrice - (last2Digits + 0.01m); }
                else if ((last2Digits == 0.05m) || (last2Digits == 0.06m) || (last2Digits == 0.07m) || (last2Digits == 0.08m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.09m - last2Digits); }
                else if (lastDigitvalue == 0)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                else if (lastDigitvalue == 1)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.02m; }
                else if ((lastDigitvalue == 2) || (lastDigitvalue == 3) || (lastDigitvalue == 4))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.05m - (lastDigitvalue / 100)); }
                else if ((lastDigitvalue == 6) || (lastDigitvalue == 7) || (lastDigitvalue == 8))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.09m - (lastDigitvalue / 100)); }

            }

            //$10.00 - $17.99
            if ((itemMarkupPrice > 9.99m) && (itemMarkupPrice < 18.00m))
            {

                if (last2Digits == 0)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                else if ((last2Digits >= 0.01m) && (last2Digits <= 0.05m))
                { itemMarkupPriceRounded = itemMarkupPrice - (last2Digits + 0.01m); }
                else if ((last2Digits > 0.05m) && (last2Digits < 0.19m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.19m - last2Digits); }
                else if (lastDigitvalue == 0)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                else if (lastDigitvalue == 1)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.02m; }
                else if (lastDigitvalue == 2)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.03m; }
                if ((last2Digits > 0.22m) && (last2Digits < 0.29m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.29m - last2Digits); }
                if ((last2Digits > 0.32m) && (last2Digits < 0.39m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.39m - last2Digits); }
                if ((last2Digits > 0.42m) && (last2Digits < 0.49m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.49m - last2Digits); }
                if ((last2Digits > 0.52m) && (last2Digits < 0.59m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.59m - last2Digits); }
                if ((last2Digits > 0.62m) && (last2Digits < 0.69m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.69m - last2Digits); }
                if ((last2Digits > 0.72m) && (last2Digits < 0.79m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.79m - last2Digits); }
                if ((last2Digits > 0.82m) && (last2Digits < 0.99m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.99m - last2Digits); }
                // if ((last2Digits > 0.92m) && (last2Digits < 0.99m))
                //{ itemMarkupPriceRounded = itemMarkupPrice +  (0.99m - last2Digits); }
            }

            //$18.00 - $24.99
            if ((itemMarkupPrice > 17.99m) && (itemMarkupPrice < 25.00m))
            {

                if (last2Digits == 0.00m)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                if ((last2Digits >= 0.01m) && (last2Digits <= 0.09m))
                { itemMarkupPriceRounded = itemMarkupPrice - (last2Digits + 0.01m); }
                if ((last2Digits > 0.09m) && (last2Digits < 0.19m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.19m - last2Digits); }
                if ((last2Digits > 0.19m) && (last2Digits < 0.49m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.49m - last2Digits); }
                if ((last2Digits > 0.49m) && (last2Digits < 0.79m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.79m - last2Digits); }
                if ((last2Digits > 0.79m) && (last2Digits < 0.99m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.99m - last2Digits); }
            }

            //≥  $25.00
            if (itemMarkupPrice > 24.99m)
            {
                if (last2Digits == 0.00m)
                { itemMarkupPriceRounded = itemMarkupPrice - 0.01m; }
                if ((last2Digits >= 0.01m) && (last2Digits <= 0.09m))
                { itemMarkupPriceRounded = itemMarkupPrice - (last2Digits + 0.01m); }
                if ((last2Digits > 0.09m) && (last2Digits < 0.49m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.49m - last2Digits); }
                if ((last2Digits > 0.49m) && (last2Digits < 0.99m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.99m - last2Digits); }

            }


            return itemMarkupPriceRounded;
        }


        //Apply rounding for Markup_Sale_Price
        private static decimal ApplyRoundingForMarkUpSalePrice(decimal itemMarkupSalePrice, decimal itemMarkupSalePriceRounded)
        {


            var salePrice = itemMarkupSalePrice;
            var lastDigitvalue = Decimal.Parse(salePrice.ToString().Last().ToString());

            decimal last2Digits = 0;
            if (salePrice.ToString().IndexOf(".") > 0)
            { last2Digits = Decimal.Parse(salePrice.ToString().Substring(salePrice.ToString().IndexOf("."))); }



            //.50 through .99
            if ((itemMarkupSalePrice > 0.49m) && (itemMarkupSalePrice < 1.00m))
            {
                if (lastDigitvalue == 0)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; ; }
                if (lastDigitvalue == 2 || lastDigitvalue == 4 || lastDigitvalue == 6 || lastDigitvalue == 8)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + 0.01m; }
                if (lastDigitvalue == 1 || lastDigitvalue == 3 || lastDigitvalue == 5 || lastDigitvalue == 7)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice; }

            }

            //$1.00 - $1.99
            if ((itemMarkupSalePrice > 0.99m) && (itemMarkupSalePrice < 2.00m))
            {
                if ((itemMarkupSalePrice == 1.00m) || (itemMarkupSalePrice == 1.01m))
                { itemMarkupSalePriceRounded = 0.99m; }
                else if (lastDigitvalue == 0)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; }
                else if ((lastDigitvalue == 1) || (lastDigitvalue == 2) || (lastDigitvalue == 3) || (lastDigitvalue == 4))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.05m - (lastDigitvalue / 100)); }
                else if ((lastDigitvalue == 6) || (lastDigitvalue == 7) || (lastDigitvalue == 8))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.09m - (lastDigitvalue / 100)); }
            }






            //$2.00 - $4.99
            if ((itemMarkupSalePrice > 1.99m) && (itemMarkupSalePrice < 5.00m))
            {
                if ((itemMarkupSalePrice > 1.99m) && (itemMarkupSalePrice < 2.02m))
                { itemMarkupSalePriceRounded = 1.99m; }
                else if (lastDigitvalue == 0)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; }
                else if ((lastDigitvalue == 1) || (lastDigitvalue == 2) || (lastDigitvalue == 3) || (lastDigitvalue == 4))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.05m - (lastDigitvalue / 100)); }
                else if ((lastDigitvalue == 6) || (lastDigitvalue == 7) || (lastDigitvalue == 8))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.09m - (lastDigitvalue / 100)); }
                if ((itemMarkupSalePrice > 2.99m) && (itemMarkupSalePrice < 3.03m))
                { itemMarkupSalePriceRounded = 2.99m; }
                if ((itemMarkupSalePrice > 3.99m) && (itemMarkupSalePrice < 4.04m))
                { itemMarkupSalePriceRounded = 3.99m; }

            }


            //$5.00 - $9.99
            if ((itemMarkupSalePrice > 4.99m) && (itemMarkupSalePrice < 10.00m))
            {

                if (last2Digits == 0)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; }
                else if ((last2Digits >= 0.01m) && (last2Digits < 0.05m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - (last2Digits + 0.01m); }
                else if ((last2Digits == 0.05m) || (last2Digits == 0.06m) || (last2Digits == 0.07m) || (last2Digits == 0.08m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.09m - last2Digits); }
                else if (lastDigitvalue == 0)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; }
                else if (lastDigitvalue == 1)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.02m; }
                else if ((lastDigitvalue == 2) || (lastDigitvalue == 3) || (lastDigitvalue == 4))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.05m - (lastDigitvalue / 100)); }
                else if ((lastDigitvalue == 6) || (lastDigitvalue == 7) || (lastDigitvalue == 8))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.09m - (lastDigitvalue / 100)); }

            }

            //$10.00 - $17.99
            if ((itemMarkupSalePrice > 9.99m) && (itemMarkupSalePrice < 18.00m))
            {

                if (last2Digits == 0)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; }
                else if ((last2Digits >= 0.01m) && (last2Digits <= 0.05m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - (last2Digits + 0.01m); }
                else if ((last2Digits > 0.05m) && (last2Digits < 0.19m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.19m - last2Digits); }
                else if (lastDigitvalue == 0)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; }
                else if (lastDigitvalue == 1)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.02m; }
                else if (lastDigitvalue == 2)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.03m; }
                if ((last2Digits > 0.22m) && (last2Digits < 0.29m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.29m - last2Digits); }
                if ((last2Digits > 0.32m) && (last2Digits < 0.39m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.39m - last2Digits); }
                if ((last2Digits > 0.42m) && (last2Digits < 0.49m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.49m - last2Digits); }
                if ((last2Digits > 0.52m) && (last2Digits < 0.59m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.59m - last2Digits); }
                if ((last2Digits > 0.62m) && (last2Digits < 0.69m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.69m - last2Digits); }
                if ((last2Digits > 0.72m) && (last2Digits < 0.79m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.79m - last2Digits); }
                if ((last2Digits > 0.82m) && (last2Digits < 0.99m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.99m - last2Digits); }
                // if ((last2Digits > 92) && (last2Digits < 0.99m))
                //{ itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.99m - last2Digits); }
            }

            //$18.00 - $24.99
            if ((itemMarkupSalePrice > 17.99m) && (itemMarkupSalePrice < 25.00m))
            {

                if (last2Digits == 0.00m)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; }
                if ((last2Digits >= 0.01m) && (last2Digits <= 0.09m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - (last2Digits + 0.01m); }
                if ((last2Digits > 0.09m) && (last2Digits < 0.19m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.19m - last2Digits); }
                if ((last2Digits > 0.19m) && (last2Digits < 0.49m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.49m - last2Digits); }
                if ((last2Digits > 0.49m) && (last2Digits < 0.79m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.79m - last2Digits); }
                if ((last2Digits > 0.79m) && (last2Digits < 0.99m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.99m - last2Digits); }
            }

            //≥  $25.00
            if (itemMarkupSalePrice > 24.99m)
            {
                if (last2Digits == 0.00m)
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - 0.01m; }
                if ((last2Digits >= 0.01m) && (last2Digits <= 0.09m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - (last2Digits + 0.01m); }
                if ((last2Digits > 0.09m) && (last2Digits < 0.49m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.49m - last2Digits); }
                if ((last2Digits > 0.49m) && (last2Digits < 0.99m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.99m - last2Digits); }

            }

            return itemMarkupSalePriceRounded;
        }


        //Override rounding for Markup_Price for Meat and Produce Items
        private static decimal ApplyRoundingForMarkUpPriceMeatAndProduceItems(decimal itemMarkupPrice, decimal itemMarkupPriceRounded, int famCode)
        {
            var salePrice = itemMarkupPrice;
            var lastDigitvalue = Decimal.Parse(salePrice.ToString().Last().ToString());

            decimal last2Digits = 0;
            if (salePrice.ToString().IndexOf(".") > 0)
            { last2Digits = Decimal.Parse(salePrice.ToString().Substring(salePrice.ToString().IndexOf("."))); }

            if (((famCode > 210000) && (famCode < 260000)) || ((famCode > 310000) && (famCode < 320000)))
            {
                if ((last2Digits >= 0.00m) && (last2Digits < 0.03m) && (itemMarkupPrice > 0.99m))
                { itemMarkupPriceRounded = itemMarkupPrice - (last2Digits + 0.01m); }
                if ((last2Digits > 0.02m) && (last2Digits <= 0.19m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.19m - last2Digits); }
                if ((last2Digits > 0.19m) && (last2Digits < 0.23m))
                { itemMarkupPriceRounded = itemMarkupPrice - ((lastDigitvalue / 100) + 0.01m); }

                if ((last2Digits > 0.22m) && (last2Digits <= 0.29m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.29m - last2Digits); }
                if ((last2Digits > 0.29m) && (last2Digits < 0.33m))
                { itemMarkupPriceRounded = itemMarkupPrice - ((lastDigitvalue / 100) + 0.01m); }


                if ((last2Digits > 0.32m) && (last2Digits <= 0.39m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.39m - last2Digits); }
                if ((last2Digits > 0.39m) && (last2Digits < 0.43m))
                { itemMarkupPriceRounded = itemMarkupPrice - ((lastDigitvalue / 100) + 0.01m); }

                if ((last2Digits > 0.42m) && (last2Digits <= 0.49m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.49m - last2Digits); }
                if ((last2Digits > 0.49m) && (last2Digits < 0.53m))
                { itemMarkupPriceRounded = itemMarkupPrice - ((lastDigitvalue / 100) + 0.01m); }


                if ((last2Digits > 0.52m) && (last2Digits <= 0.59m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.59m - last2Digits); }
                if ((last2Digits > 0.59m) && (last2Digits < 0.63m))
                { itemMarkupPriceRounded = itemMarkupPrice - ((lastDigitvalue / 100) + 0.01m); }


                if ((last2Digits > 0.62m) && (last2Digits <= 0.69m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.69m - last2Digits); }
                if ((last2Digits > 0.69m) && (last2Digits < 0.73m))
                { itemMarkupPriceRounded = itemMarkupPrice - ((lastDigitvalue / 100) + 0.01m); }

                if ((last2Digits > 0.72m) && (last2Digits <= 0.79m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.79m - last2Digits); }
                if ((last2Digits > 0.79m) && (last2Digits < 0.83m))
                { itemMarkupPriceRounded = itemMarkupPrice - ((lastDigitvalue / 100) + 0.01m); }


                if ((last2Digits > 0.82m) && (last2Digits <= 0.89m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.89m - last2Digits); }
                if ((last2Digits > 0.89m) && (last2Digits < 0.93m))
                { itemMarkupPriceRounded = itemMarkupPrice - ((lastDigitvalue / 100) + 0.01m); }

                if ((last2Digits > 0.92m) && (last2Digits <= 0.99m))
                { itemMarkupPriceRounded = itemMarkupPrice + (0.99m - last2Digits); }
            }

            return itemMarkupPriceRounded;
        }

        //Override rounding for Markup_Sale_Price for Meat and Produce Items        
        private static decimal ApplyRoundingForSalePriceMeatAndProduceItems(decimal itemMarkupSalePrice, decimal itemMarkupSalePriceRounded, int famCode)
        {
            var salePrice = itemMarkupSalePrice;
            var lastDigitvalue = Decimal.Parse(salePrice.ToString().Last().ToString());

            decimal last2Digits = 0;
            if (salePrice.ToString().IndexOf(".") > 0)
            { last2Digits = Decimal.Parse(salePrice.ToString().Substring(salePrice.ToString().IndexOf("."))); }

            if (((famCode > 210000) && (famCode < 260000)) || ((famCode > 310000) && (famCode < 320000)))
            {
                if ((last2Digits >= 0.00m) && (last2Digits < 0.03m) && (itemMarkupSalePrice > 0.99m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - (last2Digits + 0.01m); }
                if ((last2Digits > 0.02m) && (last2Digits <= 0.19m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.19m - last2Digits); }
                if ((last2Digits > 0.19m) && (last2Digits < 0.23m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - ((lastDigitvalue / 100) + 0.01m); }

                if ((last2Digits > 0.22m) && (last2Digits <= 0.29m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.29m - last2Digits); }
                if ((last2Digits > 0.29m) && (last2Digits < 0.33m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - ((lastDigitvalue / 100) + 0.01m); }


                if ((last2Digits > 0.32m) && (last2Digits <= 0.39m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.39m - last2Digits); }
                if ((last2Digits > 0.39m) && (last2Digits < 0.43m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - ((lastDigitvalue / 100) + 0.01m); }

                if ((last2Digits > 0.42m) && (last2Digits <= 0.49m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.49m - last2Digits); }
                if ((last2Digits > 0.49m) && (last2Digits < 0.53m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - ((lastDigitvalue / 100) + 0.01m); }


                if ((last2Digits > 0.52m) && (last2Digits <= 0.59m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.59m - last2Digits); }
                if ((last2Digits > 0.59m) && (last2Digits < 0.63m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - ((lastDigitvalue / 100) + 0.01m); }


                if ((last2Digits > 0.62m) && (last2Digits <= 0.69m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.69m - last2Digits); }
                if ((last2Digits > 0.69m) && (last2Digits < 0.73m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - ((lastDigitvalue / 100) + 0.01m); }

                if ((last2Digits > 0.72m) && (last2Digits <= 0.79m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.79m - last2Digits); }
                if ((last2Digits > 0.79m) && (last2Digits < 0.83m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - ((lastDigitvalue / 100) + 0.01m); }


                if ((last2Digits > 0.82m) && (last2Digits <= 0.89m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.89m - last2Digits); }
                if ((last2Digits > 0.89m) && (last2Digits < 0.93m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice - ((lastDigitvalue / 100) + 0.01m); }

                if ((last2Digits > 0.92m) && (last2Digits <= 0.99m))
                { itemMarkupSalePriceRounded = itemMarkupSalePrice + (0.99m - last2Digits); }
            }

            return itemMarkupSalePriceRounded;
        }


        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            throw new NotImplementedException();
        }



        #endregion
    }

    public static class MarkupExtensions
    {



        public static decimal lastDigitvalue(this decimal salePrice)
        {
            return Decimal.Parse(salePrice.ToString().Last().ToString());
        }


        public static decimal last2Digits(this decimal salePrice)
        {
            decimal last2Digits = 0;
            if (salePrice.ToString().IndexOf(".") > 0)
            { last2Digits = Decimal.Parse(salePrice.ToString().Substring(salePrice.ToString().IndexOf("."))); }

            return last2Digits;

        }

    }
}




////.50 through .99
//storedata.Where(i => i.Value.MARKUP_PRICE > 0.49 && i.Value.MARKUP_PRICE< 1.00 && i.Value.MARKUP_PRICE.lastDigitvalue() == 0).ToList().ForEach(i => { i.Value.MARKUP_PRICE_ROUNDED = i.Value.MARKUP_PRICE - 0.01; });
//            storedata.Where(i => i.Value.MARKUP_PRICE > 0.49 && i.Value.MARKUP_PRICE< 1.00 && (i.Value.MARKUP_PRICE.lastDigitvalue() == 2 || i.Value.MARKUP_PRICE.lastDigitvalue() == 4 || i.Value.MARKUP_PRICE.lastDigitvalue() == 6 || i.Value.MARKUP_PRICE.lastDigitvalue() == 8)).ToList()
//                                                                                                                                                     .ForEach(i => { i.Value.MARKUP_PRICE_ROUNDED = i.Value.MARKUP_PRICE + 0.01; });
//            storedata.Where(i => i.Value.MARKUP_PRICE > 0.49 && i.Value.MARKUP_PRICE< 1.00 && (i.Value.MARKUP_PRICE.lastDigitvalue() == 1 || i.Value.MARKUP_PRICE.lastDigitvalue() == 3 || i.Value.MARKUP_PRICE.lastDigitvalue() == 5 || i.Value.MARKUP_PRICE.lastDigitvalue() == 7)).ToList()
//                                                                                                                                         .ForEach(i => { i.Value.MARKUP_PRICE_ROUNDED = i.Value.MARKUP_PRICE; });

