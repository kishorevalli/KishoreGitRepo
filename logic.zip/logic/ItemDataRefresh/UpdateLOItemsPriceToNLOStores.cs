﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class UpdateLOItemsPriceToNLOStores : ItemDataAbstract
    {
        internal UpdateLOItemsPriceToNLOStores(IItemDataRefreshDac dac, string jobname)
            : base(dac, jobname)
        {
        }

  
        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {

            var processingStore = ProcessingStores.FirstOrDefault(s => s.StoreNumber == storenumber);

            if (processingStore.LOStore != null)
            {
                var prgItems = LOStoreProgramItems.FirstOrDefault(p => p.Key == processingStore.ProgramId).Value;

                if (prgItems.Any(i => i == itemData.RETAILER_REFERENCE_CODE))
                {
                    var lo_str_itm_prices = LOStorePrices.FirstOrDefault(l => l.Key == processingStore.LOStore).Value;
                    var lo_itm_price = lo_str_itm_prices.FirstOrDefault(i => i.ItemId == itemData.RETAILER_REFERENCE_CODE);

                    if (lo_itm_price != null)
                    {
                        itemData.UNIT_RETAIL_PRICE = lo_itm_price.UnitRetailPrice > itemData.UNIT_RETAIL_PRICE ? lo_itm_price.UnitRetailPrice : itemData.UNIT_RETAIL_PRICE;
                        itemData.UNIT_SALE_PRICE = lo_itm_price.UnitSalePrice > itemData.UNIT_SALE_PRICE ? lo_itm_price.UnitSalePrice : itemData.UNIT_SALE_PRICE;
                    }

                }
            }
            else
            {
                itemData.NLO_UNIT_RETAIL_PRICE = null;
                itemData.NLO_UNIT_SALE_PRICE = null;
            }
        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            throw new NotImplementedException();
        }
    }
}
