﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class InsertItemData : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;

        public InsertItemData(IItemDataRefreshDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {
            throw new NotImplementedException();
        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            throw new NotImplementedException();
        }
    }
}
