﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class UpdatePIMSAttributes : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;
        readonly IItemImportFromPimsDac _itmdac;

        public UpdatePIMSAttributes(IItemDataRefreshDac dac, string jobname, IEnumerable<int> noImageURLFmlyGrps, IEnumerable<ItemDetailsDTO> itemdetails) : base(dac, jobname, noImageURLFmlyGrps, itemdetails)
        {
            _dac = dac;
        }

        public UpdatePIMSAttributes(IItemImportFromPimsDac dac, string jobname, IEnumerable<int> noImageURLFmlyGrps, IEnumerable<ItemDetailsDTO> itemdetails) : base(dac, jobname, noImageURLFmlyGrps, itemdetails)
        {
            _itmdac = dac;
        }

        //internal async override Task Process(IDictionary<decimal, ItemDTO> itemdata)
        //{
        //    var task1 = ExcludeItemsWithZeroUnitRetailPrice(itemdata);
        //    var task2 = ExcludeItemsWithZeroUnitRetailPriceFroAlcohol(itemdata);


        //    Task.WaitAll(task1, task2);
        //}


        //async Task ExcludeItemsWithZeroUnitRetailPrice(IDictionary<ItemKeyDTO, ItemDTO> itemdata)
        //{
        //    //var coll = itemdata.Where(i => i.UNIT_RETAIL_PRICE == 0).ToList();

        //    //foreach (var item in coll)
        //    //{
        //    //    item.EXCLUDE_FROM_FILE = true;
        //    //}
        //}

        //async Task ExcludeItemsWithZeroUnitRetailPriceFroAlcohol(IDictionary<ItemKeyDTO, ItemDTO> itemdata)
        //{
        //    //var coll = itemdata.Where(i => i.ALCOHOLIC.Equals("TRUE") && i.UNIT_RETAIL_PRICE == (decimal)0.02 && i.UNIT_SALE_PRICE == 0).ToList();

        //    //foreach (var item in coll)
        //    //{
        //    //    item.EXCLUDE_FROM_FILE = true;
        //    //}

        //    //coll = itemdata.Where(i => i.ALCOHOLIC.Equals("TRUE") && i.UNIT_RETAIL_PRICE == (decimal)0.02 && i.UNIT_SALE_PRICE > (decimal)0.02).ToList();

        //    //foreach (var item in coll)
        //    //{
        //    //    item.UNIT_RETAIL_PRICE = item.UNIT_SALE_PRICE;
        //    //}
        //}


        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {

            var itemdet = ItemDetails.FirstOrDefault(i => i.ItemId == itemData.RETAILER_REFERENCE_CODE);

            if (itemdet != null)
            {

                if (itemData.UNIT_RETAIL_PRICE == 0) { itemData.EXCLUDE_FROM_FILE = true; }


                if (itemdet.Alcoholic == "TRUE" && itemData.UNIT_RETAIL_PRICE == 0.02m && itemData.UNIT_SALE_PRICE == 0) { itemData.EXCLUDE_FROM_FILE = true; }
                if (itemdet.Alcoholic == "TRUE" && itemData.UNIT_RETAIL_PRICE == 0.02m && itemData.UNIT_SALE_PRICE > 0.02m) { itemData.UNIT_RETAIL_PRICE = itemData.UNIT_SALE_PRICE; }
            }

            //Update Brand Name
            //if (itemData.BRAND_NAME.Trim() == "N/A") { itemData.BRAND_NAME = ""; }
            //if (itemData.BRAND_NAME.Trim() == "PUBLIX") { itemData.BRAND_NAME = "Publix"; }
            //if (itemData.BRAND_NAME.Trim() == "PUBLIX BAKER") { itemData.BRAND_NAME = "Publix Bakery"; }
            //if (itemData.BRAND_NAME.Trim() == "PUBLIX BRAND") { itemData.BRAND_NAME = "Publix"; }
            //if (itemData.BRAND_NAME.Trim() == "PUBLIX DELI") { itemData.BRAND_NAME = "Publix Deli"; }
            //if (itemData.BRAND_NAME.Trim() == "PUBLIX GREEN") { itemData.BRAND_NAME = "Publix GreenWise"; }
            //if (itemData.BRAND_NAME.Trim() == "PUBLIX PREMI") { itemData.BRAND_NAME = "Publix Premium"; }


            //var removeimgUrlStorelist = SystemValues.GetValue<String>("RemoveImageURLStoreList").Split(',').ToList().Select(int.Parse).ToList();
            //if (removeimgUrlStorelist.Any(s => s == storenumber))
            //{
            //    if (NoImgFmlyGrps.Any(x => x == itemData.FAM_CODE))
            //    {
            //        itemData.REMOTE_IMAGE_URL = "";
            //    }

            //}
        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            //Update Brand Name
            if (itemdetails.BrandName.Trim() == "N/A") { itemdetails.BrandName = ""; }
            if (itemdetails.BrandName.Trim() == "PUBLIX") { itemdetails.BrandName = "Publix"; }
            if (itemdetails.BrandName.Trim() == "PUBLIX BAKER") { itemdetails.BrandName = "Publix Bakery"; }
            if (itemdetails.BrandName.Trim() == "PUBLIX BRAND") { itemdetails.BrandName = "Publix"; }
            if (itemdetails.BrandName.Trim() == "PUBLIX DELI") { itemdetails.BrandName = "Publix Deli"; }
            if (itemdetails.BrandName.Trim() == "PUBLIX GREEN") { itemdetails.BrandName = "Publix GreenWise"; }
            if (itemdetails.BrandName.Trim() == "GREENWISE") { itemdetails.BrandName = "GreenWise"; }
            if (itemdetails.BrandName.Trim() == "PUBLIX PREMI") { itemdetails.BrandName = "Publix Premium"; }

        }
    }
}
