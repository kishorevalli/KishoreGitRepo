﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using System.Net.Http;
using System.Configuration;
using System.Net.Http.Headers;
using System.Collections.Concurrent;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class BalanceOnHandCheckForItems : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;

        public BalanceOnHandCheckForItems(IItemDataRefreshDac dac, string jobname, IEnumerable<int> zeroBOHStores) : base(dac, jobname, zeroBOHStores)
        {
            _dac = dac;
        }

        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {

            var _mongoItems = PublixProStoreItems.FirstOrDefault(s => s.Key == storenumber).Value;

            if (_mongoItems != null)
            {
                var bohItemDetails = _mongoItems.FirstOrDefault(mi => mi.Key == itemData.RETAILER_REFERENCE_CODE);

                if (bohItemDetails.Value != null)
                {
                    if (bohItemDetails.Value.Boh == 0 && !ZeroBOHStores.Any(s => s == storenumber))
                        itemData.EXCLUDE_FROM_FILE = true;

                    itemData.BOH_Ind = bohItemDetails.Value.bohFlag;
                    itemData.BOH = bohItemDetails.Value.Boh;
                    itemData.BOHLastUpdatedDT = bohItemDetails.Value.bohLastUpdate;
                }
            }
        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            throw new NotImplementedException();
        }
    }

}




