﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class EnableLiquorItems : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;

        public EnableLiquorItems(IItemDataRefreshDac dac, string jobname, IEnumerable<int> liquorFamilyGrps, IEnumerable<int> nonLiquorStores) : base(dac, jobname, "Liquor", liquorFamilyGrps, nonLiquorStores)
        {
            _dac = dac;
        }

        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {
            if (NonLiquorStores.Any(i => i == itemData.STORE_IDENTIFIER))
            {
                if (LiquorFamilyGrps.Any(fg => fg == itemData.FAM_CODE))
                    itemData.EXCLUDE_FROM_FILE = true;
            }
        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            throw new NotImplementedException();
        }
    }
}
