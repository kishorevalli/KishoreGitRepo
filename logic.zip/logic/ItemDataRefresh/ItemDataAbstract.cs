﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using System.Collections.Concurrent;
using Publix.S0OMNIXX.OmniItemDataUtilities;
using System.Net.Http;
using System.Configuration;
using System.Net.Http.Headers;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class ItemDataAbstract : Common
    {
        static IItemDataRefreshDac _dac;
        static IItemImportFromPimsDac _itmdac;
        protected static object sync = new object();
        static string _jobname;

        protected ItemDataAbstract(IItemDataRefreshDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
            _jobname = jobname;
            BohFailureCnt = 0;
            PublixProStoreItems = new ConcurrentDictionary<int, IDictionary<int, MongoItemsDTO>>();
        }


        protected ItemDataAbstract(IItemDataRefreshDac dac, string jobname, IEnumerable<int> zeroBOHStores) : base(dac, jobname)
        {
            _dac = dac;
            _jobname = jobname;
            ZeroBOHStores = zeroBOHStores;
        }

        protected ItemDataAbstract(IItemDataRefreshDac dac, string jobname, IEnumerable<int> alcholFmlyGrps, IEnumerable<int> nonAlcoholStores) : base(dac, jobname)
        {
            _dac = dac;
            AlcoholFamilyGrps = alcholFmlyGrps;
            NonAlcoholStores = nonAlcoholStores;
        }

        protected ItemDataAbstract(IItemDataRefreshDac dac, string jobname, string type, IEnumerable<int> liquorFamilyGrps, IEnumerable<int> nonLiquorStores) : base(dac, jobname)
        {
            _dac = dac;
            LiquorFamilyGrps = liquorFamilyGrps;
            NonLiquorStores = nonLiquorStores;
            var _liquor = type;
        }

        protected ItemDataAbstract(IItemDataRefreshDac dac, string jobname, IEnumerable<ItemOverrideDTO> overrideItems) : base(dac, jobname)
        {
            _dac = dac;
            OverrideItems = overrideItems;

        }

        protected ItemDataAbstract(IItemImportFromPimsDac dac, string jobname, IEnumerable<ItemOverrideDTO> overrideItems) : base(dac, jobname)
        {
            _itmdac = dac;
            OverrideItems = overrideItems;

        }

        protected ItemDataAbstract(IItemImportFromPimsDac dac, string jobname, IEnumerable<ProductCataglogItemDTO> idmProductCatalog, IEnumerable<int> alcholFmlyGrps, IEnumerable<int> liquorFamilyGrps) : base(dac, jobname)
        {
            _itmdac = dac;
            IdmProductCatalog = idmProductCatalog;
            AlcoholFamilyGrps = alcholFmlyGrps;
            LiquorFamilyGrps = liquorFamilyGrps;
        }

        protected ItemDataAbstract(IItemDataRefreshDac dac, string jobname, IEnumerable<int> noImgFmlyGrps, IEnumerable<ItemDetailsDTO> itemdetails) : base(dac, jobname)
        {
            _dac = dac;
            NoImgFmlyGrps = noImgFmlyGrps;
            ItemDetails = itemdetails;
        }

        protected ItemDataAbstract(IItemImportFromPimsDac dac, string jobname, IEnumerable<int> noImgFmlyGrps, IEnumerable<ItemDetailsDTO> itemdetails) : base(dac, jobname)
        {
            _itmdac = dac;
            NoImgFmlyGrps = noImgFmlyGrps;
            ItemDetails = itemdetails;
        }


        protected ItemDataAbstract(IItemDataRefreshDac dac, string jobname, IEnumerable<POSTaxPlanRateDTO> posTaxRates) : base(dac, jobname)
        {
            _dac = dac;
            PosTaxRates = posTaxRates;

        }

        //internal static IEnumerable<ItemStorePriceDTO> LOStoreDetails { get; set; }
        //internal static IEnumerable<ProgramStoreMapDTO> ProgramStoreMapDetails { get; set; }
        //internal static List<ItemProgramDTO> ItemProgramDetails { get; set; }

        protected static ConcurrentDictionary<int, IEnumerable<int>> LOStoreProgramItems { get; set; }

        protected static ConcurrentDictionary<int, IEnumerable<ItemLoStorePriceDTO>> LOStorePrices { get; set; }

        protected static IEnumerable<int> AlcoholFamilyGrps { get; set; }
        protected static IEnumerable<int> NonAlcoholStores { get; set; }
        protected static IEnumerable<int> ZeroBOHStores { get; set; }
        protected static IEnumerable<int> NonLiquorStores { get; set; }
        protected static IEnumerable<int> LiquorFamilyGrps { get; set; }
        protected static IEnumerable<ItemOverrideDTO> OverrideItems { get; set; }
        protected static IEnumerable<ProductCataglogItemDTO> IdmProductCatalog { get; set; }
        protected static IEnumerable<POSTaxPlanRateDTO> PosTaxRates { get; set; }
        internal static IEnumerable<ItemDetailsDTO> ItemDetails { get; set; }
        protected static int BohFailureCnt { get; set; }
        internal static ConcurrentDictionary<int, IDictionary<int, MongoItemsDTO>> PublixProStoreItems { get; set; }
        protected static IEnumerable<InstStoreDTO> ProcessingStores { get; set; }
        protected static IEnumerable<int> NoImgFmlyGrps { get; set; }
        internal abstract void ProcessByItem(int storenumber, ItemDataDTO itemData);
        internal abstract void UpdateItemDetails(ItemDetailsDTO itemdetails);

        internal async static Task InsertItemDetails()
        {
            await _itmdac.TruncateItemDetailsStaging();
            await _itmdac.InsertItemDetails(ItemDetails, new ItemDetailsDTO().GetPropertyMembers());
            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipItemDetailsMove))
            {
                await _itmdac.MoveItemDetailsToMain();
                await _itmdac.TruncateItemDetailsStaging();
            }
        }

        internal static void ResetBohCollection()
        {

            PublixProStoreItems = new ConcurrentDictionary<int, IDictionary<int, MongoItemsDTO>>();

        }

        public async static Task InsertStoreItemData(string storenumbers, IEnumerable<ItemDataDTO> storedata)
        {

            await _dac.InsertStoreItemData(storenumbers, storedata, new ItemDataDTO().GetPropertyMembers());

        }

        public async static Task InsertItemData(ItemDataDTO itemdata)
        {

            await _dac.InsertItemData(itemdata);

        }

        internal static void Initialize(IEnumerable<InstStoreDTO> stores, ConcurrentDictionary<int, IEnumerable<int>> loStrPrgitems, ConcurrentDictionary<int, IEnumerable<ItemLoStorePriceDTO>> loStrPrcs)
        {
            ProcessingStores = stores;
            LOStoreProgramItems = loStrPrgitems;
            LOStorePrices = loStrPrcs;

        }


        internal static void GetBohForStores(IEnumerable<StoreDTO> storenumbers)
        {

            // logBO.Info(storenumber + " BOH Process - Start");
            var MaxCountForBOHSkip = SystemValues.GetValue<int>(Constants.SystemValues.MaxCountForBOHSkip);
            var NoOfStoresForBohParallel = SystemValues.GetValue<int>(Constants.SystemValues.NoOfStoresForBohParallel);
            var maxdegreeOfParallelismStoreProcessing = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismStoreProcessing);

            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipBOHItemMobileUpdates))
            {
                var itemsToNotSendInFile = new List<MongoItemsExclude>();


                using (var client = new HttpClient(new HttpClientHandler { UseDefaultCredentials = true }))
                {
                    logBO.Info(_jobname + " - Attempting  to create client connection to mongo");
                    //client.BaseAddress = new Uri("http://localhost:18508/");
                    var endpoint = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-MongoEndpoint"];
                    client.BaseAddress = new Uri(endpoint.ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.Timeout = TimeSpan.FromMinutes(NoOfStoresForBohParallel * 10);

                    List<StoreDTO> _bohStores = new List<StoreDTO>();
                    var bohStores = string.Empty;

                    for (int i = 0; i < storenumbers.Count(); i++)
                    {
                        if (storenumbers.ElementAt(i).BOHActive)
                        {
                            _bohStores.Add(storenumbers.ElementAt(i));
                            logBO.Info(_jobname + " - BOH call queued for Store: " + storenumbers.ElementAt(i).StoreNumber);
                        }
                        else
                        {
                            logBO.Info(_jobname + " - Skipping BOH call, BOH is Inactive for Store: " + storenumbers.ElementAt(i).StoreNumber);
                        }

                        if (((i + 1) % NoOfStoresForBohParallel == 0) || (i == (storenumbers.Count() - 1)))
                        {
                            _bohStores.AsParallel().WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                                .WithMergeOptions(ParallelMergeOptions.NotBuffered)
                                .WithDegreeOfParallelism(maxdegreeOfParallelismStoreProcessing)
                                .ForAll(
                                store =>
                                {
                                    RetriveBohForStoreFromService(MaxCountForBOHSkip, client, store);
                                });
                            _bohStores = new List<StoreDTO>();
                        }
                    }
                }
            }

            // logBO.Info(storenumber + " BOH Process - End");                                                            l
            //           throw new NotImplementedException();

        }

        private static void RetriveBohForStoreFromService(int MaxCountForBOHSkip, HttpClient client, StoreDTO _store)
        {
            if (BohFailureCnt <= MaxCountForBOHSkip)
            {

                try
                {
                    //get the items from mongo service for the store we are on                          
                    // example for test: http://tminva01.publix.com/itemdetail/api/item?store=1271
                    var response = client.GetAsync("api/item?store=" + _store.StoreNumber.ToString()).Result;
                    //   var response = await client.GetAsync("http://tminva01.publix.com/itemdetail/api/item?store=1271");

                    if (response.IsSuccessStatusCode)
                    {
                        logBO.Info(_jobname + " - made the mongo call - success: " + response.IsSuccessStatusCode);
                        //var mongoItems = response.Content.ReadAsAsync<IEnumerable<MongoItemsDTO>>().Result;

                        var result = response.Content.ReadAsAsync<IEnumerable<MongoItemsDTO>>().Result;
                        var mongoItems = result.ToDictionary(x => x.Sku, x => x);

                        PublixProStoreItems.TryAdd(_store.StoreNumber, mongoItems);
                    }
                    else
                    {
                        //response.EnsureSuccessStatusCode();                                
                        logBO.Info(_jobname + " - Error - BOH Service - " + _store.StoreNumber + " - " + response.StatusCode.ToString());
                    }

                }
                catch (Exception ex)
                {
                    lock (sync) BohFailureCnt++;
                    logBO.Info(_jobname + " - Error - BOH Service - " + _store.StoreNumber + " - " + ex);
                }

            }
            else
            {
                logBO.Info(_jobname + " - Max no. of BOH failures, BOH Skipping for this store : " + _store.StoreNumber);
            }
        }
    }
}
