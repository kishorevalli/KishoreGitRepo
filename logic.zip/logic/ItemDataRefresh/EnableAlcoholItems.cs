﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class EnableAlcoholItems : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;

        public EnableAlcoholItems(IItemDataRefreshDac dac, string jobname, IEnumerable<int> alcholFmlyGrps, IEnumerable<int> nonAlcoholStores) : base(dac, jobname, alcholFmlyGrps, nonAlcoholStores)
        {
            _dac = dac;
        }

        internal  override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {
            
            if (NonAlcoholStores.Any(i => i == itemData.STORE_IDENTIFIER))
            {
                if (AlcoholFamilyGrps.Any(fg => fg == itemData.FAM_CODE))
                    itemData.EXCLUDE_FROM_FILE = true;
            }

            
        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            throw new NotImplementedException();
        }
    }
}
