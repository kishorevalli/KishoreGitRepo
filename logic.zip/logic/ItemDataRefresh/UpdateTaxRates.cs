﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class UpdateTaxRates : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;
        protected static List<int> panamacityStores;
        public UpdateTaxRates(IItemDataRefreshDac dac, string jobname, IEnumerable<POSTaxPlanRateDTO> posTaxRates) : base(dac, jobname, posTaxRates)
        {
            _dac = dac;
            panamacityStores = SystemValues.GetValue<String>(Constants.SystemValues.PanamaCityStores).Split(',').ToList().Select(int.Parse).ToList();
        }
        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {


            var rate = PosTaxRates.FirstOrDefault(t => (t.EffectiveDate <= itemData.ITEM_LOAD_DATE
                                                        && t.TerminationDate >= itemData.ITEM_LOAD_DATE)
                                                        && (t.TaxPlan1 > 0 || t.TaxPlan2 > 0 || t.TaxPlan3 > 0)
                                                        && t.StoreID == storenumber);
            string IsAlcoholic = ItemDetails.FirstOrDefault(i => i.ItemId == itemData.RETAILER_REFERENCE_CODE).Alcoholic.ToLower();


            if (panamacityStores.Any(x => x == storenumber))
            {
                itemData.TAXABLE_RATE = rate.TaxPlan1;
            }
            else
            {

                if (itemData.TAX_PLAN_1 && !itemData.TAX_PLAN_2 && !itemData.TAX_PLAN_3 && storenumber == rate.StoreID) { itemData.TAXABLE_RATE = rate.TaxPlan1; }
                if (!itemData.TAX_PLAN_1 && itemData.TAX_PLAN_2 && !itemData.TAX_PLAN_3 && storenumber == rate.StoreID)
                {
                    itemData.TAXABLE_RATE = rate.TaxPlan2;
                }
                if (!itemData.TAX_PLAN_1 && !itemData.TAX_PLAN_2 && itemData.TAX_PLAN_3 && storenumber == rate.StoreID) { itemData.TAXABLE_RATE = rate.TaxPlan3; }
                if (itemData.TAX_PLAN_1 && itemData.TAX_PLAN_2 && !itemData.TAX_PLAN_3 && storenumber == rate.StoreID)
                {
                    itemData.TAXABLE_RATE = (rate.TaxPlan1 + rate.TaxPlan2);
                }
                if (!itemData.TAX_PLAN_1 && itemData.TAX_PLAN_2 && itemData.TAX_PLAN_3 && storenumber == rate.StoreID)
                { itemData.TAXABLE_RATE = (rate.TaxPlan2 + rate.TaxPlan3); }
            }


            //itemData.TAX_PLAN_1_RATE = itemData.TAX_PLAN_1 ? rate.TaxPlan1 : 0;
            //itemData.TAX_PLAN_2_RATE = itemData.TAX_PLAN_2 ? rate.TaxPlan2 : 0;
            //itemData.TAX_PLAN_3_RATE = itemData.TAX_PLAN_3 ? rate.TaxPlan3 : 0;


        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            throw new NotImplementedException();
        }
    }
}
