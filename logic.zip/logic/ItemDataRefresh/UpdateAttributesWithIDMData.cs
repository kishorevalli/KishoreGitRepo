﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class UpdateAttributesWithIDMData : ItemDataAbstract
    {
        readonly IItemImportFromPimsDac _itmDac;

        public UpdateAttributesWithIDMData(IItemImportFromPimsDac dac, string jobname, IEnumerable<ProductCataglogItemDTO> idmProductCatalog, IEnumerable<int> alcholFmlyGrps, IEnumerable<int> liquorFamilyGrps) : base(dac, jobname, idmProductCatalog, alcholFmlyGrps, liquorFamilyGrps)
        {
            _itmDac = dac;
        }

        internal override void ProcessByItem(int storenumber, ItemDataDTO itemData)
        {


            //var anyIdmData = IdmProductCatalog.FirstOrDefault(i => i.ItemCode == itemData.RETAILER_REFERENCE_CODE);

            //if (anyIdmData != null)
            //{
            //    itemData.ITEM_NAME = anyIdmData.Title;
            //    itemData.RETAIL_PACKAGE_SIZE = anyIdmData.SizeDescription;

            //    //Update the department -all items except alcohol items

            //    if ((AlcoholFamilyGrps.Any(afg => afg == itemData.FAM_CODE)) || (LiquorFamilyGrps.Any(afg => afg == itemData.FAM_CODE)))
            //    {

            //    }
            //    else { itemData.DEPARTMENT = anyIdmData.Department; }
            //}

        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            var anyIdmData = IdmProductCatalog.FirstOrDefault(i => i.ItemCode == itemdetails.ItemId);

            if (anyIdmData != null)
            {
                itemdetails.ItemName = anyIdmData.Title;
                itemdetails.RetailPackageSize = anyIdmData.SizeDescription;

                //Update the department -all items except alcohol items

                if ((AlcoholFamilyGrps.Any(afg => afg == itemdetails.FamilyCode)) || (LiquorFamilyGrps.Any(afg => afg == itemdetails.FamilyCode)))
                {

                }
                else { itemdetails.Department = anyIdmData.Department; }
            }
        }
    }
}
