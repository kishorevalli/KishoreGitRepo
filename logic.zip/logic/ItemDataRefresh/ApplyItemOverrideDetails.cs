﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ApplyItemOverrideDetails : ItemDataAbstract
    {
        readonly IItemDataRefreshDac _dac;
        readonly IItemImportFromPimsDac _itmDac;

        public ApplyItemOverrideDetails(IItemDataRefreshDac dac, string jobname, IEnumerable<ItemOverrideDTO> overrideItems) : base(dac, jobname, overrideItems)
        {
            _dac = dac;
        }

        public ApplyItemOverrideDetails(IItemImportFromPimsDac dac, string jobname, IEnumerable<ItemOverrideDTO> overrideItems) : base(dac, jobname, overrideItems)
        {
            _itmDac = dac;
        }
     

        internal  override void ProcessByItem(int storenumber,  ItemDataDTO itemData)
        {
            //var anyFdaItem = OverrideItems.FirstOrDefault(o => o.IsFDAMenuLabel && o.ItemId == itemData.RETAILER_REFERENCE_CODE);
            //if (anyFdaItem != null)
            //{
            //    itemData.ITEM_NAME = anyFdaItem.ItemName;
            //    itemData.ITEM_DETAILS = anyFdaItem.ItemDetails;
            //    itemData.BRAND_NAME = anyFdaItem.BrandName;
            //}


            var anyExcludeItem = OverrideItems.FirstOrDefault(o => o.IsExcludeItem && o.ItemId == itemData.RETAILER_REFERENCE_CODE);
            if (anyExcludeItem != null)
            {
                itemData.EXCLUDE_FROM_FILE = true;
            }
        }

        internal override void UpdateItemDetails(ItemDetailsDTO itemdetails)
        {
            var anyFdaItem = OverrideItems.FirstOrDefault(o => o.IsFDAMenuLabel && o.ItemId == itemdetails.ItemId);
            if (anyFdaItem != null)
            {
                itemdetails.ItemName = anyFdaItem.ItemName;
                itemdetails.ItemDetails = anyFdaItem.ItemDetails;
                itemdetails.BrandName = anyFdaItem.BrandName;
            }
        }
    }
}
