﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataBO.Contracts;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Newtonsoft;
using System.IO.Compression;
using Publix.S0OMNIXX.OmniItemDataBO;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExportItemData : Common, IExportItemData
    {
        private readonly IExportItemDataDac _dac;

        public ExportItemData(IExportItemDataDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
        }

        public async Task GenerateItemDataCsvForStores()
        {
            var envMachinename = Environment.MachineName;

            var jobMachineIdentifier = SystemParameters.GetValue(Constants.SystemParameters.JobMachineIdentifier);
            var waitTimeJobFromServer2 = SystemValues.GetValue<int>(Constants.SystemValues.WaitTimeForJobInMinutes);
            if (string.Equals(envMachinename.ToUpper(), jobMachineIdentifier.ToUpper())) await Task.Delay(TimeSpan.FromMinutes(waitTimeJobFromServer2));


            logBO.Info(jobname + "- CreateIndexItemDataExportStagingStoreExcludeFile - Start");
            await _dac.CreateIndexItemDataExportStagingStoreExcludeFile();
            logBO.Info(jobname + "- CreateIndexItemDataExportStagingStoreExcludeFile - End");

            var noOfStoresProcessing = SystemValues.GetValue<int>(Constants.SystemValues.NoOfStoresForProcessing);


            var exportitemdataFactory = new ExportItemDataFactory(_dac, jobname);


            var itemloaddate = await _dac.GetItemLoadDate();
            await _dac.ResetReProcessingForFileGeneration();
            ExportItemDataFactory.CleanUpArchive();
            bool isValid = true;

            while (true)
            {
                var storeFileVersions = await _dac.GetStoreFileVersionDetails((int)Constants.ProcessingType.StoreComplete, (int)Constants.ProcessingType.FileGenerateInProgress, noOfStoresProcessing, envMachinename);
                if (storeFileVersions == null || storeFileVersions.Count() == 0) break;

                foreach (var str in storeFileVersions)
                {

                    isValid = exportitemdataFactory.IsFlagEnabled(str.FileVersionID, str.IsLiquorEnabled, str.IsSpecialtyEnabled, str.IsB2BEnabled);

                    if (isValid)
                    {
                        logBO.Info(jobname + "- Generate " + str.FileVersionName + " File for Store:" + str.StoreNumber + " - Start");

                        var expItmExtract = exportitemdataFactory.GetWriteToFileFormat(str.FileVersionID);

                        expItmExtract.Initialize(str, itemloaddate);

                        if (await expItmExtract.WriteToFile(str) > 0)
                        {
                            await expItmExtract.UpdateFileGenerate(str.StoreNumber, (int)Constants.ProcessingType.FileGenerateComplete);
                            expItmExtract.Compress();
                        }

                        logBO.Info(jobname + "- Generate " + str.FileVersionName + " File for Store:" + str.StoreNumber + " - End");
                    }
                    else
                    {
                        logBO.Info(jobname + "- Can not generate " + str.FileVersionName + " File for Store:" + str.StoreNumber + " as flag is disabled - End");
                    }
                }

            }
            logBO.Info(jobname + "- DropIndexItemDataExportStagingStoreExcludeFile - Start");
            await _dac.DropIndexItemDataExportStagingStoreExcludeFile();
            logBO.Info(jobname + "- DropIndexItemDataExportStagingStoreExcludeFile - End");
        }
    }
}

