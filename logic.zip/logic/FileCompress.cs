﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;
using System.Text.RegularExpressions;
using System.IO;
using System.Configuration;
using System.IO.Compression;
using System.Threading;
using System;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class FileCompress : Common, IFileCompress
    {

        readonly IFileCompressDac  _dac;
        public static string archiveDirectory = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-InputFilePathArchive"];

       

        public FileCompress(IFileCompressDac dac, string jobname)
            : base(dac, jobname)
        {
            _dac = dac;
        }
        public async Task FileCompressAsync()
        {
            logBO.Info(jobname + "- FileCompression - start");

            var fileTypes = await _dac.GetFileType();
            var MaxDegreeOfParallelismForCompression = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismForCompression);
            Parallel.ForEach(fileTypes,new ParallelOptions {MaxDegreeOfParallelism = MaxDegreeOfParallelismForCompression }, (currentFile) =>
             {
                 logBO.Info(jobname + "- FileCompression for file " + currentFile.Type + " - start");
                 CompressTheFile(archiveDirectory, currentFile.Type, currentFile.NamingConvention);
                 logBO.Info(jobname + "- FileCompression for file " + currentFile.Type + " - End");
             });

        }

        public static void CompressTheFile(string directoryPath, string fileType, string fileNamingConvention)
        {
            FileInfo[] dailyfiles = new DirectoryInfo(directoryPath).GetFiles(fileNamingConvention);
            var csvFiles = dailyfiles.ToList().Where(x => x.FullName.Contains(".csv")).ToList();

            if (csvFiles.Count > 0)
            {
                DateTime Mindate = csvFiles.ToList().Min(x => x.LastWriteTime);
                DateTime Maxdate = csvFiles.ToList().Max(x => x.LastWriteTime);

                TimeSpan dif = Maxdate - Mindate;
                //day wise compress



                for (int i = 0; i <= dif.Days + 1; i++)
                {
                    DateTime selectdate = Mindate.AddDays(i);
                    //Directory.CreateDirectory(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy")));

                    if (csvFiles.ToList().Where(x => x.LastWriteTime.Date == selectdate.Date).ToList().Count > 0)
                    {

                        Directory.CreateDirectory(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy")));
                        csvFiles.ToList().Where(x => x.LastWriteTime.Date == selectdate.Date).ToList().ForEach(y => y.MoveTo(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), "\\", y.Name)));
                        if (File.Exists(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), ".zip")))
                        {
                            File.Delete(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), ".zip"));
                        }
                        ZipFile.CreateFromDirectory(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), "\\"), string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), ".zip"));
                        if (File.Exists(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), ".zip")))
                        {
                            File.SetLastWriteTime(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), ".zip"), selectdate);
                        }
                        new DirectoryInfo(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), "\\")).GetFiles("*.zip").ToList().ForEach(y => y.Delete());
                        Directory.Delete(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-dd-yyyy"), "\\"), true);
                        //Thread.Sleep(1000);
                    }
                }

                for (int i = 0; i <= dif.Days + 1; i++)
                {
                    DateTime selectdate = Mindate.AddDays(i);
                    if (IsEndOfMonth(selectdate))
                    {
                        var yx = new DirectoryInfo(directoryPath).GetFiles((string.Concat("*.zip*"))).ToList().Select(x => x.LastWriteTime);
                        var monthlyFiles = new DirectoryInfo(directoryPath).GetFiles("*.zip*").ToList().Where(x => x.LastWriteTime.Date.Month == selectdate.Date.Month && x.LastWriteTime.Date.Year == selectdate.Date.Year).ToList();
                        if (monthlyFiles.ToList().Where(x => x.LastWriteTime.Month == selectdate.Month && x.LastWriteTime.Date.Year == selectdate.Date.Year).ToList().Count > 0)
                        {
                            if (!Directory.Exists(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy"), ".zip")))
                            {
                                Directory.CreateDirectory(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy")));
                                // var yx = new DirectoryInfo(directoryPath).GetFiles((string.Concat("*", fileType, "*"))).ToList().Select(x => x.LastWriteTime);
                                //new DirectoryInfo(directoryPath).GetFiles(string.Concat("*.zip*")).ToList().Where(x => x.LastWriteTime.Date.Month == selectdate.Date.Month && x.LastWriteTime.Date.Year == selectdate.Date.Year).ToList().ForEach(y => y.MoveTo(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy"), "\\" + y.Name)));
                                monthlyFiles.ToList().Where(x => x.LastWriteTime.Date.Month == selectdate.Date.Month && x.LastWriteTime.Date.Year == selectdate.Date.Year && x.Name.Contains(fileType)).ToList().ForEach(y => y.MoveTo(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy"), "\\" + y.Name)));
                                ZipFile.CreateFromDirectory(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy"), "\\"), string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy") + ".zip"));
                                if (File.Exists(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy"), ".zip")))
                                {
                                    File.SetLastWriteTime(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy"), ".zip"), selectdate);
                                }
                                new DirectoryInfo(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy"), "\\")).GetFiles("*.zip").ToList().ForEach(y => y.Delete());
                                Directory.Delete(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("MM-yyyy"), "\\"), true);
                            }
                        }

                    }
                    if (IsEndOfYear(selectdate))
                    {
                        var yearlyFiles = new DirectoryInfo(directoryPath).GetFiles("*.zip*").ToList().Where(x => x.LastWriteTime.Date.Year == selectdate.Date.Year).ToList();
                        if (yearlyFiles.ToList().Where(x => x.LastWriteTime.Year == selectdate.Year).ToList().Count > 0)
                        {

                            if (!Directory.Exists(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy"), ".zip")))
                            {
                                Directory.CreateDirectory(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy")));
                                yearlyFiles.ToList().Where(x => x.LastWriteTime.Date.Year == selectdate.Date.Year && x.Name.Contains(fileType)).ToList().ForEach(y => y.MoveTo(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy") + "\\" + y.Name)));
                                ZipFile.CreateFromDirectory(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy"), "\\"), string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy") + ".zip"));
                                if (File.Exists(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy") + ".zip")))
                                {
                                    File.SetLastWriteTime(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy"), ".zip"), selectdate);
                                }
                                new DirectoryInfo(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy"), "\\")).GetFiles("*.zip").ToList().ForEach(y => y.Delete());
                                Directory.Delete(string.Concat(directoryPath, "\\", fileType, "_", selectdate.ToString("yyyy"), "\\"), true);
                            }
                        }
                    }
                }

            }
        }
        static bool IsEndOfMonth(DateTime date)
        {
            return date.AddDays(1).Day == 1;
        }
        static bool IsEndOfYear(DateTime date)
        {
            return date.AddDays(1).Year == date.Year + 1;
        }

    }
}
