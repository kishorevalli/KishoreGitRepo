﻿using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataBO.Contracts;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataAzureAccess;
using System.IO;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExportToDataLakes : Common, IExportToDataLakes
    {
        private readonly IExportToDataLakesDac _dac;

        public ExportToDataLakes(IExportToDataLakesDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
        }
        public async Task ExportOmniItemDataToAzure()
        {

            var skipExportFlag = SystemValues.GetValue<bool>(Constants.SystemValues.SkipExportToAzureDataLakes);

            logBO.Info(jobname + "- GetExportFileTypes - Start");
            var filetypes = await _dac.GetExportFileTypes();
            logBO.Info(jobname + "- GetExportFileTypes - End");

            var factory = new ExportToDataLakesFactory(_dac, jobname);

            foreach (var typ in filetypes)
            {
                //var filetypeinst = factory.GetFileTypeInstance(typ.FileType, typ.FromDate, typ.ToDate);
                var filetypeinst = factory.GetFileTypeInstance(typ.FileType);
                await filetypeinst.GenerateCsv(typ, skipExportFlag);
            }
        }
    }
}

