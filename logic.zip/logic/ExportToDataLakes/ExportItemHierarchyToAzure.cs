﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using System;
using System.Configuration;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExportItemHierarchyToAzure : ExportToDataLakesAbstract
    {
        readonly IExportToDataLakesDac _dac;

        public ExportItemHierarchyToAzure(IExportToDataLakesDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public override async Task GenerateCsv(ExportFileTypeDTO dto, bool skipExportFlag)
        {
            logBO.Info(jobname + " - Get data from S0OMNIXX " + "for " + Constants.DataLakesExportFileName.ITEMHIERARCHY + " - Start");
            var itemHierarchyDetails = await _dac.GetItemHierarchyDetails();
            logBO.Info(jobname + " - Get data from S0OMNIXX " + "for " + Constants.DataLakesExportFileName.ITEMHIERARCHY + " - End");

            var filename = string.Concat(Constants.DataLakesExportFileName.ITEMHIERARCHY, ".csv");
            var sourcepath = GetSourceFilePath(filename);
            var destinationpath = dto.DataLakesFileLocation + "/" + filename;

            logBO.Info(jobname + " - Generate File " + Constants.DataLakesExportFileName.ITEMHIERARCHY + " - Start");
            await WriteToCsv(itemHierarchyDetails.ToList(), sourcepath);
            logBO.Info(jobname + " - Generate File " + Constants.DataLakesExportFileName.ITEMHIERARCHY + " - End");

            if (!skipExportFlag)
            {
                logBO.Info(jobname + " - Upload File " + Constants.DataLakesExportFileName.ITEMHIERARCHY + " - Start");
                await UploadCsvFile(sourcepath, destinationpath, dto.FileType, skipExportFlag);
                logBO.Info(jobname + " - Upload File " + Constants.DataLakesExportFileName.ITEMHIERARCHY + " - End");

            }
           
        }
    }
}
