﻿
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using System.Configuration;
using System;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExportItemAttributesToAzure : ExportToDataLakesAbstract
    {
        readonly IExportToDataLakesDac _dac;
        public ExportItemAttributesToAzure(IExportToDataLakesDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public override async Task GenerateCsv(ExportFileTypeDTO dto, bool skipExportFlag)
        {
            logBO.Info(jobname + " - Get data from S0OMNIXX " + "for " + Constants.DataLakesExportFileName.ITEMATTRIBUTES + " - Start");
            var itemAttributes = await _dac.GetItemAttributesDetails();
            logBO.Info(jobname + " - Get data from S0OMNIXX " + "for " + Constants.DataLakesExportFileName.ITEMATTRIBUTES + " - End");

            var filename = string.Concat(Constants.DataLakesExportFileName.ITEMATTRIBUTES, ".csv");
            var sourcepath = GetSourceFilePath(filename);
            var destinationpath = dto.DataLakesFileLocation + "/" + filename;

            logBO.Info(jobname + " - Generate File " + Constants.DataLakesExportFileName.ITEMATTRIBUTES + " - Start");
            await WriteToCsv(itemAttributes.ToList(), sourcepath);
            logBO.Info(jobname + " - Generate File " + Constants.DataLakesExportFileName.ITEMATTRIBUTES + " - End");

            if (!skipExportFlag)
            {
                logBO.Info(jobname + " - Upload File " + Constants.DataLakesExportFileName.ITEMATTRIBUTES + " - Start");
                await UploadCsvFile(sourcepath, destinationpath, dto.FileType, skipExportFlag);
                logBO.Info(jobname + " - Upload File " + Constants.DataLakesExportFileName.ITEMATTRIBUTES + " - End");
            }
               
        }
    }
}
