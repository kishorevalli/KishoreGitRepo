﻿using System.Linq;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using System.Configuration;
using System;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExportItemDetailsToAzure : ExportToDataLakesAbstract
    {
        readonly IExportToDataLakesDac _dac;

        public ExportItemDetailsToAzure(IExportToDataLakesDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public override async Task GenerateCsv(ExportFileTypeDTO dto, bool skipExportFlag)
        {
            logBO.Info(jobname + " - Get data from S0OMNIXX " + "for " + Constants.DataLakesExportFileName.ITEMDETAILS + " - Start");
            var itemDetails = await _dac.GetItemDetailsFromPimsToExport();
            logBO.Info(jobname + " - Get data from S0OMNIXX " + "for " + Constants.DataLakesExportFileName.ITEMDETAILS + " - End");

            var filename = string.Concat(Constants.DataLakesExportFileName.ITEMDETAILS, ".csv");
            var sourcepath = GetSourceFilePath(filename);
            var destinationpath = dto.DataLakesFileLocation + "/" + filename;

            logBO.Info(jobname + " - Generate File " + Constants.DataLakesExportFileName.ITEMDETAILS + " - Start");
            await WriteToCsv(itemDetails.ToList(), sourcepath);
            logBO.Info(jobname + " - Generate File " + Constants.DataLakesExportFileName.ITEMDETAILS + " - End");
            if (!skipExportFlag)
            {
                logBO.Info(jobname + " - Upload File " + Constants.DataLakesExportFileName.ITEMDETAILS + " - Start");
                await UploadCsvFile(sourcepath, destinationpath, dto.FileType, skipExportFlag);
                logBO.Info(jobname + " - Upload File " + Constants.DataLakesExportFileName.ITEMDETAILS + " - End");
            }
        }
    }
}
