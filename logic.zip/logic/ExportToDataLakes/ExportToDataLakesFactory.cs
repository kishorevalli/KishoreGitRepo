﻿using Publix.S0OMNIXX.OmniItemDataDAC;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExportToDataLakesFactory : Common
    {
        IExportToDataLakesDac dac;


        public ExportToDataLakesFactory(IExportToDataLakesDac _dac, string jobname) : base(_dac, jobname)
        {
            dac = _dac;
        }

        public ExportToDataLakesAbstract GetFileTypeInstance(string filetypeName)
        {
            ExportToDataLakesAbstract inst = null;

            switch (filetypeName.ToUpper())
            {

                case "TLOG":
                    inst = new ExportTLogToAzure(dac, jobname);
                    break;

                case "OLOG":
                    inst = new ExportOLogToAzure(dac, jobname);
                    break;

                case "ITEMDETAILS":
                    inst = new ExportItemDetailsToAzure(dac, jobname);
                    break;

                case "ITEMHIERARCHY":
                    inst = new ExportItemHierarchyToAzure(dac, jobname);
                    break;

                case "ITEMATTRIBUTES":
                    inst = new ExportItemAttributesToAzure(dac, jobname);
                    break;

            }
            return inst;
        }
    }
}
