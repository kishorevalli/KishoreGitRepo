﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Ionic.Zip;
using CsvHelper;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataAzureAccess;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class ExportToDataLakesAbstract : Common
    {
        IExportToDataLakesDac _dac;

        protected ExportToDataLakesAbstract(IExportToDataLakesDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public string FileName { get; set; }

        public abstract Task GenerateCsv(ExportFileTypeDTO filetyp, bool skipExportFlag);

        public async Task WriteToCsv<T>(List<T> dataToExport, string filePath)
        {
            using (TextWriter tw = File.CreateText(filePath))
            {
                using (CsvWriter csw = new CsvWriter(tw))
                {
                    csw.Configuration.HasHeaderRecord = true;
                    csw.WriteRecords(dataToExport);

                    await csw.FlushAsync();
                    await tw.FlushAsync();
                }
            }
        }

        public string GetSourceFilePath(string filename)
        {
            var filelocation = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-DataLakesExportFilePath"];
            if (!System.IO.Directory.Exists(filelocation))
                System.IO.Directory.CreateDirectory(filelocation);
            return filelocation + @"\" + filename;
        }

        public async Task UploadCsvFile(string sourcepath, string destinationpath, string filetype, bool skipExportFlag)
        {
            var exportDataLakes = new FileExportDataLakes(jobname);
            await exportDataLakes.ExportOmniDataToAzure(sourcepath, destinationpath);
            File.Delete(sourcepath);
        }

    }
}
