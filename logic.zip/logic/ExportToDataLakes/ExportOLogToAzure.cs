﻿using System.Linq;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using System;
using System.Configuration;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExportOLogToAzure : ExportToDataLakesAbstract
    {
        readonly IExportToDataLakesDac _dac;

        public ExportOLogToAzure(IExportToDataLakesDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public override async Task GenerateCsv(ExportFileTypeDTO dto, bool skipExportFlag)
        {
             var rundates = await _dac.GetRunDates( Constants.DataLakesExportFileName.OLOG);

            foreach (var rndt in rundates)
            {
                logBO.Info(jobname + " - Get data from S0OMNIXX " + "for " + Constants.DataLakesExportFileName.OLOG + " - Start");
                var ologAzureDetails = await _dac.GetOLogData(rndt.Id);
                logBO.Info(jobname + " - Get data from S0OMNIXX " + "for " + Constants.DataLakesExportFileName.OLOG + " - End");

                var sourcepath = GetSourceFilePath(rndt.FileName);
                var destinationpath = dto.DataLakesFileLocation + "/" + rndt.RunDate.ToString("yyyyMMdd") + "/" + rndt.FileName;

                logBO.Info(jobname + " - Generate File " + Constants.DataLakesExportFileName.OLOG + " - Start");
                await WriteToCsv(ologAzureDetails.ToList(), sourcepath);
                logBO.Info(jobname + " - Generate File " + Constants.DataLakesExportFileName.OLOG + " - End ");

                

                if (!skipExportFlag)
                {
                    logBO.Info(jobname + " - Upload File " + Constants.DataLakesExportFileName.OLOG + " - Start");
                    await UploadCsvFile(sourcepath, destinationpath, dto.FileType, skipExportFlag);
                    logBO.Info(jobname + " - Upload File " + Constants.DataLakesExportFileName.OLOG + " - Start");

                    logBO.Info(jobname + " - Update the uploaded flag for the run id  " + rndt.Id + " - Start");
                    await _dac.UpdateDataLakeUploadedFlag(rndt.Id);
                    logBO.Info(jobname + " - Update the uploaded flag for the run id  " + rndt.Id + " - End");
                }

               
            }
        }

    }
}
