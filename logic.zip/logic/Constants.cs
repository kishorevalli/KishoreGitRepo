﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class Constants
    {
        public enum JobReturnCode
        {
            Successful = 0,    //Job and/or step completed with no errors.
            Warning = 4,       //4 = Warning. Job and/or step completed with cautions.
            Failure = 8,       //8 = Failure. Job and/or step completed with one or more errors.
            Severe = 12       //12 = Severe failure. Job and/or step did not complete due to a severe error.
        }

        public enum FileVersionType
        {
            Regular,
            BOGO,
            RegularWithBOH,
            Liquor,
            Specialty,
            B2B
        }

        public enum ProcessingType
        {
            StoreInProgress = 1,
            StoreComplete = 2,
            FileGenerateInProgress = 3,
            FileGenerateComplete = 4
        }

        public static class JobStatus
        {
            public static string Start = "Start";
            public static string End = "End";
            public static string Fail = "Fail";
        }

        public static class SystemValues
        {
            public static string QueryCommandTimeout = "QueryCommandTimeout";

            // OMNIP01 - Load Item Data
            public static string MaxDegreeOfParallelism = "MaxDegreeOfParallelism";
            public static string MaxDegreeOfParallelismForMapOLogTLogToPos = "MaxDegreeOfParallelismForMapOLogTLogToPos";
            public static string StoreListSplitSize = "StoreListSplitSize";
            public static string BOHInternalLogging = "BOHInternalLogging";
            public static string SkipBOHItemMobileUpdates = "SkipBOHItemMobileUpdates";
            public static string MaxCountForBOHSkip = "MaxCountForBOHSkip";
            public static string SkipProductCatalogUpdates = "SkipProductCatalogUpdates";
            public static string MarkupPercent = "MarkupPercent";
            public static string MaxDegreeOfParallelismStoreProcessing = "MaxDegreeOfParallelismStoreProcessing";
            public static string NoOfStoresForProcessing = "NoOfStoresForProcessing";
            public static string NoOfStoresForBohParallel = "NoOfStoresForBohParallel";
            public static string MaxDegreeOfParallelismForPosLineItemFromEDW = "MaxDegreeOfParallelismForPosLineItemFromEDW";

            // OMNIP04 - Process Import Data Job
            public static string SkipTLogTaxSplit = "SkipTLogTaxSplit";
            public static string SkipTLogDiscrepancies = "SkipTLogDiscrepancies";
            public static string SkipOLogDiscrepancies = "SkipOLogDiscrepancies";
            public static string SkipPOSOLogOrdersMap = "SkipPOSOLogOrdersMap";
            public static string SkipOLogTaxSplit = "SkipOLogTaxSplit";
            public static string MapOrdersFromDate = "MapOrdersFromDate";
            public static string MapOrdersToDate = "MapOrdersToDate";
            public static string MapOrderId = "MapOrderId";
            public static string NoOfDaysAdditionalPOSTransactionsData = "NoOfDaysAdditionalPOSTransactionsData";

            // OMNIP02 - Export Item Data
            public static string ExportArchiveFilesRetentionDays = "ExportArchiveFilesRetentionDays";
            //public static string LiquorFileTag = "LiquorFileTag";
            public static string WaitTimeForJobInMinutes = "WaitTimeForJobInMinutes";
            //// public static string SpecialtyFileTag = "SpecialtyFileTag";

            // OMNIP05 - POS Transaction
            public static string FromDateKey = "ImportPOSDataFromDate";
            public static string ToDateKey = "ImportPOSDataToDate";
            public static string BinNumberKey = "ImportPOSDataBinNumber";
            public static string SkipPOSOrderTransaction = "SkipPOSOrderTransaction";
            public static string SkipPOSLineItemTransaction = "SkipPOSLineItemTransaction";
            public static string SkipDeletePOSDataFromMain = "SkipDeletePOSDataFromMain";  // applicable to both POSOrder and POSLineItem Transactions
            public static string SkipMovePOSLineItemStgToMain = "SkipMovePOSLineItemStgToMain";
            public static string SkipCopyPOSLineItemStgToScanGo = "SkipCopyPOSLineItemStgToScanGo";
            public static string ImportPosControlRangeFromDate = "ImportPosControlRangeFromDate";
            public static string ImportPosControlRangeToDate = "ImportPosControlRangeToDate";

            // OMNIP10 
            public static string SkipPrepareDataPosETicket = "SkipPrepareDataPosETicket";
            public static string SkipGenerateETicket = "SkipGenerateETicket";
            public static string SkipPublishETicket = "SkipPublishETicket";
            public static string GenerateETicketByStore = "GenerateETicketByStore";
            public static string ETicketMessageStyle1 = "ETicketMessageStyle1";

            //OMNIP12
            public static string ArchiveRetentionPeriod = "ArchiveRetentionPeriod";
            public static string SkipTruncatePartition = "SkipTruncatePartition";

            //OMNIP13
            public static string SkipETicketPostMQ = "SkipETicketPostMQ";

            public static string HistoryRetensionDays = "HistoryRetensionDays";
            public static string PanamaCityStores = "PanamaCityStores";

            //OMNIP20
            public static string SkipItemDetailsMove = "SkipItemDetailsMove";
            public static string NoOfStoresToGetItemDetails = "NoOfStoresToGetItemDetails";

            //OMNIP42
            public static string SkipExportToAzureDataLakes = "SkipExportToAzureDataLakes";

            //OMNIP42 File Compression.

            public static string MaxDegreeOfParallelismForCompression = "MaxDegreeOfParallelismForCompression";

        }

        public static class SystemMessages
        {
            public static string POSInstacartOrderMapWithDateAmount = "POSInstacartOrderMapWithDateAmount";
            public static string POSInstacartOrderMapWithDateTimeAmount = "POSInstacartOrderMapWithDateTimeAmount";
            public static string POSInstacartOrderMapWithReturnedAmountDate = "POSInstacartOrderMapWithReturnedAmountDate";
            public static string POSInstacartOrderMapWithStoreDateAmount = "POSInstacartOrderMapWithStoreDateAmount";
            public static string POSInstacartOrderMapWithStoreDateTimeAmount = "POSInstacartOrderMapWithStoreDateTimeAmount";
            public static string POSInstacartOrderNoMapFound = "POSInstacartOrderNoMapFound";
            public static string InvalidOrderId = "InvalidOrderId";
            public static string POSAlreadyMappedToDifferentOrder = "POSAlreadyMappedToDifferentOrder";
            public static string PosTotalTaxGreaterThanInstacartTotalTax = "PosTotalTaxGreaterThanInstacartTotalTax";
            public static string TLogDoesNotHaveIdentifier = "TLogDoesNotHaveIdentifier";
            public static string TaxGapTaxPlan1AmountIsNegative = "TaxGapTaxPlan1AmountIsNegative";
            public static string TaxGapTaxPlan1TaxPlan2AmountIsNegative = "TaxGapTaxPlan1TaxPlan2AmountIsNegative";
            public static string TaxGapTaxPlan3TaxPlan2AmountIsNegative = "TaxGapTaxPlan3TaxPlan2AmountIsNegative";
            public static string TaxGapTaxPlan3AmountIsNegative = "TaxGapTaxPlan3AmountIsNegative";
            public static string TLogQtyPOSQtyMismatch = "TLogQtyPOSQtyMismatch";
        }

        public static class SystemParameters
        {
            public static string POSEticketMQQueueManager = "POSEticketMQQueueManager";
            public static string POSEticketMQQueue = "POSEticketMQQueue";
            public static string JobMachineIdentifier = "JobMachineIdentifier";
        }

        public static class JobCode
        {
            public static string OMNI_IITEMDATA_REFRESH = "OMNI{0}01";
            public static string OMNI_ITEMDATA_EXPORT = "OMNI{0}02";
            public static string OMNI_ITEMDATA_IMPORT = "OMNI{0}03";
            public static string OMNI_PROCESS_IMPORT_DATA = "OMNI{0}04";
            public static string LOAD_EDW_DATA = "OMNI{0}05";
            public static string LOAD_FLEX_DATA = "OMNI{0}06";
            public static string LOAD_IDM_PRDCTLG_DATA = "OMNI{0}07";
            public static string OMNI_IMPORT_ITEMDATA_GTIN = "OMNI{0}08";
            public static string OMNI_MAP_OLOG_TLOG_TO_POS = "OMNI{0}09";
            public static string OMNI_TO_POS_ETICKET_RGLR = "OMNI{0}10";
            public static string OMNI_MOVE_SHELVE_HISTORY = "OMNI{0}11";
            public static string OMNI_TO_POS_ETICKET_TRUEUP = "OMNI{0}12";
            public static string OMNI_TO_POS_ETICKET_GENERATE = "OMNI{0}13";//As part of job split implementation, this is the new job code --Praveen
            public static string OMNI_ITEM_IMPORT_FROM_PIMS = "OMNI{0}20";
            public static string OMNI_IMPORT_DATA_STORE = "OMNI{0}23";
            public static string OMNI_SUPPORT_Checks = "OMNI{0}40";
            public static string OMNI_REPORTGENERATION = "OMNI{0}41";
            public static string OMNI_ITEMDATA_EXPORT_DATALAKES = "OMNI{0}30";
            public static string OMNI_ITEMDATA_PURGE = "OMNI{0}12";
            public static string CREATE_PARTION_ITEMDATA = "OMNI{0}14";
            public static string OMNI_FILE_COMPRESSION = "OMNI{0}42";
        }

        public static class AppSettings
        {
            public static string CreateSalesTransactionEndPoint = "CreateSalesTransactionEndPoint";
        }


        public static class JobArgs
        {
            public const string EDWDataSource = "EDW";
            public const string FLEXDataSource = "FLEX";
            public const string PIMSScanCode = "SCANCODE";
            public const string ShelveToHistory = "SHELVETOHISTORY";
            public const string IDMProductCatalog = "IDM";
            public const string Regular = "REGULAR";
            public const string TrueUp = "TRUEUP";
            public const string ETicket = "ETICKET";//As part of job split implementation, this is the new job argument name --Praveen
            public const string PIMSStoreData = "STRDET";
            public const string CreatePartition = "CREATEPARTITION";
        }

        public static class FileTypes
        {
            public static string TLog = "TLOG";
            public static string OLog = "OLOG";
            public static string CLOG = "CLOG";
            public static string OSDT = "OSDT";
            public static string OSPD = "OSPD";
        }

        public static class TableName
        {
            public static string InstOLogHistory = "Inst_OLog_History";
            public static string InstTLogHistory = "Inst_TLog_History";
            public static string InstCLogHistory = "InstCRLogHistory";
            public static string InstOSDTHistory = "InstOutOfStockDetailsHistory";
            public static string InstOSPDHistory = "InstOutOfStockProductHistory";
        }

        public static class CacheKey
        {
            public static string ItemGTIN = "ItemGTIN";
        }

        public static class DataLakesExportFileName
        {
            public static string OLOG = "OLog";
            public static string TLOG = "TLog";
            public static string ITEMDETAILS = "ItemDetails";
            public static string ITEMHIERARCHY = "ItemHierarchy";
            public static string ITEMATTRIBUTES = "ItemAttributes";

        }
    }



}
