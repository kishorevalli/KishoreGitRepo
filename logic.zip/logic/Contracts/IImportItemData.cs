﻿using System.Threading.Tasks;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public interface IImportItemData
    {
        Task ProcessVendorsLogsCsvAsync();
    }

}