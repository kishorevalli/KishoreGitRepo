﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public interface IItemDataRefresh
    {
        Task RefereshItemData();
    }
}
