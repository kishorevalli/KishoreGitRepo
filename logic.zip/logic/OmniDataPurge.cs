﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class OmniDataPurge : Common, IOmniDataPurge
    {
        readonly IOmniDataPurgeDac _dac;
        public OmniDataPurge(IOmniDataPurgeDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public async Task PurgeArchiveData()
        {
            var archiveretentionPeriodMnths = SystemValues.GetValue<int>(Constants.SystemValues.ArchiveRetentionPeriod);
            var skipTruncateParition = SystemValues.GetValue<bool>(Constants.SystemValues.SkipTruncatePartition);
            //var retentiondate = DateTime.Today.AddMonths(-archiveretentionPeriodMnths).ToString("yyyy-MM-dd");
            
            var paritionTuple = await _dac.GetArchiveItemDataParitionList(archiveretentionPeriodMnths);

            foreach (var tplePartition in paritionTuple)
            {
                if (!skipTruncateParition)
                {
                    await _dac.TruncateParition(tplePartition.Item1, tplePartition.Item2);
                }

                logBO.Info(jobname + "- Partition Number:" + tplePartition.Item1 + " Parition Range:" + tplePartition.Item2 + " will be Truncated");
            }
        }
    }
}
