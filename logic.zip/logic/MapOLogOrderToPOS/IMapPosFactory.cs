﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public interface IMapPosFactory
    {
        MapPosActionsAbstract GetActions(FileTypeEnum filetypeProcess, List<POSInstacartOrderMapDTO> _mappedOLogPosOrders);
    }
}
