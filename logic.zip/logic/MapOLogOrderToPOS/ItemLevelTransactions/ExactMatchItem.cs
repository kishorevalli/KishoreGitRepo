﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExactMatchItem : MapTLogPOS
    {
        public ExactMatchItem(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {
        }

        public async override Task<PosInstacartOrderDetailsDTO> MapTLogItemsPOSAsync(List<POSLineItemTransactionDTO> postxns, TLogDTO tlogRecord)
        {
            if (postxns.Any() && postxns.Any(p => p.ItemId == tlogRecord.ItemId))
            {
                var grpPos = postxns.FirstOrDefault(t => t.ItemId == tlogRecord.ItemId);

                foreach (var p in postxns)
                {
                    if (p.ItemId == tlogRecord.ItemId)
                    {
                        p.IsPosMapped = true;
                        break;
                    }
                }

                return await MapTLogPOS.GetmappedPosInstDetailsAsync(grpPos, tlogRecord);
            }
            else
                return await nextmatch.MapTLogItemsPOSAsync(postxns, tlogRecord);
        }
    }
}
