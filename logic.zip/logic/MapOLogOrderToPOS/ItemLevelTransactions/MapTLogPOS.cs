﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class MapTLogPOS : Common
    {
        protected static ItemGtinDTO itemgtinColl;
        protected MapTLogPOS nextmatch;
        protected IMapOLogTLogToPosDac _dac;
        protected static IEnumerable<StoreTaxRateDTO> storeTaxRates;
        protected static List<int> panamacityStores;
        public abstract Task<PosInstacartOrderDetailsDTO> MapTLogItemsPOSAsync(List<POSLineItemTransactionDTO> postxns, TLogDTO tlogRecord);

        protected MapTLogPOS(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {

            _dac = dac;
            storeTaxRates = dac.GetStoreTaxRates().Result;
            panamacityStores = SystemValues.GetValue<String>(Constants.SystemValues.PanamaCityStores).Split(',').ToList().Select(int.Parse).ToList();
        }

        public List<ItemGtinDTO> ItemGTINColl
        {
            get
            {
                var itemgtin = (List<ItemGtinDTO>)MemoryCache.Default[Constants.CacheKey.ItemGTIN];
                if (itemgtin == null)
                    return new List<ItemGtinDTO>();

                return itemgtin;
            }
            set
            {
                MemoryCache.Default.Add(Constants.CacheKey.ItemGTIN, value, DateTime.Now.AddDays(1));
            }
        }

        public void SetNextmatch(MapTLogPOS nextMatch)
        {
            this.nextmatch = nextMatch;
        }

        protected async Task<List<POSLineItemTransactionDTO>> ValidateGTINAsync(IEnumerable<POSLineItemTransactionDTO> postxns, long tlogGtin)
        {
            var result = new List<POSLineItemTransactionDTO>();
            var lstItemGtin = await _dac.GetItemGTIN(tlogGtin); //Get ItemGTIN from Cache


            //Get ItemId, GTIN from ItemGTIN with tlog GTIN

            if (postxns.Any() && lstItemGtin != null && lstItemGtin.Any())
                result = postxns.Join(lstItemGtin, p => p.GTINCheckDigit, i => i.GTINCheckDigit, (p, i) => p).ToList();   // Check POSGtin exists in this collection

            return result;

        }

        protected static Task<PosInstacartOrderDetailsDTO> GetmappedPosInstDetailsAsync(POSLineItemTransactionDTO postxn, TLogDTO tlog)
        {
            var result = new PosInstacartOrderDetailsDTO
            {
                InstacartOrderID = tlog.OrderID,
                InstacartDeliveryID = tlog.DeliveryID,
                InstacartOrderLineNumber = tlog.OrderLineNumber,
                InstacartOrderedDateTimeEST = tlog.OrderedDateTimeEST,
                InstacartDeliveryDateTimeEST = tlog.DeliveryDateTimeEST,
                InstacartStoreLocation = tlog.StoreLocation,
                InstacartReferenceCode = tlog.ItemId,
                InstacartGTIN = tlog.GTIN,
                InstacartUnit = tlog.Unit,
                InstacartQty = tlog.Qty,
                InstacartOnlinePrice = tlog.InstacartOnlinePrice,
                InstacartOnlineRevenue = tlog.InstacartOnlineRevenue,
                InstacartSalesTax = tlog.SalesTax,
                InstacartGMV = tlog.GMV,
                //InstacartTaxableSales = tlog.TaxableSales,
                //InstacartNonTaxableSales = tlog.NonTaxableSales,
                //InstacartTaxPlan1TaxableSales = tlog.TaxableSalesTaxPlan1,
                //InstacartTaxPlan1TaxPlan2TaxableSales = tlog.TaxableSalesTaxPlan1TaxPlan2,
                //InstacartTaxPlan3TaxPlan2TaxableSales = tlog.TaxableSalesTaxPlan2TaxPlan3,
                //InstacartTaxPlan3TaxableSales = tlog.TaxableSalesTaxPlan3,
                //InstacartTaxPlan1Tax = ((postxn.TaxPlan1 == true && postxn.TaxPlan2 == false && postxn.TaxPlan3 == false) ? tlog.SalesTax : 0),
                //InstacartTaxPlan1TaxPlan2Tax = ((postxn.TaxPlan1 == true && postxn.TaxPlan2 == true && postxn.TaxPlan3 == false) ? tlog.SalesTax : 0),
                //InstacartTaxPlan3TaxPlan2Tax = ((postxn.TaxPlan1 == false && postxn.TaxPlan2 == true && postxn.TaxPlan3 == true) ? tlog.SalesTax : 0),
                //InstacartTaxPlan3Tax = ((postxn.TaxPlan1 == false && postxn.TaxPlan2 == false && postxn.TaxPlan3 == true) ? tlog.SalesTax : 0),
                PosFacilityId = postxn.FacilityId,
                PosTransactionDate = postxn.TransactionDate,
                PosTransactionTM = postxn.TransactionTM,
                PosTransactionNumber = postxn.TransactionNumber,
                PosItemId = postxn.ItemId,
                PosGTIN = postxn.GTINCheckDigit,
                PosSalesVolume = postxn.SalesVolume,
                PosSalesAmount = postxn.SalesAmount,
                PosTotalTax = postxn.TotalTax,
                PosTotalSalesIncludingTax = postxn.TotalSalesIncludingTax,
                //PosTaxableSales = postxn.TaxableAmount,
                //PosNonTaxableSales = postxn.NonTaxableSales,
                //PosTaxPlan1TaxableSales = postxn.TaxableSalesTaxPlan1Amount,
                //PosTaxPlan3TaxableSales = postxn.TaxableSalesTaxPlan3Amount,
                //PosTaxPlan1TaxPlan2TaxableSales = postxn.TaxableSalesTaxPlan1TaxPlan2Amount,
                //PosTaxPlan3TaxPlan2TaxableSales = postxn.TaxableSalesTaxPlan3TaxPlan2Amount,
                PosTaxPlan1Tax = postxn.TaxPlan1Tax,
                PosTaxPlan1TaxPlan2Tax = postxn.TaxPlan1TaxPlan2Tax,
                PosTaxPlan3TaxPlan2Tax = postxn.TaxPlan3TaxPlan2Tax,
                PosTaxPlan3Tax = postxn.TaxPlan3Tax,
                SpreadPercentage = (postxn.SalesAmount != 0 ? (((tlog.GMV - tlog.SalesTax) - postxn.SalesAmount) / postxn.SalesAmount) * 100 : 0),
                //TaxGapTotalTax = tlog.SalesTax - postxn.TotalTax,
                //TaxGapTaxPlan1Tax = tlog.TaxPlan1Tax - postxn.TaxPlan1Tax,
                //TaxGapTaxPlan1TaxPlan2Tax = tlog.TaxPlan1TaxPlan2Tax - postxn.TaxPlan1TaxPlan2Tax,
                //TaxGapTaxPlan3TaxPlan2Tax = tlog.TaxPlan3TaxPlan2Tax - postxn.TaxPlan3TaxPlan2Tax,
                //TaxGapTaxPlan3Tax = tlog.TaxPlan3Tax - postxn.TaxPlan3Tax,
                //TaxGapNonTaxableSales = tlog.NonTaxableSales - postxn.NonTaxableSales,
            };


            if (postxn.TaxPlan1 == true && postxn.TaxPlan2 == false && postxn.TaxPlan3 == false)
            {
                result.InstacartTaxPlan1Tax = tlog.SalesTax;
            }
            else if (postxn.TaxPlan1 == true && postxn.TaxPlan2 == true && postxn.TaxPlan3 == false)
            {
                if (panamacityStores.Any(x => x == result.PosFacilityId))
                {

                    var taxrate = storeTaxRates.FirstOrDefault(s => s.StoreNumber == result.PosFacilityId);
                    var panamacityTax = (tlog.InstacartOnlineRevenue * taxrate.TaxPlan2) / 100;

                    result.InstacartSalesTax = result.InstacartSalesTax + panamacityTax;
                    result.InstacartTaxPlan1TaxPlan2Tax = tlog.SalesTax + panamacityTax;
                    result.InstacartOnlineRevenue = result.InstacartOnlineRevenue - panamacityTax;


                }
                else
                {
                    result.InstacartTaxPlan1TaxPlan2Tax = tlog.SalesTax;
                }
            }

            else if (postxn.TaxPlan1 == false && postxn.TaxPlan2 == true && postxn.TaxPlan3 == true)
                result.InstacartTaxPlan3TaxPlan2Tax = tlog.SalesTax;
            else if (postxn.TaxPlan1 == false && postxn.TaxPlan2 == false && postxn.TaxPlan3 == true)
                result.InstacartTaxPlan3Tax = tlog.SalesTax;
            else if (postxn.TaxPlan1 == false && postxn.TaxPlan2 == true && postxn.TaxPlan3 == false)
            {
                if (panamacityStores.Any(x => x == result.PosFacilityId))
                {
                    var taxrate = storeTaxRates.FirstOrDefault(s => s.StoreNumber == result.PosFacilityId);
                    var panamacityTax = (tlog.InstacartOnlineRevenue * taxrate.TaxPlan2) / 100;

                    result.InstacartSalesTax = result.InstacartSalesTax + panamacityTax;
                    result.InstacartTaxPlan3TaxPlan2Tax = tlog.SalesTax + panamacityTax;
                    result.InstacartOnlineRevenue = result.InstacartOnlineRevenue - panamacityTax;

                }

            }
            else if (postxn.TaxPlan1 == false && postxn.TaxPlan2 == false && postxn.TaxPlan3 == false)
            {
                if (tlog.SalesTax > 0 && tlog.TaxPlan1Tax == 0 && tlog.TaxPlan1TaxPlan2Tax == 0 && tlog.TaxPlan3TaxPlan2Tax == 0 && tlog.TaxPlan3Tax == 0)
                    result.InstacartTaxPlan1Tax = tlog.SalesTax;
                else
                {
                    result.InstacartTaxPlan1Tax = tlog.TaxPlan1Tax;
                    result.InstacartTaxPlan1TaxPlan2Tax = tlog.TaxPlan1TaxPlan2Tax;
                    result.InstacartTaxPlan3TaxPlan2Tax = tlog.TaxPlan3TaxPlan2Tax;
                    result.InstacartTaxPlan3Tax = tlog.TaxPlan3Tax;
                }
            }

            result.TaxGapTotalTax = result.InstacartSalesTax - result.PosTotalTax;
            result.TaxGapTaxPlan1Tax = result.InstacartTaxPlan1Tax - result.PosTaxPlan1Tax;
            result.TaxGapTaxPlan1TaxPlan2Tax = result.InstacartTaxPlan1TaxPlan2Tax - result.PosTaxPlan1TaxPlan2Tax;
            result.TaxGapTaxPlan3TaxPlan2Tax = result.InstacartTaxPlan3TaxPlan2Tax - result.PosTaxPlan3TaxPlan2Tax;
            result.TaxGapTaxPlan3Tax = result.InstacartTaxPlan3Tax - result.PosTaxPlan3Tax;

            result.TaxGapTaxPlan1TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan1Tax, "TaxPlan1", postxn);
            result.TaxGapTaxPlan1TaxPlan2TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan1TaxPlan2Tax, "TaxPlan1TaxPlan2", postxn);
            result.TaxGapTaxPlan3TaxPlan2TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan3TaxPlan2Tax, "TaxPlan3TaxPlan2", postxn);
            result.TaxGapTaxPlan3TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan3Tax, "TaxPlan3", postxn);

            return Task.FromResult(result);
        }

        internal static List<TLogDTO> GroupTLogOrders(List<TLogDTO> tlogsForOrder)
        {
            var grpTLog = new List<TLogDTO>();

            if (tlogsForOrder.Any())
            {
                var itemids = tlogsForOrder.GroupBy(t => t.ItemId).Where(grp => grp.Count() > 1).Select(g => g.Key);
                grpTLog = tlogsForOrder.Where(t => !itemids.Any(i => i == t.ItemId)).ToList();

                if (itemids.Any())
                {
                    var tloggrpItems = tlogsForOrder.Where(t => itemids.Any(i => i == t.ItemId))
                                                    .GroupBy(g => new { g.OrderID, g.DeliveryID, g.StoreLocation, g.ItemId, g.GTIN, g.OrderedDateTimeEST, g.DeliveryDateTimeEST },
                                                    (key, grp) => new TLogDTO
                                                    {
                                                        OrderID = key.OrderID,
                                                        DeliveryID = key.DeliveryID,
                                                        OrderLineNumber = 998,
                                                        OrderedDateTimeEST = key.OrderedDateTimeEST,
                                                        DeliveryDateTimeEST = key.DeliveryDateTimeEST,
                                                        StoreLocation = key.StoreLocation,
                                                        ItemId = key.ItemId,
                                                        GTIN = key.GTIN,
                                                        Qty = grp.Sum(i => i.Qty),
                                                        InstacartOnlinePrice = grp.Sum(i => i.InstacartOnlinePrice),
                                                        InstacartOnlineRevenue = grp.Sum(i => i.InstacartOnlineRevenue),
                                                        SalesTax = grp.Sum(i => i.SalesTax),
                                                        BottleDeposit = grp.Sum(i => i.BottleDeposit),
                                                        GMV = grp.Sum(i => i.GMV),
                                                        //TaxableSales = grp.Sum(i => i.TaxableSales),
                                                        //NonTaxableSales = grp.Sum(i => i.NonTaxableSales),
                                                        //TaxableAlcoholSales = grp.Sum(i => i.TaxableAlcoholSales),
                                                        //TaxableNonAlcoholSales = grp.Sum(i => i.TaxableNonAlcoholSales),
                                                        //NonTaxableAlcoholSales = grp.Sum(i => i.NonTaxableAlcoholSales),
                                                        //NonTaxableNonAlcoholSales = grp.Sum(i => i.NonTaxableNonAlcoholSales),
                                                        //TaxPlan1Amount = grp.Sum(i => i.TaxPlan1Amount),
                                                        //TaxPlan2Amount = grp.Sum(i => i.TaxPlan2Amount),
                                                        //TaxPlan3Amount = grp.Sum(i => i.TaxPlan3Amount),
                                                        //TaxPlan4Amount = grp.Sum(i => i.TaxPlan4Amount),
                                                        //TaxableSalesTaxPlan1 = grp.Sum(i => i.TaxableSalesTaxPlan1),
                                                        //TaxableSalesTaxPlan1TaxPlan2 = grp.Sum(i => i.TaxableSalesTaxPlan1TaxPlan2),
                                                        //TaxableSalesTaxPlan2TaxPlan3 = grp.Sum(i => i.TaxableSalesTaxPlan2TaxPlan3),
                                                        //TaxableSalesTaxPlan3 = grp.Sum(i => i.TaxableSalesTaxPlan3),
                                                        TaxPlan1Tax = grp.Sum(i => i.TaxPlan1Tax),
                                                        TaxPlan1TaxPlan2Tax = grp.Sum(i => i.TaxPlan1TaxPlan2Tax),
                                                        TaxPlan3TaxPlan2Tax = grp.Sum(i => i.TaxPlan3TaxPlan2Tax),
                                                        TaxPlan3Tax = grp.Sum(i => i.TaxPlan3Tax)
                                                    }).ToList();
                    grpTLog.AddRange(tloggrpItems);
                }
            }
            return grpTLog;
        }

        internal static List<PosInstacartOrderDetailsDTO> GetPosInstacartOrderDetailsHeader(POSInstacartOrderMapDTO posinstOrdr, List<PosInstacartOrderDetailsDTO> mappedDetails, DateTime _currentDateTime, string username)
        {
            var result = new List<PosInstacartOrderDetailsDTO>();

            // This creates header for mapped records.  Consider only records which +ve spread for Tax Gap.
            if (mappedDetails.Any(m => m.PosFacilityId != 0 && m.PosTransactionNumber != 0 && m.PosTransactionTM != 0 && m.PosTransactionDate != null && m.InstacartGMV != 0 && m.InstacartGMV != 0 && m.InstacartSalesTax - m.PosTotalTax >= 0))
            {
                result = mappedDetails.Where(m => m.PosFacilityId != 0 && m.PosTransactionNumber != 0 && m.PosTransactionTM != 0 && m.PosTransactionDate != null && m.InstacartGMV != 0 && m.InstacartSalesTax - m.PosTotalTax >= 0)
                   .GroupBy(p => new { p.InstacartOrderID, p.InstacartDeliveryID, p.InstacartStoreLocation },
                                   (key, grp) => new PosInstacartOrderDetailsDTO
                                   {
                                       InstacartOrderID = key.InstacartOrderID,
                                       InstacartDeliveryID = key.InstacartDeliveryID,
                                       InstacartOrderLineNumber = 0,
                                       InstacartStoreLocation = key.InstacartStoreLocation,
                                       InstacartQty = grp.Sum(i => i.InstacartQty),
                                       InstacartOnlinePrice = grp.Sum(i => i.InstacartOnlinePrice),
                                       InstacartOnlineRevenue = grp.Sum(i => i.InstacartOnlineRevenue),
                                       InstacartSalesTax = grp.Sum(i => i.InstacartSalesTax),
                                       InstacartGMV = grp.Sum(i => i.InstacartGMV),
                                       //InstacartTaxableSales = grp.Sum(i => i.InstacartTaxableSales),
                                       //InstacartNonTaxableSales = grp.Sum(i => i.InstacartNonTaxableSales),
                                       //InstacartTaxPlan1TaxableSales = grp.Sum(i => i.InstacartTaxPlan1TaxableSales),
                                       //InstacartTaxPlan1TaxPlan2TaxableSales = grp.Sum(i => i.InstacartTaxPlan1TaxPlan2TaxableSales),
                                       //InstacartTaxPlan3TaxPlan2TaxableSales = grp.Sum(i => i.InstacartTaxPlan3TaxPlan2TaxableSales),
                                       //InstacartTaxPlan3TaxableSales = grp.Sum(i => i.InstacartTaxPlan3TaxableSales),
                                       InstacartTaxPlan1Tax = grp.Sum(i => i.InstacartTaxPlan1Tax),
                                       InstacartTaxPlan1TaxPlan2Tax = grp.Sum(i => i.InstacartTaxPlan1TaxPlan2Tax),
                                       InstacartTaxPlan3TaxPlan2Tax = grp.Sum(i => i.InstacartTaxPlan3TaxPlan2Tax),
                                       InstacartTaxPlan3Tax = grp.Sum(i => i.InstacartTaxPlan3Tax),
                                       PosFacilityId = posinstOrdr.PosFacilityId,
                                       PosTransactionDate = posinstOrdr.PosTransactionDateTime,
                                       PosTransactionTM = posinstOrdr.PosTransactionTM,
                                       PosTransactionNumber = posinstOrdr.PosTransactionNumber,
                                       PosSalesVolume = grp.Sum(i => i.PosSalesVolume),
                                       PosSalesAmount = grp.Sum(i => i.PosSalesAmount),
                                       PosTotalTax = grp.Sum(i => i.PosTotalTax),
                                       PosTotalSalesIncludingTax = grp.Sum(i => i.PosTotalSalesIncludingTax),
                                       //PosTaxableSales = grp.Sum(i => i.PosTaxableSales),
                                       //PosNonTaxableSales = grp.Sum(i => i.PosNonTaxableSales),
                                       //PosTaxPlan1TaxableSales = grp.Sum(i => i.PosTaxPlan1TaxableSales),
                                       //PosTaxPlan1TaxPlan2TaxableSales = grp.Sum(i => i.PosTaxPlan1TaxPlan2TaxableSales),
                                       //PosTaxPlan3TaxPlan2TaxableSales = grp.Sum(i => i.PosTaxPlan3TaxPlan2TaxableSales),
                                       //PosTaxPlan3TaxableSales = grp.Sum(i => i.PosTaxPlan3TaxableSales),
                                       PosTaxPlan1Tax = grp.Sum(i => i.PosTaxPlan1Tax),
                                       PosTaxPlan1TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan1TaxPlan2Tax),
                                       PosTaxPlan3TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan3TaxPlan2Tax),
                                       PosTaxPlan3Tax = grp.Sum(i => i.PosTaxPlan3Tax),
                                       TaxGapTotalTax = grp.Sum(i => i.TaxGapTotalTax),
                                       TaxGapTaxPlan1Tax = grp.Sum(i => i.TaxGapTaxPlan1Tax),
                                       TaxGapTaxPlan1TaxPlan2Tax = grp.Sum(i => i.TaxGapTaxPlan1TaxPlan2Tax),
                                       TaxGapTaxPlan3TaxPlan2Tax = grp.Sum(i => i.TaxGapTaxPlan3TaxPlan2Tax),
                                       TaxGapTaxPlan3Tax = grp.Sum(i => i.TaxGapTaxPlan3Tax),
                                       LastUpdatedDate = _currentDateTime,
                                       LastUpdatedBy = username
                                   }).ToList();

                foreach (var item in result)
                {
                    item.SpreadPercentage = (item.PosSalesAmount != 0 ? (((item.InstacartGMV - item.InstacartSalesTax) - item.PosSalesAmount) / item.PosSalesAmount) * 100 : 0);
                    item.TaxGapTaxPlan1TaxableSales = CalculateTaxPlanAmount(item.TaxGapTaxPlan1Tax, "TaxPlan1", item);
                    item.TaxGapTaxPlan1TaxPlan2TaxableSales = CalculateTaxPlanAmount(item.TaxGapTaxPlan1TaxPlan2Tax, "TaxPlan1TaxPlan2", item);
                    item.TaxGapTaxPlan3TaxPlan2TaxableSales = CalculateTaxPlanAmount(item.TaxGapTaxPlan3TaxPlan2Tax, "TaxPlan3TaxPlan2", item);
                    item.TaxGapTaxPlan3TaxableSales = CalculateTaxPlanAmount(item.TaxGapTaxPlan3Tax, "TaxPlan3", item);
                    item.TaxGapNonTaxableSales = (item.InstacartGMV - item.PosTotalSalesIncludingTax) - (item.TaxGapTaxPlan1TaxableSales + item.TaxGapTaxPlan1TaxPlan2TaxableSales + item.TaxGapTaxPlan3TaxPlan2TaxableSales + item.TaxGapTaxPlan3TaxableSales);
                }

            }
            else
            {
                result = mappedDetails.GroupBy(p => new { p.InstacartOrderID, p.InstacartDeliveryID, p.InstacartStoreLocation },
                                   (key, grp) => new PosInstacartOrderDetailsDTO
                                   {
                                       InstacartOrderID = key.InstacartOrderID,
                                       InstacartDeliveryID = key.InstacartDeliveryID,
                                       InstacartOrderLineNumber = 0,
                                       InstacartStoreLocation = key.InstacartStoreLocation,
                                       InstacartQty = grp.Sum(i => i.InstacartQty),
                                       InstacartOnlinePrice = grp.Sum(i => i.InstacartOnlinePrice),
                                       InstacartOnlineRevenue = grp.Sum(i => i.InstacartOnlineRevenue),
                                       InstacartSalesTax = grp.Sum(i => i.InstacartSalesTax),
                                       InstacartGMV = grp.Sum(i => i.InstacartGMV),
                                       //InstacartTaxableSales = grp.Sum(i => i.InstacartTaxableSales),
                                       //InstacartNonTaxableSales = grp.Sum(i => i.InstacartNonTaxableSales),
                                       //InstacartTaxPlan1TaxableSales = grp.Sum(i => i.InstacartTaxPlan1TaxableSales),
                                       //InstacartTaxPlan1TaxPlan2TaxableSales = grp.Sum(i => i.InstacartTaxPlan1TaxPlan2TaxableSales),
                                       //InstacartTaxPlan3TaxPlan2TaxableSales = grp.Sum(i => i.InstacartTaxPlan3TaxPlan2TaxableSales),
                                       //InstacartTaxPlan3TaxableSales = grp.Sum(i => i.InstacartTaxPlan3TaxableSales),
                                       InstacartTaxPlan1Tax = grp.Sum(i => i.InstacartTaxPlan1Tax),
                                       InstacartTaxPlan1TaxPlan2Tax = grp.Sum(i => i.InstacartTaxPlan1TaxPlan2Tax),
                                       InstacartTaxPlan3TaxPlan2Tax = grp.Sum(i => i.InstacartTaxPlan3TaxPlan2Tax),
                                       InstacartTaxPlan3Tax = grp.Sum(i => i.InstacartTaxPlan3Tax),
                                       PosFacilityId = 0,
                                       PosTransactionDate = null,
                                       PosTransactionNumber = 0,
                                       PosTransactionTM = 0,
                                       LastUpdatedDate = _currentDateTime,
                                       LastUpdatedBy = username,
                                       Type = RuleTypeEnum.Exception
                                   }).ToList();
            }

            return result;
        }

        internal static PosInstacartOrderDetailsDTO GetHeaderForMappedUnMappedPosInstDetails(List<PosInstacartOrderDetailsDTO> posinstDetails, PosInstacartOrderDetailsDTO header, DateTime _currentDateTime, string username)
        {
            var result = new PosInstacartOrderDetailsDTO();

            //posinstDetails collections has both Unmapped Header & mapped Header. Hence only header which has +ve tax should be considered for final Tax Gap process.
            result = posinstDetails.Where(pi => pi.TaxGapTotalTax >= 0)
                                   .GroupBy(p => new { p.InstacartOrderID },
                               (key, grp) => new PosInstacartOrderDetailsDTO
                               {
                                   InstacartOrderID = key.InstacartOrderID,
                                   InstacartDeliveryID = header.InstacartDeliveryID,
                                   InstacartOrderLineNumber = 0,
                                   InstacartStoreLocation = header.InstacartStoreLocation,
                                   InstacartQty = grp.Sum(i => i.InstacartQty),
                                   InstacartOnlinePrice = grp.Sum(i => i.InstacartOnlinePrice),
                                   InstacartOnlineRevenue = grp.Sum(i => i.InstacartOnlineRevenue),
                                   InstacartSalesTax = grp.Sum(i => i.InstacartSalesTax),
                                   InstacartGMV = grp.Sum(i => i.InstacartGMV),
                                   //InstacartTaxableSales = grp.Sum(i => i.InstacartTaxableSales),
                                   //InstacartNonTaxableSales = grp.Sum(i => i.InstacartNonTaxableSales),
                                   //InstacartTaxPlan1TaxableSales = grp.Sum(i => i.InstacartTaxPlan1TaxableSales),
                                   //InstacartTaxPlan1TaxPlan2TaxableSales = grp.Sum(i => i.InstacartTaxPlan1TaxPlan2TaxableSales),
                                   //InstacartTaxPlan3TaxPlan2TaxableSales = grp.Sum(i => i.InstacartTaxPlan3TaxPlan2TaxableSales),
                                   //InstacartTaxPlan3TaxableSales = grp.Sum(i => i.InstacartTaxPlan3TaxableSales),
                                   InstacartTaxPlan1Tax = grp.Sum(i => i.InstacartTaxPlan1Tax),
                                   InstacartTaxPlan1TaxPlan2Tax = grp.Sum(i => i.InstacartTaxPlan1TaxPlan2Tax),
                                   InstacartTaxPlan3TaxPlan2Tax = grp.Sum(i => i.InstacartTaxPlan3TaxPlan2Tax),
                                   InstacartTaxPlan3Tax = grp.Sum(i => i.InstacartTaxPlan3Tax),
                                   PosFacilityId = header.PosFacilityId,
                                   PosTransactionDate = header.PosTransactionDate,
                                   PosTransactionTM = header.PosTransactionTM,
                                   PosTransactionNumber = header.PosTransactionNumber,
                                   PosSalesVolume = grp.Sum(i => i.PosSalesVolume),
                                   PosSalesAmount = grp.Sum(i => i.PosSalesAmount),
                                   PosTotalTax = grp.Sum(i => i.PosTotalTax),
                                   PosTotalSalesIncludingTax = grp.Sum(i => i.PosTotalSalesIncludingTax),
                                   //PosTaxableSales = grp.Sum(i => i.PosTaxableSales),
                                   //PosNonTaxableSales = grp.Sum(i => i.PosNonTaxableSales),
                                   //PosTaxPlan1TaxableSales = grp.Sum(i => i.PosTaxPlan1TaxableSales),
                                   //PosTaxPlan1TaxPlan2TaxableSales = grp.Sum(i => i.PosTaxPlan1TaxPlan2TaxableSales),
                                   //PosTaxPlan3TaxPlan2TaxableSales = grp.Sum(i => i.PosTaxPlan3TaxPlan2TaxableSales),
                                   //PosTaxPlan3TaxableSales = grp.Sum(i => i.PosTaxPlan3TaxableSales),
                                   PosTaxPlan1Tax = grp.Sum(i => i.PosTaxPlan1Tax),
                                   PosTaxPlan1TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan1TaxPlan2Tax),
                                   PosTaxPlan3TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan3TaxPlan2Tax),
                                   PosTaxPlan3Tax = grp.Sum(i => i.PosTaxPlan3Tax),
                                   LastUpdatedDate = _currentDateTime,
                                   LastUpdatedBy = username
                               }).FirstOrDefault();


            result.SpreadPercentage = (result.PosSalesAmount != 0 ? (((result.InstacartGMV - result.InstacartSalesTax) - result.PosSalesAmount) / result.PosSalesAmount) * 100 : 0);
            result.TaxGapTotalTax = result.InstacartSalesTax - result.PosTotalTax;
            result.TaxGapTaxPlan1Tax = result.InstacartTaxPlan1Tax - result.PosTaxPlan1Tax;
            result.TaxGapTaxPlan1TaxPlan2Tax = result.InstacartTaxPlan1TaxPlan2Tax - result.PosTaxPlan1TaxPlan2Tax;
            result.TaxGapTaxPlan3TaxPlan2Tax = result.InstacartTaxPlan3TaxPlan2Tax - result.PosTaxPlan3TaxPlan2Tax;
            result.TaxGapTaxPlan3Tax = result.InstacartTaxPlan3Tax - result.PosTaxPlan3Tax;

            result.TaxGapTaxPlan1TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan1Tax, "TaxPlan1", header);
            result.TaxGapTaxPlan1TaxPlan2TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan1TaxPlan2Tax, "TaxPlan1TaxPlan2", header);
            result.TaxGapTaxPlan3TaxPlan2TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan3TaxPlan2Tax, "TaxPlan3TaxPlan2", header);
            result.TaxGapTaxPlan3TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan3Tax, "TaxPlan3", header);
            result.TaxGapNonTaxableSales = (result.InstacartGMV - result.PosTotalSalesIncludingTax) - (result.TaxGapTaxPlan1TaxableSales + result.TaxGapTaxPlan1TaxPlan2TaxableSales + result.TaxGapTaxPlan3TaxPlan2TaxableSales + result.TaxGapTaxPlan3TaxableSales);
            return result;
        }

        internal static List<PosInstacartOrderDetailsDTO> GetUnmappedPosOrder(List<POSLineItemTransactionDTO> grpPos, PosInstacartOrderDetailsDTO hdr, DateTime _currentDateTime, string username)
        {
            if (grpPos.Any() && grpPos.Any(p => !p.IsPosMapped))
            {
                //logBO.Info(grpPos.Count(p => p.IsPosMapped == false).ToString() + "- " + hdr.InstacartOrderID);

                return grpPos.Where(p => !p.IsPosMapped).Select(postxn =>
                   new PosInstacartOrderDetailsDTO
                   {
                       InstacartOrderID = hdr.InstacartOrderID,
                       InstacartDeliveryID = hdr.InstacartDeliveryID,
                       InstacartOrderLineNumber = 999,
                       PosFacilityId = postxn.FacilityId,
                       PosTransactionDate = postxn.TransactionDate,
                       PosTransactionTM = postxn.TransactionTM,
                       PosTransactionNumber = postxn.TransactionNumber,
                       PosItemId = postxn.ItemId,
                       PosGTIN = postxn.GTINCheckDigit,
                       PosSalesVolume = postxn.SalesVolume,
                       PosSalesAmount = postxn.SalesAmount,
                       PosTotalTax = postxn.TotalTax,
                       PosTotalSalesIncludingTax = postxn.TotalSalesIncludingTax,
                       //PosTaxableSales = postxn.TaxableAmount,
                       //PosNonTaxableSales = postxn.NonTaxableSales,
                       //PosTaxPlan1TaxableSales = postxn.TaxableSalesTaxPlan1Amount,
                       //PosTaxPlan3TaxableSales = postxn.TaxableSalesTaxPlan3Amount,
                       //PosTaxPlan1TaxPlan2TaxableSales = postxn.TaxableSalesTaxPlan1TaxPlan2Amount,
                       //PosTaxPlan3TaxPlan2TaxableSales = postxn.TaxableSalesTaxPlan3TaxPlan2Amount,
                       PosTaxPlan1Tax = postxn.TaxPlan1Tax,
                       PosTaxPlan1TaxPlan2Tax = postxn.TaxPlan1TaxPlan2Tax,
                       PosTaxPlan3TaxPlan2Tax = postxn.TaxPlan3TaxPlan2Tax,
                       PosTaxPlan3Tax = postxn.TaxPlan3Tax,
                       LastUpdatedDate = _currentDateTime,
                       LastUpdatedBy = username
                   }).ToList();
            }

            return null;
        }

        internal static PosInstacartOrderDetailsDTO GetUnmappedGroupedTLogOrder(List<PosInstacartOrderDetailsDTO> mappedDetails, DateTime _currentDateTime, string username)
        {
            return mappedDetails.Where(m => m.PosFacilityId == 0 && m.PosTransactionNumber == 0 && m.PosTransactionTM == 0 && m.PosTransactionDate == null)
               .GroupBy(p => new { p.InstacartOrderID, p.InstacartDeliveryID, p.InstacartStoreLocation },
                (key, grp) => new PosInstacartOrderDetailsDTO
                {
                    InstacartOrderID = key.InstacartOrderID,
                    InstacartDeliveryID = key.InstacartDeliveryID,
                    InstacartOrderLineNumber = 997,
                    InstacartStoreLocation = key.InstacartStoreLocation,
                    InstacartQty = grp.Sum(i => i.InstacartQty),
                    InstacartOnlinePrice = grp.Sum(i => i.InstacartOnlinePrice),
                    InstacartOnlineRevenue = grp.Sum(i => i.InstacartOnlineRevenue),
                    InstacartSalesTax = grp.Sum(i => i.InstacartSalesTax),
                    InstacartGMV = grp.Sum(i => i.InstacartGMV),
                    //InstacartTaxableSales = grp.Sum(i => i.InstacartTaxableSales),
                    //InstacartNonTaxableSales = grp.Sum(i => i.InstacartNonTaxableSales),
                    //InstacartTaxPlan1TaxableSales = grp.Sum(i => i.InstacartTaxPlan1TaxableSales),
                    //InstacartTaxPlan1TaxPlan2TaxableSales = grp.Sum(i => i.InstacartTaxPlan1TaxPlan2TaxableSales),
                    //InstacartTaxPlan3TaxPlan2TaxableSales = grp.Sum(i => i.InstacartTaxPlan3TaxPlan2TaxableSales),
                    //InstacartTaxPlan3TaxableSales = grp.Sum(i => i.InstacartTaxPlan3TaxableSales),
                    InstacartTaxPlan1Tax = grp.Sum(i => i.InstacartTaxPlan1Tax),
                    InstacartTaxPlan1TaxPlan2Tax = grp.Sum(i => i.InstacartTaxPlan1TaxPlan2Tax),
                    InstacartTaxPlan3TaxPlan2Tax = grp.Sum(i => i.InstacartTaxPlan3TaxPlan2Tax),
                    InstacartTaxPlan3Tax = grp.Sum(i => i.InstacartTaxPlan3Tax),
                    LastUpdatedDate = _currentDateTime,
                    LastUpdatedBy = username
                }).FirstOrDefault();
        }

        internal static List<PosInstacartOrderDetailsDTO> GetUnMappedGroupedPosInstacartDetails(List<PosInstacartOrderDetailsDTO> unmappedPosInstDet, PosInstacartOrderDetailsDTO unmappedTLog, PosInstacartOrderDetailsDTO header, DateTime _currentDateTime, string username)
        {
            var unmappedGrpPosInstDetails = new List<PosInstacartOrderDetailsDTO>();

            // Map Grouped TLog to only one Unampped POS - incase if multiple UnamppedGrouped POS Exists.
            IEnumerable<PosInstacartOrderDetailsDTO> unmappedGroupedPos = null;
            if (unmappedPosInstDet != null)
            {
                unmappedGroupedPos = unmappedPosInstDet.GroupBy(p => new { p.PosFacilityId, p.PosTransactionDate, p.PosTransactionNumber, p.PosTransactionTM },
                                 (key, grp) => new PosInstacartOrderDetailsDTO
                                 {
                                     InstacartOrderID = header.InstacartOrderID,
                                     InstacartDeliveryID = header.InstacartDeliveryID,
                                     PosFacilityId = key.PosFacilityId,
                                     PosTransactionDate = key.PosTransactionDate,
                                     PosTransactionTM = key.PosTransactionTM,
                                     PosTransactionNumber = key.PosTransactionNumber,
                                     PosSalesVolume = grp.Sum(i => i.PosSalesVolume),
                                     PosSalesAmount = grp.Sum(i => i.PosSalesAmount),
                                     PosTotalTax = grp.Sum(i => i.PosTotalTax),
                                     PosTotalSalesIncludingTax = grp.Sum(i => i.PosTotalSalesIncludingTax),
                                     //PosTaxableSales = grp.Sum(i => i.PosTaxableSales),
                                     //PosNonTaxableSales = grp.Sum(i => i.PosNonTaxableSales),
                                     //PosTaxPlan1TaxableSales = grp.Sum(i => i.PosTaxPlan1TaxableSales),
                                     //PosTaxPlan1TaxPlan2TaxableSales = grp.Sum(i => i.PosTaxPlan1TaxPlan2TaxableSales),
                                     //PosTaxPlan3TaxPlan2TaxableSales = grp.Sum(i => i.PosTaxPlan3TaxPlan2TaxableSales),
                                     //PosTaxPlan3TaxableSales = grp.Sum(i => i.PosTaxPlan3TaxableSales),
                                     PosTaxPlan1Tax = grp.Sum(i => i.PosTaxPlan1Tax),
                                     PosTaxPlan1TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan1TaxPlan2Tax),
                                     PosTaxPlan3TaxPlan2Tax = grp.Sum(i => i.PosTaxPlan3TaxPlan2Tax),
                                     PosTaxPlan3Tax = grp.Sum(i => i.PosTaxPlan3Tax),
                                 });
            }

            if (unmappedGroupedPos != null)
            {
                var unmappedpos = unmappedGroupedPos.FirstOrDefault();

                // Map Grouped TLog to only one Unampped POS - incase if multiple UnamppedGrouped POS Exists.
                if (unmappedTLog == null)
                    unmappedGrpPosInstDetails.Add(GetPosInstOrderDetailsWithTLog(header, _currentDateTime, username, unmappedpos, new PosInstacartOrderDetailsDTO()));
                else
                    unmappedGrpPosInstDetails.Add(GetPosInstOrderDetailsWithTLog(header, _currentDateTime, username, unmappedpos, unmappedTLog));


                if (unmappedGroupedPos.Count() > 1)
                {
                    // Map Unampped POS on its own - incase if multiple UnamppedGrouped POS Exists- after mapping the Tlog to one Pos.
                    var unmppedPosOther = unmappedGroupedPos.Skip(1).Select(p => GetPosInstOrderDetailsWithTLog(header, _currentDateTime, username, p, new PosInstacartOrderDetailsDTO()));

                    if (unmppedPosOther != null && unmppedPosOther.Any())
                        unmappedGrpPosInstDetails.AddRange(unmppedPosOther);
                }
            }
            else if (unmappedTLog != null)
            {
                unmappedGrpPosInstDetails.Add(GetPosInstOrderDetailsWithTLog(header, _currentDateTime, username, new PosInstacartOrderDetailsDTO(), unmappedTLog));
            }

            return unmappedGrpPosInstDetails;
        }

        internal static List<POSLineItemTransactionDTO> GroupPosLineItemTransaction(IEnumerable<POSLineItemTransactionDTO> posTxnsForOrder)
        {
            var result = new List<POSLineItemTransactionDTO>();

            if (posTxnsForOrder != null && posTxnsForOrder.Any())
            {
                //foreach (var item in posTxnsForOrder)
                //{
                //    logBO.Info("PosTransactions:" + item.Serialize());
                //}

                result = posTxnsForOrder.GroupBy(p => new { p.ItemId, p.GTIN, p.GTINCheckDigit, p.FacilityId, p.TransactionDate, p.TransactionNumber, p.TransactionTM, p.TaxPlan1, p.TaxPlan2, p.TaxPlan3 },
                                     (key, grp) => new POSLineItemTransactionDTO
                                     {
                                         FacilityId = key.FacilityId,
                                         TransactionDate = key.TransactionDate,
                                         TransactionTM = key.TransactionTM,
                                         TransactionNumber = key.TransactionNumber,
                                         ItemId = key.ItemId,
                                         GTIN = key.GTIN,
                                         GTINCheckDigit = key.GTINCheckDigit,
                                         TaxPlan1 = key.TaxPlan1,
                                         TaxPlan2 = key.TaxPlan2,
                                         TaxPlan3 = key.TaxPlan3,
                                         SalesVolume = grp.Sum(i => i.SalesVolume),
                                         SalesAmount = grp.Sum(i => i.SalesAmount),
                                         TotalTax = grp.Sum(i => i.TotalTax),
                                         BottleDeposit = grp.Sum(i => i.BottleDeposit),
                                         TotalSalesIncludingTax = grp.Sum(i => i.TotalSalesIncludingTax),
                                         TaxableAmount = grp.Sum(i => i.TaxableAmount),
                                         NonTaxableSales = grp.Sum(i => i.NonTaxableSales),
                                         TaxableAlcoholSales = grp.Sum(i => i.TaxableAlcoholSales),
                                         TaxableNonAlcoholSales = grp.Sum(i => i.TaxableNonAlcoholSales),
                                         NonTaxableAlcoholSales = grp.Sum(i => i.NonTaxableAlcoholSales),
                                         NonTaxableNonAlcoholSales = grp.Sum(i => i.NonTaxableNonAlcoholSales),
                                         TaxPlan1Amount = grp.Sum(i => i.TaxPlan1Amount),
                                         TaxPlan2Amount = grp.Sum(i => i.TaxPlan2Amount),
                                         TaxPlan3Amount = grp.Sum(i => i.TaxPlan3Amount),
                                         //TaxableSalesTaxPlan1Amount = grp.Sum(i => i.TaxableSalesTaxPlan1Amount),
                                         //TaxableSalesTaxPlan3Amount = grp.Sum(i => i.TaxableSalesTaxPlan3Amount),
                                         //TaxableSalesTaxPlan1TaxPlan2Amount = grp.Sum(i => i.TaxableSalesTaxPlan1TaxPlan2Amount),
                                         //TaxableSalesTaxPlan3TaxPlan2Amount = grp.Sum(i => i.TaxableSalesTaxPlan3TaxPlan2Amount),
                                         TaxPlan1Tax = grp.Sum(i => i.TaxPlan1Tax),
                                         TaxPlan1TaxPlan2Tax = grp.Sum(i => i.TaxPlan1TaxPlan2Tax),
                                         TaxPlan3TaxPlan2Tax = grp.Sum(i => i.TaxPlan3TaxPlan2Tax),
                                         TaxPlan3Tax = grp.Sum(i => i.TaxPlan3Tax)
                                     }).ToList();
            }

            return result;

        }

        #region "Private Methods"
        static decimal CalculateTaxPlanAmount(decimal taxgapTotalTax, string taxplanType, POSLineItemTransactionDTO postxn)
        {
            var result = default(decimal);
            var currentdate = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));

            var storeTaxRate = storeTaxRates.FirstOrDefault(s => s.StoreNumber == postxn.FacilityId && (currentdate >= s.EffectiveDate && currentdate <= s.TerminationDate));

            if (storeTaxRate == null) return result;

            result = CalculateAmount(taxgapTotalTax, taxplanType, storeTaxRate);
            return result;
        }

        static decimal CalculateTaxPlanAmount(decimal taxgapTotalTax, string taxplanType, PosInstacartOrderDetailsDTO posinstDetails)
        {
            var result = default(decimal);
            var currentdate = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));

            var storeTaxRate = storeTaxRates.FirstOrDefault(s => s.StoreNumber == posinstDetails.PosFacilityId && (currentdate >= s.EffectiveDate && currentdate <= s.TerminationDate));

            if (storeTaxRate == null) return result;

            result = CalculateAmount(taxgapTotalTax, taxplanType, storeTaxRate);
            return result;
        }

        static decimal CalculateAmount(decimal taxgapTotalTax, string taxplanType, StoreTaxRateDTO storeTaxRate)
        {
            var result = default(decimal);

            switch (taxplanType)
            {
                case "TaxPlan1":
                    {
                        result = storeTaxRate.TaxPlan1 > 0 ? Math.Round(taxgapTotalTax / (storeTaxRate.TaxPlan1 / 100), 2) : 0;
                        break;
                    }
                case "TaxPlan1TaxPlan2":
                    {
                        result = storeTaxRate.TaxPlan1 + storeTaxRate.TaxPlan2 > 0 ? Math.Round(taxgapTotalTax / ((storeTaxRate.TaxPlan1 + storeTaxRate.TaxPlan2) / 100), 2) : 0;
                        break;
                    }
                case "TaxPlan3TaxPlan2":
                    {
                        result = storeTaxRate.TaxPlan3 + storeTaxRate.TaxPlan2 > 0 ? Math.Round(taxgapTotalTax / ((storeTaxRate.TaxPlan3 + storeTaxRate.TaxPlan2) / 100), 2) : 0;
                        break;
                    }
                case "TaxPlan3":
                    {
                        result = storeTaxRate.TaxPlan3 > 0 ? Math.Round(taxgapTotalTax / (storeTaxRate.TaxPlan3 / 100), 2) : 0;
                        break;
                    }
            }

            return result;
        }

        static PosInstacartOrderDetailsDTO GetPosInstOrderDetailsWithTLog(PosInstacartOrderDetailsDTO header, DateTime _currentDateTime, string username, PosInstacartOrderDetailsDTO unmappedpos, PosInstacartOrderDetailsDTO unmappedTLog)
        {
            var result = new PosInstacartOrderDetailsDTO
            {
                InstacartOrderID = header.InstacartOrderID,
                InstacartDeliveryID = header.InstacartDeliveryID,
                InstacartOrderLineNumber = -2,
                InstacartStoreLocation = unmappedTLog.InstacartStoreLocation,
                InstacartGTIN = unmappedTLog.InstacartGTIN,
                InstacartUnit = unmappedTLog.InstacartUnit,
                InstacartQty = unmappedTLog.InstacartQty,
                InstacartOnlinePrice = unmappedTLog.InstacartOnlinePrice,
                InstacartOnlineRevenue = unmappedTLog.InstacartOnlineRevenue,
                InstacartSalesTax = unmappedTLog.InstacartSalesTax,
                InstacartGMV = unmappedTLog.InstacartGMV,
                //InstacartTaxableSales = unmappedTLog.InstacartTaxableSales,
                //InstacartNonTaxableSales = unmappedTLog.InstacartNonTaxableSales,
                //InstacartTaxPlan1TaxableSales = unmappedTLog.InstacartTaxPlan1TaxableSales,
                //InstacartTaxPlan1TaxPlan2TaxableSales = unmappedTLog.InstacartTaxPlan1TaxPlan2TaxableSales,
                //InstacartTaxPlan3TaxPlan2TaxableSales = unmappedTLog.InstacartTaxPlan3TaxPlan2TaxableSales,
                //InstacartTaxPlan3TaxableSales = unmappedTLog.InstacartTaxPlan3TaxableSales,
                InstacartTaxPlan1Tax = unmappedTLog.InstacartTaxPlan1Tax,
                InstacartTaxPlan1TaxPlan2Tax = unmappedTLog.InstacartTaxPlan1TaxPlan2Tax,
                InstacartTaxPlan3TaxPlan2Tax = unmappedTLog.InstacartTaxPlan3TaxPlan2Tax,
                InstacartTaxPlan3Tax = unmappedTLog.InstacartTaxPlan3Tax,
                PosFacilityId = unmappedpos.PosFacilityId,
                PosTransactionDate = unmappedpos.PosTransactionDate,
                PosTransactionTM = unmappedpos.PosTransactionTM,
                PosTransactionNumber = unmappedpos.PosTransactionNumber,
                PosSalesVolume = unmappedpos.PosSalesVolume,
                PosSalesAmount = unmappedpos.PosSalesAmount,
                PosTotalTax = unmappedpos.PosTotalTax,
                PosTotalSalesIncludingTax = unmappedpos.PosTotalSalesIncludingTax,
                //PosTaxableSales = unmappedpos.PosTaxableSales,
                //PosNonTaxableSales = unmappedpos.PosNonTaxableSales,
                //PosTaxPlan1TaxableSales = unmappedpos.PosTaxPlan1TaxableSales,
                //PosTaxPlan1TaxPlan2TaxableSales = unmappedpos.PosTaxPlan1TaxPlan2TaxableSales,
                //PosTaxPlan3TaxPlan2TaxableSales = unmappedpos.PosTaxPlan3TaxPlan2TaxableSales,
                //PosTaxPlan3TaxableSales = unmappedpos.PosTaxPlan3TaxableSales,
                PosTaxPlan1Tax = unmappedpos.PosTaxPlan1Tax,
                PosTaxPlan1TaxPlan2Tax = unmappedpos.PosTaxPlan1TaxPlan2Tax,
                PosTaxPlan3TaxPlan2Tax = unmappedpos.PosTaxPlan3TaxPlan2Tax,
                PosTaxPlan3Tax = unmappedpos.PosTaxPlan3Tax,
                TaxGapTotalTax = unmappedTLog.InstacartSalesTax - unmappedpos.PosTotalTax,
                //TaxGapTaxPlan1Tax = unmappedTLog.InstacartTaxPlan1Tax - unmappedpos.PosTaxPlan1Tax,
                //TaxGapTaxPlan1TaxPlan2Tax = unmappedTLog.InstacartTaxPlan1TaxPlan2Tax - unmappedpos.PosTaxPlan1TaxPlan2Tax,
                //TaxGapTaxPlan3TaxPlan2Tax = unmappedTLog.InstacartTaxPlan3TaxPlan2Tax - unmappedpos.PosTaxPlan3TaxPlan2Tax,
                //TaxGapTaxPlan3Tax = unmappedTLog.InstacartTaxPlan3Tax - unmappedpos.PosTaxPlan3Tax,
                //TaxGapNonTaxableSales = unmappedTLog.InstacartNonTaxableSales - unmappedpos.PosNonTaxableSales,
                LastUpdatedDate = _currentDateTime,
                LastUpdatedBy = username
            };


            decimal percentageTaxPlan1Tax, percentageTaxPlan1TaxPlan2Tax, percentageTaxPlan3TaxPlan2Tax, percentageTaxPlan3Tax;
            percentageTaxPlan1Tax = percentageTaxPlan1TaxPlan2Tax = percentageTaxPlan3TaxPlan2Tax = percentageTaxPlan3Tax = 0;

            if (result.PosTotalTax > 0)
            {
                percentageTaxPlan1Tax = (result.PosTaxPlan1Tax * 100) / result.PosTotalTax;
                percentageTaxPlan1TaxPlan2Tax = (result.PosTaxPlan1TaxPlan2Tax * 100) / result.PosTotalTax;
                percentageTaxPlan3TaxPlan2Tax = (result.PosTaxPlan3TaxPlan2Tax * 100) / result.PosTotalTax;
                percentageTaxPlan3Tax = (result.PosTaxPlan3Tax * 100) / result.PosTotalTax;
            }

            result.InstacartTaxPlan1Tax = Math.Round((percentageTaxPlan1Tax * result.InstacartSalesTax) / 100, 2, MidpointRounding.AwayFromZero);
            result.InstacartTaxPlan1TaxPlan2Tax = Math.Round((percentageTaxPlan1TaxPlan2Tax * result.InstacartSalesTax) / 100, 2, MidpointRounding.AwayFromZero);
            result.InstacartTaxPlan3TaxPlan2Tax = Math.Round((percentageTaxPlan3TaxPlan2Tax * result.InstacartSalesTax) / 100, 2, MidpointRounding.AwayFromZero);
            result.InstacartTaxPlan3Tax = Math.Round((percentageTaxPlan3Tax * result.InstacartSalesTax) / 100, 2, MidpointRounding.AwayFromZero);

            result.InstacartTaxPlan1Tax = result.InstacartTaxPlan1Tax + (result.InstacartSalesTax - (result.InstacartTaxPlan1Tax + result.InstacartTaxPlan1TaxPlan2Tax + result.InstacartTaxPlan3TaxPlan2Tax + result.InstacartTaxPlan3Tax));

            result.TaxGapTotalTax = result.InstacartSalesTax - result.PosTotalTax;
            result.TaxGapTaxPlan1Tax = result.InstacartTaxPlan1Tax - result.PosTaxPlan1Tax;
            result.TaxGapTaxPlan1TaxPlan2Tax = result.InstacartTaxPlan1TaxPlan2Tax - result.PosTaxPlan1TaxPlan2Tax;
            result.TaxGapTaxPlan3TaxPlan2Tax = result.InstacartTaxPlan3TaxPlan2Tax - result.PosTaxPlan3TaxPlan2Tax;
            result.TaxGapTaxPlan3Tax = result.InstacartTaxPlan3Tax - result.PosTaxPlan3Tax;

            //if (unmappedpos.PosFacilityId != 0)
            //{
            //    result.TaxGapTaxPlan1TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan1Tax, "TaxPlan1", unmappedpos);
            //    result.TaxGapTaxPlan1TaxPlan2TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan1TaxPlan2Tax, "TaxPlan1TaxPlan2", unmappedpos);
            //    result.TaxGapTaxPlan3TaxPlan2TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan3TaxPlan2Tax, "TaxPlan3TaxPlan2", unmappedpos);
            //    result.TaxGapTaxPlan3TaxableSales = CalculateTaxPlanAmount(result.TaxGapTaxPlan3Tax, "TaxPlan3", unmappedpos);
            //}

            return result;
        }
        #endregion



    }
}


