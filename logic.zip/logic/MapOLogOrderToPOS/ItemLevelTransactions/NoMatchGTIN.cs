﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class NoMatchGTIN : MapTLogPOS
    {
        public NoMatchGTIN(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {
        }

        public async override Task<PosInstacartOrderDetailsDTO> MapTLogItemsPOSAsync(List<POSLineItemTransactionDTO> postxns, TLogDTO tlogRecord)
        {

            var postxnsGtin = await ValidateGTINAsync(postxns, tlogRecord.GTIN);

            if (postxnsGtin != null && postxnsGtin.Count > 0)
            {
                var grpPos = postxnsGtin.FirstOrDefault();//.Where(t => t.GTINCheckDigit == tlogRecord.GTIN && t.ItemId == tlogRecord.ItemId)

                foreach (var p in postxns)
                {
                    if (p.GTINCheckDigit == tlogRecord.GTIN)
                    {
                        p.IsPosMapped = true;
                        break;
                    }
                }

                return await MapTLogPOS.GetmappedPosInstDetailsAsync(grpPos, tlogRecord);
            }
            else
                return await MapTLogPOS.GetmappedPosInstDetailsAsync(new POSLineItemTransactionDTO(), tlogRecord);
        }
    }
}
