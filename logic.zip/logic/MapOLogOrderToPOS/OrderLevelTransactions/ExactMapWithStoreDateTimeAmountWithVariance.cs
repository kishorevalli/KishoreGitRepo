﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExactMapWithStoreDateTimeAmountWithVariance : MapOrderPOS
    {
        public ExactMapWithStoreDateTimeAmountWithVariance(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<POSInstacartOrderMapDTO> MapOLogOrderAsync(OLogDTO request, List<POSTransactionDTO> posTransactions)
        {
            // TO DO take minutes from Syetem values
            var posTrans = posTransactions.Where(trans => trans.FacilityId == request.StoreLocation &&
                                           trans.TransactionDate == request.TransactionDateConvertedToEST &&
                                        (request.TransactionDateTimeConvertedToEST >= trans.TransactionTime.AddMinutes(-mapNearestMinutes) &&
                                                request.TransactionDateTimeConvertedToEST <= trans.TransactionTime.AddMinutes(mapNearestMinutes)) &&
                                           trans.TenderAmount == request.TransactionAmt && !trans.IsPosMapped);

            if (posTrans == null || !posTrans.Any())
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);

            if (posTrans != null && posTrans.Count() == 1)
            {

                var result = await MapPOSInstacartOrderAsync(posTrans.FirstOrDefault(), request, Constants.SystemMessages.POSInstacartOrderMapWithStoreDateTimeAmount);

                foreach (var trans in posTransactions)
                {
                    if (trans.FacilityId == request.StoreLocation &&
                        trans.TransactionDate == request.TransactionDateConvertedToEST &&
                        request.TransactionDateTimeConvertedToEST == trans.TransactionTime &&
                        trans.TenderAmount == request.TransactionAmt)
                    {
                        trans.IsPosMapped = true;
                        break;
                    }
                }

                return result;
            }
            else
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);
        }
    }
}
