﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class NoMapFound : MapOrderPOS
    {
        public NoMapFound(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<POSInstacartOrderMapDTO> MapOLogOrderAsync(OLogDTO request, List<POSTransactionDTO> posTransactions)
        {
            return await MapPOSInstacartOrderAsync(null, request, Constants.SystemMessages.POSInstacartOrderNoMapFound);
        }
    }

}
