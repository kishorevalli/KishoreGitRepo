﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExactMapWithStoreDateAmount : MapOrderPOS
    {
        public ExactMapWithStoreDateAmount(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {
        }

        public override async Task<POSInstacartOrderMapDTO> MapOLogOrderAsync(OLogDTO request, List<POSTransactionDTO> posTransactions)
        {
            // TO DO take minutes from Syetem values
            var posTrans = posTransactions.Where(trans => trans.FacilityId == request.StoreLocation &&
                                           trans.TransactionDate == request.TransactionDateConvertedToEST &&
                                           trans.TenderAmount == request.TransactionAmt && !trans.IsPosMapped);

            if (posTrans == null || !posTrans.Any())
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);

            if (posTrans != null && posTrans.Count() == 1)
            {
                var result = await MapPOSInstacartOrderAsync(posTrans.FirstOrDefault(), request, Constants.SystemMessages.POSInstacartOrderMapWithStoreDateAmount);

                foreach (var trans in posTransactions)
                {
                    if (trans.FacilityId == request.StoreLocation &&
                        trans.TransactionDate == request.TransactionDateConvertedToEST &&
                        trans.TenderAmount == request.TransactionAmt)
                    {
                        trans.IsPosMapped = true;
                        break;
                    }
                }

                return result;
            }
            else
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);


        }
    }
}
