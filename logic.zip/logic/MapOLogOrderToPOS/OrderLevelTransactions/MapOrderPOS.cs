﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class MapOrderPOS : Common
    {
        protected MapOrderPOS nextmatchScenario;
        protected int mapNearestMinutes = 3;
        protected IMapOLogTLogToPosDac _dac;
        public abstract Task<POSInstacartOrderMapDTO> MapOLogOrderAsync(OLogDTO request, List<POSTransactionDTO> posTransactions);

        public IEnumerable<StoreMarketDTO> StoreMarket { get; set; }

        protected MapOrderPOS(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
            SystemMessages = dac.GetSystemMessages().Result;
            StoreMarket = dac.GetStoreMarket().Result;
        }

        public void SetNextMatchScenario(MapOrderPOS nextMatch)
        {
            this.nextmatchScenario = nextMatch;
        }

        protected string GetMarketForStore(int storenumber)
        {
            var market = string.Empty;

            if (StoreMarket.Any(s => s.StoreNumber == storenumber))
            {
                market = StoreMarket.FirstOrDefault(s => s.StoreNumber == storenumber).Market;
            }
            return market;
        }

        protected string GetStateForStore(int storenumber)
        {
            var state = string.Empty;

            if (StoreMarket.Any(s => s.StoreNumber == storenumber))
            {
                state = StoreMarket.FirstOrDefault(s => s.StoreNumber == storenumber).State;
            }
            return state;
        }


        protected static Task<POSInstacartOrderMapDTO> MapPOSInstacartOrderAsync(POSTransactionDTO posTrans, OLogDTO order, string msgKey)
        {
            var mapCriteriaMsgId = 0;
            mapCriteriaMsgId = order.OrderId == 0 ? SystemMessages.GetMessageId(Constants.SystemMessages.InvalidOrderId) : SystemMessages.GetMessageId(msgKey);

            return posTrans == null ? Task.FromResult(new POSInstacartOrderMapDTO
            {
                InstacartOrderID = order.OrderId,
                InstacartDeliveryID = order.DeliveryId,
                MarqetaStoreLocation = order.StoreLocation,
                MarqetaTransactionDate = order.TransactionDateConvertedToEST,
                MarqetaTransactionDateTimeEST = order.TransactionDateTimeConvertedToEST,
                MarqetaTransactionAmt = order.TransactionAmt,
                MapCriteriaMsgId = mapCriteriaMsgId
            }) : Task.FromResult(new POSInstacartOrderMapDTO
            {
                InstacartOrderID = order.OrderId,
                InstacartDeliveryID = order.DeliveryId,
                MarqetaStoreLocation = order.StoreLocation,
                MarqetaTransactionDate = order.TransactionDateConvertedToEST,
                MarqetaTransactionDateTimeEST = order.TransactionDateTimeConvertedToEST,
                MarqetaTransactionAmt = order.TransactionAmt,
                PosFacilityId = posTrans.FacilityId,
                PosTransactionDate = posTrans.TransactionDate,
                PosTransactionTM = posTrans.TransactionTM,
                PosTransactionNumber = posTrans.TransactionNumber,
                PosTransactionDateTime = posTrans.TransactionTime,
                PosTenderAmount = posTrans.TenderAmount,
                PosTotalSalesIncludingTax = posTrans.TotalSalesIncludingTax,
                PosSalesBeforeTax = posTrans.SalesBeforeTax,
                PosSalesTax = posTrans.SalesTax,
                PosNonAlcoholSales = posTrans.NonAlcoholSales,
                PosAlcoholSales = posTrans.AlcoholSales,
                PosBottleDeposit = posTrans.BottleDeposit,
                MapCriteriaMsgId = mapCriteriaMsgId
            });
        }
    }
}
