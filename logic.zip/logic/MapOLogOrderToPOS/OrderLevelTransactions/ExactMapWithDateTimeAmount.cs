﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExactMapWithDateTimeAmount : MapOrderPOS
    {
        public ExactMapWithDateTimeAmount(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {

        }

        public override async Task<POSInstacartOrderMapDTO> MapOLogOrderAsync(OLogDTO request, List<POSTransactionDTO> posTransactions)
        {
            // TO DO take minutes from Syetem values
            var posTrans = posTransactions.Where(trans => trans.TransactionDate == request.TransactionDateConvertedToEST &&
                                          request.TransactionDateTimeConvertedToEST == trans.TransactionTime &&
                                          trans.FacilityId == request.TLogStoreLocation &&
                                           trans.TenderAmount == request.TransactionAmt && !trans.IsPosMapped);

            if (posTrans == null || !posTrans.Any())
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);

            var posStoreState = GetStateForStore(posTrans.FirstOrDefault().FacilityId);
            var ologStoreState = GetStateForStore(request.StoreLocation);


            if (posTrans != null && posTrans.Count() == 1)//&& posStoreState == ologStoreState
            {
                var result = await MapPOSInstacartOrderAsync(posTrans.FirstOrDefault(), request, Constants.SystemMessages.POSInstacartOrderMapWithDateTimeAmount);

                foreach (var trans in posTransactions)
                {
                    if (trans.TransactionDate == request.TransactionDateConvertedToEST &&
                        request.TransactionDateTimeConvertedToEST == trans.TransactionTime &&
                        trans.FacilityId == request.TLogStoreLocation &&
                        trans.TenderAmount == request.TransactionAmt)
                    {
                        trans.IsPosMapped = true;
                        break;
                    }
                }
                return result;
            }
            else
                return await nextmatchScenario.MapOLogOrderAsync(request, posTransactions);
        }
    }
}
