﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class MapPosActionsAbstract : Common
    {
        readonly IMapOLogTLogToPosDac _dac;
        protected MapPosActionsAbstract(IMapOLogTLogToPosDac dac, string jobname, List<POSInstacartOrderMapDTO> _mappedOLogPosOrders) : base(dac, jobname)
        {
            _dac = dac;
            MappedOLogToPosOrders = _mappedOLogPosOrders;

            // Max Parallelism from DB
            MaxDegreeOfParallelismForMapOLogTLogToPos = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismForMapOLogTLogToPos);
        }

        public List<POSInstacartOrderMapDTO> MappedOLogToPosOrders { get; set; }
        public int MaxDegreeOfParallelismForMapOLogTLogToPos { get; set; }
        protected internal abstract void ConfigureMappingScenarios();
        protected internal abstract Task PrepareMappingDataAsync(DateTime _currentDateTime, string username);
        protected internal abstract Task<List<POSInstacartOrderMapDTO>> ProcessAndInsertDataAsync(DateTime _currentDateTime, string username );
    }
}
