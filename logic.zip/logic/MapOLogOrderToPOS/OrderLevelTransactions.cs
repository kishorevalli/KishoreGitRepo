﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class OrderLevelTransactions : MapPosActionsAbstract
    {
        readonly IMapOLogTLogToPosDac _dac;
        MapOrderPOS storeDateTimeAmountScenario;

        public OrderLevelTransactions(IMapOLogTLogToPosDac dac, string jobname, List<POSInstacartOrderMapDTO> _mappedOLogPosOrders) : base(dac, jobname, _mappedOLogPosOrders)
        {
            _dac = dac;
        }

        public List<OLogDTO> OLogOrders { get; private set; }
        public List<POSTransactionDTO> PosTransactions { get; private set; }

        protected internal override void ConfigureMappingScenarios()
        {
            storeDateTimeAmountScenario = new ExactMapWithStoreDateTimeAmount(_dac, jobname);
            MapOrderPOS storeDateAmountScenarioWithVariance = new ExactMapWithStoreDateTimeAmountWithVariance(_dac, jobname);
            MapOrderPOS storeDateAmountScenario = new ExactMapWithStoreDateAmount(_dac, jobname);
            MapOrderPOS dateTimeAmountScenario = new ExactMapWithDateTimeAmount(_dac, jobname);
            MapOrderPOS dateTimeAmountScenarioWithVariance = new ExactMapWithDateTimeAmountWithVariance(_dac, jobname);
            MapOrderPOS dateAmountScenario = new ExactMapWithDateAmount(_dac, jobname);
            MapOrderPOS returnedStoreAmountDateScenario = new ExactMapWithReturnedStoreAmountDate(_dac, jobname);
            MapOrderPOS returnedAmountDateScenario = new ExactMapWithReturnedAmountDate(_dac, jobname);
            MapOrderPOS noMapScenario = new NoMapFound(_dac, jobname);

            storeDateTimeAmountScenario.SetNextMatchScenario(storeDateAmountScenarioWithVariance);
            storeDateAmountScenarioWithVariance.SetNextMatchScenario(storeDateAmountScenario);
            storeDateAmountScenario.SetNextMatchScenario(dateTimeAmountScenario);
            dateTimeAmountScenario.SetNextMatchScenario(dateTimeAmountScenarioWithVariance);
            dateTimeAmountScenarioWithVariance.SetNextMatchScenario(dateAmountScenario);
            dateAmountScenario.SetNextMatchScenario(returnedStoreAmountDateScenario);
            returnedStoreAmountDateScenario.SetNextMatchScenario(returnedAmountDateScenario);
            returnedAmountDateScenario.SetNextMatchScenario(noMapScenario);
        }

        protected internal async override Task PrepareMappingDataAsync(DateTime _currentDateTime, string username)
        {
            logBO.Info(jobname + "- Prepare Mapping Data for Order Level Transactions - Start");

            var ordersFromDt = DateTime.MinValue;
            var ordersToDt = DateTime.MinValue;

            var posinstInterval = await _dac.GetPosInstacartOrderMapInterval();
            if (posinstInterval.Orders)
            {
                OLogOrders = await _dac.GetOLogOrdersById(posinstInterval.OrderIds);
                MappedOLogToPosOrders = await _dac.GetPosInstacartOrderMapById(posinstInterval.OrderIds); //For ForceReMap

                if (OLogOrders != null && OLogOrders.Count > 0)
                {
                    ordersFromDt = OLogOrders.Min(o => o.TransactionDate);
                    ordersToDt = OLogOrders.Max(o => o.TransactionDate);
                }
            }
            else if (posinstInterval.DateRange)
            {
                ordersFromDt = posinstInterval.FromDate;
                ordersToDt = posinstInterval.ToDate;
                OLogOrders = await _dac.GetOLogOrders(ordersFromDt, ordersToDt);  //Olog Orders
                MappedOLogToPosOrders = await _dac.GetPosInstacartOrderMapByDateRange(ordersFromDt, ordersToDt); //For ForceReMap
            }
            else
            {
                //OMNI gets Yesterday's Transactions today,
                //Hence to cover a complete month, start of the next month is considered as start date.

                var currentDt = DateTime.Now;

                if (OmniExtensions.today.Day == 1)
                {
                    ordersFromDt = OmniExtensions.lastMonthStart;
                    ordersToDt = OmniExtensions.lastMonthEnd;
                }
                else
                {
                    ordersFromDt = OmniExtensions.thisMonthStart;
                    ordersToDt = OmniExtensions.thisMonthEnd;
                }

                //ordersFromDt = new DateTime(currentDt.Year, currentDt.Month, 1); //2nd Of the Month
                //ordersToDt = ordersFromDt.AddMonths(1); //1st day of next month, due to above mentioned reason

                OLogOrders = await _dac.GetOLogOrders(ordersFromDt, ordersToDt);  //Olog Orders
                MappedOLogToPosOrders = await _dac.GetPosInstacartOrderMapByDateRange(ordersFromDt, ordersToDt); //For ForceReMap
            }

            if (OLogOrders != null && OLogOrders.Count > 0 && ordersFromDt != DateTime.MinValue & ordersToDt != DateTime.MinValue)
            {
                //Get Additional POS data - adding the days to From Date of Order Date
                var posOrdersFromDt = ordersFromDt.AddDays(-SystemValues.GetValue<int>(Constants.SystemValues.NoOfDaysAdditionalPOSTransactionsData));
                PosTransactions = await _dac.GetPOSTransactions(posOrdersFromDt, ordersToDt); //POS Transactions

                logBO.Info(jobname + "- Prepare Mapping Data for Order Level Transactions - End");
            }
            else
                logBO.Info(jobname + "- NO Orders To Process - Prepare Mapping Data for Order Level Transactions - End");
        }

        protected internal async override Task<List<POSInstacartOrderMapDTO>> ProcessAndInsertDataAsync(DateTime _currentDateTime, string username)
        {
            var sync = new object();
            var ologOrdersToProcess = new List<OLogDTO>();

            try
            {
                logBO.Info(jobname + "- Process Order Level Transactions - Start");

                if (MappedOLogToPosOrders != null && MappedOLogToPosOrders.Count > 0)
                    ologOrdersToProcess = OLogOrders.Where(o => !MappedOLogToPosOrders.Any(m => m.InstacartOrderID == o.OrderId )).ToList();
                else
                    ologOrdersToProcess = OLogOrders;

                await Task.Run(() => Parallel.ForEach(ologOrdersToProcess, new ParallelOptions { MaxDegreeOfParallelism = MaxDegreeOfParallelismForMapOLogTLogToPos },
                         ordr =>
                         {
                             var mpOrdr = storeDateTimeAmountScenario.MapOLogOrderAsync(ordr, PosTransactions).Result;

                             if (mpOrdr != null)
                             {
                                 mpOrdr.LastUpdatedDate = _currentDateTime;
                                 mpOrdr.LastUpdatedBy = username;
                                 lock (sync) MappedOLogToPosOrders.Add(mpOrdr);
                             }
                         }));

                await _dac.InsertPOSInstacartOrdersMap(MappedOLogToPosOrders, new POSInstacartOrderMapDTO().GetPropertyMembers());
                logBO.Info(jobname + "- Process Order Level Transactions - End");
            }
            catch (AggregateException ex)
            {
                foreach (var inrecep in ex.InnerExceptions)
                    logBO.Error(jobname + "- " + inrecep);

                throw;
            }
            return MappedOLogToPosOrders;
        }
    }
}
