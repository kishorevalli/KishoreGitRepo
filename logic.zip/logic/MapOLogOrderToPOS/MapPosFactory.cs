﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class MapPosFactory : Common, IMapPosFactory
    {
        readonly IMapOLogTLogToPosDac _dac;
        readonly string _jobname;
        public MapPosFactory(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
            _jobname = jobname;
        }

        public MapPosActionsAbstract GetActions(FileTypeEnum filetypeProcess, List<POSInstacartOrderMapDTO> _mappedOLogPosOrders)
        {
            MapPosActionsAbstract result = null;

            switch (filetypeProcess)
            {
                case FileTypeEnum.OLOG:
                    result = new OrderLevelTransactions(_dac, _jobname, new List<POSInstacartOrderMapDTO>());
                    break;

                case FileTypeEnum.TLOG:
                    result = new ItemLevelTransactions(_dac, _jobname, _mappedOLogPosOrders);
                    break;
            }

            return result;
        }
    }
}
