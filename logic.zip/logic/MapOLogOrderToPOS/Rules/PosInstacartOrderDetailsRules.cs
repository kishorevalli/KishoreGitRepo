﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class PosInstacartOrderDetailsRules<T> : IRuleBuilder<T> where T : PosInstacartOrderDetailsDTO
    {


        internal IRule<T> PosTotalTaxGreaterThanInstacartTotalTax
        {
            get
            {
                return new Rule<T>("PosTotalTaxGreaterThanInstacartTotalTax", RuleTypeEnum.Discrepancy, (T entity) =>
               {
                   if (entity != null)
                   {
                       if (entity.InstacartOrderLineNumber > 0)
                       {
                           return entity.PosTotalTax > entity.InstacartSalesTax ? false : true;
                       }
                   }
                   return true;
               });
            }
        }

        internal IRule<T> PosTotalTaxGreaterThanInstacartTotalTaxHeader
        {
            get
            {
                return new Rule<T>("PosTotalTaxGreaterThanInstacartTotalTax", RuleTypeEnum.Exception, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber == 0)
                        {
                            return entity.PosTotalTax > entity.InstacartSalesTax ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TLogDoesNotHaveIdentifier
        {
            get
            {
                return new Rule<T>("TLogDoesNotHaveIdentifier", RuleTypeEnum.Discrepancy, (T entity) =>
                 {
                     if (entity != null)
                     {
                         if (entity.InstacartOrderLineNumber > 0)
                             return entity.InstacartGTIN == 0 && entity.InstacartReferenceCode == 0 ? false : true;
                     }
                     return true;
                 });
            }
        }

        internal IRule<T> TaxGapTaxPlan1AmountIsNegative
        {
            get
            {
                return new Rule<T>("TaxGapTaxPlan1AmountIsNegative", RuleTypeEnum.Discrepancy, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber > 0)
                        {
                            return entity.TaxGapTaxPlan1Tax < 0 ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TaxGapTaxPlan1TaxPlan2AmountIsNegative
        {
            get
            {
                return new Rule<T>("TaxGapTaxPlan1TaxPlan2AmountIsNegative", RuleTypeEnum.Discrepancy, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber > 0)
                        {
                            return entity.TaxGapTaxPlan1TaxPlan2Tax < 0 ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TaxGapTaxPlan3TaxPlan2AmountIsNegative
        {
            get
            {
                return new Rule<T>("TaxGapTaxPlan3TaxPlan2AmountIsNegative", RuleTypeEnum.Discrepancy, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber > 0)
                        {
                            return entity.TaxGapTaxPlan3TaxPlan2Tax < 0 ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TaxGapTaxPlan3AmountIsNegative
        {
            get
            {
                return new Rule<T>("TaxGapTaxPlan3AmountIsNegative", RuleTypeEnum.Discrepancy, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber > 0)
                        {
                            return entity.TaxGapTaxPlan3Tax < 0 ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TaxGapTaxPlan1AmountIsNegativeHeader
        {
            get
            {
                return new Rule<T>("TaxGapTaxPlan1AmountIsNegative", RuleTypeEnum.Exception, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber == 0)
                        {
                            return entity.TaxGapTaxPlan1Tax < 0 ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TaxGapTaxPlan1TaxPlan2AmountIsNegativeHeader
        {
            get
            {
                return new Rule<T>("TaxGapTaxPlan1TaxPlan2AmountIsNegative", RuleTypeEnum.Exception, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber == 0)
                        {
                            return entity.TaxGapTaxPlan1TaxPlan2Tax < 0 ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TaxGapTaxPlan3TaxPlan2AmountIsNegativeHeader
        {
            get
            {
                return new Rule<T>("TaxGapTaxPlan3TaxPlan2AmountIsNegative", RuleTypeEnum.Exception, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber == 0)
                        {
                            return entity.TaxGapTaxPlan3TaxPlan2Tax < 0 ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TaxGapTaxPlan3AmountIsNegativeHeader
        {
            get
            {
                return new Rule<T>("TaxGapTaxPlan3AmountIsNegative", RuleTypeEnum.Exception, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber == 0)
                        {
                            return entity.TaxGapTaxPlan3Tax < 0 ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> NoTLogItemMappedWithPosItemButHeaderMapped
        {
            get
            {
                return new Rule<T>("NoTLogItemMappedWithPosItemButHeaderMapped", RuleTypeEnum.Exception, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber <= 0)
                        {
                            return (entity.TaxGapTaxPlan1Tax == entity.InstacartTaxPlan1Tax &&
                            entity.TaxGapTaxPlan1TaxPlan2Tax == entity.InstacartTaxPlan1TaxPlan2Tax &&
                            entity.TaxGapTaxPlan3TaxPlan2Tax == entity.InstacartTaxPlan3TaxPlan2Tax &&
                            entity.TaxGapTaxPlan3Tax == entity.InstacartTaxPlan3Tax &&
                            entity.TaxGapTotalTax == entity.InstacartSalesTax &&
                            entity.PosTotalTax != 0 && entity.InstacartSalesTax != 0) ? false : true;
                            //&&  entity.TaxGapNonTaxableSales == entity.InstacartNonTaxableSales
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TLogQtyPOSQtyMismatch
        {
            get
            {
                return new Rule<T>("TLogQtyPOSQtyMismatch", RuleTypeEnum.Discrepancy, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber > 0)
                        {
                            return entity.InstacartQty != entity.PosSalesVolume ? false : true;
                        }
                    }
                    return true;
                });
            }
        }

        internal IRule<T> TLogMissingPosMapping
        {
            get
            {
                return new Rule<T>("TLogMissingPosMapping", RuleTypeEnum.Discrepancy, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber > 0)
                        {
                            if (entity.PosFacilityId == 0 && entity.PosTransactionDate == null && entity.PosTransactionTM == 0 && entity.PosTransactionNumber == 0)
                            {
                                return false;
                            }
                        }
                    }
                    return true;
                });
            }
        }


        internal IRule<T> TLogMissingPosMappingHeader
        {
            get
            {
                return new Rule<T>("TLogMissingPosMapping", RuleTypeEnum.Exception, (T entity) =>
                {
                    if (entity != null)
                    {
                        if (entity.InstacartOrderLineNumber <= 0)
                        {
                            if (entity.PosFacilityId == 0 && entity.PosTransactionDate == null && entity.PosTransactionTM == 0 && entity.PosTransactionNumber == 0)
                            {
                                return false;
                            }
                        }
                    }
                    return true;
                });
            }
        }




        public IRuleValidator<T> BuildRules
        {
            get
            {
                return new RuleValidator<T>(
                                PosTotalTaxGreaterThanInstacartTotalTax,
                                TLogDoesNotHaveIdentifier,
                                TaxGapTaxPlan1AmountIsNegative,
                                TaxGapTaxPlan1TaxPlan2AmountIsNegative,
                                TaxGapTaxPlan3TaxPlan2AmountIsNegative,
                                TaxGapTaxPlan3AmountIsNegative,
                                TLogQtyPOSQtyMismatch,
                                TLogMissingPosMapping,
                                PosTotalTaxGreaterThanInstacartTotalTaxHeader,
                                TaxGapTaxPlan1AmountIsNegativeHeader,
                                TaxGapTaxPlan1TaxPlan2AmountIsNegativeHeader,
                                TaxGapTaxPlan3TaxPlan2AmountIsNegativeHeader,
                                TaxGapTaxPlan3AmountIsNegativeHeader,
                                NoTLogItemMappedWithPosItemButHeaderMapped,
                                TLogMissingPosMappingHeader);
            }
        }
    }
}
