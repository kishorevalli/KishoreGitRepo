﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ItemLevelTransactions : MapPosActionsAbstract
    {
        readonly IMapOLogTLogToPosDac _dac;
        MapTLogPOS itemgtinscneario;

        public IEnumerable<PosInstacartAggregatedOrderMapDTO> AggregatedOlogOrders { get; private set; }
        public static List<FileTypeDiscrepancyDTO> Discreapancies { get; private set; }

        public ItemLevelTransactions(IMapOLogTLogToPosDac dac, string jobname, List<POSInstacartOrderMapDTO> _mappedOLogPosOrders) : base(dac, jobname, _mappedOLogPosOrders)
        {
            _dac = dac;
        }
        protected internal override void ConfigureMappingScenarios()
        {
            itemgtinscneario = new ExactMatchItemGTIN(_dac, jobname);
            MapTLogPOS itemscenario = new ExactMatchItem(_dac, jobname);
            MapTLogPOS gtinscenario = new ExactMatchGTIN(_dac, jobname);
            MapTLogPOS nomatchscenario = new NoMatchGTIN(_dac, jobname);

            itemgtinscneario.SetNextmatch(itemscenario);
            itemscenario.SetNextmatch(gtinscenario);
            gtinscenario.SetNextmatch(nomatchscenario);
        }

        protected internal override Task PrepareMappingDataAsync(DateTime _currentDateTime, string username)
        {
            logBO.Info(jobname + "- Prepare Mapping Data for Item Level Transactions - Start");

            AggregatedOlogOrders = MappedOLogToPosOrders.Where(ol => ol.InstacartOrderID != 0)
                                                        .GroupBy(o => new { o.InstacartOrderID, o.InstacartDeliveryID },
                                (key, grp) => new PosInstacartAggregatedOrderMapDTO
                                {
                                    InstacartOrderID = key.InstacartOrderID,
                                    InstacartDeliveryID = key.InstacartDeliveryID,
                                    MarqetaTransactionAmt = grp.Sum(o => o.MarqetaTransactionAmt),
                                    PosTenderAmount = grp.Sum(o => o.PosTenderAmount),
                                    PosTotalSalesIncludingTax = grp.Sum(o => o.PosTotalSalesIncludingTax),
                                    PosSalesBeforeTax = grp.Sum(o => o.PosSalesBeforeTax),
                                    PosSalesTax = grp.Sum(o => o.PosSalesTax),
                                    PosNonAlcoholSales = grp.Sum(o => o.PosNonAlcoholSales),
                                    PosAlcoholSales = grp.Sum(o => o.PosAlcoholSales),
                                    PosBottleDeposit = grp.Sum(o => o.PosBottleDeposit),
                                    LastUpdatedBy = username,
                                    LastUpdatedDate = _currentDateTime
                                });

            logBO.Info(jobname + "- Prepare Mapping Data for Item Level Transactions - End");
            return Task.FromResult(0);
        }

        protected internal async override Task<List<POSInstacartOrderMapDTO>> ProcessAndInsertDataAsync(DateTime _currentDateTime, string username)
        {
            try
            {
                logBO.Info(jobname + "- Process Item Level Transactions - Start");

                var queue = new ConcurrentQueue<List<PosInstacartOrderDetailsDTO>>();
                var sync = new object();
                Discreapancies = new List<FileTypeDiscrepancyDTO>();

                await _dac.TruncatePOSInstacartOrdersDetailsStaging();

                var DistinctAggregatedOrders = AggregatedOlogOrders.Select(o => o.InstacartOrderID).Distinct();

                await Task.Run(() =>
                Parallel.ForEach(DistinctAggregatedOrders, new ParallelOptions { MaxDegreeOfParallelism = MaxDegreeOfParallelismForMapOLogTLogToPos },
                ordr =>
                {
                    var mappedDetails = new List<PosInstacartOrderDetailsDTO>();
                    var posInstacartOrders = MappedOLogToPosOrders.Where(o => o.InstacartOrderID == ordr);
                    var posinstOrdr = posInstacartOrders.FirstOrDefault();
                    var tlogsForOrder = _dac.GetTLogTranscations(ordr.ToString()).Result;
                    var grpTlogForOrder = MapTLogPOS.GroupTLogOrders(tlogsForOrder);
                    var posTxnsForOrder = _dac.GetPOSLineTransactions(posInstacartOrders).Result;
                    var grpPos = MapTLogPOS.GroupPosLineItemTransaction(posTxnsForOrder);


                    if (grpTlogForOrder.Any())
                    {
                        Parallel.ForEach(grpTlogForOrder, new ParallelOptions { MaxDegreeOfParallelism = MaxDegreeOfParallelismForMapOLogTLogToPos },
                            tlogordr =>
                            {
                                var det = itemgtinscneario.MapTLogItemsPOSAsync(grpPos, tlogordr).Result;
                                if (det != null)
                                {
                                    det.LastUpdatedDate = _currentDateTime;
                                    det.LastUpdatedBy = username;
                                    lock (sync) mappedDetails.Add(det);
                                }
                            });

                        var mappedOrderHeader = MapTLogPOS.GetPosInstacartOrderDetailsHeader(posinstOrdr, mappedDetails, _currentDateTime, username);    // Header Record for Mapped Line Items.

                        if (mappedOrderHeader != null)
                        {
                            if (mappedOrderHeader.Any(h => h.Type != RuleTypeEnum.Exception))  // Insert Unmapped Pos only if Items of Tlog matched with Pos.
                            {
                                var mappedOrderHeaderNoExcep = mappedOrderHeader.FirstOrDefault(h => h.Type != RuleTypeEnum.Exception);

                                var unmappedPosDetails = MapTLogPOS.GetUnmappedPosOrder(grpPos, mappedOrderHeaderNoExcep, _currentDateTime, username);
                                var unamppedTlog = MapTLogPOS.GetUnmappedGroupedTLogOrder(mappedDetails, _currentDateTime, username);

                                if (unmappedPosDetails != null || unamppedTlog != null)
                                {
                                    if (unmappedPosDetails != null)
                                        lock (sync) mappedDetails.AddRange(unmappedPosDetails); //Add Unampped Pos Orders as Details for the Order

                                    var unmappedGroupedDetails = MapTLogPOS.GetUnMappedGroupedPosInstacartDetails(unmappedPosDetails, unamppedTlog, mappedOrderHeaderNoExcep, _currentDateTime, username); //orderlinenumber = -2  UnMapped items Header
                                    lock (sync) mappedDetails.AddRange(unmappedGroupedDetails); // Header Record for UnMapped Line Items.

                                    // Evaluate new Header from MappedHeader && UnMapped Header with OrderLineNumber = 0
                                    unmappedGroupedDetails.AddRange(mappedOrderHeader);
                                    var posMapUnMapDetailsHeader = MapTLogPOS.GetHeaderForMappedUnMappedPosInstDetails(unmappedGroupedDetails, mappedOrderHeaderNoExcep, _currentDateTime, username);
                                    lock (sync) mappedDetails.Add(posMapUnMapDetailsHeader); //Header Record for Mapped and UnMapped Line Items.

                                    mappedOrderHeader.ForEach(a => a.InstacartOrderLineNumber = -1); // Making Mapped header record as -1, as another Header is created for mapped & Unmapped.
                                }
                                else if (mappedOrderHeader.Count > 1)
                                {
                                    var posMapUnMapDetailsHeader = MapTLogPOS.GetHeaderForMappedUnMappedPosInstDetails(mappedOrderHeader, mappedOrderHeader.FirstOrDefault(), _currentDateTime, username);
                                    lock (sync) mappedDetails.Add(posMapUnMapDetailsHeader); //Header Record for Mapped and UnMapped Line Items.

                                    mappedOrderHeader.ForEach(a => a.InstacartOrderLineNumber = -1); // Making Mapped header record as -1, as another Header is created for mapped & Unmapped.
                                }

                            }

                            lock (sync) mappedDetails.AddRange(mappedOrderHeader); //Add Pos Instacart Order Details Header
                        }

                        queue.Enqueue(mappedDetails);
                    }


                    while (queue.Count > 0)
                    {
                        var item = new List<PosInstacartOrderDetailsDTO>();
                        if (queue.TryDequeue(out item))
                        {
                            ValidateMappedPosInstacartOrder(item, _currentDateTime);
                        }
                    }
                }));

                var taskPosInst = _dac.InsertPOSInstacartOrdersDetailsStagingToMain();
                var taskDispcy = _dac.InsertFileTypeDiscrepancies(Discreapancies, new FileTypeDiscrepancyDTO().GetPropertyMembers());
                var taskAggr = _dac.InsertAggregatedOlogOrders(AggregatedOlogOrders, new PosInstacartAggregatedOrderMapDTO().GetPropertyMembers());

                Task.WaitAll(taskPosInst, taskDispcy, taskAggr);

                await _dac.TruncatePOSInstacartOrdersDetailsStaging();

                logBO.Info(jobname + "- Process Item Level Transactions - End");
            }
            catch (AggregateException ex)
            {
                foreach (var inrecep in ex.InnerExceptions)
                    logBO.Error(jobname + "- " + inrecep);

                throw;
            }

            return null;
        }


        public void ValidateMappedPosInstacartOrder(List<PosInstacartOrderDetailsDTO> details, DateTime _currentDateTime)
        {
            var posinstRules = new PosInstacartOrderDetailsRules<PosInstacartOrderDetailsDTO>();
            foreach (var det in details)
            {
                var result = posinstRules.BuildRules.Validate(det);

                if (!result.IsSuccess && result.ErrorMessages != null)
                {
                    if (result.ErrorMessages.Any())
                    {
                        result.ErrorMessages.ForEach(m =>
                        {
                            Discreapancies.Add(new FileTypeDiscrepancyDTO
                            {
                                OrderId = det.InstacartOrderID,
                                DeliveryId = det.InstacartDeliveryID,
                                StoreLocation = det.InstacartStoreLocation,
                                FileTypeId = 6,
                                GTIN = det.InstacartGTIN,
                                MessageId = SystemMessages.GetMessageId(m),
                                ReasonDetail = string.Empty,
                                LastUpdateDate = _currentDateTime
                            });
                        });
                    }
                }
            }
            _dac.InsertPOSInstacartOrdersDetails(details, new PosInstacartOrderDetailsDTO().GetPropertyMembers());
        }

    }
}
