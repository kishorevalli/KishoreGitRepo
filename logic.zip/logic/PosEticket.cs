﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Messaging;
using System.Text;
using System.Threading.Tasks;
using IBM.WMQ;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class PosEticket : Common, IPosEticket
    {
        readonly IPosEticketDac _dac;
        static DateTime tranmissionDateTime;


        public PosEticket(IPosEticketDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
            tranmissionDateTime = DateTime.Now;
        }

        public DateRangeDTO ETicketDateRange { get; set; }

        public async Task GetEticketTypeInterval(string eTicketType)
        {
            var eTicketInterval = await _dac.GetETicketTypeInterval(eTicketType);
            ETicketDateRange = GetDateRangeForInterval(eTicketInterval);
            ETicketDateRange.TransmissionDateTime = tranmissionDateTime;
            ETicketDateRange.SystemUserName = System.Environment.UserName;
        }

        public async Task PrepareETicketData(string eTicketType)
        {
            var strs = SystemValues.GetValue<string>(Constants.SystemValues.GenerateETicketByStore);

            switch (eTicketType)
            {
                case Constants.JobArgs.Regular:
                    {
                        await GetEticketTypeInterval(eTicketType);

                        if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipPrepareDataPosETicket))
                        {
                            logBO.Info(jobname + "- Prepare Regular ETicket data - Start");
                            if (strs == "")
                                await _dac.PrepareRegularETicketData(eTicketType, ETicketDateRange);
                            else
                                await _dac.PrepareRegularETicketDataByStore(eTicketType, ETicketDateRange, strs);
                            logBO.Info(jobname + "- Prepare Regular ETicket data - End");
                        }
                        //CP008DX
                        //Moved this code from GenerateETicket method to here 
                        //to handle all preparations of data in one place 
                        logBO.Info(jobname + "- Setup POS Eticket Data " + eTicketType + " ETicket - Start");
                        await _dac.SetUpPosETicketData(eTicketType, ETicketDateRange);
                        logBO.Info(jobname + "- Setup POS Eticket Data " + eTicketType + " ETicket - End");

                        break;
                    }
                case Constants.JobArgs.TrueUp:
                    {
                        await GetEticketTypeInterval(eTicketType);

                        if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipPrepareDataPosETicket))
                        {
                            logBO.Info(jobname + "- Prepare TrueUp ETicket data - Start");
                            if (strs == "")
                                await _dac.PrepareTrueUpETicketData(eTicketType, ETicketDateRange);
                            else
                                await _dac.PrepareTrueUpETicketDataByStore(eTicketType, ETicketDateRange, strs);
                            logBO.Info(jobname + "- Prepare TrueUp ETicket data - End");

                        }
                        //CP008DX
                        //Moved this code from GenerateETicket method to here 
                        //to handle all preparations of data in one place 
                        logBO.Info(jobname + "- Setup POS Eticket Data " + eTicketType + " ETicket - Start");
                        await _dac.SetUpPosETicketData(eTicketType, ETicketDateRange);
                        logBO.Info(jobname + "- Setup POS Eticket Data " + eTicketType + " ETicket - End");

                        break;
                    }
                //Added this case to post eTicket --CP008DX
                case Constants.JobArgs.ETicket:
                    {
                        GenerateETicket(Constants.JobArgs.Regular).Wait();
                        break;
                    }

            }
        }

        public async Task GenerateETicket(string eTicketType)
        {

            //As part of job split implementation,  removing the additional falgs for  SkipGenerateETicket,SkipPublishETicket -CP008DX
            logBO.Info(jobname + "- Generate " + eTicketType + " ETicket - Start");
            var salestxn = await _dac.GetPosETicketData();

            if (salestxn != null && salestxn.Count() > 0)
            {
                await PublishETicket(eTicketType, salestxn);
            }
            else
            {
                logBO.Info(jobname + "- There are NO E-Tickets to Publish ETicket for the Type: " + eTicketType);
            }

            logBO.Info(jobname + "- Generate " + eTicketType + " ETicket - End");

        }


        #region "Private Methods"
        async Task PublishETicket(string eTicketType, IEnumerable<CreateSalesTransactionXML1> salestxn)
        {
            try
            {
                if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipETicketPostMQ))
                {
                    var mqManger = SystemParameters.GetValue(Constants.SystemParameters.POSEticketMQQueueManager);
                    var mqQueue = SystemParameters.GetValue(Constants.SystemParameters.POSEticketMQQueue);

                    logBO.Info(jobname + "- Connecting to MQ Manager " + mqManger);
                    using (var queueManager = new MQQueueManager(mqManger))
                    {
                        logBO.Info(jobname + "- Connection to MQ Manager " + mqManger + " Successful");


                        logBO.Info(jobname + "- Accessing to MQ Queue " + mqQueue);
                        var queue = queueManager.AccessQueue(mqQueue, MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING + MQC.MQOO_INQUIRE);
                        logBO.Info(jobname + "- Access to MQ Queue " + mqQueue + " Successful");


                        var pmo = new MQPutMessageOptions();// { Options = MQC.MQPMO_NEW_MSG_ID };   //+ MQC.MQPMO_SYNCPOINT 

                        foreach (var item in salestxn)
                        {
                            var message = new MQMessage { Format = MQC.MQFMT_STRING };


                            logBO.Info(jobname + "- Publish ETicket for Store " + item.StoreNumber + " - Start");

                            message.WriteString(item.SerializeToBytes());
                            queue.Put(message, pmo);

                            //logBO.Info(jobname + "- MessageId:" + message.MessageId.GetHexString());

                            logBO.Info(jobname + "- Publish ETicket for Store " + item.StoreNumber + " - End");

                            if (MQC.MQCC_OK != pmo.CompletionCode)
                            {
                                logBO.Error(jobname + "- MQQueue CompletionCode:" + pmo.CompletionCode + " - MQQueue ReasonCode:" + pmo.ReasonCode + " - MQQueue ReasonName:" + pmo.ReasonName);
                            }

                            await UpdateETicketDetails(eTicketType, item, message);
                        }
                        //queueManager.Commit();
                    }

                }
                else
                {
                    foreach (var item in salestxn)
                    {
                        logBO.Info(jobname + "- Update ETicket Xml for Store " + item.StoreNumber + " - Start");
                        var msg = new ETicketMessageDTO
                        {
                            Id = item.EticketId,
                            DateRange = ETicketDateRange,
                            ETicketType = eTicketType,
                            StoreNumber = item.StoreNumber,
                            XmlString = item.Serialize(),
                            MQMessageId = "000000000000000000000000000000000000000000000000"
                        };
                        await _dac.UpdatePosETicketDataXml(msg);
                        logBO.Info(jobname + "- Update ETicket Xml for Store " + item.StoreNumber + " - End");
                    }
                }

            }
            catch (MQException mqEx)
            {
                logBO.Error(jobname + "- MQQueue CompletionCode:" + mqEx.CompletionCode + " - MQQueue ReasonCode:" + mqEx.ReasonCode + " - MQQueue ReasonName:" + mqEx.Reason);
                logBO.Error(jobname + "- MQException:" + mqEx);
                throw;
            }
        }

        async Task UpdateETicketDetails(string eTicketType, CreateSalesTransactionXML1 item, MQMessage message)
        {
            logBO.Info(jobname + "- Update ETicket Xml for Store " + item.StoreNumber + " - Start");
            var msg = new ETicketMessageDTO
            {
                Id = item.EticketId,
                DateRange = ETicketDateRange,
                ETicketType = eTicketType,
                StoreNumber = item.StoreNumber,
                XmlString = item.Serialize(),
                MQMessageId = message.MessageId.GetHexString()
            };
            await _dac.UpdatePosETicketDataXml(msg);
            logBO.Info(jobname + "- Update ETicket Xml for Store " + item.StoreNumber + " - End");
        }
        static DateRangeDTO GetDateRangeForInterval(PosETicketIntervalDTO eTicketInterval)
        {
            var dateRange = new DateRangeDTO();

            if (eTicketInterval.Daily)
            {
                dateRange.FromDate = Convert.ToDateTime(DateTime.Now.AddDays(-1).ToShortDateString());
                dateRange.ToDate = Convert.ToDateTime(DateTime.Now.AddDays(-1).ToShortDateString());
            }
            else if (eTicketInterval.Weekly)
            {
                dateRange.FromDate = OmniExtensions.lastWeekStart;
                dateRange.ToDate = OmniExtensions.lastWeekEnd;
            }
            else if (eTicketInterval.Monthly)
            {
                dateRange.FromDate = OmniExtensions.lastMonthStart;
                dateRange.ToDate = OmniExtensions.lastMonthEnd;
            }
            else if (eTicketInterval.DateRange)
            {
                dateRange.FromDate = eTicketInterval.FromDate;
                dateRange.ToDate = eTicketInterval.ToDate;
            }
            return dateRange;
        }
        #endregion
    }
}
