﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;
using System.Transactions;
using System.Diagnostics;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ItemDataRefresh : Common, IItemDataRefresh
    {
        readonly IItemDataRefreshDac _dac;
        public ItemDataRefresh(IItemDataRefreshDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public async Task RefereshItemData()
        {
            var envMachinename = Environment.MachineName;
            var noOfStoresProcessing = SystemValues.GetValue<int>(Constants.SystemValues.NoOfStoresForProcessing);
            var maxdegreeOfParallelismStoreProcessing = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismStoreProcessing);
            var jobMachineIdentifier = SystemParameters.GetValue(Constants.SystemParameters.JobMachineIdentifier);
            try
            {
                logBO.Info(jobname + " - Loading InMemeroy Object Details - Start");
                var nonAlcoholStoresTsk = _dac.GetNonAlcoholStores();
                var alcoholFmlyGrpsTsk = _dac.GetAlcoholFamilyGrps();
                var overrideItemsTsk = _dac.GetOverrideItems();
                var nonLiquorStoresTsk = _dac.GetNonLiquorStores();
                var liquorFamilyGrpsTsk = _dac.GetLiquorFamilyGrps();
                //var idmProductCatalogTsk = _dac.GetIDMProductCatalogData();
                var posTaxRatesTsk = _dac.GetPOSTaxRates();
                var noImageURLFmlyGrpsTsk = _dac.GetNoImgURLFamilyGrps();
                var itemdetailsTsk = _dac.GetItemDetails();
                var zeroBOHStoresTsk = _dac.GetZeroBOHEnabledStores();

                await Task.WhenAll(nonAlcoholStoresTsk, alcoholFmlyGrpsTsk, overrideItemsTsk,
                                   nonLiquorStoresTsk, liquorFamilyGrpsTsk, //idmProductCatalogTsk,
                                   noImageURLFmlyGrpsTsk, itemdetailsTsk, zeroBOHStoresTsk);
                logBO.Info(jobname + " - Loading InMemeroy Object Details - End");



                var itemdataLoadSteps = new ItemDataAbstract[10];
                itemdataLoadSteps[0] = new UpdatePIMSAttributes(_dac, jobname, noImageURLFmlyGrpsTsk.Result, itemdetailsTsk.Result);
                itemdataLoadSteps[1] = new UpdateLOItemsPriceToNLOStores(_dac, jobname);
                itemdataLoadSteps[2] = new BalanceOnHandCheckForItems(_dac, jobname,zeroBOHStoresTsk.Result);
                itemdataLoadSteps[3] = new UpdateTaxRates(_dac, jobname, posTaxRatesTsk.Result);
                itemdataLoadSteps[4] = new ApplyMarkupPrices(_dac, jobname);
                itemdataLoadSteps[5] = new ApplyTrackInventoryOverride(_dac, jobname);
                itemdataLoadSteps[6] = new ApplyItemOverrideDetails(_dac, jobname, overrideItemsTsk.Result);
                itemdataLoadSteps[7] = new EnableAlcoholItems(_dac, jobname, alcoholFmlyGrpsTsk.Result, nonAlcoholStoresTsk.Result);
                itemdataLoadSteps[8] = new EnableLiquorItems(_dac, jobname, liquorFamilyGrpsTsk.Result, nonLiquorStoresTsk.Result);
                itemdataLoadSteps[9] = new InsertItemData(_dac, jobname);

                // For the first time, to ensure there is no overlap
                if (string.Equals(envMachinename.ToUpper(), jobMachineIdentifier.ToUpper())) await Task.Delay(TimeSpan.FromMinutes(1));
                await _dac.ResetReProcessingForFileGeneration();

                while (true)
                {
                    var instStorenumbers = await _dac.GetProcessingStores(noOfStoresProcessing, Environment.MachineName);

                    if (instStorenumbers == null || instStorenumbers.Count() == 0) break;
                    var pimsStoreData = await LoadItemDataFromPIMSByStores(instStorenumbers, noOfStoresProcessing);

                    var arryStoreNumbers = pimsStoreData.Keys.Select(s => s).ToArray();
                    var strStoreNumbers = string.Join(",", arryStoreNumbers);
                    var itemdata = pimsStoreData.Values.SelectMany(a => a.Values).OrderBy(i => i.RETAILER_REFERENCE_CODE);

                    logBO.Info(jobname + " - Main - Processing Item Data For StoreNumbers:" + strStoreNumbers + " - Start");


                    logBO.Info(jobname + " - Loading InMemeroy LOStore Details - Start");
                    var loStoreProgramIds = instStorenumbers.Where(l => l.ProgramId != null)
                                                            //.Where(lo => ! ItemDataAbstract.LOStoreProgramItems.Any(p => p.Key == lo.ProgramId))
                                                            .Select(pId => (int)pId.ProgramId)
                                                            .Distinct();

                    var loStoresForPrices = instStorenumbers.Where(l => l.LOStore != null)
                                                            //.Where(lo => !ItemDataAbstract.LOStorePrices.Any(p => p.Key == lo.LOStore))
                                                            .Select(loSt => (int)loSt.LOStore)
                                                            .Distinct();

                    var loStoreProgramItemsTsk = LoadLOStoreProgramItems(loStoreProgramIds, maxdegreeOfParallelismStoreProcessing);
                    var loStorePriceDetailsTsk = LoadLOStorePriceDetails(loStoresForPrices, maxdegreeOfParallelismStoreProcessing);


                    await Task.WhenAll(loStorePriceDetailsTsk, loStoreProgramItemsTsk);
                    logBO.Info(jobname + " - Loading InMemeroy LOStore Details - End");

                    ItemDataAbstract.Initialize(instStorenumbers, loStoreProgramItemsTsk.Result, loStorePriceDetailsTsk.Result);

                    logBO.Info(jobname + " - Retrieving BOH Details From Service For StoreNumbers:" + strStoreNumbers + " - Start");

                    //var tasks = new List<Task>();
                    //foreach (var str in pimsStoreData)
                    //{
                    //    tasks.Add(Task.Factory.StartNew(() => itemdataLoadSteps[2].Process(str.Key, str.Value))); // BalanceOnHandCheckForItems  at storelevel get data
                    //}

                    //await Task.WhenAll(tasks.ToArray());
                    ItemDataAbstract.GetBohForStores(instStorenumbers);
                    var _bohStores = string.Join(",", ItemDataAbstract.PublixProStoreItems.Keys.ToArray());
                    logBO.Info(jobname + " - BOH Details Count:" + ItemDataAbstract.PublixProStoreItems.Values.Count + " For StoreNumbers:" + _bohStores);


                    logBO.Info(jobname + " - Retrieving BOH Details From Service For StoreNumbers:" + strStoreNumbers + " - End");

                    logBO.Info(jobname + " - Process Items Updates For StoreNumbers:" + strStoreNumbers + " - Start");

                    //await Task.Factory.StartNew(() =>
                    //Parallel.ForEach(itemdata, new ParallelOptions { MaxDegreeOfParallelism = maxdegreeOfParallelismStoreProcessing },
                    itemdata.AsParallel()
                    .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                    .WithMergeOptions(ParallelMergeOptions.NotBuffered)
                    .WithDegreeOfParallelism(maxdegreeOfParallelismStoreProcessing)
                    .ForAll(
                    item =>
                    {
                        itemdataLoadSteps[0].ProcessByItem(item.STORE_IDENTIFIER, item); // UpdatePIMSAttributes
                        itemdataLoadSteps[1].ProcessByItem(item.STORE_IDENTIFIER, item); // UpdateLOItemsPriceToNLOStores

                        itemdataLoadSteps[3].ProcessByItem(item.STORE_IDENTIFIER, item); // UpdateTaxRates
                        itemdataLoadSteps[4].ProcessByItem(item.STORE_IDENTIFIER, item); // ApplyMarkupPrices
                        itemdataLoadSteps[5].ProcessByItem(item.STORE_IDENTIFIER, item); // ApplyTrackInventoryOverride
                        itemdataLoadSteps[6].ProcessByItem(item.STORE_IDENTIFIER, item); // ApplyItemOverrideDetails
                        itemdataLoadSteps[7].ProcessByItem(item.STORE_IDENTIFIER, item); // EnableAlcoholItems
                        itemdataLoadSteps[8].ProcessByItem(item.STORE_IDENTIFIER, item); // EnableLiquorItems
                        itemdataLoadSteps[2].ProcessByItem(item.STORE_IDENTIFIER, item); // BalanceOnHandCheckForItems at item level.     

                        //_dac.InsertItemData(item);
                    });
                    //, TaskCreationOptions.LongRunning);
                    logBO.Info(jobname + " - Process Items Updates For StoreNumbers:" + strStoreNumbers + " - End");

                    logBO.Info(jobname + " - Insert Store Item Details For StoreNumbers:" + strStoreNumbers + " - Start");
                    await ItemDataAbstract.InsertStoreItemData(strStoreNumbers, itemdata);
                    logBO.Info(jobname + " - Insert Store Item Details For StoreNumbers:" + strStoreNumbers + " - End");


                    //Reset Boh Collection for Stores from Publix Pro
                    ItemDataAbstract.ResetBohCollection();
                    logBO.Info(jobname + " - Main - Processing Item Data For StoreNumbers:" + strStoreNumbers + " - End");
                    // break;
                }
            }
            catch (AggregateException ex)
            {
                foreach (var inrecep in ex.InnerExceptions)
                    logBO.Error(jobname + "- " + inrecep);

                throw;
            }
        }

        private async Task<ConcurrentDictionary<int, IEnumerable<int>>> LoadLOStoreProgramItems(IEnumerable<int> programIds, int maxParallelThread)
        {
            var loStoreProgramItems = new ConcurrentDictionary<int, IEnumerable<int>>();

            await Task.Run(() => Parallel.ForEach(programIds, new ParallelOptions { MaxDegreeOfParallelism = maxParallelThread },
                         pgId =>
                         {
                             var result = _dac.GetLOStoreProgramItems(pgId).Result;
                             loStoreProgramItems.TryAdd(pgId, result);
                         }));


            return loStoreProgramItems;
        }

        private async Task<ConcurrentDictionary<int, IEnumerable<ItemLoStorePriceDTO>>> LoadLOStorePriceDetails(IEnumerable<int> loStores, int maxParallelThread)
        {
            var loStrorePriceDetails = new ConcurrentDictionary<int, IEnumerable<ItemLoStorePriceDTO>>();

            await Task.Run(() => Parallel.ForEach(loStores, new ParallelOptions { MaxDegreeOfParallelism = maxParallelThread },
                         loStr =>
                         {
                             var result = _dac.GetLoStorePriceDetailsFromPIMS(loStr).Result;
                             logBO.Info("LoStroe Details" + result.Count());
                             loStrorePriceDetails.TryAdd(loStr, result);
                         }));

            return loStrorePriceDetails;
        }

        private async Task<ConcurrentDictionary<int, IDictionary<ItemKeyDTO, ItemDataDTO>>> LoadItemDataFromPIMSByStores(IEnumerable<StoreDTO> storeNumbers, int maxParallelThreads)
        {

            var pimsQueriedDateTime = DateTime.Now;

            var storeItemData = new ConcurrentDictionary<int, IDictionary<ItemKeyDTO, ItemDataDTO>>();

            await Task.Run(() => Parallel.ForEach(storeNumbers, new ParallelOptions { MaxDegreeOfParallelism = maxParallelThreads },
                         sl =>
                         {
                             logBO.Info(jobname + " - PIMS Item data load for Store: " + sl.StoreNumber);
                             var result = _dac.LoadItemDataFromPIMS(sl.StoreNumber, pimsQueriedDateTime).Result;
                             storeItemData.TryAdd(sl.StoreNumber, result);
                         }));


            return storeItemData;
        }
    }
}
