﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class MapOLogTLogToPos : Common, IMapOLogTLogToPos
    {
        readonly IMapOLogTLogToPosDac _dac;
        static DateTime currentDateTime;
        static string  currentUser;

        public List<POSInstacartOrderMapDTO> MappedOLogPosOrders { get; private set; }

        public MapOLogTLogToPos(IMapOLogTLogToPosDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
            currentDateTime = DateTime.Now;
            currentUser = System.Environment.UserName;
        }

        public async Task MapOLogOrdersToPOSAsync()
        {
            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipPOSOLogOrdersMap))
            {
                var filetypes = new[] { FileTypeEnum.OLOG, FileTypeEnum.TLOG }; // order should be OLog, then TLog
                var iMapPos = new MapPosFactory(_dac, jobname);

                foreach (var item in filetypes)
                {
                    var posActions = iMapPos.GetActions(item, MappedOLogPosOrders);

                    posActions.ConfigureMappingScenarios();
                    await posActions.PrepareMappingDataAsync(currentDateTime, currentUser).ConfigureAwait(false);
                    MappedOLogPosOrders = await posActions.ProcessAndInsertDataAsync(currentDateTime, currentUser).ConfigureAwait(false);
                }
            }
        }
    }
}
