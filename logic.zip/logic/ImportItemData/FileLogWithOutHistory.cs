﻿#region Directives

using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataDAC;

#endregion

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class FileLogWithOutHistory : FileTypeOperations
    {

        #region Constructor

        public FileLogWithOutHistory(IImportItemDataDac dac, string jobname) : base(dac, jobname)
        {

        }

        #endregion

        #region Methods

        public override async Task LoadFileTypeData(FileTypeDTO fileObj)
        {
            await LoadDataAsync(fileObj.NamingConvention, fileObj.Type, fileObj.MainTable);
            
        }

        public override async Task ProcessFileTypeData(FileTypeDTO fileObj)
        {
            var rundates = await _dac.GetRunDatesToProcess(fileObj.Type);
            var liquorFileTag = Constants.FileVersionType.Liquor.ToString();
            var specialtyFileTag = Constants.FileVersionType.Specialty.ToString();

            //loop by run dates for unproc files
            foreach (var rundt in rundates)
            {
                if(rundt.FileName.ToLower().Contains(liquorFileTag.ToLower()))
                  await _dac.UpdateLiquorRecords(rundt.Id, rundt.FileType);

                if (rundt.FileName.ToLower().Contains(specialtyFileTag.ToLower()))
                    await _dac.UpdateSpecialtyRecords(rundt.Id, rundt.FileType);

                //update FileVersion Indicator

                await _dac.UpdateInstIndicator(rundt.Id, rundt.FileType);

                //update rundates
                await _dac.UpdateRundateWithId(fileObj.Type, rundt.Id);

             }
                
        }

        #endregion
    }
}
