﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataDAC;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class OSPD : FileTypeOperations
    {
        public OSPD(IImportItemDataDac dac, string jobname) : base(dac,jobname)
        {
        }

        public async override Task LoadFileTypeData(FileTypeDTO fileObj)
        {
            await LoadDataAsync(fileObj.NamingConvention, fileObj.Type, fileObj.HistoryTable);
        }

        public async override Task ProcessFileTypeData(FileTypeDTO fileObj)
        {
            var rundates = await _dac.GetRunDatesToProcess(fileObj.Type);
            foreach (var rundt in rundates)
            {
                await _dac.ProcessOSPDData(Constants.FileTypes.OSPD, rundt.Id);
            }
        }
    }
}
