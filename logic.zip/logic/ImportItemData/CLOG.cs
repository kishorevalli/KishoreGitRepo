﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class CLOG : FileTypeOperations
    {
        public CLOG(IImportItemDataDac dac, string jobname) : base(dac, jobname)
        {

        }
        public override async Task LoadFileTypeData(FileTypeDTO fileObj)
        {
            await LoadDataAsync(fileObj.NamingConvention, fileObj.Type, fileObj.HistoryTable);
        }

        public override async Task ProcessFileTypeData(FileTypeDTO fileObj)
        {
            var rundates = await _dac.GetRunDatesToProcess(fileObj.Type);
            foreach (var rundt in rundates)
            {
                await _dac.ProcessCLogData(Constants.FileTypes.CLOG, rundt.Id);
            }
        }
    }
}
