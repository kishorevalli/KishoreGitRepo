﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Microsoft.VisualBasic.FileIO;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class FileTypeOperations : Common
    {
        protected IImportItemDataDac _dac;
        public static string archiveDirectory = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-InputFilePathArchive"];
        public static string baseDirectory = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-InputFilePath"];
        readonly static new log4net.ILog logBO = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected FileTypeOperations(IImportItemDataDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;

            //make sure the archive directory is available - create if not
            System.IO.Directory.CreateDirectory(archiveDirectory);
        }

        #region  "Abstracts"
        public abstract Task LoadFileTypeData(FileTypeDTO fileObj);
        public abstract Task ProcessFileTypeData(FileTypeDTO fileObj);

        #endregion

        protected static DataTable GetDataFromVendorsLog(string csvFilePath, bool firstLineHasData, DateTime timeStamp, int rundateId)
        {
            //works for all csv files regardless of footprint
            var csvData = new DataTable();
            var tStamp = DateTime.Now;
            var rowPositionStart = 0;

            using (TextFieldParser csvReader = new TextFieldParser(csvFilePath))
            {
                csvReader.SetDelimiters(new string[] { "," });
                csvReader.HasFieldsEnclosedInQuotes = true;

                //read column names
                var colFields = csvReader.ReadFields();
                foreach (string column in colFields)
                {
                    var datacolumn = new DataColumn
                    {
                        AllowDBNull = true
                    };
                    csvData.Columns.Add(datacolumn);
                }

                if (firstLineHasData)
                {
                    //first row is not a header row, it is a data row for this file type
                    csvData.Rows.Add(colFields);
                    rowPositionStart = 1;
                }
                else
                {
                    rowPositionStart = 2;
                }

                while (!csvReader.EndOfData)
                {
                    var fieldData = new string[] { };

                    try
                    {
                        fieldData = csvReader.ReadFields();
                    }
                    catch (MalformedLineException ex)
                    {
                        if (csvReader.ErrorLine.StartsWith("\""))
                        {
                            var line = csvReader.ErrorLine.Substring(1, csvReader.ErrorLine.Length - 2);
                            fieldData = line.Split(new string[] { "\",\"" }, StringSplitOptions.None);
                        }
                        else
                        {
                            throw ex;
                        }
                    }
                    //Making empty value as null
                    for (int i = 0; i < fieldData.Length; i++)
                    {
                        if (fieldData[i] == "")
                        {
                            fieldData[i] = null;
                        }
                    }
                    csvData.Rows.Add(fieldData);
                }

                //create the static columns
                var datacolumnStatic = new DataColumn("RunDateId")
                {
                    AllowDBNull = true,
                    DataType = typeof(int)
                };
                csvData.Columns.Add(datacolumnStatic);
                //set as first column
                datacolumnStatic.SetOrdinal(0);

                datacolumnStatic = new DataColumn("LastUpdatedDate")
                {
                    AllowDBNull = true,
                    DataType = typeof(DateTime)
                };
                csvData.Columns.Add(datacolumnStatic);
                //set as second column
                datacolumnStatic.SetOrdinal(1);

                datacolumnStatic = new DataColumn("LastUpdatedBy")
                {
                    AllowDBNull = true
                };
                csvData.Columns.Add(datacolumnStatic);
                //set as third column
                datacolumnStatic.SetOrdinal(2);

                datacolumnStatic = new DataColumn("FileRowReference")
                {
                    AllowDBNull = true
                };
                csvData.Columns.Add(datacolumnStatic);
                //set as fourth column
                datacolumnStatic.SetOrdinal(3);

                //fill data into the static columns
                for (int i = 0; i < csvData.Rows.Count; i++)
                {
                    csvData.Rows[i]["RunDateId"] = rundateId;
                    csvData.Rows[i]["LastUpdatedDate"] = timeStamp;
                    csvData.Rows[i]["LastUpdatedBy"] = System.Environment.UserName;
                    csvData.Rows[i]["FileRowReference"] = i + rowPositionStart;
                }
            }
            return csvData;
        }
        protected async Task LoadDataAsync(string filetypeNameConvention, string filetype, string historyTable)
        {
            try
            {
                var filename = string.Empty;
                var transOptions = new TransactionOptions { IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted, Timeout = TransactionManager.MaximumTimeout };

                var fileVersion = await _dac.GetFileVersion();


                //var LiquorFileTag = Constants.FileVersionType.Liquor;
                //var SpecialtyFileTag = Constants.FileVersionType.Specialty;



                //PROCESS ANY ITEM LEVEL TLOG FILES
                foreach (string filePath in Directory.GetFiles(baseDirectory, filetypeNameConvention))
                {
                    //always load to history table
                    var timeStamp = DateTime.Now;

                    filename = filePath.Substring(filePath.LastIndexOf(@"\") + 1);


                    //if (fileVersion.Any(a => a.FileTag!=null && filename.ToLower().Contains(a.FileTag.ToLower())))
                    var fileVersionItem = fileVersion.Where(a => a.TagName != null && filename.ToLower().Contains(a.TagName.ToLower())).FirstOrDefault();
                    if (fileVersionItem != null)
                    {
                        // var fileVersionItem = fileVersion.Where(a => a.FileTag != null && filename.ToLower().Contains(a.FileTag.ToLower())).FirstOrDefault();
                        if (fileVersionItem.IsImportEnabled)
                        {
                            await ProcessLoadData(filetype, historyTable, filename, transOptions, filePath, timeStamp, fileVersionItem.ID);
                        }
                    }

                    else
                    {
                        fileVersionItem = fileVersion.Where(a => Constants.FileVersionType.RegularWithBOH.ToString().ToLower() == (a.TypeName.ToLower())).FirstOrDefault();
                        await ProcessLoadData(filetype, historyTable, filename, transOptions, filePath, timeStamp, fileVersionItem.ID);
                    }

                }
            }
            catch
            {

                throw;
            }
        }

        private async Task ProcessLoadData(string filetype, string historyTable, string filename, TransactionOptions transOptions, string filePath, DateTime timeStamp, int fileVersionID)
        {
            using (var scope = new TransactionScope(TransactionScopeOption.Required, transOptions, TransactionScopeAsyncFlowOption.Enabled))
            {
                logBO.Info(jobname + "- Import " + filename + " File - Start");
                //update rundates table now that history is loaded and file moves complete
                var rundateId = await _dac.InsertRundate(timeStamp, filetype, filename, fileVersionID);

                var dt = GetDataFromVendorsLog(filePath, false, timeStamp, rundateId);
                await _dac.LoadDataFromVendorsFile(dt, filetype, historyTable);

                await _dac.UpdateFileRecordCount(rundateId, dt.Rows.Count);
                logBO.Info(jobname + "- Import " + filename + " File - End");

                logBO.Info(jobname + "- Moving file  " + filename + "- Start");
                //move to archive since the file has been loaded into sql server 
                await MoveTheFile(filePath, archiveDirectory + filename);
                logBO.Info(jobname + "- Moving file " + filename + " - End");

                scope.Complete();
            }

        }

        async Task MoveTheFile(string path, string archiveFile)
        {
            await Task.Delay(10);
            //if a file with the same name already exists in the archive folder, this new file will have an index appended to it.  Example tlog_2016-08-16_2016-08-17.csv would become tlog_2016-08-16_2016-08-17(1).csv.
            if (File.Exists(archiveFile))
            {
                var count = 1;
                var newFullPath = archiveFile;

                while (File.Exists(newFullPath))
                {
                    var tempFileName = string.Format("{0}({1})", Path.GetFileNameWithoutExtension(archiveFile), count++);
                    newFullPath = Path.Combine(Path.GetDirectoryName(archiveFile), tempFileName + Path.GetExtension(archiveFile));
                }
                File.Move(path, newFullPath);
            }
            else
            {
                File.Move(path, archiveFile);
            }
        }
    }
}
