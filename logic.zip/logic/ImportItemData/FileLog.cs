﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class FileLog : FileTypeOperations
    {
        public FileLog(IImportItemDataDac dac, string jobname) : base(dac, jobname)
        {

        }
        public override async Task LoadFileTypeData(FileTypeDTO fileObj)
        {
            //if history table exists then dump file into history first, otherwise directly into main table
            
            await LoadDataAsync(fileObj.NamingConvention,fileObj.Type, fileObj.HistoryTable);
            
        }

        public override async Task ProcessFileTypeData(FileTypeDTO fileObj)
        {
            //get all unprocessed run dates
            var rundates = await _dac.GetRunDatesToProcess(fileObj.Type);
            var liquorFileTag = Constants.FileVersionType.Liquor.ToString();
            var specialtyFileTag = Constants.FileVersionType.Specialty.ToString();
            //loop by run dates for unproc files
            foreach (var rundt in rundates)
            {
                //process file data only if history table exists
                if (fileObj.IsProcessFromHistory)
                    await _dac.ProcessGenericFileTypeData(fileObj, rundt.Id);

                if (rundt.FileName.ToLower().Contains(liquorFileTag.ToLower()))
                    await _dac.UpdateLiquorRecords(rundt.Id, rundt.FileType);

                if (rundt.FileName.ToLower().Contains(specialtyFileTag.ToLower()))
                    await _dac.UpdateSpecialtyRecords(rundt.Id, rundt.FileType);

                //Update FileVersion Indicator
                await _dac.UpdateInstIndicator(rundt.Id, rundt.FileType);

            }
        }

    }
}

