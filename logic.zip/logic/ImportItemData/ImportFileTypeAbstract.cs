﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;


namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class ImportFileTypeAbstract
    {
        abstract public FileTypeOperations GetFileType(FileTypeDTO fileObj, IImportItemDataDac _dac, string jobname);
    }
}
