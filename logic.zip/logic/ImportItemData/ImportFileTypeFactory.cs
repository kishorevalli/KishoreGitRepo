﻿using System;
using System.Configuration;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ImportFileTypeFactory : ImportFileTypeAbstract
    {
        public override FileTypeOperations GetFileType(FileTypeDTO fileObj, IImportItemDataDac _dac, string jobname)
        {

            FileTypeOperations filetypeOpr = null;
            if (!fileObj.IsGenericFormat)
            {
                switch (fileObj.Id)
                {
                    case (int)FileTypeEnum.TLOG:
                        {
                            filetypeOpr = new TLog(_dac, jobname);
                            break;
                        }
                    case (int)FileTypeEnum.OLOG:
                        {
                            filetypeOpr = new OLog(_dac, jobname);
                            break;
                        }
                    case (int)FileTypeEnum.CLOG:
                        {
                            filetypeOpr = new CLOG(_dac, jobname);
                            break;
                        }
                    //case (int)FileTypeEnum.OSDT:
                    //    {
                    //        filetypeOpr = new OSDT(_dac, jobname);
                    //        break;
                    //    }
                    case (int)FileTypeEnum.OSPD:
                        {
                            filetypeOpr = new OSPD(_dac, jobname);
                            break;
                        }
                }
            }//pbnt - call new generic log class to read new files
            else
            {
                if (fileObj.IsProcessFromHistory)
                    filetypeOpr = new FileLog(_dac, jobname);
                else
                    filetypeOpr = new FileLogWithOutHistory(_dac, jobname);
            }

            return filetypeOpr;
        }
    }
}
