﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;


namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ItemImportFromPims : Common, IItemImportFromPims
    {
        readonly IItemImportFromPimsDac _dac;

        public ItemImportFromPims(IItemImportFromPimsDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        public List<ItemDetailsDTO> ItemDetailsFromPIMS { get; set; }

        public async Task ImportItemDetailsFromPIMS()
        {
            var noOfStoresProcessing = SystemValues.GetValue<int>(Constants.SystemValues.NoOfStoresForProcessing);
            var maxdegreeOfParallelismStoreProcessing = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismStoreProcessing);
            var noOfStoresToGetItemDetails = SystemValues.GetValue<int>(Constants.SystemValues.NoOfStoresToGetItemDetails);

            try
            {

                var storenumbers = await _dac.GetActiveStores();
                logBO.Info(jobname + " - Loading ItemDetails From PIMS - Start");

                var count = storenumbers.Count();
                ItemDetailsFromPIMS = new List<ItemDetailsDTO>();

                var storeNumbers = await _dac.GetActiveStores();

                var StoreListSplitSize = SystemValues.GetValue<int>(Constants.SystemValues.StoreListSplitSize);
                var maxParallelThreads = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismStoreProcessing);

                var sync = new object();
                try
                {
                    for (int i = 0; i < count; i += noOfStoresToGetItemDetails)
                    {
                        var nums = storenumbers.Skip(i).Take(noOfStoresToGetItemDetails);
                        var storeLists = nums.Select(s => s.StoreNumber).SplitIntoChunks<int>(StoreListSplitSize);

                        await Task.Run(() => Parallel.ForEach(storeLists, new ParallelOptions { MaxDegreeOfParallelism = maxParallelThreads },
                            sl =>
                            {
                                var stores = String.Join(",", sl.ToList());
                                logBO.Info(jobname + " - PIMS Item data load. Stores List : " + stores);
                                var itms = _dac.LoadItemDetailsFromPIMSByStores(stores);
                            }));

                        var itmDet = await _dac.GetDistinctItemDetailsFromStaging();
                        await _dac.TruncateItemDetailsStaging();

                        ItemDetailsFromPIMS.AddRange(itmDet);
                        ItemDetailsFromPIMS = ItemDetailsFromPIMS.Distinct(new ItemDetailsEqualityComparer()).ToList();

                        //logBO.Info(jobname + " - Store Count : " + i);
                    }
                }
                catch (AggregateException ex)
                {
                    foreach (var inrecep in ex.InnerExceptions)
                        logBO.Error(jobname + "- " + inrecep);

                    throw;
                }



                logBO.Info(jobname + " - Loading ItemDetails From PIMS - End");



                logBO.Info(jobname + " - Loading InMemeroy Object Details - Start");

                var overrideItemsTsk = _dac.GetOverrideItems();
                var idmProductCatalogTsk = _dac.GetIDMProductCatalogData();
                var noImageURLFmlyGrpsTsk = _dac.GetNoImgURLFamilyGrps();
                var alcoholFmlyGrpsTsk = _dac.GetAlcoholFamilyGrps();
                var liquorFamilyGrpsTsk = _dac.GetLiquorFamilyGrps();

                await Task.WhenAll(overrideItemsTsk, idmProductCatalogTsk, noImageURLFmlyGrpsTsk, alcoholFmlyGrpsTsk, liquorFamilyGrpsTsk);

                logBO.Info(jobname + " - Loading InMemeroy Object Details - End");

                var itemdataLoadSteps = new ItemDataAbstract[3];
                itemdataLoadSteps[0] = new UpdatePIMSAttributes(_dac, jobname, noImageURLFmlyGrpsTsk.Result, ItemDetailsFromPIMS);
                itemdataLoadSteps[1] = new UpdateAttributesWithIDMData(_dac, jobname, idmProductCatalogTsk.Result, alcoholFmlyGrpsTsk.Result, liquorFamilyGrpsTsk.Result);
                itemdataLoadSteps[2] = new ApplyItemOverrideDetails(_dac, jobname, overrideItemsTsk.Result);

                logBO.Info(jobname + " - Processing Item Details - Start");
                await Task.Run(() =>
                Parallel.ForEach(ItemDataAbstract.ItemDetails, new ParallelOptions { MaxDegreeOfParallelism = maxdegreeOfParallelismStoreProcessing },
                item =>
                {
                    itemdataLoadSteps[0].UpdateItemDetails(item);
                    itemdataLoadSteps[1].UpdateItemDetails(item);
                    itemdataLoadSteps[2].UpdateItemDetails(item);
                }));
                logBO.Info(jobname + " - Processing Item Details - End");


                logBO.Info(jobname + " - Insert/Update Item Details - Start");
                await ItemDataAbstract.InsertItemDetails();
                logBO.Info(jobname + " - Insert/Update Item Details - End");

            }
            catch (AggregateException ex)
            {
                foreach (var inrecep in ex.InnerExceptions)
                    logBO.Error(jobname + "- " + inrecep);

                throw;
            }



        }

    }
}
