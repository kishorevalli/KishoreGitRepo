﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class Common
    {
        protected string jobname = string.Empty;
        protected readonly static log4net.ILog logBO = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public Common(ICommonDac dac, string jobname)
        {
            this.jobname = jobname;
            SystemValues = dac.GetSystemValues().Result;
            SystemMessages = dac.GetSystemMessages().Result;
            SystemParameters = dac.GetSystemParamteres().Result;
        }

        public static List<SystemValuesDTO> SystemValues { get; set; }
        public static IEnumerable<SystemMessageDTO> SystemMessages { get; set; }

        public static IEnumerable<SystemParameterDTO> SystemParameters { get; set; }
    }


    static class SystemParamtersExtension
    {
        internal static string GetValue(this IEnumerable<SystemParameterDTO> systemParameters, string key)
        {
            var result = "";
            var enviornment = OmniExtensions.EnvironmentString;
            var parameter = systemParameters.FirstOrDefault(s => s.KeyName == (key + "-" + enviornment));
            if (parameter != null)
            {
                result = parameter.ParameterValue;
            }

            return result;
        }
    }

    static class SystemValuesExtension
    {
        internal static T GetValue<T>(this List<SystemValuesDTO> systemvalues, string key)
        {
            var outputValue = default(T);

            switch (Type.GetTypeCode(typeof(T)))
            {
                case TypeCode.Boolean:
                    {
                        var blnVal = false;
                        if (systemvalues.Any(r => r.keyName == key))
                        {
                            bool.TryParse(systemvalues.FirstOrDefault(r => r.keyName == key).value, out blnVal);
                        }
                        return outputValue = (T)Convert.ChangeType(blnVal, typeof(T));
                    }
                case TypeCode.String:
                    {
                        var strVal = string.Empty;
                        if (systemvalues.Any(r => r.keyName == key))
                        {
                            strVal = systemvalues.FirstOrDefault(r => r.keyName == key).value;
                            if (strVal == null) strVal = string.Empty;
                        }
                        return outputValue = (T)Convert.ChangeType(strVal, typeof(T));
                    }
                case TypeCode.Int32:
                    {
                        var intVal = default(int);
                        if (systemvalues.Any(r => r.keyName == key))
                        {
                            Int32.TryParse(systemvalues.FirstOrDefault(r => r.keyName == key).value, out intVal);
                        }
                        return outputValue = (T)Convert.ChangeType(intVal, typeof(T));
                    }
                case TypeCode.Int64:
                    {
                        var intVal = default(Int64);
                        if (systemvalues.Any(r => r.keyName == key))
                        {
                            Int64.TryParse(systemvalues.FirstOrDefault(r => r.keyName == key).value, out intVal);
                        }
                        return outputValue = (T)Convert.ChangeType(intVal, typeof(T));
                    }
                case TypeCode.Decimal:
                    {
                        var intVal = default(decimal);
                        if (systemvalues.Any(r => r.keyName == key))
                        {
                            decimal.TryParse(systemvalues.FirstOrDefault(r => r.keyName == key).value, out intVal);
                        }
                        return outputValue = (T)Convert.ChangeType(intVal, typeof(T));
                    }
                case TypeCode.DateTime:
                    {
                        var dtVal = default(DateTime);
                        if (systemvalues.Any(r => r.keyName == key))
                        {
                            DateTime.TryParse(systemvalues.FirstOrDefault(r => r.keyName == key).value, out dtVal);
                        }
                        return outputValue = (T)Convert.ChangeType(dtVal, typeof(T));
                    }
                default:
                    {
                        break;
                    }
            }

            return outputValue;
        }

        internal static int GetMessageId(this IEnumerable<SystemMessageDTO> systemmessages, string key)
        {
            var result = systemmessages.FirstOrDefault(s => s.Key == key);
            return result == null ? default(int) : result.Id;
        }
    }
}
