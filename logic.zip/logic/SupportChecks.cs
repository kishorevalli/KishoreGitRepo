﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;
using System.Text.RegularExpressions;
using System.IO;
using System.Configuration;


namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class SupportChecks:Common, ISupportChecks
    {
        private readonly ISupportChecksDac _dac;
        public SupportChecks(ISupportChecksDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
        }

       public async Task SupportChecksAsync()
        {
            logBO.Info(jobname + "- Get support validation - start");
            // Fetch the queries to validate against the DB.
            var queries = await _dac.GetSupportChecks();
            foreach (var queryResult in queries)
            {
                logBO.Info(jobname + ": - Fetching - " + queryResult.Name + " Results- start");
                var qResult = _dac.GetQueryResult(queryResult.Query.Trim());
                
                if (qResult.Rows.Count > 0)
                {
                    // Get the Notification Details like email details, templates etc.. assigned to the query
                    var NotificationDetails = await _dac.GetNotificationDetails(queryResult.EmailNotificationId);

                    if (NotificationDetails.Count > 0)
                    {
                        var supportChecksFactory= new SupportChecksFactory(_dac);
                        var writeToHtml = supportChecksFactory.GetWriteToHtmlFormat(queryResult.Type);
                        writeToHtml.WriteResultsToHtml(queryResult, qResult, NotificationDetails);
                    }
                    else
                    {
                        logBO.Info(jobname + ": - No Notification Details found for - " + queryResult.Name);
                    }

                    logBO.Info(jobname + ": - Fetching - " + queryResult.Name + " Results - End");
                }
                else
                {
                    logBO.Info(jobname + ": - No Query Results found for - " + queryResult.Name);
                    logBO.Info(jobname + ": - Fetching - " + queryResult.Name + " Results - End");
                }

            }

        }

       
    }
}
