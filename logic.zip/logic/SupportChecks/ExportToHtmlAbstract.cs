﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class ExportToHtmlAbstract
    {

        //public abstract string ExportQueryResultsToHtml();
        internal abstract void WriteResultsToHtml(SupportChecksDTO queryResult, DataTable qResult, List<EmailNotificationDetailsDTO> notificationDetails);
    }
}
