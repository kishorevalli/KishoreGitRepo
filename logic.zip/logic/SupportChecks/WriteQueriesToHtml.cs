﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataEntities;
using System.Configuration;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    class WriteQueriesToHtml : ExportToHtmlAbstract
    {
        internal override void WriteResultsToHtml(SupportChecksDTO queryResult, DataTable qResult, List<EmailNotificationDetailsDTO> emailNotificationDetails)
        {
            StringBuilder msgBuilder = new StringBuilder();
            msgBuilder.AppendFormat(emailNotificationDetails[0].Message, queryResult.Name);
            string subject, serviceUrl;
            string[] attachments;
            CreateAttachment.GetAttachement(queryResult, qResult, emailNotificationDetails, out subject, out attachments, out serviceUrl);
            string htmlString = ExportDataTableToHtml(qResult, emailNotificationDetails[0].Template, emailNotificationDetails[0].RowTemplate);
            // Send the email to the Recipients
            if (Environment.GetEnvironmentVariable("PublixEnvironment").ToUpper() == "Production".ToUpper() && emailNotificationDetails[0].EnvironMent.ToUpper() == "Production".ToUpper())
                PublishEmailMessage.CreateandSendMessage(emailNotificationDetails[0].ToAddress, emailNotificationDetails[0].CcAddress, emailNotificationDetails[0].BccAddress, subject, string.Concat(msgBuilder.ToString(), htmlString), serviceUrl, attachments);
            else
                PublishEmailMessage.CreateandSendMessage(emailNotificationDetails[0].ToAddress, emailNotificationDetails[0].CcAddress, emailNotificationDetails[0].BccAddress, subject, string.Concat(msgBuilder.ToString(), htmlString), serviceUrl, attachments);

            if (attachments != null)
                GenerateExcelReport.DeleteFile(attachments[0].ToString());
        }

        

        #region Private Methods
        private string ExportDataTableToHtml(DataTable qResult, string strHtmlTemplate, string strRowTemplate)
        {
            StringBuilder strHTMLBuilder = new StringBuilder();

            foreach (DataColumn myColumn in qResult.Columns)
            {
                strHTMLBuilder.Append("<th >");
                strHTMLBuilder.Append(myColumn.ColumnName);
                strHTMLBuilder.Append("</th>");

            }
            foreach (DataRow myRow in qResult.Rows)
            {
                strHTMLBuilder.Append("<tr >");
                foreach (DataColumn myColumn in qResult.Columns)
                {
                    strHTMLBuilder.Append("<td >");
                    strHTMLBuilder.Append(myRow[myColumn.ColumnName].ToString());
                    strHTMLBuilder.Append("</td>");
                }
                strHTMLBuilder.Append("</tr>");
            }
            StringBuilder formattedBuilder = new StringBuilder();
            formattedBuilder.AppendFormat(strHtmlTemplate, strRowTemplate, strHTMLBuilder.ToString());
            return formattedBuilder.ToString();
        }
        #endregion

    }
}
