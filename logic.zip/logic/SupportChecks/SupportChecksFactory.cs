﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
   public class SupportChecksFactory
    {
        private readonly ISupportChecksDac _dac;
        public SupportChecksFactory(ISupportChecksDac dac)
        {
            this._dac = dac;
        }
        public ExportToHtmlAbstract GetWriteToHtmlFormat(string type)
        {
            ExportToHtmlAbstract exportHtmlAbstract = null;

            switch (type)
            {
                case QueryType.DataBase:

                    exportHtmlAbstract = new WriteQueriesToHtml();
                    break;

                case QueryType.FileType:

                    exportHtmlAbstract = new WriteFileTypesToHtml();
                    break;

            }

            return exportHtmlAbstract;
        }
    }
}
