﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataEntities;
using System.Configuration;
using System.IO;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class WriteFileTypesToHtml : ExportToHtmlAbstract
    {
        internal override void WriteResultsToHtml(SupportChecksDTO queryResult, DataTable qResult, List<EmailNotificationDetailsDTO> emailNotificationDetails)
        {
            StringBuilder filemsgBuilder = new StringBuilder();
            StringBuilder fileTypeBldr = new StringBuilder();
            string subject = string.Concat(queryResult.Name, " - ", emailNotificationDetails[0].EnvironMent);
            string serviceUrl = ConfigurationManager.AppSettings[emailNotificationDetails[0].EnvironMent + "-EmailServiceUrl"];
            filemsgBuilder.AppendFormat(emailNotificationDetails[0].Message, queryResult.Name);
            fileTypeBldr.AppendFormat(emailNotificationDetails[0].Template, emailNotificationDetails[0].RowTemplate, FileTypeChecks(queryResult, qResult));
            //string[] attachments = new string[] {@"\\P47ISSHRS01\ISSHARED\Teams and Departments\EAS\Temp\Test.txt"};
            
            if (Environment.GetEnvironmentVariable("PublixEnvironment").ToUpper() == "Production".ToUpper() && emailNotificationDetails[0].EnvironMent.ToUpper() == "Production".ToUpper())
                 PublishEmailMessage.CreateandSendMessage(emailNotificationDetails[0].ToAddress, emailNotificationDetails[0].CcAddress, emailNotificationDetails[0].BccAddress, subject, string.Concat(filemsgBuilder.ToString(), fileTypeBldr), serviceUrl);
            else
                PublishEmailMessage.CreateandSendMessage(emailNotificationDetails[0].ToAddress, emailNotificationDetails[0].CcAddress, emailNotificationDetails[0].BccAddress, subject, string.Concat(filemsgBuilder.ToString(), fileTypeBldr), serviceUrl);
               

        }

        #region Private Methods
        private string FileTypeChecks(SupportChecksDTO queryResult, DataTable qResult)
        {
            StringBuilder htmlstringforFileTypes = new StringBuilder();
            foreach (DataColumn myColumn in qResult.Columns)
            {
                htmlstringforFileTypes.Append("<th >");
                htmlstringforFileTypes.Append(myColumn.ColumnName);
                htmlstringforFileTypes.Append("</th>");

            }
            foreach (DataRow dr in qResult.Rows)
            {
                string[] fileNames = Directory.GetFiles(queryResult.FilePath, dr["NamingConvention"].ToString());

                if (fileNames.Length == 0)
                {
                    htmlstringforFileTypes.Append("<tr >");
                    foreach (DataColumn myColumn in qResult.Columns)
                    {
                        htmlstringforFileTypes.Append("<td >");
                        htmlstringforFileTypes.Append(dr[myColumn.ColumnName].ToString());
                        htmlstringforFileTypes.Append("</td>");
                    }
                    htmlstringforFileTypes.Append("</tr>");
                }

            }
            return htmlstringforFileTypes.ToString();
        }


        #endregion


    }
}
