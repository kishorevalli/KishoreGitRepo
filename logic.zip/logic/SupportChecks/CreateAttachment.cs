﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public static class CreateAttachment
    {
        public static void GetAttachement(SupportChecksDTO queryResult, DataTable qResult, List<EmailNotificationDetailsDTO> emailNotificationDetails, out string subject, out string[] attachments, out string serviceUrl)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(qResult);
            string baseDirectory = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-ReportsPath"];
            var template = queryResult.Name.Substring(0, queryResult.Name.Length > 30 ? 29 : queryResult.Name.Length);
            subject = string.Concat(queryResult.Name, " - ", emailNotificationDetails[0].EnvironMent);
            attachments = null;
            if (emailNotificationDetails[0].EnableAttachments == true)
            {
                attachments = new string[] { GenerateExcelReport.GenerateExcel(ds, template, baseDirectory) };
            }
            // Convert the query results to Html
            serviceUrl = ConfigurationManager.AppSettings[emailNotificationDetails[0].EnvironMent + "-EmailServiceUrl"];
        }
    }
}
