﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ImportItemData : Common, IImportItemData
    {
        private readonly IImportItemDataDac _dac;

        public ImportItemData(IImportItemDataDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
        }

        public async Task ProcessVendorsLogsCsvAsync()
        {
            ImportFileTypeAbstract fileTypeAbs = new ImportFileTypeFactory();

            var filetypes = await _dac.GetFileTypes(); // Get Active File Types Tlog/Olog/OOSDet/OOSPrd

            // Get FileTypes that are supposed to get executed at currentHr hour.

            var currenthr = DateTime.Now.Hour;
            logBO.Info(jobname + "- Current Hour: " + currenthr + " - For MinPickHour");

            var selectedFileTypes = filetypes.Where(f => currenthr >= f.MinPickHour).ToList();

            foreach (var filetype in selectedFileTypes)
            {
                var logOps = fileTypeAbs.GetFileType(filetype, _dac, jobname);

                logBO.Info(jobname + "- Load " + filetype.Type + " File - Start");
                await logOps.LoadFileTypeData(filetype);
                logBO.Info(jobname + "- Load " + filetype.Type + " File - End");

                logBO.Info(jobname + "- Process " + filetype.Type + " File - Start");
                await logOps.ProcessFileTypeData(filetype);
                logBO.Info(jobname + "- Process " + filetype.Type + " File - End");
            }
        }

    }
}
