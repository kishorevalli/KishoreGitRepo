﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataBO.Contracts;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public abstract class ExportItemDataAbstract : Common
    {
        IExportItemDataDac _dac;

        protected ExportItemDataAbstract(IExportItemDataDac dac, string jobname) : base(dac, jobname)
        {
            _dac = dac;
        }

        #region "Abstracts"
        public abstract Task<int> WriteToFile(StoreFileVersionDTO storefileVersion);
        public abstract Task UpdateFileGenerate(int storenumber, int filegenerationcomplete);

        #endregion

        public DateTime ItemLoadDate { get; set; }

        public string ArchiveDirectory { get; set; }

        public string FullFilePathWithFileName { get; set; }
        public string FullFilePathWithOutFileName { get; set; }

        public string FileName { get; set; }

        protected string GetFileFullPath(string filename, string directoryName)
        {

            var filePath = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-OutputFilePath"].ToString();
            System.IO.Directory.CreateDirectory(filePath + directoryName);

            FullFilePathWithFileName = filePath + directoryName + "\\" + filename;
            FullFilePathWithOutFileName = filePath + directoryName;
            return FullFilePathWithFileName;
        }

        internal void Initialize(StoreFileVersionDTO storefileVersion, DateTime itemloadDate)
        {
            if (string.IsNullOrEmpty(storefileVersion.DirectoryName))
                throw new DirectoryNotFoundException("Attempting to process a file for store " + storefileVersion.StoreNumber + " but the stores directory does not exist");

            //make sure the backup directory exists, create if not
            ArchiveDirectory = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-OutputFilePathArchive"].ToString();
            Directory.CreateDirectory(ArchiveDirectory);

            ItemLoadDate = itemloadDate;

        }

        internal void Compress()
        {
            var zipPath = ArchiveDirectory + FileName + ".zip";

            //ZipFile.CreateFromDirectory(filePathFull, zipPath);

            //zip it and place a copy in archive since the file mover process deletes the file after being sent to vendor
            if (File.Exists(zipPath))
                File.Delete(zipPath);

            if (File.Exists(FullFilePathWithFileName))
            {
                ZipFile.CreateFromDirectory(FullFilePathWithOutFileName, zipPath);
            }

        }
    }
}
