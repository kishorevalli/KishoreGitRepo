﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataEntities;

namespace Publix.S0OMNIXX.OmniItemDataBO.Contracts
{
    interface IWriteToFile
    {
        Task<int> WriteToFile(List<ItemDTO> itemsForStore, string filePathFull);
    }
}
