﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;


namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ExportItemDataFactory : Common
    {
        IExportItemDataDac dac;
        protected static IEnumerable<int> NoImgFmlyGrps { get; set; }
        protected static List<int> removeimgUrlStorelist;

        public ExportItemDataFactory(IExportItemDataDac _dac, string jobname) : base(_dac, jobname)
        {
            dac = _dac;
            NoImgFmlyGrps = _dac.GetNoImgURLFamilyGrps().Result;
            removeimgUrlStorelist = SystemValues.GetValue<String>("RemoveImageURLStoreList").Split(',').ToList().Select(int.Parse).ToList();
        }

        internal static void CleanUpArchive()
        {
            //make sure the backup directory exists, create if not
            var archiveDirectory = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-OutputFilePathArchive"].ToString();
            Directory.CreateDirectory(archiveDirectory);

            //clean up any old files in archive that have exceeded our retention days value stored in table systemvalues_t
            Directory.GetFiles(archiveDirectory)
                .Select(f => new FileInfo(f))
                .Where(f => f.LastWriteTime < DateTime.Now.AddDays(SystemValues.GetValue<int>(Constants.SystemValues.ExportArchiveFilesRetentionDays) * -1))
                .ToList()
                .ForEach(f => f.Delete());
        }

        public ExportItemDataAbstract GetWriteToFileFormat(int fileversion)
        {
            ExportItemDataAbstract itemdataAbstract;

            switch (fileversion)
            {
                case 1:
                    itemdataAbstract = new WriteToFileRegularFormat(dac, jobname, NoImgFmlyGrps, removeimgUrlStorelist);
                    break;

                case 2:
                    itemdataAbstract = new WriteToFileBOGOFormat(dac, jobname, NoImgFmlyGrps, removeimgUrlStorelist);
                    break;

                case 3:
                    itemdataAbstract = new WriteToFileRegularBOHFormat(dac, jobname, NoImgFmlyGrps, removeimgUrlStorelist);
                    break;

                case 4:
                    itemdataAbstract = new WriteToFileLiquorFormat(dac, jobname, NoImgFmlyGrps, removeimgUrlStorelist);
                    break;

                //case 5:
                //    itemdataAbstract = new WriteToFileSpecialtyFormat(dac, jobname, NoImgFmlyGrps, removeimgUrlStorelist);
                //    break;

                case 6:
                    itemdataAbstract = new WriteToFileB2BPartnerFormat(dac, jobname, NoImgFmlyGrps, removeimgUrlStorelist);
                    break;

                case 7:
                    itemdataAbstract = new WriteToFileGreenWiseFormat(dac, jobname, NoImgFmlyGrps, removeimgUrlStorelist);
                    break;

                default:
                    itemdataAbstract = new WriteToFileRegularFormat(dac, jobname, NoImgFmlyGrps, removeimgUrlStorelist);
                    break;

            }

            return itemdataAbstract;
        }

        public bool IsFlagEnabled(int fileVersion, bool IsLiquorEnabled, bool IsSpecialtyEnabled, bool IsB2BEnabled)
        {
            var valid = false;
            switch (fileVersion)
            {
                case 1:
                    valid = true;
                    break;
                case 2:
                    valid = true;
                    break;
                case 3:
                    valid = true;
                    break;
                case 4:
                    if (IsLiquorEnabled)
                        valid = true;
                    break;
                case 5:
                    if (IsSpecialtyEnabled)
                        valid = true;
                    break;
                case 6:
                    if (IsB2BEnabled)
                        valid = true;
                    break;
                case 7:
                    valid = true;
                    break;
                default:
                    valid = false;
                    break;
            }
            return valid;
        }
    }
}
