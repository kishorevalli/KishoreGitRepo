﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataBO.Contracts;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;
using Newtonsoft.Json;
using Publix.S0OMNIXX.OmniItemDataDAC;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class WriteToFileRegularBOHFormat : ExportItemDataAbstract
    {
        readonly IExportItemDataDac _dac;
        IEnumerable<int> _NoImgFmlyGrps { get; set; }
        List<int> _removeimgUrlStorelist;


        public WriteToFileRegularBOHFormat(IExportItemDataDac dac, string jobname, IEnumerable<int> NoImgFmlyGrps, List<int> removeimgUrlStorelist) : base(dac, jobname)
        {
            _dac = dac;
            _NoImgFmlyGrps = NoImgFmlyGrps;
            _removeimgUrlStorelist = removeimgUrlStorelist;
        }


        public async override Task UpdateFileGenerate(int storenumber, int filegenerationcomplete)
        {
            await _dac.UpdateFilenameField(FileName, storenumber, ItemLoadDate);
            await _dac.UpdateStoreProcessing(storenumber, filegenerationcomplete);
        }

        #region IWriteToFile Members

        public override async Task<int> WriteToFile(StoreFileVersionDTO storefileVersion)
        {
            var blankStr = string.Empty;
            string sale_price;
            string sale_start_date;
            string sale_end_date;
            var rowsForFile = 0;

            var itemsForStore = await _dac.GetItemsForFile(storefileVersion.StoreNumber);

            if (itemsForStore.Count() > 0)
            {
                FileName = ItemLoadDate.ToString("ddMMyyyy") + "_" + storefileVersion.StoreNumber + "_Publix.csv";
                var filefullpath = GetFileFullPath(FileName, storefileVersion.DirectoryName);

                using (System.IO.TextWriter writer = File.CreateText(filefullpath))
                {
                    var sbContent = new StringBuilder();
                    //if(store.
                    foreach (var item in itemsForStore)
                    {
                        if (_removeimgUrlStorelist.Any(s => s == storefileVersion.StoreNumber))
                        {
                            if (_NoImgFmlyGrps.Any(x => x == item.FAM_CODE))
                            {
                                item.REMOTE_IMAGE_URL = "";
                            }

                        }
                        if (rowsForFile == 0)
                        {
                            //first row in the file - header
                            await writer.WriteLineAsync("Scan Code,Item Code,Item Name,Multiplier,Size,UOM,Retail Price,Cost Unit,Bottle Deposit,Department,Taxable,Tax Rate,CCH Code,Prod Available,Alcoholic,Alcohol by Volume,Private Label,Brand Name,Sale Price Per Unit,Sale Start Date,Sale End Date,Loyalty Cost Price,Loyalty Cost Price Start,Loyalty Cost Price End,Organic,Kosher,Vegetarian,Vegan,Gluten Free,Fat Free,Sugar Free,Remote Image URL,Item Details,Item Location,Store,BOGO,Balance On Hand"); //,BOGO Start Date,BOGO End Date,BOGO Price"); // BOGO is not required 
                        }
                        rowsForFile++;

                        if (item.MARKUP_SALE_PRICE_ROUNDED == 0 && item.SALE_START_AT.ToShortDateString() == "1/1/1900" && item.SALE_END_AT.ToShortDateString() == "1/1/1900")
                        {
                            sale_price = blankStr;
                            sale_start_date = blankStr;
                            sale_end_date = blankStr;
                        }
                        else
                        {
                            sale_price = item.MARKUP_SALE_PRICE_ROUNDED.ToString();
                            sale_start_date = item.SALE_START_AT.ToShortDateString();
                            sale_end_date = item.SALE_END_AT.ToShortDateString();
                        }


                        var ailseInfoJson = item.LOCATION_RSS_SEQ != 0 ?
                                                                Newtonsoft.Json.JsonConvert.SerializeObject(new AisleInformationDTO
                                                                {
                                                                    LOCATION_AISLE = item.LOCATION_AISLE,
                                                                    LOCATION_SIDE = item.LOCATION_SIDE,
                                                                    LOCATION_SECTION_DESC = item.LOCATION_RSS_DESC,
                                                                    LOCATION_SECTION_SEQ = item.LOCATION_RSS_SEQ.ToString()
                                                                })
                                                               : "";




                        var settings = new JsonSerializerSettings
                        {
                            NullValueHandling = NullValueHandling.Ignore,
                            DateFormatString = "yyyy'-'MM'-'dd HH':'mm':'ss.FFF"
                        };

                        //settings.DefaultValueHandling = DefaultValueHandling.Ignore;
                        var bohDetailsJson = "";
                        if (null == item.BOH_Ind && null == item.BOH && null == item.BOHLastUpdatedDT)
                        {
                            bohDetailsJson = "{\"retailer_reference_code\":" + item.RETAILER_REFERENCE_CODE.ToString() + ", \"boh_indicator\":\"N\"}";
                        }
                        else
                        {
                            bohDetailsJson = Newtonsoft.Json.JsonConvert.SerializeObject(new BOHDetailsDTO
                            {
                                retailer_reference_code = item.RETAILER_REFERENCE_CODE.ToString(),
                                boh_indicator = item.BOH_Ind,
                                boh_count = item.BOH,
                                boh_generated_at = item.BOHLastUpdatedDT ?? DateTime.UtcNow

                            }, settings);
                        }

                        //await writer.WriteLineAsync(
                        sbContent.Append(
                                                item.SCAN_CODE
                                        + "," + item.RETAILER_REFERENCE_CODE
                                        + "," + item.ITEM_NAME.csv()
                                        + "," + item.MULTIPLIER
                                        + "," + item.SIZE
                                        + "," + item.RETAIL_PACKAGE_SIZE.csv()
                                        + "," + item.MARKUP_PRICE_ROUNDED
                                        + "," + item.COST_UNIT
                                        + "," + item.BOTTLE_DEPOSIT
                                        + "," + item.DEPARTMENT.csv()
                                        + "," + item.TAXABLE.Trim()
                                        + "," + item.TAXABLE_RATE
                                        + "," + item.CCH_CODE
                                        + "," + item.AVAILABLE.Trim()
                                        + "," + item.ALCOHOLIC.Trim()
                                        + "," + item.ALCOHOL_BY_VOLUME
                                        + "," + item.PRIVATE_LABEL_ITEM.Trim()
                                        + "," + item.BRAND_NAME.csv()
                                        + "," + sale_price
                                        + "," + sale_start_date
                                        + "," + sale_end_date
                                        + "," + blankStr //item.LOYALTY_COST_PRICE_UNIT  
                                        + "," + blankStr //item.LOYALTY_COST_PRICE_START_AT 
                                        + "," + blankStr //item.LOYALTY_COST_PRICE_END_AT 
                                        + "," + item.ORGANIC.Trim()
                                        + "," + item.KOSHER.Trim()
                                        + "," + item.VEGETARIAN.Trim()
                                        + "," + item.VEGAN.Trim()
                                        + "," + item.GLUTEN_FREE.Trim()
                                        + "," + item.FAT_FREE.Trim()
                                        + "," + item.SUGAR_FREE.Trim()
                                        + "," + item.REMOTE_IMAGE_URL
                                        + "," + item.ITEM_DETAILS.csv()
                                        + "," + ailseInfoJson.csv()
                                        + "," + item.STORE_IDENTIFIER
                                        + "," + item.BOGO.Trim()
                                        + "," + bohDetailsJson.csv());
                        sbContent.AppendLine();
                    }
                    await writer.WriteLineAsync(sbContent.ToString());
                    await writer.FlushAsync();
                    writer.Close();
                }
            }


            return rowsForFile;
        }

        #endregion
    }

}