﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ProcessImportData : Common, IProcessImportData
    {
        private readonly IProcessImportDataDac _dac;
        public ProcessImportData(IProcessImportDataDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
        }

        public async Task ProcessTLogDataAsync()
        {
            var rundates = await _dac.GetRunDatesToValidate(Constants.FileTypes.TLog);

            foreach (var rundt in rundates)
            {
                await PerformTLogTaxSplitsAsync(rundt.Id);
                await PerformTLogDiscrepancyChecksAsync(rundt.Id);
                await _dac.UpdateIsValidatedFlag(rundt.Id, Constants.FileTypes.TLog);
            }
        }

        public async Task ProcessOLogDataAsync()
        {
            var rundates = await _dac.GetRunDatesToValidate(Constants.FileTypes.OLog);

            foreach (var rundt in rundates)
            {
                await PerformOLogDiscrepancyChecksAsync(rundt.Id);
                await _dac.UpdateIsValidatedFlag(rundt.Id, Constants.FileTypes.OLog);
            }
        }





        #region "Private Methods"

        async Task PerformTLogTaxSplitsAsync(int rundateid)
        {
            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipTLogTaxSplit))
            {
                logBO.Info(jobname + "- Perform Tax Split for RunDate:" + rundateid + " - Start");
                await _dac.UpdateTaxSplits(rundateid);
                logBO.Info(jobname + "- Perform Tax Split for RunDate:" + rundateid + " - End");
            }
        }

        async Task PerformTLogDiscrepancyChecksAsync(int rundateid)
        {
            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipTLogDiscrepancies))
            {
                logBO.Info(jobname + "- Perform TLog Discrepancy Check for RunDate:" + rundateid + " - Start");
                await _dac.CheckTLogDiscrepancies(rundateid, 1);
                logBO.Info(jobname + "- Perform TLog Discrepancy Check for RunDate:" + rundateid + " - End");
            }
        }

        async Task PerformOLogDiscrepancyChecksAsync(int rundateid)
        {
            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipOLogDiscrepancies))
            {
                logBO.Info(jobname + "- Perform OLog Discrepancy Check for RunDate:" + rundateid + " - Start");
                await _dac.CheckOLogDiscrepancies(rundateid, 2);
                logBO.Info(jobname + "- Perform OLog Discrepancy Check for RunDate:" + rundateid + " - End");
            }
        }

        #endregion




    }
}
