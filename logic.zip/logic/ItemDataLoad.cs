﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;
using Publix.S0OMNIXX.OmniItemDataUtilities;

namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class ItemDataLoad : Common, IItemDataLoad
    {
        private readonly IItemDataLoadDac _dac;
        public ItemDataLoad(IItemDataLoadDac dac, string jobname) : base(dac, jobname)
        {
            this._dac = dac;
        }

        public async Task LoadItemDataFromPIMS()
        {
            logBO.Info(jobname + "- DropIndexesOnItemDataExportStaging - Start");
            await _dac.DropIndexesOnItemDataExportStaging();
            logBO.Info(jobname + "- DropIndexesOnItemDataExportStaging - End");

            logBO.Info(jobname + "- LoadItemDataFromPIMSByStores - Start");
            var rowsCopied = await LoadItemDataFromPIMSByStores(); //_dac.LoadItemDataFromPIMS();
            logBO.Info(jobname + "- PIMS Item data load complete. No of Rows copied from PIMS: " + rowsCopied);
            logBO.Info(jobname + "- LoadItemDataFromPIMSByStores - End");

            logBO.Info(jobname + "- ApplyIndexesOnItemDataExportStaging - Start");
            await _dac.ApplyIndexesOnItemDataExportStaging();
            logBO.Info(jobname + "- ApplyIndexesOnItemDataExportStaging - End");

            logBO.Info(jobname + "- UpdateLOItemsPriceToNLOStores - Start");
            var rowsUpdated = await _dac.UpdateLOItemsPriceToNLOStores();
            logBO.Info(jobname + "- Item Data - Item_Store_Include, NLO Items updated: " + rowsUpdated);
            logBO.Info(jobname + "- UpdateLOItemsPriceToNLOStores - End");


            logBO.Info(jobname + "- UpdatePIMSItemDataAttributes - Start");
            var rowsDeleted = await _dac.UpdatePIMSItemDataAttributes();
            logBO.Info(jobname + "- Item Data - Item_Store_Include, Rows deleted: " + rowsDeleted);
            logBO.Info(jobname + "- UpdatePIMSItemDataAttributes - End");

            
            logBO.Info(jobname + "- ProcessPIMSItemDataForFamilyGroupCodes - Start");
            var rowsDeletedStrFamcodes = await _dac.ProcessPIMSItemDataForFamilyGroupCodes();
            logBO.Info(jobname + "- Item Data - FamilyGroup_Store_Association, Items Data Rows deleted: " + rowsDeletedStrFamcodes);

            var rowsDeletedForLiquorExclusion = await _dac.ExcludeStoreFamilyGroupsForLiquor();
            logBO.Info(jobname + "- Item Data - Liquor Family Groups Excluded, Rows deleted: " + rowsDeletedForLiquorExclusion);
            logBO.Info(jobname + "- ProcessPIMSItemDataForFamilyGroupCodes - End");
        }


        public async Task<long> LoadItemDataFromPIMSByStores()
        {

            var storeNumbers = _dac.GetAllStoreNumbers().Result;

            var StoreListSplitSize = SystemValues.GetValue<int>(Constants.SystemValues.StoreListSplitSize);
            var maxParallelThreads = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelism);
            var storeLists = storeNumbers.SplitIntoChunks<int>(StoreListSplitSize);
            var pimsQueriedDateTime = DateTime.Now;
            //  await _dac.DropIndexOnItemDataStaging();


            await _dac.TruncateItemDataInStaging();
            try
            {
                await Task.Run(() => Parallel.ForEach(storeLists, new ParallelOptions { MaxDegreeOfParallelism = maxParallelThreads },
                    sl =>
                    {
                        var stores = String.Join(",", sl.ToList());
                        logBO.Info(jobname + " - PIMS Item data load. Stores List : " + stores);
                        _dac.LoadItemDataFromPIMSByStores(stores, pimsQueriedDateTime);
                    }));

            }
            catch (AggregateException ex)
            {
                foreach (var inrecep in ex.InnerExceptions)
                    logBO.Error(jobname + "- " + inrecep);

                throw;
            }

            return await _dac.GetItemDataCount();
        }

        public async Task LoadItemDataFromProductCatalog()
        {
            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipProductCatalogUpdates))
            {
                //logBO.Info(jobname + "- LoadItemDataFromProductCatalog - Start");
                //await _dac.LoadItemDataFromProductCatalog();
                //logBO.Info(jobname + "- LoadItemDataFromProductCatalog - End");
                //logBO.Info(jobname + "- UpdateItemDataFromProductCatalogToOmni - Start");
                await _dac.UpdateItemDataFromProductCatalogToOmni();
                //logBO.Info(jobname + "- UpdateItemDataFromProductCatalogToOmni - End");
            }
        }

        

        private static List<MongoItemsDTO> CheckBOHforItems(IEnumerable<MongoItemsDTO> mongoItems)
        {
            var itemsToNotSendInFile = new List<MongoItemsDTO>();
            foreach (var item in mongoItems)
            {
                if (item.Boh > 0)
                {
                    //this item has stock - allow record to be included
                }
                else
                {
                    //is a shipment going to happen tomorrow?
                    if (item.NextDeliveryQty > 0 && Convert.ToDateTime(item.NextDeliveryDate).ToShortDateString() == DateTime.Today.AddDays(1).ToShortDateString())
                    {
                        //they are getting a deliver tomorrow - allow the record to be included
                    }
                    else
                    {
                        //no stock, no delivery tomorrow 
                        //flag this record with a 1 in the exclude from file field
                        itemsToNotSendInFile.Add(new MongoItemsDTO { Number = item.Number, Sku = item.Sku });
                    }
                }
            }

            return itemsToNotSendInFile;
        }

        public async Task UpdateItemDataBOH()
        {
            var maxParallelThreads = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelism);
            var bohFailureCnt = 0;
            var MaxCountForBOHSkip = SystemValues.GetValue<int>(Constants.SystemValues.MaxCountForBOHSkip);


            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipBOHItemMobileUpdates))
            {
                //var stores = await _dac.GetStoreNumbers();
                var stores = await _dac.GetStoreNumbersForBOH();
                var itemsToNotSendInFile = new List<MongoItemsExclude>();
              //  var mongoItemsList = new List<MongoItemsDTO>();

                using (var client = new HttpClient(new HttpClientHandler { UseDefaultCredentials = true }))
                {
                    logBO.Info(jobname + " - Attempting  to create client connection to mongo");
                    //client.BaseAddress = new Uri("http://localhost:18508/");
                    var endpoint = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-MongoEndpoint"];
                    client.BaseAddress = new Uri(endpoint.ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    foreach (var store in stores)
                    {

                        //await Task.Run(() => Parallel.ForEach(stores, new ParallelOptions { MaxDegreeOfParallelism = maxParallelThreads },
                        // async (store, loopstate) =>
                        // {                      
                        try
                        {

                            //get the items from mongo service for the store we are on
                            logBO.Info(jobname + " - Store: " + store.StoreNumber.ToString());

                            //var mongoItemsReturned = new List<MongoItemsDTO>();


                            logBO.Info(jobname + " - Attempting connection to mongo");
                            // New code:
                            // example for test: http://tminva01.publix.com/itemdetail/api/item?store=1271
                           var response = await client.GetAsync("api/item?store=" + store.StoreNumber.ToString());
                         //   var response = await client.GetAsync("http://tminva01.publix.com/itemdetail/api/item?store=1271");
                            logBO.Info(jobname + " - made the mongo call - success: " + response.IsSuccessStatusCode);
                            if (response.IsSuccessStatusCode)
                            {
                                var mongoItems = response.Content.ReadAsAsync<IEnumerable<MongoItemsDTO>>().Result;


                                if (store.FileVersionID == 1)
                                {
                                    var i = 0;
                                    //var itemsToNotSendInFile = new List<MongoItemsDTO>();
                                    foreach (var item in mongoItems)
                                    {
                                        i++;
                                        if (item.Boh > 0 || item.Boh == null)
                                        {
                                            //this item has stock - allow record to be included
                                        }
                                        else
                                        {
                                            itemsToNotSendInFile.Add(new MongoItemsExclude { STORE_IDENTIFIER = item.Number, RETAILER_REFERENCE_CODE = item.Sku });
                                        }
                                    }

                                    
                                }
                                else
                                {
                                    var mongoItemsList = new List<MongoItemsDTO>();
                                    //mongoItems = mongoItems.Where(p => p.activationStatus != "INACTIVE").ToList(); //remove the inactive mongo items from the query - they should not be in the base storagge table?                                
                                    foreach (var item in mongoItems)
                                    {
                                        mongoItemsList.Add(new MongoItemsDTO { Number = item.Number, Sku = item.Sku , Boh = item.Boh , bohFlag = item.bohFlag, bohLastUpdate = item.bohLastUpdate < DateTime.MinValue ? null : item.bohLastUpdate });
                                    }

                                    if (mongoItemsList != null)
                                        await UpdateBOHDetails(mongoItemsList);
                                }
                            }
                            else
                            {
                                //response.EnsureSuccessStatusCode();
                                bohFailureCnt++;
                                logBO.Info(jobname + "- Error - BOH Service - " + store.StoreNumber + " - " + response.StatusCode.ToString());
                            }

                        }
                        catch (Exception ex)
                        {
                            bohFailureCnt++;
                            logBO.Info(jobname + "- Error - BOH Service - " + store.StoreNumber + " - " + ex);
                        }

                        if (bohFailureCnt > MaxCountForBOHSkip)
                        {
                            logBO.Info(jobname + "- Skipping the BOH Service call for the remaining stores.");
                           // loopstate.Break();
                            break;
                        }

                   //  }));

                      }

                    if (itemsToNotSendInFile.Count > 0)
                       await UpdateBOHStatus(itemsToNotSendInFile);
                   



                }// newly added               

            }
        }

        private async Task UpdateBOHStatus(List<MongoItemsExclude> mongoItemsExclude)
        {
            logBO.Info(jobname + " - BOH updates to DB - Start");
            //update the staging table by setting the donotsend flag for the items we want to exclude because they have no BOH and no Delivery tomorrow

            await _dac.UpdateItemDataBOHExcludeFlag(mongoItemsExclude);
            logBO.Info(jobname + " - BOH updates to DB - End");
        }


        private async Task UpdateBOHDetails(List<MongoItemsDTO> mongoItems)
        {
            logBO.Info(jobname + " - BOH updates to DB - Start");
            //update the bohStatus , bohCount, bohLastUpdateDateTime in staging table.

            await _dac.UpdateItemDataWithBOHDetails(mongoItems);
            logBO.Info(jobname + " - BOH updates to DB - End");
        }


        public async Task ApplyMarupRules()
        {
            //logBO.Info(jobname + "- UpdateTaxRates - Start");
            //await _dac.UpdateTaxRates();
            //logBO.Info(jobname + "- UpdateTaxRates - End");
            //logBO.Info(jobname + "- UpdateMarkupFields - Start");

            var activeStores = await _dac.GetActiveStores();
            var maxParallelThreads = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelism);

            logBO.Info(jobname + "- Update TaxRates & Markup - Start");

            foreach (var actStr in activeStores)
            {
                //logBO.Info(jobname + "- UpdateTaxRates - StoreNumber:" + actStr.StoreNumber + " - Start");
                await _dac.UpdateTaxRates(actStr.StoreNumber);
                //logBO.Info(jobname + "- UpdateTaxRates - StoreNumber:" + actStr.StoreNumber + " - End");

                //logBO.Info(jobname + "- UpdateMarkupFields - StoreNumber:" + actStr.StoreNumber + " - Start");
                await _dac.UpdateMarkupFields(actStr.StoreNumber, actStr.MarkupPercent);
                //logBO.Info(jobname + "- UpdateMarkupFields - StoreNumber:" + actStr.StoreNumber + " - End");

                //Task.WaitAll(task1, task2);

            }

            logBO.Info(jobname + "- Update TaxRates & Markup - End");

            //try
            //{
            //    await Task.Run(() => Parallel.ForEach(activeStores, new ParallelOptions { MaxDegreeOfParallelism = maxParallelThreads },
            //        sl =>
            //        {
            //            logBO.Info(jobname + " - Update Markup field for store : " + sl);
            //            _dac.UpdateMarkupFields(sl.StoreNumber, sl.MarkupPercent);
            //        }));

            //}
            //catch (AggregateException ex)
            //{
            //    foreach (var inrecep in ex.InnerExceptions)
            //        logBO.Error(jobname + "- " + inrecep);

            //    throw;
            //}


            //logBO.Info(jobname + "- UpdateMarkupFields - End");
        }

        public async Task ApplyTrackInventoryOverride()
        {
            await _dac.ApplyTrackInventoryOverride();
        }


        public async Task ApplyItemOverride()
        {
            //Fetch Item Details 

            //Override item details
            await _dac.ApplyItemOverride();
        }


        public async Task PushItemDataFromStgToMain()
        {
            await _dac.PushItemDataFromStgToMain();
        }

    }
}
