﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Publix.S0OMNIXX.OmniItemDataDAC;
using Publix.S0OMNIXX.OmniItemDataEntities;



namespace Publix.S0OMNIXX.OmniItemDataBO
{
    public class LoadDataFromSource : Common, ILoadDataFromSource
    {
        readonly ILoadDataFromSourceDac _dac;

        public LoadDataFromSource(ILoadDataFromSourceDac dac, string jobname)
            : base(dac, jobname)
        {
            _dac = dac;
        }

        public async Task LoadPOSDataAsync(string dataSource)
        {

            switch (dataSource)
            {
                case Constants.JobArgs.EDWDataSource:
                    {
                        await LoadEDWDataAsync();
                        break;
                    }
                case Constants.JobArgs.FLEXDataSource:
                    {
                        await LoadItemCodeFromFlexAsync();
                        break;
                    }
                case Constants.JobArgs.ShelveToHistory:
                    {
                        await MoveShelveToHistoryAsync();
                        break;
                    }
                case Constants.JobArgs.IDMProductCatalog:
                    {
                        await LoadIDMProductCatalogDataAsync();
                        break;
                    }
                case Constants.JobArgs.PIMSScanCode:
                    {
                        await LoadGTINFromPIMSAsync();
                        break;
                    }
                case Constants.JobArgs.PIMSStoreData:
                    {
                        await LoadStoreDetailsFromPIMSAsync();
                        break;
                    }
                case Constants.JobArgs.CreatePartition:
                    {
                        await CreatePartitionForItemData();
                        break;
                    }
                default:
                    {
                        logBO.Info("Invalid DataSource");
                        break;
                    }
            }
        }

        #region "IDM Product Catalog"

        async Task LoadIDMProductCatalogDataAsync()
        {
            logBO.Info(jobname + "- Load ItemData From ProductCatalog - Start");
            await _dac.LoadItemDataFromProductCatalog();
            logBO.Info(jobname + "- Load ItemData From ProductCatalog - End");
        }

        #endregion

        #region "Load Flex Data"
        async Task LoadItemCodeFromFlexAsync()
        {
            logBO.Info(jobname + "- LoadItemCodeDataFromFLEX - Start");
            await _dac.LoadItemCodeDataFromFLEX();
            logBO.Info(jobname + "- LoadItemCodeDataFromFLEX - End");
        }
        #endregion

        #region "MoveShelveToHistory"

        //async Task PushItemDataFromStgToMain()
        //{
        //    await _dac.PushItemDataFromStgToMain();
        //}

        async Task MoveShelveToHistoryAsync()
        {
            bool itemDataExportStagingHasData = await _dac.ItemDataExportStagingHasData();
            logBO.Info(jobname + "- PushItemDataFromStgToMain - Start");
            if (itemDataExportStagingHasData)
            {
                await _dac.PushItemDataFromStgToMain();
            }
            else
            {
                logBO.Info(jobname + "- Skip PushItemDataFromStgToMain No data in ItemDataExportStagin");
            }
            logBO.Info(jobname + "- PushItemDataFromStgToMain - End");

            logBO.Info(jobname + "- CreateIndexForItemDataExportMain - Start");
            await _dac.CreateIndexForItemDataExportMain();
            logBO.Info(jobname + "- CreateIndexForItemDataExportMain - End");
            logBO.Info(jobname + "- MoveItemDataFromHistoryToArch - Start");
            int HistoryRetensionDays = SystemValues.GetValue<int>(Constants.SystemValues.HistoryRetensionDays);
            _dac.MoveItemDataFromHistoryToArch(HistoryRetensionDays);
            logBO.Info(jobname + "- MoveItemDataFromHistoryToArch - End");
            logBO.Info(jobname + "- MoveItemDataFromShelveToHistory - Start");
            _dac.MoveItemDataFromShelveToHistory();
            logBO.Info(jobname + "- MoveItemDataFromShelveToHistory - End");
        }

        #endregion

        #region "Load EDW Data"
        async Task LoadEDWDataAsync()
        {

            // Get System Values for POS Queries
            var FromDate = SystemValues.GetValue<string>(Constants.SystemValues.FromDateKey);
            var ToDate = SystemValues.GetValue<string>(Constants.SystemValues.ToDateKey);
            var BinNumber = SystemValues.GetValue<string>(Constants.SystemValues.BinNumberKey);
            var transactionTimeout = SystemValues.GetValue<int>(Constants.SystemValues.QueryCommandTimeout);
            var FromDateControlRange = SystemValues.GetValue<string>(Constants.SystemValues.ImportPosControlRangeFromDate);
            var ToDateControlRange = SystemValues.GetValue<string>(Constants.SystemValues.ImportPosControlRangeToDate);

            //Date Manipulation for SQL & Terdata queries
            const string strSqlDate = "CAST(GETDATE() AS DATE)";
            const string strTeradataDate = "CURRENT_DATE";

            // When string CURRENT_DATE is given in SystemValues
            // FromDate values is made GetDate() -1 -- This to ensure, rerun of the job is successful with DELETE
            // ToDate is just converted to GetDate()
            //Eg: FromDate: CURRENT_DATE -1 ToDate: CURRENT_DATE -- This brings previous day data for POS
            // SQL Delete should happen only for previous day hence FromDate: Getdate() -1 and ToDate: GetDate()
            //Eg: FromDate: 1/30/2017 ToDate: 1/31/2017 -- This brings data 1/30 for POS
            // SQL Delete should happen only for 1/30 hence FromDate: 1/30 and ToDate: 1/31 -1 which is 1/30
            // When string Date literal is given in SystemValues
            // FromDate is taken ASIS, so that delete happens only on that day.
            // ToDate is converted to given ToDate -1
            var DeletePOSDataFromDate = (FromDate.Contains(strTeradataDate)) ? "DATEADD(DAY, -1, " + strSqlDate + ")" : FromDate;
            var DeletePOSDataToDate = (ToDate.Contains(strTeradataDate)) ? strSqlDate : "DATEADD(DAY, -1, " + ToDate + ")";
            var transOptions = new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted, Timeout = new TimeSpan(0, transactionTimeout, 0) };

            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipPOSOrderTransaction))
            {
                if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipDeletePOSDataFromMain))
                {
                    logBO.Info(jobname + "- Delete POSSalesTransData For DateRange - Start");
                    var deletedCount = await _dac.DeletePOSSalesTransDataForDateRange(DeletePOSDataFromDate, DeletePOSDataToDate);
                    logBO.Info(jobname + "No. of EDW rows deleted: " + deletedCount);
                    logBO.Info(jobname + "- Delete POSSalesTransData For DateRange - End");
                }

                logBO.Info(jobname + "- Load POSData From EDW - Start");
                var rowsLoaded = await _dac.LoadPOSDataFromEDW(FromDate, ToDate, BinNumber);
                logBO.Info(jobname + "No. of POS Sales Transaction rows Loaded : " + rowsLoaded);
                logBO.Info(jobname + "- Load POSData From EDW - End");
            }

            if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipPOSLineItemTransaction))
            {

                await _dac.TruncatePOSLineItemTransactionStaging();

                logBO.Info(jobname + "- Load POSItemLineData From EDW To Staging - Start");
                var rowsItemLineLoaded = await _dac.LoadPOSItemLineDataFromEDWToStaging(FromDate, ToDate, BinNumber, FromDateControlRange, ToDateControlRange);
                logBO.Info(jobname + "- Load POSItemLineData From EDW To Staging - End");

                logBO.Info(jobname + "- Get POSLineItemTransactions From EDW Count - Start");
                rowsItemLineLoaded = await _dac.GetPOSLineItemTransactionsFromEDWCount();
                logBO.Info(jobname + "No. of EDW POS Sales Trans Item Line rows Loaded : " + rowsItemLineLoaded);
                logBO.Info(jobname + "- Get POSLineItemTransactions From EDW Count - End");

                logBO.Info(jobname + "- Update POSLineItemTransaction Staging TaxPlan Amount - Start");
                var rowsTaxUpdated = await _dac.UpdatePOSLineItemTransactionStagingTaxPlanAmount();
                logBO.Info(jobname + "No. of EDW POS Sales Trans Item Line rows Upadted in Staging table : " + rowsTaxUpdated);
                logBO.Info(jobname + "- Update POSLineItemTransaction Staging TaxPlan Amount - End");

                logBO.Info(jobname + "- Update GTIN + check digit to POSLineItemTransactionStaging - Start");
                await _dac.UpdatePOSLineItmTransactionStagGTINCheckDigit();
                logBO.Info(jobname + "- Update GTIN + check digit to POSLineItemTransactionStaging - End");

                logBO.Info(jobname + "- Adjust Tax Rates + Adjust Tax Rates for POS line item tx to match with Header - Start");
                await AdjustTaxRates();
                logBO.Info(jobname + "- Adjust Tax Rates + Adjust Tax Rates for POS line item tx to match with Header - End");

                logBO.Info(jobname + "- Update TaxPlan Buckets - Start");
                await _dac.UpdateTaxPlanBuckets();
                logBO.Info(jobname + "- Update TaxPlan Buckets - End");


                // Skips the Move of POSLineItem data from Staging to Main
                if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipMovePOSLineItemStgToMain))
                {
                    using (var scope = new TransactionScope(TransactionScopeOption.Required, transOptions, TransactionScopeAsyncFlowOption.Enabled))
                    {
                        // Skips delete from the Main table - this will be used when reload a date range of data
                        if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipDeletePOSDataFromMain))
                        {
                            logBO.Info(jobname + "- Delete POSLineItemTransaction from Main - Start");
                            var deletedItemLineCount = await _dac.DeletePOSSalesLineItemTransDataForDateRange(DeletePOSDataFromDate, DeletePOSDataToDate);
                            logBO.Info(jobname + "No. of EDW POS Line Item Sales Trans Item Line rows deleted: " + deletedItemLineCount);
                            logBO.Info(jobname + "- Delete POSLineItemTransaction from Main - End");
                        }
                        logBO.Info(jobname + "- Move POSLineItemTransaction Staging To Main - Start");
                        await _dac.MovePOSLineItemTransactionStagingToMain(DeletePOSDataFromDate, DeletePOSDataToDate);
                        logBO.Info(jobname + "- Move POSLineItemTransaction Staging To Main - End");
                        scope.Complete();
                    }
                    if (!SystemValues.GetValue<bool>(Constants.SystemValues.SkipCopyPOSLineItemStgToScanGo))
                    {
                        logBO.Info(jobname + "- Copy POSLineItemTransaction Staging To OMNI Scan Go - Start");
                        await _dac.CopyPOSLineItemTransactionStagingToOMNIScanGo();
                        logBO.Info(jobname + "- Copy POSLineItemTransaction Staging To OMNI Scan Go - End");
                    }
                    logBO.Info(jobname + "- Truncate POSLineItemTransaction Staging - Start");
                    await _dac.TruncatePOSLineItemTransactionStaging();
                    logBO.Info(jobname + "- Truncate POSLineItemTransaction Staging - End");

                }
            }
        }


        private async Task AdjustTaxRates()
        {
            var posTransactionHeaders = await _dac.GetDistinctPOSTransactions();
            foreach (var posTxHeader in posTransactionHeaders)
            {
                var posLineItemTransactions = await _dac.GetPOSLineItemTransactions(posTxHeader.FacilityId, posTxHeader.TransactionDate, posTxHeader.TransactionTM, posTxHeader.TransactionNumber);
                var totalTaxAmt = posLineItemTransactions.Sum(posTx => posTx.TotalTax);


                if (posTxHeader.TotalTax != totalTaxAmt)
                {
                    //  POSLineItemTransactionDTO posLineItemTx = null;
                    var differenceAmt = posTxHeader.TotalTax - totalTaxAmt;

                    if (differenceAmt > 0) //Header is more in this case  -- //Add
                    {
                        await AddTaxToPosLineItems(posLineItemTransactions, differenceAmt);
                    }
                    else //Subtract 
                    {
                        await SubtractTaxFrmPOSLineItems(posLineItemTransactions, differenceAmt);
                    }

                }
            }
        }

        private async Task SubtractTaxFrmPOSLineItems(List<POSLineItemTransactionDTO> posLineItemTransactions, decimal differenceAmt)
        {

            List<PosLineItemTransactionUpdatedTaxDto> updatedTax = new List<PosLineItemTransactionUpdatedTaxDto>();
            var sync = new object();
            var MaxDegreeOfParallelismForPosLineItemFromEDW = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismForPosLineItemFromEDW);

            //Parallel.ForEach(posLineItemTransactions, new ParallelOptions { MaxDegreeOfParallelism = MaxDegreeOfParallelismForPosLineItemFromEDW }
            //    , ((posLineItem, loopState) =>
            //    {
            foreach (POSLineItemTransactionDTO posLineItem in posLineItemTransactions)
            {
                if (differenceAmt != 0)
                {
                    if (posLineItem.TaxPlan1Amount != 0)
                    {
                        posLineItem.TaxPlan1Amount = posLineItem.TaxPlan1Amount - (decimal)0.01;
                        if (differenceAmt != 0)
                        {
                            updatedTax.Add(new PosLineItemTransactionUpdatedTaxDto(posLineItem));
                            differenceAmt += (decimal)0.01;
                            if (differenceAmt == 0) break;
                        }

                    }
                    else if (posLineItem.TaxPlan2Amount != 0)
                    {
                        posLineItem.TaxPlan2Amount = posLineItem.TaxPlan2Amount - (decimal)0.01;
                        if (differenceAmt != 0)
                        {
                            differenceAmt += (decimal)0.01;
                            updatedTax.Add(new PosLineItemTransactionUpdatedTaxDto(posLineItem));
                            if (differenceAmt == 0) break;
                        }
                    }
                    else if (posLineItem.TaxPlan3Amount != 0)
                    {
                        posLineItem.TaxPlan3Amount = posLineItem.TaxPlan3Amount - (decimal)0.01;
                        if (differenceAmt != 0)
                        {
                            differenceAmt += (decimal)0.01;
                            updatedTax.Add(new PosLineItemTransactionUpdatedTaxDto(posLineItem));
                            if (differenceAmt == 0) break;
                        }
                    }
                }
            }
            await _dac.AdjustPOSLineItemTaxAmount(updatedTax);
        }

        private async Task AddTaxToPosLineItems(List<POSLineItemTransactionDTO> posLineItemTransactions, decimal differenceAmt)
        {
            List<PosLineItemTransactionUpdatedTaxDto> updatedTax = new List<PosLineItemTransactionUpdatedTaxDto>();
            object sync = new object();
            var MaxDegreeOfParallelismForPosLineItemFromEDW = SystemValues.GetValue<int>(Constants.SystemValues.MaxDegreeOfParallelismForPosLineItemFromEDW);

            foreach (var posLineItem in posLineItemTransactions)
            {
                if (posLineItem.TaxPlan1Amount != 0)
                {
                    posLineItem.TaxPlan1Amount = posLineItem.TaxPlan1Amount + (decimal)0.01;
                    differenceAmt -= (decimal)0.01;
                    updatedTax.Add(new PosLineItemTransactionUpdatedTaxDto(posLineItem));
                    if (differenceAmt == 0) break;
                }
                else if (posLineItem.TaxPlan2Amount != 0)
                {
                    posLineItem.TaxPlan2Amount = posLineItem.TaxPlan2Amount + (decimal)0.01;
                    differenceAmt -= (decimal)0.01;
                    updatedTax.Add(new PosLineItemTransactionUpdatedTaxDto(posLineItem));
                    if (differenceAmt == 0) break;
                }
                else if (posLineItem.TaxPlan3Amount != 0)
                {
                    posLineItem.TaxPlan3Amount = posLineItem.TaxPlan3Amount + (decimal)0.01;
                    differenceAmt -= (decimal)0.01;
                    updatedTax.Add(new PosLineItemTransactionUpdatedTaxDto(posLineItem));
                    if (differenceAmt == 0) break;
                }
            }
            await _dac.AdjustPOSLineItemTaxAmount(updatedTax);
        }

        //private async Task AdjustTaxRates()
        //{
        //    var posTransactionHeaders = await _dac.GetDistinctPOSTransactions();
        //    foreach (var posTxHeader in posTransactionHeaders)
        //    {
        //        var posLineItemTransactions = await _dac.GetPOSLineItemTransactions(posTxHeader.FacilityId, posTxHeader.TransactionDate, posTxHeader.TransactionTM, posTxHeader.TransactionNumber);
        //        var totalTaxAmt = posLineItemTransactions.Sum(posTx => posTx.TotalTax);


        //        if (posTxHeader.TotalTax != totalTaxAmt)
        //        {
        //          //  POSLineItemTransactionDTO posLineItemTx = null;
        //            var differenceAmt = posTxHeader.TotalTax - totalTaxAmt;

        //            if (differenceAmt > 0) //Header is more in this case  -- //Add
        //            {

        //                foreach (var posLineItem in posLineItemTransactions)
        //                {
        //                    if (posLineItem.TaxPlan1Amount > 0)
        //                    {

        //                        posLineItem.TaxPlan1Amount = posLineItem.TaxPlan1Amount + differenceAmt;
        //                        await _dac.AdjustPOSLineItemTaxAmount(posLineItem);
        //                        break;
        //                        //  break;                                                                

        //                    }
        //                    else if (posLineItem.TaxPlan2Amount > 0)
        //                    {

        //                        posLineItem.TaxPlan2Amount = posLineItem.TaxPlan2Amount + differenceAmt;
        //                        await _dac.AdjustPOSLineItemTaxAmount(posLineItem);
        //                        break;
        //                        //  break;


        //                    }
        //                    else if (posLineItem.TaxPlan3Amount > 0)
        //                    {

        //                        posLineItem.TaxPlan3Amount = posLineItem.TaxPlan3Amount + differenceAmt;
        //                        await _dac.AdjustPOSLineItemTaxAmount(posLineItem);
        //                        break;
        //                        //  break;


        //                    }



        //                }
        //            }
        //            else //Subtract 
        //            {
        //                foreach (var posLineItem in posLineItemTransactions)
        //                {
        //                    if (differenceAmt == 0) break;
        //                    if (posLineItem.TaxPlan1Amount > 0) 
        //                    {
        //                        while (posLineItem.TaxPlan1Amount > (decimal)0.01)
        //                        {
        //                            if (differenceAmt == 0) break;
        //                            posLineItem.TaxPlan1Amount = posLineItem.TaxPlan1Amount - (decimal)0.01;
        //                            differenceAmt += (decimal)0.01;

        //                        }
        //                        await _dac.AdjustPOSLineItemTaxAmount(posLineItem);
        //                        //break;
        //                    }
        //                    else if (posLineItem.TaxPlan2Amount > 0)
        //                    {
        //                        while (posLineItem.TaxPlan2Amount > (decimal)0.01)
        //                        {
        //                            if (differenceAmt == 0) break;
        //                            posLineItem.TaxPlan2Amount = posLineItem.TaxPlan2Amount - (decimal)0.01;
        //                            differenceAmt += (decimal)0.01;

        //                        }
        //                        await _dac.AdjustPOSLineItemTaxAmount(posLineItem);
        //                        //break;
        //                    }
        //                    else if (posLineItem.TaxPlan3Amount > 0)
        //                    {
        //                        while (posLineItem.TaxPlan3Amount > (decimal)0.01)
        //                        {
        //                            if (differenceAmt == 0) break;
        //                            posLineItem.TaxPlan3Amount = posLineItem.TaxPlan3Amount - (decimal)0.01;
        //                            differenceAmt += (decimal)0.01;

        //                        }
        //                        await _dac.AdjustPOSLineItemTaxAmount(posLineItem);
        //                        //break;
        //                    }


        //                    //Update lineItem Transaction.
        //                   // if (posLineItemTx != null)


        //                    if (differenceAmt == 0) break;
        //                }
        //            }

        //        }
        //    }
        //}

        #endregion

        #region "Load PIMS Scan Code \ GTIN"
        async Task LoadGTINFromPIMSAsync()
        {
            logBO.Info(jobname + "- LoadGTINFromPIMS - Truncate Start");
            await _dac.TruncateScanCode();
            logBO.Info(jobname + "- LoadGTINFromPIMS - Truncate End");

            logBO.Info(jobname + "- LoadGTINFromPIMS - Start");
            await _dac.LoadGTINFromPIMS();
            logBO.Info(jobname + "- LoadGTINFromPIMS - End");

            logBO.Info(jobname + "- Update GTINCheckDigit - Start");
            await _dac.UpdateGTINCheckDigit();
            logBO.Info(jobname + "-  Update GTINCheckDigit - End");
        }


        #endregion

        #region "Load PIMS Store Data"

        async Task LoadStoreDetailsFromPIMSAsync()
        {
            logBO.Info(jobname + "- LoadStoreDetailsFromPIMS - Start");
            await _dac.LoadStoreDetailsFromPIMSAsync();
            logBO.Info(jobname + "- LoadStoreDetailsFromPIMS - End");
        }

        #endregion

        #region "Create Partition for Item Data Export in archive" 
        async Task CreatePartitionForItemData()
        {
            logBO.Info(jobname + "- CreatePartitionForItemData - Start");
            await _dac.CreatePartitionForItemData();
            logBO.Info(jobname + "- CreatePartitionForItemData - End");
        }
        #endregion
    }
}






