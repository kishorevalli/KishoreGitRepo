C# 6.0 Cookbook
==========

This is the example code that accompanies C# 6.0 Cookbook by Jay Hilyard and Stephen Teilhet (9781491921463). 

Click the Download Zip button to the right to download example code.

Visit the catalog page [here](http://shop.oreilly.com/product/0636920037347.do).

See an error? Report it [here](http://oreilly.com/catalog/errata.csp?isbn=0636920037347), or simply fork and send us a pull request.
