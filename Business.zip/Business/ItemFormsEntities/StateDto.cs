﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class StateDto
    {
        public string StateShortName { get; set; }
        public string StateFullName { get; set; }
        public string CountyName { get; set; }
        public string CityName { get; set; }


    }
}
