﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class NutrientDictionary
    {
        public decimal NutrDictionaryID { get; set; }
        public string Name { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public string DataType { get; set; }
        public string Isrequired { get; set; }
        public decimal SortOrder { get; set; }
        public decimal RequiredDailyValues { get; set; }
        public DateTime CreationDateTime { get; set; }
        public string CreatedBy { get; set; }
        public string FkUOMID { get; set; }
        public decimal FkNutrTypeID { get; set; }
    }
}
