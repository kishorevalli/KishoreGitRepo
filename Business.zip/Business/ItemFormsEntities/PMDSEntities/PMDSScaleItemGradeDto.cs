﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSScaleItemGradeDto
    {
        public string Date { get; set; }
        public Int16 FkScaleGradeCode { get; set; }
        public string FkScaleGradeCodeDesc { get; set; }
        public string FkFacGrpTypCod { get; set; }
        public string FkFacGrpTypCodDesc { get; set; }
        public Int16 FkFacGrpCode { get; set; }
        public string FkFacGrpCodeDesc { get; set; }


    }
}
