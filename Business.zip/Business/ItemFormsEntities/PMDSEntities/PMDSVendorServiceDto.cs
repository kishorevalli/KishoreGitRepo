﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSVendorServiceDto
    {
        public int? VendorNumber { get; set; }

        public string VendorName { get; set; }

        public decimal? Gtin { get; set; }

        public int? ItemCode { get; set; }

        public int? StoreNumber { get; set; }

        public string StateCode { get; set; }

        public string StateName { get; set; }

        public string CountyCode { get; set; }

        public string CountyName { get; set; }

    }
}
