﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PIDMDataDto
    {
        public int? ItemCode { get; set; }
        public BasicItemDefinitionDto BasicItemDefinition { get; set; }
        public IEnumerable<AdditionalGTINDto> AddtionalGtinList { get; set; }
        public PMDSGeneralProductAttributesDto GeneralProductAttributes { get; set; }
        public PackagingHierarchyDto PackagingHierarchy { get; set; }
        public IEnumerable<ShipperItemCompositionDto> ShipperItemCompositionList { get; set; }
        public PMDSScaleItemDetailsDto ScaleItemDetails { get;set;}

        
    }
}
