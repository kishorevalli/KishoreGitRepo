﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSPackagingHierarchyDto
    {
        
        public string RetailPackType { get; set; }
        public string RetailPackTypeDescription { get; set; }
        public int RetailPackSize { get; set; }
        public decimal Size { get; set; }
        public string SizeUOM { get; set; }
        public string SizeUOMDescription { get; set; }
        public decimal LabelAmount { get; set; }
        public string MasterCaseCodeType { get; set; }
        public decimal MasterCaseGTIN { get; set; }
        public int MasterCaseGTINCheckDigit { get; set; }
        public string MasterCaseVendorItemGTIN { get; set; }
        public int MasterCaseSellingUnit { get; set; }
        public decimal MasterCaseWeight { get; set; }
        public decimal MasterCaseHeight { get; set; }
        public decimal MasterCaseLength { get; set; }
        public decimal MasterCaseDepth { get; set; }
        public decimal MasterCaseCubicFootage { get; set; }
        public string InnerPackExist { get; set; }
        public decimal InnerCaseGTIN { get; set; }
        public int InnerCaseGTINCheckDigit { get; set; }
        public int InnerCaseSellingUnits { get; set; }
        public decimal InnerCaseWeight { get; set; }
        public decimal InnerCaseNetWeight { get; set; }
        public decimal InnerCaseHeight { get; set; }
        public decimal InnerCaseLength { get; set; }
        public decimal InnerCaseDepth { get; set; }
        public decimal InnerCaseCubicFootage { get; set; }
        public int MasterCasesInSinglePalletLayer { get; set; }
        public int LayersOnPallet { get; set; }
        public string PalletGTIN { get; set; }
        public int PalletQuantity { get; set; }
        public decimal PalletCubicFootage { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
    }
}
