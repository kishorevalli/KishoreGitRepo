﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
   public class PMDSGTINDto
    {
        public bool IsGTINExist { get; set; }

        public long GTIN { get; set; }

        public int CheckDigit { get; set; }

        public string GTINTypeCode { get; set; }
        public string GTINTypeDescription { get; set; }

        public string CategoryOfGTIN { get; set; }
        private DateTime _lastScanDate = DateTime.Now;
        public DateTime? LastScanDate
        {
            get
            {
                return _lastScanDate;
            }
            set
            {
                if (value == null || value == DateTime.MinValue)
                    _lastScanDate = DateTime.Now;
                else
                    _lastScanDate = value.GetValueOrDefault();
            }
        }
    }
}
