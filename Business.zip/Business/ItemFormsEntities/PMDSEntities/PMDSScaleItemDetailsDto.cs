﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSScaleItemDetailsDto
    {
        public string BackRoomScaleIn { get; set; }
        public string ScaleDescFrstLn { get; set; }
        public string ScaleDescScndLn { get; set; }
        public decimal Tare { get; set; }
        public string ExtraTextReqTag { get; set; }
        public string NutriFactReqTag { get; set; }
        public string FkScaleNutriCod { get; set; }
        public string PriceModifierEdi { get; set; }
        public decimal? CalorieUnit { get; set; }
        public List<PMDSScaleItemGradeDto> ScaleItemGradeList { get; set; }
        public List<PMDSScaleItemLocationDto> ScaleItemLocationList { get; set; }
        public List<PMDSScaleItemOverrideDescDto> ScaleItemOverrideDescList { get; set; }
        public List<PMDSScaleItemShelfLifeDto> ScaleItemShelfLifeList { get; set; }

    }
}
