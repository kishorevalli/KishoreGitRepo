﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSGeneralProductAttributesDto
    {
        public string PerishableIndicator { get; set; }
        public DateTime? ProductDate { get; set; }
        public int? BornOnDays { get; set; }
        public string CountryOfOrigin { get; set; }
        public string Hazardous { get; set; }
        public string Ignitable { get; set; }
        public string Corrosive { get; set; }
        public string Reactive { get; set; }
        public string Toxic { get; set; }
        public string EPAListed { get; set; }
        public string ContainsBattery { get; set; }
        public string EMailForBatterySurvey { get; set; }
        public string DEARegulated { get; set; }
        public string NarcoticFlag { get; set; }
        public string DrugSchedule { get; set; }
        public decimal? NDCNumber { get; set; }
        public string NDCFormat { get; set; }
        public string NDCFormatDescription { get; set; }
        public string DisInfectent { get; set; }
        public string Allergic { get; set; }
        public string GlutenFree { get; set; }
        public string OrganicItem { get; set; }
        public string GreenLeaf { get; set; }
        public string Pesticide { get; set; }
        public string LiquorSwitch { get; set; }
        public string LiquorDescription { get; set; }
        public string TobaccoIndicator { get; set; }
        public string VariableWeightIndicator { get; set; }
        public string RandomUnitWeight { get; set; }
        public string FoodStampSwitch { get; set; }
        public decimal? UnitPricingCount { get; set; }
        public string UnitPricingUOM { get; set; }
        public int? ShelfTagCount { get; set; }
        public string TagSize { get; set; }
        public string SeasonalIndicator { get; set; }
        public string SeasonBeginDate { get; set; }
        public string SeasonEndDate { get; set; }
        public int? MinDaysRequired { get; set; }
        public int? MaxDaysRequired { get; set; }
        public int? WarehouseShelfLife { get; set; }
        public string QuantityRequired { get; set; }
        public string BioFlag { get; set; }
        public DateTime? ActivationProtectionEndDate { get; set; }
        public string ManuallyOrderedItem { get; set; }
        public DateTime? NutritionalInfoNotAvailableUntil { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }
}
