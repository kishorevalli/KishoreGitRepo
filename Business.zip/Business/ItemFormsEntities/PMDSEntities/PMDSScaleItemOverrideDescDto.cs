﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSScaleItemOverrideDescDto
    {
        public string DescText1 { get; set; }
        public string DescText2 { get; set; }
        public string FkFacGrpTypCod { get; set; }
        public string FkFacGrpTypCodDesc { get; set; }
        public Int16 FkFacGrpCode { get; set; }
        public string FkFacGrpCodeDesc { get; set; }

    }
}
