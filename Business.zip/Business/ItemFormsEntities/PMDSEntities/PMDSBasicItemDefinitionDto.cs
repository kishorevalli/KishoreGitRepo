﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSBasicItemDefinitionDto
    {
        public string ItemTypeCode { get; set; }
        public string ItemTypeDescription { get; set; }
        public decimal? GTIN { get; set; }
        public int? GTINCheckDigit { get; set; }
        public string ExistingGTINIndicator { get; set; }
        public int? CompressedUPC { get; set; }
        public decimal? PriceLookupCode { get; set; }
        public int? ReUseItemCode { get; set; }
        public string ReUseItemDescription { get; set; }
        public int? SubmissionReasonID { get; set; }
        public int? ItemCaseTypeID { get; set; }
        public string RecipeRequired { get; set; }
        public string IngredientItemRequired { get; set; }
        public int? ModelProductItemCode { get; set; }
        public string ModelProductItemDescription { get; set; }
        public string ModelProductItemTypeCode { get; set; }
        public int? ModelPackagingItemCode { get; set; }
        public string ModelPackagingItemDescription { get; set; }
        public string ModelPackagingItemTypeCode { get; set; }
        public string VendorItemCode { get; set; }
        public string VendorItemDescription { get; set; }
        public int ItemCode { get; set; }
        public string ItemDescription { get; set; }
        public string Brand { get; set; }
        public string Manufacturer { get; set; }
        public string RetailPackagedItem { get; set; }
        public string RetailPackType { get; set; }
        public string RetailPackTypeDescription { get; set; }
        public int? RetailPackSize { get; set; }
        public decimal? Size { get; set; }
        public string SizeUOM { get; set; }
        public string SizeUOMDescription { get; set; }
        public string MinorityManufacturer { get; set; }
        public string PackageDescription { get; set; }
        public string ContainerType { get; set; }
        public decimal? LabelAmount { get; set; }
        public string PerpetualInventoryFlag { get; set; }
        public string ReceiptDescription { get; set; }
        public string AdDescription { get; set; }
        public string ProductCatalogShortDescription1 { get; set; }
        public string ProductCatalogShortDescription2 { get; set; }
        public string NonDiscountable { get; set; }
        public string TaxExemptionRequired { get; set; }
        public string TaxExemptionVendorEmail { get; set; }
        public string TaxExemptionPublixEmail { get; set; }
        public string AdditionalGTINPresent { get; set; }
        public IEnumerable<AdditionalGTINDto> AddtionalGtinList { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        public DateTime? LastScanDate { get; set; }

        public string ScaleDescription1 { get; set; }
        public string ScaleDescription2 { get; set; }

        public string ShipperFlag { get; set; }
    }
}
