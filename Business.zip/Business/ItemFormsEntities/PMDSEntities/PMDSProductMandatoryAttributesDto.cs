﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSProductMandatoryAttributesDto
    {
        public int ProductAttributeGroupCode { get; set; }
        public string ProductAttributeGroup { get; set; }
        public int ProductAttributeCode { get; set; }
        public string ProductAttribute { get; set; }
        public int SequenceNumber { get; set; }
        public string PermittedValue { get; set; }
        public string AttributeType { get; set; }
        public string ItemGroupTypeCode { get; set; }
        public int ItemGroupCode { get; set; }
        public string DataType { get; set; } // varchar or numeric
        public string CurrentFamilyNo { get; set; }
    }
}


//"itemAttributes": [
//    {
//      "productAttributeGroupCode": 7,
//      "productAttributeGroup": "MPS            ",
//      "productAttributeCode": 21,
//      "productAttribute": "PKG DESCRIPTION",
//      "sequenceNumber": 1,
//      "dataType": "S",
//      "permittedValue": "BOX                      ",
//      "attributeType": "G",
//      "itemGroupTypeCode": "   ",
//      "itemGroupCode": 0,
//      "currentFamilyNo": null
//    },
//]