﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
   public class PMDSShipperItemCompositionDto
    {
        public string ShipperItemCode { get; set; }
        public string ShipperItemDescription { get; set; }
        public string ShipperGTIN { get; set; }
        public string ShipperGTINCheckDigit { get; set; }
        public string CompositionItemCode { get; set; }
        public string CompositionItemDescription { get; set; }
        public string CompositionGTIN { get; set; }
        public string CompositionGTINCheckDigit { get; set; }
        public string Quantity { get; set; }
        public string Uom { get; set; }
        public string FamilyGroupId { get; set; }
        public string SubDepartmentId { get; set; }
        public string SubDepartmentName { get; set; }
    }
}
