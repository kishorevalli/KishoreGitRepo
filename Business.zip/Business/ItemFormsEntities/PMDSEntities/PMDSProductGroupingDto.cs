﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSProductGroupingDto
    {
        public string CHILDGROUPTYPECODE { get; set; }
        public int? CHILDGROUPCODE { get; set; }
        public string CHILDFULLDESCRIPTION { get; set; }
        public string PARENTGROUPTYPECODE { get; set; }
        public int? PARENTGROUPCODE { get; set; }
        public string PARENTFULLDESCRIPTION { get; set; }
        public string GRANDPARENTGROUPTYPECODE { get; set; }
        public int? GRANDPARENTITEMGROUPCODE { get; set; }
        public string GRANDPARENTFULLDESCRIPTION { get; set; }
        public string ITEMTAG { get; set; }
    }
    
    public class PMDSChildGroupTypeCode
    {
        public string CHILDGROUPTYPECODE { get; set; }
        public string ITEMTAG { get; set; }
    }
}
