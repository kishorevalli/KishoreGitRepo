﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PIDMProductGroupVBGDto
    {
        public string code;
        public string Description;
        public List<PIDMProductGroupVBGVendorDto> Vendors;
        
    }
    public class PIDMProductGroupVBGVendorDto
    {
        public int VendorNumber;
        public string VendorDescription;
    }
}
