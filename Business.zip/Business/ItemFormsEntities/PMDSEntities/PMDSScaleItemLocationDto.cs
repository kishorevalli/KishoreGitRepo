﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities.PMDSEntities
{
    public class PMDSScaleItemLocationDto
    {
        public Int16 PluCode { get; set; }
        public int FkScaleLocCode { get; set; }
        public string FkScaleLocCodeDesc { get; set; }
        public Int16 FkScaleActNum { get; set; }
        public string FkScaleActNumDesc { get; set; }


    }
}
