﻿using System;
using System.Collections.Generic;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class NutritionalPanelDto
    {
        public int ID { get; set; }
        public int ItemFormID { get; set; }        
        public string NutritionalPanelName { get; set; }
        public decimal? GTIN { get; set; }
        public string FormattedGtin
        {
            get
            {
                return GTIN > 0 ? String.Format("{0:000-00000-00000}", GTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                GTIN = result ? (decimal?)GtinDec : null;
            }
        }
        public int? GTINCheckDigit { get; set; }
        public string ContainsAllergen { get; set; }
        public string ServingSize { get; set; }
        public decimal? ServingsPerContainer { get; set; }
        public int? SortOrder { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        public bool IsDirty { get; set; }
        public bool IsDeleted { get; set; }
        public List<NutritionalInfoDto> NutritionalInfoList { get; set; }
        public List<NutritionalAllergenInfoDto> NutritionalAllergenInfoList { get; set; }
    }
}
