﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class DashboardSearchCriteriaDto
    {
        // public string FormattedSearchGtin { get; set; }

        public int BuyerID { get; set; }
        public string VendorContactID { get; set; }
        public decimal GTIN { get; set; }
        public string FormattedGtin
        {
            get
            {
                return GTIN > 0 ? String.Format("{0:000-00000-00000}", GTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                GTIN = result ? GtinDec : Decimal.Zero;
            }
        }
        public int SearchGTINCheckDigit { get; set; }
        public int SearchItemCode { get; set; }
        public DateTime SearchSubmittedFromDate { get; set; }
        public int CompressedUPC { get; set; }
        public string SearchItemDescription { get; set; }
        public DateTime SearchSubmittedToDate { get; set; }
        public int PriceLookupCode { get; set; }
        public string SearchFormStatusId { get; set; }
        public Int64 SearchFormId { get; set; }
        public string searchSelectedOrganization { get; set; }
        public string searchSelectedVendors { get; set; }

        public string finalVendorList { get; set; }

        public UserType userType { get; set; }

        public string viewItemFormsForUserID { get; set; }

        public bool IncludeVSARelatedForm { get; set; }

        public bool IsIncludeRelatedFromChecked { get; set; }

        public bool IsIncludeGroupedItemFormChecked { get; set; }





    }
}


