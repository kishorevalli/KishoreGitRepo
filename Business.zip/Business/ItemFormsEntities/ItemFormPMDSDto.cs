﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ItemFormPMDSDto
    {
        public int ID { get; set; }
        public Int64 ItemFormDisplayID { get; set; }      
        public int FormTypeID { get; set; }
      //  public string DSDAuthRequestSelectStoreOption { get; set; }
        public int? ItemCode { get; set; }
        public int? BuyerID { get; set; }
        public string BuyerName { get; set; }        
        public BasicItemDefinitionDto BasicItemDefinition { get; set; }        
        public GeneralProductAttributesDto GeneralProductAttributes { get; set; }
        public IEnumerable<ShipperItemCompositionDto> ShipperItemCompositionList { get; set; }
        public IEnumerable<PackagingHierarchyDto> PackagingHierarchy { get; set; }
        public IEnumerable<DsdVendorAuthorizationDto> DsdVendorAuthorizations { get; set; }
        public IEnumerable<ProductGroupingDto> ProductGrouping { get; set; }
        public IEnumerable<ProductAttributeDto> ProductAttributes { get; set; }
        public ScaleInfoDto ScaleItemDetails { get; set; }        
    }
}
