﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class AdditionalGTINDto
    {
        public int ID { get; set; }
        public int ItemFormID { get; set; }
        public decimal GTIN { get; set; }
        public string FormattedGtin
        {
            get
            {
                return GTIN > 0 ? String.Format("{0:000-00000-00000}", GTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                GTIN = result ? GtinDec : Decimal.Zero;
            }
        }
        public int? GTINCheckDigit { get; set; }
        public string ExistingGTINIndicator { get; set; }
        public int? CompressedUPC { get; set; }
        public decimal? PriceLookupCode { get; set; }
        public string OverrideReceiptDescription { get; set; }
        public string RetailPackType { get; set; }

        public string RetailPackTypeDescription { get; set; }
        public int? RetailPackSize { get; set; }
        public decimal? Size { get; set; }
        public string SizeUOM { get; set; }        
        public string SizeUOMDescription { get; set; }
        public decimal? LabelAmount { get; set; }
        public string NonDiscountable { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }
}