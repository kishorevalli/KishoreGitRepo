﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class DsdVendorAuthorizationDto
    {
        public int ID { get; set; }

        public int ItemFormID { get; set; }

        public int VendorNumber { get; set; }

        public string VendorName { get; set; }

        public string StateCode { get; set; }

        public string StateName { get; set; }

        public string CountyCode { get; set; }

        public string CountyName { get; set; }

        public int NoOfStores { get; set; }
    }
}
