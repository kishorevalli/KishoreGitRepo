﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
   public class ItemFormPurgeCriteriaDTO
    {
        public int FormTypeID;
        public string FormStatus;
        public string PurgeDateFieldName;
        public int DateFactor;
        public string PurgeFlag;
        public string PurgeDataBaseName;
        public string PurgeListTableGroupNumber;
        public string PurgeDateFieldTableName;        
    }
}
