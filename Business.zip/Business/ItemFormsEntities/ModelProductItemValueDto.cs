﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ModelProductItemValueDto
    {

        public int ItemFormID { get; set; }
        public string Brand { get; set; }
        public string Manufacturer { get; set; }
        public string ItemDescription { get; set; }
        public string ReceiptDescription { get; set; }
        public string ScaleDescription1 { get; set; }
        public string ScaleDescription2 { get; set; }      
        public string AdDescription { get; set; }
        public string ProductCatalogShortDescription1 { get; set; }
        public string ProductCatalogShortDescription2 { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }
}
