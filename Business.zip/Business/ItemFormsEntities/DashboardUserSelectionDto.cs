﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
   public class DashboardUserSelectionDto
    {
        public string LoggedInUserID { get; set; }      

        public string VendorContactID { get; set; }
        public int? BuyerID { get; set; }
        public bool? IsVSARelatedFormChecked { get; set; }
        public bool? IsVSAUser { get; set; }
        public bool IsFavouriteClicked { get; set; }
        public bool IsSearchClicked { get; set; }
        public int? DashboardStatusQueriesID { get; set; }
        public string DashboardStatusName { get; set; }        
        public int StatusID { get; set; }
        public decimal? SearchGTIN { get; set; }

        public string SearchFormattedGtin
        {
            get
            {
                return SearchGTIN > 0 ? String.Format("{0:000-00000-00000}", SearchGTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                SearchGTIN = result ? GtinDec : Decimal.Zero;
            }
        }

        public int? SearchGTINCheckDigit { get; set; }
        public int? SearchItemCode { get; set; }
        public Int64? SearchFormID { get; set; }        
        public DateTime? SearchSubmittedFromDate { get; set; }
        public DateTime? SearchSubmittedToDate { get; set; }
        public int? CompressedUPC { get; set; }
        public string SearchItemDescription { get; set; }
        public int? PriceLookupCode { get; set; }
        public int? SearchFormStatusId { get; set; }
        public string searchSelectedOrganization { get; set; }
        public string searchSelectedVendors { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }

    }
}
