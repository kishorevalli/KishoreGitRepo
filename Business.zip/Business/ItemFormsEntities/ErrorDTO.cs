﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ErrorDTO
    {
        public string ErrorCode { get; set; }
        public string SeverityLevel { get; set; }
        public string ControlName { get; set; }

        public string TabName { get; set; }

        public string ErrorDescription { get; set; }
    }
    public class WarningDTO
    {
        public string ErrorCode { get; set; }
        public string ControlName { get; set; }
        public string ErrorDescription { get; set; }
    }
    public class SubTabValidationDTO
    {
        public string SubTabType { get; set; }
        public string SubTabName { get; set; }
        public List<ErrorDTO> Errors { get; set; }
        public List<WarningDTO> Warnings { get; set; }

    }
    public class ItemValidationDTO
    {
        public string TabName { get; set; }
        public List<ErrorDTO> Errors { get; set; }
        public List<WarningDTO> Warnings { get; set; }
        public List<SubTabValidationDTO> SubTabValidations { get; set; }

    }

    public class ItemSaveResponseDTO
    {
        public bool Status { get; set; }
        public ItemValidationDTO Validation { get; set; }

    }


}
