﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ProductAttributeDto
    {
        public int ID { get; set; }        
        public int ItemFormID { get; set; }
        public int? ProductAttributeGroupCode { get; set; }
        public string ProductAttributeGroupDescription { get; set; }
        public string ProductAttributeType { get; set; }
        public int? AttributeCode { get; set; }
        public string AttributeDescription { get; set; }
        public int? AttributeValueSequenceNumber { get; set; }
        public string AttributeValueDisplayText { get; set; } 
        public string NewAttributeValue { get; set; }
        public string NewAttributeApprovalIndicator { get; set; }        
        public string NewAttributeApprovedBy { get; set; }
        public DateTime? NewAttributeApprovedDate { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string ItemGroupType { get; set; }
        public int ItemGroupCode { get; set; }
        public string DataType { get; set; }        
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        public int modelGroupCodeType { get; set; }
        //public bool IsApproved
        //{
        //    get { return (NewAttributeApprovalIndicator != null && NewAttributeApprovalIndicator == "Y"); }
        //    set { NewAttributeApprovalIndicator = value ? "Y" : "N"; }
        //}
        public List<LookupIntDto> PermittedValues { get; set; }

        public string CurrentFamilyNo { get; set; }

        public string Visible { get; set; }

        public string ReadOnly { get; set; }

        //  public bool IsDirty { get; set; }
    }
}
