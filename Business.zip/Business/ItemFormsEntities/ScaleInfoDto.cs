﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ScaleInfoDto
    {
        public int ItemFormID { get; set; }
        public string BackroomScaleIndicator { get; set; }
        public string ScaleDescription1 { get; set; }
        public string ScaleDescription2 { get; set; }
        public decimal? CalorieInformation { get; set; }
        public decimal? Tare { get; set; }
        public string ScaleExtraTextRequired { get; set; }
        public string PriceModifier { get; set; }
        public string NutritionCodeRequired { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public bool IsDirty { get; set; }
        public bool IsDirtyItemOverride { get; set; }
        public bool IsDirtyScaleLocation { get; set; }
        public bool IsDirtyScaleGrade { get; set; }
        public bool IsDirtyScaleShelfLife { get; set; }
        public int FormActionID { get; set; }
        public List<ScaleOverrideDescriptionDto> ScaleOverrideDescriptionList { get; set; }
        public List<ScaleShelfLifeDto> ScaleShelfLifeList { get; set; }
        public List<ScaleLocationDto> ScaleLocationList { get; set; }
        public List<ScaleGradeDto> ScaleGradeList { get; set; }
    }
}
