﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class CategoryReviewDto
    {
        public string Vendor { get; set; }
        public string RSS { get; set; }
        public string GTINWithCheckDigit {
            get
            {
                return GTIN > 0 ? String.Format("{0:000-00000-00000}", GTIN) + " " + ((int)GTINCheckDigit).ToString() : "";
            }
            set { }
        }        
        public string ItemDescription { get; set; }
        public string ProjectedSales52WeeksStr {
            get
            {
                return ProjectedSales52Weeks != null ? string.Format("{0:c}", ProjectedSales52Weeks) : "";
            }
            set { }
        }
        public string UnitCostStr
        {
            get
            {
                return UnitCost != null ? string.Format("{0:c}", UnitCost) : "";
            }
            set { }
        }
        public string UnitCostUOM { get; set; }
        public decimal? CaseCost { get; set; }
        public string CasePack { get; set; }
        public string SuggestedRetailStr
        {
            get
            {
                return SuggestedRetail != null ? string.Format("{0:c}", SuggestedRetail) : "";
            }
            set { }
        }
        public string SuggestedMarginStr
        {
            get
            {
                return SuggestedMargin != null ? SuggestedMargin.ToString() : "";
            }
            set { }
        }
        public string ItemPreviouslyPresented { get; set; }
        public string AvailableShipDateStr
        {
            get
            {
                return AvailableShipDate != null ? ((DateTime)AvailableShipDate).ToString("MM/dd/yyyy") : "";
            }
            set { }
        }
        public string NewItemFundsAvailable { get; set; }
        public string NewItemFundsAmountStr
        {
            get
            {
                return NewItemFundsAmount != null ? string.Format("{0:c}", NewItemFundsAmount) : "";
            }
            set { }
        }      
        public string VendorComments { get; set; }
        public string BuyerComments { get; set; }
        public string ItemFormDisplayID { get; set; }
        public decimal GTIN { get; set; }
        public int? GTINCheckDigit { get; set; }
        public decimal? ProjectedSales52Weeks { get; set; }
        public decimal? UnitCost { get; set; }
        public decimal? SuggestedRetail { get; set; }
        public decimal? SuggestedMargin { get; set; }
        public DateTime? AvailableShipDate { get; set; }
        public decimal? NewItemFundsAmount { get; set; }
        public int ItemFormID { get; set; }
    }
}
