﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ProductGroupType
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public string ItemTag { get; set; }
        public bool IsMandatory {
            get { return (ItemTag != null && ItemTag == "M"); }
        }
    }
}
