﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class RetailPackTypeDto
    {
        public string RetailPackType { get; set; }

        public string RetailPackTypeDescription { get; set; }
        public int? RetailPackSize { get; set; }
        public decimal? Size { get; set; }
        public string SizeUOM { get; set; }
        public string SizeUOMDescription { get; set; }
        public decimal? LabelAmount { get; set; }
    }
}
