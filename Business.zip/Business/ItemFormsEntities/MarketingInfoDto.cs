﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class MarketingInfoDto
    {
        public int ItemFormID { get; set; }
        public decimal? ProjectedSales52Weeks { get; set; }
        public decimal? UnitCost { get; set; }
        public string UnitCostUOM { get; set; }
        public decimal? SuggestedRetail { get; set; }
        public decimal? SuggestedMargin { get; set; }
        public string ItemPreviouslyPresented { get; set; }
        public DateTime? AvailableShipDate { get; set; }
        public string NewItemFundsAvailable { get; set; }
        public decimal? NewItemFundsAmount { get; set; }
        public string PromoSupportFrequency { get; set; }
        public string MediaSupport { get; set; }
        public string LocalChainPresentlyStocking { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        #region Needed info to update in ItemFormDto 
        public int? FormStatusID { get; set; }
        public int? FormActionID { get; set; }
        public UserType SubmittedUserTypeID { get; set; }
        public string VendorContactEmail { get; set; }
        #endregion
        public List<SimilarItemGTINDto> SimilarItemGTINList { get; set; }
    }
}
    