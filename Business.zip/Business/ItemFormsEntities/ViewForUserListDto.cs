﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
   public class ViewForUserListDto
    {


        public int? ItemFormId { get; set; }

        public string ViewForUserId { get; set; }

        public bool? IsValidForAssignment { get; set; }

    }
}
