﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class VendorDomainDto
    {
        public int VendorNumber { get; set; }
        public string VendorName { get; set; }
        public string VendorType { get; set; }
        public int OrganizationID { get; set; }
        public string OrganizationName { get; set; }
        public string SearchType { get; set; }
        public string SearchString { get; set; }

    }

    public class VendorDomainComparer : IEqualityComparer<VendorDomainDto>
    {
        // Products are equal if their names and product numbers are equal.
        public bool Equals(VendorDomainDto x, VendorDomainDto y)
        {

            //Check whether the compared objects reference the same data.
            if (Object.ReferenceEquals(x, y)) return true;

            //Check whether any of the compared objects is null.
            if (Object.ReferenceEquals(x, null) || Object.ReferenceEquals(y, null))
                return false;

            //Check whether the products' properties are equal.
            return x.VendorNumber == y.VendorNumber && x.VendorNumber == y.VendorNumber;
        }

        // If Equals() returns true for a pair of objects 
        // then GetHashCode() must return the same value for these objects.

        public int GetHashCode(VendorDomainDto shipperItemComposition)
        {
            //Check whether the object is null
            if (Object.ReferenceEquals(shipperItemComposition, null)) return 0;

            //Get hash code for the Name field if it is not null.
            int hashProductName = shipperItemComposition.VendorNumber == null ? 0 : shipperItemComposition.VendorNumber.GetHashCode();

            //Get hash code for the Code field.
            int hashProductCode = shipperItemComposition.VendorNumber.GetHashCode();

            //Calculate the hash code for the product.
            return hashProductName ^ hashProductCode;
        }

    }


}
