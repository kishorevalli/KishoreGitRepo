﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class WarehouseGtinDto
    {
        public int ItemFormID { get; set; }
        public decimal GTIN { get; set; }
        public int? WarehouseNumber { get; set; }

        public string Name { get; set; }
    }
}

