﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ProductGroupingDto
    {
        public string ProductGroupType { get; set; }
        public int? ProductGroupCode { get; set; }
        public string ProductGroupDescription { get; set; }
        public int ModelGroupCodeType { get; set; }
        public List<ProductGroupingDto> Parents { get; set; }
        public bool IsMandatory { get; set; }
        public List<ProductGroupingVendorDto> Vendors;
    }

    public class ProductGroupingLinearDto
    {
        public int? ID { get; set; }
        public int? ItemFormID { get; set; }
        public string ChildProductGroupType { get; set; }
        public int? ChildProductGroupCode { get; set; }
        public string ChildProductGroupDescription { get; set; }
        public string ItemTag { get; set; }
        public string ParentProductGroupType { get; set; }
        public int? ParentProductGroupCode { get; set; }
        public string ParentProductGroupDescription { get; set; }
        public string GrandParentProductGroupType { get; set; }
        public int? GrandParentProductGroupCode { get; set; }
        public string GrandParentProductGroupDescription { get; set; }
        public bool IsMandatory
        {
            get { return (ItemTag != null && ItemTag == "M"); }
            set { ItemTag = value ? "M" : "O"; }
        }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }

    //public class ProductGroup
    //{
    //    public string ProductGroupType { get; set; }
    //    public int ProductGroupCode { get; set; }
    //    public string ProductGroupDescription { get; set; }
    //    public int Level { get; set; }
    //}
}
