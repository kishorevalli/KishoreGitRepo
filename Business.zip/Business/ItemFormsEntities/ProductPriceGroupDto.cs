﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ProductPriceGroupDto
    {
        public int PriceGroupID { get; set; }
        public string PriceGroupName { get; set; }
        public int LeadItemCode { get; set; }
        public int ItemCode { get; set; }
        public string ItemDescription { get; set; }
        public int? VendorNumber { get; set; }
        public string VendorName { get; set; }
        public IEnumerable<ProductPriceGroupDto> PriceGroupItems { get; set; }
    }
}
