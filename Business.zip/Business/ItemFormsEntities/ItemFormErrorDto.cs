﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ItemFormErrorDto
    {
        public int Id { get; set; }
        public int ItemFormID { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
        public string TabName { get; set; }
        public string SubTabName { get; set; }
        public string ControlName { get; set; } // This value comes from ErrorMessage Table
        public string SeverityLevel { get; set; } // This value comes from ErrorMessage Table
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
