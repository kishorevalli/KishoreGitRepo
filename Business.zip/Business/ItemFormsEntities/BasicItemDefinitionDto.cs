﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class BasicItemDefinitionDto
    {
        public int ItemFormID { get; set; }

        public long ItemFormDisplayId { get; set; }
        public string ItemTypeCode { get; set; }
        public string ItemTypeDescription { get; set; }

        public decimal GTIN { get; set; }    
        public string FormattedGtin
        {
            get
            {
                return GTIN > 0 ? String.Format("{0:000-00000-00000}", GTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                GTIN = result ? GtinDec : Decimal.Zero;
            }
        }

        public int? GTINCheckDigit { get; set; }
        public string ExistingGtinIndicator { get; set; }

      
        public int? CompressedUPC { get; set; }

        
        public decimal? PriceLookupCode { get; set; }
        public int? ReuseItemCode { get; set; }
        public string ReUseItemDescription { get; set; }

        
        public int? SubmissionReasonID { get; set; }
        
        public int? ItemCaseTypeID { get; set; }
        public string RecipeRequired { get; set; }
        public string IngredientItemRequired { get; set; }
        public int? ModelProductItemCode { get; set; }
        public string ModelProductItemDescription { get; set; }
        public string ModelProductItemTypeCode { get; set; }
        public int? ModelPackagingItemCode { get; set; }
        public string ModelPackagingItemDescription { get; set; }
        public string ModelPackagingItemTypeCode { get; set; }
        public string VendorItemCode { get; set; }
        public string VendorItemDescription { get; set; }
        public int? ItemCode { get; set; }
        public string ItemDescription { get; set; }
        public string Brand { get; set; }
        public string Manufacturer { get; set; }
        public string RetailPackagedItem { get; set; }
        public string RetailPackType { get; set; }
        public string RetailPackTypeDescription { get; set; }
        public int? RetailPackSize { get; set; }
        public decimal? Size { get; set; }
        public string SizeUOM { get; set; }
        public string SizeUOMDescription { get; set; }

        public string BackroomScaleIndicator { get; set; }
        public string ScaleDescription1 { get; set; }
        public string ScaleDescription2 { get; set; }

        public string MinorityManufacturer { get; set; }
        public string PackageDescription { get; set; }
        public string ContainerType { get; set; }
        public decimal? LabelAmount { get; set; }
        public string PerpetualInventoryFlag { get; set; }
        public string ReceiptDescription { get; set; }
        public string AdDescription { get; set; }
        public string ProductCatalogShortDescription1 { get; set; }
        public string ProductCatalogShortDescription2 { get; set; }
        public string NonDiscountable { get; set; }
        public string AdditionalGTINPresent { get; set; }

        public string AutoGenerateType4GTIN { get; set; }

        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }



        //public DateTime? LastScanDate { get; set; }

        private DateTime _lastScanDate = DateTime.Now;
        public DateTime? LastScanDate
        {
            get
            {
                return _lastScanDate;
            }
            set
            {
                if (value == null || value == DateTime.MinValue)
                    _lastScanDate = DateTime.Now;
                else
                    _lastScanDate = value.GetValueOrDefault();
            }
        }

        public int FormTypeID { get; set; }

        public int FormStatusID { get; set; }

        public int FormActionID { get; set; }

        public UserType SubmittedUserTypeID { get; set; }

        public string VendorContactID { get; set; }

        public bool IsBrandChanged { get; set; }

        public bool IsManufacturerChanged { get; set; }

        public string ShipperFlag { get; set; }


        public List<AdditionalGTINDto> AddtionalGtinList { get; set; }
    }
    
}