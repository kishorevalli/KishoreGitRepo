﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    //public class FormActionStatusDto
    //{
    //    public int ItemFormID { get; set; }

    //    public int FormTypeId { get; set; }
    //    public int CurrentFormStatusID { get; set; }
    //    public string CurrentFormStatus { get; set; }
    //    public int FormActionID { get; set; }
    //    public string ActionName { get; set; }
    //    public string BuyerActionName { get; set; }
    //    public string VendorActionName { get; set; }
    //    public int CreatedFormStatusID { get; set; }
    //    public string CreatedFormStatus { get; set; }
    //    public string ActionComment { get; set; }
    //    public string CurrentFormStatusComment { get; set; }
    //    public string CreatedFormStatusComment { get; set; }

    //    public string LastUpdatedBy { get; set; }
    //}


}
