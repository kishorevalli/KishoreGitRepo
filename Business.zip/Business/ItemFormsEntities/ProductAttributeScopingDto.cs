﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ProductAttributeScopingDto
    {
        public int ID { get; set; }
        public int ProductAttributeGroupCode { get; set; }
        public string ProductAttributeGroupDescription { get; set; }
        public int? AttributeCode { get; set; }
        public string AttributeDescription { get; set; }
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public string ReadOnly { get; set; }
        public string Visible { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public string ColumnValue { get; set; }

    }
}
