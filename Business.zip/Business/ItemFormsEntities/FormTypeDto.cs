﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Publix.S0VPITEM.ItemFormsWeb.Models
{
    
    public class FormTypeDto
    { 
        public int ID;
        public string Name;
        public bool IsActive;
        public string CreatedBy;
        public DateTime CreatedDate;
        public string LastUpdatedBy;
        public DateTime LastUpdatedDate;
    }

}