﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class PackagingHierarchyDto
    {
        public int ID { get; set; }
        public int ItemFormID { get; set; }
        public string RetailPackType { get; set; }
        public string RetailPackTypeDescription { get; set; }
        public int? RetailPackSize { get; set; }
        public decimal? Size { get; set; }
        public string SizeUOM { get; set; }
        public string SizeUOMDescription { get; set; }
        public decimal? LabelAmount { get; set; }
        public string MasterCaseCodeType { get; set; }
        public decimal? MasterCaseGTIN { get; set; }

        public string MasterCaseFormattedGtin
        {
            get
            {
                return MasterCaseGTIN > 0 ? String.Format("{0:000-00000-00000}", MasterCaseGTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                MasterCaseGTIN = result ? GtinDec : Decimal.Zero;
            }
        }

        public int? MasterCaseGTINCheckDigit { get; set; }
        public string MasterCaseVendorItemGTIN { get; set; } 
        public int? MasterCaseSellingUnit { get; set; }        
        public decimal? MasterCaseWeight { get; set; }
        public decimal? MasterCaseNetWeight { get; set; }
        public decimal? MasterCaseHeight { get; set; }
        public decimal? MasterCaseLength { get; set; }
        public decimal? MasterCaseDepth { get; set; }
        public decimal? MasterCaseCubicFootage { get; set; }
        public string InnerPackExist { get; set; }
        public string InnerCaseCodeType { get; set; }
        public decimal? InnerCaseGTIN { get; set; }

        public string InnerCaseFormattedGtin
        {
            get
            {
                return InnerCaseGTIN > 0 ? String.Format("{0:000-00000-00000}", InnerCaseGTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                InnerCaseGTIN = result ? GtinDec : Decimal.Zero;
            }
        }

        public int? InnerCaseGTINCheckDigit { get; set; }
        public int? InnerCaseSellingUnits { get; set; }
        public decimal? InnerCaseWeight { get; set; }
        public decimal? InnerCaseNetWeight { get; set; }
        public decimal? InnerCaseHeight { get; set; }
        public decimal? InnerCaseLength { get; set; }
        public decimal? InnerCaseDepth { get; set; }
        public decimal? InnerCaseCubicFootage { get; set; }
        public int? MasterCasesInSinglePalletLayer { get; set; }
        public int? LayersOnPallet { get; set; }
        public string PalletGTIN { get; set; }
        //public string palletFormattedGtin
        //{
        //    get
        //    {
        //        return PalletGTIN > 0 ? String.Format("{0:000-00000-00000}", PalletGTIN) : "";
        //    }
        //    set
        //    {
        //        decimal GtinDec;
        //        bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
        //        PalletGTIN = result ? GtinDec : Decimal.Zero;
        //    }
        //}
        public int? PalletQuantity { get; set; }
        public decimal? PalletCubicFootage { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        public int FormActionID { get; set; }
        public int FormStatusID { get; set; }
        public bool IsDirty { get; set; }
        public UserType SubmittedUserTypeID { get; set; }
        public decimal GTIN { get; set; } // This is the primary GTIN of the item form . Added it here as it is required for primary vendor validation.
        public List<OrderablePackLevelDto> orderablePackLevels { get; set; }
    }
}
