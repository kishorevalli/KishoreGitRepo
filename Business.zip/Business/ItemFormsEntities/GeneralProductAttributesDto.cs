﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Collections.Generic;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class GeneralProductAttributesDto
    {
        public int ItemFormID { get; set; }        
        public int NutritionalPanelTypeID {get ; set;}
        public string PerishableItem { get; set; }
        public string ProductDate { get; set; }
        public int? BornOnDays { get; set; }
        public string CountryOfOrigin { get; set; }        
        public string Ignitable { get; set; }
        public string Corrosive { get; set; }
        public string Reactive { get; set; }
        public string Toxic { get; set; }
        public string EPAListedWaste { get; set; }
        public string ContainsBattery { get; set; }
        public string EMailForBatterySurvey { get; set; }
        public string DEARegulated { get; set; }       
        public string Narcotic { get; set; }
        public string DrugScheduleCode { get; set; }
        public decimal? NDCNumber { get; set; }
        public string NDCFormat { get; set; }
        public string NDCFormatDescription { get; set; }
        public string Disinfectant { get; set; }
        public string Allergic { get; set; }
        public string GlutenFree { get; set; }
        public int OrganicTypesID { get; set; }
        public string PMDSOrganicName { get; set; }
        public string GreenLeaf { get; set; }
        public string Pesticide { get; set; }      
        public string Liquor { get; set; }
        public string LiquorDescription { get; set; }    
        public string Tobacco { get; set; }
        public string VariableWeightIndicator { get; set; }
        public string RandomWeight { get; set; }
        public string FoodStamp { get; set; }
        public decimal? UnitPricingCount { get; set; }
        public string UnitPricingUOM { get; set; }    
        public int? TagCount { get; set; }
        public string TagSize { get; set; }     
        public string SeasonalItem { get; set; }
        public string SeasonBeginDate { get; set; }
        public string SeasonEndDate { get; set; }
        public int? MinDaysRequired { get; set; }
        public int? MaxDaysRequired { get; set; }    
        public int? WhseShelfLife { get; set; }
        public string IgnoreQuantityCheck { get; set; }
        public string BioFlag { get; set; }
        public DateTime? ActivationProtectionEndDate { get; set; }
        public string ManuallyOrderedItem { get; set; }
        public DateTime? NutritionalInfoNotAvailableUntil { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        public bool IsDirty { get; set; }
        public int FormStatusID { get; set; }
        public int FormActionID { get; set; }
        public UserType SubmittedUserTypeID { get; set; }
        public List<NutritionalPanelDto> NutritionalPanelList { get; set; }
        //Extra fields to validate GPA
        public string RetailPackagedItem { get; set; }
    }
}
