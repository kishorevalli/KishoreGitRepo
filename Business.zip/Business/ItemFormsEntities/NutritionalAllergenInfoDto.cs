﻿using System;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class NutritionalAllergenInfoDto
    {
        public int ID { get; set; }
        public int NutritionalPanelID { get; set; }
        public int NutrDictionaryID { get; set; }
        public string AllergenName { get; set; }
        public string Value { get; set; }
        public int? SortOrder { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }
}
