﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
   public class ItemFormPurgeTableListDTO
    {

        public int PurgeListGroupNumber;
        public string PurgeTableName;
        public string PurgeFlag;
        public string PurgeDataBase;
        public string PurgeTableFieldName;
        public string SubQueryTableName;
        public string SubQueryFieldName;
        public string PurgeTableSequence;      
    }
}
