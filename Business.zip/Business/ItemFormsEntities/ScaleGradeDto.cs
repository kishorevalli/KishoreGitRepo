﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ScaleGradeDto
    {
        public int ID { get; set; }
        public int ItemFormID { get; set; }
        public string FacilityGroupType { get; set; }
        public string FacilityGroupTypeDescription { get; set; }
        public Int16 FacilityGroupCode { get; set; }
        public string FacilityGroupDescription { get; set; }
        public Int16 Grade { get; set; }
        public string GradeDescription { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedDate { get; set; }
                
    }
}
