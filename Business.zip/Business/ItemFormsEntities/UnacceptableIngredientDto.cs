﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class UnacceptableIngredientDto
    {
        public int ID { get; set; }
        public string Ingredient { get; set; }
        public string Description { get; set; }
    }
}
