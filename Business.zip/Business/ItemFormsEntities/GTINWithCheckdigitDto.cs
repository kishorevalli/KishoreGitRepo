﻿using System;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class GTINWithCheckdigitDto
    {
        public decimal GTIN { get; set; }
        public string FormattedGtin
        {
            get
            {
                return GTIN > 0 ? String.Format("{0:000-00000-00000}", GTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                GTIN = result ? GtinDec : Decimal.Zero;
            }
        }
        public int? GTINCheckDigit { get; set; }
    }
}
