﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class OrderablePackLevelDto
    {
           public int PackagingHierarchyID { get; set; }
           public int InsertedByUserTypeID { get; set; }
           public int? VendorNumber { get; set; }
           public string VendorDescription { get; set; }

        public string VendorType { get; set; }
        public int? Warehouse { get; set; }
           public string WarehouseDescription { get; set; }
           public int? OrderingPackagingLevelID { get; set; }

          public string OrderingPackagingLevelDescription { get; set; }
           public int? OrderPackQuantity { get; set; }
           public int? ShippingPackagingLevelID { get; set; }

           public string ShippingPackagingLevelDescription { get; set; }
           public int? ShippingPackQty { get; set; }
           public int? ShipMax { get; set; }
           public string ShipPallet { get; set; }
           public DateTime? EffectiveDate { get; set; }
        
        //   public string EffectiveDateString
        //{
        //    get
        //    {
        //        return EffectiveDate == null ? "" : EffectiveDate.ToString();
        //    }
        //    set
        //    {
        //        if (value == "")
        //            EffectiveDate = null;
        //        else
        //            EffectiveDate = Convert.ToDateTime(EffectiveDateString);
        //    }
        //}


        public DateTime? TerminationDate { get; set; }

      //  public string TerminationDateString { get; set; }

        public string PrimaryVendor { get; set; }
        public bool PrimaryVendorBool
        {
            get
            {
                return PrimaryVendor == "Y" ? true : false;
            }
            set
            {
                PrimaryVendor = value == true ? "Y" : "N";
            }
        }


        public string CreatedBy { get; set; }
           public DateTime? CreatedDate { get; set; }
           public string LastUpdatedBy { get; set; }
           public DateTime? LastUpdatedDate { get; set; }
    }
}
