﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ScaleItemFacilityLookupDto
    {
        public string Code;
        public string Description;
        public string FacilityGroup;
        public string FacilityGroupDescription;
        public string FacilityCodeDescription;

        public ScaleItemFacilityLookupDto(string code, string description, string facilityGroup, string facilityGroupDescription)
        {
            Code = code;
            Description = description;
            FacilityGroup = facilityGroup;
            FacilityGroupDescription = facilityGroupDescription;
            FacilityCodeDescription = code + " - " + description;
        }
        

    }
}
