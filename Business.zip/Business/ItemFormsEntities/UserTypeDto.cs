﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class UserTypesDto
    {
        public int ID;
        public string Name;
        public bool IsActive;
        public string CreatedBy;
        public DateTime CreatedDate;
        public string LastUpdatedBy;
        public DateTime LastUpdatedDate;

    }

    public enum UserType
    {
        ALL = 0,
        Vendor,
        Buyer,
        Clerical,
        MfgClerical,
        MfgBDD,
        CategoryMgr,
        Support,
        BuyerReadOnly,
     

    };
}

  
        