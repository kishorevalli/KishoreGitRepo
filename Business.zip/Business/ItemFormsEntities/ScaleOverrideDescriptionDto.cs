﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ScaleOverrideDescriptionDto
    {
        public int ID { get; set; }
        public int ItemFormID { get; set; }
        public string FacilityGroupType { get; set; }
        public string FacilityGroupTypeDescription { get; set; }
        public Int16 FacilityGroupCode { get; set; }
        public string FacilityGroupDescription { get; set; }
        public string OverrideDescriptionLine1 { get; set; }
        public string OverrideDescriptionLine2 { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }
        
    }
}
