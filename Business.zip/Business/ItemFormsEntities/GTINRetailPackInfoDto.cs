﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class GTINRetailPackInfoDto
    {
        public decimal[] NutritionalPanelGTINList { get; set; }

        public int[] PackagingHierarchiesList { get; set; }

        public int ItemFormID { get; set; }
    }
}
