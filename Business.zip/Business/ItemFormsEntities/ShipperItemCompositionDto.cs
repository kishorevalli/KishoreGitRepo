﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ShipperItemCompositionDto
    {
        public int? ItemFormID { get; set; }
        public string ShipperItemCode { get; set; }
        public string ShipperItemDescription { get; set; }
        public string ShipperGTIN { get; set; }
        public string ShipperGTINCheckDigit { get; set; }
        public string CompositionItemCode { get; set; }
        public string CompositionItemDescription { get; set; }
        public decimal CompositionGTIN { get; set; }
        public string FormattedCompositionGtin
        {
            get
            {
                return CompositionGTIN > 0 ? String.Format("{0:000-00000-00000}", CompositionGTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                CompositionGTIN = result ? GtinDec : Decimal.Zero;
            }
        }

        public string CompositionItemTypeCode { get; set; }
        public string CompositionGTINCheckDigit { get; set; }
        public string Quantity { get; set; }
        public string CompositionUOM { get; set; }
        public string CompositionUOMDescription { get; set; }
        public string FamilyGroupId { get; set; }
        public string SubDepartmentID { get; set; }
        public string SubDepartment { get; set; }
        public string VendorNumber { get; set; }
        public int? FormStatusID { get; set; }
        public int? FormActionID { get; set; }
        public UserType SubmittedUserTypeID { get; set; }

        public UserType CreatedByUserTypeID { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    
    }

    public class ShipperItemCompositionComparer : IEqualityComparer<ShipperItemCompositionDto>
    {
        // Products are equal if their names and product numbers are equal.
        public bool Equals(ShipperItemCompositionDto x, ShipperItemCompositionDto y)
        {

            //Check whether the compared objects reference the same data.
            if (Object.ReferenceEquals(x, y)) return true;

            //Check whether any of the compared objects is null.
            if (Object.ReferenceEquals(x, null) || Object.ReferenceEquals(y, null))
                return false;

            //Check whether the products' properties are equal.
            return x.CompositionGTIN == y.CompositionGTIN && x.CompositionGTIN == y.CompositionGTIN;
        }

        // If Equals() returns true for a pair of objects 
        // then GetHashCode() must return the same value for these objects.

        public int GetHashCode(ShipperItemCompositionDto shipperItemComposition)
        {
            //Check whether the object is null
            if (Object.ReferenceEquals(shipperItemComposition, null)) return 0;

            //Get hash code for the Name field if it is not null.
            int hashProductName = shipperItemComposition.CompositionGTIN == null ? 0 : shipperItemComposition.CompositionGTIN.GetHashCode();

            //Get hash code for the Code field.
            int hashProductCode = shipperItemComposition.CompositionGTIN.GetHashCode();

            //Calculate the hash code for the product.
            return hashProductName ^ hashProductCode;
        }

    }
}
