﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class DsdVendorStoreAuthorizationDto
    {
        public int ItemFormID { get; set; }

        public decimal GTIN { get; set; }

        public int[] VendorNumbers { get; set; }

        public int[] StoreNumbers { get; set; }

        public bool IsAllServicedStores { get; set; }

        public string CreatedBy { get; set; }

        public string LastUpdatedBy { get; set; }
    }
}
