﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class PIDMDataDto
    {
        public BasicItemDefinitionDto BasicItemDefinition { get; set; }
        public IEnumerable<AdditionalGTINDto> AddtionalGtinList { get; set; }
        public PMDSGeneralProductAttributesDto GeneralProductAttributes { get; set; }

    }
}
