﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class DashboardFormStatusDto
    {
        public string FormStatus { get; set; }
        public string FormStatusIDs { get; set; }        
            
    }
}
