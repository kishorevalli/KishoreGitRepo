﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class CreateItemFormDto
    {
         public int ItemFormID { get; set; }

        public string Status { get; set; }

        public string ErrorMessage { get; set; }

        public string LastUpdatedBy { get; set; }

        public DateTime LastUpdatedDate { get; set; }

        public string ParentFlag { get; set; }

    }
}
