﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class FormCommentDto
    {
        public int ID { get; set; }
        public int ItemFormID { get; set; }
        public string Comment { get; set; }
        public int CreatedByUserTypeID { get; set; }
        public bool? ShowVendor { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }
}
