﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class LookupDto
    {
        
        public string Code;
        public string Description;
        public int IsActive { get; set; }
        
    }
}