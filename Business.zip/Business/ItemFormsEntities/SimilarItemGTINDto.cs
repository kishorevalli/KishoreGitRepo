﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class SimilarItemGTINDto
    {
        public int ID { get; set; }
        public int ItemFormID { get; set; }
        public decimal SimilarGTIN { get; set; }
        public string FormattedSimilarGtin
        {
            get
            {
                return SimilarGTIN > 0 ? String.Format("{0:000-00000-00000}", SimilarGTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                SimilarGTIN = result ? GtinDec : Decimal.Zero;
            }
        }
        public int? SimilarGTINCheckDigit { get; set; }
        public int? SimilarGTINNewItemFormID { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        public string SimilarGTINNewItemFormDisplayID { get; set; }
    }
}
