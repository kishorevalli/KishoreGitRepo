﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ReuseItemCodeDto
    {
        public int ItemCode { get; set; }

        public string ItemDescription { get; set; }

        public int SubDeptCode { get; set; }
        
        public int? ItemFormID { get; set; }

        public bool? IsAvailable { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string LastUpdatedBy { get; set; }

        public DateTime LastUpdatedDate { get; set; }

        public ItemValidationDTO ValidationErrors { get; set; }

    }

    public class ReuseItemCodeDtoComparer : IEqualityComparer<ReuseItemCodeDto>
    {

        public bool Equals(ReuseItemCodeDto obj1, ReuseItemCodeDto obj2)
        {
            //Check whether the objects are the same object. 
            if (Object.ReferenceEquals(obj1, obj2)) return true;

            //Check whether the ReuseItemCodeDto' properties are equal. 
            return obj1 != null && obj2 != null && obj1.SubDeptCode.Equals(obj2.SubDeptCode) && obj1.ItemCode.Equals(obj2.ItemCode);
        }

        public int GetHashCode(ReuseItemCodeDto obj)
        {

            //Get hash code for the Code field. 
            int hashSubDeptCode = obj.SubDeptCode.GetHashCode();

             //Get hash code for the Code field. 
            int hashItemCode = obj.ItemCode.GetHashCode();

            //Calculate the hash code for the product. 
            return hashSubDeptCode ^ hashItemCode; ;
        }

    }
}
