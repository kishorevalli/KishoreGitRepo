﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class DsdAuthRequestStoreDto
    {
        public int ID { get; set; }
        public int ItemFormID { get; set; }

        public Int64 ItemFormDisplayID { get; set; }

        public int VendorNumber { get; set; }

        public string VendorName { get; set; }

        public int StoreNumber { get; set; }

        public string StateCode { get; set; }

        public string StateName { get; set; }

        public string CountyCode { get; set; }

        public string CountyName { get; set; }

        public string IsActive { get; set; }

        public bool IsDirty { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string LastUpdatedBy { get; set; }

        public DateTime LastUpdatedDate { get; set; }

    }
}
