﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class FormActionDto
    {
        public int ID;
        public string Name;
        public string BuyerActionName;
        public string VendorActionName;
        public bool IsActive;
        public string CreatedBy;
        public DateTime CreatedDate;
        public string LastUpdatedBy;
        public DateTime LastUpdatedDate;

    }
}