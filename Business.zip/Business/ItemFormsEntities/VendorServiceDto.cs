﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class VendorServiceDto
    {
        public int ItemFormID { get; set; }

        public int? VendorNumber { get; set; }

        public string VendorName { get; set; }

        public decimal? Gtin { get; set; }

        public int? ItemCode { get; set; }

        public int? StoreNumber { get; set; }

        public string StateCode { get; set; }

        public string StateName { get; set; }

        public string CountyCode { get; set; }

        public string CountyName { get; set; }

        public string IsActive { get; set; }

        public bool IsOnlyOverlappedAuth { get; set; }
        
    }

    public class VendorServiceDtoComparer : IEqualityComparer<VendorServiceDto>
    {
        public bool Equals(VendorServiceDto v1, VendorServiceDto v2)
        {
            return v1.StoreNumber == v2.StoreNumber;
        }

        public int GetHashCode(VendorServiceDto v)
        {
            return v.StoreNumber.Value;
        }
    }

}
