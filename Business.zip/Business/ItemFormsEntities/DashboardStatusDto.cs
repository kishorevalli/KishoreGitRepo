﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class DashboardStatusDto
    {
        public int DashboardStatusNameId { get; set; }
        public string Status { get; set; }

        public int? StatusID { get; set; }
        public string StatusComment { get; set; }
        public string StatusImage { get; set; }

        public UserType? UserTypeID { get; set; }
        public bool IncludeVSARelatedForm { get; set; }
        public bool IsIncludeRelatedFromChecked { get; set; }

        public int BuyerID { get; set; }
        public string VendorContactID { get; set; }
        public bool IsVSALoggedIn { get; set; }

        //UserTypeID //UserId
        //
    }
}
