﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ItemFormDto
    {
        public int ID { get; set; }
        public Int64 ItemFormDisplayID { get; set; }

        [Required]
        public int FormTypeID { get; set; }
        public DateTime SubmissionDate { get; set; }
       
        public string SubmittedBy { get; set; }
        public int SubmittedUserTypeID { get; set; }

        public int CreatedByUserTypeID { get; set; }
        public int FormStatusID { get; set; }

        [Required]
        public int FormActionID { get; set; }
       
        public int PendingRoleUserTypeID { get; set; }
        public string DSDAuthRequestSelectStoreOption { get; set; }
        public DateTime ItemCreatedDateTime { get; set; }

        public int? ItemCode { get; set; }
        public string ParentFlag { get; set; }
        public string IsInGroup { get; set; }      
        public DateTime? GroupID { get; set; }
        public int? BuyerID { get; set; }
        public string BuyerName { get; set; }

        public string CreatedBy { get; set; }

        public string VendorContactID { get; set; }
        public string VendorContactName { get; set; }
        public string VendorContactEmail { get; set; }       
            

        public DateTime CreatedDate { get; set; }

        
        public string LastUpdatedBy { get; set; }
        
        public DateTime? LastUpdatedDate { get; set; }

        public DateTime? LastScanDate { get; set; }
        public int? ItemFormErrorCount { get; set; }

        //public BasicItemDefinitionDto BasicItemDefinition{ get; set; }

        // public GeneralProductAttributesDto GeneralProductAttributes { get; set; }

        //   public ProductGroupingDto ProductGrouping { get; set; }
    }
}


