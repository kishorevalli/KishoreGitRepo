﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
   public  class DashboardItemFormDto
    {
        public int ItemFormID { get; set; }

        public string ParentFlag { get; set; }
        public string IsInGroup { get; set; }
        public string GroupID { get; set; }

        public string EligibleForGroupingParenting { get; set; }

        public string SingleGTINItemForm { get; set; }        

        public bool showDetails { get; set; }

        public string ItemFormDisplayID { get; set; }
        public decimal GTIN { get; set; }
        public string FormattedGtin
        {
            get
            {
                return GTIN > 0 ? String.Format("{0:000-00000-00000}", GTIN) : "";
            }
            set
            {
                decimal GtinDec;
                bool result = Decimal.TryParse(value.Replace("-", string.Empty), out GtinDec);
                GTIN = result ? GtinDec : Decimal.Zero;
            }
        }
        public int? GTINCheckDigit { get; set; }
        public string VendorItemCode { get; set; }
        public int? CompressedUPC { get; set; }
        public decimal? PriceLookupCode { get; set; }
        public int? VendorNumber { get; set; }
        public string VendorList { get; set; }        
        public int FormStatusID { get; set; }
        public string VendorItemDescription { get; set; }

        public string BuyerItemDescription { get; set; }
        public string FormStatus { get; set; }
        public string BuyerStatusNameForLinkedForm { get; set; }
        public string BuyerStatusName { get; set; }
        public string VendorStatusName { get; set; }
        public int? FormTypeID { get; set; }
        public string FormType { get; set; }
        public string BuyerProductGroupCode { get; set; }
        public string BuyerProductGroupDescription { get; set; }
        public string RSSProductGroupCode { get; set; }
        public string RSSProductGroupDescription { get; set; }

        public int FormActionID { get; set; }

        public int SelectedFormActionID { get; set; }

        public int WarningCount { get; set; }

        public bool isSelected { get; set; }
        public List<FormUserPermittedActionDto> formActions { get; set; }
        public UserType CreatedByUserTypeID { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }

        public List<DashboardItemFormDto> ChildGTINItemFormList { get; set; }
    }
}
