﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsEntities
{
    public class ProductMandatoryAttributesRequestDto
    {
       // public int ItemFormID { get; set; }
        public int CurrentFamNo { get; set; }
        public int? ItemCode { get; set; }
     //   public int modelGroupCodeType { get; set; }
        public List<ItemGroupType> ItemGroupTypes { get; set; }
    }
}
