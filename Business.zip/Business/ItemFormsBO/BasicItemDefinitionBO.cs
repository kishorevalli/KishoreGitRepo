﻿using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Formatting;
using System.Collections;
using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class BasicItemDefinitionBO : IBasicItemDefinitionBO
    {
        protected readonly IBasicItemDefinitionDac _basicItemDefinitionDac;
        protected readonly IGeneralProductAttributesDac _generalProductAttributesDac;
        protected readonly ICommonBO _commonBo;
        protected readonly IGeneralProductAttributesBO _generalProductAttributesBo;
        protected readonly IPackagingHierarchyBO _packagingHierarchyBo;
        protected readonly IShipperItemCompositionBO _shipperItemCompositionBo;
        protected readonly IDsdAuthorizationRequestBO _dsdAuthorizationRequestBO;
        protected readonly IScaleItemDetailsBO _scaleItemDetailsBo;

        public BasicItemDefinitionBO(ICommonBO commonBo, 
            IBasicItemDefinitionDac basicItemDefinitionDac ,
            IGeneralProductAttributesDac generalProductAttributesDac ,
            IGeneralProductAttributesBO generalProductAttributesBo,
            IPackagingHierarchyBO packagingHierarchyBo,
            IShipperItemCompositionBO shipperItemCompositionBo,
            IDsdAuthorizationRequestBO dsdAuthorizationRequestBO,
            IScaleItemDetailsBO scaleItemDetailsBo)
        {
            this._basicItemDefinitionDac = basicItemDefinitionDac;
            this._generalProductAttributesDac = generalProductAttributesDac;
            this._commonBo = commonBo;
            this._generalProductAttributesBo = generalProductAttributesBo;
            this._packagingHierarchyBo = packagingHierarchyBo;
            this._shipperItemCompositionBo = shipperItemCompositionBo;
            this._dsdAuthorizationRequestBO = dsdAuthorizationRequestBO;
            this._scaleItemDetailsBo = scaleItemDetailsBo;
        }

        public async Task<IEnumerable<LookupDto>> GetSubmissionReasons()
        {
            return await _basicItemDefinitionDac.GetSubmissionReasons();
        }

        public async Task<IEnumerable<LookupDto>> GetItemCaseTypes()
        {
            return await _basicItemDefinitionDac.GetItemCaseTypes();
        }

                      
        public async Task<bool> SaveBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            SetUserID(basicItemDefinitionDto);

            //IEnumerable <PackagingHierarchyDto> packagingHierarchies = await _packagingHierarchyBo.GetPackagingHierarchiesByModelItemCode(basicItemDefinitionDto.ModelPackagingItemCode);
           
            //if ((packagingHierarchies != null) && (packagingHierarchies.ToList().Count > 0))
            //{
            //    foreach (var ph in packagingHierarchies)
            //    {
            //        ph.ItemFormID = basicItemDefinitionDto.ItemFormID;
            //        ph.ID = 0;
            //    }
            //    await _packagingHierarchyBo.SavePackagingHierarchies(packagingHierarchies.ToList(), true);
            //}

            return await _basicItemDefinitionDac.SaveBasicItemDefinition(basicItemDefinitionDto);
        }

        public async Task<IEnumerable<long>> GetItemFormsDisplayIDs(string userId)
        {
            return await _basicItemDefinitionDac.GetItemFormsDisplayIDs(userId);
        }


        public async Task<BasicItemDefinitionDto> GetBasicItemDefinitionData(int itemFormId)
        {
            return await _basicItemDefinitionDac.GetBasicItemDefinitionData(itemFormId);
        }

        public async Task<BasicItemDefinitionDto> GetPmdsBasicItemDefinitionDetailsByItemID(int ItemCode)
        {
            return await _commonBo.GetPIDMDataObject<BasicItemDefinitionDto, PMDSBasicItemDefinitionDto>("api/GetBasicItemDefinitionDetailsByItemID/" + ItemCode);
        }

        public async Task<IEnumerable<LookupDto>> GetRetailPackTypes()
        {
            return await GetPIDMLookup("api/GetRetailPackTypes");

        }

        public async Task<IEnumerable<LookupDto>> GetUnitOfMeasures()
        {
            return await GetPIDMLookup("api/GetUnitOfMeasures");
        }

        public async Task<IEnumerable<ItemTypeDto>> GetItemTypes()
        {
            string resource = "api/GetItemTypes";
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse(resource);            
            IEnumerable<ItemTypeDto> itemTypeDtoList = new List<ItemTypeDto>();
            if (response.IsSuccessStatusCode)
            {
                itemTypeDtoList = await response.Content.ReadAsAsync<IEnumerable<ItemTypeDto>>();
            }
            //Order By 
            itemTypeDtoList = itemTypeDtoList.OrderByDescending(c => c.SubtypeIndicator).ThenBy(c => c.Description);
            return itemTypeDtoList;
        }

        public async Task<IEnumerable<ItemDescriptionDto>> GetItemsMatchingDescription(ItemDescriptionDto itemDescriptionDto)
        {
            string resource = "api/GetItemsMatchingDescription";
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponseViaPost(resource, itemDescriptionDto);
            IEnumerable<ItemDescriptionDto> lookupDtoList = new List<ItemDescriptionDto>();
            if (response.IsSuccessStatusCode)
            {
                lookupDtoList = await response.Content.ReadAsAsync<IEnumerable<ItemDescriptionDto>>();
            }          
            return lookupDtoList;
        }

        public async Task<IEnumerable<ReuseItemCodeDto>> GetAvailableItemFormReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto)
        {
            return await _basicItemDefinitionDac.GetAvailableItemFormReuseItemCodesBySubDept(reuseItemCodeDto);
        }

        public async Task<IEnumerable<ReuseItemCodeDto>> GetReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto)
        {
            List<ReuseItemCodeDto> deleteItemFormReUseItemCodeDtoList = new List<ReuseItemCodeDto>();

            List<ReuseItemCodeDto> insertItemFormReUseItemCodeDtoList = new List<ReuseItemCodeDto>();

            string resource = "api/GetReuseItemCodeListBySubDept/" + reuseItemCodeDto.SubDeptCode + "";
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse(resource);            
            IEnumerable<ReuseItemCodeDto> pmdsReUseItemCodeDtoList = new List<ReuseItemCodeDto>();
            if (response.IsSuccessStatusCode)
            {
                pmdsReUseItemCodeDtoList = response.Content.ReadAsAsync<IEnumerable<ReuseItemCodeDto>>().Result;
            }
            IEnumerable<ReuseItemCodeDto>  itemFormReUseItemCodeDtoList = await _basicItemDefinitionDac.GetItemFormReuseItemCodesBySubDept(reuseItemCodeDto);
            //TODO change to extension
            //var excluedeReuseItemCodes = new HashSet<int>(itemFormReUseItemCodeDtoList.Select(x => x.ItemCode));
            //reUseItemCodeDtoList = reUseItemCodeDtoList.Where(x => !excluedeReuseItemCodes.Contains(x.ItemCode)).ToList();

            //Get the list of Reuse item code which are in Reuse item code table NOT in PMDS 
            foreach (ReuseItemCodeDto itemFormReUseItem in itemFormReUseItemCodeDtoList)
            {
                if(pmdsReUseItemCodeDtoList.Where(x => x.ItemCode == itemFormReUseItem.ItemCode).Count() == 0)
                {
                    deleteItemFormReUseItemCodeDtoList.Add(itemFormReUseItem);
                }
            }

            //Get the list of Reuse item code which are in PMDS and NOT in ItemForm Reuse item code table
            foreach (ReuseItemCodeDto pmdsReUseItemCode in pmdsReUseItemCodeDtoList)
            {
                if (itemFormReUseItemCodeDtoList.Where(x => x.ItemCode == pmdsReUseItemCode.ItemCode).Count() == 0)
                {
                    pmdsReUseItemCode.CreatedBy = reuseItemCodeDto.CreatedBy;
                    insertItemFormReUseItemCodeDtoList.Add(pmdsReUseItemCode);
                }
                
            }

            //Delete ReuseItemCodes in ItemForm Reuse item code table which are UnAvailable in PMDS
            await _basicItemDefinitionDac.DeleteUnAvailableReuseItemCodes(deleteItemFormReUseItemCodeDtoList);
            //Insert missing ReuseItemCodes in ItemForm Reuse item code table which are Available in PMDS
            await _basicItemDefinitionDac.InsertAvailableReuseItemCodes(insertItemFormReUseItemCodeDtoList);

            if(deleteItemFormReUseItemCodeDtoList.Count > 0 || insertItemFormReUseItemCodeDtoList.Count > 0)
            {
                itemFormReUseItemCodeDtoList = await _basicItemDefinitionDac.GetItemFormReuseItemCodesBySubDept(reuseItemCodeDto);
            }

            itemFormReUseItemCodeDtoList = itemFormReUseItemCodeDtoList.Where(x => x.ItemFormID == null).OrderBy(c=>c.ItemCode);

            return itemFormReUseItemCodeDtoList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reuseItemCode"></param>
        /// <returns></returns>
        public async Task<ReuseItemCodeDto> IsReuseItemCodeExist(int reuseItemCode)
        {
            string resource = "api/IsReuseItemCodeExist/" + reuseItemCode + "";
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse(resource);
            ReuseItemCodeDto reUseItemCodeDto = null;
            if (response.IsSuccessStatusCode)
            {
                reUseItemCodeDto = response.Content.ReadAsAsync<ReuseItemCodeDto>().Result;
            }          

            return reUseItemCodeDto;
        }


        public async Task<IEnumerable<LookupDto>> GetReuseItemSubDepartments()
        {
            return await _basicItemDefinitionDac.GetReuseItemSubDepartments();
           
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reuseItemCodeDto"></param>
        /// <returns></returns>
        public async Task<ReuseItemCodeDto> IsSelectedReuseItemCodeAlreadyUsed(ReuseItemCodeDto reuseItemCodeDto)
        {
            return await _basicItemDefinitionDac.IsSelectedReuseItemCodeAlreadyUsed(reuseItemCodeDto);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reuseItemCodeDto"></param>
        /// <returns></returns>
        public async Task<bool> SaveReuseItemCode(ReuseItemCodeDto reuseItemCodeDto)
        {
            return await _basicItemDefinitionDac.SaveReuseItemCode(reuseItemCodeDto);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="itemFormID"></param>
        /// <returns></returns>
        public async Task<bool> DeleteModelProductItemValues(int itemFormID)
        {
            return await _basicItemDefinitionDac.DeleteModelProductItemValues(itemFormID);
        }

        public async Task<IEnumerable<LookupDto>> GetPIDMLookup(string Resource)
        {
            //System.Net.Http.HttpResponseMessage response =  GetHttpResponseMessage(Resource);
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse(Resource);
            
            IEnumerable<LookupDto> lookUps = new List<LookupDto>();
            if (response.IsSuccessStatusCode)
            {
                lookUps = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
            }
            return lookUps;
        }


       



        public async Task<IEnumerable<LookupDto>> GetCaseCodeTypes()
        {
            return await GetPIDMLookup("api/GetCaseCodeTypes");
        }


        public async Task<IEnumerable<LookupDto>> GetFacilityGroups()
        {
            return await GetPIDMLookup("api/GetFacilityGroups");
        }


        public async Task<IEnumerable<LookupDto>> GetScaleActionCodes()
        {
            return await GetPIDMLookup("api/GetScaleActionCodes");
        }


        public async Task<IEnumerable<LookupDto>> GetAttributeCodes()
        {
            return await GetPIDMLookup("api/GetAttributeCodes");
        }



        public async Task<IEnumerable<LookupDto>> GetItemAttributeGroups()
        {
            return await GetPIDMLookup("api/GetItemAttributeGroups");
        }

        public async Task<long> ConvertCompressedUPCToGTIN(int compressedUPC)
        {
            int[] upcArray = new int[6];
            string Gtin = "0";
            
            if (Math.Floor(Math.Log10(compressedUPC) + 1) != 6)
                throw new Exception("Invalid Compressed UPC");
            else
            {   //put the digits in the array.
                for (int i = 5; i >= 0; i--)
                {
                    upcArray[i] = compressedUPC % 10;
                    compressedUPC /= 10;
                }

                var upcPositionSix = upcArray[5];

                if (upcPositionSix < 3)
                {
                    Gtin = "0" + upcArray[0].ToString() + upcArray[1].ToString() + upcArray[5].ToString() + "0000" + upcArray[2].ToString() + upcArray[3].ToString() + upcArray[4].ToString();
                    Gtin = Gtin.PadLeft(13, '0');
                }
                else if (upcPositionSix == 3)
                {
                    Gtin = "0" + upcArray[0].ToString() + upcArray[1].ToString() + upcArray[2].ToString() + "00000" + upcArray[3].ToString() + upcArray[4].ToString();
                    Gtin = Gtin.PadLeft(13, '0');
                }
                else if (upcPositionSix == 4)
                {
                    Gtin = "0" + upcArray[0].ToString() + upcArray[1].ToString() + upcArray[2].ToString() + upcArray[3].ToString() + "00000" + upcArray[4].ToString();
                    Gtin = Gtin.PadLeft(13, '0');
                }
                else if (upcPositionSix > 4)
                {
                    Gtin = "0" + upcArray[0].ToString() + upcArray[1].ToString() + upcArray[2].ToString() + upcArray[3].ToString() + upcArray[4].ToString() + "0000" + upcArray[5].ToString();
                    Gtin = Gtin.PadLeft(13, '0');
                }

                return await Task.FromResult(Convert.ToInt64(Gtin));
            }
        }


        public async Task<long> ConvertPLUToGTIN(int priceLookUp)
        {
            return await Task.FromResult(Convert.ToInt64(priceLookUp.ToString().PadLeft(12, '0')));
        }


        
        public async Task<ItemValidationDTO> ValidateBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            ItemValidationDTO bidValidationDTO = new ItemValidationDTO();

            //TODO : put all the tab names into some common file as consts. 
            bidValidationDTO.TabName = "Basic Item Definition";

            List<ErrorDTO> errorList = new List<ErrorDTO>();
            List<WarningDTO> warningsList = new List<WarningDTO>();

            // GTIN and GTIN Check  Digit validations.
            //var errorGTIN = await ValidateGTIN(basicItemDefinitionDto.GTIN, basicItemDefinitionDto.FormattedGtin , basicItemDefinitionDto.GTINCheckDigit,basicItemDefinitionDto.SubmittedUserTypeID);

            var errorGTIN = await ValidateGTIN(basicItemDefinitionDto);
            if (errorGTIN != null)
                AddErrorOrWarningToList(errorGTIN, errorList, warningsList, basicItemDefinitionDto.FormActionID);

            await ValidateDescriptions(basicItemDefinitionDto, errorList, warningsList);

            //SubmissionReasonID mandatory
            if ((basicItemDefinitionDto.SubmissionReasonID == 0) || (basicItemDefinitionDto.SubmissionReasonID == null))
            {
                AddErrorOrWarningToList(await GetErrorMessage("BID28"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
            }

            //ItemCaseTypeID is mandatory
            if ((basicItemDefinitionDto.ItemCaseTypeID == 0) || (basicItemDefinitionDto.ItemCaseTypeID == null))
            {
                AddErrorOrWarningToList(await GetErrorMessage("BID29"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
            }

            //Mandatory Fields by Family Grp. TODO: needs to be changed and use the new service for the mandatory attributes.
            //if ((basicItemDefinitionDto.ItemFormID != 0))
            //{
            //    List<ErrorDTO> mandatoryFieldsErrors = await ValidateFamilyGroupMandatoryFields(basicItemDefinitionDto, "2");  //TODO: remove the hardcoded family grp.
            //    if (mandatoryFieldsErrors != null)
            //    {
            //        foreach (var error in mandatoryFieldsErrors)
            //        {
            //            AddErrorOrWarningToList(error, errorList, warningsList, basicItemDefinitionDto.FormActionID);
            //        }
            //    }
            //}

            bidValidationDTO.Errors = errorList;
            bidValidationDTO.Warnings = warningsList;

            return bidValidationDTO;
        }

        private async Task ValidateDescriptions(BasicItemDefinitionDto basicItemDefinitionDto, List<ErrorDTO> errorList, List<WarningDTO> warningsList)
        {
            //Vendor Item Description
            if ((basicItemDefinitionDto.VendorItemDescription != "") && (basicItemDefinitionDto.VendorItemDescription != null))
            {
                if (basicItemDefinitionDto.VendorItemDescription.Contains(':') || basicItemDefinitionDto.VendorItemDescription.Contains(',') || basicItemDefinitionDto.VendorItemDescription.Contains('~') || basicItemDefinitionDto.VendorItemDescription.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID05"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }
            }

            //Package Description
            if ((basicItemDefinitionDto.PackageDescription != "") && (basicItemDefinitionDto.PackageDescription != null))
            {
                if (basicItemDefinitionDto.PackageDescription.Contains(':') || basicItemDefinitionDto.PackageDescription.Contains(',') || basicItemDefinitionDto.PackageDescription.Contains('~') || basicItemDefinitionDto.PackageDescription.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID06"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }
            }

            //Receipt Description 
            if ((basicItemDefinitionDto.ReceiptDescription != "") && (basicItemDefinitionDto.ReceiptDescription != null))
            {
                if (basicItemDefinitionDto.ReceiptDescription.Contains(':') || basicItemDefinitionDto.ReceiptDescription.Contains(',') || basicItemDefinitionDto.ReceiptDescription.Contains('~') || basicItemDefinitionDto.ReceiptDescription.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID30"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }
            }

            //ScaleDescription1  
            if ((basicItemDefinitionDto.ScaleDescription1 != "") && (basicItemDefinitionDto.ScaleDescription1 != null))
            {
                if (basicItemDefinitionDto.ScaleDescription1.Contains(':') || basicItemDefinitionDto.ScaleDescription1.Contains(',') || basicItemDefinitionDto.ScaleDescription1.Contains('~') || basicItemDefinitionDto.ScaleDescription1.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID31"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }
            }

            //ScaleDescription2  
            if ((basicItemDefinitionDto.ScaleDescription2 != "") && (basicItemDefinitionDto.ScaleDescription2 != null))
            {
                if (basicItemDefinitionDto.ScaleDescription2.Contains(':') || basicItemDefinitionDto.ScaleDescription2.Contains(',') || basicItemDefinitionDto.ScaleDescription2.Contains('~') || basicItemDefinitionDto.ScaleDescription2.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID32"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }
            }

            //AD Description  
            if ((basicItemDefinitionDto.AdDescription != "") && (basicItemDefinitionDto.AdDescription != null))
            {
                if (basicItemDefinitionDto.AdDescription.Contains(':') || basicItemDefinitionDto.AdDescription.Contains(',') || basicItemDefinitionDto.AdDescription.Contains('~') || basicItemDefinitionDto.AdDescription.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID33"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }
            }

            //ProductCatalogShortDescription1  
            if ((basicItemDefinitionDto.ProductCatalogShortDescription1 != "") && (basicItemDefinitionDto.ProductCatalogShortDescription1 != null))
            {
                if (basicItemDefinitionDto.ProductCatalogShortDescription1.Contains(':') || basicItemDefinitionDto.ProductCatalogShortDescription1.Contains(',') || basicItemDefinitionDto.ProductCatalogShortDescription1.Contains('~') || basicItemDefinitionDto.ProductCatalogShortDescription1.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID34"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }
            }

            //ProductCatalogShortDescription2
            if ((basicItemDefinitionDto.ProductCatalogShortDescription2 != "") && (basicItemDefinitionDto.ProductCatalogShortDescription2 != null))
            {
                if (basicItemDefinitionDto.ProductCatalogShortDescription2.Contains(':') || basicItemDefinitionDto.ProductCatalogShortDescription2.Contains(',') || basicItemDefinitionDto.ProductCatalogShortDescription2.Contains('~') || basicItemDefinitionDto.ProductCatalogShortDescription2.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID35"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }

            }


            //Item Description
            if ((basicItemDefinitionDto.ItemDescription != "") && (basicItemDefinitionDto.ItemDescription != null))
            {
                if (basicItemDefinitionDto.ItemDescription.Contains(':') || basicItemDefinitionDto.ItemDescription.Contains(',') || basicItemDefinitionDto.ItemDescription.Contains('~') || basicItemDefinitionDto.ItemDescription.Contains('^'))
                {
                    AddErrorOrWarningToList(await GetErrorMessage("BID36"), errorList, warningsList, basicItemDefinitionDto.FormActionID);
                }
            }
        }

        private void AddErrorOrWarningToList(ErrorDTO errorDTO, List<ErrorDTO> errorList, List<WarningDTO> warningsList , int action)
        {
            
            switch (errorDTO.SeverityLevel)
            {
                
                case "Warning":                    
                    if (action == 5)
                        errorList.Add(errorDTO);
                    else
                    warningsList.Add(Mapper.Map<WarningDTO>(errorDTO));
                    break;
                case "Error":
                    errorList.Add(errorDTO);
                    break;
                default:
                    errorList.Add(errorDTO);
                    break;
            }
        }


        //GTIN and GTIN Check  Digit validations.
        //public async Task<ErrorDTO> ValidateGTIN(decimal GTIN, string formattedGTIN , int? checkDigit, UserType submittedUserType)
        public async Task<ErrorDTO> ValidateGTIN(BasicItemDefinitionDto basicItemDefinition)
        {
            if (basicItemDefinition.AutoGenerateType4GTIN == "Y")
                return null;

            decimal GTIN = basicItemDefinition.GTIN;
            string formattedGTIN = basicItemDefinition.FormattedGtin;
            int? checkDigit = basicItemDefinition.GTINCheckDigit;
            UserType submittedUserType = basicItemDefinition.SubmittedUserTypeID;



            if (GTIN == 0)
            {
                var error = await GetErrorMessage("BID07");
                return error;                
            }
            else
            {
                if (checkDigit == null && basicItemDefinition.PriceLookupCode == null)
                {
                    var error = await GetErrorMessage("BID14");
                    return error;
                }

                if (basicItemDefinition.PriceLookupCode == null && checkDigit != await GenerateCheckDigitFromGTIN(formattedGTIN))
                {
                    var error = await GetErrorMessage("BID14");
                    return error;
                }

                if (submittedUserType == UserType.Vendor && (GTIN >= 0020000000000) && (GTIN <= 0029999999999))
                {
                    var error = await GetErrorMessage("BID09");
                    return error;
                }

                if ((GTIN >= 0040000000000) && (GTIN <= 0049999999999))
                {
                    var error = await GetErrorMessage("BID10");
                    return error;
                }

                if ((GTIN >= 0050000000000) && (GTIN <= 0059999999999))
                {
                    var error = await GetErrorMessage("BID11");
                    return error;
                }

                if (basicItemDefinition.CompressedUPC == null && basicItemDefinition.PriceLookupCode == null)
                {

                    if ((GTIN < 1000000) || (GTIN > 9999999999999))
                    {
                        var error = await GetErrorMessage("BID12");
                        return error;
                    }
                    else if(GTIN > 4141500000 && GTIN < 4141599999)
                    {
                        var error = await GetErrorMessage("BID12");
                        return error;
                    }
                }
                else // compressed UPC and PLU range.
                {
                    if (basicItemDefinition.CompressedUPC != null)
                    {

                        if ((basicItemDefinition.CompressedUPC < 100000) || (basicItemDefinition.CompressedUPC > 999999))
                        {
                            var error = await GetErrorMessage("BID26");
                            return error;
                        }                   
                     
                    }

                    if (basicItemDefinition.PriceLookupCode != null)
                    {

                        if ((basicItemDefinition.PriceLookupCode < 10000) || (basicItemDefinition.PriceLookupCode > 99999))
                        {
                            var error = await GetErrorMessage("BID27");
                            return error;
                        }
                    }
                }

                if (await _basicItemDefinitionDac.IsGTINExistsInPackagingHierarchy(GTIN))
                {
                    var error = await GetErrorMessage("BID13");
                    return error;
                }

            }
            return null;
        }

        //If GTIN is used instead of formatted GTIN , preceding 0's will be truncated and will give wrong checkdigit.
        //To preserve preceding 0's (ex: 0000088888888) , string formatedGTIN is used instead of GTIN(decimal).
        public async Task<int> GenerateCheckDigitFromGTIN(string formatedGTIN)
        {
            //Ex: formatedGTIN = 036 - 00024 - 14500
            string gtin = formatedGTIN.Replace("-" , "");
            char[] gtinArray = gtin.ToCharArray();
            //1.	Add the odd number digits: 0+6+0+2+1+5 = 14.
            var oddDigitSum = Convert.ToInt16(Char.GetNumericValue(gtinArray[0])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[2])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[4])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[6])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[8])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[10])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[12]));
            //2.Multiply the result by 3: 14 × 3 = 42.
            var oddDigitMultiply = oddDigitSum * 3;
            //3.Add the even number digits: 3 + 0 + 0 + 4 + 4 = 11.
            var evenDigitSum = Convert.ToInt16(Char.GetNumericValue(gtinArray[1])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[3])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[5])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[7])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[9])) + Convert.ToInt16(Char.GetNumericValue(gtinArray[11]));
            //4.Add the two results together: 42 + 11 = 53.
            var totalSum = oddDigitMultiply + evenDigitSum;
            var modValue = totalSum % 10;
            var checkdigit = modValue == 0 ? 0 : 10 - modValue;

            return await Task.FromResult(checkdigit);
        }

        
      
        public async Task<BasicItemDefinitionDto> SaveItemDataByPmdsGTIN(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            if (basicItemDefinitionDto.GTIN != 0)
            {
                await SaveModelDataForPackagingHierarchyByGtin(basicItemDefinitionDto);
            }

            PIDMDataDto pidmItemData  = await GetPMDSDataByGTIN(basicItemDefinitionDto);

            if (pidmItemData!=null && pidmItemData.BasicItemDefinition != null)
            {
                BasicItemDefinitionDto pidmBasicItemDefinitionDto = pidmItemData.BasicItemDefinition;
                pidmBasicItemDefinitionDto.ItemFormID = basicItemDefinitionDto.ItemFormID;
                pidmBasicItemDefinitionDto.ItemFormDisplayId = basicItemDefinitionDto.ItemFormDisplayId;

                pidmBasicItemDefinitionDto.FormTypeID = basicItemDefinitionDto.FormTypeID;
                pidmBasicItemDefinitionDto.FormStatusID = basicItemDefinitionDto.FormStatusID;
                pidmBasicItemDefinitionDto.FormActionID = basicItemDefinitionDto.FormActionID;
                pidmBasicItemDefinitionDto.SubmittedUserTypeID = basicItemDefinitionDto.SubmittedUserTypeID;

                pidmBasicItemDefinitionDto.CreatedBy = basicItemDefinitionDto.CreatedBy;
                pidmBasicItemDefinitionDto.LastUpdatedBy = basicItemDefinitionDto.LastUpdatedBy;

                pidmBasicItemDefinitionDto.ItemFormDisplayId = basicItemDefinitionDto.ItemFormDisplayId;
                pidmBasicItemDefinitionDto.ItemFormID = basicItemDefinitionDto.ItemFormID;
                pidmBasicItemDefinitionDto.LastUpdatedBy = basicItemDefinitionDto.LastUpdatedBy;
                pidmBasicItemDefinitionDto.ItemTypeCode = basicItemDefinitionDto.ItemTypeCode;
                pidmBasicItemDefinitionDto.ItemTypeDescription = basicItemDefinitionDto.ItemTypeDescription;
                pidmBasicItemDefinitionDto.AutoGenerateType4GTIN = basicItemDefinitionDto.AutoGenerateType4GTIN;
                pidmBasicItemDefinitionDto.RecipeRequired = basicItemDefinitionDto.RecipeRequired;
                pidmBasicItemDefinitionDto.IngredientItemRequired = basicItemDefinitionDto.IngredientItemRequired;


                pidmBasicItemDefinitionDto.GTIN = basicItemDefinitionDto.GTIN;
                pidmBasicItemDefinitionDto.GTINCheckDigit = basicItemDefinitionDto.GTINCheckDigit;
                pidmBasicItemDefinitionDto.ExistingGtinIndicator = basicItemDefinitionDto.ExistingGtinIndicator;
                pidmBasicItemDefinitionDto.CompressedUPC = basicItemDefinitionDto.CompressedUPC;
                pidmBasicItemDefinitionDto.PriceLookupCode = basicItemDefinitionDto.PriceLookupCode;
                pidmBasicItemDefinitionDto.ReuseItemCode = basicItemDefinitionDto.ReuseItemCode;

                pidmBasicItemDefinitionDto.ModelProductItemCode = null;

                if (pidmItemData.AddtionalGtinList != null)
                    pidmBasicItemDefinitionDto.AddtionalGtinList = pidmItemData.AddtionalGtinList.ToList();

                SetUserID(basicItemDefinitionDto);
                

                bool retValue = await _basicItemDefinitionDac.SaveBasicItemDefinition(pidmBasicItemDefinitionDto);
                                 //GPA 
                if (pidmItemData.GeneralProductAttributes != null)
                {
                    GeneralProductAttributesDto modelGPADto = PopulateDataFromModelGPA(basicItemDefinitionDto, pidmItemData);
                    modelGPADto.IsDirty = true;
                    await _generalProductAttributesBo.SaveGeneralProductAttributes(modelGPADto);
                }

                //Packaging Hierarchy           
                //if (pidmItemData.PackagingHierarchy != null)
                //{                  
                //    //check if this PMDS item is created through item forms 
                //    var isItemFormsItem = await _basicItemDefinitionDac.CheckIfItemCreatedByItemForms(pidmItemData.ItemCode);

                //    //if the item is created by item forms, model the packaging hierarchy.
                //    if (isItemFormsItem)
                //    {
                //        PackagingHierarchyDto modelPackagingHierarchyDto = PopulateDataFromModelPackagingHierarchy(basicItemDefinitionDto, pidmItemData);
                //        modelPackagingHierarchyDto.IsDirty = true;
                //        //await _packagingHierarchyBo.SavePackagingHierarchy(modelPackagingHierarchyDto);                        
                //    }
                //}

                // For Packaging Hierarchies , we pull the packaging hiearchy data from the item forms database and not from PMDS.
                //var isItemFormsItem = await _basicItemDefinitionDac.CheckIfItemCreatedByItemForms(pidmItemData.ItemCode);
                //if (isItemFormsItem)
                //{
                //    List<PackagingHierarchyDto> packagingHierarchies = _packagingHierarchyBo.GetPackagingHierarchiesByModelGTIN(basicItemDefinitionDto.GTIN).Result.ToList();
                //    if ((packagingHierarchies != null) && (packagingHierarchies.Count > 0))
                //    {
                //        await _packagingHierarchyBo.SavePackagingHierarchies(packagingHierarchies, true);
                //    }
                //}

               

                //Shipper Item Composition
                if (pidmItemData.ShipperItemCompositionList != null)
                {
                    List<ShipperItemCompositionDto> ShipperItemCompositionList = PopulateDataFromModelShipperItemComposition(basicItemDefinitionDto, pidmItemData);
                    //ShipperItemCompositionList.IsDirty = true;

                    await _shipperItemCompositionBo.SaveAllShipperItemCompositionList(ShipperItemCompositionList, basicItemDefinitionDto.ItemFormID);
                }
                //DSD Vendor Authrorization 
               
                await _dsdAuthorizationRequestBO.ProcessDsdVendorStoreAuthorizationByGtin(basicItemDefinitionDto);

                if(pidmItemData.ScaleItemDetails != null)
                {
                    await _scaleItemDetailsBo.SaveScaleItemDetails(basicItemDefinitionDto, pidmItemData);
                }

                //TODO : other tabs data    
                basicItemDefinitionDto = await _basicItemDefinitionDac.GetBasicItemDefinitionData(pidmBasicItemDefinitionDto.ItemFormID);
               
                return basicItemDefinitionDto;
            }
            else
                return null;                       
        }

 
        public async Task<Boolean> isGTINExistInPMDS(Decimal gtin)
        {
            BasicItemDefinitionDto basicItemDefinitionDto = new BasicItemDefinitionDto();
            basicItemDefinitionDto.GTIN = gtin;
            //PIDMDataDto gtindata = GetPMDSDataByGTIN(basicItemDefinitionDto).Result;
            
            //if (gtindata == null)
            //    return  false;
            //else
            //    return true;
            return true;
        }


        private async Task<PIDMDataDto> GetPMDSDataByGTIN(BasicItemDefinitionDto basicItemDefinitionDto)
        {

            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetPIDMDataByGTIN/" + basicItemDefinitionDto.GTIN);
            PIDMDataDto pidmItemData = new PIDMDataDto();
            try
            {

            

            if (response.IsSuccessStatusCode)
            {
                pidmItemData = response.Content.ReadAsAsync<PIDMDataDto>().Result;
                if (pidmItemData.BasicItemDefinition == null)
                { return null; }
                
            }

            }
            catch (Exception e )
            {

                throw;
            }



            return pidmItemData;
        }

        public async Task<bool> SaveItemDataByPmdsItemCode(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData)
        {
            bool retValue = false;
            if (pidmItemData != null)
            {
                if(pidmItemData.BasicItemDefinition != null)
                {
                    BasicItemDefinitionDto pidmBasicItemDefinitionDto = pidmItemData.BasicItemDefinition;

                    pidmBasicItemDefinitionDto.ItemFormDisplayId = basicItemDefinitionDto.ItemFormDisplayId;
                    pidmBasicItemDefinitionDto.ItemFormID = basicItemDefinitionDto.ItemFormID;

                    pidmBasicItemDefinitionDto.FormTypeID = basicItemDefinitionDto.FormTypeID;
                    pidmBasicItemDefinitionDto.FormStatusID = basicItemDefinitionDto.FormStatusID;
                    pidmBasicItemDefinitionDto.FormActionID = basicItemDefinitionDto.FormActionID;
                    pidmBasicItemDefinitionDto.SubmittedUserTypeID = basicItemDefinitionDto.SubmittedUserTypeID;

                    pidmBasicItemDefinitionDto.CreatedBy = basicItemDefinitionDto.CreatedBy;
                    pidmBasicItemDefinitionDto.LastUpdatedBy = basicItemDefinitionDto.LastUpdatedBy;

                    pidmBasicItemDefinitionDto.ItemTypeCode = basicItemDefinitionDto.ItemTypeCode;
                    pidmBasicItemDefinitionDto.AutoGenerateType4GTIN = basicItemDefinitionDto.AutoGenerateType4GTIN;
                    pidmBasicItemDefinitionDto.GTIN = basicItemDefinitionDto.GTIN;
                    pidmBasicItemDefinitionDto.GTINCheckDigit = basicItemDefinitionDto.GTINCheckDigit;
                    pidmBasicItemDefinitionDto.ExistingGtinIndicator = basicItemDefinitionDto.ExistingGtinIndicator;
                    pidmBasicItemDefinitionDto.CompressedUPC = basicItemDefinitionDto.CompressedUPC;
                    pidmBasicItemDefinitionDto.PriceLookupCode = basicItemDefinitionDto.PriceLookupCode;
                    pidmBasicItemDefinitionDto.ReuseItemCode = basicItemDefinitionDto.ReuseItemCode;
                    pidmBasicItemDefinitionDto.SubmissionReasonID = basicItemDefinitionDto.SubmissionReasonID;
                    pidmBasicItemDefinitionDto.ItemCaseTypeID = basicItemDefinitionDto.ItemCaseTypeID;
                    pidmBasicItemDefinitionDto.RecipeRequired = basicItemDefinitionDto.RecipeRequired;
                    pidmBasicItemDefinitionDto.IngredientItemRequired = basicItemDefinitionDto.IngredientItemRequired;
                    pidmBasicItemDefinitionDto.ModelProductItemCode = basicItemDefinitionDto.ModelProductItemCode;

                    pidmBasicItemDefinitionDto.ModelProductItemDescription = pidmBasicItemDefinitionDto.ItemDescription;


                    ModelProductItemValueDto modelProductItemValueDto = new ModelProductItemValueDto();

                    modelProductItemValueDto.ItemFormID = basicItemDefinitionDto.ItemFormID;
                    modelProductItemValueDto.AdDescription = pidmBasicItemDefinitionDto.AdDescription;
                    modelProductItemValueDto.Brand = pidmBasicItemDefinitionDto.Brand;
                    modelProductItemValueDto.ItemDescription = pidmBasicItemDefinitionDto.ItemDescription;
                    modelProductItemValueDto.Manufacturer = pidmBasicItemDefinitionDto.Manufacturer;
                    modelProductItemValueDto.ProductCatalogShortDescription1 = pidmBasicItemDefinitionDto.ProductCatalogShortDescription1;
                    modelProductItemValueDto.ProductCatalogShortDescription2 = pidmBasicItemDefinitionDto.ProductCatalogShortDescription2;
                    modelProductItemValueDto.ReceiptDescription = pidmBasicItemDefinitionDto.ReceiptDescription;
                    modelProductItemValueDto.ScaleDescription1 = pidmBasicItemDefinitionDto.ScaleDescription1;
                    modelProductItemValueDto.ScaleDescription2 = pidmBasicItemDefinitionDto.ScaleDescription2;
                    modelProductItemValueDto.CreatedBy = basicItemDefinitionDto.LastUpdatedBy;
                    modelProductItemValueDto.LastUpdatedBy = basicItemDefinitionDto.LastUpdatedBy;

                    await _basicItemDefinitionDac.SaveModelProductItemValues(modelProductItemValueDto);

                    //These fields should NOT be modeled based on the model item code. 
                    pidmBasicItemDefinitionDto.ItemDescription = "";
                    pidmBasicItemDefinitionDto.ReceiptDescription = "";
                    pidmBasicItemDefinitionDto.AdDescription = "";
                    pidmBasicItemDefinitionDto.ProductCatalogShortDescription1 = "";
                    pidmBasicItemDefinitionDto.ProductCatalogShortDescription2 = "";
                    //pidmBasicItemDefinitionDto.ItemTypeDescription = "";
                    //pidmBasicItemDefinitionDto.ModelProductItemDescription = "";
                    //pidmBasicItemDefinitionDto.ModelPackagingItemDescription = "";
                    //pidmBasicItemDefinitionDto.ReUseItemDescription = "";
                    //pidmBasicItemDefinitionDto.VendorItemDescription = "";

                    pidmBasicItemDefinitionDto.ScaleDescription1 = "";
                    pidmBasicItemDefinitionDto.ScaleDescription2 = "";

                    SetUserID(basicItemDefinitionDto);

                    await _basicItemDefinitionDac.SaveBasicItemDefinition(pidmBasicItemDefinitionDto);

                    //Update ItemForm
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = pidmBasicItemDefinitionDto.ItemFormID;
                    itemForm.FormStatusID = pidmBasicItemDefinitionDto.FormStatusID;
                    itemForm.FormActionID = pidmBasicItemDefinitionDto.FormActionID;
                    itemForm.SubmittedUserTypeID = (int)pidmBasicItemDefinitionDto.SubmittedUserTypeID;
                    itemForm.LastUpdatedBy = pidmBasicItemDefinitionDto.CreatedBy;
                    await _commonBo.UpdateItemForm(itemForm);
                }
                
                  //GPA 
                if (pidmItemData.GeneralProductAttributes != null)
                { 
                    GeneralProductAttributesDto modelGPADto = PopulateDataFromModelGPA(basicItemDefinitionDto, pidmItemData);
                    modelGPADto.IsDirty = true;                               
                    await _generalProductAttributesBo.SaveGeneralProductAttributes(modelGPADto);
                }

                //PackagingHierarchy
                //if (pidmItemData.PackagingHierarchy != null)
                //{
                //    if (pidmItemData.PackagingHierarchy != null)
                //    {
                //        PackagingHierarchyDto modelPackagingHierarchyDto = PopulateDataFromModelPackagingHierarchy(basicItemDefinitionDto, pidmItemData);
                //        modelPackagingHierarchyDto.IsDirty = true;
                //    }
                //}

                //List<PackagingHierarchyDto> packagingHierarchies = _packagingHierarchyBo.GetPackagingHierarchiesByModelItemCode(basicItemDefinitionDto.ModelPackagingItemCode).Result.ToList();
                //if ((packagingHierarchies != null) && (packagingHierarchies.Count > 0))
                //{
                //    await _packagingHierarchyBo.SavePackagingHierarchies(packagingHierarchies, true);
                //}

                //DSD Vendor Authrorization             
                basicItemDefinitionDto.ItemCode = basicItemDefinitionDto.ModelProductItemCode;
                //temp remove dsd call save model item
                //await _dsdAuthorizationRequestBO.ProcessDsdVendorStoreAuthorizationByModelItemCode(basicItemDefinitionDto);
                if (pidmItemData.ScaleItemDetails != null)
                {
                    await _scaleItemDetailsBo.SaveScaleItemDetails(basicItemDefinitionDto, pidmItemData);
                }

                //TODO : other tabs data     
            }

            return retValue;
          
        }

        public async Task<bool> SaveModelDataForPackagingHierarchyByGtin(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            try
            {
                await _packagingHierarchyBo.GetModelDataForPackagingHierarchyByGtin(basicItemDefinitionDto.CreatedBy, basicItemDefinitionDto.GTIN, basicItemDefinitionDto.ItemFormID, basicItemDefinitionDto.SubmittedUserTypeID);
                return true;
            }
            catch (Exception ex)
            { throw; }
        }


        public async Task<bool> SaveModelDataForPackagingHierarchy(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            try
            {
                await _packagingHierarchyBo.GetModelDataForPackagingHierarchy(basicItemDefinitionDto.CreatedBy, basicItemDefinitionDto.ModelPackagingItemCode, basicItemDefinitionDto.ItemFormID , basicItemDefinitionDto.SubmittedUserTypeID);
                return true;
            }
            catch (Exception ex)
            { throw; }
        }

        private static GeneralProductAttributesDto PopulateDataFromModelGPA(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData)
        {
            GeneralProductAttributesDto modelGPADto = new GeneralProductAttributesDto();
            modelGPADto = Mapper.Map<GeneralProductAttributesDto>(pidmItemData.GeneralProductAttributes);            
            modelGPADto.ItemFormID = basicItemDefinitionDto.ItemFormID;
            modelGPADto.FormActionID = basicItemDefinitionDto.FormActionID;
            modelGPADto.FormStatusID = basicItemDefinitionDto.FormStatusID;
            modelGPADto.CreatedBy = basicItemDefinitionDto.CreatedBy;
            return modelGPADto;
        }

        private static List<ShipperItemCompositionDto> PopulateDataFromModelShipperItemComposition(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData)
        {            
            List<ShipperItemCompositionDto> ShipperItemCompositionList = new List<ShipperItemCompositionDto>();

            foreach (var ShipperItemComposition in pidmItemData.ShipperItemCompositionList)
            {
                ShipperItemCompositionDto modelShipperItemCompositionDto = new ShipperItemCompositionDto();
                modelShipperItemCompositionDto = Mapper.Map<ShipperItemCompositionDto>(ShipperItemComposition);
                modelShipperItemCompositionDto.ItemFormID = basicItemDefinitionDto.ItemFormID;                
                modelShipperItemCompositionDto.CreatedBy = basicItemDefinitionDto.CreatedBy;
                ShipperItemCompositionList.Add(modelShipperItemCompositionDto);
            }
            return ShipperItemCompositionList;
        }

        private static PackagingHierarchyDto PopulateDataFromModelPackagingHierarchy(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData)
        {
            PackagingHierarchyDto modelPHDto = new PackagingHierarchyDto();
            modelPHDto = Mapper.Map<PackagingHierarchyDto>(pidmItemData.PackagingHierarchy);
            modelPHDto.ItemFormID = basicItemDefinitionDto.ItemFormID;
            modelPHDto.FormActionID = basicItemDefinitionDto.FormActionID;
            modelPHDto.FormStatusID = basicItemDefinitionDto.FormStatusID;
            modelPHDto.CreatedBy = basicItemDefinitionDto.CreatedBy;
            return modelPHDto;
        }
              
       
        public async Task<PIDMDataDto> GetPMDSDataByItemCode(int itemCode)
        {
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetPIDMDataByItemID/" + itemCode);
            PIDMDataDto pidmItemData = new PIDMDataDto();

            if (response.IsSuccessStatusCode)
            {
                pidmItemData = response.Content.ReadAsAsync<PIDMDataDto>().Result;
                if (pidmItemData.BasicItemDefinition == null)
                { return null; }                              

               
            }
            return pidmItemData;            
        }

        public async Task<PMDSGTINDto> IsGTINExists(decimal GTIN)
        {

            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/IsGTINExist/" + GTIN);
            Boolean isGtinExists = false;
            if (response.IsSuccessStatusCode)
            {
                PMDSGTINDto gtinDetails = response.Content.ReadAsAsync<PMDSGTINDto>().Result;
                isGtinExists = gtinDetails.IsGTINExist;
                return gtinDetails;                
            }

            return null;
        }

        
        public Boolean RemoveItemFormCache(String CacheKey)
        {
            return _basicItemDefinitionDac.RemoveItemFormCache(CacheKey);
        }

       
        public async Task<ErrorDTO> GetErrorMessage(string ErrorCode)
        {
            IEnumerable<ErrorDTO> Errors = await _basicItemDefinitionDac.GetErrorMessages();
            return Errors.FirstOrDefault(e => e.ErrorCode == ErrorCode);
        }

        public async Task<List<ErrorDTO>> ValidateFamilyGroupMandatoryFields(BasicItemDefinitionDto BIDDto, string familyGroupID)
        {

            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetFamilyGroupMandatoryFields/" + familyGroupID + "");
            IEnumerable<FamilyGroupMandatoryField> FGMandatoryField = new List<FamilyGroupMandatoryField>();
            List<ErrorDTO> MandatoryFieldErrors = new List<ErrorDTO>();
            if (response.IsSuccessStatusCode)
            {
                FGMandatoryField = response.Content.ReadAsAsync<IEnumerable<FamilyGroupMandatoryField>>().Result;
                foreach (var field in FGMandatoryField)
                {
                    switch (field.FieldName)
                    {
                        case "Brand":
                            if (string.IsNullOrEmpty(BIDDto.Brand))
                                MandatoryFieldErrors.Add(await GetErrorMessage("BID01"));
                            break;
                        case "Manufacturer":
                            if (string.IsNullOrEmpty(BIDDto.Manufacturer))
                                MandatoryFieldErrors.Add(await GetErrorMessage("BID02"));
                            break;
                        case "Minority Manufacturer":
                            if (string.IsNullOrEmpty(BIDDto.MinorityManufacturer))
                                MandatoryFieldErrors.Add(await GetErrorMessage("BID03"));
                            break;
                        case "Container Type":
                            if (string.IsNullOrEmpty(BIDDto.PackageDescription))
                                MandatoryFieldErrors.Add(await GetErrorMessage("BID04"));
                            break;
                    }
                }

            }
            return MandatoryFieldErrors;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="itemFormID"></param>
        /// <returns></returns>
        public async Task<ModelProductItemValueDto> GetModelProductItemValues(int itemFormID)
        {
            return await _basicItemDefinitionDac.GetModelProductItemValues(itemFormID);
        }

        public async Task<List<ErrorDTO>> ValidateAndSaveModelItemCodeData(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            List<ErrorDTO> errorList = new List<ErrorDTO>();

            PIDMDataDto pidmItemData = await GetPMDSDataByItemCode(Convert.ToInt32(basicItemDefinitionDto.ModelProductItemCode));            

            if (pidmItemData != null && pidmItemData.BasicItemDefinition != null)
            {
                //Validate the model Item code is same Case type
                if((pidmItemData.BasicItemDefinition.ShipperFlag == "N"? 1: 2) != basicItemDefinitionDto.ItemCaseTypeID)
                {
                    var error = await GetErrorMessage("BID16");
                    errorList.Add(error);
                }

                // Check the item type is retail or non retail
                // If retail apply the RETAIL_PACK_TYPE_CODE='R' and ItemType to fetch on the regular pack
                // If non retail just return the BID retrived after apply the item type filter

                if(basicItemDefinitionDto.SubmittedUserTypeID == UserType.Buyer && pidmItemData.BasicItemDefinition.ItemTypeCode != null && pidmItemData.BasicItemDefinition.ItemTypeCode != basicItemDefinitionDto.ItemTypeCode)
                {
                    var error = await GetErrorMessage("BID46");
                    errorList.Add(error);
                }

                if (basicItemDefinitionDto.SubmittedUserTypeID == UserType.Buyer && (pidmItemData.BasicItemDefinition.ItemTypeCode == "FG" || pidmItemData.BasicItemDefinition.ItemTypeCode == "RI") && pidmItemData.BasicItemDefinition.RetailPackType != "R")
                {
                    var error = await GetErrorMessage("BID47");
                    errorList.Add(error);
                }

                //Validate the model Item code is not fall in to the item types RS, RM and WIP
                if (basicItemDefinitionDto.SubmittedUserTypeID == UserType.Vendor && (pidmItemData.BasicItemDefinition.ItemTypeCode == "RS" || 
                    pidmItemData.BasicItemDefinition.ItemTypeCode == "RM" || pidmItemData.BasicItemDefinition.ItemTypeCode == "WIP"))
                {
                    var error = await GetErrorMessage("BID17");
                    errorList.Add(error);
                }

                if(errorList.Count == 0)
                {
                    //No Errors. Save the BID data
                    await SaveItemDataByPmdsItemCode(basicItemDefinitionDto, pidmItemData);

                }
                
            }
            else
            {
                //No Record Found
                var error = await GetErrorMessage("BID15");
                errorList.Add(error);
            }               
           
            return errorList;
        }

        //public async Task<IEnumerable<GTINWithCheckdigitDto>> GetBasicItemDefinitionGTIN(int itemFormID)
        //{
        //    return await _basicItemDefinitionDac.GetBasicItemDefinitionGTIN(itemFormID);
        //}
        public async Task<IEnumerable<GTINWithCheckdigitDto>> GetNutritionalPanelGTIN(int itemFormID)
        {
            return await _basicItemDefinitionDac.GetNutritionalPanelGTIN(itemFormID);
        }
        public async Task<bool> RemoveGTINRetailPackRelatedInfo(GTINRetailPackInfoDto gtinRetailPackInfo)
        {
            try
            {
                await _packagingHierarchyBo.DeletePackagingHierarchies(gtinRetailPackInfo);
                await _dsdAuthorizationRequestBO.DeleteDsdVendorsNotInPackagingHierarchy(gtinRetailPackInfo.ItemFormID);
                await _basicItemDefinitionDac.RemoveGTINRetailPackRelatedInfo(gtinRetailPackInfo);
            }
            catch 
            {
                throw;
            }

            return true;

        }

        public async Task<IEnumerable<PackagingHierarchyDto>> GetExistingPackagingHierarchies(int itemFormID)
        {
            return await _packagingHierarchyBo.GetExistingPackagingHierarchies(itemFormID);
        }

        private void SetUserID(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            string userName = string.IsNullOrEmpty(basicItemDefinitionDto.CreatedBy) == true ? "IFWUser" : basicItemDefinitionDto.CreatedBy;

            basicItemDefinitionDto.CreatedBy = userName;
            basicItemDefinitionDto.LastUpdatedBy = userName;

            if (basicItemDefinitionDto.AddtionalGtinList != null && basicItemDefinitionDto.AddtionalGtinList.Count > 0)
            {
                foreach (var additionalGtin in basicItemDefinitionDto.AddtionalGtinList)
                {
                    additionalGtin.CreatedBy = userName;
                    additionalGtin.LastUpdatedBy = userName;
                }
            }
        }
    }

}
