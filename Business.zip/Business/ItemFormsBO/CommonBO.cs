﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System.Net.Http;
using System.Net.Http.Headers;
using Publix.S0VPITEM.ItemFormsEntities;
using System.Text.RegularExpressions;
using System.Configuration;
using Publix.S0VPITEM.ItemFormsBO.VendorPortalAdminSvc;
using System.Runtime.Caching;
using Publix.S0VPITEM.ItemFormsCommon;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using AutoMapper;
using Publix.S0VPITEM.ItemFormsBO.ItemFormSvc;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class CommonBO : ICommonBO
    {
        protected readonly ICommonDac _commonDac;
        //protected readonly IBasicItemDefinitionBO _basicItemDefinitionBo;
        //protected readonly IGeneralProductAttributesBO _generalProductAttributesBo;
        private static readonly HttpClient _httpClient;

        public CommonBO(ICommonDac commonDac)
            //IBasicItemDefinitionBO basicItemDefinitionBo,
            //IGeneralProductAttributesBO generalProductAttributesBo)
        {
            //this._basicItemDefinitionBo = basicItemDefinitionBo;
            //this._generalProductAttributesBo = generalProductAttributesBo;
            this._commonDac = commonDac;       
        }

        static CommonBO()
        {
            var baseUrl = ConfigurationManager.AppSettings[Environment.GetEnvironmentVariable("PublixEnvironment") + "-PMDSURL"];
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(30); //TODO: set timeout from webconfig.
            _httpClient.BaseAddress = new Uri(baseUrl);           
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<IEnumerable<LookupDto>> GetPIDMLookup(string Resource)
        {
            //System.Net.Http.HttpResponseMessage response =  GetHttpResponseMessage(Resource);
            HttpResponseMessage response = await GetHttpResponse(Resource);         
            IEnumerable<LookupDto> lookUps = new List<LookupDto>();
            if (response.IsSuccessStatusCode)
            {
                lookUps = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
            }
            return lookUps;
        }
        public async Task<IEnumerable<T>> GetPIDMData<T, P>(string Resource)
        {
            HttpResponseMessage response = await GetHttpResponse(Resource);
            IEnumerable<P> PIDMDataList = new List<P>();
            if (response.IsSuccessStatusCode)
            {
                PIDMDataList = response.Content.ReadAsAsync<IEnumerable<P>>().Result;
            }
            return Mapper.Map<IEnumerable<T>>(PIDMDataList);
        }
        public async Task<IEnumerable<T>> GetPIDMDataByPost<T, P>(string Resource, dynamic data)
        {
            HttpResponseMessage response = await GetHttpResponseViaPost(Resource, data);
            IEnumerable<P> PIDMDataList = new List<P>();
            if (response.IsSuccessStatusCode)
            {
                PIDMDataList = response.Content.ReadAsAsync<IEnumerable<P>>().Result;
            }
            return Mapper.Map<IEnumerable<T>>(PIDMDataList);
        }
        public async Task<T> GetPIDMDataObject<T, P>(string Resource)
        {
            HttpResponseMessage response = await GetHttpResponse(Resource);
            P PIDMData = default(P);
            if (response.IsSuccessStatusCode)
            {
                PIDMData = response.Content.ReadAsAsync<P>().Result;
            }
            return Mapper.Map<T>(PIDMData);
        }
        public async Task<T> GetPIDMDataObjectByPost<T, P>(string Resource, dynamic data)
        {
            HttpResponseMessage response = await GetHttpResponseViaPost(Resource, data);
            P PIDMData = default(P);
            if (response.IsSuccessStatusCode)
            {
                PIDMData = response.Content.ReadAsAsync<P>().Result;
            }
            return Mapper.Map<T>(PIDMData);
        }
        public async Task<HttpResponseMessage> GetHttpResponse(string resource)
        {           
            System.Net.Http.HttpResponseMessage response = await _httpClient.GetAsync(resource);
            await response.EnsureSuccessStatusCodeAsync();
            return response;
        }
               
        public async Task<HttpResponseMessage> GetHttpResponseViaPost<T>(string resource, T request)
        {
            System.Net.Http.HttpResponseMessage response = await _httpClient.PostAsJsonAsync(resource, request);
            await response.EnsureSuccessStatusCodeAsync();
            return response;
        }                      

        public async Task<bool> DeleteItemForm(ItemFormDto itemFormDto)
        {
            return await _commonDac.DeleteItemForm(itemFormDto);
        }


        public async Task<ItemFormDto> SaveItemForm(ItemFormDto itemFormDto)
        {
            if(!string.IsNullOrEmpty(itemFormDto.VendorContactID))
            itemFormDto.VendorContactEmail =  DashboardBO.GetEmailIDForVendor(itemFormDto.VendorContactID);

            return await _commonDac.SaveItemForm(itemFormDto);
        }

        public async Task<ItemFormDto> GetItemFormData(long itemFormDisplayId)
        {
            return await _commonDac.GetItemFormData(itemFormDisplayId);
        }

        public async Task<ItemFormDto> GetItemFormDataById(int itemFormId)
        {
            return await _commonDac.GetItemFormDataById(itemFormId);
        }

        public async Task UpdateItemForm(ItemFormDto itemForm)
        { 
            await _commonDac.UpdateItemForm(itemForm);

        }
        
        public async Task UpdateItemCodeForItemForm(ItemFormDto itemForm)
        {
            await _commonDac.UpdateItemCodeForItemForm(itemForm);

        }

        public async Task SubmitItemFormsForCreation(int itemFormId, string createdBy)
        {
            var groupedChildFormIds = await _commonDac.GetChildForms(itemFormId);
            List<CreateItemFormDto> itemFormsForCreation = new List<CreateItemFormDto>();
            if (groupedChildFormIds.Count() > 0)
            {
                foreach (var formId in groupedChildFormIds)
                {
                    CreateItemFormDto ifc = new CreateItemFormDto();
                    ifc.ItemFormID = formId;
                    ifc.Status = "W";
                    ifc.ParentFlag = formId == itemFormId ? "Y" : "N";
                    ifc.LastUpdatedBy = createdBy;
                    itemFormsForCreation.Add(ifc);
                }
            }
            else
            {
                CreateItemFormDto ifc = new CreateItemFormDto();
                ifc.ItemFormID = itemFormId;
                ifc.Status = "W";
                ifc.ParentFlag = "Y";
                ifc.LastUpdatedBy = createdBy;
                itemFormsForCreation.Add(ifc);
            }
            

            await _commonDac.SubmitItemFormsForCreation(itemFormsForCreation);
        }

        //public async Task<IEnumerable<int>> GetChildForms(int itemFormId)
        //{
        //    return await _commonDac.GetChildForms(itemFormId);
        //}


        public bool IsValidEmail(string email)
        {
           
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
                return true;
            else
                return false;
        }

        public async  Task<IEnumerable<ErrorDTO>> GetErrorMessagesByType(ErrorDTO errors)
        {
          return  await _commonDac.GetErrorMessagesByType(errors);
        }

        public string PublixEnvironment
        {
            get
            {
                return Environment.GetEnvironmentVariable("PublixEnvironment");
            }
        }

      
        public async Task<IEnumerable<VendorDomainDto>> GetAssociatedVendorListForExternalUser(string userId , string groupName="")
        {
           var associatedVendors = await GetAssociatedVendorsForUser(userId,groupName);
            return await Task.FromResult(associatedVendors);
        }

        //Checking cache first before calling web service.
        public async Task<IEnumerable<VendorDomainDto>> GetAssociatedVendorsForUser(string userId, string groupName)
        {
            //Caching based on UserId and groupName combination.
                var CacheKey = userId + "_" + groupName;

                var associatedVendors = (List<VendorDomainDto>)MemoryCache.Default[CacheKey];

           
                if (associatedVendors == null)
                {
                    associatedVendors = new List<VendorDomainDto>();                       
                       AdminService adminsvc = new AdminService();
                    var vendorsAndOrgs = adminsvc.GetAssociatedVendorListForExternalUser(userId, groupName);
                    foreach (var associatedVendor in vendorsAndOrgs)
                    {
                        VendorDomainDto vendor = new VendorDomainDto();
                        vendor.VendorNumber = associatedVendor.VendorNumber;
                        vendor.VendorName = associatedVendor.VendorName;
                        vendor.VendorType = associatedVendor.VendorType;
                        vendor.OrganizationID = associatedVendor.OrganizationID;
                        vendor.OrganizationName = associatedVendor.OrganizationName;

                        associatedVendors.Add(vendor);
                    }

                    MemoryCache.Default.Add(CacheKey, associatedVendors, DateTime.Now.AddDays(1));

                }            
           
            return await Task.FromResult(associatedVendors);
        }

        //public async Task<IEnumerable<VendorDomainDto>> GetPossibleVendorUsers(int ItemFormID)
        //{
        //    // Get the list of the vendors of the item form


        //    // the cost offer service will provide the users who has authorization to all the vendors of the itm form
        //    // TO DO it is harded coded for the list of users.
        //    //return 1;

        //}
        public async Task<IEnumerable<int>> GetVendorsForItemForm(int itemFormID)
        {
            var associatedVendors = await _commonDac.GetVendorsForItemForm(itemFormID);
            return await Task.FromResult(associatedVendors);
        }

        public async Task<bool> IsDsdVendorsExistForUser(string userId, string groupName = "")
        {
            IEnumerable<VendorDomainDto> vendorList = await GetAssociatedVendorListForExternalUser(userId, groupName);
            int rowCount = 0;
            if (vendorList != null && vendorList.Count() > 0)
            {
                vendorList = vendorList.Where(x => x.VendorType == AppConstants.VENDOR_TYPE_DSD);
                rowCount = vendorList.Count();
            }
            return (rowCount > 0 ? true : false);
        }
        public async Task<bool> IsDsdVendorsExistForItemForm(int itemFormId)
        {            
            return await _commonDac.IsDsdVendorsExistForItemForm(itemFormId);
        }

        public async Task<bool> IsFAMCodeExistsInProductGrouping(int itemFormId)
        {
            return await _commonDac.IsFAMCodeExistsInProductGrouping(itemFormId);
        }

        public async Task<IEnumerable<VendorDomainDto>> GetVendorForSearch(VendorDomainDto vendorDomainDto)
        {
            string resource = string.Empty;
            System.Net.Http.HttpResponseMessage response;
            IEnumerable<VendorDomainDto> vendorDomainDtoList = new List<VendorDomainDto>();

            resource = "api/GetVendorForSearch";
            response = await GetHttpResponseViaPost(resource, vendorDomainDto);

            if (response.IsSuccessStatusCode)
            {
                vendorDomainDtoList = await response.Content.ReadAsAsync<IEnumerable<VendorDomainDto>>();
            }

            if (vendorDomainDtoList != null && vendorDomainDtoList.Count() > 0 && vendorDomainDto.VendorType == AppConstants.VENDOR_TYPE_DSD)
            {
                vendorDomainDtoList = vendorDomainDtoList.Where(x => x.VendorType == AppConstants.VENDOR_TYPE_DSD);
            }

            return vendorDomainDtoList;
        }

        public async Task<ErrorDTO> GetErrorMessage(string ErrorCode, int action = 1)
        {
            IEnumerable<ErrorDTO> Errors = await _commonDac.GetErrorMessages();
            var errorDTOTemplate = Errors.FirstOrDefault(e => e.ErrorCode == ErrorCode);
            //if (action == 3)
            //{
            //    return new ErrorDTO()
            //    {
            //        ErrorCode = errorDTOTemplate.ErrorCode,
            //        SeverityLevel = "Error",
            //        ControlName = errorDTOTemplate.ControlName,
            //        ErrorDescription = errorDTOTemplate.ErrorDescription
            //    };
            //}
            return errorDTOTemplate;
        }

        public async Task<PIDMDataDto> GetPMDSDataByItemCode(int itemCode)
        {
            System.Net.Http.HttpResponseMessage response = await GetHttpResponse("api/GetPIDMDataByItemID/" + itemCode);
            PIDMDataDto pidmItemData = new PIDMDataDto();

            if (response.IsSuccessStatusCode)
            {
                pidmItemData = response.Content.ReadAsAsync<PIDMDataDto>().Result;
                if (pidmItemData.BasicItemDefinition == null)
                { return null; }


            }
            return pidmItemData;
        }

        public async Task<PIDMDataDto> GetPMDSDataByGTIN(decimal? gtin)
        {

            System.Net.Http.HttpResponseMessage response = await GetHttpResponse("api/GetPIDMDataByGTIN/" + gtin);
            PIDMDataDto pidmItemData = new PIDMDataDto();

            if (response.IsSuccessStatusCode)
            {
                pidmItemData = response.Content.ReadAsAsync<PIDMDataDto>().Result;
                if (pidmItemData.BasicItemDefinition == null)
                { return null; }

            }

            return pidmItemData;
        }



        public async Task<string> GetVendorItemCode(int itemFormID)
        {
            return await _commonDac.GetVendorItemCode(itemFormID);
          
        }

        public async Task<IEnumerable<GTINWithCheckdigitDto>> GetBasicItemDefinitionGTIN(int itemFormID)
        {
            return await _commonDac.GetBasicItemDefinitionGTIN(itemFormID);
        }


        public async Task<IEnumerable<LookupDto>> GetFacilityGroupByType(string type)
        {
            System.Net.Http.HttpResponseMessage response = await GetHttpResponse("api/GetFacilityGroupByType/" + type);
            if (response.IsSuccessStatusCode)
            {
                IEnumerable<LookupDto> result = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
                return result;
            }
            return null;

        }

        public async Task<string> GetUserType(string userID)
        {           
            ItemFormService itemFormsvc = new ItemFormService();
            var userType = itemFormsvc.GetUserTypeForUser(userID);
            if (!string.IsNullOrEmpty(userType))
                return await Task.FromResult(userType);                       

            return null;
        }

        public async Task<IEnumerable<LookupDto>> GetFacilityGroupTypes()
        {
            System.Net.Http.HttpResponseMessage response = await GetHttpResponse("api/GetFacilityGroupTypes");
            if (response.IsSuccessStatusCode)
            {
                IEnumerable<LookupDto> result = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
                return result;
            }
            return null;
        }
        public async Task<IEnumerable<ItemFormDto>> GetItemFormGroup(int ItemFormID)
        {
            return await _commonDac.GetItemFormGroup(ItemFormID);
        }
        public async Task<string> GetSystemValueByKey(string KeyName)
        {
            IEnumerable<KeyValuePair<string, string>> SystemValues = await _commonDac.GetSystemValues();
            return SystemValues.Where(kv => kv.Key == KeyName).Select(kv => kv.Value).FirstOrDefault();
        }


        public async Task<bool> SaveItemFormErrors(ItemValidationDTO ItemValidation, int ItemFormID, string CreatedBy)
        {
            string TabName = ItemValidation.TabName;
            List<ItemFormErrorDto> ItemFormErroList = MapTo(ItemValidation, TabName, ItemFormID, CreatedBy);
            return await _commonDac.SaveItemFormErrors(ItemFormErroList,TabName, ItemFormID);
        }

        public async Task<IEnumerable<ItemValidationDTO>> GetItemFormErrors(int ItemFormID)
        {            
            IEnumerable<ItemFormErrorDto> ItemFormErroList = await _commonDac.GetItemFormErrors(ItemFormID);
            return MapTo(ItemFormErroList.ToList());
        }


        private List<ItemFormErrorDto> MapTo(ItemValidationDTO ItemValidation, string TabName, int ItemFormID, string CreatedBy)
        {
            List<ItemFormErrorDto> ItemFormErrorList = new List<ItemFormErrorDto>();
            if(ItemValidation.Errors!=null && ItemValidation.Errors.Count > 0)
            {
                foreach(var error in ItemValidation.Errors)
                {
                    ItemFormErrorList.Add(new ItemFormErrorDto
                    {
                        ItemFormID = ItemFormID,
                        ErrorCode = error.ErrorCode,
                        ErrorDescription = error.ErrorDescription,
                        TabName = TabName,
                        CreatedBy = CreatedBy
                    });
                }                
            }
            if (ItemValidation.Warnings != null && ItemValidation.Warnings.Count > 0)
            {
                foreach (var warning in ItemValidation.Warnings)
                {
                    ItemFormErrorList.Add(new ItemFormErrorDto
                    {
                        ItemFormID = ItemFormID,
                        ErrorCode = warning.ErrorCode,
                        ErrorDescription = warning.ErrorDescription,
                        TabName = TabName,
                        CreatedBy = CreatedBy
                    });
                }
            }
            if(ItemValidation.SubTabValidations != null && ItemValidation.SubTabValidations.Count > 0)
            {
                foreach(var subTab in ItemValidation.SubTabValidations)
                {
                    string SubTabName = subTab.SubTabName;
                    if(subTab.Errors != null && subTab.Errors.Count > 0)
                    {
                        foreach(var error in subTab.Errors)
                        {
                            ItemFormErrorList.Add(new ItemFormErrorDto
                            {
                                ItemFormID = ItemFormID,
                                ErrorCode = error.ErrorCode,
                                ErrorDescription = error.ErrorDescription,
                                TabName = TabName,
                                SubTabName = SubTabName,
                                CreatedBy = CreatedBy
                            });
                        }
                    }
                    if (subTab.Warnings != null && subTab.Warnings.Count > 0)
                    {
                        foreach (var warning in subTab.Warnings)
                        {
                            ItemFormErrorList.Add(new ItemFormErrorDto
                            {
                                ItemFormID = ItemFormID,
                                ErrorCode = warning.ErrorCode,
                                ErrorDescription = warning.ErrorDescription,
                                TabName = TabName,
                                SubTabName = SubTabName,
                                CreatedBy = CreatedBy
                            });
                        }
                    }
                }
            }
            return ItemFormErrorList;
        }

        private  List<ItemValidationDTO> MapTo(List<ItemFormErrorDto> ItemFormErrorList)
        {
            List<ItemValidationDTO> ItemValidationList = new List<ItemValidationDTO>();
            IEnumerable<string> TabNames = ItemFormErrorList.Select(item => item.TabName).Distinct();
            if(TabNames !=null) {
                foreach(var TabName in TabNames)
                {
                    ItemValidationDTO ItemValidationTab = new ItemValidationDTO();
                    ItemValidationTab.TabName = TabName;
                    ItemValidationTab.Errors = ItemFormErrorList.Where(item => item.TabName == TabName && item.SubTabName == null && item.SeverityLevel == "Error").Select(item => new ErrorDTO {
                        ErrorCode = item.ErrorCode,
                        ErrorDescription = item.ErrorDescription,
                        TabName = item.TabName,
                        ControlName = item.ControlName,
                        SeverityLevel = item.SeverityLevel
                    }).ToList();
                    ItemValidationTab.Warnings = ItemFormErrorList.Where(item => item.TabName == TabName && item.SubTabName == null && item.SeverityLevel == "Warning").Select(item => new WarningDTO
                    {
                        ErrorCode = item.ErrorCode,
                        ErrorDescription = item.ErrorDescription,
                        ControlName = item.ControlName,
                    }).ToList();
                    IEnumerable<string> SubTabNames = ItemFormErrorList.Where(item => item.TabName == TabName && item.SubTabName != null).Select(item => item.SubTabName).Distinct();
                    if(SubTabNames != null)
                    {
                        ItemValidationTab.SubTabValidations = new List<SubTabValidationDTO>();
                        foreach (var SubTabName in SubTabNames)
                        {
                            SubTabValidationDTO SubTabValidationTab = new SubTabValidationDTO();
                            SubTabValidationTab.SubTabName = SubTabName;
                            SubTabValidationTab.Errors = ItemFormErrorList.Where(item => item.TabName == TabName && item.SubTabName == SubTabName && item.SeverityLevel == "Error").Select(item => new ErrorDTO
                            {
                                ErrorCode = item.ErrorCode,
                                ErrorDescription = item.ErrorDescription,
                                TabName = item.TabName,
                                ControlName = item.ControlName,
                                SeverityLevel = item.SeverityLevel
                            }).ToList();
                            SubTabValidationTab.Warnings = ItemFormErrorList.Where(item => item.TabName == TabName && item.SubTabName == SubTabName && item.SeverityLevel == "Warning").Select(item => new WarningDTO
                            {
                                ErrorCode = item.ErrorCode,
                                ErrorDescription = item.ErrorDescription,
                                ControlName = item.ControlName,
                            }).ToList();
                            ItemValidationTab.SubTabValidations.Add(SubTabValidationTab);
                        }
                    }
                    ItemValidationList.Add(ItemValidationTab);
                }
            }

            return ItemValidationList;
        }


        //public async Task<bool> CreateItem(int itemFormID , string createdBy)
        //{
        //    var bidData = await _basicItemDefinitionBo.GetBasicItemDefinitionData(itemFormID);
        //    bidData.FormActionID = 5; // Submit for Create Item action.
        //    var bidValidationDto = await _basicItemDefinitionBo.ValidateBasicItemDefinition(bidData);
        //    if (bidValidationDto.Errors.Count > 0 || bidValidationDto.SubTabValidations.Count > 0)
        //    {
        //        // Add these errors to error table.
        //        await SaveItemFormErrors(bidValidationDto, itemFormID, createdBy);
        //    }

        //    var gpaData = await _generalProductAttributesBo.GetGeneralProdutAttributes(itemFormID);
        //    gpaData.FormActionID = 5;
        //    var gpaValidationDto = await _generalProductAttributesBo.ValidateGeneralProductAttributes(gpaData);
        //    if (gpaValidationDto.Errors.Count > 0 || gpaValidationDto.SubTabValidations.Count > 0)
        //    {
        //        // Add these errors to error table.
        //        await SaveItemFormErrors(gpaValidationDto, itemFormID, createdBy);
        //    }

            
        //    return true;
        //}
    }
}
