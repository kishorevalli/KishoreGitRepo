﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System.Net.Http;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using AutoMapper;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class ProductGroupingBO : IProductGroupingBO
    {
        protected readonly IProductGroupingDac _productGroupingDac;
        protected readonly ICommonBO _commonBo;
        public ProductGroupingBO(IProductGroupingDac productGroupingDac, ICommonBO commonBo)
        {
            this._productGroupingDac = productGroupingDac;
            this._commonBo = commonBo;
        }
        public async Task<IEnumerable<ProductGroupingDto>> GetProductGrouping(int ItemFormID)
        {
            IEnumerable<ProductGroupingLinearDto> _productGroupingList = await _productGroupingDac.GetProductGrouping(ItemFormID);
            return MapTo(_productGroupingList.ToList());
        }

        public async Task<IEnumerable<ProductGroupingDto>> GetProductGroupingByItemCode(int ItemCode, int ModelGroupCodeType)
        {
            IEnumerable<ProductGroupingLinearDto> _productGroupingList = await _commonBo.GetPIDMData<ProductGroupingLinearDto, PMDSProductGroupingDto>("api/GetProductGroupsByItemID/" + ItemCode);
            List<ProductGroupingDto> ProductGroupingDtoList = MapTo(_productGroupingList.ToList(), ModelGroupCodeType);
            ProductGroupingDtoList.AddRange(await _productGroupingDac.GetFLEXProductGroup(ItemCode, ModelGroupCodeType));
            ProductGroupingDtoList.AddRange(await _productGroupingDac.GetPPMSProductGroup(ItemCode, ModelGroupCodeType));
            return ProductGroupingDtoList;
        }
        public async Task<IEnumerable<ProductGroupType>> GetChildItemGroupTypes()
        {            
            return await _commonBo.GetPIDMData<ProductGroupType, PMDSChildGroupTypeCode>("api/GetChildItemGroupTypes/");
        }
        public async Task<IEnumerable<LookupDto>> GetItemGroupCodes(string GroupType)
        {
            return await _commonBo.GetPIDMLookup("api/GetItemGroupCodes/"+ GroupType);
        }
        public async Task<IEnumerable<ProductGroupingVendorDto>> GetVBGVendors(int ItemFormID)
        {
            return await _productGroupingDac.GetVBGVendors(ItemFormID);
        }
        public async Task<IEnumerable<ProductVBGGroupDto>> GetVBGGroupCodes(List<int> VendorNumbers)
        {
            return await _commonBo.GetPIDMDataByPost<ProductVBGGroupDto, PIDMProductGroupVBGDto>("api/GetVBGGroupCodes/", VendorNumbers);
        }
        public async Task<IEnumerable<ProductGroupingDto>> GetParentGroupTypesAndCodes(string GroupType, int GroupCode)
        {
            IEnumerable<ProductGroupingLinearDto> _productGroupingList = await _commonBo.GetPIDMDataByPost<ProductGroupingLinearDto, PMDSProductGroupingDto>("api/GetParentGroupTypesAndCodes",new { GroupType, GroupCode });
            return MapTo(_productGroupingList.ToList(), 0);
        }
        public async Task<int> GetSubmittedItemFormIDWithSameGTIN(int ItemFormID)
        {
            string FormStatusAfterSubmit = await _commonBo.GetSystemValueByKey("FormStatusAfterSubmit");
            if (string.IsNullOrEmpty(FormStatusAfterSubmit)) return 0;
            return await _productGroupingDac.GetSubmittedItemFormIDWithSameGTIN(ItemFormID, FormStatusAfterSubmit);
        }
        public async Task<IEnumerable<ProductPriceGroupDto>> GetProductPriceGroup(string SearchBy, string SearchValue)
        {
            IEnumerable<ProductPriceGroupDto> _productPriceGroupList =  await _productGroupingDac.GetProductPriceGroup(SearchBy, SearchValue);
            return MapTo(_productPriceGroupList);
        }
        public async Task<IEnumerable<ProductAdGroupDto>> GetProductAdGroup(string SearchBy, string SearchValue)
        {
            IEnumerable<ProductAdGroupDto> _productAdGroupList = await _productGroupingDac.GetProductAdGroup(SearchBy, SearchValue);
            string ItemCode = null;
            if (SearchBy == "ItemCode")
            {
                ItemCode = SearchValue;
            }
            return MapTo(_productAdGroupList, ItemCode);
        }
        public async Task<IEnumerable<LookupDto>> GetSubDepartments()
        {
            return await _commonBo.GetPIDMLookup("api/GetSubDepartments/");
        }
        public async Task<IEnumerable<LookupDto>> GetCategory(int SubDepartment)
        {
            return await _commonBo.GetPIDMLookup("api/GetCategory/" + SubDepartment);
        }
        public async Task<IEnumerable<LookupDto>> GetFamilyGroup(int SubDepartment, int Category)
        {
            return await _commonBo.GetPIDMLookup("api/GetFamilyGroup/" + SubDepartment+"/"+ Category);
        }

        public async Task<ItemValidationDTO> ValidateProductGrouping(List<ProductGroupingDto> productGroupingList)
        {
            ItemValidationDTO bidValidationDTO = new ItemValidationDTO();

            //TODO : put all the tab names into some common file as consts. 
            bidValidationDTO.TabName = "Product Grouping";
            List<ErrorDTO> errorList = new List<ErrorDTO>();
            List<WarningDTO> warningsList = new List<WarningDTO>();
            bool isFAMPresent = false;
            bool isRSSPresent = false;
            var GroupCodeCount = productGroupingList.GroupBy(info => info.ProductGroupType)
                                    .Select(group => new
                                    {
                                        Type= group.Key,
                                        Count = group.Count()
                                    });
            foreach(var groupCode in GroupCodeCount)
            {
                if(groupCode.Type == "FAM")
                {
                    isFAMPresent = true;
                }
                if(groupCode.Type == "RSS")
                {
                    isRSSPresent = true;
                }
                if (groupCode.Count > 1)
                {
                    if (groupCode.Type == "VBG" || groupCode.Type == "RSS") continue;
                    if (groupCode.Type == "FLEX" || groupCode.Type == "PPMS") continue;
                    string ErrorCode = (groupCode.Type == "FAM")? "PG03" : "PG02";
                    var errorDTOTemplate = await _commonBo.GetErrorMessage(ErrorCode);
                    if (errorDTOTemplate.SeverityLevel == "Error")
                    {
                        errorList.Add(new ErrorDTO()
                        {
                            ErrorCode = errorDTOTemplate.ErrorCode,
                            SeverityLevel = errorDTOTemplate.SeverityLevel,
                            ControlName = errorDTOTemplate.ControlName,
                            ErrorDescription = String.Format(errorDTOTemplate.ErrorDescription, groupCode.Type)
                        });
                    }
                    else
                    {
                        warningsList.Add(new WarningDTO()
                        {
                            ErrorCode = errorDTOTemplate.ErrorCode,
                            ControlName = errorDTOTemplate.ControlName,
                            ErrorDescription = String.Format(errorDTOTemplate.ErrorDescription, groupCode.Type)
                        });
                    }
                }
            }
            if (!isFAMPresent)
            {
                var error = await _commonBo.GetErrorMessage("PG01");
                if (error.SeverityLevel == "Warning")
                    warningsList.Add(Mapper.Map<WarningDTO>(error));
                else
                    errorList.Add(error);
            }
            if (!isRSSPresent)
            {
                var error = await _commonBo.GetErrorMessage("PG04");
                if(error != null)
                {
                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
            }
            bidValidationDTO.Errors = errorList;
            bidValidationDTO.Warnings = warningsList;
            return bidValidationDTO;
        }
        //TODO: Need to call this method if vendor is submitting the form.
        public async Task<bool> CopyProductGroupingOnSubmit(int ItemFormID)
        {
            try
            {
                int SimilarItemFormID = await GetSubmittedItemFormIDWithSameGTIN(ItemFormID);
                if (SimilarItemFormID > 0)
                {
                    return await _productGroupingDac.CopyProductGrouping(ItemFormID, SimilarItemFormID);
                }
                return true;
            }
            catch(Exception ex)
            {
                string xx = ex.ToString();
                return false;
            }
            
        }
        public async Task<bool> SaveProductGrouping(List<ProductGroupingDto> productGroupingList, int ItemFormID, string currentUser, UserType SubmittedUserTypeID, int? FormStatusID = null, int? FormActionID = null)
        {
            bool successFlag = true;
            var productGroupingLinearList = MapTo(productGroupingList, ItemFormID, currentUser);
            successFlag = await _productGroupingDac.SaveProductGrouping(productGroupingLinearList, ItemFormID);
            // Collect the BuyerID and BuyerName to store in Item Form
            int? buyerId = null;
            string buyerName = "";
            var productGroup = productGroupingLinearList.Where(item => item.ParentProductGroupType == "BUY").FirstOrDefault();
            if (productGroup != null)
            {
                buyerId = productGroup.ParentProductGroupCode;
                buyerName = productGroup.ParentProductGroupDescription;
            }
            // Update the ItemForm audit info 
            ItemFormDto itemForm = new ItemFormDto();
            itemForm.ID = ItemFormID;
            itemForm.FormStatusID = FormStatusID ?? 0;
            itemForm.FormActionID = FormActionID ?? 0;
            itemForm.SubmittedUserTypeID = (int)SubmittedUserTypeID;
            itemForm.BuyerID = buyerId;
            itemForm.BuyerName = buyerName;
            itemForm.CreatedBy = currentUser;
            itemForm.LastUpdatedBy = currentUser;
            await _productGroupingDac.UpdateItemFormBuyer(itemForm);
            List<ProductGroupingLinearDto> productGroupingFAMList = productGroupingLinearList.Where(item => item.ChildProductGroupType == "FAM").ToList();
            if(productGroupingFAMList != null && productGroupingFAMList.Count > 0)
            {
                await CopyFAMProductGrouping(productGroupingFAMList, ItemFormID);
            }
            return successFlag;
        }
        public async Task<bool> SaveFAMProductGrouping(List<ProductGroupingDto> productGroupingList, int ItemFormID, string currentUser, UserType SubmittedUserTypeID, int? FormStatusID = null, int? FormActionID = null)
        {
            bool successFlag = true;
            var productGroupingLinearList = MapTo(productGroupingList, ItemFormID, currentUser);
            successFlag = await _productGroupingDac.SaveFAMProductGrouping(productGroupingLinearList, ItemFormID);
            // Collect the BuyerID and BuyerName to store in Item Form
            int? buyerId = null;
            string buyerName = "";
            var productGroup = productGroupingLinearList.Where(item => item.ParentProductGroupType == "BUY").FirstOrDefault();
            if (productGroup != null)
            {
                buyerId = productGroup.ParentProductGroupCode;
                buyerName = productGroup.ParentProductGroupDescription;
                // Update the ItemForm audit info 
                ItemFormDto itemForm = new ItemFormDto();
                itemForm.ID = ItemFormID;
                itemForm.FormStatusID = FormStatusID ?? 0;
                itemForm.FormActionID = FormActionID ?? 0;
                itemForm.SubmittedUserTypeID = (int)SubmittedUserTypeID;
                itemForm.BuyerID = buyerId;
                itemForm.BuyerName = buyerName;
                itemForm.CreatedBy = currentUser;
                itemForm.LastUpdatedBy = currentUser;
                await _productGroupingDac.UpdateItemFormBuyer(itemForm);
                await CopyFAMProductGrouping(productGroupingLinearList, ItemFormID);
            }
            return successFlag;
        }
        private async Task<bool> CopyFAMProductGrouping(List<ProductGroupingLinearDto> productGroupingFAMList, int ItemFormID)
        {
            var sameGTINItemForms = await _commonBo.GetItemFormGroup(ItemFormID);
            string FormStatusAfterSubmit = await _commonBo.GetSystemValueByKey("FormStatusAfterSubmit");
            if (string.IsNullOrEmpty(FormStatusAfterSubmit)) return true;
            List<string> Status = FormStatusAfterSubmit.Split(',').ToList();
            var currentItemForm = sameGTINItemForms.Where(item => item.ID == ItemFormID && Status.Contains(item.FormStatusID.ToString())).FirstOrDefault();
            if(currentItemForm != null)
            {
                List<int> SimilarItemFormIDs = sameGTINItemForms.Where(item => item.ID != ItemFormID && Status.Contains(item.FormStatusID.ToString())).Select(item => item.ID).ToList();
                if (SimilarItemFormIDs != null && SimilarItemFormIDs.Count > 0)
                {
                    await _productGroupingDac.CopyFAMProductGrouping(productGroupingFAMList, ItemFormID, SimilarItemFormIDs);
                }
            }
            return true;
        }

        #region Conversion to tree structure
        /** TODO: Revisit this logic of conversion to make it as efficient as possible.*/
        private List<ProductGroupingDto> MapTo(List<ProductGroupingLinearDto> productGroupingList, int ModelGroupCodeType = 0)
        {
            List<ProductGroupingDto> productGroupingDtoList = new List<ProductGroupingDto>();
            for (int i = 0; i < productGroupingList.Count; i++)
            {
                var match = productGroupingList.Find(pg => pg.ParentProductGroupType == productGroupingList[i].ChildProductGroupType
                                                         && pg.ParentProductGroupCode == productGroupingList[i].ChildProductGroupCode
                                                         && pg.ParentProductGroupDescription == productGroupingList[i].ChildProductGroupDescription);
                if (match != null) continue;
                var index = productGroupingList.FindIndex(pg => pg.ChildProductGroupType == productGroupingList[i].ChildProductGroupType
                                                          && pg.ChildProductGroupCode == productGroupingList[i].ChildProductGroupCode
                                                          && pg.ChildProductGroupDescription == productGroupingList[i].ChildProductGroupDescription);


                if (index == i)
                {
                    ProductGroupingDto productGroupingDto = new ProductGroupingDto
                    {
                        ProductGroupType = productGroupingList[i].ChildProductGroupType,
                        ProductGroupCode = productGroupingList[i].ChildProductGroupCode,
                        ProductGroupDescription = productGroupingList[i].ChildProductGroupDescription,
                        ModelGroupCodeType = ModelGroupCodeType,
                        IsMandatory = productGroupingList[i].IsMandatory
                    };
                    productGroupingDto.Parents = this.PopulateFirstLevel(productGroupingDto, productGroupingList);
                    productGroupingDtoList.Add(productGroupingDto);
                }
            }

            return productGroupingDtoList;
        }
        private List<ProductGroupingDto> PopulateFirstLevel(ProductGroupingDto childProductGroupingDto, List<ProductGroupingLinearDto> productGroupingList)
        {
            List<ProductGroupingDto> productGroupingDtoList = new List<ProductGroupingDto>();
            for (int i = 0; i < productGroupingList.Count; i++)
            {
                if (string.IsNullOrWhiteSpace(productGroupingList[i].ParentProductGroupType)) continue;
                var index = productGroupingList.FindIndex(pg => pg.ChildProductGroupType == childProductGroupingDto.ProductGroupType
                                                          && pg.ChildProductGroupCode == childProductGroupingDto.ProductGroupCode
                                                          && pg.ChildProductGroupDescription == childProductGroupingDto.ProductGroupDescription
                                                          && pg.ParentProductGroupType == productGroupingList[i].ParentProductGroupType
                                                          && pg.ParentProductGroupCode == productGroupingList[i].ParentProductGroupCode
                                                          && pg.ParentProductGroupDescription == productGroupingList[i].ParentProductGroupDescription);
                if (index == i)
                {
                    ProductGroupingDto productGroupingDto = new ProductGroupingDto
                    {
                        ProductGroupType = productGroupingList[i].ParentProductGroupType,
                        ProductGroupCode = productGroupingList[i].ParentProductGroupCode,
                        ProductGroupDescription = productGroupingList[i].ParentProductGroupDescription,
                        ModelGroupCodeType = childProductGroupingDto.ModelGroupCodeType
                    };
                    productGroupingDto.Parents = this.PopulateSecondLevel(childProductGroupingDto, productGroupingDto, productGroupingList);
                    productGroupingDtoList.Add(productGroupingDto);
                }
            }

            return productGroupingDtoList;
        }
        private List<ProductGroupingDto> PopulateSecondLevel(ProductGroupingDto childProductGroupingDto, ProductGroupingDto parentProductGroupingDto, List<ProductGroupingLinearDto> productGroupingList)
        {
            List<ProductGroupingDto> productGroupingDtoList = new List<ProductGroupingDto>();
            for (int i = 0; i < productGroupingList.Count; i++)
            {
                if (string.IsNullOrWhiteSpace(productGroupingList[i].GrandParentProductGroupType)) continue;
                var index = productGroupingList.FindIndex(pg => pg.ChildProductGroupType == childProductGroupingDto.ProductGroupType
                                                          && pg.ChildProductGroupCode == childProductGroupingDto.ProductGroupCode
                                                          && pg.ChildProductGroupDescription == childProductGroupingDto.ProductGroupDescription
                                                          && pg.ParentProductGroupType == parentProductGroupingDto.ProductGroupType
                                                          && pg.ParentProductGroupCode == parentProductGroupingDto.ProductGroupCode
                                                          && pg.ParentProductGroupDescription == parentProductGroupingDto.ProductGroupDescription
                                                          && pg.GrandParentProductGroupType == productGroupingList[i].GrandParentProductGroupType
                                                          && pg.GrandParentProductGroupCode == productGroupingList[i].GrandParentProductGroupCode
                                                          && pg.GrandParentProductGroupDescription == productGroupingList[i].GrandParentProductGroupDescription);
                if (index == i)
                {
                    ProductGroupingDto productGroupingDto = new ProductGroupingDto
                    {
                        ProductGroupType = productGroupingList[i].GrandParentProductGroupType,
                        ProductGroupCode = productGroupingList[i].GrandParentProductGroupCode,
                        ProductGroupDescription = productGroupingList[i].GrandParentProductGroupDescription,
                        ModelGroupCodeType = childProductGroupingDto.ModelGroupCodeType
                    };
                    productGroupingDto.Parents = new List<ProductGroupingDto>();
                    productGroupingDtoList.Add(productGroupingDto);
                }
            }
            return productGroupingDtoList;
        }
        private IEnumerable<ProductPriceGroupDto> MapTo(IEnumerable<ProductPriceGroupDto> ProductPriceGroupLinearList)
        {
            List<ProductPriceGroupDto> ProductPriceGroupDtoList = new List<ProductPriceGroupDto>();
            var PriceGroupHierarchy = ProductPriceGroupLinearList.GroupBy(info => info.PriceGroupID);
            foreach (var PriceGroup in PriceGroupHierarchy)
            {
                List<ProductPriceGroupDto> groupedList = PriceGroup.ToList();
                ProductPriceGroupDto ProductPriceGroupLinearDto = groupedList.Find(item => item.ItemCode == item.LeadItemCode);
                if(ProductPriceGroupLinearDto != null)
                {
                    var ProductPriceGroupDto = new ProductPriceGroupDto
                    {
                        PriceGroupID = ProductPriceGroupLinearDto.PriceGroupID,
                        PriceGroupName = ProductPriceGroupLinearDto.PriceGroupName,
                        LeadItemCode = ProductPriceGroupLinearDto.LeadItemCode,
                        ItemCode = ProductPriceGroupLinearDto.ItemCode,
                        ItemDescription = ProductPriceGroupLinearDto.ItemDescription,
                        VendorName = ProductPriceGroupLinearDto.VendorName,
                        VendorNumber = ProductPriceGroupLinearDto.VendorNumber,
                        PriceGroupItems = groupedList.Where(item => item.ItemCode != item.LeadItemCode)
                    };
                    ProductPriceGroupDtoList.Add(ProductPriceGroupDto);
                }
                // We need this if there is no item with the same ItemCode and LeadItemCode
                else
                {
                    var ProductPriceGroupDto = new ProductPriceGroupDto
                    {
                        PriceGroupID = groupedList[0].PriceGroupID,
                        PriceGroupName = groupedList[0].PriceGroupName,
                        LeadItemCode = groupedList[0].LeadItemCode,
                        ItemCode = groupedList[0].ItemCode,
                        ItemDescription = groupedList[0].ItemDescription,
                        VendorName = groupedList[0].VendorName,
                        VendorNumber = groupedList[0].VendorNumber,
                        PriceGroupItems = groupedList
                    };
                    ProductPriceGroupDtoList.Add(ProductPriceGroupDto);
                }
            }

            return ProductPriceGroupDtoList;
        }

        private IEnumerable<ProductAdGroupDto> MapTo(IEnumerable<ProductAdGroupDto> ProductAdGroupLinearList, string ItemCode)
        {
            List<ProductAdGroupDto> ProductAdGroupDtoList = new List<ProductAdGroupDto>();
            var AdGroupHierarchy = ProductAdGroupLinearList.GroupBy(info => info.AdGroupID);
            foreach (var AdGroup in AdGroupHierarchy)
            {
                List<ProductAdGroupDto> groupedList = AdGroup.ToList();
                ProductAdGroupDto ProductAdGroupLinearDto;
                if (!string.IsNullOrEmpty(ItemCode))
                {
                   ProductAdGroupLinearDto = groupedList.Find(item => item.ItemCode.ToString() == ItemCode);
                }
                else
                {
                    ProductAdGroupLinearDto = groupedList.Find(item => item.LeadCode == "Y");
                }
                if (ProductAdGroupLinearDto != null)
                {
                    var ProductAdGroupDto = new ProductAdGroupDto
                    {
                        AdGroupID = ProductAdGroupLinearDto.AdGroupID,
                        AdGroupName = ProductAdGroupLinearDto.AdGroupName,
                        ItemCode = ProductAdGroupLinearDto.ItemCode,
                        ItemDescription = ProductAdGroupLinearDto.ItemDescription,
                        LeadCode = ProductAdGroupLinearDto.LeadCode,
                        AdGroupItems = groupedList
                    };
                    ProductAdGroupDtoList.Add(ProductAdGroupDto);
                }
                else // It will never hit this line, but just keeping it same as Price Group code 
                {
                    var ProductAdGroupDto = new ProductAdGroupDto
                    {
                        AdGroupID = groupedList[0].AdGroupID,
                        AdGroupName = groupedList[0].AdGroupName,
                        ItemCode = groupedList[0].ItemCode,
                        ItemDescription = groupedList[0].ItemDescription,
                        LeadCode = groupedList[0].LeadCode,
                        AdGroupItems = groupedList
                    };
                    ProductAdGroupDtoList.Add(ProductAdGroupDto);
                }
            }

            return ProductAdGroupDtoList;
        }
        #endregion

        #region Conversion to flat structure
        private List<ProductGroupingLinearDto> MapTo(List<ProductGroupingDto> productGroupingList, int ItemFormID, string currentUser)
        {
            List<ProductGroupingLinearDto> ProductGroupingLinearList = new List<ProductGroupingLinearDto>();
            var filteredList = productGroupingList.Where(item => item.ProductGroupCode > 0 || !string.IsNullOrEmpty(item.ProductGroupDescription)).ToList();
            if (filteredList.Count > 0)
            {
                foreach (var productGrouping in filteredList)
                {
                    var filteredParentList = (productGrouping.Parents != null)? productGrouping.Parents.Where(item => item.ProductGroupCode > 0 || !string.IsNullOrEmpty(item.ProductGroupDescription)).ToList(): new List<ProductGroupingDto>();
                    if (filteredParentList.Count > 0)
                    {
                        foreach (var parentProductGrouping in filteredParentList)
                        {
                            var filteredGrandParentList = parentProductGrouping.Parents.Where(item => item.ProductGroupCode > 0 || !string.IsNullOrEmpty(item.ProductGroupDescription)).ToList();
                            if (filteredGrandParentList.Count > 0)
                            {
                                foreach (var grandParentProductGrouping in filteredGrandParentList)
                                {
                                    ProductGroupingLinearList.Add(new ProductGroupingLinearDto
                                    {
                                        ItemFormID = ItemFormID,
                                        ChildProductGroupType = productGrouping.ProductGroupType,
                                        ChildProductGroupCode = productGrouping.ProductGroupCode,
                                        ChildProductGroupDescription = productGrouping.ProductGroupDescription,
                                        IsMandatory = productGrouping.IsMandatory,
                                        ParentProductGroupType = parentProductGrouping.ProductGroupType,
                                        ParentProductGroupCode = parentProductGrouping.ProductGroupCode,
                                        ParentProductGroupDescription = parentProductGrouping.ProductGroupDescription,
                                        GrandParentProductGroupType = grandParentProductGrouping.ProductGroupType,
                                        GrandParentProductGroupCode = grandParentProductGrouping.ProductGroupCode,
                                        GrandParentProductGroupDescription = grandParentProductGrouping.ProductGroupDescription,
                                        CreatedBy = currentUser,
                                        LastUpdatedBy = currentUser
                                    });
                                }
                            }
                            else
                            {
                                ProductGroupingLinearList.Add(new ProductGroupingLinearDto
                                {
                                    ItemFormID = ItemFormID,
                                    ChildProductGroupType = productGrouping.ProductGroupType,
                                    ChildProductGroupCode = productGrouping.ProductGroupCode,
                                    ChildProductGroupDescription = productGrouping.ProductGroupDescription,
                                    IsMandatory = productGrouping.IsMandatory,
                                    ParentProductGroupType = parentProductGrouping.ProductGroupType,
                                    ParentProductGroupCode = parentProductGrouping.ProductGroupCode,
                                    ParentProductGroupDescription = parentProductGrouping.ProductGroupDescription,
                                    CreatedBy = currentUser,
                                    LastUpdatedBy = currentUser
                                });
                            }
                        }
                    }
                    else
                    {
                        ProductGroupingLinearList.Add(new ProductGroupingLinearDto
                        {
                            ItemFormID = ItemFormID,
                            ChildProductGroupType = productGrouping.ProductGroupType,
                            ChildProductGroupCode = productGrouping.ProductGroupCode,
                            ChildProductGroupDescription = productGrouping.ProductGroupDescription,
                            IsMandatory = productGrouping.IsMandatory,
                            CreatedBy = currentUser,
                            LastUpdatedBy = currentUser
                        });
                    }
                }
            }
            return ProductGroupingLinearList;
        }
        #endregion

    }
}
