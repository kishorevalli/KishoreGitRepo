﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class WorkFlowBO : IWorkFlowBO
    {
        protected readonly IWorkFlowDac _workflowDac;
        protected readonly ICommonBO _commonBo;

        public WorkFlowBO(IWorkFlowDac workflowDac, ICommonBO commonBo)
        {
            this._workflowDac = workflowDac;
            this._commonBo = commonBo;
        }

        public Task<IEnumerable<FormUserPermittedActionDto>> GetFormUserPermittedAction(UserType currentUserType, int formCurrentStatusID , int formTypeID)
        {
            return _workflowDac.GetFormUserPermittedAction(currentUserType,formCurrentStatusID , formTypeID);
        }

        public List<DashboardItemFormDto> LoadFormActionsForItemFormListInternal(List<DashboardItemFormDto> ItemFormList, UserType userType)
        {
            // getting all the form actions for new item form
            List<FormUserPermittedActionDto> FormActionList = _workflowDac.GetFormUserPermittedAction(userType, 0, 1).Result.ToList(); 
            List<DashboardItemFormDto> ResultItemFormList = new List<DashboardItemFormDto>();

            foreach (var CurrentItemForm in ItemFormList)
            {
                AddActionsToItemForm(CurrentItemForm, userType, ResultItemFormList);
            }
            return ResultItemFormList;
        }


        public List<DashboardItemFormDto> LoadFormActionsForItemFormListVendor(List<DashboardItemFormDto> ItemFormList, string LoggedInUserID)
        {
            List<DashboardItemFormDto> ResultItemFormList = new List<DashboardItemFormDto>();
            List<FormUserPermittedActionDto> FormActionList = _workflowDac.GetFormUserPermittedAction(UserType.Vendor, 0, 1).Result.ToList();
    

            IEnumerable<VendorDomainDto> loggedInVendors = _commonBo.GetAssociatedVendorListForExternalUser(LoggedInUserID).Result;
            string LoggedInVendorList = String.Join(",", loggedInVendors.Select(v => v.VendorNumber));

            foreach (var CurrentItemForm in ItemFormList)
            {
                CurrentItemForm.formActions = new List<FormUserPermittedActionDto>();
                List<FormUserPermittedActionDto> ActionList = new List<FormUserPermittedActionDto>();
                // run the validation of the form is having valid vendors during the current time.
                if (ValidateItemFormByVendors(CurrentItemForm.ItemFormID, LoggedInVendorList))
                //if (true)
                {
                    AddActionsToItemForm(CurrentItemForm, UserType.Vendor, ResultItemFormList);
                }
                else
                {
                    CurrentItemForm.formActions.Add(new FormUserPermittedActionDto
                    {
                        ItemFormID = CurrentItemForm.ItemFormID,
                        FormActionID = -2,
                        ActionName = "Reassign Vendor Contact",
                        BuyerActionName = "Reassign Vendor Contact",
                        VendorActionName = "Reassign Vendor Contact",
                        ActionComment = "Please Reassign Vendor Contact"
                    });
                    ResultItemFormList.Add(CurrentItemForm);
                }
            }
            return ResultItemFormList;
        }

       void AddActionsToItemForm(DashboardItemFormDto CurrentItemForm,UserType userType, List<DashboardItemFormDto> ItemFormListResult)
        {
            List<FormUserPermittedActionDto> TotalUserActionList = _workflowDac.GetFormUserPermittedAction(userType, 0, 1).Result.ToList();            

            List<FormUserPermittedActionDto> CurrentFormActionList = TotalUserActionList.FindAll(Action => Action.FormTypeId == CurrentItemForm.FormTypeID && Action.CurrentFormStatusID == CurrentItemForm.FormStatusID);

            CurrentItemForm.formActions = new List<FormUserPermittedActionDto>();
            foreach (var action in CurrentFormActionList)
            {
                FormUserPermittedActionDto CurrentAction = new FormUserPermittedActionDto
                {
                    ItemFormID = CurrentItemForm.ItemFormID,
                    FormTypeId = action.FormTypeId,
                    CurrentFormStatusID = action.CurrentFormStatusID,
                    FormActionID = action.FormActionID,
                    ActionName = action.ActionName,
                    BuyerActionName = action.BuyerActionName,
                    VendorActionName = action.VendorActionName,
                    CreatedFormStatusID = action.CreatedFormStatusID,
                    ActionComment = action.ActionComment,
                    CurrentFormStatusComment = action.CurrentFormStatusComment,
                    CreatedFormStatusComment = action.CreatedFormStatusComment
                };
                if(CurrentAction.FormActionID != 2)
                CurrentItemForm.formActions.Add(CurrentAction);
            }
            //adding EDit Action which should not have any form status DB impact
            //CurrentItemForm.formActions.Add(new FormUserPermittedActionDto
            //{
            //    ItemFormID = CurrentItemForm.ItemFormID,
            //    FormActionID = -1,
            //    ActionName = "Edit",
            //    BuyerActionName = "Edit",
            //    VendorActionName = "Edit",
            //    ActionComment = "Please select item form to edit"
            //});
            ItemFormListResult.Add(CurrentItemForm);
        }        


        public bool ValidateItemFormByVendors(int ItemFormID, string LoggedInVendorList)
        {
            try
            {
                int InvalidVendor = _workflowDac.ValidateItemFormByVendors(ItemFormID, LoggedInVendorList);
                if (InvalidVendor > 0)
                    return false;
                return true;
            }
            catch (Exception e)
            {

                throw;
            }

        }

    }


}

