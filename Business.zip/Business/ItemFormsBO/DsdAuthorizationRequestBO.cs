﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsCommon;
using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class DsdAuthorizationRequestBO: IDsdAuthorizationRequestBO
    {
        protected readonly IDsdAuthorizationRequestDac _dsdAuthorizationRequestDac;
        protected readonly ICommonBO _commonBo;
        public DsdAuthorizationRequestBO(ICommonBO commonBO, IDsdAuthorizationRequestDac dsdAuthorizationRequestDac)
        {
            this._dsdAuthorizationRequestDac = dsdAuthorizationRequestDac;
            this._commonBo = commonBO;
        }

       
        public async Task<IEnumerable<VendorDomainDto>> GetDsdVendors(string userId, string groupName="")
        {
            IEnumerable<VendorDomainDto> vendorList = await _commonBo.GetAssociatedVendorListForExternalUser(userId, groupName);

            if(vendorList != null && vendorList.Count() > 0)
            {
                vendorList = vendorList.Where(x => x.VendorType == AppConstants.VENDOR_TYPE_DSD).OrderBy(x=> x.VendorNumber);
            }
            return vendorList;
        }


        public async Task<IEnumerable<VendorServiceDto>> GetStoresServicedByVendor(int[] vendorNumbers)
        {
            string resource = string.Empty;
            System.Net.Http.HttpResponseMessage response;
            IEnumerable<VendorServiceDto> vendorServiceList = new List<VendorServiceDto>();
            IEnumerable<VendorServiceDto> tempvendorServiceList = new List<VendorServiceDto>();

            VendorServiceDto vendorServiceDto = null;
            foreach (int vendor in vendorNumbers)
            {
                vendorServiceDto = new VendorServiceDto();
                vendorServiceDto.VendorNumber = vendor;
                resource = "api/GetStoresServiced";
                response = await _commonBo.GetHttpResponseViaPost(resource, vendorServiceDto);

                tempvendorServiceList = new List<VendorServiceDto>();
                if (response.IsSuccessStatusCode)
                {
                    tempvendorServiceList = await response.Content.ReadAsAsync<IEnumerable<VendorServiceDto>>();
                }

                //vendorServiceList = vendorServiceList.Union(tempvendorServiceList, new VendorServiceDtoComparer());

                vendorServiceList = vendorServiceList.Union(tempvendorServiceList);

            }
            
            
            return vendorServiceList;
        }

        public async Task<bool> SaveDsdVendorStoreAuthorization(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            List<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList = new List<DsdAuthRequestStoreDto>();

            IEnumerable<VendorServiceDto> vendorServiceList = new List<VendorServiceDto>();
            DsdAuthRequestStoreDto dsdAuthRequestStoreDto = null;

            vendorServiceList = await GetStoresServicedByVendor(dsdVendorStoreAuthorizationDto.VendorNumbers);

            if (!dsdVendorStoreAuthorizationDto.IsAllServicedStores)
            {
                vendorServiceList = vendorServiceList.Where(r => dsdVendorStoreAuthorizationDto.StoreNumbers.Contains(r.StoreNumber.Value));
            }                     

            foreach (VendorServiceDto vendorServiceDto in vendorServiceList)
            {                
                dsdAuthRequestStoreDto = new DsdAuthRequestStoreDto();

                dsdAuthRequestStoreDto = Mapper.Map<DsdAuthRequestStoreDto>(vendorServiceDto);
               
                dsdAuthRequestStoreDto.ItemFormID = dsdVendorStoreAuthorizationDto.ItemFormID;
                //TODO change the logic for View/edit store authorization
                dsdAuthRequestStoreDto.IsActive = "Y";
                dsdAuthRequestStoreDto.CreatedBy = dsdVendorStoreAuthorizationDto.CreatedBy;
                dsdAuthRequestStoreDto.LastUpdatedBy = dsdVendorStoreAuthorizationDto.CreatedBy;
                dsdAuthRequestStoreDto.LastUpdatedDate = DateTime.Now;
                dsdAuthRequestStoreDto.CreatedDate = DateTime.Now;
                dsdAuthRequestStoreDtoList.Add(dsdAuthRequestStoreDto);
            }


            //SetUserID(dsdAuthRequestStoreDtoList, dsdVendorStoreAuthorizationDto.CreatedBy);

            bool retValue = false;

            if (!dsdVendorStoreAuthorizationDto.IsAllServicedStores)
            {
                retValue = await _dsdAuthorizationRequestDac.SaveDsdVendorStoreAuthorization(dsdAuthRequestStoreDtoList);
            }
            else
            {
                retValue = await _dsdAuthorizationRequestDac.DeleteDsdVendorAuthorizationsByItemFormAndVendors(dsdVendorStoreAuthorizationDto);
                retValue = await _dsdAuthorizationRequestDac.BulkInsertDsdVendorStoreAuthorization(dsdAuthRequestStoreDtoList);                
            }
                

            if (retValue)
            {
                bool isOverlapExist = await _dsdAuthorizationRequestDac.IsOverlappedVendorStoreAuthExistsByItemForm(dsdVendorStoreAuthorizationDto.ItemFormID);

                if(isOverlapExist)
                    retValue =  false;
                else
                    retValue =  true;

            }

            return retValue;          

        }

        public async Task<bool> SaveDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList)
        {
            return await _dsdAuthorizationRequestDac.SaveDsdVendorStoreAuthorization(dsdAuthRequestStoreDtoList);
        }

        public async Task<IEnumerable<DsdVendorAuthorizationDto>> GetDsdVendorAuthorizations(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.GetDsdVendorAuthorizations(itemFormID);           
        }

        public async Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdVendorsByItemForm(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.GetAuthorizedDsdVendorsByItemForm(itemFormID);
        }

        public async Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdStatesByItemForm(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.GetAuthorizedDsdStatesByItemForm(itemFormID);
        }

        public async Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdCountiesByItemForm(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.GetAuthorizedDsdCountiesByItemForm(itemFormID);
        }

        public async Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdVendorStoreAuthorizationsByItemForm(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.GetDsdVendorStoreAuthorizationsByItemForm(itemFormID);
        }

        public async Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdVendorStoreAuthorizationsBySearchCriteria(VendorServiceDto vendorServiceDto)
        {
            return await _dsdAuthorizationRequestDac.GetDsdVendorStoreAuthorizationsBySearchCriteria(vendorServiceDto);
        }


        public async Task<IEnumerable<VendorDomainDto>> GetDSDVendorDataForInternalUser()
        {
            string resource = string.Empty;
            System.Net.Http.HttpResponseMessage response;
            IEnumerable<VendorDomainDto> vendorDomainDtoList = new List<VendorDomainDto>();

            resource = "api/GetDSDVendorDataForInternalUser";
            response = await _commonBo.GetHttpResponse(resource);

            if (response.IsSuccessStatusCode)
            {
                vendorDomainDtoList = await response.Content.ReadAsAsync<IEnumerable<VendorDomainDto>>();
            }

            if (vendorDomainDtoList != null && vendorDomainDtoList.Count() > 0)
                    vendorDomainDtoList = vendorDomainDtoList.OrderBy(o => o.VendorNumber);

            return vendorDomainDtoList;
        }

       

        public async Task<bool> ValidateAndSaveDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList, string userName)
        {
            //TODO Validations           

            var vendorStoreGroup = dsdAuthRequestStoreDtoList
                            .Where(x => x.IsActive == "Y")
                            .GroupBy(g => new { g.StoreNumber, g.IsActive })
                            .Select(group => new
                            {
                                StoreNumber = group.Key.StoreNumber,
                                IsActive = group.Key.IsActive,
                                Count = group.Count()
                            });
                        

            if (vendorStoreGroup.Where(c => c.Count > 1).ToList().Count() > 0)
                return false;

            dsdAuthRequestStoreDtoList = dsdAuthRequestStoreDtoList.Where(x => x.IsDirty == true);
            SetUserID(dsdAuthRequestStoreDtoList, userName);

            return await _dsdAuthorizationRequestDac.SaveDsdVendorStoreAuthorization(dsdAuthRequestStoreDtoList);

        }

        public async Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdOverlappedVendorStoreAuthorizationsByItemForm(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.GetDsdOverlappedVendorStoreAuthorizationsByItemForm(itemFormID);
        }

        public async Task<bool> IsOverlappedVendorStoreAuthExistsByItemForm(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.IsOverlappedVendorStoreAuthExistsByItemForm(itemFormID);
        }

        public async Task<bool> IsMultipleDsdVendorsSubmittingSameGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            return await _dsdAuthorizationRequestDac.IsMultipleDsdVendorsSubmittingSameGtin(dsdVendorStoreAuthorizationDto);
        }

        public async Task<bool> IsOverlappedVendorStoreAuthExistsByGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            return await _dsdAuthorizationRequestDac.IsOverlappedVendorStoreAuthExistsByGtin(dsdVendorStoreAuthorizationDto);
        }

        public async Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdOverlappedVendorStoreAuthorizationsByGtin(decimal gtin)
        {
            return await _dsdAuthorizationRequestDac.GetDsdOverlappedVendorStoreAuthorizationsByGtin(gtin);
        }

        private void SetUserID(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList, string userName)
        {            

            if (dsdAuthRequestStoreDtoList != null && dsdAuthRequestStoreDtoList.Count() > 0)
            {
                foreach (var dsdAuthRequestStoreDto in dsdAuthRequestStoreDtoList)
                {
                    dsdAuthRequestStoreDto.CreatedBy = userName;
                    dsdAuthRequestStoreDto.LastUpdatedBy = userName;
                }
            }
        }


        public async Task ProcessDsdVendorStoreAuthorizationByGtin(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            List<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList = new List<DsdAuthRequestStoreDto>();
            DsdAuthRequestStoreDto dsdAuthRequestStoreDto = null;

            //Delete existing vendor store authrorizations added in Item from
            await _dsdAuthorizationRequestDac.DeleteDsdVendorAuthorizationsByItemForm(basicItemDefinitionDto.ItemFormID);

            IEnumerable<VendorDomainDto> dsdVendorsList = await GetDsdVendors(basicItemDefinitionDto.VendorContactID);

            IEnumerable<VendorServiceDto> vendorStoreAuthorizationList = await GetDsdVendorStoreAuthorizationByGtin(basicItemDefinitionDto);

            if (vendorStoreAuthorizationList != null && vendorStoreAuthorizationList.Count() > 0)
            {
                var includeVendorNumbers = new HashSet<int>(dsdVendorsList.Select(x => x.VendorNumber));
                vendorStoreAuthorizationList = vendorStoreAuthorizationList.Where(x => includeVendorNumbers.Contains(x.VendorNumber.Value)).ToList();

                foreach (VendorServiceDto storeAuthorization in vendorStoreAuthorizationList)
                {
                    dsdAuthRequestStoreDto = new DsdAuthRequestStoreDto();
                    dsdAuthRequestStoreDto = Mapper.Map<DsdAuthRequestStoreDto>(storeAuthorization);

                    dsdAuthRequestStoreDto.ItemFormID = basicItemDefinitionDto.ItemFormID;
                    dsdAuthRequestStoreDto.IsActive = "Y";
                    dsdAuthRequestStoreDto.CreatedBy = basicItemDefinitionDto.CreatedBy;
                    dsdAuthRequestStoreDto.LastUpdatedBy = basicItemDefinitionDto.CreatedBy;
                    dsdAuthRequestStoreDtoList.Add(dsdAuthRequestStoreDto);
                }
                if (vendorStoreAuthorizationList != null && vendorStoreAuthorizationList.Count() > 0)
                    await SaveDsdVendorStoreAuthorization(dsdAuthRequestStoreDtoList);
            }
               
        }

        public async Task ProcessDsdVendorStoreAuthorizationByModelItemCode(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            List<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList = new List<DsdAuthRequestStoreDto>();
            DsdAuthRequestStoreDto dsdAuthRequestStoreDto = null;

            //Delete existing vendor store authrorizations added in Item from
            await _dsdAuthorizationRequestDac.DeleteDsdVendorAuthorizationsByItemForm(basicItemDefinitionDto.ItemFormID);

            IEnumerable<VendorDomainDto> dsdVendorsList = await GetDsdVendors(basicItemDefinitionDto.VendorContactID);

            IEnumerable<VendorServiceDto> vendorStoreAuthorizationList = await GetDsdVendorStoreAuthorizationByItemCode(basicItemDefinitionDto);

            if(vendorStoreAuthorizationList != null && vendorStoreAuthorizationList.Count() > 0)
            {
                var includeVendorNumbers = new HashSet<int>(dsdVendorsList.Select(x => x.VendorNumber));
                vendorStoreAuthorizationList = vendorStoreAuthorizationList.Where(x => includeVendorNumbers.Contains(x.VendorNumber.Value)).ToList();

                foreach (VendorServiceDto storeAuthorization in vendorStoreAuthorizationList)
                {
                    dsdAuthRequestStoreDto = new DsdAuthRequestStoreDto();
                    dsdAuthRequestStoreDto = Mapper.Map<DsdAuthRequestStoreDto>(storeAuthorization);

                    dsdAuthRequestStoreDto.ItemFormID = basicItemDefinitionDto.ItemFormID;
                    dsdAuthRequestStoreDto.IsActive = "Y";
                    dsdAuthRequestStoreDto.CreatedBy = basicItemDefinitionDto.CreatedBy;
                    dsdAuthRequestStoreDto.LastUpdatedBy = basicItemDefinitionDto.CreatedBy;
                    dsdAuthRequestStoreDtoList.Add(dsdAuthRequestStoreDto);
                }
                if(vendorStoreAuthorizationList != null && vendorStoreAuthorizationList.Count() > 0)
                    await SaveDsdVendorStoreAuthorization(dsdAuthRequestStoreDtoList);
            }

        }


        private async Task<IEnumerable<VendorServiceDto>> GetDsdVendorStoreAuthorizationByGtin(BasicItemDefinitionDto basicItemDefinitionDto)
        {

            string resource = string.Empty;
            System.Net.Http.HttpResponseMessage response;
            IEnumerable<VendorServiceDto> vendorStoreAuthorizationList = new List<VendorServiceDto>();

            VendorServiceDto vendorServiceDto = new VendorServiceDto();
            vendorServiceDto.Gtin = basicItemDefinitionDto.GTIN;

            resource = "api/GetStoresServiced";
            response = await _commonBo.GetHttpResponseViaPost(resource, vendorServiceDto);

            if (response.IsSuccessStatusCode)
            {
                vendorStoreAuthorizationList = await response.Content.ReadAsAsync<IEnumerable<VendorServiceDto>>();
            }

            return vendorStoreAuthorizationList;
        }

        private async Task<IEnumerable<VendorServiceDto>> GetDsdVendorStoreAuthorizationByItemCode(BasicItemDefinitionDto basicItemDefinitionDto)
        {

            string resource = string.Empty;
            System.Net.Http.HttpResponseMessage response;
            IEnumerable<VendorServiceDto> vendorStoreAuthorizationList = new List<VendorServiceDto>();

            VendorServiceDto vendorServiceDto = new VendorServiceDto();
            vendorServiceDto.ItemCode = basicItemDefinitionDto.ItemCode;

            resource = "api/GetStoresServiced";
            response = await _commonBo.GetHttpResponseViaPost(resource, vendorServiceDto);

            if (response.IsSuccessStatusCode)
            {
                vendorStoreAuthorizationList = await response.Content.ReadAsAsync<IEnumerable<VendorServiceDto>>();
            }

            return vendorStoreAuthorizationList;
        }

        public async Task<BasicItemDefinitionDto> GetBasicItemDefnitionDataByGTIN(BasicItemDefinitionDto basicItemDefinitionDto)
        {

            PIDMDataDto pidmItemData = await _commonBo.GetPMDSDataByGTIN(basicItemDefinitionDto.GTIN);

            if (pidmItemData != null && pidmItemData.BasicItemDefinition != null)
            {
                BasicItemDefinitionDto pidmBasicItemDefinitionDto = pidmItemData.BasicItemDefinition;
                pidmBasicItemDefinitionDto.ItemFormID = basicItemDefinitionDto.ItemFormID;
                pidmBasicItemDefinitionDto.ItemFormDisplayId = basicItemDefinitionDto.ItemFormDisplayId;

                pidmBasicItemDefinitionDto.FormTypeID = basicItemDefinitionDto.FormTypeID;
                pidmBasicItemDefinitionDto.FormStatusID = basicItemDefinitionDto.FormStatusID;
                pidmBasicItemDefinitionDto.FormActionID = basicItemDefinitionDto.FormActionID;
                pidmBasicItemDefinitionDto.SubmittedUserTypeID = basicItemDefinitionDto.SubmittedUserTypeID;

                pidmBasicItemDefinitionDto.CreatedBy = basicItemDefinitionDto.CreatedBy;
                pidmBasicItemDefinitionDto.LastUpdatedBy = basicItemDefinitionDto.LastUpdatedBy;      

                pidmBasicItemDefinitionDto.GTIN = basicItemDefinitionDto.GTIN;
                pidmBasicItemDefinitionDto.GTINCheckDigit = basicItemDefinitionDto.GTINCheckDigit;
                pidmBasicItemDefinitionDto.ExistingGtinIndicator = basicItemDefinitionDto.ExistingGtinIndicator;
                pidmBasicItemDefinitionDto.CompressedUPC = basicItemDefinitionDto.CompressedUPC;
                pidmBasicItemDefinitionDto.PriceLookupCode = basicItemDefinitionDto.PriceLookupCode;

                await _dsdAuthorizationRequestDac.SaveBasicItemDefinition(pidmBasicItemDefinitionDto);

                //Update ItemForm
                ItemFormDto itemForm = new ItemFormDto();
                itemForm.ID = pidmBasicItemDefinitionDto.ItemFormID;
                itemForm.FormStatusID = pidmBasicItemDefinitionDto.FormStatusID;
                itemForm.FormActionID = pidmBasicItemDefinitionDto.FormActionID;
                itemForm.ItemCode = pidmBasicItemDefinitionDto.ItemCode;
                itemForm.SubmittedUserTypeID = (int)pidmBasicItemDefinitionDto.SubmittedUserTypeID;
                itemForm.LastUpdatedBy = pidmBasicItemDefinitionDto.CreatedBy;
                await _commonBo.UpdateItemCodeForItemForm(itemForm);

                //DSD Vendor Authrorization 
                await ProcessDsdVendorStoreAuthorizationByGtin(basicItemDefinitionDto);
               
                basicItemDefinitionDto = await GetBasicItemDefinitionData(pidmBasicItemDefinitionDto.ItemFormDisplayId);

                return basicItemDefinitionDto;
            }
            else
                return null;
        }

        public async Task<List<ErrorDTO>> ValidateAndSaveModelItemCodeData(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            List<ErrorDTO> errorList = new List<ErrorDTO>();

            PIDMDataDto pidmItemData = await _commonBo.GetPMDSDataByItemCode(Convert.ToInt32(basicItemDefinitionDto.ItemCode));

            if (pidmItemData != null && pidmItemData.BasicItemDefinition != null)
            {
                
                // Check the item type is retail or non retail
                // If retail apply the RETAIL_PACK_TYPE_CODE='R' and ItemType to fetch on the regular pack
                // If non retail just return the BID retrived after apply the item type filter
                                

                //Validate the model Item code is not fall in to the item types RS, RM and WIP
                if ( pidmItemData.BasicItemDefinition.RetailPackType != "R")
                {
                    var error = await _commonBo.GetErrorMessage("BID15");
                    errorList.Add(error);
                }

                if (errorList.Count == 0)
                {
                    //No Errors. Save the BID data
                    await SaveItemDataByPmdsItemCode(basicItemDefinitionDto, pidmItemData);

                }

            }
            else
            {
                //No Record Found
                var error = await _commonBo.GetErrorMessage("BID15");
                errorList.Add(error);
            }

            return errorList;
        }

        public async Task<bool> SaveItemDataByPmdsItemCode(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData)
        {
            bool retValue = false;
            if (pidmItemData != null)
            {
                if (pidmItemData.BasicItemDefinition != null)
                {                    

                    BasicItemDefinitionDto pidmBasicItemDefinitionDto = new BasicItemDefinitionDto();

                    pidmBasicItemDefinitionDto = Mapper.Map<BasicItemDefinitionDto>(pidmItemData.BasicItemDefinition);

                    pidmBasicItemDefinitionDto.ItemFormDisplayId = basicItemDefinitionDto.ItemFormDisplayId;
                    pidmBasicItemDefinitionDto.ItemFormID = basicItemDefinitionDto.ItemFormID;

                    pidmBasicItemDefinitionDto.FormTypeID = basicItemDefinitionDto.FormTypeID;
                    pidmBasicItemDefinitionDto.FormStatusID = basicItemDefinitionDto.FormStatusID;
                    pidmBasicItemDefinitionDto.FormActionID = basicItemDefinitionDto.FormActionID;
                    pidmBasicItemDefinitionDto.SubmittedUserTypeID = basicItemDefinitionDto.SubmittedUserTypeID;
                    pidmBasicItemDefinitionDto.VendorContactID = basicItemDefinitionDto.VendorContactID;

                    pidmBasicItemDefinitionDto.CreatedBy = basicItemDefinitionDto.CreatedBy;
                    pidmBasicItemDefinitionDto.LastUpdatedBy = basicItemDefinitionDto.LastUpdatedBy;
                    
                    pidmBasicItemDefinitionDto.ExistingGtinIndicator = basicItemDefinitionDto.ExistingGtinIndicator;
                    pidmBasicItemDefinitionDto.CompressedUPC = basicItemDefinitionDto.CompressedUPC;
                    pidmBasicItemDefinitionDto.PriceLookupCode = basicItemDefinitionDto.PriceLookupCode;

                    await _dsdAuthorizationRequestDac.SaveBasicItemDefinition(pidmBasicItemDefinitionDto);

                    //Update ItemForm
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = pidmBasicItemDefinitionDto.ItemFormID;
                    itemForm.FormStatusID = pidmBasicItemDefinitionDto.FormStatusID;
                    itemForm.FormActionID = pidmBasicItemDefinitionDto.FormActionID;
                    itemForm.ItemCode = pidmBasicItemDefinitionDto.ItemCode;
                    itemForm.SubmittedUserTypeID = (int)pidmBasicItemDefinitionDto.SubmittedUserTypeID;
                    itemForm.LastUpdatedBy = pidmBasicItemDefinitionDto.CreatedBy;
                    await _commonBo.UpdateItemCodeForItemForm(itemForm);
                }
              

                //DSD Vendor Authrorization 
                await ProcessDsdVendorStoreAuthorizationByModelItemCode(basicItemDefinitionDto);
                //TODO : other tabs data     
            }

            return retValue;

        }

        public async Task<BasicItemDefinitionDto> GetBasicItemDefinitionData(long itemFormDisplayId)
        {
            return await _dsdAuthorizationRequestDac.GetBasicItemDefinitionData(itemFormDisplayId);
        }

        public async Task<IEnumerable<VendorDomainDto>> GetDsdVendorsExistForItemForm(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.GetDsdVendorsExistForItemForm(itemFormID);
        }
        public async Task<bool> DeleteDsdVendorsNotInPackagingHierarchy(int itemFormID)
        {
            return await _dsdAuthorizationRequestDac.DeleteDsdVendorsNotInPackagingHierarchy(itemFormID);
        }
    }
}
