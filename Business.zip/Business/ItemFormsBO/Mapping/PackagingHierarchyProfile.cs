﻿using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsBO.CustomResolver;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class PackagingHierarchyProfile : Profile
    {
        public PackagingHierarchyProfile()
        {
            CreateMap<PMDSPackagingHierarchyDto, PackagingHierarchyDto>()
                .ForMember(dest => dest.PalletGTIN,
                          opts => opts.MapFrom(src => src.PalletGTIN));
        }   
    }
}
