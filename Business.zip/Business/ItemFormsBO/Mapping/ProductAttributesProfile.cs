﻿using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class ProductAttributesProfile : Profile
    {
        public ProductAttributesProfile()
        {
            CreateMap<PMDSProductMandatoryAttributesDto, ProductAttributeDto>()
               .ForMember(dest => dest.ProductAttributeGroupDescription,
                         opts => opts.MapFrom(src => src.ProductAttributeGroup))
               .ForMember(dest => dest.AttributeCode,
                      opts => opts.MapFrom(src => src.ProductAttributeCode))
               .ForMember(dest => dest.AttributeDescription,
                      opts => opts.MapFrom(src => src.ProductAttribute))              
               .ForMember(dest => dest.ProductAttributeType,
                      opts => opts.MapFrom(src => src.AttributeType))
               .ForMember(dest => dest.ItemGroupType,
                      opts => opts.MapFrom(src => src.ItemGroupTypeCode))
               .ForMember(dest => dest.ItemGroupCode,
                      opts => opts.MapFrom(src => src.ItemGroupCode))
               .ForMember(dest => dest.DataType, 
                          opts => opts.MapFrom(src => src.DataType));
          
            //.ForMember(dest => dest.AttributeValueSequenceNumber,
            //         opts => opts.MapFrom(src => src.SequenceNumber))


        }
    }
}
