﻿using Publix.S0VPITEM.ItemFormsEntities;
using AutoMapper;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class ErrorProfile : Profile
    {
        public ErrorProfile()
        {
            CreateMap<ErrorDTO, WarningDTO>();
        }
    }
}
