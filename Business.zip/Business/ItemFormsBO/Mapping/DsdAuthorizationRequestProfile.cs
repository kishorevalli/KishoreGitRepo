﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class DsdAuthorizationRequestProfile:Profile
    {
        public DsdAuthorizationRequestProfile()
        {
            CreateMap<PMDSVendorServiceDto, VendorServiceDto>()
                .ForMember(dest => dest.VendorNumber,
                          opts => opts.MapFrom(src => src.VendorNumber));

            CreateMap<PMDSVendorDto, VendorDomainDto>()
               .ForMember(dest => dest.VendorNumber,
                         opts => opts.MapFrom(src => src.VendorNumber));

            CreateMap<VendorServiceDto, DsdAuthRequestStoreDto>()
              .ForMember(dest => dest.VendorNumber,
                        opts => opts.MapFrom(src => src.VendorNumber));
        }
    }
}
