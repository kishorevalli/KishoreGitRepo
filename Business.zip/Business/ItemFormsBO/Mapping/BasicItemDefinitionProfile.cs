﻿using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class BasicItemDefinitionProfile:Profile
    {

        public BasicItemDefinitionProfile()
        {
            CreateMap<PMDSBasicItemDefinitionDto, BasicItemDefinitionDto>()
                .ForMember(dest => dest.GTIN, opts => opts.MapFrom(src => src.GTIN));
        }
    }
}
