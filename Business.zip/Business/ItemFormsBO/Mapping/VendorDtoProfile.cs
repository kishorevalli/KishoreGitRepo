﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.VendorPortalAdminSvc;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class VendorDtoProfile : Profile
    {
        public VendorDtoProfile()
        {
            CreateMap<VendorPortalAdminSvc.VendorDTO, Publix.S0VPITEM.ItemFormsEntities.VendorDto>();
        }
       
    }
}
