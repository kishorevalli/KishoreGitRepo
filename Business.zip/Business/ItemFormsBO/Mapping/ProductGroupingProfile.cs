﻿using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class ProductGroupingProfile : Profile
    {
        public ProductGroupingProfile()
        {
            CreateMap<PMDSProductGroupingDto, ProductGroupingLinearDto>()
             .ForMember(dest => dest.ChildProductGroupType,
                      opts => opts.MapFrom(src => src.CHILDGROUPTYPECODE))
             .ForMember(dest => dest.ChildProductGroupCode,
                      opts => opts.MapFrom(src => src.CHILDGROUPCODE))
             .ForMember(dest => dest.ChildProductGroupDescription,
                      opts => opts.MapFrom(src => src.CHILDFULLDESCRIPTION))
             .ForMember(dest => dest.ParentProductGroupType,
                      opts => opts.MapFrom(src => src.PARENTGROUPTYPECODE))
             .ForMember(dest => dest.ParentProductGroupCode,
                        opts => opts.MapFrom(src => src.PARENTGROUPCODE))
             .ForMember(dest => dest.ParentProductGroupDescription,
                        opts => opts.MapFrom(src => src.PARENTFULLDESCRIPTION))
             .ForMember(dest => dest.GrandParentProductGroupType,
                        opts => opts.MapFrom(src => src.GRANDPARENTGROUPTYPECODE))
             .ForMember(dest => dest.GrandParentProductGroupCode,
                        opts => opts.MapFrom(src => src.GRANDPARENTITEMGROUPCODE))
             .ForMember(dest => dest.GrandParentProductGroupDescription,
                        opts => opts.MapFrom(src => src.GRANDPARENTFULLDESCRIPTION))
            .ForMember(dest => dest.ItemTag,
                        opts => opts.MapFrom(src => src.ITEMTAG));

            CreateMap<PMDSChildGroupTypeCode, ProductGroupType>()
             .ForMember(dest => dest.Code,
                      opts => opts.MapFrom(src => src.CHILDGROUPTYPECODE))
            .ForMember(dest => dest.ItemTag,
                        opts => opts.MapFrom(src => src.ITEMTAG));

            CreateMap<PIDMProductGroupVBGVendorDto, ProductGroupingVendorDto>()
           .ForMember(dest => dest.VendorNumber,
                    opts => opts.MapFrom(src => src.VendorNumber))
           .ForMember(dest => dest.VendorDescription,
                    opts => opts.MapFrom(src => src.VendorDescription));

            CreateMap<PIDMProductGroupVBGDto, ProductVBGGroupDto>()
            .ForMember(dest => dest.Code,
                     opts => opts.MapFrom(src => src.code))
            .ForMember(dest => dest.Description,
                     opts => opts.MapFrom(src => src.Description))
           .ForMember(dest => dest.Vendors,
                       opts => opts.MapFrom(src => src.Vendors));
        }
    }
}
