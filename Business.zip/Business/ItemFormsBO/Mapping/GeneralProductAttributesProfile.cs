﻿using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsBO.CustomResolver;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class GeneralProductAttributesProfile : Profile
    {
       public GeneralProductAttributesProfile()
        {

            CreateMap<PMDSGeneralProductAttributesDto, GeneralProductAttributesDto>()
             .ForMember(dest => dest.PerishableItem,
                      opts => opts.MapFrom(src => src.PerishableIndicator))
             .ForMember(dest => dest.Narcotic,
                      opts => opts.MapFrom(src => src.NarcoticFlag))
             .ForMember(dest => dest.DrugScheduleCode,
                      opts => opts.MapFrom(src => src.DrugSchedule))
             .ForMember(dest => dest.Liquor,
                      opts => opts.MapFrom(src => src.LiquorSwitch))
             .ForMember(dest => dest.Tobacco,
                        opts => opts.MapFrom(src => src.TobaccoIndicator))
             .ForMember(dest => dest.TagCount,
                        opts => opts.MapFrom(src => src.ShelfTagCount))
             .ForMember(dest => dest.SeasonalItem,
                        opts => opts.MapFrom(src => src.SeasonalIndicator))
             .ForMember(dest => dest.WhseShelfLife,
                        opts => opts.MapFrom(src => src.WarehouseShelfLife))
             .ForMember(dest => dest.OrganicTypesID,
                        opt => opt.ResolveUsing<OrganicItemValueResolver, string>(src => src.OrganicItem))
             .ForMember(dest => dest.IgnoreQuantityCheck,
                        opts => opts.MapFrom(src => src.QuantityRequired))
            .ForMember(dest => dest.Disinfectant,
                        opts => opts.MapFrom(src => src.DisInfectent));
        }
    }
}
