﻿using AutoMapper;
using Publix.S0VPITEM.ItemFormsDac;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsBO.CustomResolver
{
    //  public class CustomResolver : IValueResolver<object, object, int>
    //{
    //    public int Resolve(object source, object destination, int member, ResolutionContext context)
    //    {
    //        return member;
    //    }
    //}

    public class OrganicItemValueResolver : IMemberValueResolver<object, object, string, int>
    {
        protected readonly IGeneralProductAttributesDac _generalProductAttributesDac;
        //public OrganicItemValueResolver(IGeneralProductAttributesDac generalProductAttributesDac)
        //{
        //    _generalProductAttributesDac = generalProductAttributesDac;
        //}
        public OrganicItemValueResolver()
        {
            _generalProductAttributesDac = new GeneralProductAttributesDac();
        }
        public int Resolve(object source, object destination, string sourceMember, int destinationMember, ResolutionContext context)
        {
            IEnumerable<OrganicType> organicTypes = Task.Run(async () => await _generalProductAttributesDac.GetOrganicTypes()).Result;
            var organicTypeFind = organicTypes.Where(org => org.PMDSName == sourceMember).FirstOrDefault();
            if (organicTypeFind != null)
            {
                return organicTypeFind.Code;
            }
            return 4;
        }
    }


}
