﻿using AutoMapper;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Mapping
{
    public class ScaleItemDetailsProfile:Profile
    {
        public ScaleItemDetailsProfile()
        {
            CreateMap<PMDSScaleItemDetailsDto, ScaleInfoDto>()
                .ForMember(dest => dest.BackroomScaleIndicator, opts => opts.MapFrom(src => src.BackRoomScaleIn))
                .ForMember(dest => dest.ScaleDescription1, opts => opts.MapFrom(src => src.ScaleDescFrstLn))
                .ForMember(dest => dest.ScaleDescription2, opts => opts.MapFrom(src => src.ScaleDescScndLn))
                .ForMember(dest => dest.CalorieInformation, opts => opts.MapFrom(src => src.CalorieUnit))
                .ForMember(dest => dest.Tare, opts => opts.MapFrom(src => src.Tare))
                .ForMember(dest => dest.ScaleExtraTextRequired, opts => opts.MapFrom(src => src.ExtraTextReqTag))
                .ForMember(dest => dest.NutritionCodeRequired, opts => opts.MapFrom(src => src.NutriFactReqTag))
                .ForMember(dest => dest.PriceModifier, opts => opts.MapFrom(src => src.PriceModifierEdi));

            CreateMap<PMDSScaleItemGradeDto, ScaleGradeDto>()
                .ForMember(dest => dest.FacilityGroupType, opts => opts.MapFrom(src => src.FkFacGrpTypCod))
                .ForMember(dest=>dest.FacilityGroupTypeDescription, opts=>opts.MapFrom(src=>src.FkFacGrpTypCodDesc))
                .ForMember(dest => dest.FacilityGroupCode, opts => opts.MapFrom(src => src.FkFacGrpCode))
                .ForMember(dest=>dest.FacilityGroupDescription, opts=>opts.MapFrom(src=>src.FkFacGrpCodeDesc))
                .ForMember(dest => dest.Grade, opts => opts.MapFrom(src => src.FkScaleGradeCode))
                .ForMember(dest=>dest.GradeDescription, opts=>opts.MapFrom(src=>src.FkScaleGradeCodeDesc));

            CreateMap<PMDSScaleItemLocationDto, ScaleLocationDto>()
                .ForMember(dest => dest.ScaleLocation, opts => opts.MapFrom(src => src.FkScaleLocCode))
                .ForMember(dest=>dest.ScaleLocationDescription, opts => opts.MapFrom(src=>src.FkScaleLocCodeDesc))
                .ForMember(dest => dest.PLUNumber, opts => opts.MapFrom(src => src.PluCode))
                .ForMember(dest => dest.Action, opts => opts.MapFrom(src => src.FkScaleActNum))
                .ForMember(dest=>dest.ActionDescription, opts=>opts.MapFrom(src=>src.FkScaleActNumDesc));

            CreateMap<PMDSScaleItemOverrideDescDto, ScaleOverrideDescriptionDto>()
                .ForMember(dest => dest.OverrideDescriptionLine1, opts => opts.MapFrom(src => src.DescText1))
                .ForMember(dest => dest.OverrideDescriptionLine2, opts => opts.MapFrom(src => src.DescText2))
                .ForMember(dest => dest.FacilityGroupType, opts => opts.MapFrom(src => src.FkFacGrpTypCod))
                .ForMember(dest => dest.FacilityGroupTypeDescription, opts => opts.MapFrom(src => src.FkFacGrpTypCodDesc))
                .ForMember(dest => dest.FacilityGroupCode, opts => opts.MapFrom(src => src.FkFacGrpCode))
                .ForMember(dest => dest.FacilityGroupDescription, opts => opts.MapFrom(src => src.FkFacGrpCodeDesc));

            CreateMap<PMDSScaleItemShelfLifeDto, ScaleShelfLifeDto>()
                .ForMember(dest => dest.ShelfLifeDay, opts => opts.MapFrom(src => src.ShelfLifeDays))
                .ForMember(dest => dest.FacilityGroupType, opts => opts.MapFrom(src => src.FkFacGrpTypCod))
                .ForMember(dest => dest.FacilityGroupTypeDescription, opts => opts.MapFrom(src => src.FkFacGrpTypCodDesc))
                .ForMember(dest => dest.FacilityGroupCode, opts => opts.MapFrom(src => src.FkFacGrpCode))
                .ForMember(dest => dest.FacilityGroupDescription, opts => opts.MapFrom(src => src.FkFacGrpCodeDesc));

        }
    }
}
