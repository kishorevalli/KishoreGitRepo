﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsCommon;
using System.Net.Http;

namespace Publix.S0VPITEM.ItemFormsBO
{

    public class ShipperItemCompositionBO : IShipperItemCompositionBO
    {
        protected readonly IShipperItemCompositionDac _shipperItemCompositionDac;
        protected readonly ICommonBO _commonBo;
        public ShipperItemCompositionBO(ICommonBO commonBO, IShipperItemCompositionDac shipperItemCompositionDac)
        {
            this._shipperItemCompositionDac = shipperItemCompositionDac;
            this._commonBo = commonBO;
        }

        public async Task<bool> SaveAllShipperItemCompositionList(IEnumerable<ShipperItemCompositionDto> shipperCompositionList,int ItemFormID)
        {                 
            // Delete all the shippers items for the item form id           
           await _shipperItemCompositionDac.DeleteAllShipperCompositionItems(ItemFormID);
            // Call the insert shipper item for each loop of the collection in shipperCompositionList
            foreach (ShipperItemCompositionDto shipperItemComposition in shipperCompositionList)
                await _shipperItemCompositionDac.InsertShipperCompositionItem(shipperItemComposition);
            return true;
        }

        public async Task<bool> SaveShipperItemCompositions(IEnumerable<ShipperItemCompositionDto> shipperCompositionList, int ItemFormID)
        {
            // retrive the existing shipper item composition from database
            List<ShipperItemCompositionDto> DBShipperCompositionList = GetShipperCompositionItems(ItemFormID).Result.ToList();
            List<ShipperItemCompositionDto> UIShipperCompositionList = shipperCompositionList.ToList();

            // compare with the shipper item compositions which is coming from UI

            // issue a delete statements which is being deleted
            DBShipperCompositionList.Except(UIShipperCompositionList,new ShipperItemCompositionComparer())
                .ToList().ForEach(shipperitem => _shipperItemCompositionDac.DeleteShipperCompositionItem(shipperitem));
            
            // update statements for updated
            UIShipperCompositionList.Intersect(DBShipperCompositionList, new ShipperItemCompositionComparer())
                .ToList().ForEach(shipperitem => _shipperItemCompositionDac.SaveShipperCompositionItems(shipperitem));

            // insert statements for newly added shipper item composition
            UIShipperCompositionList.Except(DBShipperCompositionList, new ShipperItemCompositionComparer())
              .ToList().ForEach(shipperitem => _shipperItemCompositionDac.InsertShipperCompositionItem(shipperitem)); 
         
            return true;
        }


        public async Task<IEnumerable<ShipperItemCompositionDto>> GetShipperCompositionItems(int ItemFormID)
        {
            return await _shipperItemCompositionDac.GetShipperCompositionItems(ItemFormID);
        }

        public async Task<int> GetCaseType(int ItemFormID)
        {
            return await _shipperItemCompositionDac.GetCaseType(ItemFormID);
        }

        public async Task<int> GetShipperSubDepartmentCode(int ItemFormID)
        {
            return await _shipperItemCompositionDac.GetShipperSubDepartmentCode(ItemFormID);
        }

        public async Task<int> GetProductGroupingSubDepartmentCode(int ItemFormID)
        {
            return await _shipperItemCompositionDac.GetProductGroupingSubDepartmentCode(ItemFormID);
        }

        public async Task<int> DeleteShipperItemCompositionList(int ItemFormID)
        {
            return await _shipperItemCompositionDac.DeleteShipperItemCompositionList(ItemFormID);
        }

        public async Task<ItemValidationDTO> ValidateShipperItemComposition(IEnumerable<ShipperItemCompositionDto> shipperItemComposition)
        {
            // TODO validation
            ItemValidationDTO Validation = new ItemValidationDTO();
            Validation.TabName = "Shipper Item Composition";
            List<ErrorDTO> errorList = new List<ErrorDTO>();
            List<WarningDTO> warningsList = new List<WarningDTO>();
            Validation.Errors = errorList;
            Validation.Warnings = warningsList;
            return await Task.FromResult(Validation);
        }




        public async Task<ShipperItemCompositionDto> ValidateShipperItemCompositionByItemCode(int itemid, string userId, string groupName,UserType CreatedByUserTypeID)
        {
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetShipperCompositionItemByItemID/" + itemid);
            System.Net.Http.HttpResponseMessage PMDSVendorsResponse = await _commonBo.GetHttpResponse("api/GetVendorsForShipperCompositionItem/" + itemid);
            ShipperItemCompositionDto pidmShipperItemData;

            if (response.IsSuccessStatusCode)
            {
                pidmShipperItemData = response.Content.ReadAsAsync<ShipperItemCompositionDto>().Result;

                if (pidmShipperItemData != null &&( pidmShipperItemData.CompositionItemTypeCode == "FG" || pidmShipperItemData.CompositionItemTypeCode == "RI"))
                {
                    IEnumerable<VendorDomainDto> loggedInVendors = await _commonBo.GetAssociatedVendorListForExternalUser(userId, groupName);

                    IEnumerable<int> PMDSvendors = PMDSVendorsResponse.Content.ReadAsAsync<IEnumerable<int>>().Result;

                    Boolean IsVendorCreated = false;
                    if (CreatedByUserTypeID == UserType.Vendor)
                        IsVendorCreated = true;

                    if (pidmShipperItemData != null && IsVendorCreated)
                    {                       
                        if (loggedInVendors.ToList().Any(vendor => PMDSvendors.Contains(vendor.VendorNumber)))
                            return pidmShipperItemData;
                        else
                            return null;
                    }
                    else if (pidmShipperItemData != null && !IsVendorCreated)
                        return pidmShipperItemData;
                    else if (pidmShipperItemData == null)
                        return null;
                }
                else
                    return null;
            }            
            return null;
            
        }

        public async Task<ShipperItemCompositionDto> ValidateShipperItemCompositionByGTIN(decimal GTIN, string userId, string groupName, UserType CreatedByUserTypeID)
        {
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetShipperCompositionItemByGTIN/" + GTIN);
            System.Net.Http.HttpResponseMessage PMDSVendorsResponse = await _commonBo.GetHttpResponse("api/GetVendorsForShipperCompositionGTIN/" + GTIN);
            ShipperItemCompositionDto pidmShipperItemData;

            // check the GTIN is in PMDS
            // Check it is avail for vendor
            // else check it is avaiable in item form db (only for vendor)
            // check is it avail for the vendor  (only for vendor)
            // if none match return null
            if (response.IsSuccessStatusCode)
            {
                pidmShipperItemData = response.Content.ReadAsAsync<ShipperItemCompositionDto>().Result;
                if (pidmShipperItemData.CompositionItemTypeCode == "FG" || pidmShipperItemData.CompositionItemTypeCode == "RI")
                {

                    IEnumerable<VendorDomainDto> loggedInVendors = await _commonBo.GetAssociatedVendorListForExternalUser(userId, groupName);
                      IEnumerable<int> PMDSvendors = PMDSVendorsResponse.Content.ReadAsAsync<IEnumerable<int>>().Result;

                Boolean IsVendorCreated = false;
                if (CreatedByUserTypeID == UserType.Vendor)
                    IsVendorCreated = true;

                if (pidmShipperItemData != null && IsVendorCreated)
                {
                        if (loggedInVendors.ToList().Any(vendor => PMDSvendors.Contains(vendor.VendorNumber)))
                            return pidmShipperItemData;
                    else
                        GetShipperItemCompositionFromItemFormDB(GTIN, loggedInVendors);
                }
                else if (pidmShipperItemData != null && !IsVendorCreated)
                    return pidmShipperItemData;
                else if (pidmShipperItemData == null && IsVendorCreated)
                    return GetShipperItemCompositionFromItemFormDB(GTIN, loggedInVendors);
                else if (pidmShipperItemData == null && !IsVendorCreated)
                    return _shipperItemCompositionDac.CheckShipperItemCompositionGTINExistInItemForm(GTIN).Result.FirstOrDefault();
                }
                else
                    return null;
            }
            return null;
        }

        // IsCompositionGTINAuthorizedForUser()

        public  ShipperItemCompositionDto GetShipperItemCompositionFromItemFormDB(decimal GTIN, IEnumerable<VendorDomainDto> loggedInVendors)
        {
           IEnumerable<ShipperItemCompositionDto> shipperCompositionItems = _shipperItemCompositionDac.CheckShipperItemCompositionGTINExistInItemForm(GTIN).Result;            
            List<ShipperItemCompositionDto> matchedShipperCompositionItems = new List<ShipperItemCompositionDto>(); ;

            foreach (var shipperCompositionItem in shipperCompositionItems)
            {
                IEnumerable<VendorDomainDto> matchedshipperCompositionItemVendors =  _commonBo.GetAssociatedVendorListForExternalUser(shipperCompositionItem.CreatedBy,"").Result;

                if (loggedInVendors.Intersect(matchedshipperCompositionItemVendors, new VendorDomainComparer()).Count() == matchedshipperCompositionItemVendors.Count())
                {
                    if(loggedInVendors.Count() > 0 && matchedshipperCompositionItemVendors.Count() > 0)
                    matchedShipperCompositionItems.Add(shipperCompositionItem);
                }
            }           
            return matchedShipperCompositionItems.FirstOrDefault();
        }



    }
}
