﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface IProductGroupingBO
    {
        Task<IEnumerable<ProductGroupingDto>> GetProductGrouping(int ItemFormID);
        Task<IEnumerable<ProductGroupingDto>> GetProductGroupingByItemCode(int ItemCode, int ModelGroupCodeType);
        Task<IEnumerable<ProductGroupType>> GetChildItemGroupTypes();
        Task<IEnumerable<LookupDto>> GetItemGroupCodes(string GroupType);
        Task<IEnumerable<ProductVBGGroupDto>> GetVBGGroupCodes(List<int> VendorNumbers);
        Task<IEnumerable<ProductGroupingDto>> GetParentGroupTypesAndCodes(string GroupType, int GroupCode);
        Task<ItemValidationDTO> ValidateProductGrouping(List<ProductGroupingDto> productGroupingList);
        Task<bool> SaveProductGrouping(List<ProductGroupingDto> productGroupingList, int ItemFormID, string currentUser, UserType SubmittedUserTypeID, int? FormStatusID = null, int? FormActionID = null);
        Task<bool> SaveFAMProductGrouping(List<ProductGroupingDto> productGroupingList, int ItemFormID, string currentUser, UserType SubmittedUserTypeID, int? FormStatusID = null, int? FormActionID = null);
        Task<IEnumerable<ProductPriceGroupDto>> GetProductPriceGroup(string SearchBy, string SearchValue);
        Task<IEnumerable<ProductAdGroupDto>> GetProductAdGroup(string SearchBy, string SearchValue);
        Task<IEnumerable<ProductGroupingVendorDto>> GetVBGVendors(int ItemFormID);
        Task<IEnumerable<LookupDto>> GetSubDepartments();
        Task<IEnumerable<LookupDto>> GetCategory(int SubDepartment);
        Task<IEnumerable<LookupDto>> GetFamilyGroup(int SubDepartment, int Category);
        Task<int> GetSubmittedItemFormIDWithSameGTIN(int ItemFormID);
        Task<bool> CopyProductGroupingOnSubmit(int ItemFormID);
    }
}
