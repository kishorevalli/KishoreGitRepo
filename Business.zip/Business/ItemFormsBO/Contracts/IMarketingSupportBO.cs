﻿using Publix.S0VPITEM.ItemFormsEntities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface IMarketingSupportBO
    {
        Task<IEnumerable<LookupDto>> GetPromoSupportFrequency();
        Task<IEnumerable<LookupDto>> GetUnitCostUOM();
        Task<MarketingInfoDto> GetMarketingInfo(int ItemFormID);
        Task<ItemValidationDTO> ValidateMarketingInfo(MarketingInfoDto marketingInfo);
        Task<bool> SaveMarketingInfo(MarketingInfoDto marketingInfo);
        Task<IEnumerable<FormCommentDto>> GetFormComment(int ItemFormID, int UserType);
        Task<bool> SaveFormComment(FormCommentDto formComment);
        Task<bool> CloneSimilarItemForm(int ItemFormID);

    }
}
