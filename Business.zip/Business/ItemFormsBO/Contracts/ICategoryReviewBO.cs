﻿using ClosedXML.Excel;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface ICategoryReviewBO
    {
        //Task<IEnumerable<LookupDto>> GetRSSListByBuyerID(int BuyerID);
        Task<IEnumerable<CategoryReviewDto>> GetCategoryReviewReport(int BuyerID);
        Task<XLWorkbook> BuildExcelFile(List<CategoryReviewDto> CategoryReviewList);
    }
}
