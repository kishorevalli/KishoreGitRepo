﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface IBasicItemDefinitionBO
    {
        Task<IEnumerable<ItemTypeDto>> GetItemTypes();

        Task<IEnumerable<ReuseItemCodeDto>> GetReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto);

        Task<IEnumerable<ReuseItemCodeDto>> GetAvailableItemFormReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto);
        Task<IEnumerable<LookupDto>> GetReuseItemSubDepartments();

        Task<ReuseItemCodeDto> IsSelectedReuseItemCodeAlreadyUsed(ReuseItemCodeDto reuseItemCodeDto);

        Task<bool> SaveReuseItemCode(ReuseItemCodeDto reuseItemCodeDto);

        Task<IEnumerable<LookupDto>> GetSubmissionReasons();
        Task<IEnumerable<LookupDto>> GetItemCaseTypes();
        Task<IEnumerable<LookupDto>> GetRetailPackTypes();
        Task<IEnumerable<LookupDto>> GetUnitOfMeasures();
        Task<IEnumerable<LookupDto>> GetFacilityGroups();
        Task<IEnumerable<LookupDto>> GetScaleActionCodes();
        Task<IEnumerable<LookupDto>> GetAttributeCodes();
        Task<IEnumerable<LookupDto>> GetItemAttributeGroups();



        Task<bool> SaveBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto);

        Task<BasicItemDefinitionDto> GetBasicItemDefinitionData(int itemFormId);

        Task<long> ConvertCompressedUPCToGTIN(int compressedUPC);
        Task<long> ConvertPLUToGTIN(int priceLookUp);
        Task<IEnumerable<long>> GetItemFormsDisplayIDs(string userId);
        Task<ItemValidationDTO> ValidateBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto);
        //Task<ErrorDTO> ValidateGTIN(decimal GTIN, string formattedGtin, int? checkDigit, UserType submittedUserType);
        Task<ErrorDTO> ValidateGTIN(BasicItemDefinitionDto basicItemDefinition);
        Task<int> GenerateCheckDigitFromGTIN(string GTIN);
        Task<BasicItemDefinitionDto> SaveItemDataByPmdsGTIN(BasicItemDefinitionDto basicItemDefinitionDto);
        Task<bool> SaveItemDataByPmdsItemCode(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData);
        Task<PMDSGTINDto> IsGTINExists(decimal GTIN);

        Task<Boolean> isGTINExistInPMDS(Decimal gtin);
        Task<ReuseItemCodeDto> IsReuseItemCodeExist(int reuseItemCode);

        Task<ModelProductItemValueDto> GetModelProductItemValues(int itemFormID);

        Task<bool> DeleteModelProductItemValues(int itemFormID);

        Task<List<ErrorDTO>> ValidateAndSaveModelItemCodeData(BasicItemDefinitionDto basicItemDefinitionDto);

        bool RemoveItemFormCache(String CacheKey);

        Task<IEnumerable<ItemDescriptionDto>> GetItemsMatchingDescription(ItemDescriptionDto itemDescriptionDto);

    //    Task<IEnumerable<GTINWithCheckdigitDto>> GetBasicItemDefinitionGTIN(int itemFormID);

        Task<IEnumerable<GTINWithCheckdigitDto>> GetNutritionalPanelGTIN(int itemFormID);

        Task<bool> RemoveGTINRetailPackRelatedInfo(GTINRetailPackInfoDto gtinRetailPackInfo);

        Task<IEnumerable<PackagingHierarchyDto>> GetExistingPackagingHierarchies(int itemFormID);

        Task<bool> SaveModelDataForPackagingHierarchy(BasicItemDefinitionDto basicItemDefinitionDto);
        Task<BasicItemDefinitionDto> GetPmdsBasicItemDefinitionDetailsByItemID(int ItemCode);
    }
}
