﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;


namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface ISubmitBO
    {
        Task<bool> PerformSubmitValidations(int itemFormID, string createdBy, UserType userType);
    }
}
