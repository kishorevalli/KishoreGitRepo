﻿using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface IScaleItemDetailsBO
    {
        Task<IEnumerable<LookupDto>> GetOverrideSaleDescription();
        Task<IEnumerable<LookupFlagDto>> GetScaleLocation();
        Task<IEnumerable<LookupDto>> GetScaleGrade();
        Task<IEnumerable<LookupDto>> GetScaleActionCodes();
        //Task<IEnumerable<LookupDto>> GetFacilityGroupByType(string Type);
        //Task<IEnumerable<LookupDto>> GetFacilityGroupTypes();
        Task<bool> SaveScaleInfo(ScaleInfoDto scaleItemDetails);
        Task<ScaleInfoDto> GetScaleInfo(int itemFormID);
        Task SaveScaleItemDetails(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData);
        Task<ItemValidationDTO> ValidateScaleItemDetails(ScaleInfoDto dto);
    }
}
