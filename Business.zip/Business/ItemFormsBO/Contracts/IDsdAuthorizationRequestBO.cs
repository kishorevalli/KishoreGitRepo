﻿using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface IDsdAuthorizationRequestBO
    {
        Task<IEnumerable<VendorDomainDto>> GetDsdVendors(string userId, string groupName="");

        Task<IEnumerable<VendorServiceDto>> GetStoresServicedByVendor(int[] vendorNumbers);

        Task<bool> SaveDsdVendorStoreAuthorization(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto);

        Task<IEnumerable<DsdVendorAuthorizationDto>> GetDsdVendorAuthorizations(int itemFormID);

        Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdVendorsByItemForm(int itemFormID);

        Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdStatesByItemForm(int itemFormID);

        Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdCountiesByItemForm(int itemFormID);

        Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdVendorStoreAuthorizationsByItemForm(int itemFormID);

        Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdVendorStoreAuthorizationsBySearchCriteria(VendorServiceDto vendorServiceDto);

        Task<IEnumerable<VendorDomainDto>> GetDSDVendorDataForInternalUser();

        Task<bool> ValidateAndSaveDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList, string userName);

        Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdOverlappedVendorStoreAuthorizationsByItemForm(int itemFormID);

        Task<bool> IsOverlappedVendorStoreAuthExistsByItemForm(int itemFormID);

        Task<bool> IsMultipleDsdVendorsSubmittingSameGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto);

        Task<bool> SaveDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList);

        Task<bool> IsOverlappedVendorStoreAuthExistsByGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto);

        Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdOverlappedVendorStoreAuthorizationsByGtin(decimal gtin);

        Task<List<ErrorDTO>> ValidateAndSaveModelItemCodeData(BasicItemDefinitionDto basicItemDefinitionDto);

        Task<BasicItemDefinitionDto> GetBasicItemDefinitionData(long itemFormDisplayId);

        Task<bool> SaveItemDataByPmdsItemCode(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData);

        Task ProcessDsdVendorStoreAuthorizationByModelItemCode(BasicItemDefinitionDto basicItemDefinitionDto);

        Task ProcessDsdVendorStoreAuthorizationByGtin(BasicItemDefinitionDto basicItemDefinitionDto);

        Task<BasicItemDefinitionDto> GetBasicItemDefnitionDataByGTIN(BasicItemDefinitionDto basicItemDefinitionDto);

        Task<IEnumerable<VendorDomainDto>> GetDsdVendorsExistForItemForm(int itemFormID);
        Task<bool> DeleteDsdVendorsNotInPackagingHierarchy(int itemFormID);
    }
}
