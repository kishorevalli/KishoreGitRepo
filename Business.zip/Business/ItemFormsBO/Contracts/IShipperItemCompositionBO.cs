﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
   public interface IShipperItemCompositionBO
    {
        Task<bool> SaveAllShipperItemCompositionList(IEnumerable<ShipperItemCompositionDto> shipperCompositionList, int ItemFormID);
        Task<bool> SaveShipperItemCompositions(IEnumerable<ShipperItemCompositionDto> shipperCompositionList, int ItemFormID);
        Task<IEnumerable<ShipperItemCompositionDto>> GetShipperCompositionItems(int ItemFormID);
        Task<ShipperItemCompositionDto> ValidateShipperItemCompositionByItemCode(int itemid, string userId, string groupName, UserType CreatedByUserTypeID);
        Task<ShipperItemCompositionDto> ValidateShipperItemCompositionByGTIN(decimal GTIN, string userId, string groupName, UserType CreatedByUserTypeID);
        Task<ItemValidationDTO> ValidateShipperItemComposition(IEnumerable<ShipperItemCompositionDto> shipperItemComposition);
        Task<int> GetCaseType(int ItemFormID);
        Task<int> GetShipperSubDepartmentCode(int ItemFormID);
        Task<int> GetProductGroupingSubDepartmentCode(int ItemFormID);
        Task<int> DeleteShipperItemCompositionList(int ItemFormID);
    }
}
