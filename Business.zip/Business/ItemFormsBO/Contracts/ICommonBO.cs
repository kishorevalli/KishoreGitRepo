﻿ using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.VendorPortalAdminSvc;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface ICommonBO
    {
        //Task<Boolean> IsGTINExists(long Gtin);
        Task<IEnumerable<LookupDto>> GetPIDMLookup(string Resource);
        Task<IEnumerable<T>> GetPIDMData<T, P>(string Resource);
        Task<T> GetPIDMDataObject<T, P>(string Resource);
        Task<IEnumerable<T>> GetPIDMDataByPost<T, P>(string Resource, dynamic data);
        Task<T> GetPIDMDataObjectByPost<T, P>(string Resource, dynamic data);
        Task<HttpResponseMessage> GetHttpResponse(string resource);

        Task<HttpResponseMessage> GetHttpResponseViaPost<T>(string resource, T request);

        Task<bool> DeleteItemForm(ItemFormDto itemFormDto);

        Task<ItemFormDto> SaveItemForm(ItemFormDto itemFormDto);

        Task<ItemFormDto> GetItemFormData(long itemFormDisplayId);

        bool IsValidEmail(string email);

        Task UpdateItemForm(ItemFormDto itemForm);      
          
        Task<IEnumerable<ErrorDTO>> GetErrorMessagesByType(ErrorDTO errors);

        string PublixEnvironment { get; } 

        Task<IEnumerable<VendorDomainDto>> GetAssociatedVendorListForExternalUser(string userId, string groupName="");

        Task UpdateItemCodeForItemForm(ItemFormDto itemForm);

        Task<bool> IsDsdVendorsExistForUser(string userId, string groupName = "");

        Task<IEnumerable<VendorDomainDto>> GetVendorForSearch(VendorDomainDto vendorDomainDto);

        Task<string> GetVendorItemCode(int itemFormID);

        Task<string> GetUserType(string userID);

        Task<ErrorDTO> GetErrorMessage(string ErrorCode, int action = 1);

        Task<PIDMDataDto> GetPMDSDataByItemCode(int itemCode);
        Task<PIDMDataDto> GetPMDSDataByGTIN(decimal? gtin);

        Task<IEnumerable<GTINWithCheckdigitDto>> GetBasicItemDefinitionGTIN(int itemFormID);
        Task<bool> IsDsdVendorsExistForItemForm(int itemFormId);

        Task<IEnumerable<LookupDto>> GetFacilityGroupByType(string type);

        Task<IEnumerable<LookupDto>> GetFacilityGroupTypes();
        Task<bool> IsFAMCodeExistsInProductGrouping(int itemFormId);
        Task<bool> SaveItemFormErrors(ItemValidationDTO ItemValidation, int ItemFormID, string CreatedBy);
        Task<IEnumerable<ItemValidationDTO>> GetItemFormErrors(int ItemFormID);

        Task<IEnumerable<ItemFormDto>> GetItemFormGroup(int ItemFormID);
        Task<string> GetSystemValueByKey(string KeyName);

        Task SubmitItemFormsForCreation(int itemFormId , string createdBy);

        Task<IEnumerable<int>> GetVendorsForItemForm(int itemFormID);

        Task<ItemFormDto> GetItemFormDataById(int itemFormId);

//        Task<IEnumerable<int>> GetChildForms(int itemFormId);


        //     Task<bool> CreateItem(int itemFormID, string createdBy);

    }
}
