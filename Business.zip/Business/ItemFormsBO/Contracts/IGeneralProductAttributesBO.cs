﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using System.Collections;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface IGeneralProductAttributesBO
    {
        Task<IEnumerable<LookupDto>> GetProductDateTypes();
        Task<IEnumerable<LookupDto>> GetNDCFormats();
        Task<IEnumerable<LookupDto>> GetNutritionalPanelTypes();
        Task<IEnumerable<LookupDto>> GetOrganicTypes();
        Task<IEnumerable<VariableWeightIndicatorDto>> GetVariableWeightIndicators();
        Task<IEnumerable<LookupDto>> GetLiquorTypes();
        Task<IEnumerable<LookupDto>> GetShelfTagSizes();
        Task<IEnumerable<NutrientDictionary>> GetNutrientDetails();
        Task<IEnumerable<NutrientDictionary>> GetAllergensDetails();

        Task<IEnumerable<DrugScheduleCodeDto>> GetDrugScheduleCodes();

        Task<GeneralProductAttributesDto> GetGeneralProdutAttributes(int itemFormID);
        Task<bool> SaveGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes);
        Task<List<SubTabValidationDTO>> validateNutritionPanel(List<NutritionalPanelDto> NutritionalPanelList, DateTime? NutritionalInfoNotAvailableUntil , int action);
        Task<ItemValidationDTO> ValidateGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes);
        Task<IEnumerable<UnacceptableIngredientDto>> GetUnacceptableIngredientList();

        Task<GeneralProductAttributesDto> GetGPAWeightDetails(int itemFormID);
    }
}
