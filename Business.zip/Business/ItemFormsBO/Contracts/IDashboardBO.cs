﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsBO.ItemFormSvc;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
   public interface IDashboardBO
    {        
        Task<IEnumerable<DashboardItemFormDto>> GetItemFormListBySearchCriteria(DashboardSearchCriteriaDto dashboardSearchCriteriaDto, string LoggedInUserID);
        Task<IEnumerable<DashboardItemFormDto>> GetItemFormListBySearchCriteriaInternalUser(DashboardSearchCriteriaDto dashboardSearchCriteriaDto, string LoggedInUserID);      

        Task<IEnumerable<DashboardStatusDto>> GetDashboardStatus(LoggedInUserDto loggedInUser);
        Task<int> GetDashboardStatusCount(DashboardStatusDto dashboardStatusDto);

        Task<int> GetDashboardStatusCountInternal(DashboardStatusDto dashboardStatusDto);
        Task<IEnumerable<DashboardItemFormDto>> GetDashboardStatusDetail(DashboardStatusDto dashboardStatusDto, string LoggedInUserID);

        Task<IEnumerable<DashboardItemFormDto>> GetDashboardStatusDetailInternal(DashboardStatusDto dashboardStatusDto, string LoggedInUserID);
        Task<bool> UpdateItemFormActionAndCurrentStatusList(IEnumerable<FormUserPermittedActionDto> FormUserPermittedActionList);
        Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForVendor();
        Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForBuyer(int LoggedInUserTypeID);

        Task<bool> UpdateVSARelatedForm(string VSALoginUserID);
        Task<bool> InsertDashboardUserSelection(DashboardUserSelectionDto dashboardUserSelectionDto);
        Task<DashboardUserSelectionDto> GetDashboardUserSelection(string LoggedInUserID);
        //TODO Remove
        Task<IEnumerable<ItemFormDto>> GetItemForms(string userId);
        Task<IEnumerable<ViewForUserListDto>> GetPossibleVendorUserForItemForm(ViewForUserListDto[] ViewForUserList);

        Task<bool> UpdateReassignVendorContact(ViewForUserListDto vendorContact);

        Task<IEnumerable<DashboardItemFormDto>> AddItemFormToGroup(int ItemFormID);

        Task<IEnumerable<DashboardItemFormDto>> RemoveItemFormFromGroup(int ItemFormID);

        Task<IEnumerable<DashboardItemFormDto>> ParentingItemForm(int ItemFormID);
        Task<IEnumerable<DashboardItemFormDto>> UnParentingItemForm(int ItemFormID);

        Task<IEnumerable<ErrorDTO>> GetDashboardErrorMessageList(int ItemFormID);

        Task<bool> ChangeVendorSubmittedFormToReview(int ItemFormID);
        Task<bool> UpdateItemFormStatusForInternalUser(IEnumerable<FormUserPermittedActionDto> formUserPermittedActionList);
        Task<DashboardStatusDto> GetDefaultFavouriteForUserType(int UserTypeID);
        Task<string> GetParentStatusForGTIN(decimal GTIN);
        List<BuyerDTO> GetBuyerRelatedUsers(string UserId, string UserRole);

        List<VendorDTO> GetVendorRelatedUsers(string UserId, string UserRole);

        Task<IEnumerable<FormUserPermittedActionDto>> GetFormActionsForItemForm(int currentUserTypeID, int CurrentFormStatusID);
    }
}
