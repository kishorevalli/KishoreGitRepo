﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;


namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
   public interface IWorkFlowBO
    {
        Task<IEnumerable<FormUserPermittedActionDto>> GetFormUserPermittedAction(UserType currentUserType, int formCurrentStatusID , int formTypeID);
        List<DashboardItemFormDto> LoadFormActionsForItemFormListInternal(List<DashboardItemFormDto> ItemFormList, UserType userType);
        List<DashboardItemFormDto> LoadFormActionsForItemFormListVendor(List<DashboardItemFormDto> ItemFormList, string LoggedInUserID);

        bool ValidateItemFormByVendors(int ItemFormID, string LoggedInVendorList);
    }
}
