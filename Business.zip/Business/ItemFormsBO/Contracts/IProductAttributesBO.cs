﻿using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface IProductAttributesBO
    {
        //Task<IEnumerable<ProductAttributeDto>> GetProductAttributesByItemCode(string ItemCode);

        Task<IEnumerable<ProductAttributeDto>> GetMandatoryAttributesList(int famCode , List<int> rssCode, string ItemCode);

        Task<IEnumerable<ProductAttributeDto>> GetMandatoryAttributes(ProductMandatoryAttributesRequestDto mandatoryAttributesRequest , int modelGroupCodeType , int ItemFormID);

        Task<IEnumerable<ProductAttributeDto>> GetProductAttributes(int ItemFormID);

        Task<bool> SaveProductAttributes(List<ProductAttributeDto> productAttributes, int itemFormId , string currentUser);

      //  Task<ProductMandatoryAttributesRequestDto> GetFamAndRssDetails(int ItemFormID);

        Task<IEnumerable<StateDto>> GetStates();

        Task<IEnumerable<StateDto>> GetCounties(string stateShortName);

        Task<IEnumerable<StateDto>> GetCities(StateDto state);

        Task<ItemValidationDTO> ValidateProductAttributes(List<ProductAttributeDto> productAttributes , int itemFormID , int? formActionID );
        Task<IEnumerable<ProductAttributeScopingDto>> GetProductAttributesScopingDetails(int itemFormID);
        Task<List<ItemGroupType>> GetProductGroupingFamAndRSS(ProductMandatoryAttributesRequestDto mandatoryAttributesRequest, int ItemFormID);



    }
}
