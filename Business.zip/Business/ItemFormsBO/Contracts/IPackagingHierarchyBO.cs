﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO.Contracts
{
    public interface IPackagingHierarchyBO
    {
        Task<IEnumerable<RetailPackTypeDto>> GetRetailPackTypesForItemForm(int itemFormID);
        Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchies(int itemFormID);
        Task<IEnumerable<CaseCodeTypeDto>> GetCaseCodeTypes();
        Task<bool> SavePackagingHierarchies(List<PackagingHierarchyDto> packagingHierarchylist, bool isModeling = false);
        Task<IEnumerable<OrderingLevelsDto>> GetOrderingLevels();
        Task<IEnumerable<VendorDomainDto>> GetVendorOrgs(string userId, string groupName = "");
        Task<IEnumerable<VendorDomainDto>> GetVendorsDomain(string userId, string groupName = "");
        Task<IEnumerable<VendorDomainDto>> GetVendorsForSelectedOrgs(List<int> selectedOrgs, string userId, string groupName);
        Task<IEnumerable<WarehouseDto>> GetWarehouses();
        Task<int> IsPrimaryVendorExistsForWHByGtin(WarehouseGtinDto warehouseDetails);

        Task<ItemValidationDTO> ValidatePackagingHierarchy(List<PackagingHierarchyDto> packagingHierarchyList , int formActionId = 1);
        Task<IEnumerable<PackagingHierarchyDto>> GetExistingPackagingHierarchies(int itemFormID);

        Task<bool> DeletePackagingHierarchies(GTINRetailPackInfoDto gtinRetailPackInfo);
       // Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchiesByModelItemCode(int? modelItemCode  ,int? itemformId , string userId);

        Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchiesByModelGTIN(decimal gtin);
        Task GetModelDataForPackagingHierarchy(string currentUserId, int? modelItemCode, int itemFormID , UserType userType);

        Task GetModelDataForPackagingHierarchyByGtin(string currentUserId, decimal gtin, int itemFormID, UserType userType);

        Task<IEnumerable<VendorDomainDto>> GetDsdVendorsExistInDsdForItemForm(int itemFormID);

    }
}
