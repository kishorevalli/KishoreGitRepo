﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsDac;



namespace Publix.S0VPITEM.ItemFormsBO
{
    public class ItemFormAutoPurgeBO
    {
        ItemFormAutoPurgeDAC DAC = new ItemFormAutoPurgeDAC();
        string dbName = String.Empty;
      
        public int ProcessAutoPurge(string purgeDBName)
        {
            string selectStmt;
            string sdelete = String.Empty;

            //Task<IEnumerable<ItemFormPurgeCriteriaDTO>> listPurgeCriteria;
            //IEnumerable<ItemFormPurgeCriteriaDTO> listPurgeCriteria;

            Task<IEnumerable<ItemFormPurgeTableListDTO>> tableList;
            ItemFormPurgeTableListDTO tlist = new ItemFormPurgeTableListDTO();
            ItemFormPurgeCriteriaDTO purgeCriteria = new ItemFormPurgeCriteriaDTO();
            try
            {
                Task <IEnumerable<ItemFormPurgeCriteriaDTO>> listPurgeCriteria = GetPurgeCriteria();
                List<ItemFormPurgeCriteriaDTO> listPurgeCriteria1 = listPurgeCriteria.Result.ToList();

                foreach (ItemFormPurgeCriteriaDTO listItem in listPurgeCriteria.Result.ToList())
                {
                    selectStmt = String.Empty;
                    // flagdisplay = false;
                    selectStmt = GenerateFilters(listItem);
                    // tableList.Clear();
                    sdelete = String.Empty;
                    if ((selectStmt != ""))
                    {
                        Task<IEnumerable<int>> Form2Purge = GetAutoPurgeCandidates(selectStmt);
                        // LogMessage(logTitle, string.Format(MessageMgr.GetSystemMsg("AP0001"), listItem.OfferTypeID, Offer2Purge.Count));
                        if ((Form2Purge.Result.Count() > 0))
                        {
                            tableList = GetPurgeTableList(listItem.PurgeListTableGroupNumber);
                            //flagdisplay1 = false;
                            foreach (int id in Form2Purge.Result.ToList())
                            {
                                sdelete = String.Empty;
                                sdelete = GeneratePurgeScriptDynamicallyWithCriteria(tableList, id);
                                //if ((flagdisplay1 == false))
                                //{
                                //    SaveDynamicScriptInLog(sdelete, listItem.OfferTypeID);
                                //    flagdisplay1 = true;
                                //}
                                ProcessPurges(sdelete);
                            }
                            //LogMessage(logTitle, string.Format(MessageMgr.GetSystemMsg("AP0002"), Offer2Purge.Count, listItem.OfferTypeID));
                        }
                    }
                    else
                    {
                       tableList = GetPurgeTableList(listItem.PurgeListTableGroupNumber);
                       sdelete = GeneratePurgeScriptDynamicallyWithOutCriteria(tableList, listItem.DateFactor);
                       ProcessPurges(sdelete);
                    }
                }
            }
           catch (Exception ex)
            {
                //jobHistory.JobStatus = JobStatus.Fail;
                throw;
            }
            finally
            {
                // jobHistoryBO.CompleteJobHistory(jobHistory);
            }
            return 0;
       }


        public string GeneratePurgeScriptDynamicallyWithCriteria(Task<IEnumerable<ItemFormPurgeTableListDTO>> listTable, int formID)
        {
            string deleteStmt = String.Empty;
            deleteStmt = "BEGIN TRANSACTION  BEGIN TRY ";
            foreach (ItemFormPurgeTableListDTO item in listTable.Result.ToList())
            {
                if (((item.SubQueryTableName != "") && (item.SubQueryFieldName != "")))
                {
                    if ((item.SubQueryTableName.ToUpper() == "ItemForm"))
                    {
                        deleteStmt = (deleteStmt + (" DELETE FROM "
                                    + (item.PurgeTableName.ToString() + (" where  "
                                    + (item.PurgeTableFieldName.ToString() + (" in ( select  "
                                    + (item.SubQueryFieldName.ToString() + (" from "
                                    + (item.SubQueryTableName.ToString() + (" where id = "
                                    + (formID + ");  ")))))))))));
                    }
                    else
                    {
                        deleteStmt = (deleteStmt + (" DELETE FROM "
                                    + (item.PurgeTableName.ToString() + (" where  "
                                    + (item.PurgeTableFieldName.ToString() + (" in ( select  "
                                    + (item.SubQueryFieldName.ToString() + (" from "
                                    + (item.SubQueryTableName.ToString() + (" where ItemFormID = "
                                    + (formID + ");  ")))))))))));
                    }

                }
                else if ((item.PurgeTableFieldName.ToString() == ""))
                {
                    deleteStmt = (deleteStmt + (" delete from "
                                + (item.PurgeTableName.ToString() + (" where ItemFormID = "
                                + (formID + ";  ")))));
                }
                else
                {
                    deleteStmt = (deleteStmt + (" delete from "
                                + (item.PurgeTableName.ToString() + (" where  "
                                + (item.PurgeTableFieldName.ToString() + (" = "
                                + (formID + ";  ")))))));
                }

            }
            deleteStmt = (deleteStmt + " COMMIT TRANSACTION END TRY BEGIN CATCH ROLLBACK TRANSACTION select ERROR_MESSAGE() AS ErrorMessage E" + "ND CATCH");
            return deleteStmt;
        }

        public string GeneratePurgeScriptDynamicallyWithOutCriteria(Task<IEnumerable<ItemFormPurgeTableListDTO>> listTable, int datefactor)
        {
            string deleteStmt = String.Empty;
            deleteStmt = "BEGIN TRANSACTION  BEGIN TRY ";
            foreach (ItemFormPurgeTableListDTO item in listTable.Result.ToList())
            {
                deleteStmt = (deleteStmt + (" DELETE from "
                            + (item.PurgeTableName.ToString() + (" where "
                            + (item.PurgeTableFieldName.ToString() + ("<  \'"
                            + (DateTime.Now.AddMonths((datefactor * -1)).Date + "\'")))))));
            }

            deleteStmt = (deleteStmt + " COMMIT TRANSACTION END TRY BEGIN CATCH ROLLBACK TRANSACTION select ERROR_MESSAGE() AS ErrorMessage E" + "ND CATCH");
            return deleteStmt;
        }

        private Task<IEnumerable<ItemFormPurgeTableListDTO>> GetPurgeTableList(string purgeListGroups)
        {
            return DAC.GetPurgeTableList(("SELECT * FROM ItemFormPurgeTableList where PurgeListTableGroupNumber  in  (" + purgeListGroups + ")  and purgeflag= \'Y\' order by isnull(PurgeTableSequence,999999)"));
        }

        public Task<IEnumerable<ItemFormPurgeCriteriaDTO>> GetPurgeCriteria()
        {
            string str = ("SELECT * FROM  ItemFormPurgeCriteria WHERE purgeflag =\'Y\'");
            return  DAC.GetPurgeCriteria(str);
        }

        private Task<IEnumerable<int>> GetAutoPurgeCandidates(string str)
        {
            return DAC.GetAutoPurgeCandidates(str, dbName);
        }

        public string GenerateFilters(ItemFormPurgeCriteriaDTO criteria)
        {
            string whereCondition = String.Empty;
            string tAlias = String.Empty;
            string _retentionFiled = String.Empty;
            int formType;
            string formStatus;
            string purgeDateFieldName;
            int dateFactor;
            string purgeFlag;
            string purgetablename;
            string purgeListGroupNumber = String.Empty;
            string selectStmt = String.Empty;

            formType = criteria.FormTypeID;
            formStatus = criteria.FormStatus;
            purgeDateFieldName = criteria.PurgeDateFieldName;
            dateFactor = criteria.DateFactor;
            purgeFlag = criteria.PurgeFlag;
            purgetablename = criteria.PurgeDateFieldTableName;
            purgeListGroupNumber = criteria.PurgeListTableGroupNumber;


            DateTime _retentiondate = DateTime.Now.AddMonths((dateFactor * -1)).Date;
            _retentionFiled = purgeDateFieldName;

            //if (((purgetablename != "") && (purgeDateFieldName != "")))
            //{
            //    tAlias = GetTableAliasName(purgetablename);
            //    _retentionFiled = (tAlias + ("." + PurgeDateFieldName));
            //}
            switch (formType)
            {
                case 1:
                    whereCondition = (whereCondition + ("FormTypeID = " + (formType + (" and "+ (_retentionFiled + ("  <  \'" + (_retentiondate.Date + ("\'  and  FormStatusID in (" + (formStatus + ")")))))))));
                    break;
               case 2:
                    break;
                case 3:
                    break;
           }

           selectStmt = ("SELECT DISTINCT ID FROM dbo.ItemForm with(nolock) WHERE  " + whereCondition);
           return selectStmt;
        }

        private int ProcessPurges(string str)
        {
            DAC.PurgeCostOffer(str, dbName);
            // LogMessage("AutoPurge", String.Format(MessageMgr.GetSystemMsg("AP0006"), purge.ID))
            return 0;
        }

        //public string GetTableAliasName(string tname)
        //{
        //    string tAlias = String.Empty;
        //    string[] title = tname.Split(new char[] { '_', c });
        //    foreach (string n in title)
        //    {
        //        tAlias = (tAlias + n.Substring(0, 1));
        //    }
        //    return tAlias;
        //}
    }
}
