﻿using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClosedXML.Excel;
using ClosedXML.Extensions;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class CategoryReviewBO : ICategoryReviewBO
    {
        protected readonly ICategoryReviewDac _categoryReviewDac;

        public CategoryReviewBO(ICategoryReviewDac categoryReviewDac)
        {
            this._categoryReviewDac = categoryReviewDac;
        }

        public async Task<IEnumerable<CategoryReviewDto>> GetCategoryReviewReport(int BuyerID)
        {
           return await _categoryReviewDac.GetCategoryReviewReport(BuyerID);
        }

        //public async Task<IEnumerable<LookupDto>> GetRSSListByBuyerID(int BuyerID)
        //{
        //    throw new NotImplementedException();

        //}
        public async Task<XLWorkbook> BuildExcelFile(List<CategoryReviewDto> CategoryReviewList)
        {
            var excelList = CategoryReviewList.Select(row => new
            {
                row.Vendor,
                row.RSS,
                row.GTINWithCheckDigit,
                row.ItemDescription,
                row.ProjectedSales52WeeksStr,
                row.UnitCostStr,
                row.UnitCostUOM,
                row.CasePack,
                row.CaseCost,
                row.SuggestedRetailStr,
                row.SuggestedMarginStr,
                row.ItemPreviouslyPresented,
                row.AvailableShipDateStr,
                row.NewItemFundsAvailable,
                row.NewItemFundsAmountStr,
                row.VendorComments,
                row.BuyerComments,
                row.ItemFormDisplayID
            });
            //Creating the workbook
            var t = Task.Run(() =>
            {
                var wb = new XLWorkbook();
                var ws = wb.AddWorksheet("CategoryReviewRpt");
                ws.Cell(1, 1).Value = "Category Review Report";

                ws.Cell(2, 1).Value = "Vendor";
                ws.Cell(2, 2).Value = "Review (RSS)";
                ws.Cell(2, 3).Value = "GTIN with Check Digit";
                ws.Cell(2, 4).Value = "Item Description";
                ws.Cell(2, 5).Value = "52 week Projected Sale";
                ws.Cell(2, 6).Value = "Unit Cost";
                ws.Cell(2, 7).Value = "Unit Size";
                ws.Cell(2, 8).Value = "Case Pack";
                ws.Cell(2, 9).Value = "Case Cost";
                ws.Cell(2, 10).Value = "Suggested Retail";
                ws.Cell(2, 11).Value = "Suggested Margin";
                ws.Cell(2, 12).Value = "Item Previously Presented";
                ws.Cell(2, 13).Value = "Available Ship Date";
                ws.Cell(2, 14).Value = "New Item Funds Available";
                ws.Cell(2, 15).Value = "New Item Funds Amount";
                ws.Cell(2, 16).Value = "Vendor Comments";
                ws.Cell(2, 17).Value = "Buyer Comments";
                ws.Cell(2, 18).Value = "Item Form ID";
                var rngTitles = ws.Range(2, 1, 2, 18);

                ws.Cell(3, 1).Value = excelList;

                //Format Report Header
                ws.Range(1, 1, 1, 4).Merge();
                ws.Range(1, 1, 1, 4).Style.Font.Bold = true;
                ws.Range(1, 1, 1, 4).Style.Font.FontSize = 15;
                ws.Range(1, 1, 1, 4).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                ws.Range(1, 1, 1, 4).Style.Fill.BackgroundColor = XLColor.LightGreen;

                //Format all titles
                rngTitles.Style.Font.Bold = true;
                rngTitles.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

                ws.Columns().AdjustToContents();
                ws.Column(16).Width = 40;
                ws.Column(16).Style.Alignment.WrapText = true;
                ws.Column(17).Width = 40;
                ws.Column(17).Style.Alignment.WrapText = true;
                ws.Column(5).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Right);
                ws.Column(6).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Right);
                ws.Column(10).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Right);
                ws.Column(15).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Right);
                return wb;
            });

            return await t;
        }
    }
}
