﻿using Publix.S0VPITEM.ItemFormsBO.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class SubmitBO : ISubmitBO
    {
        protected readonly IBasicItemDefinitionBO _basicItemDefinitionBo;
        protected readonly IGeneralProductAttributesBO _generalProductAttributesBo;
        protected readonly IDsdAuthorizationRequestBO _dsdAuthorizationRequestBo;
        protected readonly IPackagingHierarchyBO _packagingHierarchyBo;
        protected readonly IProductAttributesBO _productAttributesBo;
        protected readonly IProductGroupingBO _productGroupingBo;
        protected readonly IScaleItemDetailsBO _scaleItemDetailsBo;
        protected readonly IShipperItemCompositionBO _shipperItemCompositionBo;
        protected readonly IMarketingSupportBO _marketingSupportBo;

        protected readonly ICommonBO _commonBo;

        public SubmitBO(ICommonBO commonBo,
            IBasicItemDefinitionBO basicItemDefinitionBo,
            IGeneralProductAttributesBO generalProductAttributesBo,
            IDsdAuthorizationRequestBO dsdAuthorizationRequestBo,
            IPackagingHierarchyBO packagingHierarchyBo,
            IProductAttributesBO productAttributesBo,
            IProductGroupingBO productGroupingBo,
            IScaleItemDetailsBO scaleItemDetailsBo,
            IShipperItemCompositionBO shipperItemCompositionBo,
            IMarketingSupportBO marketingSupportBo)
        {
            this._basicItemDefinitionBo = basicItemDefinitionBo;
            this._generalProductAttributesBo = generalProductAttributesBo;
            this._dsdAuthorizationRequestBo = dsdAuthorizationRequestBo;
            this._packagingHierarchyBo = packagingHierarchyBo;
            this._productAttributesBo = productAttributesBo;
            this._productGroupingBo = productGroupingBo;
            this._scaleItemDetailsBo = scaleItemDetailsBo;
            this._shipperItemCompositionBo = shipperItemCompositionBo;
            this._commonBo = commonBo;
            this._marketingSupportBo = marketingSupportBo;
            //  this._commonDac = commonDac;
        }

        public async Task<bool> PerformSubmitValidations(int itemFormID, string createdBy, UserType userType)
        {
            var errrosAvailable = false;
            List<ItemFormDto> grpdItemForms = await GetGroupedFormsByItemFormID(itemFormID);

            foreach (var itemForm in grpdItemForms)
            {
                //if (await SubmitValidationsBID(itemForm.ID, createdBy))
                //    errrosAvailable = true;

                var bidData = await _basicItemDefinitionBo.GetBasicItemDefinitionData(itemFormID);
                bidData.SubmittedUserTypeID = userType;
                var bidValidationDto = await _basicItemDefinitionBo.ValidateBasicItemDefinition(bidData);
                await _commonBo.SaveItemFormErrors(bidValidationDto, itemFormID, createdBy);
                errrosAvailable = (bidValidationDto.Errors.Count > 0 || bidValidationDto.Warnings.Count > 0);


                if (await SubmitValidationsGPA(itemForm.ID, createdBy, userType, bidData.RetailPackagedItem))
                    errrosAvailable = true;

                if (await SubmitValidationsDSD(itemFormID, createdBy))
                    errrosAvailable = true;

                if (await SubmitValidationsPH(itemForm.ID, createdBy , userType))
                    errrosAvailable = true;

                if (await SubmitValidationsShipperComposition(itemForm.ID, createdBy))
                    errrosAvailable = true;

                if (await SubmitValidationsMarketingSupport(itemForm.ID, createdBy, userType))
                    errrosAvailable = true;

                if (userType == UserType.Buyer || userType == UserType.CategoryMgr)
                {
                    if (await SubmitValidationsScaleItems(itemForm.ID, createdBy))
                        errrosAvailable = true;

                    if(await SubmitValidationsProductAttributes(itemForm.ID, createdBy))
                        errrosAvailable = true; 
                }

                if (await SubmitValidationsProductGrouping(itemForm.ID, createdBy))
                    errrosAvailable = true;
            }
            if (!errrosAvailable)
            {
                foreach (var itemForm in grpdItemForms)
                {
                    await _marketingSupportBo.CloneSimilarItemForm(itemForm.ID);
                }
                if(userType == UserType.Vendor)
                {
                    await _productGroupingBo.CopyProductGroupingOnSubmit(itemFormID);
                }
            }
            return errrosAvailable;
        }


        //Get all the grouped forms by ItemFormID.
        private async Task<List<ItemFormDto>> GetGroupedFormsByItemFormID(int itemFormID)
        {
            var sameGTINList = await _commonBo.GetItemFormGroup(itemFormID);
            var grpdItemForms = new List<ItemFormDto>();
            foreach (ItemFormDto itemForm in sameGTINList)
            {
                if (itemForm.ID == itemFormID && itemForm.IsInGroup != "Y")
                {
                    grpdItemForms = new List<ItemFormDto>();
                    grpdItemForms.Add(itemForm);
                    break;
                }
                else if (itemForm.IsInGroup == "Y")
                {
                    grpdItemForms.Add(itemForm);
                }
            }

            return grpdItemForms;
        }


        private async Task<bool> IsSameGTINAndVendorList(int itemFormID)
        {
            var itemFormsWithSameGtin = await _commonBo.GetItemFormGroup(itemFormID);
            var sameGtinForms = itemFormsWithSameGtin.Where(i => (i.ID != itemFormID && i.FormStatusID == 4)); // excluding the current item form
            var vendorsForItemForm = await _commonBo.GetVendorsForItemForm(itemFormID); // vendors for the current item form
                                                                                        // bool vendorsNotMatched = false;
            bool vendorsMatched = sameGtinForms.Count() > 0 ? true : false;
            foreach (ItemFormDto itemForm in sameGtinForms)
            {
                var vendors = await _commonBo.GetVendorsForItemForm(itemForm.ID);
                //Check if all the vendors match as well.
                foreach (var vendor in vendorsForItemForm)
                {
                    if (vendors.Any(v => v != vendor))
                    {
                        //vendorsNotMatched = true;
                        vendorsMatched = false;
                        break;
                    }
                }

                if (vendorsMatched == true)
                    break;
            }
            return vendorsMatched;
        }



        private async Task<bool> SubmitValidationsDSD(int itemFormID, string createdBy)
        {
            ItemValidationDTO dsdValidationDto = new ItemValidationDTO();
            var overLapExists = await _dsdAuthorizationRequestBo.IsOverlappedVendorStoreAuthExistsByItemForm(itemFormID);
            if (overLapExists)
            {
                dsdValidationDto.Errors = new List<ErrorDTO>();
                var errorDTOTemplate = await _commonBo.GetErrorMessage("DSD01");
                dsdValidationDto.Errors.Add(new ErrorDTO()
                {
                    ErrorCode = errorDTOTemplate.ErrorCode,
                    SeverityLevel = errorDTOTemplate.SeverityLevel,
                    ControlName = errorDTOTemplate.ControlName,
                    ErrorDescription = errorDTOTemplate.ErrorDescription,
                    TabName = errorDTOTemplate.TabName
                });

                await _commonBo.SaveItemFormErrors(dsdValidationDto, itemFormID, createdBy);
                return true;
            }
            return false;
        }

        private async Task<bool> SubmitValidationsProductGrouping(int itemFormID, string createdBy)
        {
            var pgData = await _productGroupingBo.GetProductGrouping(itemFormID);
            var pgValidationDto = await _productGroupingBo.ValidateProductGrouping(pgData.ToList());
            await _commonBo.SaveItemFormErrors(pgValidationDto, itemFormID, createdBy);
            return (pgValidationDto.Errors.Count > 0 || pgValidationDto.Warnings.Count > 0); // returns true when errors found.

        }

        private async Task<bool> SubmitValidationsProductAttributes(int itemFormID, string createdBy)
        {
            var paData = await _productAttributesBo.GetProductAttributes(itemFormID);
            var paValidationDto = await _productAttributesBo.ValidateProductAttributes(paData.ToList(), itemFormID, 3);
          //  bool validationFlag = false;

            ProductMandatoryAttributesRequestDto mandatoryAttributesRequest = new ProductMandatoryAttributesRequestDto();
            //get mandatory attributes based on product grouping.
            var mandatoryattributesByproductgrping = await _productAttributesBo.GetMandatoryAttributes(mandatoryAttributesRequest, 4, itemFormID);

            var difList = paData.Where(pa => !mandatoryattributesByproductgrping.Any(a => a.ItemGroupCode == pa.ItemGroupCode && a.ItemGroupType == pa.ItemGroupType && a.AttributeCode == pa.AttributeCode && a.ProductAttributeGroupCode == pa.ProductAttributeGroupCode))
            .Union(mandatoryattributesByproductgrping.Where(a => !paData.Any(pa => a.ItemGroupCode == pa.ItemGroupCode && a.ItemGroupType == pa.ItemGroupType && a.AttributeCode == pa.AttributeCode && a.ProductAttributeGroupCode == pa.ProductAttributeGroupCode)));

            if (difList.Count() > 0)
            {
                var errorDTOTemplate = await _commonBo.GetErrorMessage("PA04");
                paValidationDto.Errors.Add(new ErrorDTO()
                {
                    ErrorCode = errorDTOTemplate.ErrorCode,
                    SeverityLevel = errorDTOTemplate.SeverityLevel,
                    ControlName = errorDTOTemplate.ControlName,
                    ErrorDescription = errorDTOTemplate.ErrorDescription,
                    TabName = errorDTOTemplate.TabName
                });
            }

            //if (paData.Count() == mandatoryattributesByproductgrping.Count())
            //{
            //    foreach (var pa in paData)
            //    {
            //        if (mandatoryattributesByproductgrping.Any(a => a.ItemGroupCode == pa.ItemGroupCode && a.ItemGroupType == pa.ItemGroupType && a.AttributeCode == pa.AttributeCode && a.ProductAttributeGroupCode == pa.ProductAttributeGroupCode))
            //            continue;
            //        else
            //        {
            //            validationFlag = true;
            //            break;
            //        }
            //    }

            //}
            //else
            //{
            //    validationFlag = true;
            //}

            //if (validationFlag)
            //{

            //    var errorDTOTemplate = await _commonBo.GetErrorMessage("PCH26");
            //    paValidationDto.Errors.Add(new ErrorDTO()
            //    {
            //        ErrorCode = errorDTOTemplate.ErrorCode,
            //        SeverityLevel = errorDTOTemplate.SeverityLevel,
            //        ControlName = errorDTOTemplate.ControlName,
            //        ErrorDescription = errorDTOTemplate.ErrorDescription,
            //        TabName = errorDTOTemplate.TabName
            //    });
            //}

            await _commonBo.SaveItemFormErrors(paValidationDto, itemFormID, createdBy);
            return (paValidationDto.Errors.Count > 0 || paValidationDto.Warnings.Count > 0);

        }

        private async Task<bool> SubmitValidationsScaleItems(int itemFormID, string createdBy)
        {
            var scaleData = await _scaleItemDetailsBo.GetScaleInfo(itemFormID);
            var scaleValidationDto = await _scaleItemDetailsBo.ValidateScaleItemDetails(scaleData);
            await _commonBo.SaveItemFormErrors(scaleValidationDto, itemFormID, createdBy);
            return (scaleValidationDto.Errors.Count > 0 || scaleValidationDto.Warnings.Count > 0 || scaleValidationDto.SubTabValidations.Where(stv => stv.Errors.Count() > 0 || stv.Warnings.Count() > 0).FirstOrDefault() != null);

        }

        private async Task<bool> SubmitValidationsShipperComposition(int itemFormID, string createdBy)
        {
            var shipperData = await _shipperItemCompositionBo.GetShipperCompositionItems(itemFormID);
            var shipperCompositionValiationDto = await _shipperItemCompositionBo.ValidateShipperItemComposition(shipperData);
            await _commonBo.SaveItemFormErrors(shipperCompositionValiationDto, itemFormID, createdBy);
            return (shipperCompositionValiationDto.Errors.Count > 0 || shipperCompositionValiationDto.Warnings.Count > 0);
        }
        private async Task<bool> SubmitValidationsMarketingSupport(int itemFormID, string createdBy, UserType userType)
        {
            var marketingData = await _marketingSupportBo.GetMarketingInfo(itemFormID);
            if (marketingData != null)
            {
                marketingData.SubmittedUserTypeID = userType;

            }
            var marketingSupportValiationDto = await _marketingSupportBo.ValidateMarketingInfo(marketingData);
            await _commonBo.SaveItemFormErrors(marketingSupportValiationDto, itemFormID, createdBy);
            return (marketingSupportValiationDto.Errors.Count > 0 || marketingSupportValiationDto.Warnings.Count > 0);
        }

        private async Task<bool> SubmitValidationsPH(int itemFormID, string createdBy, UserType userType)
        {
            var phData = await _packagingHierarchyBo.GetPackagingHierarchies(itemFormID);
            if (phData.Count() > 0)
            {
                foreach (PackagingHierarchyDto ph in phData)
                {
                    ph.SubmittedUserTypeID = userType;
                }
            }
            var phValidationDto = await _packagingHierarchyBo.ValidatePackagingHierarchy(phData.ToList(), 3);

            if (phData.Count() == 0)   //If there are no packaging hierarchies , that means the user didnot even go to the C:\Projects\VPMD\Dev\ItemForms\2.0.0\Source\ItemForms\UX\ItemFormsWeb\Controllers\Api\BasicItemDefinitionController.cspackaging hierarchy tab.
            {
                phValidationDto.Errors = new List<ErrorDTO>();
                var errorDTOTemplate = await _commonBo.GetErrorMessage("PCH26");
                phValidationDto.Errors.Add(new ErrorDTO()
                {
                    ErrorCode = errorDTOTemplate.ErrorCode,
                    SeverityLevel = errorDTOTemplate.SeverityLevel,
                    ControlName = errorDTOTemplate.ControlName,
                    ErrorDescription = errorDTOTemplate.ErrorDescription,
                    TabName = errorDTOTemplate.TabName
                });
            }

            if (phData.Count() > 0)
            {
                if (phData.FirstOrDefault().FormStatusID == 1)
                {  //Itemform cannot be submitted if there is any other itemform with the same gtin and vendor list.
                    var sameVendorsExists = await IsSameGTINAndVendorList(itemFormID);
                    if (sameVendorsExists)
                    {
                        phValidationDto.Errors = new List<ErrorDTO>();
                        var errorDTOTemplate = await _commonBo.GetErrorMessage("PCH32");
                        phValidationDto.Errors.Add(new ErrorDTO()
                        {
                            ErrorCode = errorDTOTemplate.ErrorCode,
                            SeverityLevel = errorDTOTemplate.SeverityLevel,
                            ControlName = errorDTOTemplate.ControlName,
                            ErrorDescription = errorDTOTemplate.ErrorDescription,
                            TabName = errorDTOTemplate.TabName
                        });
                    }
                }
              
            }

            await _commonBo.SaveItemFormErrors(phValidationDto, itemFormID, createdBy);
            return (phValidationDto.Errors.Count > 0 || phValidationDto.Warnings.Count > 0 ||
                         phValidationDto.SubTabValidations.Where(stv => stv.Errors.Count() > 0 || stv.Warnings.Count() > 0).FirstOrDefault() != null);

        }

        private async Task<bool> SubmitValidationsGPA(int itemFormID, string createdBy, UserType submittedUserType, string retailPackagedItem)
        {
            var gpaData = await _generalProductAttributesBo.GetGeneralProdutAttributes(itemFormID);
            if (gpaData != null)
            {
                gpaData.SubmittedUserTypeID = submittedUserType;
                gpaData.RetailPackagedItem = retailPackagedItem;
            }
            ItemValidationDTO gpaValidationDto = await _generalProductAttributesBo.ValidateGeneralProductAttributes(gpaData);

            //if (gpaData == null)
            //{
            //    //gpaValidationDto.Errors = new List<ErrorDTO>();
            //    var errorDTOTemplate = await _commonBo.GetErrorMessage("GPA17");
            //    gpaValidationDto.TabName = "General Product Attributes";
            //    gpaValidationDto.Errors.Add(new ErrorDTO()
            //    {
            //        ErrorCode = errorDTOTemplate.ErrorCode,
            //        SeverityLevel = errorDTOTemplate.SeverityLevel,
            //        ControlName = errorDTOTemplate.ControlName,
            //        ErrorDescription = errorDTOTemplate.ErrorDescription,
            //        TabName = errorDTOTemplate.TabName
            //    });
            //}
            await _commonBo.SaveItemFormErrors(gpaValidationDto, itemFormID, createdBy);
            return (gpaValidationDto.Errors.Count > 0 || gpaValidationDto.Warnings.Count > 0 || (gpaValidationDto.SubTabValidations != null && gpaValidationDto.SubTabValidations.Where(stv => stv.Errors.Count() > 0 || stv.Warnings.Count() > 0).FirstOrDefault() != null));

        }



        private async Task<bool> SubmitValidationsBID(int itemFormID, string createdBy)
        {
            var bidData = await _basicItemDefinitionBo.GetBasicItemDefinitionData(itemFormID);
            var bidValidationDto = await _basicItemDefinitionBo.ValidateBasicItemDefinition(bidData);
            await _commonBo.SaveItemFormErrors(bidValidationDto, itemFormID, createdBy);
            return (bidValidationDto.Errors.Count > 0 || bidValidationDto.Warnings.Count > 0);

        }
    }
}
