﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using AutoMapper;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class MarketingSupportBO : IMarketingSupportBO
    {
        protected readonly IMarketingSupportDac _marketingSupportDac;
        protected readonly ICommonBO _commonBo;
        public MarketingSupportBO(IMarketingSupportDac marketingSupportDac, ICommonBO commonBo)
        {
            this._marketingSupportDac = marketingSupportDac;
            this._commonBo = commonBo;
        }
        public async Task<MarketingInfoDto> GetMarketingInfo(int ItemFormID)
        {
            return await _marketingSupportDac.GetMarketingInfo(ItemFormID);
        }

        public async Task<IEnumerable<LookupDto>> GetPromoSupportFrequency()
        {
            return await _marketingSupportDac.GetPromoSupportFrequency();
        }

        public async Task<IEnumerable<LookupDto>> GetUnitCostUOM()
        {
            return await _marketingSupportDac.GetUnitCostUOM();
        }
        public async Task<ItemValidationDTO> ValidateMarketingInfo(MarketingInfoDto marketingInfo)
        {
            ItemValidationDTO bidValidationDTO = new ItemValidationDTO();

            //TODO : put all the tab names into some common file as consts. 
            bidValidationDTO.TabName = "Marketing Support";
            List<ErrorDTO> errorList = new List<ErrorDTO>();
            List<WarningDTO> warningsList = new List<WarningDTO>();

            if (marketingInfo == null) marketingInfo = new MarketingInfoDto();
            if (marketingInfo.SubmittedUserTypeID == UserType.Vendor)
            {
                if (string.IsNullOrEmpty(marketingInfo.VendorContactEmail))
                {
                    var error = await _commonBo.GetErrorMessage("MS01");
                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
            }
            bidValidationDTO.Errors = errorList;
            bidValidationDTO.Warnings = warningsList;
            return bidValidationDTO;
        }
        public async Task<bool> SaveMarketingInfo(MarketingInfoDto marketingInfo)
        {
            bool successFlag = await _marketingSupportDac.SaveMarketingInfo(marketingInfo);
            ItemFormDto itemForm = new ItemFormDto();
            itemForm.ID = marketingInfo.ItemFormID;
            itemForm.VendorContactEmail = marketingInfo.VendorContactEmail;
            await _marketingSupportDac.UpdateItemFormVendorEmail(itemForm);
            return successFlag;
        }
        public async Task<IEnumerable<FormCommentDto>> GetFormComment(int ItemFormID, int UserType)
        {
            return await _marketingSupportDac.GetFormComment(ItemFormID, UserType);
        }
        public async Task<bool> SaveFormComment(FormCommentDto formComment)
        {
           return await _marketingSupportDac.SaveFormComment(formComment); 
        }
        public async Task<bool> CloneSimilarItemForm(int ItemFormID)
        {
            bool successFlag = false;
            try
            {
                var similarItemGTINList = await _marketingSupportDac.CreateSimilarItemForms(ItemFormID);
                if (similarItemGTINList != null && similarItemGTINList.Count > 0)
                {
                    //foreach(var similarItem in similarItemGTINList)
                    //{
                    //    await _marketingSupportDac.CloneSimilarItemFormData(similarItem);
                    //}
                    Parallel.ForEach(similarItemGTINList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (similarItem) =>
                    {
                        Task.Run(async () => { await _marketingSupportDac.CloneSimilarItemFormData(similarItem); }).Wait();
                    });
                }
                successFlag = true;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return successFlag;
        }
    }
}
