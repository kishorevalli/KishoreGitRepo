﻿using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using System.Net.Http;
using System.Linq;
using AutoMapper;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class GeneralProductAttributesBO : IGeneralProductAttributesBO
    {
        protected readonly IGeneralProductAttributesDac _generalProductAttributesDac;
        protected readonly ICommonBO _commonBo;

        public GeneralProductAttributesBO(ICommonBO commonBo , IGeneralProductAttributesDac generalProductAttributesDac)
        {
            this._generalProductAttributesDac = generalProductAttributesDac;
            this._commonBo = commonBo;
        }

        public Task<IEnumerable<LookupDto>> GetNDCFormats()
        {
            LookupDto[] ndcFormats = new LookupDto[4];
            
            for (var i = 0; i < 4; i++)
            {
                ndcFormats[i] = new LookupDto();
                ndcFormats[i].Code = "N" + (i+1).ToString();
                ndcFormats[i].Description = "N" + (i + 1).ToString();
            }                       
            return Task.FromResult(ndcFormats.AsEnumerable());            
        }

        public Task<IEnumerable<LookupDto>> GetNutritionalPanelTypes()
        {
            return _generalProductAttributesDac.GetNutritionalPanelTypes();            
        }
        public Task<IEnumerable<VariableWeightIndicatorDto>> GetVariableWeightIndicators()
        {
            return _generalProductAttributesDac.GetVariableWeightIndicators();
        }

        public Task<IEnumerable<UnacceptableIngredientDto>> GetUnacceptableIngredientList()
        {
            return _generalProductAttributesDac.GetUnacceptableIngredientList();
        }
       
        public async Task<IEnumerable<LookupDto>> GetLiquorTypes()
        {
            return await _commonBo.GetPIDMLookup("api/GetLiquorTypes");
        }
        public async Task<IEnumerable<LookupDto>> GetShelfTagSizes()
        {
            var shelfTagSizes = await _commonBo.GetPIDMLookup("api/GetShelfTagSizes");
            return shelfTagSizes.Select(res => new LookupDto
            {
                Code = res.Code.Trim(),
                Description = res.Description
            });
        }

        public async Task<IEnumerable<LookupDto>> GetOrganicTypes()
        {
            var organicTypes = await _generalProductAttributesDac.GetOrganicTypes();

            return organicTypes.Select(res => new LookupDto
            {
                Code = res.Code.ToString(),
                Description = res.Description
            });
        }

        public Task<IEnumerable<LookupDto>> GetProductDateTypes()
        {
            //TODO: after confirmation from PMDS , remove this hardcoded and call service or pull from S0VPITEM db.
            List<LookupDto> productDateTypes = new List<LookupDto>();
            LookupDto manufacturingDateType = new LookupDto();
            manufacturingDateType.Code = "M";
            manufacturingDateType.Description = "Manufacturing Date";

            LookupDto expiryDate = new LookupDto();
            expiryDate.Code = "E";
            expiryDate.Description = "Expiry Date";

            productDateTypes.Add(manufacturingDateType);
            productDateTypes.Add(expiryDate);

            System.Collections.IEnumerable productDateTypesEnumerable = productDateTypes;
            return Task.FromResult(productDateTypes.AsEnumerable());
            
        }

        //Get Nutrient Details for Nutritional Panel from PMDS
        public async Task<IEnumerable<NutrientDictionary>> GetNutrientDetails()
        {
            string resource = "api/GetNutrientDetails";
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse(resource);
            IEnumerable<NutrientDictionary> nutrientsList = new List<NutrientDictionary>();
            if (response.IsSuccessStatusCode)
            {
                nutrientsList = await response.Content.ReadAsAsync<IEnumerable<NutrientDictionary>>();
            }
            return nutrientsList;            
        }

        //Get Allergen Details for Nutritional Panel from PMDS
        public async Task<IEnumerable<NutrientDictionary>> GetAllergensDetails()
        {
            string resource = "api/GetAllergensDetails";
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse(resource);
            IEnumerable<NutrientDictionary> allergensList = new List<NutrientDictionary>();
            if (response.IsSuccessStatusCode)
            {
                allergensList = await response.Content.ReadAsAsync<IEnumerable<NutrientDictionary>>();
            }
            return allergensList;
        }

        public async Task<bool> SaveGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes)
        {
            SetUserID(generalProductAttributes);
            //   return _generalProductAttributesDac.SaveGeneralProductAttributes(generalProductAttributes);
            bool successFlag = false;
            try
            {                
                generalProductAttributes.NutritionalInfoNotAvailableUntil = generalProductAttributes.NutritionalInfoNotAvailableUntil == DateTime.MinValue ? null : generalProductAttributes.NutritionalInfoNotAvailableUntil;
                generalProductAttributes.NutritionalPanelTypeID = generalProductAttributes.NutritionalPanelTypeID != 0 ? generalProductAttributes.NutritionalPanelTypeID : 5; // 5 -> none.

                var gpaDetailsExists = await _generalProductAttributesDac.IsGPADetailsExistsForItemForm(generalProductAttributes.ItemFormID);
                if (gpaDetailsExists)
                {
                    if (generalProductAttributes.IsDirty)
                    {
                        await _generalProductAttributesDac.UpdateGeneralProductAttributes(generalProductAttributes);

                        if (generalProductAttributes.NutritionalPanelList != null && generalProductAttributes.NutritionalPanelList.Count > 0)
                        {
                            //TODO: Get the max degree of parallelism from db system values. 
                            Parallel.ForEach(generalProductAttributes.NutritionalPanelList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (nutritionalPanel) =>
                            {
                                if (nutritionalPanel.IsDeleted)
                                {
                                    Task.Run(async () => { await _generalProductAttributesDac.DeleteNutritionalPanel(nutritionalPanel); }).Wait();
                                }
                                else if (nutritionalPanel.ID == 0)
                                {
                                    Task.Run(async () => { await _generalProductAttributesDac.InsertNutritionalPanel(nutritionalPanel); }).Wait();
                                }
                                else if (nutritionalPanel.IsDirty)
                                {
                                    Task.Run(async () => { await _generalProductAttributesDac.UpdateNutritionalPanels(nutritionalPanel); }).Wait();
                                }                           
                            });
                            await Task.WhenAll();
                        }
                    }
                }
                else
                {
            

                    await _generalProductAttributesDac.InsertGeneralProductAttributes(generalProductAttributes);
                    if (generalProductAttributes.NutritionalPanelList != null)
                    {
                        Parallel.ForEach(generalProductAttributes.NutritionalPanelList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (nutritionalPanel) =>
                        {
                            Task.Run(async () => { await _generalProductAttributesDac.InsertNutritionalPanel(nutritionalPanel); }).Wait();
                        });
                    }
                }

               
               
                successFlag = true;
            }
            catch (Exception ex)
            {
                throw;
            }

            return successFlag;
        }
       
        private static void SetUserID(GeneralProductAttributesDto generalProductAttributes)
        {
            string user = generalProductAttributes.CreatedBy;            
            generalProductAttributes.CreatedBy = user;
            generalProductAttributes.LastUpdatedBy = user;

            if (generalProductAttributes.NutritionalPanelList != null && generalProductAttributes.NutritionalPanelList.Count > 0)
            {
                foreach (var NutritionalPanel in generalProductAttributes.NutritionalPanelList)
                {
                    NutritionalPanel.CreatedBy = user;
                    NutritionalPanel.LastUpdatedBy = user;
                    if (NutritionalPanel.NutritionalInfoList != null && NutritionalPanel.NutritionalInfoList.Count > 0)
                    {
                        NutritionalPanel.NutritionalInfoList.ForEach(NI =>
                        {
                            NI.CreatedBy = user;
                            NI.LastUpdatedBy = user;
                        });
                    }
                    if (NutritionalPanel.NutritionalAllergenInfoList != null && NutritionalPanel.NutritionalAllergenInfoList.Count > 0)
                    {
                        NutritionalPanel.NutritionalAllergenInfoList.ForEach(NA =>
                        {
                            NA.CreatedBy = user;
                            NA.LastUpdatedBy = user;
                        });
                    }

                }
            }
        }



        //public Task<IEnumerable<ErrorDTO>> GetErrorMessages()
        //{
        //    return _generalProductAttributesDac.GetErrorMessages();
        //}
        public async Task<ErrorDTO> GetErrorMessage(string ErrorCode, int action = 1)
        {
            IEnumerable<ErrorDTO> Errors = await _generalProductAttributesDac.GetErrorMessages();
            var errorDTOTemplate = Errors.FirstOrDefault(e => e.ErrorCode == ErrorCode);
            //if (action == 3)
            //{
            //    return new ErrorDTO()
            //    {
            //        ErrorCode = errorDTOTemplate.ErrorCode,
            //        SeverityLevel = "Error",
            //        ControlName = errorDTOTemplate.ControlName,
            //        ErrorDescription = errorDTOTemplate.ErrorDescription
            //    };
            //}
            return errorDTOTemplate;
        }

        public async Task<ItemValidationDTO> ValidateGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes)
        {
            ItemValidationDTO gpaErrorDto = new ItemValidationDTO();
            gpaErrorDto.TabName = "General Product Attributes";
            List<ErrorDTO> errorList = new List<ErrorDTO>();
            List<WarningDTO> warningsList = new List<WarningDTO>();

            if (generalProductAttributes == null) generalProductAttributes = new GeneralProductAttributesDto();
            if (string.IsNullOrEmpty(generalProductAttributes.CountryOfOrigin))
            {
                var error = await _commonBo.GetErrorMessage("GPA18", generalProductAttributes.FormActionID);
                if (error.SeverityLevel == "Warning")
                    warningsList.Add(Mapper.Map<WarningDTO>(error));
                else
                    errorList.Add(error);
            }
            //email battery
            if (generalProductAttributes.ContainsBattery == "Y")
                if (generalProductAttributes.EMailForBatterySurvey != "")
                {
                    if (!(_commonBo.IsValidEmail(generalProductAttributes.EMailForBatterySurvey)))
                    {
                        var error = await _commonBo.GetErrorMessage("GPA02", generalProductAttributes.FormActionID);
                        if (error.SeverityLevel == "Warning")
                            warningsList.Add(Mapper.Map<WarningDTO>(error));
                        else
                            errorList.Add(error);
                    }
                }
                else
                {
                    var error = await _commonBo.GetErrorMessage("GPA01", generalProductAttributes.FormActionID); //Email For Battery is required.
                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
            if (generalProductAttributes.Narcotic == "Y")
            {
                if (!(generalProductAttributes.DrugScheduleCode == "2" || generalProductAttributes.DrugScheduleCode == "3"))
                {
                    var error = await _commonBo.GetErrorMessage("GPA03", generalProductAttributes.FormActionID);  // Drug schedule code should be 2 or 3 when Item is Narcotic.

                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
            }
            if (generalProductAttributes.ProductDate == "M")
            {
                if (generalProductAttributes.BornOnDays == null || generalProductAttributes.BornOnDays == 0)
                {
                    var error = await _commonBo.GetErrorMessage("GPA04", generalProductAttributes.FormActionID); //Born On Days is mandatory if product date is Manufacture Date.

                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
            }
            // Buyer specific validations
            if (generalProductAttributes.SubmittedUserTypeID == UserType.Buyer)
            {
                if (!string.IsNullOrWhiteSpace(generalProductAttributes.Liquor) && generalProductAttributes.Tobacco == "Y")
                {
                    var error = await _commonBo.GetErrorMessage("GPA08", generalProductAttributes.FormActionID); //Tobacco cannot be Y if liquor type is entered.

                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
                if (generalProductAttributes.PerishableItem == "Y" && (generalProductAttributes.MinDaysRequired ?? 0) == 0)
                {
                    var error = await _commonBo.GetErrorMessage("GPA09", generalProductAttributes.FormActionID); //Min days required should be greater than 0 if perishable item is Y

                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
                if (generalProductAttributes.MaxDaysRequired < generalProductAttributes.MinDaysRequired)
                {
                    var error = await _commonBo.GetErrorMessage("GPA10", generalProductAttributes.FormActionID); //Max days required should be greater than Min days required

                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
                //Seasonal Begin date
                if (!string.IsNullOrWhiteSpace(generalProductAttributes.SeasonBeginDate))
                {
                    if (!generalProductAttributes.SeasonBeginDate.IsDateinMMDDFormat())
                    {
                        var error = await _commonBo.GetErrorMessage("GPA11", generalProductAttributes.FormActionID); //Season begin date format is not correct

                        if (error.SeverityLevel == "Warning")
                            warningsList.Add(Mapper.Map<WarningDTO>(error));
                        else
                            errorList.Add(error);
                    }
                }
                else if (generalProductAttributes.SeasonalItem == "Y")
                {
                    var error = await _commonBo.GetErrorMessage("GPA13", generalProductAttributes.FormActionID); //Season begin date is required if SeasonalItem is Y

                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
                //Seasonal End date
                if (!string.IsNullOrWhiteSpace(generalProductAttributes.SeasonEndDate))
                {
                    if (!generalProductAttributes.SeasonEndDate.IsDateinMMDDFormat())
                    {
                        var error = await _commonBo.GetErrorMessage("GPA12", generalProductAttributes.FormActionID); //Season end date format is not correct

                        if (error.SeverityLevel == "Warning")
                            warningsList.Add(Mapper.Map<WarningDTO>(error));
                        else
                            errorList.Add(error);
                    }
                }
                else if (generalProductAttributes.SeasonalItem == "Y")
                {
                    var error = await _commonBo.GetErrorMessage("GPA14", generalProductAttributes.FormActionID); //Season end date is required if SeasonalItem is Y

                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
                // For Retail Item Types -- Unit price count, Unit price UOM, Tag Size are Mandatory
                if (generalProductAttributes.RetailPackagedItem == "Y")
                {
                    if (generalProductAttributes.UnitPricingCount == null || generalProductAttributes.UnitPricingCount == 0)
                    {
                        var error = await _commonBo.GetErrorMessage("GPA19", generalProductAttributes.FormActionID);
                        if (error.SeverityLevel == "Warning")
                            warningsList.Add(Mapper.Map<WarningDTO>(error));
                        else
                            errorList.Add(error);
                    }
                    if (string.IsNullOrWhiteSpace(generalProductAttributes.UnitPricingUOM))
                    {
                        var error = await _commonBo.GetErrorMessage("GPA20", generalProductAttributes.FormActionID);
                        if (error.SeverityLevel == "Warning")
                            warningsList.Add(Mapper.Map<WarningDTO>(error));
                        else
                            errorList.Add(error);
                    }
                    if (string.IsNullOrEmpty(generalProductAttributes.TagSize))
                    {
                        var error = await _commonBo.GetErrorMessage("GPA21", generalProductAttributes.FormActionID);
                        if (error.SeverityLevel == "Warning")
                            warningsList.Add(Mapper.Map<WarningDTO>(error));
                        else
                            errorList.Add(error);
                    }
                }
            }
            //if ((generalProductAttributes.Ignitable == "Y") || (generalProductAttributes.EPAListedWaste == "Y") ||
            //    (generalProductAttributes.Toxic == "Y") || (generalProductAttributes.Reactive == "Y") ||
            //    (generalProductAttributes.Corrosive == "Y") || (generalProductAttributes.ContainsBattery == "Y"))
            //{
            //    if(generalProductAttributes.Hazardous != "Y")
            //    {
            //        var error = await _commonBo.GetErrorMessage("GPA05", generalProductAttributes.FormActionID);  // Hazardous should be yes.

            //        if (error.SeverityLevel == "Warning")
            //            warningsList.Add(Mapper.Map<WarningDTO>(error));
            //        else
            //            errorList.Add(error); //Invalid email format.
            //    }
            //}

            var npErrors = await validateNutritionPanel(generalProductAttributes.NutritionalPanelList, generalProductAttributes.NutritionalInfoNotAvailableUntil, generalProductAttributes.FormActionID);

            gpaErrorDto.SubTabValidations = npErrors;
            gpaErrorDto.Errors = errorList;
            gpaErrorDto.Warnings = warningsList;
            return gpaErrorDto;
        }


        public async Task<List<SubTabValidationDTO>> validateNutritionPanel(List<NutritionalPanelDto> NutritionalPanelList, DateTime? NutritionalInfoNotAvailableUntil , int action = 1)
        {
            List<SubTabValidationDTO> errors = new List<SubTabValidationDTO>();
            //validate each panel.
            if (NutritionalPanelList != null && NutritionalPanelList.Count > 0)
            {
                foreach (NutritionalPanelDto panel in NutritionalPanelList)
                {
                    if (panel.IsDeleted) continue;
                    SubTabValidationDTO panelErrors = new SubTabValidationDTO
                    {
                        SubTabName = panel.SortOrder.ToString(),
                        Errors = new List<ErrorDTO>(),
                        Warnings = new List<WarningDTO>()
                    };
                    if (string.IsNullOrEmpty(panel.NutritionalPanelName) && NutritionalPanelList.Where(p => p.IsDeleted == false).ToList().Count > 1)
                    {
                        var error = await _commonBo.GetErrorMessage("GPA07", action); 
                        if (error.SeverityLevel == "Error")
                        {
                            panelErrors.Errors.Add(error);
                        }
                        else
                        {
                            panelErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                        }
                    }
                    if(NutritionalPanelList.Where(p => p.IsDeleted == false && p.NutritionalPanelName.Trim() == panel.NutritionalPanelName.Trim()).ToList().Count > 1)
                    {
                        var error = await _commonBo.GetErrorMessage("GPA16", action);
                        if (error.SeverityLevel == "Error")
                        {
                            panelErrors.Errors.Add(error);
                        }
                        else
                        {
                            panelErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                        }
                    }
                    if (string.IsNullOrEmpty(panel.FormattedGtin)){
                        var error = await _commonBo.GetErrorMessage("GPA15", action);
                        if (error.SeverityLevel == "Error")
                        {
                            panelErrors.Errors.Add(error);
                        }
                        else
                        {
                            panelErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                        }
                    }
                    if (NutritionalInfoNotAvailableUntil == null || (DateTime.Now.Subtract((DateTime)NutritionalInfoNotAvailableUntil)).Days >= 0)
                    {

                        // validate NutritionalInfo
                        foreach (var nutritionInfo in panel.NutritionalInfoList)
                        {
                            if (nutritionInfo.IsRequired == "Y" && nutritionInfo.Quantity == null && nutritionInfo.DailyValuePercentage == null)
                            {
                                var errorDTOTemplate = await _commonBo.GetErrorMessage("GPA06", action);
                                if (errorDTOTemplate.SeverityLevel == "Error")
                                {
                                    panelErrors.Errors.Add(new ErrorDTO()
                                    {
                                        ErrorCode = errorDTOTemplate.ErrorCode,
                                        SeverityLevel = errorDTOTemplate.SeverityLevel,
                                        ControlName = errorDTOTemplate.ControlName,
                                        ErrorDescription = String.Format(errorDTOTemplate.ErrorDescription, nutritionInfo.NutrientName)
                                    });
                                }
                                else
                                {
                                    panelErrors.Warnings.Add(new WarningDTO()
                                    {
                                        ErrorCode = errorDTOTemplate.ErrorCode,
                                        ControlName = errorDTOTemplate.ControlName,
                                        ErrorDescription = String.Format(errorDTOTemplate.ErrorDescription, nutritionInfo.NutrientName)
                                    });
                                }

                            }

                        }
                    }
                    if (panelErrors.Errors.Count > 0 || panelErrors.Warnings.Count > 0)
                    {
                        errors.Add(panelErrors);
                    }

                }
            }

            return errors;
        }

        public Task<GeneralProductAttributesDto> GetGPAWeightDetails(int itemFormID)
        {
            return _generalProductAttributesDac.GetGPAWeightDetails(itemFormID);
        }


        public Task<GeneralProductAttributesDto> GetGeneralProdutAttributes(int itemFormID)
        {
            return _generalProductAttributesDac.GetGeneralProductAttributes(itemFormID);
        }

        public Task<IEnumerable<DrugScheduleCodeDto>> GetDrugScheduleCodes()
        {
            return _generalProductAttributesDac.GetDrugScheduleCodes();
            //LookupDto[] drugScheduleCodes = new LookupDto[7];

            //int[] scheduleCodes = new int[] { 2, 3, 4, 5, 6, 8, 9 };
            //for (var i = 0; i < scheduleCodes.Length;  i++)
            //{
            //    drugScheduleCodes[i] = new LookupDto();
            //    drugScheduleCodes[i].Code = scheduleCodes[i].ToString();
            //    drugScheduleCodes[i].Description = scheduleCodes[i].ToString();
            //}
            //return Task.FromResult(drugScheduleCodes.AsEnumerable());
        }
    }
}
