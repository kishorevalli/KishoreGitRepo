﻿using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MoreLinq;
using AutoMapper;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class PackagingHierarchyBO : IPackagingHierarchyBO
    {
        protected readonly IPackagingHierarchyDac _packagingHierarchyDac;
        protected readonly IGeneralProductAttributesBO _generalProductAttributesBO;
        protected readonly IDsdAuthorizationRequestBO _dsdAuthorizationRequestBO;
        // protected readonly IBasicItemDefinitionBO _basicItemDefinitionBO;
        protected readonly ICommonBO _commonBo;
        public PackagingHierarchyBO(ICommonBO commonBO , IPackagingHierarchyDac packagingHierarchyDac , 
            IGeneralProductAttributesBO generalProductAttributesBO, IDsdAuthorizationRequestBO dsdAuthorizationRequestBO
            )
        {
            this._packagingHierarchyDac = packagingHierarchyDac;
            this._commonBo = commonBO;
            this._generalProductAttributesBO = generalProductAttributesBO;
            this._dsdAuthorizationRequestBO = dsdAuthorizationRequestBO;
           // this._basicItemDefinitionBO = basicItemDefinitionBO;
        }
        public async Task<IEnumerable<RetailPackTypeDto>> GetRetailPackTypesForItemForm(int itemFormID)
        {
            return await _packagingHierarchyDac.GetRetailPackTypesForItemForm(itemFormID);
        }

        //get existing packaging hierarchies from the packaging hierarchy table or new packaging hierarchies based on new retail pack types added in the BID screen\tables.
        public async Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchies(int itemFormID)
        {
            var retailpacktypes = await _packagingHierarchyDac.GetRetailPackTypesForItemForm(itemFormID);
            var existingPackagingHierarchies = await _packagingHierarchyDac.GetPackagingHierarchies(itemFormID);
            List<PackagingHierarchyDto> packagingHierarchies = new List<PackagingHierarchyDto>();

            
            if (retailpacktypes.Count() > 0)
            {
                foreach (var retailpack in retailpacktypes)
                {
                    //Retail Pack ( RetailPackType , RetailPackSize ,  Size , SizeUOM , LabelAmount)
                    if (existingPackagingHierarchies.Any(ph => (ph.RetailPackType == retailpack.RetailPackType && ph.RetailPackSize == retailpack.RetailPackSize && ph.Size == retailpack.Size
                                                                                                              && ph.SizeUOM == retailpack.SizeUOM && ph.LabelAmount == retailpack.LabelAmount)))
                    {
                        packagingHierarchies.Add(existingPackagingHierarchies.Where(ph => ph.RetailPackType == retailpack.RetailPackType && ph.RetailPackSize == retailpack.RetailPackSize && ph.Size == retailpack.Size
                                                                                                              && ph.SizeUOM == retailpack.SizeUOM && ph.LabelAmount == retailpack.LabelAmount).First());
                    }
                    else
                    {
                        PackagingHierarchyDto packagingHierarchy = new PackagingHierarchyDto();
                        List<OrderablePackLevelDto> orderablePackLevels = new List<OrderablePackLevelDto>();

                       
                        packagingHierarchy.RetailPackType = retailpack.RetailPackType;
                        packagingHierarchy.RetailPackSize = retailpack.RetailPackSize;
                        packagingHierarchy.RetailPackTypeDescription = retailpack.RetailPackTypeDescription;
                        packagingHierarchy.Size = retailpack.Size;
                        packagingHierarchy.SizeUOM = retailpack.SizeUOM;
                        packagingHierarchy.SizeUOMDescription = retailpack.SizeUOMDescription;
                        packagingHierarchy.LabelAmount = retailpack.LabelAmount;
                        packagingHierarchy.orderablePackLevels = orderablePackLevels;

                        packagingHierarchies.Add(packagingHierarchy);
                    }
                }
            }
            else if (existingPackagingHierarchies.Count() > 0) //For non retail pack type , there will be no retail pack type but there will be packaging hierarchy with blank retail pack desc.
            {
                foreach (var ph in existingPackagingHierarchies)
                {
                    packagingHierarchies.Add(ph);
                }
            }

            //if ((existingPackagingHierarchies == null) || (existingPackagingHierarchies.ToList().Count == 0))
            //{
            //    var modelItemformId = await GetValidItemFormIDForModellingByModelPHItemCode(itemFormID, currentUserId);
            //    if (modelItemformId != 0)
            //    {
            //        await GetModelDataForPackagingHierarchy(retailpacktypes, packagingHierarchies, modelItemformId);

            //    }

            //}
            

            var sortedPackagingHierarchies = SortPackagingHierarchies(packagingHierarchies);
            return sortedPackagingHierarchies;
            //return await _packagingHierarchyDac.GetPackagingHierarchies(itemFormID);
        }

        public async Task GetModelDataForPackagingHierarchy(string currentUserId, int? modelItemCode , int itemFormID , UserType userType)
        {
            var retailpacktypes = await _packagingHierarchyDac.GetRetailPackTypesForItemForm(itemFormID);
            List<PackagingHierarchyDto> packagingHierarchies = new List<PackagingHierarchyDto>();
            var modelItemformId = await GetValidItemFormIDForModellingByModelPHItemCode(modelItemCode, itemFormID ,currentUserId , userType);
                if (modelItemformId != 0)
                {
            var modelPackagingHierarchies = await _packagingHierarchyDac.GetPackagingHierarchies(modelItemformId);
            if (modelPackagingHierarchies != null && modelPackagingHierarchies.Count() > 0)
            {
                var regularModelPH = modelPackagingHierarchies.Where(ph => ph.RetailPackType == "R" || ph.RetailPackType == "").FirstOrDefault();
                if (regularModelPH != null)
                {
                    var retailpackR = retailpacktypes.Where(rp => rp.RetailPackType == "R").FirstOrDefault();
                     //   regularModelPH.ID = 0;
                    regularModelPH.RetailPackSize = (retailpackR != null) ? retailpackR.RetailPackSize : null;
                    regularModelPH.RetailPackType = (retailpackR != null) ? retailpackR.RetailPackType : "";
                    regularModelPH.RetailPackTypeDescription = (retailpackR != null) ? retailpackR.RetailPackTypeDescription : "";
                    regularModelPH.Size = (retailpackR != null) ? retailpackR.Size : null;
                    regularModelPH.SizeUOM = (retailpackR != null) ? retailpackR.SizeUOM : "";
                    regularModelPH.LabelAmount = (retailpackR != null) ? retailpackR.LabelAmount : null;
                    regularModelPH.MasterCaseGTIN = null;
                        regularModelPH.MasterCaseGTINCheckDigit = null;                        
                    regularModelPH.InnerCaseGTIN = null;
                        regularModelPH.InnerCaseGTINCheckDigit = null;
                    regularModelPH.PalletGTIN = "";
                        regularModelPH.ItemFormID = itemFormID;
                        regularModelPH.IsDirty = true;

                }
                packagingHierarchies.Remove((packagingHierarchies.Where(ph => ph.RetailPackType == "R" || ph.RetailPackType == "").FirstOrDefault()));
               packagingHierarchies.Add(regularModelPH);
                  await  SavePackagingHierarchies(packagingHierarchies , true);
            }
        }
        }


        public async Task GetModelDataForPackagingHierarchyByGtin(string currentUserId, decimal gtin, int itemFormID, UserType userType)
        {
            var retailpacktypes = await _packagingHierarchyDac.GetRetailPackTypesForItemForm(itemFormID);
            List<PackagingHierarchyDto> packagingHierarchies = new List<PackagingHierarchyDto>();
            var modelItemformId = await GetValidItemFormIDForModellingByGtin(gtin, itemFormID, currentUserId, userType);
            if (modelItemformId != 0)
            {
                var modelPackagingHierarchies = await _packagingHierarchyDac.GetPackagingHierarchies(modelItemformId);
                if (modelPackagingHierarchies != null && modelPackagingHierarchies.Count() > 0)
                {
                    var regularModelPH = modelPackagingHierarchies.Where(ph => ph.RetailPackType == "R" || ph.RetailPackType == "").FirstOrDefault();
                    if (regularModelPH != null)
                    {
                        var retailpackR = retailpacktypes.Where(rp => rp.RetailPackType == "R").FirstOrDefault();
                        //   regularModelPH.ID = 0;
                        regularModelPH.RetailPackSize = (retailpackR != null) ? retailpackR.RetailPackSize : null;
                        regularModelPH.RetailPackType = (retailpackR != null) ? retailpackR.RetailPackType : "";
                        regularModelPH.RetailPackTypeDescription = (retailpackR != null) ? retailpackR.RetailPackTypeDescription : "REGULAR";
                        regularModelPH.Size = (retailpackR != null) ? retailpackR.Size : null;
                        regularModelPH.SizeUOM = (retailpackR != null) ? retailpackR.SizeUOM : "";
                        regularModelPH.LabelAmount = (retailpackR != null) ? retailpackR.LabelAmount : null;
                        regularModelPH.MasterCaseGTIN = null;
                        regularModelPH.MasterCaseGTINCheckDigit = null;
                        regularModelPH.InnerCaseGTIN = null;
                        regularModelPH.InnerCaseGTINCheckDigit = null;
                        regularModelPH.PalletGTIN = "";
                        regularModelPH.ItemFormID = itemFormID;
                        regularModelPH.IsDirty = true;

                    }
                    packagingHierarchies.Remove((packagingHierarchies.Where(ph => ph.RetailPackType == "R" || ph.RetailPackType == "").FirstOrDefault()));
                    packagingHierarchies.Add(regularModelPH);
                    await SavePackagingHierarchies(packagingHierarchies, true);
                }
            }
        }

        //public async Task GetDataForPackagingHierarchyByModleItemCode(int modelItemCode , IEnumerable<RetailPackTypeDto> retailpacktypes, List<PackagingHierarchyDto> packagingHierarchies, int modelItemformId)
        //{

        //    var modelPackagingHierarchies = await _packagingHierarchyDac.GetPackagingHierarchies(modelItemformId);
        //    if (modelPackagingHierarchies != null && modelPackagingHierarchies.Count() > 0)
        //    {
        //        var regularModelPH = modelPackagingHierarchies.Where(ph => ph.RetailPackType == "R" || ph.RetailPackType == "").FirstOrDefault();
        //        if (regularModelPH != null)
        //        {
        //            var retailpackR = retailpacktypes.Where(rp => rp.RetailPackType == "R").FirstOrDefault();
        //            regularModelPH.RetailPackSize = (retailpackR != null) ? retailpackR.RetailPackSize : null;
        //            regularModelPH.RetailPackType = (retailpackR != null) ? retailpackR.RetailPackType : "";
        //            regularModelPH.RetailPackTypeDescription = (retailpackR != null) ? retailpackR.RetailPackTypeDescription : "";
        //            regularModelPH.Size = (retailpackR != null) ? retailpackR.Size : null;
        //            regularModelPH.SizeUOM = (retailpackR != null) ? retailpackR.SizeUOM : "";
        //            regularModelPH.LabelAmount = (retailpackR != null) ? retailpackR.LabelAmount : null;
        //            regularModelPH.MasterCaseGTIN = null;
        //            regularModelPH.InnerCaseGTIN = null;
        //            regularModelPH.PalletGTIN = "";

        //        }
        //        packagingHierarchies.Remove((packagingHierarchies.Where(ph => ph.RetailPackType == "R" || ph.RetailPackType == "").FirstOrDefault()));
        //        packagingHierarchies.Add(regularModelPH);
        //    }
        //}

        public async Task<int> GetValidItemFormIDForModellingByModelPHItemCode(int? modelItemCode ,int? itemformId , string userId , UserType userType)
        {
            List<int> userVendorIds = new List<int>();
            if (userType == UserType.Vendor)
            {
                var userVendors = await _commonBo.GetAssociatedVendorListForExternalUser(userId);
                userVendorIds = userVendors.Select(v => v.VendorNumber).ToList();
            }
            var modelItemId = await _packagingHierarchyDac.GetValidItemFormIDForModellingByModelPHItemCode(modelItemCode , itemformId, userVendorIds , userType);
            //var modelPackagingHierarchies = await _packagingHierarchyDac.GetPackagingHierarchiesByModelItemCode(itemformId);
            return modelItemId.FirstOrDefault();
        }

        public async Task<int> GetValidItemFormIDForModellingByGtin(decimal gtin, int? itemformId, string userId, UserType userType)
        {
            List<int> userVendorIds = new List<int>();
            if (userType == UserType.Vendor)
            {
                var userVendors = await _commonBo.GetAssociatedVendorListForExternalUser(userId);
                userVendorIds = userVendors.Select(v => v.VendorNumber).ToList();
            }
            var modelItemId = await _packagingHierarchyDac.GetValidItemFormIDForModellingByGtin(gtin, itemformId, userVendorIds, userType);
            //var modelPackagingHierarchies = await _packagingHierarchyDac.GetPackagingHierarchiesByModelItemCode(itemformId);
            return modelItemId.FirstOrDefault();
        }

        public async Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchiesByModelItemCode(int? itemformId)
        {
            var modelPackagingHierarchies = await _packagingHierarchyDac.GetPackagingHierarchiesByModelItemCode(itemformId);
            return modelPackagingHierarchies;
        }

        public async Task<IEnumerable<PackagingHierarchyDto>> GetExistingPackagingHierarchies(int itemFormID)
        {
            return  await _packagingHierarchyDac.GetPackagingHierarchies(itemFormID);            
        }

        public async Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchiesByModelGTIN(decimal gtin)
        {
            return await _packagingHierarchyDac.GetPackagingHierarchiesByModelGTIN(gtin);
        }
      

        public async Task<bool> DeletePackagingHierarchies(GTINRetailPackInfoDto gtinRetailPackInfo)
        {
            return await _packagingHierarchyDac.DeletePackagingHierarchies(gtinRetailPackInfo);
        }

        //Regular retail pack should be first and other retail packs should be sorted in the alphabetical order.
        public List<PackagingHierarchyDto> SortPackagingHierarchies(List<PackagingHierarchyDto> packagingHierarchies)
        {
            if (packagingHierarchies != null && packagingHierarchies.Count > 0)
            {
                List<PackagingHierarchyDto> sortedPackagingHierarchies = new List<PackagingHierarchyDto>();
                sortedPackagingHierarchies = packagingHierarchies.Where(ph => ph.RetailPackType == "R").ToList();
                packagingHierarchies.RemoveAll(ph => ph.RetailPackType == "R");
                if (packagingHierarchies.Count > 0)
                {
                    sortedPackagingHierarchies = sortedPackagingHierarchies.Concat(packagingHierarchies.OrderBy(ph => ph.RetailPackType)).ToList();
                }
                return sortedPackagingHierarchies;
            }
            else return packagingHierarchies;
        }


        public async Task<IEnumerable<CaseCodeTypeDto>> GetCaseCodeTypes()
        {
            return await _packagingHierarchyDac.GetCaseCodeTypes();           
        }

        public async Task<IEnumerable<OrderingLevelsDto>> GetOrderingLevels()
        {
            return await _packagingHierarchyDac.GetOrderingLevels();
        }


        //Get Distinct Orgs for the User Id.
        public async Task<IEnumerable<VendorDomainDto>> GetVendorOrgs(string userId, string groupName ="")
        {
            IEnumerable<VendorDomainDto> vendorOrgsList = await _commonBo.GetAssociatedVendorListForExternalUser(userId, groupName);

            if (vendorOrgsList != null && vendorOrgsList.Count() > 0)
            {
                return vendorOrgsList.DistinctBy(vo => vo.OrganizationID);
            }

            return null;
        }


        //Get vendors for the selected orgs.
        public async Task<IEnumerable<VendorDomainDto>> GetVendorsForSelectedOrgs(List<int> selectedOrgs , string userId , string groupName)
        {
            IEnumerable<VendorDomainDto> vendorOrgsList = await _commonBo.GetAssociatedVendorListForExternalUser(userId, groupName);
            IEnumerable<VendorDomainDto> vendorforSelectedOrgs = null;
            if (vendorOrgsList != null && vendorOrgsList.Count() > 0)
            {
                vendorforSelectedOrgs = vendorOrgsList.Where(vo => selectedOrgs.Contains(vo.OrganizationID) && (vo.VendorType == "DSD" || vo.VendorType == "WHS"));
            }
            return vendorforSelectedOrgs;
        }


        public async Task<IEnumerable<VendorDomainDto>> GetVendorsDomain(string userId, string groupName="")
        {
            IEnumerable<VendorDomainDto> vendorOrgsList = await _commonBo.GetAssociatedVendorListForExternalUser(userId, groupName);

            if (vendorOrgsList != null && vendorOrgsList.Count() > 0)
            {
                return vendorOrgsList;
            }

            return null;
        }

        public async Task<ItemValidationDTO> ValidatePackagingHierarchy(List<PackagingHierarchyDto> packagingHierarchyList , int formActionId = 1)
        {
            ItemValidationDTO TabErrorDto = new ItemValidationDTO();
            TabErrorDto.TabName = "Packaging Hierarchy";

            List<ErrorDTO> tabErrorList = new List<ErrorDTO>();
            List<WarningDTO> tabWarningsList = new List<WarningDTO>();

            List<SubTabValidationDTO> errors = new List<SubTabValidationDTO>();
            //validate each panel.
            if (packagingHierarchyList != null && packagingHierarchyList.Count > 0)
            {
                foreach (PackagingHierarchyDto packagingHierarchy in packagingHierarchyList)
                {
                    //if (packagingHierarchy.IsDeleted) continue;

                    SubTabValidationDTO phErrors = new SubTabValidationDTO
                    {
                        //Retail pack is added as the sub tab name to identify the packaging hierarchy uniquely. 
                        SubTabName = (packagingHierarchy.RetailPackSize != null ? packagingHierarchy.RetailPackSize.ToString() : "") +
                                     (packagingHierarchy.RetailPackType != null ? packagingHierarchy.RetailPackType.ToString() : "") +
                                     (packagingHierarchy.Size != null ? packagingHierarchy.Size.ToString() : "") +
                                     (packagingHierarchy.SizeUOM != null ? packagingHierarchy.SizeUOM.ToString() : "") +
                                     (packagingHierarchy.LabelAmount != null ? packagingHierarchy.LabelAmount.ToString() : ""),

                        Errors = new List<ErrorDTO>(),
                        Warnings = new List<WarningDTO>()
                    };



                    //Packaging Hierarchy Validations:
                    var repack = (packagingHierarchy.MasterCaseSellingUnit / packagingHierarchy.InnerCaseSellingUnits);
                    bool isWarehouseItem = CheckIsWarehouseItem(packagingHierarchy);


                    //PH/15
                    //GetWeightDetailsFromGPA          //TODO: get only the required weight details from GPA. 
                    var gpa = await _generalProductAttributesBO.GetGPAWeightDetails(packagingHierarchy.ItemFormID);
                    if (gpa != null)
                    {
                        if ((gpa.RandomWeight == "Y") || ((gpa.VariableWeightIndicator != "N") && (gpa.VariableWeightIndicator != null)) || (isWarehouseItem && repack > 1))
                        {
                            await ValidateWeights(packagingHierarchy, phErrors);
                        }
                    }

                    if (IsMCHeightLengthDepthValid(packagingHierarchy, isWarehouseItem, repack) == false)
                    {
                        var error = await _commonBo.GetErrorMessage("PCH03", packagingHierarchy.FormActionID);
                        if (error.SeverityLevel == "Warning")
                            phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                        else
                            phErrors.Errors.Add(error);

                    }

                    if ((packagingHierarchy.MasterCaseGTIN == null) || (packagingHierarchy.MasterCaseGTIN == 0))
                    {
                        var error = await _commonBo.GetErrorMessage("PCH31", packagingHierarchy.FormActionID);
                        if (error.SeverityLevel == "Warning")
                            phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                        else
                            phErrors.Errors.Add(error);
                    }


                    if (packagingHierarchy.InnerPackExist == "Y")
                    {
                        if(packagingHierarchy.InnerCaseGTIN == null)
                        {
                            var error = await _commonBo.GetErrorMessage("PCH30", packagingHierarchy.FormActionID);
                            if (error.SeverityLevel == "Warning")
                                phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                            else
                                phErrors.Errors.Add(error);
                        }

                        await ValidateICHeightLengthDepth(packagingHierarchy, phErrors, repack, isWarehouseItem);

                        await ValidateICCubicFootage(packagingHierarchy, phErrors);
                    }

                    

                    await ValidateMCCubicFootage(packagingHierarchy, phErrors);
                    await ValidateHiAndTi(packagingHierarchy, phErrors, repack, isWarehouseItem);

                    

                    if (isWarehouseItem)
                    {
                        if (packagingHierarchy.MasterCaseCodeType == "")
                        {
                            var error = await _commonBo.GetErrorMessage("PCH15", packagingHierarchy.FormActionID);
                            if (error.SeverityLevel == "Warning")
                                phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                            else
                                phErrors.Errors.Add(error);
                        }
                    }

                    await ValidateGtins(packagingHierarchy, phErrors);

                    await ValidateOrderingPackLevels(packagingHierarchy, phErrors);

                    errors.Add(phErrors);
                }
            }
            TabErrorDto.Errors = tabErrorList;
            TabErrorDto.Warnings = tabWarningsList;
            TabErrorDto.SubTabValidations = errors;
            return TabErrorDto;
        }

        private async Task ValidateOrderingPackLevels(PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {

            if ((packagingHierarchy.orderablePackLevels == null) || (packagingHierarchy.orderablePackLevels.Count == 0))
            {
                var error = await _commonBo.GetErrorMessage("PCH23", packagingHierarchy.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);                
            }

            if (packagingHierarchy.orderablePackLevels.Count > 0)
            {
                foreach (var opl in packagingHierarchy.orderablePackLevels)
                {
                    if ((opl.OrderingPackagingLevelID == null) || (opl.OrderingPackagingLevelID == 0))
                    {
                        var error = await _commonBo.GetErrorMessage("PCH19", packagingHierarchy.FormActionID);
                        if (error.SeverityLevel == "Warning")
                            phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                        else
                            phErrors.Errors.Add(error);
                        break;
                    }
                    else
                    {
                        await ValidateOrderingQty(opl , packagingHierarchy , phErrors);
                    }                   

                }
            }

            if (packagingHierarchy.SubmittedUserTypeID == UserType.Buyer)
            {

                if (packagingHierarchy.orderablePackLevels.Count > 0)
                {
                    var isWHErrorAdded = false;
                    foreach (var opl in packagingHierarchy.orderablePackLevels)
                    {
                        if (opl.VendorType == "WHS")
                        {
                            if ((opl.Warehouse == null) && (isWHErrorAdded == false))
                            {
                                var error = await _commonBo.GetErrorMessage("PCH25", packagingHierarchy.FormActionID);
                                if (error.SeverityLevel == "Warning")
                                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                                else
                                    phErrors.Errors.Add(error);
                                isWHErrorAdded = true;
                            }
                        }
                   
                        if ((opl.ShippingPackagingLevelID == null) || (opl.ShippingPackagingLevelID == 0))
                        {
                            if (!(phErrors.Errors.Any(e => e.ErrorCode == "PCH20") || phErrors.Warnings.Any(e => e.ErrorCode == "PCH20")))
                                {
                                var error = await _commonBo.GetErrorMessage("PCH20", packagingHierarchy.FormActionID);
                                if (error.SeverityLevel == "Warning")
                                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                                else
                                    phErrors.Errors.Add(error);
                              }
                           // break;
                        }
                        else
                        {
                            await ValidateShippingPackQty(opl, packagingHierarchy, phErrors);
                        }

                        if (opl.EffectiveDate == null)
                        {
                            if (!(phErrors.Errors.Any(e => e.ErrorCode == "PCH27") || phErrors.Warnings.Any(e => e.ErrorCode == "PCH27")))
                            {
                                var error = await _commonBo.GetErrorMessage("PCH27", packagingHierarchy.FormActionID);
                                if (error.SeverityLevel == "Warning")
                                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                                else
                                    phErrors.Errors.Add(error);
                            }
                        }


                        if (opl.TerminationDate == null)
                        {
                            if (!(phErrors.Errors.Any(e => e.ErrorCode == "PCH28") || phErrors.Warnings.Any(e => e.ErrorCode == "PCH28")))
                            {
                                var error = await _commonBo.GetErrorMessage("PCH28", packagingHierarchy.FormActionID);
                                if (error.SeverityLevel == "Warning")
                                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                                else
                                    phErrors.Errors.Add(error);
                            }                     
                        }

                        if (opl.ShipMax == null || opl.ShipMax == 0)
                        {
                            if (!(phErrors.Errors.Any(e => e.ErrorCode == "PCH29") || phErrors.Warnings.Any(e => e.ErrorCode == "PCH29")))
                            {
                                var error = await _commonBo.GetErrorMessage("PCH29", packagingHierarchy.FormActionID);
                                if (error.SeverityLevel == "Warning")
                                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                                else
                                    phErrors.Errors.Add(error);
                            }            
                        }



                    }
                }
            }
        }

        private async Task ValidateOrderingQty(OrderablePackLevelDto opl , PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {
            switch (opl.OrderingPackagingLevelID)
            {
                case 1: // pallet
                    if ((packagingHierarchy.LayersOnPallet * packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.MasterCaseSellingUnit) == 0)
                    {
                        await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    else
                    {
                        if ((packagingHierarchy.LayersOnPallet * packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.MasterCaseSellingUnit) != opl.OrderPackQuantity)
                        {
                            await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                        }
                    }
                    break;
                case 2: // Tier
                    if ((packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.MasterCaseSellingUnit) == 0)
                    {
                        await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    else
                    {
                        if ((packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.MasterCaseSellingUnit) != opl.OrderPackQuantity)
                        {
                            await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                        }
                    }             
                    break;
                case 3: // MC
                    if ((packagingHierarchy.MasterCaseSellingUnit == 0) || (packagingHierarchy.MasterCaseSellingUnit == null))
                    {
                        await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    else
                    {
                        if (packagingHierarchy.MasterCaseSellingUnit != opl.OrderPackQuantity)
                        {
                            await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                        }

                    }                 
                    break;
                case 4: //IC
                    if ((packagingHierarchy.InnerCaseSellingUnits == 0) || (packagingHierarchy.InnerCaseSellingUnits == null))
                    {
                        await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    else
                    {
                        if (packagingHierarchy.InnerCaseSellingUnits != opl.OrderPackQuantity)
                        {
                            await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                        }
                    }             
                    break;
                case 5: //Each
                    if (opl.OrderPackQuantity != 1)
                    {
                        await AddInvalidOrderingQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    break;
            }
        }


        private async Task ValidateShippingPackQty(OrderablePackLevelDto opl, PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {
            switch (opl.ShippingPackagingLevelID)
            {
                case 1: // pallet
                    if ((packagingHierarchy.LayersOnPallet * packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.MasterCaseSellingUnit) == 0)
                    {
                        await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    else
                    {
                        if ((packagingHierarchy.LayersOnPallet * packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.MasterCaseSellingUnit) != opl.ShippingPackQty)
                        {
                            await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                        }
                    }
                    break;
                case 2: // Tier
                    if ((packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.MasterCaseSellingUnit) == 0)
                    {
                        await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    else
                    {
                        if ((packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.MasterCaseSellingUnit) != opl.ShippingPackQty)
                        {
                            await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                        }
                    }
                    break;
                case 3: // MC
                    if ((packagingHierarchy.MasterCaseSellingUnit == 0) || (packagingHierarchy.MasterCaseSellingUnit == null))
                    {
                        await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    else
                    {
                        if (packagingHierarchy.MasterCaseSellingUnit != opl.ShippingPackQty)
                        {
                            await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                        }

                    }
                    break;
                case 4: //IC
                    if ((packagingHierarchy.InnerCaseSellingUnits == 0) || (packagingHierarchy.InnerCaseSellingUnits == null))
                    {
                        await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    else
                    {
                        if (packagingHierarchy.InnerCaseSellingUnits != opl.ShippingPackQty)
                        {
                            await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                        }
                    }
                    break;
                case 5: //Each
                    if (opl.ShippingPackQty != 1)
                    {
                        await AddInvalidShippingPackQtyErrorMsg(opl, packagingHierarchy, phErrors);
                    }
                    break;
            }
        }

        private async Task AddInvalidOrderingQtyErrorMsg(OrderablePackLevelDto opl, PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {
            var error = await _commonBo.GetErrorMessage("PCH21", packagingHierarchy.FormActionID);
            error.ErrorDescription = error.ErrorDescription + " Vendor#:" + opl.VendorNumber + " Ordering Level:" + opl.OrderingPackagingLevelDescription;
            if (error.SeverityLevel == "Warning")
                phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
            else
                phErrors.Errors.Add(error);
        }

        private async Task AddInvalidShippingPackQtyErrorMsg(OrderablePackLevelDto opl, PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {
            var error = await _commonBo.GetErrorMessage("PCH22", packagingHierarchy.FormActionID);
            error.ErrorDescription = error.ErrorDescription + " Vendor#:" + opl.VendorNumber + " Shipping Level:" + opl.ShippingPackagingLevelDescription;
            if (error.SeverityLevel == "Warning")
                phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
            else
                phErrors.Errors.Add(error);
        }

        private async Task ValidateGtins(PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {
            var bidGtins = await _commonBo.GetBasicItemDefinitionGTIN(packagingHierarchy.ItemFormID);

            if (packagingHierarchy.MasterCaseGTIN != null && packagingHierarchy.MasterCaseGTIN != 0) 
            {
                if (bidGtins.Any(gtin => (gtin.GTIN == packagingHierarchy.MasterCaseGTIN)))
                {
                    var error = await _commonBo.GetErrorMessage("PCH16", packagingHierarchy.FormActionID);              
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }
                else
                {
                   
                        var pidmdto = await _commonBo.GetPMDSDataByGTIN(packagingHierarchy.MasterCaseGTIN);
                        if (pidmdto != null && pidmdto.BasicItemDefinition != null)
                    {
                            var error = await _commonBo.GetErrorMessage("PCH16", packagingHierarchy.FormActionID);                       
                            if (error.SeverityLevel == "Warning")
                                phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                            else
                                phErrors.Errors.Add(error);

                        }
                  
                }
            }

            if (packagingHierarchy.InnerCaseGTIN != null && packagingHierarchy.InnerCaseGTIN != 0)
            {
                if (bidGtins.Any(gtin => (gtin.GTIN == packagingHierarchy.InnerCaseGTIN)))
                {
                    var error = await _commonBo.GetErrorMessage("PCH17", packagingHierarchy.FormActionID);                
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }
                else
                {
                    var pidmdto = await _commonBo.GetPMDSDataByGTIN(packagingHierarchy.InnerCaseGTIN);
                    if (pidmdto != null && pidmdto.BasicItemDefinition != null)
                    {
                        var error = await _commonBo.GetErrorMessage("PCH17", packagingHierarchy.FormActionID);                        
                        if (error.SeverityLevel == "Warning")
                            phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                        else
                            phErrors.Errors.Add(error);

                    }
                }
            }



            if (packagingHierarchy.PalletGTIN != null && packagingHierarchy.PalletGTIN != "")
            {
               
                    Int64 nPalletGtin;
                    var isNumeric = Int64.TryParse(packagingHierarchy.PalletGTIN, out nPalletGtin);
                // packagingHierarchy.MasterCaseVendorItemGTIN = isNumeric ? String.Format("{0:000-00000-00000}", nPalletGtin) : vendorItemCode;
                // packagingHierarchy.IsDirty = true;

                if (isNumeric)
                {
                    if (bidGtins.Any(gtin => (gtin.GTIN == nPalletGtin)))
                    {
                        var error = await _commonBo.GetErrorMessage("PCH18", packagingHierarchy.FormActionID);
                        if (error.SeverityLevel == "Warning")
                            phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                        else
                            phErrors.Errors.Add(error);
                    }
                    else
                    {
                        var pidmdto = await _commonBo.GetPMDSDataByGTIN(nPalletGtin);
                        if (pidmdto != null && pidmdto.BasicItemDefinition != null)
                        {
                            var error = await _commonBo.GetErrorMessage("PCH18", packagingHierarchy.FormActionID);
                            if (error.SeverityLevel == "Warning")
                                phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                            else
                                phErrors.Errors.Add(error);

                        }
                    }
                }
            }
        }


        private async Task ValidateICHeightLengthDepth(PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors, int? repack, bool isWarehouseItem)
        {
            if (IsICHeightLengthDepthValid(packagingHierarchy, isWarehouseItem, repack) == false)
            {
                var error = await _commonBo.GetErrorMessage("PCH07", packagingHierarchy.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);

            }
        }

        private async Task ValidateICCubicFootage(PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {
            if ((packagingHierarchy.InnerCaseLength * packagingHierarchy.InnerCaseDepth * packagingHierarchy.InnerCaseHeight) > 1920)
            {
                var error = await _commonBo.GetErrorMessage("PCH08", packagingHierarchy.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);
            }
        }

        private async Task ValidateWeights(PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {
            if ((packagingHierarchy.MasterCaseWeight == 0) || (packagingHierarchy.MasterCaseWeight == null))
            {
                var error = await _commonBo.GetErrorMessage("PCH01", packagingHierarchy.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);
            }

            if ((packagingHierarchy.MasterCaseNetWeight == 0) || (packagingHierarchy.MasterCaseNetWeight == null))
            {
                var error = await _commonBo.GetErrorMessage("PCH05", packagingHierarchy.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);
            }

            if (packagingHierarchy.InnerPackExist == "Y")
            {
                //Inner Case weight                          
                if ((packagingHierarchy.InnerCaseWeight == 0) || (packagingHierarchy.InnerCaseWeight == null))
                {
                    var error = await _commonBo.GetErrorMessage("PCH04", packagingHierarchy.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }

                if ((packagingHierarchy.InnerCaseNetWeight == 0) || (packagingHierarchy.InnerCaseNetWeight == null))
                {
                    var error = await _commonBo.GetErrorMessage("PCH06", packagingHierarchy.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }
            }
        }

        private async Task ValidateHiAndTi(PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors, int? repack, bool isWarehouseItem)
        {
            if (isWarehouseItem && repack > 1)
            {
                if ((packagingHierarchy.MasterCasesInSinglePalletLayer == null) || (packagingHierarchy.MasterCasesInSinglePalletLayer == 0))
                {
                    var error = await _commonBo.GetErrorMessage("PCH12", packagingHierarchy.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }

                if ((packagingHierarchy.LayersOnPallet == null) || (packagingHierarchy.LayersOnPallet == 0))
                {
                    var error = await _commonBo.GetErrorMessage("PCH13", packagingHierarchy.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }
            }
            else
            {
                if ((packagingHierarchy.MasterCasesInSinglePalletLayer != null || packagingHierarchy.MasterCasesInSinglePalletLayer > 0)
                                                    && (packagingHierarchy.LayersOnPallet == null || packagingHierarchy.LayersOnPallet == 0))
                {
                    var error = await _commonBo.GetErrorMessage("PCH14", packagingHierarchy.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }

                if ((packagingHierarchy.LayersOnPallet != null || packagingHierarchy.LayersOnPallet > 0)
                                                   && (packagingHierarchy.MasterCasesInSinglePalletLayer == null || packagingHierarchy.MasterCasesInSinglePalletLayer == 0))
                {
                    var error = await _commonBo.GetErrorMessage("PCH14", packagingHierarchy.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }
            }
        }

        private async Task ValidateMCCubicFootage(PackagingHierarchyDto packagingHierarchy, SubTabValidationDTO phErrors)
        {
            if ((packagingHierarchy.MasterCaseLength * packagingHierarchy.MasterCaseDepth * packagingHierarchy.MasterCaseHeight) > 1920)
            {
                var error = await _commonBo.GetErrorMessage("PCH09", packagingHierarchy.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);
            }


            if ((packagingHierarchy.MasterCaseLength * packagingHierarchy.MasterCaseDepth * packagingHierarchy.MasterCaseHeight * packagingHierarchy.MasterCasesInSinglePalletLayer * packagingHierarchy.LayersOnPallet) > 193920)
            {
                var error = await _commonBo.GetErrorMessage("PCH10", packagingHierarchy.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);
            }

            if ((packagingHierarchy.MasterCaseHeight * packagingHierarchy.LayersOnPallet) > 101)
            {
                var error = await _commonBo.GetErrorMessage("PCH11", packagingHierarchy.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);
            }
        }

        private static Boolean IsMCHeightLengthDepthValid(PackagingHierarchyDto packagingHierarchy , bool isWarehouseItem , int? repack)
        {
            if ((isWarehouseItem) && (repack > 1))
            {
                //MC Height is required
                if ((packagingHierarchy.MasterCaseHeight != null) && (packagingHierarchy.MasterCaseLength != null) && (packagingHierarchy.MasterCaseDepth != null))
                {
                    return true;
                }
            }
            else
            {
                if ((packagingHierarchy.MasterCaseHeight != null) && (packagingHierarchy.MasterCaseLength != null) && (packagingHierarchy.MasterCaseDepth != null))
                {
                    return true;
                }
                else if ((packagingHierarchy.MasterCaseHeight == null) && (packagingHierarchy.MasterCaseLength == null) && (packagingHierarchy.MasterCaseDepth == null))
                {
                    return true;
                }

            }                      

            return false;
        }

        private static Boolean IsICHeightLengthDepthValid(PackagingHierarchyDto packagingHierarchy, bool isWarehouseItem, int? repack)
        {
            if ((isWarehouseItem) && (repack > 1))
            {
                //MC Height is required
                //if ((packagingHierarchy.InnerCaseHeight == null) || (packagingHierarchy.InnerCaseLength == null) || (packagingHierarchy.InnerCaseDepth == null))
                //{
                //    return false;
                //}
                if ((packagingHierarchy.InnerCaseHeight != null) && (packagingHierarchy.InnerCaseLength != null) && (packagingHierarchy.InnerCaseDepth != null))
                {
                    return true;
                }
            }
            else
            {
                if ((packagingHierarchy.InnerCaseHeight != null) && (packagingHierarchy.InnerCaseLength != null) && (packagingHierarchy.InnerCaseDepth != null))
                {
                    return true;
                }
                else if ((packagingHierarchy.InnerCaseHeight == null) && (packagingHierarchy.InnerCaseLength == null) && (packagingHierarchy.InnerCaseDepth == null))
                {
                    return true;
                }
            }           

            return false;
        }

        private static bool CheckIsWarehouseItem(PackagingHierarchyDto packagingHierarchy)
        {
          
            //check if it is a warehouse item
            foreach (OrderablePackLevelDto opl in packagingHierarchy.orderablePackLevels)
            {
                if (opl.VendorType == "WHS")
                    return true;
            }
            return false;
        }


        //public async Task<ErrorDTO> GetErrorMessage(string ErrorCode, int action = 1)
        //{
        //    IEnumerable<ErrorDTO> Errors = await _generalProductAttributesDac.GetErrorMessages();
        //    var errorDTOTemplate = Errors.FirstOrDefault(e => e.ErrorCode == ErrorCode);
        //    if (action == 5)
        //    {
        //        return new ErrorDTO()
        //        {
        //            ErrorCode = errorDTOTemplate.ErrorCode,
        //            SeverityLevel = "Error",
        //            ControlName = errorDTOTemplate.ControlName,
        //            ErrorDescription = errorDTOTemplate.ErrorDescription
        //        };
        //    }
        //    return errorDTOTemplate;
        //}

        public async Task<bool> SavePackagingHierarchies(List<PackagingHierarchyDto> packagingHierarchyList , bool isModeling = false)
        {
            SetUserID(packagingHierarchyList);
            
            bool successFlag = false;
            try
            {
                foreach(var packagingHierarchy in packagingHierarchyList)
                {
                    if (packagingHierarchy.MasterCaseCodeType == "VI")
                    {    await GetMasterCaseVendorItemGtin(packagingHierarchy);    }

                    var phId = await _packagingHierarchyDac.IsPackagingHierarchyExistsForItemForm(packagingHierarchy);
                    var packagingHierarchyExists = phId == 0 ? false : true;
                    if (packagingHierarchyExists)
                    {
                        if (packagingHierarchy.IsDirty)
                        {

                            //Update packaging Hiearchy     
                            if (isModeling)
                                packagingHierarchy.ID = phId;
                            await _packagingHierarchyDac.UpdatePackagingHierarchy(packagingHierarchy);                            
                            // Delete all the orderable pack levels for that packaging hierarchy , reatail pack type , itemformId
                            await _packagingHierarchyDac.DeleteOrderingLevels(packagingHierarchy.ID , isModeling);
                            // Insert Orderable pack levels

                            if ((packagingHierarchy.orderablePackLevels != null) && (packagingHierarchy.orderablePackLevels.Count > 0))
                            {
                                //TODO : MaxDegreeOfParallelism from web config
                                Parallel.ForEach(packagingHierarchy.orderablePackLevels, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (orderablePackLevel) =>
                                {   //Insert all the orderable pack levels for that packaging hierarchy , reatail pack type                                     
                                    orderablePackLevel.PackagingHierarchyID = packagingHierarchy.ID;
                                    orderablePackLevel.CreatedBy = packagingHierarchy.CreatedBy;
                                    orderablePackLevel.LastUpdatedBy = packagingHierarchy.LastUpdatedBy;
                                    if ((orderablePackLevel.PrimaryVendorBool == true))
                                    {
                                        WarehouseGtinDto warehouseDetails = new WarehouseGtinDto();
                                        warehouseDetails.WarehouseNumber = orderablePackLevel.Warehouse;
                                        warehouseDetails.GTIN = packagingHierarchy.GTIN; // This is the primary GTIN.
                                        _packagingHierarchyDac.UpdatePrimaryVendorForWarehouse(warehouseDetails);
                                    }
                                    _packagingHierarchyDac.InsertOrderabePackLevels(orderablePackLevel);
                                });
                                await Task.WhenAll();
                            }
                        }
                    }
                    else
                    {
                        if (isModeling)
                            packagingHierarchy.ID = 0;

                        var packagingHierarchyId = await _packagingHierarchyDac.InsertPackagingHierarchy(packagingHierarchy);
                        if ((packagingHierarchy.orderablePackLevels != null) && (packagingHierarchy.orderablePackLevels.Count > 0))
                        {                            
                            Parallel.ForEach(packagingHierarchy.orderablePackLevels, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (orderablePackLevel) =>
                                 {   //Insert all the orderable pack levels for that packaging hierarchy , reatail pack type                                     
                                     orderablePackLevel.PackagingHierarchyID = packagingHierarchyId;
                                     orderablePackLevel.CreatedBy = packagingHierarchy.CreatedBy;
                                     orderablePackLevel.LastUpdatedBy = packagingHierarchy.LastUpdatedBy;
                                     if (orderablePackLevel.PrimaryVendorBool == true)
                                     { WarehouseGtinDto warehouseDetails = new WarehouseGtinDto();
                                         warehouseDetails.WarehouseNumber = orderablePackLevel.Warehouse;
                                         warehouseDetails.GTIN = packagingHierarchy.GTIN; // This is the primary GTIN.
                                         _packagingHierarchyDac.UpdatePrimaryVendorForWarehouse(warehouseDetails);
                                     }
                                     _packagingHierarchyDac.InsertOrderabePackLevels(orderablePackLevel);
                                 });
                            await Task.WhenAll();
                        }
                    }
                }

               
                await _dsdAuthorizationRequestBO.DeleteDsdVendorsNotInPackagingHierarchy(packagingHierarchyList.First().ItemFormID);
                successFlag = true;
            }
            catch (Exception ex)
            {
                throw;
            }

            return successFlag;
        }

        private async Task GetMasterCaseVendorItemGtin(PackagingHierarchyDto packagingHierarchy)
        {
            var vendorItemCode = await _commonBo.GetVendorItemCode(packagingHierarchy.ItemFormID);
            if (vendorItemCode != null)
            {
                Int64 nVendorItemCode;
                var isNumeric = Int64.TryParse(vendorItemCode, out nVendorItemCode);             
                packagingHierarchy.MasterCaseVendorItemGTIN = isNumeric ? String.Format("{0:000-00000-00000}", nVendorItemCode) : vendorItemCode;
                packagingHierarchy.IsDirty = true;
            }
        }

        private static void SetUserID(List<PackagingHierarchyDto> packagingHierarchyList)
        {
            foreach (var packagingHierarchy in packagingHierarchyList)
            {
                string user = packagingHierarchy.CreatedBy == "" ? "IFWUser" : packagingHierarchy.CreatedBy;
                packagingHierarchy.CreatedBy = user;
                packagingHierarchy.LastUpdatedBy = user;
            }
           
        }


        public async Task<IEnumerable<WarehouseDto>> GetWarehouses()
        {
            var warehouses = await _commonBo.GetPIDMLookup("api/GetWarehouses");
            return warehouses.Select(res => new WarehouseDto
            {
                WarehouseNumber = Convert.ToInt32(res.Code),
                Name = res.Description
            });
        }

        public async Task<int> IsPrimaryVendorExistsForWHByGtin(WarehouseGtinDto warehouseDetails)
        {
            return await _packagingHierarchyDac.IsPrimaryVendorExistsForWHByGtin(warehouseDetails);
        }
        public async Task<IEnumerable<VendorDomainDto>> GetDsdVendorsExistInDsdForItemForm(int itemFormID)
        {
            return await _packagingHierarchyDac.GetDsdVendorsExistInDsdForItemForm(itemFormID);
        }

    }
}
