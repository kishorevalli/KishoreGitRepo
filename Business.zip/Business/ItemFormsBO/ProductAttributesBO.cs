﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System.Net.Http;
using AutoMapper;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class ProductAttributesBO : IProductAttributesBO
    {
        protected readonly ICommonBO _commonBo; 
        protected readonly IProductAttributesDac _productAttributesDac;
        


        public ProductAttributesBO(ICommonBO commonBo , IProductAttributesDac productAttributesDac)
        {
            _commonBo = commonBo;            
            _productAttributesDac = productAttributesDac;
        }
       

        public Task<IEnumerable<ProductAttributeDto>> GetProductAttributes(int itemFormID)
        {
            return _productAttributesDac.GetProductAttributes(itemFormID);
        }

        //Get States for lookup from PIDM
        public async Task<IEnumerable<StateDto>> GetStates()
        {
          //  return await _commonBo.GetPIDMLookup("api/GetStates");

            string resource = "api/GetStates";
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse(resource);
            IEnumerable<StateDto> statesList = new List<StateDto>();
            if (response.IsSuccessStatusCode)
            {
                statesList = await response.Content.ReadAsAsync<IEnumerable<StateDto>>();
            }
            return statesList;
        }


        //Get Counties for lookup from PIDM
        public async Task<IEnumerable<StateDto>> GetCounties(string stateShortName)
        {
            string resource = "api/GetCounties/"+ stateShortName;
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse(resource);
            IEnumerable<StateDto> coutinesList = new List<StateDto>();
            if (response.IsSuccessStatusCode)
            {
                coutinesList = await response.Content.ReadAsAsync<IEnumerable<StateDto>>();
            }
            return coutinesList;
        }


        //Get Cities for lookup from PIDM
        public async Task<IEnumerable<StateDto>> GetCities(StateDto state)
        {
            string resource = "api/GetCities";
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponseViaPost(resource , state);
            IEnumerable<StateDto> citiesList = new List<StateDto>();
            if (response.IsSuccessStatusCode)
            {
                citiesList = await response.Content.ReadAsAsync<IEnumerable<StateDto>>();
            }
            return citiesList;
        }

        public Task<IEnumerable<ProductAttributeDto>> GetMandatoryAttributesList(int famCode, List<int> rssCode, string ItemCode)
        {
            throw new NotImplementedException();
        }

        public async  Task<IEnumerable<ProductAttributeScopingDto>> GetProductAttributesScopingDetails(int itemFormID)
        {
            List<ProductAttributeScopingDto> paScopingDetails = new List<ProductAttributeScopingDto>();

            var paScopingDetailsTsk = await _productAttributesDac.GetProductAttributesScopingDetails();
            paScopingDetails = paScopingDetailsTsk.ToList();

            foreach (var paScope in paScopingDetails)
            {
                paScope.ColumnValue = await _productAttributesDac.GetPAScopingColumnValue(paScope.TableName, paScope.ColumnName, itemFormID);
            }

            return paScopingDetails;
        }

        

        public async Task<IEnumerable<ProductAttributeDto>> GetMandatoryAttributes(ProductMandatoryAttributesRequestDto mandatoryAttributesRequest, int modelGroupCodeType, int ItemFormID)
        {
            List<ProductAttributeDto> productAttributesList = new List<ProductAttributeDto>();
            string resource = "api/GetMandatoryAttributes";
          

            //Get the FAM and RSS details from product grouping .
            if (modelGroupCodeType == 4)
            {
                List<ItemGroupType> rssList = await GetProductGroupingFamAndRSS(mandatoryAttributesRequest, ItemFormID);
                mandatoryAttributesRequest.ItemGroupTypes = rssList;
            }

            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponseViaPost(resource, mandatoryAttributesRequest);
            IEnumerable<PMDSProductMandatoryAttributesDto> mandatoryAttributesList = new List<PMDSProductMandatoryAttributesDto>();
            //IEnumerable<ProductMandatoryAttributesDto> groupedMandatoryAttributesList = new List<ProductMandatoryAttributesDto>();
            if (response.IsSuccessStatusCode)
            {
                mandatoryAttributesList = await response.Content.ReadAsAsync<IEnumerable<PMDSProductMandatoryAttributesDto>>();
                
                var groupedMandatoryAttributesList = mandatoryAttributesList.ToLookup(a => new { a.ProductAttributeGroupCode, a.ProductAttributeCode, a.ItemGroupTypeCode, a.ItemGroupCode });

                foreach (var mandatoryAttributeGroup in groupedMandatoryAttributesList)
                {
                    ProductAttributeDto pa = new ProductAttributeDto();
                    List<LookupIntDto> permittedValuesList = new List<LookupIntDto>();
                    pa = Mapper.Map<ProductAttributeDto>(mandatoryAttributeGroup.FirstOrDefault());                 
                    foreach (var element in mandatoryAttributeGroup)
                    {
                        LookupIntDto permittedValue = new LookupIntDto();
                        permittedValue.Code = element.SequenceNumber;
                        permittedValue.Description = element.PermittedValue.Trim();
                        permittedValuesList.Add(permittedValue);
                    }
                    pa.PermittedValues = permittedValuesList;
                    pa.modelGroupCodeType = modelGroupCodeType;
                    pa.TerminationDate = new DateTime(9999, 12, 31);
                    pa.Visible = "Y";
                    pa.ReadOnly = "N";
                    productAttributesList.Add(pa);

                }
                return productAttributesList;

            }

           // var groupedMandatoryAttributesList = mandatoryAttributesList.GroupBy(a => new { a.ProductAttributeGroupCode, a.ProductAttributeCode, a.ItemGroupTypeCode, a.ItemGroupCode });
            return productAttributesList;
        }

        public async Task<List<ItemGroupType>> GetProductGroupingFamAndRSS(ProductMandatoryAttributesRequestDto mandatoryAttributesRequest, int ItemFormID)
        {
            List<ItemGroupType> rssList = new List<ItemGroupType>();
            var productGroupingDetails = await _productAttributesDac.GetFamAndRssDetails((int)ItemFormID);
            foreach (var grp in productGroupingDetails)
            {
                if (grp.ChildProductGroupType == "FAM")
                {
                    if (grp.ChildProductGroupCode != null)
                        mandatoryAttributesRequest.CurrentFamNo = (int)grp.ChildProductGroupCode;
                }
                else //RSS
                {
                    if (grp.ChildProductGroupCode != null)
                    {
                        ItemGroupType rss = new ItemGroupType();
                        rss.ItemGroupTypeCode = grp.ChildProductGroupType;
                        rss.ItemGroupCode = (int)grp.ChildProductGroupCode;
                        rssList.Add(rss);
                    }
                }
            }

            return rssList;
        }

        //public async Task<ItemValidationDTO> ValidateProductAttributesBeforeSubmit(int itemFormID)
        //{
        //    //Get Product Attributes 
        //}

        public async Task<ItemValidationDTO> ValidateProductAttributes(List<ProductAttributeDto> productAttributes , int itemFormID , int? formActionID)
        {
            ItemValidationDTO TabErrorDto = new ItemValidationDTO();
            TabErrorDto.TabName = "Product Attributes";

            List<ErrorDTO> tabErrorList = new List<ErrorDTO>();
            List<WarningDTO> tabWarningsList = new List<WarningDTO>();

            //var mandatoryProductAttributes = await GetMandatoryAttributes(new ProductMandatoryAttributesRequestDto(), 4, itemFormID);

            //if (mandatoryProductAttributes.Count() != productAttributes.Count)
            //{
            //    var error = await _commonBo.GetErrorMessage("PA02");
            //    if (error.SeverityLevel == "Warning")
            //        tabWarningsList.Add(Mapper.Map<WarningDTO>(error));
            //    else
            //        tabErrorList.Add(error);
            //}

            foreach (var pa in productAttributes)
            {
                if ((pa.AttributeValueSequenceNumber == null || pa.AttributeValueSequenceNumber == 0) 
                                                && (pa.NewAttributeValue == null || pa.NewAttributeValue == ""))
                {
                    var error = await _commonBo.GetErrorMessage("PA01"); 
                    if (error.SeverityLevel == "Warning")
                        tabWarningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        tabErrorList.Add(error);

                    break;
                }


                //If there is new value and not approved , throw warning \ error.
                if ((pa.NewAttributeValue != null) && (pa.NewAttributeApprovalIndicator != "Y")) 
                {

                    var error = await _commonBo.GetErrorMessage("PA03");
                    if (error.SeverityLevel == "Warning")
                        tabWarningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        tabErrorList.Add(error);

                    break;
                }

            
                //TODO : check if the mandatory attributes and the product attributes are same as the part of submit validation.
            }
            
            TabErrorDto.Errors = tabErrorList;
            TabErrorDto.Warnings = tabWarningsList;

            return TabErrorDto;

        }

        //public async Task<IEnumerable<VendorDomainDto>> GetVendorForSearch(VendorDomainDto vendorDomainDto)
        //{
        //    string resource = string.Empty;
        //    System.Net.Http.HttpResponseMessage response;
        //    IEnumerable<VendorDomainDto> vendorDomainDtoList = new List<VendorDomainDto>();

        //    resource = "api/GetVendorForSearch";
        //    response = await GetHttpResponseViaPost(resource, vendorDomainDto);

        //    if (response.IsSuccessStatusCode)
        //    {
        //        vendorDomainDtoList = await response.Content.ReadAsAsync<IEnumerable<VendorDomainDto>>();
        //    }

        //    if (vendorDomainDtoList != null && vendorDomainDtoList.Count() > 0 && vendorDomainDto.VendorType == AppConstants.VENDOR_TYPE_DSD)
        //    {
        //        vendorDomainDtoList = vendorDomainDtoList.Where(x => x.VendorType == AppConstants.VENDOR_TYPE_DSD);
        //    }

        //    return vendorDomainDtoList;
        //}


        public Task<bool> SaveProductAttributes(List<ProductAttributeDto> productAttributes , int itemFormId , string currentUser)
        {

            foreach (var pa in productAttributes)
            {
                pa.ItemFormID = itemFormId;
                pa.CreatedBy = currentUser;
                if(pa.NewAttributeApprovalIndicator == "Y" && pa.NewAttributeApprovedDate == null)
                {
                    pa.NewAttributeApprovedDate = DateTime.Now;
                    pa.NewAttributeApprovedBy = currentUser;

                }
            }
            return _productAttributesDac.SaveProductAttributes(productAttributes, itemFormId);
           // throw new NotImplementedException();
        }

      
        //public async Task<ProductMandatoryAttributesRequestDto> GetFamAndRssDetails(int itemFormID)
        //{

            //    ProductMandatoryAttributesRequestDto mandatoryAttributesRequest = new ProductMandatoryAttributesRequestDto();
            //    List<ItemGroupType> rssList = new List<ItemGroupType>();
            //    var productGroupingDetails = await _productAttributesDac.GetFamAndRssDetails(itemFormID);
            //    foreach (var grp in productGroupingDetails)
            //    {
            //        if (grp.ChildProductGroupType == "FAM")
            //        {
            //            if (grp.ChildProductGroupCode != null)
            //                mandatoryAttributesRequest.CurrentFamNo = (int)grp.ChildProductGroupCode;
            //        }
            //        else //RSS
            //        {
            //            if (grp.ChildProductGroupCode != null)
            //            {
            //                ItemGroupType rss = new ItemGroupType();
            //                rss.ItemGroupTypeCode = grp.ChildProductGroupType;
            //                rss.ItemGroupCode = (int)grp.ChildProductGroupCode;
            //                rssList.Add(rss);
            //            }

            //        }

            //        mandatoryAttributesRequest.ItemGroupTypes = rssList;
            //    }

            //    return mandatoryAttributesRequest;
            //}


        public async Task<ErrorDTO> GetErrorMessage(string ErrorCode, int action = 1)
        {
            IEnumerable<ErrorDTO> Errors = await _productAttributesDac.GetErrorMessages();
            var errorDTOTemplate = Errors.FirstOrDefault(e => e.ErrorCode == ErrorCode);
            //if (action == 5)
            //{
            //    return new ErrorDTO()
            //    {
            //        ErrorCode = errorDTOTemplate.ErrorCode,
            //        SeverityLevel = "Error",
            //        ControlName = errorDTOTemplate.ControlName,
            //        ErrorDescription = errorDTOTemplate.ErrorDescription
            //    };
            //}
            return errorDTOTemplate;
        }
    }
}
