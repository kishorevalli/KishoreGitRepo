﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System.Net.Http;
using Publix.S0VPITEM.ItemFormsEntities.PMDSEntities;
using AutoMapper;
using Publix.S0VPITEM.ItemFormsDac;
using System.Text.RegularExpressions;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public class ScaleItemDetailsBO : IScaleItemDetailsBO
    {
        protected readonly IScaleItemDetailsDac _scaleItemDetailsDac;
        protected readonly ICommonBO _commonBo;

        public ScaleItemDetailsBO(ICommonBO commonBO, IScaleItemDetailsDac scaleItemDetailsDac)
        {
            this._commonBo = commonBO;
            this._scaleItemDetailsDac = scaleItemDetailsDac;
        }

        public async Task<IEnumerable<LookupDto>> GetOverrideSaleDescription()
        {
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetFacilityGroups");
            if (response.IsSuccessStatusCode)
            {
                IEnumerable<LookupDto> result = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
                return null;
            }

            return null;
        }

        public async Task<IEnumerable<LookupFlagDto>> GetScaleLocation()
        {
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetScaleLocation");
            if (response.IsSuccessStatusCode)
            {
                IEnumerable<LookupFlagDto> result = response.Content.ReadAsAsync<IEnumerable<LookupFlagDto>>().Result;
                return result;
            }
            return null;
        }

        public async Task<IEnumerable<LookupDto>> GetScaleGrade()
        {
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetScaleGrade");
            if (response.IsSuccessStatusCode)
            {
                IEnumerable<LookupDto> result = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
                return result;
            }
            return null;
        }

        public async Task<IEnumerable<LookupDto>> GetScaleActionCodes()
        {
            System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetScaleActionCodes");
            if (response.IsSuccessStatusCode)
            {
                IEnumerable<LookupDto> result = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
                return result;
            }
            return null;
        }

        //public async Task<IEnumerable<LookupDto>> GetFacilityGroupByType(string type)
        //{
        //    System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetFacilityGroupByType/"+type);
        //    if (response.IsSuccessStatusCode)
        //    {
        //        IEnumerable<LookupDto> result = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
        //        return result;
        //    }
        //    return null;

        //}

        //public async Task<IEnumerable<LookupDto>> GetFacilityGroupTypes()
        //{
        //    System.Net.Http.HttpResponseMessage response = await _commonBo.GetHttpResponse("api/GetFacilityGroupTypes");
        //    if (response.IsSuccessStatusCode)
        //    {
        //        IEnumerable<LookupDto> result = response.Content.ReadAsAsync<IEnumerable<LookupDto>>().Result;
        //        return result;
        //    }
        //    return null;
        //}

        public async Task<bool> SaveScaleInfo(ScaleInfoDto scaleItemDetails)
        {

            SetItemFormId(scaleItemDetails);
            SetUserId(scaleItemDetails);

            bool success = false;

            bool scaleInfoExists = await _scaleItemDetailsDac.IsScaleItemDetailsExist(scaleItemDetails.ItemFormID);
            if (scaleInfoExists)
            {
                if (scaleItemDetails.IsDirtyItemOverride || scaleItemDetails.IsDirtyScaleGrade || scaleItemDetails.IsDirtyScaleLocation || scaleItemDetails.IsDirtyScaleShelfLife || scaleItemDetails.IsDirty)
                {
                    if (scaleItemDetails.IsDirtyItemOverride)
                    {
                        await _scaleItemDetailsDac.InsertScaleOverrideDescriptionAudit(scaleItemDetails.ItemFormID);
                        await Task.Run(() => Parallel.ForEach(scaleItemDetails.ScaleOverrideDescriptionList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (scaleOverrideDescriptionDto) =>
                          {
                              _scaleItemDetailsDac.InsertScaleOverrideDescription(scaleOverrideDescriptionDto, scaleItemDetails.ItemFormID);
                          }));


                    }
                    if (scaleItemDetails.IsDirtyScaleLocation)
                    {
                        await _scaleItemDetailsDac.InsertScaleLocationAudit(scaleItemDetails.ItemFormID);
                        await Task.Run(() => Parallel.ForEach(scaleItemDetails.ScaleLocationList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (scaleLocationDto) =>
                          {
                              _scaleItemDetailsDac.InsertScaleLocation(scaleLocationDto, scaleItemDetails.ItemFormID);
                          }));

                    }
                    if (scaleItemDetails.IsDirtyScaleShelfLife)
                    {
                        await _scaleItemDetailsDac.InsertScaleShelfLifeAudit(scaleItemDetails.ItemFormID);
                        await Task.Run(() => Parallel.ForEach(scaleItemDetails.ScaleShelfLifeList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (scaleShelfLifeDto) =>
                          {
                              _scaleItemDetailsDac.InsertScaleShelfLife(scaleShelfLifeDto, scaleItemDetails.ItemFormID);
                          }));

                    }
                    if (scaleItemDetails.IsDirtyScaleGrade)
                    {
                        await _scaleItemDetailsDac.InsertScaleGradeAudit(scaleItemDetails.ItemFormID);
                        await Task.Run(() => Parallel.ForEach(scaleItemDetails.ScaleGradeList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (scaleGradeDto) =>
                          {
                              _scaleItemDetailsDac.InsertScaleGrade(scaleGradeDto, scaleItemDetails.ItemFormID);
                          }));

                    }

                    await _scaleItemDetailsDac.UpdateScaleInfo(scaleItemDetails);
                }

                success = true;
            }
            else
            {
                await _scaleItemDetailsDac.InsertScaleInfo(scaleItemDetails);
                await Task.Run(() => Parallel.ForEach(scaleItemDetails.ScaleOverrideDescriptionList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (scaleOverrideDescriptionDto) =>
                  {
                      _scaleItemDetailsDac.InsertScaleOverrideDescription(scaleOverrideDescriptionDto, scaleItemDetails.ItemFormID);
                  }));

                await Task.Run(() => Parallel.ForEach(scaleItemDetails.ScaleLocationList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (scaleLocationDto) =>
                  {
                      _scaleItemDetailsDac.InsertScaleLocation(scaleLocationDto, scaleItemDetails.ItemFormID);
                  }));

                await Task.Run(() => Parallel.ForEach(scaleItemDetails.ScaleShelfLifeList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (scaleShelfLifeDto) =>
                  {
                      _scaleItemDetailsDac.InsertScaleShelfLife(scaleShelfLifeDto, scaleItemDetails.ItemFormID);
                  }));

                await Task.Run(() => Parallel.ForEach(scaleItemDetails.ScaleGradeList, new ParallelOptions() { MaxDegreeOfParallelism = 6 }, (scaleGradeDto) =>
                  {
                      _scaleItemDetailsDac.InsertScaleGrade(scaleGradeDto, scaleItemDetails.ItemFormID);
                  }));

                success = true;
            }


            return success;
        }

        public async Task<ScaleInfoDto> GetScaleInfo(int itemFormID)
        {
            return await _scaleItemDetailsDac.GetScaleInfo(itemFormID);
        }

        public void SetUserId(ScaleInfoDto dto)
        {
            dto.LastUpdatedBy = dto.CreatedBy;
            dto.ScaleOverrideDescriptionList.ForEach(x => x.LastUpdatedBy = dto.CreatedBy);
            dto.ScaleShelfLifeList.ForEach(x => x.LastUpdatedBy = dto.CreatedBy);
            dto.ScaleGradeList.ForEach(x => x.LastUpdatedBy = dto.CreatedBy);
            dto.ScaleLocationList.ForEach(x => x.LastUpdatedBy = dto.CreatedBy);
        }

        public async Task SaveScaleItemDetails(BasicItemDefinitionDto basicItemDefinitionDto, PIDMDataDto pidmItemData)
        {
            ScaleInfoDto dto = Mapper.Map<ScaleInfoDto>(pidmItemData.ScaleItemDetails);
            dto.ScaleOverrideDescriptionList = Mapper.Map<List<ScaleOverrideDescriptionDto>>(pidmItemData.ScaleItemDetails.ScaleItemOverrideDescList);
            dto.ScaleGradeList = Mapper.Map<List<ScaleGradeDto>>(pidmItemData.ScaleItemDetails.ScaleItemGradeList);
            dto.ScaleLocationList = Mapper.Map<List<ScaleLocationDto>>(pidmItemData.ScaleItemDetails.ScaleItemLocationList);
            dto.ScaleShelfLifeList = Mapper.Map<List<ScaleShelfLifeDto>>(pidmItemData.ScaleItemDetails.ScaleItemShelfLifeList);

            dto.ItemFormID = basicItemDefinitionDto.ItemFormID;
            dto.CreatedBy = basicItemDefinitionDto.CreatedBy;
            dto.IsDirty = true;
            dto.IsDirtyItemOverride = true;
            dto.IsDirtyScaleGrade = true;
            dto.IsDirtyScaleLocation = true;
            dto.IsDirtyScaleShelfLife = true;
            dto.ScaleOverrideDescriptionList.ForEach(x => { x.ItemFormID = basicItemDefinitionDto.ItemFormID; x.CreatedBy = basicItemDefinitionDto.CreatedBy; });
            dto.ScaleShelfLifeList.ForEach(x => { x.ItemFormID = basicItemDefinitionDto.ItemFormID; x.CreatedBy = basicItemDefinitionDto.CreatedBy; });
            dto.ScaleGradeList.ForEach(x => { x.ItemFormID = basicItemDefinitionDto.ItemFormID; x.CreatedBy = basicItemDefinitionDto.CreatedBy; });
            dto.ScaleLocationList.ForEach(x => { x.ItemFormID = basicItemDefinitionDto.ItemFormID; x.CreatedBy = basicItemDefinitionDto.CreatedBy; });

            bool result = await SaveScaleInfo(dto);




        }

        private void SetItemFormId(ScaleInfoDto dto)
        {
            dto.ScaleOverrideDescriptionList.ForEach(x => x.ItemFormID = dto.ItemFormID);
            dto.ScaleShelfLifeList.ForEach(x => x.ItemFormID = dto.ItemFormID);
            dto.ScaleGradeList.ForEach(x => x.ItemFormID = dto.ItemFormID);
            dto.ScaleLocationList.ForEach(x => x.ItemFormID = dto.ItemFormID);
        }


        public async Task<ItemValidationDTO> ValidateScaleItemDetails(ScaleInfoDto dto)
        {
            ItemValidationDTO sidErrorDto = new ItemValidationDTO();
            sidErrorDto.TabName = "Scale Item Details";

            List<ErrorDTO> errorList = new List<ErrorDTO>();
            List<WarningDTO> warningsList = new List<WarningDTO>();

            if(dto.ScaleDescription1 == null || dto.ScaleDescription1.Trim()=="")
            {
                var error = await _commonBo.GetErrorMessage("SID01", dto.FormActionID);
                if (error.SeverityLevel == "Warning")
                    warningsList.Add(Mapper.Map<WarningDTO>(error));
                else
                    errorList.Add(error);
            }

            if(dto.BackroomScaleIndicator == null || dto.BackroomScaleIndicator.Trim()=="")
            {
                var error = await _commonBo.GetErrorMessage("SID02", dto.FormActionID);
                if (error.SeverityLevel == "Warning")
                    warningsList.Add(Mapper.Map<WarningDTO>(error));
                else
                    errorList.Add(error);
            }

            //if (dto.Tare != null)
            //{
            //    if (!IsValidTare(dto.Tare.Value.ToString()))
            //    {
            //        var error = await _commonBo.GetErrorMessage("SID03", dto.FormActionID);
            //        if (error.SeverityLevel == "Warning")
            //            warningsList.Add(Mapper.Map<WarningDTO>(error));
            //        else
            //            errorList.Add(error);
            //    }
            //}

            if (dto.ScaleExtraTextRequired == null || dto.ScaleExtraTextRequired.Trim() == "")
            {
                if (dto.ScaleLocationList.Where(x => x.ScaleLocationDescription.ToUpper().Trim() == "BAKERY").Count()>0)
                {
                    var error = await _commonBo.GetErrorMessage("SID13", dto.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        warningsList.Add(Mapper.Map<WarningDTO>(error));
                    else
                        errorList.Add(error);
                }
             }


            List<SubTabValidationDTO> subErrors = new List<SubTabValidationDTO>();
            SubTabValidationDTO phErrors = new SubTabValidationDTO();
            phErrors.SubTabName = "OverrideScaleDescErrors";
            phErrors.Warnings = new List<WarningDTO>();
            phErrors.Errors = new List<ErrorDTO>();
            if (dto.ScaleOverrideDescriptionList.Count > 0)
            {
                if (dto.ScaleOverrideDescriptionList.Exists(x => x.FacilityGroupDescription == null || x.FacilityGroupDescription == "")) {
                    var error = await _commonBo.GetErrorMessage("SID05", dto.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }
                if (dto.ScaleOverrideDescriptionList.Exists(x => x.OverrideDescriptionLine1 == null || x.OverrideDescriptionLine1 == ""))
                {
                    var error = await _commonBo.GetErrorMessage("SID06", dto.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrors.Errors.Add(error);
                }
                
            }else
            {
                var error = await _commonBo.GetErrorMessage("SID04", dto.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrors.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrors.Errors.Add(error);
            }

            if (phErrors.Warnings.Count > 0 || phErrors.Errors.Count > 0) subErrors.Add(phErrors);


            SubTabValidationDTO phErrorsLoc = new SubTabValidationDTO();
            phErrorsLoc.SubTabName = "ScaleLocationErrors";
            phErrorsLoc.Warnings = new List<WarningDTO>();
            phErrorsLoc.Errors = new List<ErrorDTO>();
            if (dto.ScaleLocationList.Count > 0)
            {
                if (dto.ScaleLocationList.Exists(x => x.ScaleLocationDescription == null || x.ScaleLocationDescription == ""))
                {
                    var error = await _commonBo.GetErrorMessage("SID08", dto.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrorsLoc.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrorsLoc.Errors.Add(error);
                }
                if (dto.ScaleLocationList.Exists(x => x.PLUNumber == null))
                {
                    var error = await _commonBo.GetErrorMessage("SID09", dto.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrorsLoc.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrorsLoc.Errors.Add(error);
                }

            }
            else
            {
                var error = await _commonBo.GetErrorMessage("SID07", dto.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrorsLoc.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrorsLoc.Errors.Add(error);
            }

            if (phErrorsLoc.Warnings.Count > 0 || phErrorsLoc.Errors.Count > 0) subErrors.Add(phErrorsLoc);



            SubTabValidationDTO phErrorsGrade = new SubTabValidationDTO();
            phErrorsGrade.SubTabName = "ScaleGradeErrors";
            phErrorsGrade.Warnings = new List<WarningDTO>();
            phErrorsGrade.Errors = new List<ErrorDTO>();
            if (dto.ScaleGradeList.Count > 0)
            {
                if (dto.ScaleGradeList.Exists(x => x.FacilityGroupDescription == null || x.FacilityGroupDescription == ""))
                {
                    var error = await _commonBo.GetErrorMessage("SID11", dto.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrorsGrade.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrorsGrade.Errors.Add(error);
                }
                if (dto.ScaleGradeList.Exists(x => x.GradeDescription == null||x.GradeDescription==""))
                {
                    var error = await _commonBo.GetErrorMessage("SID12", dto.FormActionID);
                    if (error.SeverityLevel == "Warning")
                        phErrorsGrade.Warnings.Add(Mapper.Map<WarningDTO>(error));
                    else
                        phErrorsGrade.Errors.Add(error);
                }

            }
            else
            {
                var error = await _commonBo.GetErrorMessage("SID10", dto.FormActionID);
                if (error.SeverityLevel == "Warning")
                    phErrorsGrade.Warnings.Add(Mapper.Map<WarningDTO>(error));
                else
                    phErrorsGrade.Errors.Add(error);
            }

            if (phErrorsGrade.Warnings.Count > 0 || phErrorsGrade.Errors.Count > 0) subErrors.Add(phErrorsGrade);





            sidErrorDto.Errors = errorList;
            sidErrorDto.Warnings = warningsList;
            sidErrorDto.SubTabValidations = subErrors;

            return sidErrorDto;


        }

        public async Task<ErrorDTO> GetErrorMessage(string ErrorCode, int action = 1)
        {
            IEnumerable<ErrorDTO> Errors = await _scaleItemDetailsDac.GetErrorMessages();
            var errorDTOTemplate = Errors.FirstOrDefault(e => e.ErrorCode == ErrorCode);
            //if (action == 5)
            //{
            //    return new ErrorDTO()
            //    {
            //        ErrorCode = errorDTOTemplate.ErrorCode,
            //        SeverityLevel = "Error",
            //        ControlName = errorDTOTemplate.ControlName,
            //        ErrorDescription = errorDTOTemplate.ErrorDescription
            //    };
           // }
            return errorDTOTemplate;
        }

        private bool IsValidTare(string tare)
        {

            Regex regex = new Regex(@"^([1-4]?[0-9]([.][0-9]{1,2})?|99.99|50|\0)$");
            Match match = regex.Match(tare);
            if (match.Success)
                return true;
            else
                return false;
        }


    }
}
