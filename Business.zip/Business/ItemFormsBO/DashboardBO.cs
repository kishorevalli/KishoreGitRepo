﻿using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.ItemFormSvc;
using System.Web;
using System.Net.Http;

namespace Publix.S0VPITEM.ItemFormsBO
{
   public class DashboardBO : IDashboardBO
    {

        protected readonly IDashboardDac _dashboardDac;
        protected readonly ICommonBO _commonBo;
        protected readonly IWorkFlowBO _workFlowBo;
        public DashboardBO(ICommonBO commonBO, IDashboardDac dashboardDac, IWorkFlowBO workFlowBo)
        {
            this._dashboardDac = dashboardDac;
            this._commonBo = commonBO;
            this._workFlowBo = workFlowBo;
        }        
        public async Task<IEnumerable<DashboardItemFormDto>> GetItemFormListBySearchCriteria(DashboardSearchCriteriaDto dashboardSearchCriteriaDto,string LoggedInUserID) {
            CheckSearchSubmittedFromDate(dashboardSearchCriteriaDto);
            PrepareVendorList(dashboardSearchCriteriaDto);
            List<DashboardItemFormDto> ItemFormList = (await _dashboardDac.GetItemFormListBySearchCriteria(dashboardSearchCriteriaDto)).ToList();         
            return await Task.FromResult(_workFlowBo.LoadFormActionsForItemFormListVendor(ItemFormList, LoggedInUserID));
        }

        public async Task<IEnumerable<DashboardItemFormDto>> GetItemFormListBySearchCriteriaInternalUser(DashboardSearchCriteriaDto dashboardSearchCriteriaDto, string LoggedInUserID)
        {
            CheckSearchSubmittedFromDate(dashboardSearchCriteriaDto);
            PrepareVendorList(dashboardSearchCriteriaDto);
            IEnumerable<DashboardItemFormDto> ItemFormList =  _dashboardDac.GetItemFormListBySearchCriteriaInternalUser(dashboardSearchCriteriaDto).Result.ToList();
            //ItemFormList.RemoveAll(i => i.FormStatusID == 1);
            //_workFlowBo.LoadFormActionsForItemFormListInternal(ItemFormList.ToList(), dashboardSearchCriteriaDto.userType);
            ItemFormList =  AddChildItemFormsToParent(ItemFormList);      
            return await Task.FromResult(ItemFormList.OrderBy(itemform => itemform.GTIN));
        }

        public void CheckSearchSubmittedFromDate(DashboardSearchCriteriaDto dashboardSearchCriteriaDto) {

            DateTime FromDate = dashboardSearchCriteriaDto.SearchSubmittedFromDate;
            DateTime ToDate = dashboardSearchCriteriaDto.SearchSubmittedToDate;
            if (FromDate == DateTime.MinValue && ToDate != DateTime.MinValue)
                dashboardSearchCriteriaDto.SearchSubmittedFromDate = DateTime.Now.AddYears(-10);
            if (FromDate != DateTime.MinValue && ToDate == DateTime.MinValue)
                dashboardSearchCriteriaDto.SearchSubmittedToDate = DateTime.Now;

        }

        public void PrepareVendorList(DashboardSearchCriteriaDto dashboardSearchCriteriaDto)
        {

            if (!string.IsNullOrEmpty(dashboardSearchCriteriaDto.searchSelectedOrganization)) {
                // call the web service and load the vendors
            }
            if (!string.IsNullOrEmpty(dashboardSearchCriteriaDto.searchSelectedVendors))
            {
                dashboardSearchCriteriaDto.finalVendorList = dashboardSearchCriteriaDto.searchSelectedVendors;
            }
        }

        public async Task<IEnumerable<DashboardStatusDto>> GetDashboardStatus(LoggedInUserDto loggedInUser) {
            return await _dashboardDac.GetDashboardStatus(loggedInUser);
        }

        public async Task<int> GetDashboardStatusCount(DashboardStatusDto dashboardStatusDto) {
            return await _dashboardDac.GetDashboardStatusCount(dashboardStatusDto);
        }
        public async Task<int> GetDashboardStatusCountInternal(DashboardStatusDto dashboardStatusDto)
        {
            return await _dashboardDac.GetDashboardStatusCountInternal(dashboardStatusDto);
        }

        public async Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForVendor()
        {
            return await _dashboardDac.GetDashboardFormStatusForVendor();
        }

        public async Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForBuyer(int LoggedInUserTypeID)
        {
            return await _dashboardDac.GetDashboardFormStatusForBuyer(LoggedInUserTypeID);
        }


        public async Task<IEnumerable<ViewForUserListDto>> GetPossibleVendorUserForItemForm( ViewForUserListDto[] ViewForUserList) {

            List<ViewForUserListDto> PossibleVendorUserForItemForm = new List<ViewForUserListDto>();

            foreach (ViewForUserListDto VendorUser in ViewForUserList)
            {
                IEnumerable<VendorDomainDto> loggedInVendors = await _commonBo.GetAssociatedVendorListForExternalUser(VendorUser.ViewForUserId);
                string VendorList = String.Join(",", loggedInVendors.Select(v => v.VendorNumber));
                if(_workFlowBo.ValidateItemFormByVendors(VendorUser.ItemFormId.Value, VendorList))
                {
                    VendorUser.IsValidForAssignment = true;
                    PossibleVendorUserForItemForm.Add(VendorUser);
                }                
            }
            return PossibleVendorUserForItemForm;
        } 



        public async Task<IEnumerable<DashboardItemFormDto>> GetDashboardStatusDetail(DashboardStatusDto dashboardStatusDto,string LoggedInUserID) {
            List<DashboardItemFormDto> ItemFormList = ( _dashboardDac.GetDashboardStatusDetail(dashboardStatusDto).Result).ToList();
            Task<IEnumerable<DashboardItemFormDto>> ResultItemFormList = Task.FromResult(ItemFormList.AsEnumerable());
           //Task<IEnumerable<DashboardItemFormDto>> ResultItemFormList = Task.FromResult(_workFlowBo.LoadFormActionsForItemFormListVendor(ItemFormList, LoggedInUserID).AsEnumerable());
            return await ResultItemFormList;           

        }

        public async Task<IEnumerable<DashboardItemFormDto>> GetDashboardStatusDetailInternal(DashboardStatusDto dashboardStatusDto, string LoggedInUserID)
        {
            List<DashboardItemFormDto> ItemFormList = (_dashboardDac.GetDashboardStatusDetailInternal(dashboardStatusDto).Result).ToList();

            //ItemFormList.RemoveAll(i => i.FormStatusID == 1);
           //IEnumerable<DashboardItemFormDto> ResultItemFormList = _workFlowBo.LoadFormActionsForItemFormListVendor(ItemFormList, LoggedInUserID);
            //return await AddChildItemFormsToParentWithStatusFilter(ResultItemFormList, dashboardStatusDto.StatusID.Value);
            return await Task.FromResult(AddChildItemFormsToParent(ItemFormList));
            //return await Task.FromResult(ItemFormList);
        }

        public async Task<bool> UpdateItemFormActionAndCurrentStatusList(IEnumerable<FormUserPermittedActionDto> formUserPermittedActionList) {
            // An asynchronous module or handler completed while an asynchronous operation was still pending
            //formUserPermittedActionList.ToList().ForEach(async formUserPermittedAction => await _dashboardDac.UpdateItemFormActionAndCurrentStatus(formUserPermittedAction));
            foreach (var formUserPermittedAction in formUserPermittedActionList)
            {
                await _dashboardDac.UpdateItemFormActionAndCurrentStatus(formUserPermittedAction);
            }
            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateItemFormStatusForInternalUser(IEnumerable<FormUserPermittedActionDto> formUserPermittedActionList)
        {
            foreach (var formUserPermittedAction in formUserPermittedActionList.ToList())
            {
                await _dashboardDac.UpdateItemFormStatusForInternalUser(formUserPermittedAction);
            }

            //formUserPermittedActionList.ToList().ForEach(async formUserPermittedAction => await _dashboardDac.UpdateItemFormStatusForInternalUser(formUserPermittedAction));
            return true;
        }

        public async Task<IEnumerable<DashboardItemFormDto>> AddItemFormToGroup(int ItemFormID)
        {
           return await Task.FromResult(AddChildItemFormsToParent(_dashboardDac.AddItemFormToGroup(ItemFormID).Result));
        }

        public async Task<IEnumerable<DashboardItemFormDto>> RemoveItemFormFromGroup(int ItemFormID)
        {
            return await Task.FromResult(AddChildItemFormsToParent(_dashboardDac.RemoveItemFormFromGroup(ItemFormID).Result));
            //return await AddChildItemFormsToParent(_dashboardDac.RemoveItemFormFromGroup(ItemFormID));
        }        

        public async Task<IEnumerable<DashboardItemFormDto>> ParentingItemForm(int ItemFormID)
        {
            return await Task.FromResult(AddChildItemFormsToParent(_dashboardDac.ParentingItemForm(ItemFormID).Result));
            //return await AddChildItemFormsToParent(_dashboardDac.ParentingItemForm(ItemFormID));
        }

        public async Task<IEnumerable<DashboardItemFormDto>> UnParentingItemForm(int ItemFormID)
        {
            return await Task.FromResult(AddChildItemFormsToParent(_dashboardDac.UnParentingItemForm(ItemFormID).Result));
            //return await AddChildItemFormsToParent(_dashboardDac.UnParentingItemForm(ItemFormID).Result);
        }

        public IEnumerable<DashboardItemFormDto> AddChildItemFormsToParent(IEnumerable<DashboardItemFormDto> ItemFormEnum)
        {
            List<DashboardItemFormDto> ItemFormList = ItemFormEnum.ToList();
            //ItemFormList = _workFlowBo.LoadFormActionsForItemFormListInternal(ItemFormList, UserType.Buyer);

            //SetGroupAndParentFlag(ItemFormList.ToList());
            // taking the parent flag whic is not null for group id
            foreach (var item in ItemFormList.ToList().FindAll(itemform => itemform.ParentFlag == "Y" && itemform.GroupID == null))
            {
                item.ChildGTINItemFormList = ItemFormList.FindAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "Y" && itemform.ParentFlag == "N" && itemform.GroupID == null);
                          
                
                ItemFormList.RemoveAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "Y" && itemform.ParentFlag == "N" && itemform.GroupID == null);              
            }
            foreach (var item in ItemFormList.ToList().FindAll(itemform => itemform.ParentFlag == "Y" && itemform.GroupID != null))
            {
                item.ChildGTINItemFormList = ItemFormList.FindAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "Y" && itemform.ParentFlag == "N" && itemform.GroupID != null);

                ItemFormList.RemoveAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "Y" && itemform.ParentFlag == "N" && itemform.GroupID != null);
            }
            //RemoveCreateItemActions(ItemFormList); TODO for the new Approach
            return ItemFormList.AsEnumerable();
        }

        public Task<IEnumerable<DashboardItemFormDto>> AddChildItemFormsToParentWithStatusFilter(Task<IEnumerable<DashboardItemFormDto>> ItemFormEnum,int FormStatusID)
        {
            List<DashboardItemFormDto> ItemFormList = ItemFormEnum.Result.ToList();
            ItemFormList = _workFlowBo.LoadFormActionsForItemFormListInternal(ItemFormList, UserType.Buyer);
            
            //SetGroupAndParentFlag(ItemFormList.ToList());
            // taking the parent flag whic is not null for group id
            foreach (var item in ItemFormList.ToList().FindAll(itemform => itemform.ParentFlag == "Y" && itemform.GroupID == null))
            {
                //if (item.FormStatusID != FormStatusID)                
                if(ItemFormList.Any(item2 => item2.FormStatusID == FormStatusID && item2.GTIN == item.GTIN && item2.GroupID == null))
                    item.ChildGTINItemFormList = ItemFormList.FindAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "Y" && itemform.ParentFlag == "N" && itemform.GroupID == null);                
                else if (FormStatusID !=0)
                    ItemFormList.Remove(item);

                ItemFormList.RemoveAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "Y" && itemform.ParentFlag == "N" && itemform.GroupID == null);
                ItemFormList.RemoveAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "N" && itemform.ParentFlag == "N" && itemform.GroupID == null && itemform.FormStatusID != FormStatusID);
            }
            foreach (var item in ItemFormList.ToList().FindAll(itemform => itemform.ParentFlag == "Y" && itemform.GroupID != null))
            {
                //if (item.FormStatusID != FormStatusID)                
                if (ItemFormList.Any(item2 => item2.FormStatusID == FormStatusID && item2.GTIN == item.GTIN && item2.GroupID != null))
                    item.ChildGTINItemFormList = ItemFormList.FindAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "Y" && itemform.ParentFlag == "N" && itemform.GroupID != null);               
                else
                    ItemFormList.Remove(item);

                ItemFormList.RemoveAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "Y" && itemform.ParentFlag == "N" && itemform.GroupID != null);
                ItemFormList.RemoveAll(itemform => itemform.GTIN == item.GTIN && itemform.IsInGroup == "N" && itemform.ParentFlag == "N" && itemform.GroupID != null && itemform.FormStatusID != FormStatusID);
            }
            //RemoveCreateItemActions(ItemFormList);
            return Task.FromResult(ItemFormList.AsEnumerable());
        }

        public void SetGroupAndParentFlag(List<DashboardItemFormDto> ItemFormList)
        {
            ItemFormList.ForEach(itemform=> {               
                    itemform.EligibleForGroupingParenting = "Y";
                    //itemform.showDetails = true;
            });
        }

        //public void RemoveCreateItemActions(List<DashboardItemFormDto> ItemFormList) {

        //    ItemFormList.ForEach(itemform =>
        //    {
        //        if(itemform.ChildGTINItemFormList != null && itemform.ChildGTINItemFormList.Count > 0 && (itemform.ChildGTINItemFormList.Any(childitemform => childitemform.WarningCount > 0) || itemform.WarningCount > 0))
        //            itemform.formActions.RemoveAll(action => action.FormActionID == 13);
        //        else if(itemform.ChildGTINItemFormList == null && itemform.WarningCount > 0)
        //            itemform.formActions.RemoveAll(action => action.FormActionID == 13);
        //    });


        //}

        //Task<bool> AddItemFormToGroup(int ItemFormID);

        public async Task<bool> UpdateVSARelatedForm(string VSALoginUserID)
        {
            IEnumerable<VendorDomainDto> loggedInVendors = await _commonBo.GetAssociatedVendorListForExternalUser(VSALoginUserID);
            string VendorList = String.Join(",", loggedInVendors.Select(v => v.VendorNumber));
            return _dashboardDac.UpdateVSARelatedForm(VSALoginUserID, VendorList);
        }

        public async Task<bool> InsertDashboardUserSelection(DashboardUserSelectionDto dashboardUserSelectionDto)
        {
            return await _dashboardDac.InsertDashboardUserSelection(dashboardUserSelectionDto);           
        }

        public async Task<bool> UpdateReassignVendorContact(ViewForUserListDto vendorContact)
        {
            return await _dashboardDac.UpdateReassignVendorContact(vendorContact);
        }

        public async Task<DashboardUserSelectionDto> GetDashboardUserSelection(string LoggedInUserID)
        {
            return await _dashboardDac.GetDashboardUserSelection(LoggedInUserID);
        }


        //TODO Remove
        public async Task<IEnumerable<ItemFormDto>> GetItemForms(string userId)
        {
            return await _dashboardDac.GetItemForms(userId);
        }

        public async Task<IEnumerable<ErrorDTO>> GetDashboardErrorMessageList(int ItemFormID)
        {
            return await _dashboardDac.GetDashboardErrorMessageList(ItemFormID);
        }

        public async Task<bool> ChangeVendorSubmittedFormToReview(int ItemFormID)
        {
            return await _dashboardDac.ChangeVendorSubmittedFormToReview(ItemFormID);
        }

        public async Task<DashboardStatusDto> GetDefaultFavouriteForUserType(int UserTypeID)
        {
            return await _dashboardDac.GetDefaultFavouriteForUserType(UserTypeID);
        }

        public async Task<string> GetParentStatusForGTIN(decimal GTIN) {
            return await _dashboardDac.GetParentStatusForGTIN(GTIN);
        }

        
        public List<BuyerDTO> GetBuyerRelatedUsers(string UserId, string UserRole) {
            ItemFormService itemFormsvc = new ItemFormService();
            return  itemFormsvc.GetBuyerRelatedUsers(UserId, UserRole).ToList();
        }

        public List<VendorDTO> GetVendorRelatedUsers(string UserId, string UserRole)
        {
            string SessionKey = "GetVendorRelatedUsers" + UserId + UserRole;
            ItemFormService itemFormsvc = new ItemFormService();
            return itemFormsvc.GetVendorRelatedUsers(UserId, UserRole).ToList();
            //if (HttpContext.Current.Session[SessionKey] == null)
            //    HttpContext.Current.Session[SessionKey] = itemFormsvc.GetVendorRelatedUsers(UserId, UserRole).ToList();
            //return (List<VendorDTO>)HttpContext.Current.Session[SessionKey];

        }

        public static string GetEmailIDForVendor(string VendorID)
        {
            ItemFormService itemFormsvc = new ItemFormService();
            return itemFormsvc.GetEmailIDForVendor(VendorID);
         
        }

        public async Task<IEnumerable<FormUserPermittedActionDto>> GetFormActionsForItemForm(int currentUserTypeID, int CurrentFormStatusID) {
            return await _dashboardDac.GetFormActionsForItemForm(currentUserTypeID, CurrentFormStatusID);
        }




    }
}
