﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsBO
{
    public static class ItemFormsExtensions
    {
        // Check if date entered is in MM/DD format
        public static bool IsDateinMMDDFormat(this String dateEntry)
        {
            //if (dateEntry.Length != 5) return false;
            string[] monthdayarr = dateEntry.Split('/');
            if (monthdayarr.Length != 2) return false;
            int month, day;
            if (!Int32.TryParse(monthdayarr[0], out month)) return false;
            if (!Int32.TryParse(monthdayarr[1], out day)) return false;
            if (month < 1 || month > 12) //Month must be between 1 and 12
            {
                return false;
            }
            if (day < 1 || day > 31) //Day must be between 1 and 31
            {
                return false;
            }
            if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) //"Month that doesn't have 31 days!"
            {
                return false;
            }
            if (month == 2) // "February doesn't have more than 29 days!"
            {
                if (day > 29)
                {
                    return false;
                }
            }
            return true;
        }
        public static async Task EnsureSuccessStatusCodeAsync(this HttpResponseMessage response)
        {
            if (response.IsSuccessStatusCode)
            {
                return;
            }
            var content = await response.Content.ReadAsStringAsync();
            if (response.Content != null)
                response.Content.Dispose();
            var responseMessage = "Response status code does not indicate success: " + (int)response.StatusCode + " (" + response.StatusCode + " ). ";
            throw new HttpRequestException(responseMessage + Environment.NewLine + content);
        }
    }
}
