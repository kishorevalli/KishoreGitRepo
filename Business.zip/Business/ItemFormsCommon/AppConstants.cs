﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsCommon
{
    public static class AppConstants
    {
        public const string VENDOR_TYPE_DSD = "DSD";
        public const string VENDOR_TYPE_WHS = "WHS";
    }
}
