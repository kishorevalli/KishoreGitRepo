﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsCommon;
using System.Web.Services.Protocols;

namespace Publix.S0VPITEM.ItemFormsCommon
{
  public  class EmailServiceAgent
    {
       //public bool SendNotificationEmail(string subject, string messageBody)
       public void SendNotificationEmail()
        {
            string[] recipients = new string[] { "p1052774" };
           // string messageBody = "This is the test email from Item form development project sent for testing purpose. This does not have any business importance, Please ignore this email.";
            string subject = "Test Email from Item Form";
            string senderName = "p1052774";
            string emailSenderAddress = "p1052774";

            SendMailV3A.WebMessenger sendMail = new SendMailV3A.WebMessenger();
            SendMailV3A.MessageSetRequest sendMailRequest = new SendMailV3A.MessageSetRequest();
            SendMailV3A.MessageSetResult sendMailResponse = new SendMailV3A.MessageSetResult(); 
            SendMailV3A.RequestRecipient sendMailTo = new SendMailV3A.RequestRecipient(); 
            SendMailV3A.RequestRecipient sendMailFrom = new SendMailV3A.RequestRecipient();
            SendMailV3A.RequestMessage sendMailMessage = new SendMailV3A.RequestMessage();

            sendMail.Credentials = new System.Net.NetworkCredential(@"CORP\UVPITMT","cuDVE8ae");
          
            // sendMailMessage.Body = messageBody;
            sendMailMessage.Format = 1;
            sendMailMessage.Priority = 1;
            sendMailMessage.Sensitivity = 0;
            sendMailMessage.Subject = "Test Email From Item Form Send Email Service";


            sendMailMessage.Attachments = new string[1];
            string path = @"\\P47ISSHRS01\ISSHARED\Teams and Departments\EAS\Temp\Test.txt";
            sendMailMessage.Attachments[0] = path;

                      


            sendMailTo.Alias = "p1052774";
            sendMailTo.EmailAddress = String.Empty;
            sendMailTo.Name = String.Empty;
            sendMailTo.RecipientType = "To";
            sendMailFrom.Alias = String.Empty;
            sendMailFrom.EmailAddress = emailSenderAddress;
            sendMailFrom.Name = senderName;
            sendMailFrom.RecipientType = "From";


            sendMailRequest.DoRelay = false;
            sendMailRequest.IsBroadcast = false;
            sendMailRequest.Receipt = false;
            sendMailRequest.SenderID = "S0VPITEM";
           

            sendMailMessage.Body = "This is the test email from Item form development project sent for testing purpose. Please ignore this email."; ;

            
            sendMailMessage.Recipients = new SendMailV3A.RequestRecipient[1];
            //sendMailMessage.Recipients[0] = sendMailTo;
            sendMailMessage.Recipients[0]= sendMailTo;

            sendMailRequest.Messages = new SendMailV3A.RequestMessage[1];
            sendMailRequest.Messages[0] = sendMailMessage;

            sendMailFrom.EmailAddress = emailSenderAddress;
            sendMailFrom.Name = senderName;
            sendMailResponse = sendMail.SendMessageSetSync(sendMailRequest);

            String ErrorMessage = String.Empty;

            if (sendMailResponse.Errors.Count() > 0)
            {
                ErrorMessage = "";
            }
            
        }


    }
}
