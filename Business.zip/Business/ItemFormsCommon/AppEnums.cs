﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsCommon
{
    public static class AppEnums
    {
        public enum UserType
        {
            ALL = 0,
            Vendor,
            Buyer,
            Clerical,
            MfgClerical,
            MfgBDD,
            Support,
            BuyerReadOnly,

        };
    }
}
