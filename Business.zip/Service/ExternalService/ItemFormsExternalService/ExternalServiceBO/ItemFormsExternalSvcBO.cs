﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ItemFormsExternalService.ExternalServiceBO.Contracts;
using ItemFormsExternalService.ExternalServiceDac;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsBO.Contracts;

namespace ItemFormsExternalService.ExternalServiceBO
{
    public class ItemFormsExternalSvcBO : IItemFormsExternalSvcBO
    {
        private IItemFormsExternalSvcDac _externalSvcDac;
        protected readonly IBasicItemDefinitionBO _basicItemDefinitionBo;
        protected readonly IGeneralProductAttributesBO _generalProductAttributesBo;
        protected readonly IDsdAuthorizationRequestBO _dsdAuthorizationRequestBo;
        protected readonly IPackagingHierarchyBO _packagingHierarchyBo;
        protected readonly IProductAttributesBO _productAttributesBo;
        protected readonly IProductGroupingBO _productGroupingBo;
        protected readonly IScaleItemDetailsBO _scaleItemDetailsBo;
        protected readonly IShipperItemCompositionBO _shipperItemCompositionBo;
        protected readonly IMarketingSupportBO _marketingSupportBo;

        protected readonly ICommonBO _commonBo;

        public ItemFormsExternalSvcBO(IItemFormsExternalSvcDac externalSvcDac,
            ICommonBO commonBo,
            IBasicItemDefinitionBO basicItemDefinitionBo,
            IGeneralProductAttributesBO generalProductAttributesBo,
            IDsdAuthorizationRequestBO dsdAuthorizationRequestBo,
            IPackagingHierarchyBO packagingHierarchyBo,
            IProductAttributesBO productAttributesBo,
            IProductGroupingBO productGroupingBo,
            IScaleItemDetailsBO scaleItemDetailsBo,
            IShipperItemCompositionBO shipperItemCompositionBo,
            IMarketingSupportBO marketingSupportBo)
        {
            this._externalSvcDac = externalSvcDac;
            this._basicItemDefinitionBo = basicItemDefinitionBo;
            this._generalProductAttributesBo = generalProductAttributesBo;
            this._dsdAuthorizationRequestBo = dsdAuthorizationRequestBo;
            this._packagingHierarchyBo = packagingHierarchyBo;
            this._productAttributesBo = productAttributesBo;
            this._productGroupingBo = productGroupingBo;
            this._scaleItemDetailsBo = scaleItemDetailsBo;
            this._shipperItemCompositionBo = shipperItemCompositionBo;
            this._commonBo = commonBo;
            this._marketingSupportBo = marketingSupportBo;
        }

        public async Task<IEnumerable<ItemFormPMDSDto>> GetItemFormDetails(int itemFormId)
        {         
            List<ItemFormPMDSDto> groupedItemformsList = new List<ItemFormPMDSDto>();            
            List<ItemFormDto> grpdItemForms = await GetGroupedFormsByItemFormID(itemFormId);

            foreach (var itemForm in grpdItemForms)
            {                
                ItemFormPMDSDto itemformPMDSdto = new ItemFormPMDSDto();
                var itemFormData = await _commonBo.GetItemFormDataById(itemForm.ID);
                itemformPMDSdto.ID = itemFormData.ID;
                itemformPMDSdto.ItemFormDisplayID = itemFormData.ItemFormDisplayID;
                itemformPMDSdto.BuyerID = itemFormData.BuyerID;
                itemformPMDSdto.BuyerName = itemFormData.BuyerName;
                itemformPMDSdto.FormTypeID = itemFormData.FormTypeID;

                if (itemForm.ID == itemFormId)
                {
                    var bidData = await _basicItemDefinitionBo.GetBasicItemDefinitionData(itemForm.ID);
                    itemformPMDSdto.BasicItemDefinition = bidData;
                }

                if (itemForm.ID == itemFormId)
                {
                    var gpaData = await _generalProductAttributesBo.GetGeneralProdutAttributes(itemForm.ID);
                    itemformPMDSdto.GeneralProductAttributes = gpaData;
                }

                var phData = await _packagingHierarchyBo.GetPackagingHierarchies(itemForm.ID);
                foreach (var ph in phData)
                {
                    ph.orderablePackLevels = ph.orderablePackLevels.Where(opl => opl.ShippingPackagingLevelID != null).ToList();                   
                }
                itemformPMDSdto.PackagingHierarchy = phData;
              

                var dsdData = await _dsdAuthorizationRequestBo.GetDsdVendorAuthorizations(itemForm.ID);
                itemformPMDSdto.DsdVendorAuthorizations = dsdData;

                // var marketingData = await _marketingSupportBo.GetMarketingInfo(itemFormId);
                // itemformPMDSdto.mar

                if (itemForm.ID == itemFormId)
                {
                    var shipperData = await _shipperItemCompositionBo.GetShipperCompositionItems(itemForm.ID);
                    itemformPMDSdto.ShipperItemCompositionList = shipperData;
                }

                if (itemForm.ID == itemFormId)
                {
                    var scaleData = await _scaleItemDetailsBo.GetScaleInfo(itemForm.ID);
                    itemformPMDSdto.ScaleItemDetails = scaleData;
                }


                if (itemForm.ID == itemFormId)
                {
                    var paData = await _productAttributesBo.GetProductAttributes(itemForm.ID);
                    itemformPMDSdto.ProductAttributes = paData;
                }

                var pgData = await _productGroupingBo.GetProductGrouping(itemForm.ID);
                itemformPMDSdto.ProductGrouping = pgData;

                groupedItemformsList.Add(itemformPMDSdto);
            }

            return groupedItemformsList;
        }

        //public Task<IEnumerable<int>> GetItemFormsSubmittedForCreation()
        //{
        //    throw new NotImplementedException();
        //}
    


    public async Task<IEnumerable<int>> GetItemFormsSubmittedForCreation()
        {
            return await _externalSvcDac.GetItemFormsSubmittedForCreation();
        }


        //Get all the grouped forms by ItemFormID.
        private async Task<List<ItemFormDto>> GetGroupedFormsByItemFormID(int itemFormID)
        {
            var sameGTINList = await _commonBo.GetItemFormGroup(itemFormID);
            var grpdItemForms = new List<ItemFormDto>();
            foreach (ItemFormDto itemForm in sameGTINList)
            {
                if (itemForm.ID == itemFormID && itemForm.IsInGroup != "Y")
                {
                    grpdItemForms = new List<ItemFormDto>();
                    grpdItemForms.Add(itemForm);
                    break;
                }
                else if (itemForm.IsInGroup == "Y")
                {
                    grpdItemForms.Add(itemForm);
                }
            }

            return grpdItemForms;
        }
    }
}