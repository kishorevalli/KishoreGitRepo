﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Publix.S0VPITEM.ItemFormsEntities;

namespace ItemFormsExternalService.ExternalServiceDac
{
    public class ItemFormsExternalSvcDac : BaseDac , IItemFormsExternalSvcDac
    {

        public async Task<IEnumerable<int>> GetItemFormsSubmittedForCreation()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<int>(GetItemFormsSubmittedForCreationSQL));
            }         
        }




        #region Queries        

        //      private const string GetItemFormsSubmittedForCreationSQL = @" SELECT ItemFormID FROM ItemFormsForCreation ifc
        //inner join ItemForm ifm on ifc.ItemFormID = ifm.ID
        // where ifc.Status = 'W' and ifm.ParentFlag = 'Y'";


        private const string GetItemFormsSubmittedForCreationSQL = @" SELECT ItemFormID FROM ItemFormsForCreation 
                        where Status = 'W' and ParentFlag = 'Y'";



        #endregion
    }
}