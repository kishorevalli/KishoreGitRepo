﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Dapper;
using System.Configuration;
using System.Data.Common;

namespace ItemFormsExternalService.ExternalServiceDac
{
    public abstract class BaseDac
    {
        public static string PublixEnvironment
        {
            get
            {
                return Environment.GetEnvironmentVariable("PublixEnvironment");
            }
        }

        /// <summary>
        /// get the DbConnection for the S0VPITEM database
        /// </summary>
        public IDbConnection S0VPITEM_Connection
        {
            get
            {
                var cs = ConfigurationManager.ConnectionStrings[PublixEnvironment + "-S0VPITEM"];
                var cf = DbProviderFactories.GetFactory(cs.ProviderName);
                var cn = cf.CreateConnection();
                cn.ConnectionString = cs.ConnectionString;
                return cn;
            }
        }
    }
}