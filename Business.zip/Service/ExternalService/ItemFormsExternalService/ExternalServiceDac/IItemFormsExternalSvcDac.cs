﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemFormsExternalService.ExternalServiceDac
{
    public interface IItemFormsExternalSvcDac
    {
        Task<IEnumerable<int>> GetItemFormsSubmittedForCreation();

       // Task<IEnumerable<ItemFormPMDSDto>> GetItemFormDetails(int itemFormId);
    }
}
