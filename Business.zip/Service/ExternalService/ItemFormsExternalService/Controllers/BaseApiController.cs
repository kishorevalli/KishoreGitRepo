﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using log4net;

namespace ItemFormsExternalService.Controllers
{
    public class BaseApiController : ApiController
    {
        protected readonly ILog _Logger;

        /// <summary>
        /// Constructor
        /// </summary>        
        /// <param name="logger"></param>
        public BaseApiController(ILog logger)
        {            
            _Logger = logger;
        }

    }
}
