﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using log4net;
using System.Threading.Tasks;
using System.Collections;
using ItemFormsExternalService.ExternalServiceBO.Contracts;
using ItemFormsExternalService.ExternalServiceBO;

namespace ItemFormsExternalService.Controllers
{
    [RoutePrefix("api/ItemForms")]
    public class ItemFormsExternalSvcController : BaseApiController
    {
        private ILog _logger;
        private IItemFormsExternalSvcBO _itemFormsSvcBO;
        public ItemFormsExternalSvcController(ILog logger , IItemFormsExternalSvcBO itemFormsSvcBO) : base(logger)
        {
            this._logger = logger;
            this._itemFormsSvcBO = itemFormsSvcBO;
        }

        [HttpGet]
        [Route("GetItemFormsSubmittedForCreation")]
        public async Task<IHttpActionResult> GetItemFormsSubmittedForCreation()
        {
            try
            {
                var itemForms = await _itemFormsSvcBO.GetItemFormsSubmittedForCreation();
                return Ok(itemForms);
            }
            catch (Exception ex)
            {
                _logger.Error("ItemFormsController.GetItemFormsSubmittedForCreation: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

        [HttpGet]
        [Route("GetItemFormDetails")]
        public async Task<IHttpActionResult> GetItemFormDetails(int itemFormID)
        {
            var itemForms = await _itemFormsSvcBO.GetItemFormDetails(itemFormID);
            return Ok(itemForms);
            
            //throw new NotImplementedException();
        }
    }
}
