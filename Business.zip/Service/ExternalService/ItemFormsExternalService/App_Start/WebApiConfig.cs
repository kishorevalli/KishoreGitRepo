﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Unity;
using ItemFormsExternalService.ExternalServiceBO.Contracts;
using ItemFormsExternalService.ExternalServiceBO;
using ItemFormsExternalService.ExternalServiceDac;
using Unity.Lifetime;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsBO;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsDac;

namespace ItemFormsExternalService
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            //config.Routes.MapHttpRoute(
            //    name: "DefaultApi",
            //    routeTemplate: "api/{controller}/{id}",
            //    defaults: new { id = RouteParameter.Optional }
            //);


            // Web API configuration and services
            var container = new UnityContainer();
            container.RegisterInstance(WebApiApplication.log);            
            config.DependencyResolver = new UnityResolver(container);

            // register business objects
            container.RegisterType<IItemFormsExternalSvcBO, ItemFormsExternalSvcBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IItemFormsExternalSvcDac, ItemFormsExternalSvcDac>(new HierarchicalLifetimeManager());

            container.RegisterType<ICommonBO, CommonBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IBasicItemDefinitionBO, BasicItemDefinitionBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IGeneralProductAttributesBO, GeneralProductAttributesBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IPackagingHierarchyBO, PackagingHierarchyBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IDsdAuthorizationRequestBO, DsdAuthorizationRequestBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IShipperItemCompositionBO, ShipperItemCompositionBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IMarketingSupportBO, MarketingSupportBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IProductGroupingBO, ProductGroupingBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IScaleItemDetailsBO, ScaleItemDetailsBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IProductAttributesBO, ProductAttributesBO>(new HierarchicalLifetimeManager());


            container.RegisterType<ICommonDac, CommonDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IBasicItemDefinitionDac, BasicItemDefinitionDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IGeneralProductAttributesDac, GeneralProductAttributesDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IWorkFlowDac, WorkFlowDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IDsdAuthorizationRequestDac, DsdAuthorizationRequestDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IPackagingHierarchyDac, PackagingHierarchyDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IShipperItemCompositionDac, ShipperItemCompositionDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IDashboardDac, DashboardDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IMarketingSupportDac, MarketingSupportDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IProductGroupingDac, ProductGroupingDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IScaleItemDetailsDac, ScaleItemDetailsDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IProductAttributesDac, ProductAttributesDac>(new HierarchicalLifetimeManager());
            config.DependencyResolver = new UnityResolver(container);
        }
    }
}
