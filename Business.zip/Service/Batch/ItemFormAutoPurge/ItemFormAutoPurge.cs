﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO;




namespace ItemFormAutoPurge
{
    class ItemFormAutoPurge
    {
        enum returnCode
        {

            Successful = 0,  // Job and/or step completed with no errors.
            Warning = 4,    // 4 = Warning. Job and/or step completed with cautions.
            Failure = 8,   // 8 = Failure. Job and/or step completed with one or more errors.
            Severe = 12,
        }
        static int Main(string[] args)
        {
            int retCode = 4;
            string purgeDBName;
            //string logTile;
            ItemFormAutoPurgeBO APBO = new ItemFormAutoPurgeBO();
            try
            {
               // logTile = ("AutoPurge " + purgeDBName);
                purgeDBName = "S0VPITEM";
                // APBO.LogMessage(logTile, string.Format(MessageMgr.GetSystemMsg("AP0007"), Now));
                APBO.ProcessAutoPurge(purgeDBName);
                retCode = (int)returnCode.Successful; 
            }
            catch (Exception ex)
            {
                string s = ex.Message;
               // APBO.LogMessage(logTile, ex.Message, TraceEventType.Error);
                retCode =(int) returnCode.Severe;
            }
            finally
            {
               // APBO.LogMessage(logTile, string.Format(MessageMgr.GetSystemMsg("AP0008"), Now));
            }
            return retCode;

        }
    }
}
