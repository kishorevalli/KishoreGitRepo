﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsCommon;

namespace LithiumBatterySurveyNotification
{
    class LithiumBatterySurveyNotification
    {
        static void Main(string[] args)
        {
            Publix.S0VPITEM.ItemFormsCommon.EmailServiceAgent sa = new EmailServiceAgent();

            sa.SendNotificationEmail();

        }
    }
}
