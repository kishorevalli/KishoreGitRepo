﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using System.Threading.Tasks;

using log4net;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;


namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    

    [RoutePrefix("api/ShipperItemComposition")]
    public class ShipperItemCompositionController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IShipperItemCompositionBO _shipperItemCompositionBO;
        private ISubmitBO _submitBO;
        protected readonly ICommonBO _commonBo;

        public ShipperItemCompositionController(IIdentityService identityService, ILog logger, IShipperItemCompositionBO shipperItemCompositionBO,ICommonBO commonBo, ISubmitBO submitBO)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._shipperItemCompositionBO = shipperItemCompositionBO;
            this._commonBo = commonBo;
            this._submitBO = submitBO;
        }
      
        [HttpGet]
        [Route("GetShipperCompositionItems")]
        public async Task<IHttpActionResult> GetShipperCompositionItems(int ItemFormID)
        {
            try
            {
                IEnumerable<ShipperItemCompositionDto> shipperCompositionItems = await _shipperItemCompositionBO.GetShipperCompositionItems(ItemFormID);
                return Ok(shipperCompositionItems);
            }
            catch (Exception ex)
            {
                _logger.Error("ShipperItemCompositionController.GetShipperCompositionItems: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        
        [HttpPost]
        [Route("ValidateShipperItemCompositionByItemCode")]
        public async Task<IHttpActionResult> ValidateShipperItemCompositionByItemCode(ShipperItemCompositionDto shipperItem)
        {
            try
            {
                int itemcode = Convert.ToInt32(shipperItem.CompositionItemCode);
                ShipperItemCompositionDto shipperCompositionItems = await _shipperItemCompositionBO.ValidateShipperItemCompositionByItemCode(itemcode, _identity.CurrentUser, _identity.GetUserProfile().GroupName, shipperItem.CreatedByUserTypeID);
                if (shipperCompositionItems != null && shipperCompositionItems.CompositionItemCode == "0")
                    shipperCompositionItems.CompositionItemCode = string.Empty;
                return Ok(shipperCompositionItems);
            }
            catch (Exception ex)
            {
                _logger.Error("ShipperItemCompositionController.ValidateShipperItemCompositionByItemCode: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("ValidateShipperItemCompositionByGTIN")]
        public async Task<IHttpActionResult> ValidateShipperItemCompositionByGTIN(ShipperItemCompositionDto shipperItem)
        {
            try
            {
               
                ShipperItemCompositionDto shipperCompositionItems = await _shipperItemCompositionBO.ValidateShipperItemCompositionByGTIN(shipperItem.CompositionGTIN, _identity.CurrentUser, _identity.GetUserProfile().GroupName, shipperItem.CreatedByUserTypeID);
                return Ok(shipperCompositionItems);
            }
            catch (Exception ex)
            {
                _logger.Error("ShipperItemCompositionController.ValidateShipperItemCompositionByItemCode: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("SaveShipperItemCompositions")]
        public async Task<IHttpActionResult> SaveShipperItemCompositions(IEnumerable<ShipperItemCompositionDto> shipperCompositionList)
        {

            try
            {
                var shipperErrorDto = await _shipperItemCompositionBO.ValidateShipperItemComposition(shipperCompositionList);

                if ((shipperErrorDto.Errors.Count() > 0))
                {
                    return ResponseMessage(
                        Request.CreateResponse(HttpStatusCode.BadRequest, shipperErrorDto));
                }
                else
                {
                    UserProfile userProfile = _IdentityService.GetUserProfile();
                    string currentUser = userProfile.CurrentUser;
                    UserType userType = userProfile.userType;

                    int? ItemFormID = shipperCompositionList.First().ItemFormID;
                    bool returnValue = await _shipperItemCompositionBO.SaveShipperItemCompositions(shipperCompositionList, ItemFormID.GetValueOrDefault());
                    bool _success = await _commonBo.SaveItemFormErrors(shipperErrorDto, (int)ItemFormID, currentUser);
                    var itemSaveResponseDTO = new ItemSaveResponseDTO
                    {
                        Status = returnValue,
                        Validation = shipperErrorDto
                    };

                    //Submit - validate all tabs. If any error\warning found return status false. If no error found , update item form with submit status.
                    if (shipperCompositionList.First().FormActionID == 3)
                    {
                        var errorsFound = await _submitBO.PerformSubmitValidations((int)ItemFormID, _IdentityService.CurrentUser, userType);
                        if (errorsFound)
                        {
                            var itemSubmitResponseDTO = new ItemSaveResponseDTO
                            {
                                Status = false,
                                Validation = null
                            };

                            return Ok(itemSubmitResponseDTO);
                        }
                    }

                    //Update ItemForm
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = (int)shipperCompositionList.First().ItemFormID;
                    itemForm.FormStatusID = shipperCompositionList.FirstOrDefault().FormStatusID ?? 0;
                    itemForm.FormActionID = shipperCompositionList.FirstOrDefault().FormActionID ?? 0;
                    itemForm.SubmittedUserTypeID = (int)shipperCompositionList.FirstOrDefault().SubmittedUserTypeID;
                    itemForm.LastUpdatedBy = _IdentityService.CurrentUser;
                    await _commonBo.UpdateItemForm(itemForm);
                    //  }
                    return Ok(itemSaveResponseDTO);
                }
            }

            //try
            //{
            //    int? ItemFormID = shipperCompositionList.First().ItemFormID;                
            //    bool result = await _shipperItemCompositionBO.SaveShipperItemCompositions(shipperCompositionList,ItemFormID.GetValueOrDefault());
            //    return Ok(result);
            //}
            catch (Exception ex)
            {
                _logger.Error("ShipperItemCompositionController.SaveShipperItemCompositions: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        

    }
}
