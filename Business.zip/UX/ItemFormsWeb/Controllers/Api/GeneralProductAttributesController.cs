using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Publix.S0VPITEM.ItemFormsEntities;
using log4net;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/GeneralProductAttributes")]
    public class GeneralProductAttributesController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IGeneralProductAttributesBO _generalProductAttributesBO;
        private ISubmitBO _submitBO;
        protected readonly ICommonBO _commonBo;

        public GeneralProductAttributesController(IIdentityService identityService, ILog logger, IGeneralProductAttributesBO generalProductAttributesBO, ICommonBO commonBo, ISubmitBO submitBO)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._generalProductAttributesBO = generalProductAttributesBO;
            this._commonBo = commonBo;
            this._submitBO = submitBO;
        }


        [HttpGet]
        [Route("GetNutritionalPanelTypes")]
        public async Task<IHttpActionResult> GetNutritionalPanelTypes()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _generalProductAttributesBO.GetNutritionalPanelTypes();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetNutritionalPanelTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetOrganicTypes")]
        public async Task<IHttpActionResult> GetOrganicTypes()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _generalProductAttributesBO.GetOrganicTypes();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetOrganicTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetNDCFormats")]
        public async Task<IHttpActionResult> GetNDCFormats()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _generalProductAttributesBO.GetNDCFormats();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetNDCFormats: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetProductDateTypes")]
        public async Task<IHttpActionResult> GetProductDateTypes()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _generalProductAttributesBO.GetProductDateTypes();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetProductDateTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDrugScheduleCodes")]
        public async Task<IHttpActionResult> GetDrugScheduleCodes()
        {
            try
            {
                IEnumerable<DrugScheduleCodeDto> lookupDtoList = await _generalProductAttributesBO.GetDrugScheduleCodes();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetDrugScheduleCodes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetNutrientDetails")]
        public async Task<IHttpActionResult> GetNutrientDetails()
        {
            try
            {
                IEnumerable<NutrientDictionary> nutrientList = await _generalProductAttributesBO.GetNutrientDetails();
                var response = nutrientList
                    .Select(item => new NutritionalInfoDto
                    {
                        NutrDictionaryID = (int)item.NutrDictionaryID,
                        NutrientName = item.Name,
                        UOM = item.FkUOMID,
                        IsRequired = item.Isrequired,
                        SortOrder = (int)item.SortOrder
                    });
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetNutrientDetails: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }



        [HttpGet]
        [Route("GetAllergensDetails")]
        public async Task<IHttpActionResult> GetAllergensDetails()
        {
            try
            {
                IEnumerable<NutrientDictionary> allergensList = await _generalProductAttributesBO.GetAllergensDetails();
                var response = allergensList.Select(item => new NutritionalAllergenInfoDto
                {
                    NutrDictionaryID = (int)item.NutrDictionaryID,
                    AllergenName = item.Name,
                    SortOrder = (int)item.SortOrder
                });
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetAllergensDetails: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        //Authorize attribute will check for the principal object and will throw 401 error if principal not found.
        [Authorize]
        [HttpPost]
        [Route("SaveGeneralProductAttributes")]
        public async Task<IHttpActionResult> SaveGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes)
        {
            try
            {               
                var gpaErrorDto = await _generalProductAttributesBO.ValidateGeneralProductAttributes(generalProductAttributes);

                if ((gpaErrorDto.Errors.Count() > 0) || (gpaErrorDto.SubTabValidations.Where(stv => stv.Errors.Count() > 0).FirstOrDefault() != null))
                {
                    return ResponseMessage(
                        Request.CreateResponse(HttpStatusCode.BadRequest, gpaErrorDto));
                }
                else
                {
                    UserProfile userProfile = _IdentityService.GetUserProfile();
                    string currentUser = userProfile.CurrentUser;
                    UserType userType = userProfile.userType;
                    generalProductAttributes.CreatedBy = currentUser;
                    bool returnValue = await _generalProductAttributesBO.SaveGeneralProductAttributes(generalProductAttributes);
                    bool _success = await _commonBo.SaveItemFormErrors(gpaErrorDto, generalProductAttributes.ItemFormID, generalProductAttributes.CreatedBy);
                    var itemSaveResponseDTO = new ItemSaveResponseDTO
                    {
                        Status = returnValue,
                        Validation = gpaErrorDto
                    };

                    //Submit - validate all tabs. If any error\warning found return status false. If no error found , update item form with submit status.
                    if (generalProductAttributes.FormActionID == 3)
                    {
                        var errorsFound = await _submitBO.PerformSubmitValidations(generalProductAttributes.ItemFormID, _IdentityService.CurrentUser , userType);
                        if (errorsFound)
                        {
                            var itemSubmitResponseDTO = new ItemSaveResponseDTO
                            {
                                Status = false,
                                Validation = null
                            };

                            return Ok(itemSubmitResponseDTO);
                        }
                    }

                    //Update ItemForm
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = generalProductAttributes.ItemFormID;
                    itemForm.FormStatusID = generalProductAttributes.FormStatusID;
                    itemForm.FormActionID = generalProductAttributes.FormActionID;
                    itemForm.SubmittedUserTypeID = (int)generalProductAttributes.SubmittedUserTypeID;
                    itemForm.LastUpdatedBy = generalProductAttributes.LastUpdatedBy;
                    await _commonBo.UpdateItemForm(itemForm);
                    //  }
                    return Ok(itemSaveResponseDTO);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.SaveGeneralProductAttributes", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetGeneralProductAttributes")]
        public async Task<IHttpActionResult> GetGeneralProductAttributes(int ItemFormID)
        {
            try
            {
                string currentUserId = _IdentityService.CurrentUser;
                var generalProductAttributes = await _generalProductAttributesBO.GetGeneralProdutAttributes(ItemFormID);
                //if (generalProductAttributes != null)
                //{
                //    return Ok(generalProductAttributes);
                //}
                //else
                //{ return NotFound(); }
                return Ok(generalProductAttributes);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetGeneralProductAttributes", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetVariableWeightIndicators")]
        public async Task<IHttpActionResult> GetVariableWeightIndicators()
        {
            try
            {
                IEnumerable<VariableWeightIndicatorDto> lookupDtoList = await _generalProductAttributesBO.GetVariableWeightIndicators();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetVariableWeightIndicators: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetLiquorTypes")]
        public async Task<IHttpActionResult> GetLiquorTypes()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _generalProductAttributesBO.GetLiquorTypes();
                //return Ok(lookupDtoList);
                List<LookupDto> lookupDtoListWithEmpty = new List<LookupDto>()
                {
                    new LookupDto { Code = "", Description = "" }
                };
                lookupDtoListWithEmpty.AddRange(lookupDtoList.ToList());
                return Ok(lookupDtoListWithEmpty);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetLiquorTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetShelfTagSizes")]
        public async Task<IHttpActionResult> GetShelfTagSizes()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _generalProductAttributesBO.GetShelfTagSizes();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetShelfTagSizes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetUnacceptableIngredientList")]
        public async Task<IHttpActionResult> GetUnacceptableIngredientList()
        {
            try
            {
                IEnumerable<UnacceptableIngredientDto> unacceptableIngredientList = await _generalProductAttributesBO.GetUnacceptableIngredientList();
                return Ok(unacceptableIngredientList);
            }
            catch (Exception ex)
            {
                _logger.Error("GeneralProductAttributesController.GetUnacceptableIngredientList: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

    }
}