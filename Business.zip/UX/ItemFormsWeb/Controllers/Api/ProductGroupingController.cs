﻿using log4net;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Collections.Generic;
using System.Net.Http;
using System.Net;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/ProductGrouping")]
    public class ProductGroupingController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IProductGroupingBO _productGroupingBO;
        private ISubmitBO _submitBO;        
        protected readonly ICommonBO _commonBo;

        public ProductGroupingController(IIdentityService identityService, ILog logger, IProductGroupingBO productGroupingBO, ICommonBO commonBo , ISubmitBO submitBO)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._productGroupingBO = productGroupingBO;
            this._commonBo = commonBo;
            this._submitBO = submitBO;
        }
        
        [HttpGet]
        [Route("GetProductGrouping")]
        public async Task<IHttpActionResult> GetProductGrouping(int ItemFormID)
        {
            try
            {
                IEnumerable<ProductGroupingDto> lookupDtoList = await _productGroupingBO.GetProductGrouping(ItemFormID);
                return Ok(lookupDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetProductGrouping: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetProductGroupingByItemCode")]
        public async Task<IHttpActionResult> GetProductGroupingByItemCode(int? ItemCode, int ModelGroupCodeType)
        {
            try
            {
                if(ItemCode == null) return Ok(new List<ProductGroupingDto>());
                IEnumerable<ProductGroupingDto> ProductGroupingDtoList = await _productGroupingBO.GetProductGroupingByItemCode((int)ItemCode, ModelGroupCodeType);
                return Ok(ProductGroupingDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetProductGroupingByItemCode: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetChildItemGroupTypes")]
        public async Task<IHttpActionResult> GetChildItemGroupTypes()
        {
            try
            {
                IEnumerable<ProductGroupType> ProductGroupTypeList = await _productGroupingBO.GetChildItemGroupTypes();
                return Ok(ProductGroupTypeList);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetChildItemGroupTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetItemGroupCodes")]
        public async Task<IHttpActionResult> GetItemGroupCodes(string GroupType)
        {
            try
            {
                IEnumerable<LookupDto> ProductGroupCodes = await _productGroupingBO.GetItemGroupCodes(GroupType);
                return Ok(ProductGroupCodes);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetItemGroupCodes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetVBGVendors")]
        public async Task<IHttpActionResult> GetVBGVendors(int ItemFormID)
        {
            try
            {
                var ProductGroupingDtoList = await _productGroupingBO.GetVBGVendors(ItemFormID);
                return Ok(ProductGroupingDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetVBGVendors: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpPost]
        [Route("GetVBGGroupCodes")]
        public async Task<IHttpActionResult> GetVBGGroupCodes(List<ProductGroupingVendorDto> Vendors)
        {
            try
            {
                List<int> VendorNumbers = Vendors.Select(vn => vn.VendorNumber).ToList();
                IEnumerable<ProductVBGGroupDto> ProductGroupCodes = await _productGroupingBO.GetVBGGroupCodes(VendorNumbers);
                return Ok(ProductGroupCodes);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetVBGGroupCodes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetParentGroupTypesAndCodes")]
        public async Task<IHttpActionResult> GetParentGroupTypesAndCodes(string GroupType, int GroupCode)
        {
            try
            {
                IEnumerable<ProductGroupingDto> ProductGroupingDtoList = await _productGroupingBO.GetParentGroupTypesAndCodes(GroupType, GroupCode);
                return Ok(ProductGroupingDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetParentGroupTypesAndCodes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetSubmittedItemFormIDWithSameGTIN")]
        public async Task<IHttpActionResult> GetSubmittedItemFormIDWithSameGTIN(int ItemFormID)
        {
            try
            {
                int similarItemFormID = await _productGroupingBO.GetSubmittedItemFormIDWithSameGTIN(ItemFormID);
                return Ok(similarItemFormID);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetSubmittedItemFormIDWithSameGTIN: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpPost]
        [Route("GetProductPriceGroup")]
        public async Task<IHttpActionResult> GetProductPriceGroup(LookupDto LookupDto)
        {
            try
            {
                string SearchBy = LookupDto.Code;
                string SearchValue = LookupDto.Description;
                if (string.IsNullOrEmpty(SearchValue)) return Ok(new List<ProductPriceGroupDto>());
                var ProductGroupingDtoList = await _productGroupingBO.GetProductPriceGroup(SearchBy, SearchValue);
                return Ok(ProductGroupingDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetProductPriceGroup: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpPost]
        [Route("GetProductAdGroup")]
        public async Task<IHttpActionResult> GetProductAdGroup(LookupDto LookupDto)
        {
            try
            {
                string SearchBy = LookupDto.Code;
                string SearchValue = LookupDto.Description;
                if (string.IsNullOrEmpty(SearchValue)) return Ok(new List<ProductAdGroupDto>());
                var ProductGroupingDtoList = await _productGroupingBO.GetProductAdGroup(SearchBy, SearchValue);
                return Ok(ProductGroupingDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetProductAdGroup: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetSubDepartments")]
        public async Task<IHttpActionResult> GetSubDepartments()
        { 
            try
            {
                var SubDepartments = await _productGroupingBO.GetSubDepartments();
                return Ok(SubDepartments);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetSubDepartments: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetCategory")]
        public async Task<IHttpActionResult> GetCategory(int SubDepartment)
        {
            try
            {
                var ProductGroupingDtoList = await _productGroupingBO.GetCategory(SubDepartment);
                return Ok(ProductGroupingDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetCategory: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetFamilyGroup")]
        public async Task<IHttpActionResult> GetFamilyGroup(int SubDepartment, int Category)
        {
            try
            {
                var ProductGroupingDtoList = await _productGroupingBO.GetFamilyGroup(SubDepartment, Category);
                return Ok(ProductGroupingDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.GetFamilyGroup: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [Authorize]
        [HttpPost]
        [Route("SaveProductGrouping/{ItemFormID}/{FormStatusID:int?}/{FormActionID:int?}")]
        public async Task<IHttpActionResult> SaveProductGrouping(List<ProductGroupingDto> productGroupingList, int ItemFormID, int? FormStatusID = null, int? FormActionID = null)
        {
            try
            {
                ItemValidationDTO validationDTO = await _productGroupingBO.ValidateProductGrouping(productGroupingList);

                if (validationDTO.Errors.Count() > 0)
                {
                    return ResponseMessage(
                            Request.CreateResponse(HttpStatusCode.BadRequest, validationDTO));
                }
                else
                {
                    UserProfile userProfile = _IdentityService.GetUserProfile();
                    string currentUser = userProfile.CurrentUser;
                    UserType userType = userProfile.userType;
                    bool returnValue = await _productGroupingBO.SaveProductGrouping(productGroupingList, ItemFormID, currentUser, userType, FormStatusID, FormActionID);
                    bool _success = await _commonBo.SaveItemFormErrors(validationDTO, ItemFormID, currentUser);
                    var itemSaveResponseDTO = new ItemSaveResponseDTO
                    {
                        Status = returnValue,
                        Validation = validationDTO
                    };

                    //Submit - validate all tabs. If any error\warning found return bad Request. If no error found , update item form with submit status.
                    if (FormActionID == 3)
                    {
                        var errorsFound = await _submitBO.PerformSubmitValidations(ItemFormID, _IdentityService.CurrentUser, userType);
                        if (errorsFound)
                        {
                            var itemSubmitResponseDTO = new ItemSaveResponseDTO
                            {
                                Status = false,
                                Validation = null
                            };

                            return Ok(itemSubmitResponseDTO);
                        }
                    }

                    //Update ItemForm
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = ItemFormID;
                    itemForm.FormStatusID = FormStatusID ?? 0;
                    itemForm.FormActionID = FormActionID ?? 0;
                    itemForm.SubmittedUserTypeID = (int)userType;
                    itemForm.LastUpdatedBy = currentUser;
                    await _commonBo.UpdateItemForm(itemForm);
                    return Ok(itemSaveResponseDTO);
                }
                
            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.SaveProductGrouping", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [Authorize]
        [HttpPost]
        [Route("SaveFAMProductGrouping/{ItemFormID}/{FormStatusID:int?}/{FormActionID:int?}")]
        public async Task<IHttpActionResult> SaveFAMProductGrouping(List<ProductGroupingDto> productGroupingList, int ItemFormID, int? FormStatusID = null, int? FormActionID = null)
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                string currentUser = userProfile.CurrentUser;
                UserType userType = userProfile.userType;
                bool returnValue = await _productGroupingBO.SaveFAMProductGrouping(productGroupingList, ItemFormID, currentUser, userType, FormStatusID, FormActionID);                
                return Ok(returnValue);

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.SaveFAMProductGrouping", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
    }
}
