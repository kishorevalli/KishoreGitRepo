﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using Publix.S0VPITEM.ItemFormsEntities;
using log4net;
using Publix.S0VPITEM.ItemFormsBO.Contracts;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/WorkFlow")]
    public class WorkFlowController :BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IWorkFlowBO _WorkFlowBO;

        public WorkFlowController(IIdentityService identityService, ILog logger, IWorkFlowBO WorkFlowBO)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._WorkFlowBO = WorkFlowBO;
        }

        [HttpGet]
        [Route("GetFormUserPermittedAction/{currentUserType}/{formCurrentStatusID}/{formTypeID}")]
        public  async Task<IHttpActionResult> GetFormUserPermittedAction(UserType currentUserType, int formCurrentStatusID , int formTypeID)
        {
            try
            {
                
                return Ok(await _WorkFlowBO.GetFormUserPermittedAction(currentUserType, formCurrentStatusID , formTypeID));
            }
            catch (Exception ex)
            {
                _logger.Error("WorkFlowController.GetFormUserPermittedAction: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
           
        }    
    }
}