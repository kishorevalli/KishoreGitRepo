﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using log4net;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    public class BaseApiController : ApiController
    {
        protected readonly ILog _Logger;
        protected readonly IIdentityService _IdentityService;
               
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="identityService"></param>
        /// <param name="logger"></param>
        public BaseApiController(IIdentityService identityService, ILog logger)
        {
            _IdentityService = identityService;
            _Logger = logger;
        }

        
        //public static string PublixEnvironment
        //{
        //    get
        //    {
        //        return Environment.GetEnvironmentVariable("PublixEnvironment");
        //    }
        //}
    }
}
