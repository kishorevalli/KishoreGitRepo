﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Publix.S0VPITEM.ItemFormsEntities;
using log4net;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using System.Web.Http.Results;
using System.Net.Http.Headers;
using System.Configuration;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/Common")]
    public class CommonController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private ICommonBO _commonBO;
        public CommonController(IIdentityService identityService, ILog logger , ICommonBO commonBO) : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._commonBO = commonBO;
        }

        [HttpPost]
        [Route("DeleteItemForm")]
        public async Task<IHttpActionResult> DeleteItemForm(ItemFormDto itemFormDto)
        {
            try
            {
                //TODO Inject IdentityService to DAC class
                itemFormDto.CreatedBy = _IdentityService.CurrentUser;
                itemFormDto.LastUpdatedBy = _IdentityService.CurrentUser;

                //TODO: call _commonBO.UpdateItemForm instead of DeleteItemForm and pass the formstatusID of delete.               
                bool returnValue = await _commonBO.DeleteItemForm(itemFormDto);
                return Ok(returnValue);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.DeleteItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

        [HttpPost]
        [Route("SaveItemForm")]
        public async Task<IHttpActionResult> SaveItemForm(ItemFormDto itemFormDto)
        {
            try
            {                
                //TODO Inject IdentityService to DAC class       
                UserProfile userProfile = _IdentityService.GetUserProfile();
                itemFormDto.SubmittedUserTypeID = (int)userProfile.userType; //userProfile.IsExternal ? 1 : 2; //TODO Remove hard code
                itemFormDto.CreatedBy = userProfile.CurrentUser;
                itemFormDto.LastUpdatedBy = userProfile.CurrentUser;
                itemFormDto.CreatedByUserTypeID = (int)userProfile.userType;
                itemFormDto = await _commonBO.SaveItemForm(itemFormDto);
                return Ok(itemFormDto);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.SaveItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

        [HttpGet]
        [Route("GetItemFormData")]
        public async Task<IHttpActionResult> GetItemFormData(long itemFormDisplayId)
        {
            try
            {
                ItemFormDto itemFormDto = await _commonBO.GetItemFormData(itemFormDisplayId);
                return Ok(itemFormDto);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetBasicItemDefinitionData: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }


        }

        [HttpPost]
        [Route("GetErrorMessagesByType")]
        public async Task<IEnumerable<ErrorDTO>> GetErrorMessagesByType(ErrorDTO errors)
        {
            try
            {
                Task<IEnumerable<ErrorDTO>> popuperrors =  _commonBO.GetErrorMessagesByType(errors);
                return await popuperrors;
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetErrorMessagesByType: ", ex);
                //return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
                return null;
            }

        }

        [HttpGet]
        [Route("GetAuthData")]
        public IHttpActionResult GetAuthData()
        {
            
            
            try
            {                
                var user = _identity.GetUserProfile();           
                if (string.IsNullOrEmpty(user.CurrentUser))
                {
                    string redirectUri = ConfigurationManager.AppSettings[_commonBO.PublixEnvironment + "-LoginURL"];
                    var obj = new 
                    {
                        Message = "Authorization has been denied for this request",
                        RedirectUri = (!string.IsNullOrEmpty(redirectUri) && redirectUri.StartsWith("http")) ? new Uri(redirectUri) : null
                    };
                    var response = Request.CreateResponse(HttpStatusCode.Unauthorized, obj);
                    return ResponseMessage(response);
                }
                return Ok(user);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.GetAuthData: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }


        }

        [HttpGet]
        [Route("GetNavigationUri")]
        public IHttpActionResult GetNavigationUri()
        {
            try
            {
                string logoutURL = ConfigurationManager.AppSettings[_commonBO.PublixEnvironment + "-LogOutURL"];
                var logoutUri = (!string.IsNullOrEmpty(logoutURL) && logoutURL.StartsWith("http")) ? new Uri(logoutURL) : null;
                return Ok(logoutUri);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.GetNavigationUrl: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }


        }

        [HttpGet]
        [Route("IsDsdVendorsExistForUser")]
        public async Task<IHttpActionResult> IsDsdVendorsExistForUser(string userId)
        {
            try
            {
                bool retValue = true;
                var user = _identity.GetUserProfile();
                if (user.IsExternal)
                {
                    retValue = await _commonBO.IsDsdVendorsExistForUser(userId);
                }
                else
                {
                    //TODO Remove when we don't need to cache
                    try
                    {
                        await _commonBO.IsDsdVendorsExistForUser(userId).ConfigureAwait(false);
                    }
                    catch
                    {
                        throw;
                    }
                    
                }
               
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.IsDsdVendorsExistForUser: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("IsDsdVendorsExistForItemForm")]
        public async Task<IHttpActionResult> IsDsdVendorsExistForItemForm(int itemFormId)
        {
            try
            {
                bool retValue = await _commonBO.IsDsdVendorsExistForItemForm(itemFormId);
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.IsDsdVendorsExistForItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("IsFAMCodeExistsInProductGrouping")]
        public async Task<IHttpActionResult> IsFAMCodeExistsInProductGrouping(int itemFormId)
        {
            try
            {
                bool retValue = await _commonBO.IsFAMCodeExistsInProductGrouping(itemFormId);
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.IsFAMCodeExistsInProductGrouping: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetVendorForSearch")]
        public async Task<IHttpActionResult> GetVendorForSearch(VendorDomainDto vendorDomainDto)
        {
            try
            {               
                IEnumerable<VendorDomainDto> vendorDomainDtoList = await _commonBO.GetVendorForSearch(vendorDomainDto);
                return Ok(vendorDomainDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.GetVendorForSearch: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetUserType")]
        public async Task<IHttpActionResult> GetUserType(string userID)
        {

            try
            {
                string result = await _commonBO.GetUserType(userID);
                return Ok(result);

                //TODO: remove this hardcoded 

                //if (userID == "XALP1")
                //{
                //    return Ok("MGR");
                //}
                //else
                //{ return Ok("BUY");
                //}
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.GetUserType: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

        [HttpPost]
        [Route("UpdateItemForm")]
        public async Task<IHttpActionResult> UpdateItemForm(ItemFormDto itemFormDto)
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                itemFormDto.SubmittedUserTypeID = (int)userProfile.userType;
                itemFormDto.CreatedBy = userProfile.CurrentUser;
                itemFormDto.LastUpdatedBy = userProfile.CurrentUser;

                await _commonBO.UpdateItemForm(itemFormDto);
                return Ok(true);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.UpdateItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }



        [HttpGet]
        [Route("GetBasicItemDefinitionGTIN")]
        public async Task<IHttpActionResult> GetBasicItemDefinitionGTIN(int itemFormID)
        {
            try
            {
                var retValue = await _commonBO.GetBasicItemDefinitionGTIN(itemFormID);

                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetBasicItemDefinitionGTIN: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetItemFormErrors")]
        public async Task<IHttpActionResult> GetItemFormErrors(int itemFormID)
        {
            try
            {
                var retValue = await _commonBO.GetItemFormErrors(itemFormID);

                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.GetItemFormErrors: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetItemFormGroup")]
        public async Task<IHttpActionResult> GetItemFormGroup(int itemFormID)
        {
            try
            {
                IEnumerable<ItemFormDto> sameGTINList = await _commonBO.GetItemFormGroup(itemFormID);
                List<ItemFormDto> groupList = new List<ItemFormDto>();
                foreach(ItemFormDto itemForm in sameGTINList)
                {
                    if(itemForm.ID == itemFormID && itemForm.IsInGroup != "Y")
                    {
                        groupList = new List<ItemFormDto>();
                        groupList.Add(itemForm);
                        break;
                    }
                    else if(itemForm.IsInGroup == "Y")
                    {
                        groupList.Add(itemForm);
                    }
                };
              
                return Ok(groupList);
            }
            catch (Exception ex)
            {
                _logger.Error("CommonController.GetItemFormGroup: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        //[HttpPost]
        //[Route("CreateItem")]
        //public async Task<IHttpActionResult> CreateItem(int itemFormID, string createdBy)
        //{
        //    try
        //    {
        //        var retValue = await _commonBO.CreateItem(itemFormID, createdBy);

        //        return Ok(retValue);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error("CommonController.CreateItem: ", ex);
        //        return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
        //    }
        //}

    }
}
