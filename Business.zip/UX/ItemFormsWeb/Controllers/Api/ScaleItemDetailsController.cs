﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using log4net;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using System.Threading.Tasks;
using System.Web.Http;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using System.Net;
using System.Net.Http;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/ScaleItemDetails")]
    public class ScaleItemDetailsController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IScaleItemDetailsBO _scaleItemDetailsBO;
        private ICommonBO _commonBO;
        private ISubmitBO _submitBO;
        // GET: ScaleItemDetails
        public ScaleItemDetailsController(IIdentityService identityService, ILog logger, 
                                    IScaleItemDetailsBO scaleItemDetailsBO,ICommonBO commonBO, ISubmitBO submitBO) : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._scaleItemDetailsBO = scaleItemDetailsBO;
            this._commonBO = commonBO;
            this._submitBO = submitBO;
        }

        [HttpGet]
        [Route("GetScaleLocation")]
        public async Task<IHttpActionResult> GetScaleLocation()
        {
            try
            {
                IEnumerable<LookupFlagDto> result = await _scaleItemDetailsBO.GetScaleLocation();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("ScaleItemDetailsController.GetScaleLocation: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetScaleGrade")]
        public async Task<IHttpActionResult> GetScaleGrade()
        {
            try
            {
                IEnumerable<LookupDto> result = await _scaleItemDetailsBO.GetScaleGrade();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("ScaleItemDetailsController.GetScaleGrade: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetScaleActionCodes")]
        public async Task<IHttpActionResult> GetScaleActionCodes()
        {
            try
            {
                IEnumerable<LookupDto> result = await _scaleItemDetailsBO.GetScaleActionCodes();
                var resultModified = result.Select(x => new { Code = Convert.ToInt32(x.Code), Description = x.Description }).Where(y=>y.Code>=43 && y.Code<=50);
                return Ok(resultModified);
            }
            catch (Exception ex)
            {
                _logger.Error("ScaleItemDetailsController.GetScaleActionCodes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetFacilityGroupByType")]
        public async Task<IHttpActionResult> GetFacilityGroupByType(string Type)
        {
            try
            {
                IEnumerable<LookupDto> result = await _commonBO.GetFacilityGroupByType(Type);
                IEnumerable<LookupDto> resultGroupTypes = await _commonBO.GetFacilityGroupTypes();
                LookupDto resultType = resultGroupTypes.Where(x => x.Code.ToUpper() == Type.ToUpper()).FirstOrDefault();
                IEnumerable<ScaleItemFacilityLookupDto> scaleItemFacilityLookupList = result.Select(x => new ScaleItemFacilityLookupDto(x.Code, x.Description, resultType.Code, resultType.Description));

                return Ok(scaleItemFacilityLookupList);
            }
            catch (Exception ex)
            {
                _logger.Error("ScaleItemDetailsController.GetScaleActionCodes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetFacilityGroupTypes")]
        public async Task<IHttpActionResult> GetFacilityGroupTypes()
        {
            try
            {
                IEnumerable<LookupDto> result = await _commonBO.GetFacilityGroupTypes();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("ScaleItemDetailsController.GetScaleActionCodes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetScaleInfo")]
        public async Task<IHttpActionResult> GetScaleInfo(int itemFormId)
        {
            try
            {
                ScaleInfoDto scaleInfo = await _scaleItemDetailsBO.GetScaleInfo(itemFormId);
                return Ok(scaleInfo);
            }
            catch (Exception ex)
            {
                _logger.Error("ScaleItemDetailsController.GetScaleInfo", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("SaveScaleInfo")]
        public async Task<IHttpActionResult> SaveScaleInfo(ScaleInfoDto scaleItemDetails)
        {
            try
            {
                var sidErrorDto = await _scaleItemDetailsBO.ValidateScaleItemDetails(scaleItemDetails);


                if (sidErrorDto.Errors.Count() > 0 || (sidErrorDto.SubTabValidations.Where(sid => sid.Errors.Count() > 0).FirstOrDefault() != null))
                {
                    return ResponseMessage(
                        Request.CreateResponse(HttpStatusCode.BadRequest, sidErrorDto));
                }

                else
                {
                    UserProfile userProfile = _IdentityService.GetUserProfile();
                    string currentUser = userProfile.CurrentUser;
                    UserType userType = userProfile.userType;
                    scaleItemDetails.CreatedBy = _IdentityService.CurrentUser;
                    scaleItemDetails.ScaleOverrideDescriptionList.ForEach(x => x.CreatedBy = _IdentityService.CurrentUser);
                    scaleItemDetails.ScaleShelfLifeList.ForEach(x => x.CreatedBy = _IdentityService.CurrentUser);
                    scaleItemDetails.ScaleGradeList.ForEach(x => x.CreatedBy = _IdentityService.CurrentUser);
                    scaleItemDetails.ScaleLocationList.ForEach(x => x.CreatedBy = _IdentityService.CurrentUser);
                    bool success = await _scaleItemDetailsBO.SaveScaleInfo(scaleItemDetails);
                    bool _success = await _commonBO.SaveItemFormErrors(sidErrorDto, scaleItemDetails.ItemFormID, _IdentityService.CurrentUser);
                    var itemSaveResponseDTO = new ItemSaveResponseDTO
                    {
                        Status = success,
                        Validation = sidErrorDto
                    };

                    //Submit - validate all tabs. If any error\warning found return bad Request. If no error found , update item form with submit status.
                    if (scaleItemDetails.FormActionID == 3)
                    {
                        var errorsFound = await _submitBO.PerformSubmitValidations(scaleItemDetails.ItemFormID, _IdentityService.CurrentUser, userType);
                        if (errorsFound)
                            return ResponseMessage(
                           Request.CreateResponse(HttpStatusCode.BadRequest));
                    }

                    //TODO: pass formstatusID.
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = scaleItemDetails.ItemFormID;
                   // itemForm.FormStatusID = scaleItemDetails.FormStatusID;
                    itemForm.FormActionID = scaleItemDetails.FormActionID;
                    //itemForm.SubmittedUserTypeID = (int)userType;                
                    itemForm.CreatedBy = currentUser;
                    itemForm.LastUpdatedBy = currentUser;
                    await _commonBO.UpdateItemForm(itemForm);

                    return Ok(itemSaveResponseDTO);
                                        
                }
            }
            catch(Exception ex)
            {
                _logger.Error("ScaleItemDetailsController.SaveScaleInfo", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

    }
}