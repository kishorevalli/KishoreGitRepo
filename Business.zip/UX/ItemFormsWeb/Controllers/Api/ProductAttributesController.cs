﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using log4net;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/ProductAttributes")]
    public class ProductAttributesController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IProductAttributesBO _productAttributesBO;
        private ICommonBO _commonBO;
        private ISubmitBO _submitBO;
        public ProductAttributesController(IIdentityService identityService, ILog logger, IProductAttributesBO productAttributesBO, ICommonBO commonBO, ISubmitBO submitBO) : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._productAttributesBO = productAttributesBO;
            this._commonBO = commonBO;
            this._submitBO = submitBO;
        }



        [HttpGet]
        [Route("GetStates")]
        public async Task<IHttpActionResult> GetStates()
        {
            try
            {
                IEnumerable<StateDto> states = await _productAttributesBO.GetStates();
                return Ok(states);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductAttributesController.GetStates: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetCounties")]
        public async Task<IHttpActionResult> GetCounties(string stateShortName)
        {
            try
            {
                IEnumerable<StateDto> counties = await _productAttributesBO.GetCounties(stateShortName);
                return Ok(counties);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductAttributesController.GetCounties: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpPost]
        [Route("GetCities")]
        public async Task<IHttpActionResult> GetCities(StateDto state)
        {
            try
            {
                IEnumerable<StateDto> cities = await _productAttributesBO.GetCities(state);
                return Ok(cities);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductAttributesController.GetCities: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetFacilityGroupByType")]
        public async Task<IHttpActionResult> GetFacilityGroupByType(string groupType)
        {
            try
            {
                IEnumerable<LookupDto> result = await _commonBO.GetFacilityGroupByType(groupType);


                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductAttributesController.GetFacilityGroupByType: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetFacilityGroupTypes")]
        public async Task<IHttpActionResult> GetFacilityGroupTypes()
        {
            try
            {
                IEnumerable<LookupDto> result = await _commonBO.GetFacilityGroupTypes();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductAttributesController.GetFacilityGroupTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }



        [HttpGet]
        [Route("GetProductAttributes")]
        public async Task<IHttpActionResult> GetProductAttributes(int itemFormID)
        {
            try
            {
                IEnumerable<ProductAttributeDto> result = await _productAttributesBO.GetProductAttributes(itemFormID);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductAttributesController.GetProductAttributes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }


        [HttpGet]
        [Route("GetProductAttributesScopingDetails")]
        public async Task<IHttpActionResult> GetProductAttributesScopingDetails(int itemFormID)
        {
            try
            {
                IEnumerable<ProductAttributeScopingDto> result = await _productAttributesBO.GetProductAttributesScopingDetails(itemFormID);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductAttributesController.GetProductAttributesScopingDetails: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }


        [HttpPost]
        [Route("GetMandatoryAttributes/{ModelGroupCodeType}/{ItemFormID}")]
        // public async Task<IHttpActionResult> GetMandatoryAttributes(int famCode , List<int> rssList , int itemCode)
        public async Task<IHttpActionResult> GetMandatoryAttributes(ProductMandatoryAttributesRequestDto mandatoryAttributesRequest, int modelGroupCodeType, int ItemFormID)
        {
            //ProductMandatoryAttributesRequestDto mandatoryAttributesRequest = new ProductMandatoryAttributesRequestDto();
            //mandatoryAttributesRequest.ItemCode = itemCode;
            //mandatoryAttributesRequest.CurrentFamNo = famCode;

            //List<ItemGroupType> itemGroupTypes = new List<ItemGroupType>();

            //foreach (var rss in rssList)
            //{
            //    ItemGroupType itemGrpType = new ItemGroupType();
            //    itemGrpType.ItemGroupCode = rss;
            //    itemGrpType.ItemGroupTypeCode = "RSS";
            //    itemGroupTypes.Add(itemGrpType);
            //}

            try
            {
                if (modelGroupCodeType != 4 && mandatoryAttributesRequest.ItemCode == null)
                {
                    return Ok(new List<ProductAttributeDto>());
                }
                IEnumerable<ProductAttributeDto> result = await _productAttributesBO.GetMandatoryAttributes(mandatoryAttributesRequest, modelGroupCodeType, ItemFormID);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("ProductAttributesController.GetMandatoryAttributes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpPost]
        [Route("SaveProductAttributes/{ItemFormID}/{FormStatusID:int?}/{FormActionID:int?}")]
        public async Task<IHttpActionResult> SaveProductAttributes(List<ProductAttributeDto> productAttributes, int ItemFormID, int? FormStatusID = null, int? FormActionID = null)
        {
            try
            {
                ItemValidationDTO validationDTO = await _productAttributesBO.ValidateProductAttributes(productAttributes, ItemFormID, FormActionID);

                if (validationDTO.Errors.Count() > 0)
                {
                    return ResponseMessage(
                            Request.CreateResponse(HttpStatusCode.BadRequest, validationDTO));
                }
                else
                {
                    UserProfile userProfile = _IdentityService.GetUserProfile();
                    string currentUser = userProfile.CurrentUser;
                    UserType userType = userProfile.userType;
                    bool returnValue = await _productAttributesBO.SaveProductAttributes(productAttributes, ItemFormID, currentUser); // userType, FormStatusID, FormActionID);
                    bool _success = await _commonBO.SaveItemFormErrors(validationDTO, ItemFormID, currentUser);
                    var itemSaveResponseDTO = new ItemSaveResponseDTO
                    {
                        Status = returnValue,
                        Validation = validationDTO
                    };

                    //Submit - validate all tabs. If any error\warning found return bad Request. If no error found , update item form with submit status.
                    if (FormActionID == 3)
                    {
                        var errorsFound = await _submitBO.PerformSubmitValidations(ItemFormID, _IdentityService.CurrentUser , userType);
                        if (errorsFound)
                            return ResponseMessage(
                           Request.CreateResponse(HttpStatusCode.BadRequest));
                    }

                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = ItemFormID;
                    itemForm.FormStatusID = FormStatusID ?? 0;
                    itemForm.FormActionID = FormActionID ?? 0;
                    //itemForm.SubmittedUserTypeID = (int)userType;                
                    itemForm.CreatedBy = currentUser;
                    itemForm.LastUpdatedBy = currentUser;
                    await _commonBO.UpdateItemForm(itemForm);
                    return Ok(itemSaveResponseDTO);
                }

            }
            catch (Exception ex)
            {
                _logger.Error("ProductGroupingController.SaveProductGrouping", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
    }
}
