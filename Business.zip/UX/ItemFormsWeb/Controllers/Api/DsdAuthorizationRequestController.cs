﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;

using log4net;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/DsdAuthorizationRequest")]
    public class DsdAuthorizationRequestController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IDsdAuthorizationRequestBO _dsdAuthorizationRequestBO;

        public DsdAuthorizationRequestController(IIdentityService identityService, ILog logger, IDsdAuthorizationRequestBO dsdAuthorizationRequestBO)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._dsdAuthorizationRequestBO = dsdAuthorizationRequestBO;
        }

        [HttpGet]
        [Route("GetDsdVendors")]
        public async Task<IHttpActionResult> GetDsdVendors()
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();               
                IEnumerable<VendorDomainDto> vendorList = await _dsdAuthorizationRequestBO.GetDsdVendors(userProfile.CurrentUser, userProfile.GroupName);
                return Ok(vendorList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDsdVendors: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDsdVendorsByUserId")]
        public async Task<IHttpActionResult> GetDsdVendorsByUserId(string userId)
        {
            try
            {               
                IEnumerable<VendorDomainDto> vendorList = await _dsdAuthorizationRequestBO.GetDsdVendors(userId);
                return Ok(vendorList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDsdVendorsByUserId: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetStoresServicedByVendor")]
        public async Task<IHttpActionResult> GetStoresServicedByVendor(int[] vendorNumbers)
        {
            try
            {                
                IEnumerable<VendorServiceDto> vendorServiceList = await _dsdAuthorizationRequestBO.GetStoresServicedByVendor(vendorNumbers);
                return Ok(vendorServiceList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetStoresServicedByVendor: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpPost]
        [Route("SaveDsdVendorStoreAuthorization")]
        public async Task<IHttpActionResult> SaveDsdVendorStoreAuthorization(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            try
            {               
                dsdVendorStoreAuthorizationDto.CreatedBy = _IdentityService.CurrentUser;
             bool returnValue = await _dsdAuthorizationRequestBO.SaveDsdVendorStoreAuthorization(dsdVendorStoreAuthorizationDto);
                return Ok(returnValue);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.SaveDsdVendorStoreAuthorization: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDsdVendorAuthorizations")]
        public async Task<IHttpActionResult> GetDsdVendorAuthorizations(int itemFormID)
        {
            try
            {
                IEnumerable<DsdVendorAuthorizationDto> dsdVendorAuthorizationDtoList = await _dsdAuthorizationRequestBO.GetDsdVendorAuthorizations(itemFormID);
                return Ok(dsdVendorAuthorizationDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDsdVendorAuthorizations: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetAuthorizedDsdVendorsByItemForm")]
        public async Task<IHttpActionResult> GetAuthorizedDsdVendorsByItemForm(int itemFormID)
        {
            try
            {
                IEnumerable<DsdVendorAuthorizationDto> dsdVendorAuthorizationDtoList = await _dsdAuthorizationRequestBO.GetAuthorizedDsdVendorsByItemForm(itemFormID);
                return Ok(dsdVendorAuthorizationDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetAuthorizedDsdVendorsByItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetAuthorizedDsdStatesByItemForm")]
        public async Task<IHttpActionResult> GetAuthorizedDsdStatesByItemForm(int itemFormID)
        {
            try
            {
                IEnumerable<DsdVendorAuthorizationDto> dsdVendorAuthorizationDtoList = await _dsdAuthorizationRequestBO.GetAuthorizedDsdStatesByItemForm(itemFormID);
                return Ok(dsdVendorAuthorizationDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetAuthorizedDsdVendorsByItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetAuthorizedDsdCountiesByItemForm")]
        public async Task<IHttpActionResult> GetAuthorizedDsdCountiesByItemForm(int itemFormID)
        {
            try
            {
                IEnumerable<DsdVendorAuthorizationDto> dsdVendorAuthorizationDtoList = await _dsdAuthorizationRequestBO.GetAuthorizedDsdCountiesByItemForm(itemFormID);
                return Ok(dsdVendorAuthorizationDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetAuthorizedDsdCountiesByItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDsdVendorStoreAuthorizationsByItemForm")]
        public async Task<IHttpActionResult> GetDsdVendorStoreAuthorizationsByItemForm(int itemFormID)
        {
            try
            {
                IEnumerable<DsdAuthRequestStoreDto> dsdVendorAuthorizationDtoList = await _dsdAuthorizationRequestBO.GetDsdVendorStoreAuthorizationsByItemForm(itemFormID);
                return Ok(dsdVendorAuthorizationDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDsdVendorStoreAuthorizationsByItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetDsdVendorStoreAuthorizationsBySearchCriteria")]
        public async Task<IHttpActionResult> GetDsdVendorStoreAuthorizationsBySearchCriteria(VendorServiceDto vendorServiceDto)
        {
            try
            {
                IEnumerable<DsdAuthRequestStoreDto> dsdVendorAuthorizationDtoList = await _dsdAuthorizationRequestBO.GetDsdVendorStoreAuthorizationsBySearchCriteria(vendorServiceDto);
                return Ok(dsdVendorAuthorizationDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDsdVendorStoreAuthorizationsBySearchCriteria: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDsdOverlappedVendorStoreAuthorizationsByItemForm")]
        public async Task<IHttpActionResult> GetDsdOverlappedVendorStoreAuthorizationsByItemForm(int itemFormID)
        {
            try
            {
                IEnumerable<DsdAuthRequestStoreDto> dsdVendorAuthorizationDtoList = await _dsdAuthorizationRequestBO.GetDsdOverlappedVendorStoreAuthorizationsByItemForm(itemFormID);
                return Ok(dsdVendorAuthorizationDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDsdOverlappedVendorStoreAuthorizationsByItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDSDVendorDataForInternalUser")]
        public async Task<IHttpActionResult> GetDSDVendorDataForInternalUser()
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                IEnumerable<VendorDomainDto> vendorDomainDtoList = await _dsdAuthorizationRequestBO.GetDSDVendorDataForInternalUser();
                return Ok(vendorDomainDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDSDVendorDataForInternalUser: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("ValidateAndSaveDsdVendorStoreAuthorization")]
        public async Task<IHttpActionResult> ValidateAndSaveDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList)
        {
            try
            {              
                bool returnValue = await _dsdAuthorizationRequestBO.ValidateAndSaveDsdVendorStoreAuthorization(dsdAuthRequestStoreDtoList, _IdentityService.CurrentUser);
                return Ok(returnValue);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.ValidateAndSaveDsdVendorStoreAuthorization: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("IsOverlappedVendorStoreAuthExistsByItemForm")]
        public async Task<IHttpActionResult> IsOverlappedVendorStoreAuthExistsByItemForm(int itemFormID)
        {
            try
            {
                bool retValue = await _dsdAuthorizationRequestBO.IsOverlappedVendorStoreAuthExistsByItemForm(itemFormID);
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.IsDsdOverlapVendorsExistForItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("IsMultipleDsdVendorsSubmittingSameGtin")]
        public async Task<IHttpActionResult> IsMultipleDsdVendorSubmittingSameGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            try
            {
                bool retValue = await _dsdAuthorizationRequestBO.IsMultipleDsdVendorsSubmittingSameGtin(dsdVendorStoreAuthorizationDto);                
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.IsMultipleDsdVendorSubmittingSameGtin: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("IsOverlappedVendorStoreAuthExistsByGtin")]
        public async Task<IHttpActionResult> IsOverlappedVendorStoreAuthExistsByGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            try
            {
                bool retValue = await _dsdAuthorizationRequestBO.IsOverlappedVendorStoreAuthExistsByGtin(dsdVendorStoreAuthorizationDto);
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.IsOverlappedVendorStoreAuthExistsByGtin: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }



        [HttpGet]
        [Route("GetDsdOverlappedVendorStoreAuthorizationsByGtin")]
        public async Task<IHttpActionResult> GetDsdOverlappedVendorStoreAuthorizationsByGtin(decimal gtin)
        {
            try
            {
                IEnumerable<DsdAuthRequestStoreDto> dsdVendorAuthorizationDtoList = await _dsdAuthorizationRequestBO.GetDsdOverlappedVendorStoreAuthorizationsByGtin(gtin);
                return Ok(dsdVendorAuthorizationDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDsdOverlappedVendorStoreAuthorizationsByGtin: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetBasicItemDefnitionDataByItemCode")]
        public async Task<IHttpActionResult> GetBasicItemDefnitionDataByItemCode(BasicItemDefinitionDto basicItemDefinitionDto)
        {

            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                basicItemDefinitionDto.SubmittedUserTypeID = userProfile.userType;
                basicItemDefinitionDto.CreatedBy = userProfile.CurrentUser;
                basicItemDefinitionDto.LastUpdatedBy = userProfile.CurrentUser;

                var errorList = await _dsdAuthorizationRequestBO.ValidateAndSaveModelItemCodeData(basicItemDefinitionDto);

                if (errorList != null && errorList.Count > 0)
                {
                    return ResponseMessage(
                            Request.CreateResponse(HttpStatusCode.BadRequest, errorList));
                }
                else
                {
                    basicItemDefinitionDto.CreatedBy = _IdentityService.CurrentUser;
                    basicItemDefinitionDto = await _dsdAuthorizationRequestBO.GetBasicItemDefinitionData(basicItemDefinitionDto.ItemFormDisplayId);
                    return Ok(basicItemDefinitionDto);
                }

            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetBasicItemDefnitionDataByItemCode: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }


        }

        [HttpPost]
        [Route("GetBasicItemDefnitionDataByGTIN")]
        public async Task<IHttpActionResult> GetBasicItemDefnitionDataByGTIN(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                basicItemDefinitionDto.SubmittedUserTypeID = userProfile.userType;
                basicItemDefinitionDto.CreatedBy = userProfile.CurrentUser;
                basicItemDefinitionDto.LastUpdatedBy = userProfile.CurrentUser;

                basicItemDefinitionDto = await _dsdAuthorizationRequestBO.GetBasicItemDefnitionDataByGTIN(basicItemDefinitionDto);
                if (basicItemDefinitionDto != null)
                    return Ok(basicItemDefinitionDto);
                else
                    return NotFound();
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetBasicItemDefnitionDataByGTIN: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }


        }
        [HttpGet]
        [Route("GetDsdVendorsExistForItemForm")]
        public async Task<IHttpActionResult> GetDsdVendorsExistForItemForm(int itemFormID)
        {
            
            try
            {
                var result = await _dsdAuthorizationRequestBO.GetDsdVendorsExistForItemForm(itemFormID);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DsdAuthorizationRequestController.GetDsdVendorsExistForItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
    }
}
