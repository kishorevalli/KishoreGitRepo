﻿using log4net;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using System;
using System.Threading.Tasks;
using System.Web.Http;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/MarketingSupport")]
    public class MarketingSupportController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IMarketingSupportBO _marketingSupportBO;
        private ISubmitBO _submitBO;
        protected readonly ICommonBO _commonBo;

        public MarketingSupportController(IIdentityService identityService, ILog logger, IMarketingSupportBO marketingSupportBO, ISubmitBO submitBO , ICommonBO commonBo)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._marketingSupportBO = marketingSupportBO;
            this._submitBO = submitBO;
            this._commonBo = commonBo;
        }

        [HttpGet]
        [Route("GetPromoSupportFrequency")]
        public async Task<IHttpActionResult> GetPromoSupportFrequency()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _marketingSupportBO.GetPromoSupportFrequency();
                return Ok(lookupDtoList);
                
            }
            catch (Exception ex)
            {
                _logger.Error("MarketingSupportController.GetPromoSupportFrequency: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetUnitCostUOM")]
        public async Task<IHttpActionResult> GetUnitCostUOM()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _marketingSupportBO.GetUnitCostUOM();
                return Ok(lookupDtoList);

            }
            catch (Exception ex)
            {
                _logger.Error("MarketingSupportController.GetUnitCostUOM: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetMarketingInfo")]
        public async Task<IHttpActionResult> GetMarketingInfo(int ItemFormID)
        {
            try
            {
                var marketingInfo = await _marketingSupportBO.GetMarketingInfo(ItemFormID);
                if (marketingInfo != null)
                {
                    return Ok(marketingInfo);
                }
                else
                { return NotFound(); }
            }
            catch (Exception ex)
            {
                _logger.Error("MarketingSupportController.GetMarketingInfo", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
       
       
        [HttpPost]
        [Route("SaveMarketingInfo")]
        public async Task<IHttpActionResult> SaveMarketingInfo(MarketingInfoDto marketingInfo)
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                marketingInfo.SubmittedUserTypeID = userProfile.userType;
                marketingInfo.CreatedBy = userProfile.CurrentUser;
                marketingInfo.LastUpdatedBy = userProfile.CurrentUser;
                ItemValidationDTO validationDTO = await _marketingSupportBO.ValidateMarketingInfo(marketingInfo);

                if (validationDTO.Errors.Count() > 0)
                {
                    return ResponseMessage(
                            Request.CreateResponse(HttpStatusCode.BadRequest, validationDTO));
                }
                else
                {
                   if (marketingInfo.SimilarItemGTINList != null && marketingInfo.SimilarItemGTINList.Count > 0)
                    {
                        foreach (var SimilarItemGTIN in marketingInfo.SimilarItemGTINList)
                        {
                            SimilarItemGTIN.CreatedBy = userProfile.CurrentUser;
                            SimilarItemGTIN.LastUpdatedBy = userProfile.CurrentUser;
                        }
                    }
                    bool returnValue = await _marketingSupportBO.SaveMarketingInfo(marketingInfo);
                    bool _success = await _commonBo.SaveItemFormErrors(validationDTO, marketingInfo.ItemFormID, marketingInfo.CreatedBy);
                    var itemSaveResponseDTO = new ItemSaveResponseDTO
                    {
                        Status = returnValue,
                        Validation = validationDTO
                    };

                    //Submit - validate all tabs. If any error\warning found return bad Request. If no error found , update item form with submit status.
                    if (marketingInfo.FormActionID == 3)
                    {
                        var errorsFound = await _submitBO.PerformSubmitValidations(marketingInfo.ItemFormID, _IdentityService.CurrentUser, userProfile.userType);
                        if (errorsFound)
                        {
                            var itemSubmitResponseDTO = new ItemSaveResponseDTO
                            {
                                Status = false,
                                Validation = null
                            };

                            return Ok(itemSubmitResponseDTO);
                        }
                    }

                    //Update ItemForm
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = marketingInfo.ItemFormID;
                    itemForm.FormStatusID = marketingInfo.FormStatusID ?? 0;
                    itemForm.FormActionID = marketingInfo.FormActionID ?? 0;
                    itemForm.SubmittedUserTypeID = (int)marketingInfo.SubmittedUserTypeID;
                    itemForm.CreatedBy = marketingInfo.CreatedBy;
                    itemForm.LastUpdatedBy = marketingInfo.LastUpdatedBy;
                    await _commonBo.UpdateItemForm(itemForm);

                    return Ok(itemSaveResponseDTO);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("MarketingSupportController.SaveMarketingInfo", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetFormComment")]
        public async Task<IHttpActionResult> GetFormComment(int ItemFormID)
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                int UserType = (int)userProfile.userType;
                var formComments = await _marketingSupportBO.GetFormComment(ItemFormID, UserType);
                return Ok(formComments);
            }
            catch (Exception ex)
            {
                _logger.Error("MarketingSupportController.GetFormComment", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpPost]
        [Route("SaveFormComment")]
        public async Task<IHttpActionResult> SaveFormComment(FormCommentDto formComment)
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                formComment.CreatedByUserTypeID = (int)userProfile.userType;
                formComment.CreatedBy = userProfile.CurrentUser;
                bool returnValue = await _marketingSupportBO.SaveFormComment(formComment);
                var itemSaveResponseDTO = new ItemSaveResponseDTO
                {
                    Status = returnValue,
                    Validation = null
                };
                return Ok(itemSaveResponseDTO);
            }
            catch (Exception ex)
            {
                _logger.Error("MarketingSupportController.SaveFormComment", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
    }
}
