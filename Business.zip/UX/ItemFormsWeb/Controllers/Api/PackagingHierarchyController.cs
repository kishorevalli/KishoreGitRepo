﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using log4net;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/PackagingHierarchy")]
    public class PackagingHierarchyController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IPackagingHierarchyBO _packagingHierarchyBO;
        private ISubmitBO _submitBO;
        protected readonly ICommonBO _commonBo;

        public PackagingHierarchyController(IIdentityService identityService, ILog logger, IPackagingHierarchyBO packagingHierarchyBO , ISubmitBO submitBO , ICommonBO commonBo)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._packagingHierarchyBO = packagingHierarchyBO;
            this._submitBO = submitBO;
            this._commonBo = commonBo;
        }


        [HttpGet]
        [Route("GetRetailPackTypesForItemForm")]
        public async Task<IHttpActionResult> GetRetailPackTypesForItemForm(int itemFormID)
        {
            try
            {
                IEnumerable<RetailPackTypeDto> retailPacks = await _packagingHierarchyBO.GetRetailPackTypesForItemForm(itemFormID);
                return Ok(retailPacks);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetRetailPackTypesForItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetCaseCodeTypes")]
        public async Task<IHttpActionResult> GetCaseCodeTypes()
        {
            try
            {
                IEnumerable<CaseCodeTypeDto> caseCodeTypes = await _packagingHierarchyBO.GetCaseCodeTypes();
                return Ok(caseCodeTypes);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetCaseCodeTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetOrderingLevels")]
        public async Task<IHttpActionResult> GetOrderingLevels()
        {
            try
            {
                IEnumerable<OrderingLevelsDto> orderingLevels = await _packagingHierarchyBO.GetOrderingLevels();
                return Ok(orderingLevels);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetOrderingLevels: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetPackagingHierarchies")]
        public async Task<IHttpActionResult> GetPackagingHierarchies(int ItemFormID)
        {
            try
            {
                //var packagingHierarchies = await _packagingHierarchyBO.GetPackagingHierarchies(ItemFormID , _IdentityService.CurrentUser);
                var packagingHierarchies = await _packagingHierarchyBO.GetPackagingHierarchies(ItemFormID);

                if (packagingHierarchies != null)
                {
                    return Ok(packagingHierarchies);
                }
                else
                { return NotFound(); }
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetPackagingHierarchies", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetVendorOrgs")]
        public async Task<IHttpActionResult> GetVendorOrgs()
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();            

                IEnumerable<VendorDomainDto> vendorOrgsList = await _packagingHierarchyBO.GetVendorOrgs(userProfile.CurrentUser, userProfile.GroupName);
                return Ok(vendorOrgsList);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetVendorOrgs: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetVendorOrgsByUserId")]
        public async Task<IHttpActionResult> GetVendorOrgsByUserId(string userId)
        {
            try
            {
                IEnumerable<VendorDomainDto> vendorOrgsList = await _packagingHierarchyBO.GetVendorOrgs(userId);
                return Ok(vendorOrgsList);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetVendorOrgs: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetVendorsDomain")]
        public async Task<IHttpActionResult> GetVendorsDomain()
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                IEnumerable<VendorDomainDto> vendorOrgsList = await _packagingHierarchyBO.GetVendorsDomain(userProfile.CurrentUser, userProfile.GroupName);
                return Ok(vendorOrgsList);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetVendorOrgs: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetVendorsDomainByUserId")]
        public async Task<IHttpActionResult> GetVendorsDomainByUserId(string userId)
        {
            try
            {                
                IEnumerable<VendorDomainDto> vendorOrgsList = await _packagingHierarchyBO.GetVendorsDomain(userId);
                return Ok(vendorOrgsList);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetVendorOrgs: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetVendorsForSelectedOrgs")]
        public async Task<IHttpActionResult> GetVendorsForSelectedOrgs(List<int> selectedOrgs)
        {
            try
            {
                UserProfile userProfile = _IdentityService.GetUserProfile();
                IEnumerable<VendorDomainDto> vendorList = await _packagingHierarchyBO.GetVendorsForSelectedOrgs(selectedOrgs, userProfile.CurrentUser, userProfile.GroupName);
                return Ok(vendorList);
            }

            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetVendorsForSelectedOrgs: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        [HttpGet]
        [Route("GetWarehouses")]
        public async Task<IHttpActionResult> GetWarehouses()
        {
            try
            {
                
                IEnumerable<WarehouseDto> warehouses = await _packagingHierarchyBO.GetWarehouses();
                return Ok(warehouses);
            }

            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetWarehouses: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("IsPrimaryVendorExistsForWHByGtin")]
        public async Task<IHttpActionResult> IsPrimaryVendorExistsForWHByGtin(WarehouseGtinDto warehouseDetails)
        {
            try
            {
                int count = await _packagingHierarchyBO.IsPrimaryVendorExistsForWHByGtin(warehouseDetails);
                return Ok(count);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.IsPrimaryVendorExistsForWHByGtin: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

      

        [HttpPost]
        [Route("SavePackagingHierarchies")]
        public async Task<IHttpActionResult> SavePackagingHierarchies(List<PackagingHierarchyDto> packagingHierarchyList)
        {
            try
            {

               var phErrorDto = await _packagingHierarchyBO.ValidatePackagingHierarchy(packagingHierarchyList);


                if ((phErrorDto.Errors.Count() > 0) || (phErrorDto.SubTabValidations.Where(stv => stv.Errors.Count() > 0).FirstOrDefault() != null))
                {
                    return ResponseMessage(
                        Request.CreateResponse(HttpStatusCode.BadRequest, phErrorDto));
                }
                else
                {
                    UserProfile userProfile = _IdentityService.GetUserProfile();
                    string currentUser = userProfile.CurrentUser;
                    UserType userType = userProfile.userType;
                    packagingHierarchyList.ForEach(ph => ph.CreatedBy = _IdentityService.CurrentUser);
                    bool returnValue = await _packagingHierarchyBO.SavePackagingHierarchies(packagingHierarchyList);
                    bool _success = await _commonBo.SaveItemFormErrors(phErrorDto, packagingHierarchyList.First().ItemFormID, _IdentityService.CurrentUser);
                    var itemSaveResponseDTO = new ItemSaveResponseDTO
                {
                    Status = returnValue,
                    Validation = phErrorDto
                };

                    //Submit - perform all tab validations . 
                    if (packagingHierarchyList.First().FormActionID == 3)
                    {
                        var errorsFound = await _submitBO.PerformSubmitValidations(packagingHierarchyList.First().ItemFormID, _IdentityService.CurrentUser , userType);
                        if (errorsFound)
                        {
                            var itemSubmitResponseDTO = new ItemSaveResponseDTO
                            {
                                Status = false,
                                Validation = null
                            };

                            return Ok(itemSubmitResponseDTO);
                        }
                       
                    }

                    //Update ItemForm
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = packagingHierarchyList.First().ItemFormID;
                    itemForm.FormStatusID = packagingHierarchyList.First().FormStatusID;
                    itemForm.FormActionID = packagingHierarchyList.First().FormActionID;
                    itemForm.SubmittedUserTypeID = (int)packagingHierarchyList.First().SubmittedUserTypeID;
                    itemForm.CreatedBy = packagingHierarchyList.First().CreatedBy;
                    await _commonBo.UpdateItemForm(itemForm);

                    return Ok(itemSaveResponseDTO);

                }

               
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.SavePackagingHierarchies", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
           }
        [HttpGet]
        [Route("GetDsdVendorsExistInDsdForItemForm")]
        public async Task<IHttpActionResult> GetDsdVendorsExistInDsdForItemForm(int itemFormID)
        {
            try
            {

                var DsdVendors = await _packagingHierarchyBO.GetDsdVendorsExistInDsdForItemForm(itemFormID);
                return Ok(DsdVendors);
            }

            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetDsdVendorsExistInDsdForItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


    }
}

