﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Publix.S0VPITEM.ItemFormsEntities;
using log4net;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
//using System.ComponentModel.DataAnnotations;
//using System.Threading;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/BasicItemDefinition")]
    public class BasicItemDefinitionController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IBasicItemDefinitionBO _basicItemDefinitionBO;
        private ISubmitBO _submitBO;
        protected readonly ICommonBO _commonBo;

        public BasicItemDefinitionController(IIdentityService identityService, ILog logger, IBasicItemDefinitionBO basicItemDefinitionBO,ICommonBO commonBo, ISubmitBO submitBO)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._basicItemDefinitionBO = basicItemDefinitionBO;
            this._commonBo = commonBo;
            this._submitBO = submitBO;
        }

        [HttpGet]
        [Route("GetSubmissionReasons")]
        public async Task<IHttpActionResult> GetSubmissionReasons()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _basicItemDefinitionBO.GetSubmissionReasons();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetSubmissionReasons: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetItemCaseTypes")]
        public async Task<IHttpActionResult> GetItemCaseTypes()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _basicItemDefinitionBO.GetItemCaseTypes();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetItemCaseTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetReuseItemCodesBySubDept")]
        public async Task<IHttpActionResult> GetReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto)
        {
            try
            {
                IEnumerable<ReuseItemCodeDto> reUseItemCodeDtoList = await _basicItemDefinitionBO.GetReuseItemCodesBySubDept(reuseItemCodeDto);
                return Ok(reUseItemCodeDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetReuseItemCodesBySubDept: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetAvailableItemFormReuseItemCodesBySubDept")]
        public async Task<IHttpActionResult> GetAvailableItemFormReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto)
        {
            try
            {
                IEnumerable<ReuseItemCodeDto> reUseItemCodeDtoList = await _basicItemDefinitionBO.GetAvailableItemFormReuseItemCodesBySubDept(reuseItemCodeDto);
                return Ok(reUseItemCodeDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetReuseItemCodesBySubDept: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetReuseItemSubDepartments")]
        public async Task<IHttpActionResult> GetReuseItemSubDepartments()
        {
            try
            {                
                IEnumerable<LookupDto> subDepartmentList = await _basicItemDefinitionBO.GetReuseItemSubDepartments();
                return Ok(subDepartmentList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetReuseItemSubDepartments: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("IsSelectedReuseItemCodeAlreadyUsed")]
        public async Task<IHttpActionResult> IsSelectedReuseItemCodeAlreadyUsed(ReuseItemCodeDto reuseItemCodeDto)
        {
            try
            {
                var returnValue = await _basicItemDefinitionBO.IsSelectedReuseItemCodeAlreadyUsed(reuseItemCodeDto);
                return Ok(returnValue);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.IsSelectedReuseItemCodeAlreadyExists: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

        [HttpGet]
        [Route("IsReuseItemCodeExist")]
        public async Task<IHttpActionResult> IsReuseItemCodeExist(int reuseItemCode)
        {
            try
            {
                ReuseItemCodeDto reuseItemCodeDto = await _basicItemDefinitionBO.IsReuseItemCodeExist(reuseItemCode);
                return Ok(reuseItemCodeDto);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.IsReuseItemCodeExist: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("SaveReuseItemCode")]
        public async Task<IHttpActionResult> SaveReuseItemCode(ReuseItemCodeDto reuseItemCodeDto)
        {
            try
            {
                //TODO Inject IdentityService to DAC class
                reuseItemCodeDto.CreatedBy = _IdentityService.CurrentUser;
                reuseItemCodeDto.LastUpdatedBy = _IdentityService.CurrentUser;
                bool returnValue = await _basicItemDefinitionBO.SaveReuseItemCode(reuseItemCodeDto);
                return Ok(returnValue);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.SaveReuseItemCode: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

        [HttpPost]
        [Route("SaveModelDataForPackagingHierarchy")]
        public async Task<IHttpActionResult> SaveModelDataForPackagingHierarchy(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            try
            {
                basicItemDefinitionDto.CreatedBy = _IdentityService.CurrentUser;
                basicItemDefinitionDto.LastUpdatedBy = _IdentityService.CurrentUser;
                

                var status = await _basicItemDefinitionBO.SaveModelDataForPackagingHierarchy(basicItemDefinitionDto);
                return Ok(status);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.SaveReuseItemCode: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetRetailPackTypes")]
        public async Task<IHttpActionResult> GetRetailPackTypes()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _basicItemDefinitionBO.GetRetailPackTypes();            
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetRetailPackTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetUnitOfMeasures")]
        public async Task<IHttpActionResult> GetUnitOfMeasures()
        {
            try
            {
                IEnumerable<LookupDto> lookupDtoList = await _basicItemDefinitionBO.GetUnitOfMeasures();
                return Ok(lookupDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetUnitOfMeasures: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetItemTypes")]
        public async Task<IHttpActionResult> GetItemTypes()
        {
            try
            {
                IEnumerable<ItemTypeDto> itemTypeDtoList = await _basicItemDefinitionBO.GetItemTypes();
                return Ok(itemTypeDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetItemTypes: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        //public class NameFormGroup
        //{
        //    [Required]
        //    [MaxLength(50)]
        //    public string FirstNameCtrl { get; set; }
        //    [Required]
        //    public string LastNameCtrl { get; set; }
        //}
        //[HttpPost]
        //[Route("SaveTest")]
        //public  IHttpActionResult SaveTest(NameFormGroup nameFormGroup)
        //{
        //    Thread.Sleep(300);
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            return Ok("120820170002");

        //        }
        //        else
        //        {
        //            return BadRequest(ModelState);
        //        }
        //    }
        //    catch(Exception ex)
        //    {
        //        _logger.Error("BasicItemDefinitionController.SaveBasicItemDefinition: ", ex);
        //        return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
        //    }

        //}
        [HttpPost]
        [Route("SaveBasicItemDefinition")]
        public async Task<IHttpActionResult> SaveBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            try
            {

                ItemValidationDTO bidValidationDTO = await _basicItemDefinitionBO.ValidateBasicItemDefinition(basicItemDefinitionDto);

                if (bidValidationDTO.Errors.Count() > 0)
                {                 
                    return ResponseMessage(
                            Request.CreateResponse(HttpStatusCode.BadRequest, bidValidationDTO));
                }
                else
                {
                    UserProfile userProfile = _IdentityService.GetUserProfile();
                    basicItemDefinitionDto.CreatedBy = _IdentityService.CurrentUser;
                    UserType userType = userProfile.userType;                    
                    bool returnValue = await _basicItemDefinitionBO.SaveBasicItemDefinition(basicItemDefinitionDto);
                    bool _success = await _commonBo.SaveItemFormErrors(bidValidationDTO, basicItemDefinitionDto.ItemFormID, _IdentityService.CurrentUser);
                    ItemSaveResponseDTO itemSaveResponseDTO = new ItemSaveResponseDTO
                    {
                        Status = returnValue,
                        Validation = bidValidationDTO
                    };


                    //Submit - validate all tabs. If any error\warning found return bad Request. If no error found , update item form with submit status.
                    if (basicItemDefinitionDto.FormActionID == 3)
                    {
                        var errorsFound = await _submitBO.PerformSubmitValidations(basicItemDefinitionDto.ItemFormID, _IdentityService.CurrentUser, userType);
                        if (errorsFound)
                        {
                            var itemSubmitResponseDTO = new ItemSaveResponseDTO
                            {
                                Status = false,
                                Validation = null
                            };

                            return Ok(itemSubmitResponseDTO);
                        }
                    }

                    //Update ItemForm
                    ItemFormDto itemForm = new ItemFormDto();
                    itemForm.ID = basicItemDefinitionDto.ItemFormID;
                    itemForm.FormStatusID = basicItemDefinitionDto.FormStatusID;
                    itemForm.FormActionID = basicItemDefinitionDto.FormActionID;
                    itemForm.SubmittedUserTypeID = (int)basicItemDefinitionDto.SubmittedUserTypeID;
                    itemForm.LastUpdatedBy = basicItemDefinitionDto.LastUpdatedBy;
                    await _commonBo.UpdateItemForm(itemForm);
                    //  }
                    return Ok(itemSaveResponseDTO);


                }

            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.SaveBasicItemDefinition: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
       
        }

        
      
        [HttpGet]
        [Route("GetBasicItemDefinitionData")]
        public async Task<IHttpActionResult> GetBasicItemDefinitionData(int itemFormId)
        {
            try
            {
                BasicItemDefinitionDto basicItemDefinitionDto = await _basicItemDefinitionBO.GetBasicItemDefinitionData(itemFormId);
                return Ok(basicItemDefinitionDto);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetBasicItemDefinitionData: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

            
        }

        [HttpGet]
        [Route("GetItemFormsDisplayIDs")]
        public async Task<IEnumerable<long>> GetItemFormsDisplayIDs(string userId)
        {
            IEnumerable<long> ItemFormsDisplayIDs = await _basicItemDefinitionBO.GetItemFormsDisplayIDs(userId);
            return await Task.FromResult(ItemFormsDisplayIDs);
        }
        [HttpGet]
        [Route("ConvertCompressedUPCToGTIN")]
        public async Task<IHttpActionResult> ConvertCompressedUPCToGTIN(string compressedUPC)
        {
            int compressedUPCInt;

            bool result = Int32.TryParse(compressedUPC, out compressedUPCInt);
            if (result)
            {
                long Gtin = await _basicItemDefinitionBO.ConvertCompressedUPCToGTIN(compressedUPCInt);
                string formatted = String.Format("{0:000-00000-00000}", Gtin);
                return Ok(formatted);
            }
            else
            {
                return BadRequest("check input compressedUPC: " + compressedUPC);
            }
            
        }
        [HttpGet]
        [Route("ConvertPLUToGTIN")]
        public async Task<IHttpActionResult> ConvertPLUToGTIN(string priceLookUp)
        {
            int priceLookUpInt;

            bool result = Int32.TryParse(priceLookUp, out priceLookUpInt);
            if (result)
            {
                long Gtin = await _basicItemDefinitionBO.ConvertPLUToGTIN(priceLookUpInt);
                string formatted = String.Format("{0:000-00000-00000}", Gtin);
                return Ok(formatted);
            }
            else
            {
                return BadRequest("check input priceLookUp: " + priceLookUp);
            }

        }

        //8500000138
        [HttpPost]
        [Route("SaveItemDataByPmdsGTIN")]
        public async Task<IHttpActionResult> SaveItemDataByPmdsGTIN(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            try
            {
                basicItemDefinitionDto.CreatedBy = _IdentityService.CurrentUser;
                basicItemDefinitionDto = await _basicItemDefinitionBO.SaveItemDataByPmdsGTIN(basicItemDefinitionDto);
                if (basicItemDefinitionDto != null)
                    return Ok(basicItemDefinitionDto);
                else
                    return NotFound();
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.SaveItemDataByPmdsGTIN: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

                       
        }

        //17001
        [HttpPost]
        [Route("SaveItemDataByPmdsItemCode")]
        public async Task<IHttpActionResult> SaveItemDataByPmdsItemCode(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            
            try
            {
                var errorList = await _basicItemDefinitionBO.ValidateAndSaveModelItemCodeData(basicItemDefinitionDto);
                
                if (errorList != null && errorList.Count>0)
                {
                    return ResponseMessage(
                            Request.CreateResponse(HttpStatusCode.BadRequest, errorList));
                }
                else
                {
                    basicItemDefinitionDto.CreatedBy = _IdentityService.CurrentUser;
                    basicItemDefinitionDto = await _basicItemDefinitionBO.GetBasicItemDefinitionData(basicItemDefinitionDto.ItemFormID);
                    return Ok(basicItemDefinitionDto);
                }
               
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.SaveItemDataByPmdsItemCode: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

            
        }

        [HttpGet]
        [Route("IsGTINExists")]
        public async Task<IHttpActionResult> IsGTINExists(decimal GTIN)
        {
            try
            {
                var isGTINExists = await _basicItemDefinitionBO.IsGTINExists(GTIN);
                return Ok(isGTINExists);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.IsGTINExists: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
            
        }


        [HttpGet]
        [Route("GetExistingPackagingHierarchies")]
        public async Task<IHttpActionResult> GetExistingPackagingHierarchies(int itemFormID)
        {
            try
            {
                var packagingHierarchies = await _basicItemDefinitionBO.GetExistingPackagingHierarchies(itemFormID);
                return Ok(packagingHierarchies);
            }
            catch (Exception ex)
            {
                _logger.Error("PackagingHierarchyController.GetExistingPackagingHierarchies: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        //[HttpGet]
        //[Route("isGTINExistInPMDS")]
        //public async Task<Boolean> isGTINExistInPMDS(decimal GTIN)
        //{
        //    var isGTINExists = await _basicItemDefinitionBO.isGTINExistInPMDS(GTIN);
        //    return isGTINExists;
        //}


        private ItemFormDto GetItemFormDto()
        {

            ItemFormDto testFormDto = new ItemFormDto
            {
                FormActionID = 1,
                FormTypeID = 1,
                FormStatusID = 1,
                PendingRoleUserTypeID = 1,
                SubmittedUserTypeID = 1,
                SubmissionDate = DateTime.Now.Date,
                CreatedBy = "JM Vendor",
                CreatedDate = DateTime.Now.Date
            };
            return testFormDto;
        }

        private List<AdditionalGTINDto> GetAdditionalGTINs()
        {
            List<AdditionalGTINDto> additionalGTINs = new List<AdditionalGTINDto>();
            AdditionalGTINDto additionalGTIN1 = new AdditionalGTINDto { GTIN = 123456, ExistingGTINIndicator = "N", GTINCheckDigit = 2, RetailPackType = "Y", RetailPackSize = 2,RetailPackTypeDescription ="RPDEsc", SizeUOM = "LB", SizeUOMDescription = "Pounds",CreatedBy="Vijay",CreatedDate=DateTime.Now.Date };
            AdditionalGTINDto additionalGTIN2 = new AdditionalGTINDto { GTIN = 223456, ExistingGTINIndicator = "Y", GTINCheckDigit = 3, RetailPackType = "Y", RetailPackSize = 2, RetailPackTypeDescription = "RPDEsc" , SizeUOM = "KG", SizeUOMDescription = "Kilo", CreatedBy = "Vijay", CreatedDate = DateTime.Now.Date };

            additionalGTINs.Add(additionalGTIN1);
            additionalGTINs.Add(additionalGTIN2);
            return additionalGTINs;

        }
      

        [HttpGet]
        [Route("RemoveItemFormCache/{CacheKey}")]
   
        public Boolean RemoveItemFormCache(String CacheKey)
        {
           return  _basicItemDefinitionBO.RemoveItemFormCache(CacheKey);
          
        }

        [HttpGet]
        [Route("GetModelProductItemValues")]
        public async Task<IHttpActionResult> GetModelProductItemValues(int itemFormID)
        {
            try
            {
                ModelProductItemValueDto modelProductItemValueDto = await _basicItemDefinitionBO.GetModelProductItemValues(itemFormID);
                return Ok(modelProductItemValueDto);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetModelProductItemValues: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }


        }

        [HttpGet]
        [Route("DeleteModelProductItemValues")]
        public async Task<IHttpActionResult> DeleteModelProductItemValues(int itemFormID)
        {
            try
            {
                bool returnValue = await _basicItemDefinitionBO.DeleteModelProductItemValues(itemFormID);
                return Ok(returnValue);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.DeleteModelProductItemValues: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

        [HttpPost]
        [Route("GetItemsMatchingDescription")]
        public async Task<IHttpActionResult> GetItemsMatchingDescription(ItemDescriptionDto itemDescriptionDto)
        {
            try
            {               
                IEnumerable<ItemDescriptionDto> itemDescriptionDtoList = await _basicItemDefinitionBO.GetItemsMatchingDescription(itemDescriptionDto);
                return Ok(itemDescriptionDtoList);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetItemsMatchingDescription: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }

        }

        //[HttpGet]
        //[Route("GetBasicItemDefinitionGTIN")]
        //public async Task<IHttpActionResult> GetBasicItemDefinitionGTIN(int itemFormID)
        //{
        //    try
        //    {
        //        var retValue = await _basicItemDefinitionBO.GetBasicItemDefinitionGTIN(itemFormID);

        //        return Ok(retValue);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error("BasicItemDefinitionController.GetBasicItemDefinitionGTIN: ", ex);
        //        return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
        //    }
        //}
        [HttpGet]
        [Route("GetNutritionalPanelGTIN")]
        public async Task<IHttpActionResult> GetNutritionalPanelGTIN(int itemFormID)
        {
            try
            {
                var retValue = await _basicItemDefinitionBO.GetNutritionalPanelGTIN(itemFormID);
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetNutritionalPanelGTIN: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("RemoveGTINRetailPackRelatedInfo")]
        public async Task<IHttpActionResult> RemoveGTINRetailPackRelatedInfo(GTINRetailPackInfoDto gtinRetailPackInfo)
        {
            try
            {
                var retValue = await _basicItemDefinitionBO.RemoveGTINRetailPackRelatedInfo(gtinRetailPackInfo);
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.RemoveGtinRetailPackRelatedInfo: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpGet]
        [Route("GetPmdsBasicItemDefinitionDetailsByItemID")]
        public async Task<IHttpActionResult> GetPmdsBasicItemDefinitionDetailsByItemID(int ItemCode)
        {
            try
            {
                var retValue = await _basicItemDefinitionBO.GetPmdsBasicItemDefinitionDetailsByItemID(ItemCode);
                return Ok(retValue);
            }
            catch (Exception ex)
            {
                _logger.Error("BasicItemDefinitionController.GetPIDMBasicItemDefinitionDetailsByItemID: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
    }
}
