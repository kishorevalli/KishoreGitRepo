﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using log4net;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsBO.ItemFormSvc;
using System.Web;
using ClosedXML.Extensions;
using ClosedXML.Excel;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/Dashboard")]
    public class DashboardController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;
        private IDashboardBO _dashboardBO;
        private ICategoryReviewBO _categoryReviewBO;

        public DashboardController(IIdentityService identityService, ILog logger, IDashboardBO dashboardBO, ICategoryReviewBO categoryReviewBO)
            : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;
            this._dashboardBO = dashboardBO;
            this._categoryReviewBO = categoryReviewBO;
        }


        [HttpPost]
        [Route("GetItemFormListBySearchCriteria")]
        public async Task<IHttpActionResult> GetItemFormListBySearchCriteria(DashboardSearchCriteriaDto dashboardSearchCriteriaDto)
        {
            try
            {
                //dashboardSearchCriteriaDto.VendorContactID = "PGVU1";
                if (_identity.GetUserProfile().GroupName == "VPMD_VendorPortal_VendorSuperAdmin" && dashboardSearchCriteriaDto.IsIncludeRelatedFromChecked)
                    dashboardSearchCriteriaDto.IncludeVSARelatedForm = true;

                IEnumerable<DashboardItemFormDto> ItemFormList = await _dashboardBO.GetItemFormListBySearchCriteria(dashboardSearchCriteriaDto,_identity.CurrentUser);
                return Ok(ItemFormList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetItemFormListBySearchCriteria: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetItemFormListBySearchCriteriaInternalUser")]
        public async Task<IHttpActionResult> GetItemFormListBySearchCriteriaInternalUser(DashboardSearchCriteriaDto dashboardSearchCriteriaDto)
        {
            try
            {         

                IEnumerable<DashboardItemFormDto> ItemFormList = await _dashboardBO.GetItemFormListBySearchCriteriaInternalUser(dashboardSearchCriteriaDto, _identity.CurrentUser);
                return Ok(ItemFormList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetItemFormListBySearchCriteriaInternalUser: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }



        [HttpPost]
        [Route("GetDashboardStatus")]
        public async Task<IHttpActionResult> GetDashboardStatus(LoggedInUserDto loggedInUser)
        {
            try
            {
                //dashboardStatusDto.UserID = "PGVU1";
                IEnumerable<DashboardStatusDto> ItemFormList = await _dashboardBO.GetDashboardStatus(loggedInUser);
                if (_identity.GetUserProfile().GroupName == "VPMD_VendorPortal_VendorSuperAdmin")
                    ItemFormList.ToList().ForEach(status => status.IsVSALoggedIn = true);
                return Ok(ItemFormList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardStatus: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        

        [HttpPost]
        [Route("GetDashboardStatusCount")]
        public async Task<IHttpActionResult> GetDashboardStatusCount(DashboardStatusDto dashboardStatusDto)
        {
            try
            {
                //dashboardStatusDto.UserID = "PGVU1";
                if (_identity.GetUserProfile().GroupName == "VPMD_VendorPortal_VendorSuperAdmin" && dashboardStatusDto.IsIncludeRelatedFromChecked)
                    dashboardStatusDto.IncludeVSARelatedForm = true;

                int ItemFormList = await _dashboardBO.GetDashboardStatusCount(dashboardStatusDto);
                return Ok(ItemFormList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardStatusCount: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetDashboardStatusCountInternal")]
        public async Task<IHttpActionResult> GetDashboardStatusCountInternal(DashboardStatusDto dashboardStatusDto)
        {
            try
            {
             

                int ItemFormList = await _dashboardBO.GetDashboardStatusCountInternal(dashboardStatusDto);
                return Ok(ItemFormList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardStatusCountInternal: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetDashboardStatusDetail")]
        public async Task<IHttpActionResult> GetDashboardStatusDetail(DashboardStatusDto dashboardStatusDto)
        {
            try
            {
                //dashboardStatusDto.UserID = "PGVU1";
                if (_identity.GetUserProfile().GroupName == "VPMD_VendorPortal_VendorSuperAdmin" && dashboardStatusDto.IsIncludeRelatedFromChecked)
                    dashboardStatusDto.IncludeVSARelatedForm = true;

                IEnumerable<DashboardItemFormDto> ItemFormList = await _dashboardBO.GetDashboardStatusDetail(dashboardStatusDto, _identity.CurrentUser);
                return Ok(ItemFormList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardStatusDetail: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("GetDashboardStatusDetailInternal")]
        public async Task<IHttpActionResult> GetDashboardStatusDetailInternal(DashboardStatusDto dashboardStatusDto)
        {
            try
            {          

                IEnumerable<DashboardItemFormDto> ItemFormList = await _dashboardBO.GetDashboardStatusDetailInternal(dashboardStatusDto, _identity.CurrentUser);
                return Ok(ItemFormList.OrderBy(item=> item.GTIN));
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardStatusDetail: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetFormActionsForItemForm/{CurrentUserTypeID}/{CurrentFormStatusID}")]
        public async Task<IHttpActionResult> GetFormActionsForItemForm(int CurrentUserTypeID, int CurrentFormStatusID)
        {
            try
            {

                IEnumerable<FormUserPermittedActionDto> result = await _dashboardBO.GetFormActionsForItemForm(CurrentUserTypeID, CurrentFormStatusID);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetFormActionsForItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        //


        [HttpGet]
        [Route("GetDashboardFormStatusForVendor")]
        public async Task<IHttpActionResult> GetDashboardFormStatusForVendor()
        {
            try
            {
                //dashboardStatusDto.UserID = "PGVU1";
                IEnumerable<DashboardFormStatusDto> ItemFormList = await _dashboardBO.GetDashboardFormStatusForVendor();
                return Ok(ItemFormList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardFormStatusForVendor: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDashboardFormStatusForBuyer")]
        public async Task<IHttpActionResult> GetDashboardFormStatusForBuyer()
        {
            try
            {
                //dashboardStatusDto.UserID = "PGVU1"; // find the logged in user type and pass it
                IEnumerable<DashboardFormStatusDto> ItemFormList = await _dashboardBO.GetDashboardFormStatusForBuyer(2);
                return Ok(ItemFormList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardFormStatusForVendor: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("UpdateItemFormActionAndCurrentStatusList")]
        public async Task<IHttpActionResult> UpdateItemFormActionAndCurrentStatusList(IEnumerable<FormUserPermittedActionDto> formUserPermittedActionList)
        {
            try
            {
                bool result = await _dashboardBO.UpdateItemFormActionAndCurrentStatusList(formUserPermittedActionList);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.UpdateItemFormActionAndCurrentStatusList: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("UpdateItemFormStatusForInternalUser")]
        public async Task<IHttpActionResult> UpdateItemFormStatusForInternalUser(IEnumerable<FormUserPermittedActionDto> formUserPermittedActionList)
        {
            try
            {
                bool result = await _dashboardBO.UpdateItemFormStatusForInternalUser(formUserPermittedActionList);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.UpdateItemFormStatusForInternalUser: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("UpdateVSARelatedForm")]
        public async Task<IHttpActionResult> UpdateVSARelatedForm()
        {
            try
            {
                bool result = false;
                if (_identity.GetUserProfile().GroupName == "VPMD_VendorPortal_VendorSuperAdmin")
                     result = await _dashboardBO.UpdateVSARelatedForm(_identity.CurrentUser);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.UpdateVSARelatedForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpPost]
        [Route("InsertDashboardUserSelection")]
        public async Task<IHttpActionResult> InsertDashboardUserSelection(DashboardUserSelectionDto dashboardUserSelectionDto)
        {
            try
            {
                if (_identity.GetUserProfile().GroupName == "VPMD_VendorPortal_VendorSuperAdmin")
                    dashboardUserSelectionDto.IsVSAUser = true;
                    bool  result = await _dashboardBO.InsertDashboardUserSelection(dashboardUserSelectionDto);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.InsertDashboardUserSelection: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("AddItemFormToGroup")]
        public async Task<IHttpActionResult> AddItemFormToGroup(int ItemFormID)
        {
            try
            {
                return Ok( await _dashboardBO.AddItemFormToGroup(ItemFormID));               
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.AddItemFormToGroup: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("RemoveItemFormFromGroup")]
        public async Task<IHttpActionResult> RemoveItemFormFromGroup(int ItemFormID)
        {
            try
            {
                return Ok(await _dashboardBO.RemoveItemFormFromGroup(ItemFormID));
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.RemoveItemFormFromGroup: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("ParentingItemForm")]
        public async Task<IHttpActionResult> ParentingItemForm(int ItemFormID)
        {
            try
            {
                return Ok(await _dashboardBO.ParentingItemForm(ItemFormID));
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.ParentingItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("UnParentingItemForm")]
        public async Task<IHttpActionResult> UnParentingItemForm(int ItemFormID)
        {
            try
            {
                return Ok(await _dashboardBO.UnParentingItemForm(ItemFormID));
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.UnParentingItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }


        //Task<bool> AddItemFormToGroup(int ItemFormID);

        [HttpPost]
        [Route("UpdateReassignVendorContact")]
        public async Task<IHttpActionResult> UpdateReassignVendorContact(ViewForUserListDto vendorContact)
        {
            try
            {
           
                bool result = await _dashboardBO.UpdateReassignVendorContact(vendorContact);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.UpdateReassignVendorContact: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

  
        [HttpPost]
        [Route("GetPossibleVendorUserForItemForm")]
        public async Task<IHttpActionResult> GetPossibleVendorUserForItemForm(ViewForUserListDto[] ViewForUserList)
        {
            try
            {
                IEnumerable<ViewForUserListDto> PossibleVendorUserList = await _dashboardBO.GetPossibleVendorUserForItemForm(ViewForUserList);
                return Ok(PossibleVendorUserList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetPossibleVendorUserForItemForm: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDashboardUserSelection")]
        public async Task<IHttpActionResult> GetDashboardUserSelection()
        {
            try
            {
                //dashboardStatusDto.UserID = "PGVU1";
                DashboardUserSelectionDto UserSelection = await _dashboardBO.GetDashboardUserSelection(_identity.CurrentUser);
                return Ok(UserSelection);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardUserSelection: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        //TODO Remove
        //[HttpGet]
        //[Route("GetItemForms")]
        //public async Task<IHttpActionResult> GetItemForms(string userId)
        //{           

        //    try
        //    {
        //        IEnumerable<ItemFormDto> itemFormsList = await _dashboardBO.GetItemForms(userId);
        //        return Ok(itemFormsList);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error("DashboardController.GetItemForms: ", ex);
        //        return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
        //    }
        //}

        [HttpGet]
        [Route("GetDashboardErrorMessageList")]
        public async Task<IHttpActionResult> GetDashboardErrorMessageList(int ItemFormID)
        {

            try
            {
                IEnumerable<ErrorDTO> DashboardErrorMessageList = await _dashboardBO.GetDashboardErrorMessageList(ItemFormID);
                return Ok(DashboardErrorMessageList);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDashboardErrorMessageList: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("ChangeVendorSubmittedFormToReview")]
        public async Task<IHttpActionResult> ChangeVendorSubmittedFormToReview(int ItemFormID)
        {

            try
            {
                bool result = await _dashboardBO.ChangeVendorSubmittedFormToReview(ItemFormID);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.ChangeVendorSubmittedFormToReview: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetDefaultFavouriteForUserType")]
        public async Task<IHttpActionResult> GetDefaultFavouriteForUserType(int UserTypeID)
        {

            try
            {
                DashboardStatusDto result = await _dashboardBO.GetDefaultFavouriteForUserType(UserTypeID);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetDefaultFavouriteForUserType: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetParentStatusForGTIN")]
        public async Task<IHttpActionResult> GetParentStatusForGTIN(decimal GTIN)
        {
            try
            {
                string result = await _dashboardBO.GetParentStatusForGTIN(GTIN);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetParentStatusForGTIN: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetBuyerRelatedUsers")]
        public async Task<IHttpActionResult> GetBuyerRelatedUsers()
        {
            try
            {
                string SessionKey = "GetBuyerRelatedUsers" + _identity.CurrentUser + _identity.GetUserProfile().GroupName;

                if (HttpContext.Current.Application[SessionKey] == null)
                {
                    ItemFormService itemFormsvc = new ItemFormService();
                    HttpContext.Current.Application[SessionKey] = _dashboardBO.GetBuyerRelatedUsers(_identity.CurrentUser, _identity.GetUserProfile().GroupName);
                }
                List<BuyerDTO> result = (List<BuyerDTO>)HttpContext.Current.Application[SessionKey];

               // List<BuyerDTO> result =  _dashboardBO.GetBuyerRelatedUsers(_identity.CurrentUser, _identity.GetUserProfile().GroupName);
                
                return Ok( await Task.FromResult(result.OrderBy(buyer => buyer.UserId)));
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetBuyerRelatedUsers: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }

        [HttpGet]
        [Route("GetVendorRelatedUsers")]
        public async Task<IHttpActionResult> GetVendorRelatedUsers()
        {
            try
            {
                //List<VendorDTO> releatedVendors = new List<VendorDTO>();
                //releatedVendors.Add(new VendorDTO { VendorID = "YBPVSA02", VendorName = " Vendor Super Admin 02" });
                //releatedVendors.Add(new VendorDTO { VendorID = "YBPVU02", VendorName = "Vendor User 02" });

                

                string SessionKey = "GetVendorRelatedUsers" + _identity.CurrentUser + _identity.GetUserProfile().GroupName;              
               
                //return itemFormsvc.GetVendorRelatedUsers(UserId, UserRole).ToList();
                if (HttpContext.Current.Application[SessionKey] == null)
                {
                    ItemFormService itemFormsvc = new ItemFormService();
                    HttpContext.Current.Application[SessionKey] = _dashboardBO.GetVendorRelatedUsers(_identity.CurrentUser, _identity.GetUserProfile().GroupName);
                }
                List<VendorDTO> result = (List<VendorDTO>)HttpContext.Current.Application[SessionKey];


                //List<VendorDTO> result = _dashboardBO.GetVendorRelatedUsers(_identity.CurrentUser, _identity.GetUserProfile().GroupName);

                return Ok(await Task.FromResult(result.OrderBy(vendor => vendor.VendorName)));
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetVendorRelatedUsers: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        //List<VendorDTO> GetVendorRelatedUsers(string UserId, string UserRole)
        [HttpGet]
        [Route("GetCategoryReviewReport")]
        public async Task<IHttpActionResult> GetCategoryReviewReport(int BuyerID)
        {
            try
            {
                var result = await _categoryReviewBO.GetCategoryReviewReport(BuyerID);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error("DashboardController.GetCategoryReviewReport: ", ex);
                return InternalServerError(new Exception("An unexpected server error occurred.  Please try again or notify support."));
            }
        }
        [HttpPost]
        [Route("DownloadCategoryReviewReport")]
        public async Task<HttpResponseMessage> DownloadCategoryReviewReport(List<CategoryReviewDto> CategoryReviewList)
        {
            var wb = await _categoryReviewBO.BuildExcelFile(CategoryReviewList);
            return wb.Deliver("CategoryReviewReport.xlsx");
        }

        [HttpGet]
        [Route("DownloadFile")]
        public async Task<HttpResponseMessage> DownloadFile(int id)
        {
            var wb = await BuildExcelFile(id);
            return wb.Deliver("excelfile.xlsx");
        }

        private async Task<XLWorkbook> BuildExcelFile(int id)
        {
            //Creating the workbook
            var t = Task.Run(() =>
            {
                var wb = new XLWorkbook();
                var ws = wb.AddWorksheet("Sheet1");
                ws.FirstCell().SetValue(id);

                return wb;
            });

            return await t;
        }

    }
}
