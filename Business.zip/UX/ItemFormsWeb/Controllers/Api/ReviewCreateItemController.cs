﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Publix.S0VPITEM.ItemFormsEntities;
using log4net;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;


namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Api
{
    [RoutePrefix("api/ReviewCreateItem")]
    public class ReviewCreateItemController : BaseApiController
    {
        private IIdentityService _identity;
        private ILog _logger;     
        private ISubmitBO _submitBO;
        protected readonly ICommonBO _commonBo;
        public ReviewCreateItemController(IIdentityService identityService, ILog logger,  ICommonBO commonBo, ISubmitBO submitBO) : base(identityService, logger)
        {
            this._identity = identityService;
            this._logger = logger;         
            this._commonBo = commonBo;
            this._submitBO = submitBO;
        }

        [HttpGet]
        [Route("CreateItem")]
        public async Task<IHttpActionResult>  CreateItem(int itemFormId)
        {
            UserProfile userProfile = _IdentityService.GetUserProfile();
            string currentUser = userProfile.CurrentUser;
            UserType userType = userProfile.userType;
            var errorsFound = await _submitBO.PerformSubmitValidations(itemFormId, _IdentityService.CurrentUser, userType);
            var itemSubmitResponseDTO = new ItemSaveResponseDTO();
            if (errorsFound)
            {
                itemSubmitResponseDTO.Status = false;
                itemSubmitResponseDTO.Validation = null;
                return Ok(itemSubmitResponseDTO);
            }
            else
            { //TODO: remove the hardcoded formstatusId and FormActionId
                itemSubmitResponseDTO.Status = true;
                itemSubmitResponseDTO.Validation = null;
                //Update ItemForm
                ItemFormDto itemForm = new ItemFormDto();
                itemForm.ID = itemFormId;
                itemForm.FormStatusID = 11;
                itemForm.FormActionID = 13;
                itemForm.SubmittedUserTypeID = (int)userType;
                itemForm.LastUpdatedBy = currentUser;
                await _commonBo.UpdateItemForm(itemForm);

                //Add the item to ItemForCreation table for the batch job to pick it up.
                //get all the child forms 
                await _commonBo.SubmitItemFormsForCreation(itemFormId, currentUser);

            }
            return Ok(itemSubmitResponseDTO);
        }
    }
}