﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Security
{
    public class UserProfile
    {
        public string CurrentUser { get; set; }
        public UserType userType { get; set; }        
        public bool IsExternal { get; set; }        
        public string GroupName { get; set; }

    }



    public class IdentityService : IIdentityService
    {        
        public IPrincipal CurrentPrincipal
        {
            get
            {
                return System.Threading.Thread.CurrentPrincipal;
            }
        }

        public string CurrentUser
        {
            get
            {
                if (CurrentPrincipal.Identity.IsAuthenticated) return CurrentPrincipal.Identity.Name.ToUpper().Replace("CORP\\", "").ToString();
                else return string.Empty;
                //return @"XCMT";  //hard-coded user for testing
            }
        }

        public UserProfile GetUserProfile()
        {
            return CreatetUserProfile();
        }

        private UserProfile CreatetUserProfile()
        {
            UserProfile user = new UserProfile();
            if (CurrentUser == string.Empty)
                return user;

            user.CurrentUser = CurrentUser;
            var rolesList = GetItemFormsValidRoles();
            foreach (var role in rolesList)
            {
                if (CurrentPrincipal.IsInRole(role.GroupName))
                {
                    user.userType = role.UserType;
                    user.IsExternal = role.IsExternal;
                    user.GroupName = role.GroupName;

                    break;
                }
            }
            return user;
        }

         /// <summary>
        /// groups used to obtain the highest priority group since Site Minder will send multiple groups the user belongs to
        /// </summary>
        /// <returns></returns>
        public static Group[] GetItemFormsValidRoles()
        {
            Group[] validRoles = new Group[] {
                new Group { GroupName = "VPMD_VENDORPORTAL_VENDORSUPERADMIN" , GroupPriority = 0 , UserType = UserType.Vendor , IsExternal = true},
                new Group { GroupName = "VPMD_VENDORPORTAL_VENDORUSERADMIN"  , GroupPriority = 0 , UserType = UserType.Vendor , IsExternal = true},
                new Group { GroupName = "VPMD_VENDORPORTAL_VENDORUSER"       , GroupPriority = 0 , UserType = UserType.Vendor , IsExternal = true},
                new Group { GroupName = "VPMD_VENDORPORTAL_SYSTEMSUPPORT"    , GroupPriority = 0 , UserType = UserType.Support ,IsExternal = false}, //ReadOnly , Allow actions
                new Group { GroupName = "VPMD_VENDORPORTAL_ITEMFORM_CLERICAL", GroupPriority = 1 , UserType = UserType.Clerical , IsExternal = false},
                new Group { GroupName = "VPMD_VENDORPORTAL_ITEMFORM_MFGCLERICAL", GroupPriority = 1 , UserType = UserType.MfgClerical , IsExternal = false},
                new Group { GroupName = "VPMD_VENDORPORTAL_ITEMFORM_MFGBDD", GroupPriority = 2  , UserType = UserType.MfgBDD , IsExternal = false},
                new Group { GroupName = "VPMD_VENDORPORTAL_ITEMFORM_RO", GroupPriority = 3 , UserType = UserType.Buyer , IsExternal = false}, //ReadOnly
                new Group { GroupName = "VPMD_VENDORPORTAL_ITEMFORM_RW", GroupPriority = 4 , UserType = UserType.Buyer , IsExternal = false}
            };
            return validRoles;
        }


     

    }
}

