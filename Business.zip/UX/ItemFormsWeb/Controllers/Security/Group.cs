﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Security
{
    public class Group
    {
        public string GroupName { get; set; }
        public int GroupPriority { get; set; }

        public UserType UserType { get; set; }

        public bool IsExternal { get; set; }
    }
}