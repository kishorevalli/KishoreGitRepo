﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Filters;
using System.Configuration;
using System.Web;
using System.Web.SessionState;
using System.Security.Claims;


namespace Publix.S0VPITEM.ItemFormsWeb.Controllers.Security
{
    public class SiteMinderAuthenticationAttribute : ActionFilterAttribute, IAuthenticationFilter
    {
        static readonly log4net.ILog _logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static readonly string SITEMINDER_HEADER_USER_TOKEN = "iv-user";
        private static readonly string SITEMINDER_HEADER_ROLE_TOKEN = "iv-groups";




        //authenticates the request by validating credentials in the request, if present.
        public Task AuthenticateAsync(HttpAuthenticationContext context, CancellationToken cancellationToken)
        {
            IEnumerable<string> users = new List<string>();
            IEnumerable<string> roles = new List<string>();

            if (HttpContext.Current.Request.Headers[SITEMINDER_HEADER_USER_TOKEN] != null)
            {
                context.Request.Headers.TryGetValues(SITEMINDER_HEADER_USER_TOKEN, out users);
                context.Request.Headers.TryGetValues(SITEMINDER_HEADER_ROLE_TOKEN, out roles);
                //TODO: drive this logging based on flag in db
                _logger.DebugFormat("SITEMINDER_HEADER_USER_TOKEN={0}", string.Join(", ", users));
                _logger.DebugFormat("SITEMINDER_HEADER_ROLE_TOKEN={0}", string.Join(", ", roles));

                var smUser = users.FirstOrDefault();
                var smRoles = string.Join(",", roles);

                if (!string.IsNullOrWhiteSpace(smRoles)) smRoles = smRoles.Replace(@"""", string.Empty).ToUpper();
                string siteMinderRolesString = smRoles;

                string LogMessage = smUser + " has the following Roles " + smRoles;
                //await Task.FromResult(0);
                //   await SiteMinderRolesLog.LogTimTamRolesForUser(LogMessage);  //TODO 

                bool auth = true;
                var user = string.Empty;
                var role = string.Empty;

                if (smUser != null && smUser.Any()) user = smUser;
                else auth = false;

                if (siteMinderRolesString != null && siteMinderRolesString.Any()) role = this.GetRoleByPriority(siteMinderRolesString);
                else auth = false;

                if (auth)
                {
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, user),
                        new Claim(ClaimTypes.Role, role),
                    };

                    ClaimsIdentity identity = new ClaimsIdentity(claims, "SiteMinder");
                    ClaimsPrincipal principal = new ClaimsPrincipal(identity);

                    Thread.CurrentPrincipal = principal;
                    context.Principal = principal;
                }
                else
                {
                    context.ActionContext.Response.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                }
            }
            else
            {


#if DEBUG


                string user = string.Empty;
                string role = string.Empty;

                if (HttpContext.Current.Request.QueryString.Count > 1)
                {
                    user = HttpContext.Current.Request.QueryString["id"];
                    role = HttpContext.Current.Request.QueryString["role"];
                }
                else
                {
                    if (HttpContext.Current.Request.UrlReferrer != null)
                    {
                        string paramStr = HttpContext.Current.Request.UrlReferrer.Query;
                        var paramArr = paramStr.Split('&');

                        if (paramArr.Length > 1)
                        {
                            user = paramArr.First().Split('=').Last();
                            role = paramArr.Last().Split('=').Last();
                        }
                    }
                }

                if (string.IsNullOrWhiteSpace(user))
                {
                    //  this.AccessDenied(app);
                }
                else
                {
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, user),
                        new Claim(ClaimTypes.Role, role),
                    };

                    ClaimsIdentity identity = new ClaimsIdentity(claims, "SiteMinder");
                    ClaimsPrincipal principal = new ClaimsPrincipal(identity);

                    Thread.CurrentPrincipal = principal;
                    context.Principal = principal;
                }
#else

#endif
            }

            return Task.FromResult(0);
        }



        //adds an authentication challenge to the HTTP response, if needed.
        public Task ChallengeAsync(HttpAuthenticationChallengeContext context, CancellationToken cancellationToken)
        {
            context.Result = new ResultWithChallenge(context.Result);
            return Task.FromResult(0);
        }


        public class ResultWithChallenge : IHttpActionResult
        {
            private readonly IHttpActionResult next;
            public ResultWithChallenge(IHttpActionResult next)
            {
                this.next = next;
            }
            public async Task<HttpResponseMessage> ExecuteAsync(
                                        CancellationToken cancellationToken)
            {
                var response = await next.ExecuteAsync(cancellationToken);
                return response;
            }
        }

        #region Private method


        /// <summary>
        /// Gets role by priority.
        /// </summary>
        /// <param name="Roles"></param>
        /// <returns></returns>
        private string GetRoleByPriority(string Roles)
        {
            string groupName = string.Empty;

            try
            {
                var SMRoles = Roles.Split(',');

                var matchRoles = (from tr in SMRoles
                                  join r in IdentityService.GetItemFormsValidRoles() on tr equals r.GroupName
                                  select r).ToArray();

                //if (!matchRoles.Any()) AccessDenied(app);
                if (matchRoles.FirstOrDefault() != null)
                {
                    groupName = matchRoles.FirstOrDefault().GroupName;
                }

            }
            catch (Exception ex)
            {
                _logger.Warn("SiteminderAuthenticationAttribute.GetRoleByPriority", ex);
            }

            _logger.DebugFormat("GetRoleByPriority.GroupName = {0}", groupName);

            return groupName;
        }



        #endregion


    }
}