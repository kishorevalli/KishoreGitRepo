
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { PageNotAuthorizedComponent } from './shared/page-not-authorized.component';

export const routes: Routes = [
    // {

    //     path: 'dashboard',        
    //     loadChildren:'app/dashboard/dashboard.module#DashboardModule'
    // },
    // {
    //     path: 'basicitemdefinition',
    //     loadChildren: 'app/basicitemdefinition/basicitemdefinition.module#BasicitemdefinitionModule'

    // },
    {
        path: 'new-item-form',
        loadChildren: './new-item-form/new-item-form.module#NewItemFormModule'
    },
    {
        path: 'login',        
        component : LoginComponent
    },    
    {  path: 'not-authorized', 
       component: PageNotAuthorizedComponent
    },
];

@NgModule({
 // imports: [RouterModule.forRoot(routes, {useHash: true})],
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
