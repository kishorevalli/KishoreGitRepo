import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import { DashboardComponent } from './dashboard.component';
import { DashboardVendorComponent } from './dashboard-vendor.component';
import { DashboardBuyerComponent } from './dashboard-buyer.component';
import { AuthGuard } from './auth.guard';
import { AuthService } from '../core/services/auth.service';
import { CategoryReviewReportComponent } from './category-review-report/category-review-report.component';


const routes: Routes = [
    {
        path: '',
        component: DashboardComponent,
         canActivate: [AuthGuard],
    },
    {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard],
    },
    {
        path: 'dashboard-vendor',
        component: DashboardVendorComponent,
        canActivate: [AuthGuard],
    },
    {
        path: 'dashboard-buyer',
        component: DashboardBuyerComponent,
        canActivate: [AuthGuard],
    },
    {
        path: 'category-review-report',
        component: CategoryReviewReportComponent,
        canActivate: [AuthGuard],
    },
   
    // {
    //     path: 'dashboard/:id',
    //     component: DashboardComponent
    // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [
    AuthGuard,
    ]
})
export class DashboardRoutingModule { }
