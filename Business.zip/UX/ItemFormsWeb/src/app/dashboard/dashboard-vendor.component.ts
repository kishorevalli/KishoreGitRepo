
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import 'rxjs/add/operator/filter';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { BasicItemDefinitionService } from '../new-item-form/basic-item-definition/basic-item-definition.service';
import { IItemFormDto, ItemFormDto, UserType, IFormUserPermittedActionDto, FormUserPermittedActionDto } from '../new-item-form/new-item-form.interface';
import { DashboardService } from './dashboard.service';
import { IDashboardItemFormDto, DashboardItemFormDto, IDashboardStatusDto, DashboardStatusDto, IDashboardSearchCriteriaDto, DashboardSearchCriteriaDto, IDashboardFormStatusDto, DashboardFormStatusDto, DashboardUserSelectionDto, IDashboardUserSelectionDto, ViewForUserListDto, IViewForUserListDto, LoggedInUserDto, ILoggedInUserDto, VendorDto, IVendorDto} from './dashboard.interface';
import { ILookupDto, LookupDto } from '../shared/common.interface';
import { AuthService } from '../core/services/auth.service';
import { gtinValidator, GtinValidatorOptions, GTINValidatorHelper } from '../new-item-form/common/validators/gtin.validator';
import { GridEvent } from '../shared/grid/grid-event';
import { ReassignVendorcontactComponent } from './reassign-vendorcontact.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, fadeInContent, transformMenu } from '@angular/material';
import * as _moment from 'moment';
const moment = _moment;

@Component({
  selector: 'ifw-dashboard-vendor',
  templateUrl: './dashboard-vendor.component.html',
  styleUrls: ['./dashboard-vendor.component.scss']
})
export class DashboardVendorComponent implements OnInit {

    vendorDashboardFormGroup: FormGroup;
    gtinControlFormGroup: FormGroup;
    gtinHelper: GTINValidatorHelper;
    errors: string[];
    userId: any;
    formErrors: any;
    loading: boolean = false;
    showLoadingSpinner: boolean = false;
    showVendorsLoadingSpinner: boolean = false;
    showGridLoadingSpinner: boolean = false;
    public isBuyer: boolean;
    public ShowIncludeRelatedFormCheckBox: boolean;
    public IsFavouriteSectionClicked: boolean;
    public IsSearchSectionClicked: boolean; 
    public dashboardStatusQueriesID: Number;
    public vendorContactIDSessionDB: string;
    public dashboardStatusName: string;
    public displayResultText: string = "Favorite: Forms in Draft";
    public futureDate: Date;
    public dashboardStatusID: Number;

    //Grid
    public itemFormsRows: IDashboardItemFormDto[];
    public dashboardFormsStatus: IDashboardStatusDto[]
    public dashboardFormsStatusForSearch: IDashboardFormStatusDto[]
    public dashboardUserSelectionDto: DashboardUserSelectionDto
    public data: any[] = [];

    public viewForUserList: ViewForUserListDto[] = [];
    public relatedVendors: VendorDto[] = [];
   
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = true;
    public filterBy: string = "";
    public filterValue: string = "";
    public sortable: boolean = true;
    public active: string = "";
    public direction: string = "";
    public isVSALoggedIn: Boolean;

    constructor(private route: ActivatedRoute,
        private router: Router,
        private formBuilder: FormBuilder,
        private basicItemDefService: BasicItemDefinitionService,
        public dialog: MatDialog,
        private dashboardService: DashboardService,
        public auth: AuthService) { }

    ngOnInit() {
        this.dashboardStatusQueriesID = 41;
        this.isBuyer = false;
        this.futureDate = moment().add(1, "days").toDate();
        this.gtinHelper = new GTINValidatorHelper({}); 
        this.itemFormsRows = [];
        this.pagination = true;


        this.vendorDashboardFormGroup = this.formBuilder.group({
            searchItemCode: '',
            searchItemDescription: '',
            //formattedGtin: ['', [gtinValidator({
            //    validateCheckDigit: false,
            //    range: false,
            //    type2: false,
            //    dummy: false,
            //    vendorCoupon: false,
            //    checkDigitCtrlName: 'searchGTINCheckDigit'
            //})]],
            formattedGtin: [''],
            searchGTINCheckDigit: '',
            searchPLU: '',
            priceLookupCode: '',
            compressedUPC: '',
            searchFormId: '',
            searchOrganization: '',
            searchVendor: '',
            searchSubmittedFromDate: '',
            searchFormStatusId: '',
            searchSubmittedToDate: '',
            specificVendorContactId: '',
            vendorContactID: 0,
            searchFormStatus: [],
            IsIncludeRelatedFormChecked: true,
            dashboardFormsStatus: []
        });
        //this.showLoadingSpinner = true;
        this.showVendorsLoadingSpinner = true;
        this.LoadDashboardUserSelectionFromDBBeforeDropDownLoad();    

        this.dashboardService.getDashboardFormStatusForVendor().subscribe(res => {
            this.dashboardFormsStatusForSearch = res;
        }); 

       
        this.dashboardService.userType = (this.isBuyer) ? UserType.Buyer : UserType.Vendor;

        this.userId = this.auth.currentUser;
        this.isBuyer = !this.auth.isExternal;
        this.dashboardService.userType = (this.isBuyer) ? UserType.Buyer : UserType.Vendor;
        this.loading = true;      
    }

    public getVendorRelatedUser(userSelectionRes:IDashboardUserSelectionDto) {
        this.dashboardService.getVendorRelatedUsers().subscribe(VendorRelatedUsersRes => {
            this.relatedVendors = VendorRelatedUsersRes;
            this.showVendorsLoadingSpinner = false;
            if (userSelectionRes != null && this.relatedVendors.some(vendor => vendor.vendorID == userSelectionRes.vendorContactID))
                this.vendorDashboardFormGroup.patchValue({ vendorContactID: this.vendorContactIDSessionDB });
            else
                this.LoadDashboardUserSelectionFromDBAfterDropDownLoad();
                           
        }, (err) => {
            //this.showLoadingSpinner = false;
        });
    }



    public LoadDashboardUserSelectionFromDBBeforeDropDownLoad() {

        let loggedInUser: LoggedInUserDto = { "loggedInUserID": this.userId, "loggedInUserTypeID": UserType.Vendor.toString() }

        this.dashboardService.getDashboardUserSelection().subscribe(userSelectionRes => {

            this.getVendorRelatedUser(userSelectionRes);

            if (userSelectionRes != null) {
                let intialDBvendor: VendorDto = { vendorID: userSelectionRes.vendorContactID, vendorName: userSelectionRes.vendorContactID, vendorNumber: userSelectionRes.vendorContactID };
                this.relatedVendors.push(intialDBvendor);
                this.vendorDashboardFormGroup.patchValue({ vendorContactID: userSelectionRes.vendorContactID });
                this.vendorContactIDSessionDB = userSelectionRes.vendorContactID;
                this.IsFavouriteSectionClicked = userSelectionRes.isFavouriteClicked;
                this.IsSearchSectionClicked = userSelectionRes.isSearchClicked;
                this.dashboardStatusQueriesID = userSelectionRes.dashboardStatusQueriesID;
                this.dashboardStatusID = userSelectionRes.statusID;

                this.dashboardService.getDashboardStatus(loggedInUser).subscribe(
                    statusres => {
                        this.dashboardFormsStatus = statusres;
                        this.dashboardFormsStatus.forEach(status => {
                            status.userTypeID = UserType.Vendor;
                            status.vendorContactID = userSelectionRes.vendorContactID;
                            if (status.statusID == userSelectionRes.statusID)
                                this.displayResultText = status.status
                            this.dashboardService.getDashboardStatusCount(status).subscribe(res => status.statusCount = res);
                        })
                    });


                if (userSelectionRes.isFavouriteClicked && userSelectionRes.dashboardStatusQueriesID > 0) {
                    this.IsFavouriteSectionClicked = true;
                    let dbStatus: DashboardStatusDto = { "dashboardStatusNameId": userSelectionRes.dashboardStatusQueriesID, "vendorContactID": userSelectionRes.vendorContactID, "statusID": userSelectionRes.statusID }
                    this.dashboardService.getDashboardStatusDetail(dbStatus).subscribe(res => {
                        this.itemFormsRows = res;
                        this.getInitialItemFormData();
                        this.showLoadingSpinner = false;
                    }, (err) => {
                        this.showLoadingSpinner = false;
                    });
                }

                else if (userSelectionRes.isSearchClicked) {


                    let searchCriteria: DashboardSearchCriteriaDto = {
                        "formattedGtin": userSelectionRes.searchGTIN.toString(),
                        "searchGTINCheckDigit": userSelectionRes.searchGTINCheckDigit,
                        "IsIncludeRelatedFromChecked": userSelectionRes.isVSARelatedFormChecked,
                        "isFavouriteClicked": this.IsFavouriteSectionClicked,
                        "searchItemCode": userSelectionRes.searchItemCode,
                        "searchSubmittedFromDate": userSelectionRes.searchSubmittedFromDate,
                        "searchSubmittedToDate": userSelectionRes.searchSubmittedToDate,
                        "compressedUPC": userSelectionRes.compressedUPC,
                        "searchItemDescription": userSelectionRes.searchItemDescription,
                        "priceLookupCode": userSelectionRes.priceLookupCode,
                        "searchFormStatusId": userSelectionRes.searchFormStatusId,
                        "searchFormId": userSelectionRes.searchFormID,
                        // TO DO Get it from Drop down
                        // "organizationId": 1,
                        //"userType": this.vendorDashboardFormGroup.get("userType").value,                        
                        "userType": UserType.Vendor,
                        "viewItemFormsForUserID": userSelectionRes.vendorContactID,
                        searchSelectedOrganization: '',
                        searchSelectedVendors: ' ',
                    }

                    this.vendorDashboardFormGroup.patchValue({
                        formattedGtin: userSelectionRes.searchGTIN,
                        //searchGTINCheckDigit: dashboardUserSelectionDto,
                        IsIncludeRelatedFromChecked: userSelectionRes.isVSARelatedFormChecked,
                        isSearchClicked: userSelectionRes.isSearchClicked,
                        searchItemCode: userSelectionRes.searchItemCode,
                        searchSubmittedFromDate: userSelectionRes.searchSubmittedFromDate,
                        searchSubmittedToDate: userSelectionRes.searchSubmittedToDate,
                        compressedUPC: userSelectionRes.compressedUPC,
                        searchItemDescription: userSelectionRes.searchItemDescription,
                        priceLookupCode: userSelectionRes.priceLookupCode,
                        searchFormStatusId: userSelectionRes.searchFormStatusId,
                        searchFormId: userSelectionRes.searchFormID,
                        //isItemPackagedForRetail: this.basicItemDefinitionDto.retailPackagedItem,
                        //organizationId: dashboardUserSelectionDto.organizationId,
                        userType: UserType.Vendor,
                        vendorContactID: userSelectionRes.vendorContactID,
                        specificVendorContactId: userSelectionRes.vendorNumber
                    });

                    //this.vendorDashboardFormGroup.patchValue({ vendorContactID: userSelectionRes.vendorContactID });

                    this.dashboardService.getItemFormListBySearchCriteria(this.GetCurrentSearchCriteria()).subscribe(res => {
                        this.itemFormsRows = res;
                        this.getInitialItemFormData();
                        this.displayResultText = "Filter Criteria";
                        this.showLoadingSpinner = false;
                    }, (err) => {
                        this.showLoadingSpinner = false;
                    });
                }
            }
        

        });

    }

    public LoadDashboardUserSelectionFromDBAfterDropDownLoad() {
     
                if (this.relatedVendors != undefined) {
                    if (this.relatedVendors.some(vendor => vendor.vendorID == this.userId)) {
                        this.vendorDashboardFormGroup.patchValue({ vendorContactID: this.userId });
                        this.IsSearchSectionClicked = undefined;
                        this.IsFavouriteSectionClicked = undefined
                        this.onVendorContactIDChange(this.userId);
                    }                  
                    else {
                        if (this.relatedVendors[0] != undefined) {
                            let VendorContactID: string = this.relatedVendors[0].vendorID; 
                                               
                        this.IsSearchSectionClicked = undefined;
                        this.IsFavouriteSectionClicked = undefined
                        this.onVendorContactIDChange(VendorContactID);
                            this.vendorDashboardFormGroup.patchValue({ vendorContactID: VendorContactID });
                        }                        
                    }
                }
    }

    public ClearSearchCriteria() {
        this.vendorDashboardFormGroup.patchValue({
            formattedGtin: '',          
            isFavouriteClicked: true,
            searchItemCode: '',
            searchSubmittedFromDate: '',
            searchSubmittedToDate: '',
            compressedUPC: '',
            searchItemDescription: '',
            priceLookupCode: '',
            searchFormStatusId: '',
            searchFormId: '',
            //isItemPackagedForRetail: this.basicItemDefinitionDto.retailPackagedItem,
            organizationId: '',
            userType: UserType.Vendor,      
            specificVendorContactId: ''
        });

    }

    public LoadStatusDetails(dashbordStatusDto: DashboardStatusDto) {

        //this.dashboardService.getDashboardStatus(dashbordStatusDto).subscribe(
        //    res => {
        //        this.dashboardFormsStatus = res;
        //        this.dashboardFormsStatus.forEach(status => {
        //            status.vendorContactID = dashbordStatusDto.vendorContactID;
        //            status.userID = dashbordStatusDto.userID;
        //            status.IsIncludeRelatedFromChecked = dashbordStatusDto.IsIncludeRelatedFromChecked;
        //            status.userTypeID = dashbordStatusDto.userTypeID;
        //            this.isVSALoggedIn = dashbordStatusDto.isVSALoggedIn;
        //            this.dashboardService.getDashboardStatusCount(status).subscribe(res => status.statusCount = res);
        //        })
        //    });

        this.dashboardService.getDashboardStatusDetail(dashbordStatusDto).subscribe(res => {
            this.itemFormsRows = res;
            this.getInitialItemFormData();
            this.showLoadingSpinner = false;
        }); 

    }


    public onIncludeVSARelatedForm(isChecked:boolean) {
        console.log(isChecked);

        if (this.IsFavouriteSectionClicked || this.IsFavouriteSectionClicked == undefined) {
            this.DisplayCurrentSelectedFavourite(this.GetCurrentDashboardStatus());
        }
        else {

            this.dashboardService.getItemFormListBySearchCriteria(this.GetCurrentSearchCriteria()).subscribe(res => {
                this.itemFormsRows = res;
                this.getInitialItemFormData();
                this.showLoadingSpinner = false;
            });
            this.InsertUserSelections();
        }

        // check the selected User type iS VSA  and if checked. and Call the update methods for related forms..
        //After Completion of the above  .Create the current user selection DTO which Add the Include Relation property ..
        // CALL the load method of count and Search details
        // in Uncheck Re contruct the user current selection DTO with checked as false and Call the load method of count and search.
        // Finally call the update of user selection into database.

    }

    public FormatGtin(): void {
        var compositionGTINControl = this.vendorDashboardFormGroup.get("formattedGtin");
        let gtin = compositionGTINControl.value;
        //this.validateShipperItemCompositionByGTIN(gtin.replace(/-/g, ""));
        if (gtin.length > 7) {
            // this.additionalGtinDto.compositionGTIN = this.gtinHelper.padGtin(this.additionalGtinDto.compositionGTIN, 13);
            compositionGTINControl.patchValue(this.gtinHelper.padGtin(gtin, 13));
            this.gtinValidationRules(this.isBuyer);
        }
        this.isGTINValid();

    }

    public onVendorContactIDChange(vendorContactID: string) {
        // Check the Loggin User is VSA id if so check the selected user is matching Logged in USer that means VSA user is View for UserID
        //let IsIncludeRelatedFormChecked: Boolean = this.vendorDashboardFormGroup.get("IsIncludeRelatedFormChecked").value;

        this.showLoadingSpinner = true;
        let dashbordStatusDto: DashboardStatusDto

        this.isVSALoggedIn = true;
        if (this.isVSALoggedIn && (this.userId == vendorContactID)) {
            this.ShowIncludeRelatedFormCheckBox = true;
            this.vendorDashboardFormGroup.patchValue({ "IsIncludeRelatedFormChecked": false });
        }
        else {
            this.ShowIncludeRelatedFormCheckBox = false;
        }
        if (this.IsSearchSectionClicked == undefined && this.IsFavouriteSectionClicked == undefined) {
            this.dashboardService.getDefaultFavouriteForUserType(1).subscribe(res => {
                dashbordStatusDto = res;
                dashbordStatusDto.userTypeID = UserType.Vendor;
                dashbordStatusDto.vendorContactID = vendorContactID;
                this.displayResultText = res.status;
                this.DisplayCurrentSelectedFavourite(dashbordStatusDto);
            });

        }
        else if ((this.IsSearchSectionClicked == undefined || this.IsSearchSectionClicked == false) && this.IsFavouriteSectionClicked) {
            dashbordStatusDto = this.GetCurrentDashboardStatus();
            this.DisplayCurrentSelectedFavourite(dashbordStatusDto);
        }
        else {
            this.dashboardService.getItemFormListBySearchCriteria(this.GetCurrentSearchCriteria()).subscribe(res => {
                this.itemFormsRows = res;
                this.getInitialItemFormData();
                this.showLoadingSpinner = false;
            });
            this.FavouriteRefreshStatusAndCount();

        }
        //this.showLoadingSpinner = false;

        // if the user select to VSA from VU. Display the Check box Include broker forms with default unchecked.
        // if the user moves away from VSA to VU uncheck the checkbox and hide it.
        // No Call will be made to include broker forms in drop down change
        // If fav is Selected Create and Object of Fav and perform 2 task parellay 1. Load the item forms 2. Update the user selection into the table.
        // If Fav is not selected .Create the Search Object and perform 2 task parellay 1. Load the item forms 2. Update the user selection into the table.
        
      
    }

    public GetCurrentDashboardStatus(): DashboardStatusDto {
        let dashbordStatusDto: DashboardStatusDto = {
            "dashboardStatusNameId": this.dashboardStatusQueriesID,
            "statusID": this.dashboardStatusID,
            "IsIncludeRelatedFromChecked": this.vendorDashboardFormGroup.get("IsIncludeRelatedFormChecked").value,
            "isFavouriteClicked": this.IsFavouriteSectionClicked,
            "vendorContactID": this.vendorDashboardFormGroup.get("vendorContactID").value,           
            "userTypeID": UserType.Vendor,
            "isVSALoggedIn": this.isVSALoggedIn
        }
        return dashbordStatusDto;
    }

    public FavouriteRefreshStatusAndCount() {

        let vendorContactID: string = this.vendorDashboardFormGroup.get("vendorContactID").value;
        let loggedInUser: LoggedInUserDto = { "loggedInUserID": this.userId, "loggedInUserTypeID": UserType.Vendor.toString() }
        console.log(this.vendorDashboardFormGroup.get("IsIncludeRelatedFromChecked"))
        this.dashboardService.getDashboardStatus(loggedInUser).subscribe(
            res => {
                this.dashboardFormsStatus = res;
                res.forEach(status => {
                    status.vendorContactID = vendorContactID;
                    status.IsIncludeRelatedFromChecked = false;
                    status.userTypeID = UserType.Vendor;
                    this.isVSALoggedIn = status.isVSALoggedIn;
                    this.dashboardService.getDashboardStatusCount(status).subscribe(res => status.statusCount = res);
                })
            });

    }

    public DisplayCurrentSelectedFavourite(dashbordStatusDto: DashboardStatusDto) {

        this.FavouriteRefreshStatusAndCount();
        this.LoadStatusDetails(dashbordStatusDto);   
    }

    public InsertUserSelections() {

        if (this.IsFavouriteSectionClicked != undefined && this.IsFavouriteSectionClicked) {

            let dashboardUserSelectionFavDto: DashboardUserSelectionDto = {
                "loggedInUserID": this.userId,
                "vendorContactID": this.vendorDashboardFormGroup.get("vendorContactID").value,
                "isFavouriteClicked": this.IsFavouriteSectionClicked,
                "dashboardStatusQueriesID": this.dashboardStatusQueriesID,
                "dashboardStatusName": this.dashboardStatusName,
                "statusID": this.dashboardStatusID
            }
            if (dashboardUserSelectionFavDto.vendorContactID.length > 0)
            this.dashboardService.insertDashboardUserSelection(dashboardUserSelectionFavDto).subscribe(res => console.log(res));
        }       
        else if (this.IsSearchSectionClicked != undefined && this.IsSearchSectionClicked) {
            let dashboardSearchCriteriaDto: DashboardSearchCriteriaDto = this.GetCurrentSearchCriteria();
            
            let intSearchGTIN
            if (dashboardSearchCriteriaDto.formattedGtin != null) {
                intSearchGTIN = +dashboardSearchCriteriaDto.formattedGtin.replace("-", '').replace("-", '');
            }

            let dashboardUserSelectionSearchDto: DashboardUserSelectionDto = {
                "loggedInUserID": this.userId,
                "vendorContactID": this.vendorDashboardFormGroup.get("vendorContactID").value,
                "isVSARelatedFormChecked": this.vendorDashboardFormGroup.get("IsIncludeRelatedFormChecked").value,
                "isVSAUser": this.isVSALoggedIn,
                "isSearchClicked": this.IsSearchSectionClicked,
                "searchGTIN": +dashboardSearchCriteriaDto.formattedGtin,
                "searchItemCode": dashboardSearchCriteriaDto.searchItemCode,
                "searchFormID": dashboardSearchCriteriaDto.searchFormId,
                "searchSubmittedFromDate": dashboardSearchCriteriaDto.searchSubmittedFromDate,
                "searchSubmittedToDate": dashboardSearchCriteriaDto.searchSubmittedToDate,
                "compressedUPC": dashboardSearchCriteriaDto.compressedUPC,
                "searchItemDescription": dashboardSearchCriteriaDto.searchItemDescription,
                "priceLookupCode": dashboardSearchCriteriaDto.priceLookupCode,
                "searchFormStatusId": dashboardSearchCriteriaDto.searchFormStatusId,
                //"organizationId": dashboardSearchCriteriaDto.organizationId,
                //"vendorNumber": dashboardSearchCriteriaDto.specificVendorContactId
            }
            if(dashboardUserSelectionSearchDto.vendorContactID.length > 0)            
            this.dashboardService.insertDashboardUserSelection(dashboardUserSelectionSearchDto).subscribe(res => console.log(res));

        }

    }


    public data$ = new Subject<IFormUserPermittedActionDto[]>();
    public getFormActionsForItemForm(itemform: IDashboardItemFormDto) {
        console.log(itemform);
        var loading: IFormUserPermittedActionDto = new FormUserPermittedActionDto();
        loading.vendorActionName = "Loading..";
        this.data$.next([loading]);
        this.dashboardService.getFormActionsForItemForm(1, itemform.formStatusID).subscribe(res => {
            this.data$.next(res);
        });
    }
    selectrow(formAction: IFormUserPermittedActionDto, row: IDashboardItemFormDto) {
        row.selectedFormActionID = formAction.formActionID;
        row.selectedFormActionName = formAction.vendorActionName;
        row.isSelected = true;
        console.log(formAction);
        console.log(row);
    }
    public onStatusCountClick(status: IDashboardStatusDto) {
        console.log(status);
        this.IsFavouriteSectionClicked = true;
        this.IsSearchSectionClicked = false;
        this.ClearSearchCriteria();
        this.dashboardStatusQueriesID = status.dashboardStatusNameId;       
        this.dashboardStatusID = status.statusID;
        this.displayResultText = " Favourite : " + status.status;
        // Construct a Empty Search criteria of DTO user Selection DTO and persiste in DB.
        this.showGridLoadingSpinner = true;
        this.dashboardService.getDashboardStatusDetail(status).subscribe(res => {
            this.itemFormsRows = res;
            this.getInitialItemFormData();
            this.showGridLoadingSpinner = false;
        }, (err) => {
            this.showGridLoadingSpinner = false;
        });
       
      
        this.InsertUserSelections();

    }

    //public onFormActionGridChange(selectedFormActionId:Number,currentItemForm:DashboardItemFormDto,c) {
    //    console.log(selectedFormActionId);
    //    console.log(currentItemForm);
    //    currentItemForm.isSelected = true;
    //    currentItemForm.selectedFormActionID = selectedFormActionId;
    //    if (selectedFormActionId == -1) {

    //        this.itemFormsRows.forEach(itemform => {
    //            if (itemform.itemFormID != currentItemForm.itemFormID) {
    //                itemform.isSelected = false;
    //                itemform.selectedFormActionID = 0;
    //                //itemform.formActions.forEach(action => action.formActionID = 0);
    //            }
    //        });
    //        //this.getInitialItemFormData();
    //    }
    //    else if (selectedFormActionId == -2) {
    //        console.log(currentItemForm.itemFormID);
    //        this.showPopupValidateForReuseItemCode(this.GetPossibleVendorUserForAssigment(), currentItemForm.itemFormID);


    //        //this.getInitialItemFormData();
    //    }
    //    else {
    //        let AlreadyEdit: boolean = false;
    //        this.itemFormsRows.forEach(itemform => {
    //            if (itemform.selectedFormActionID == -1) {
    //                itemform.selectedFormActionID = 0;
    //                itemform.isSelected = false;
    //            }
    //        });
    //        //this.getInitialItemFormData();

    //    }

     
    //}

    public GetPossibleVendorUserForAssigment(): ViewForUserListDto[] {
        console.log(this.viewForUserList);
        let selectedVendorContactId = this.vendorDashboardFormGroup.get("vendorContactID").value;
        let possibleVendorUserForAssigment: ViewForUserListDto[] = this.viewForUserList.filter(user => user.viewForUserId != selectedVendorContactId);
        return possibleVendorUserForAssigment;
    }

    showPopupValidateForReuseItemCode(vendorContactList: ViewForUserListDto[], CurrentItemFormID:Number) {
       
        let dialogRef = this.dialog.open(ReassignVendorcontactComponent, {
            disableClose: true,            
            width: '500px',
            data: {
                vendorContactList: vendorContactList, itemFormID: CurrentItemFormID
            }
        });

        dialogRef.afterClosed().subscribe(result => {          
            console.log(result);
            this.LoadDashboardUserSelectionFromDBAfterDropDownLoad();
            this.itemFormsRows.forEach(itemform => {
                if (itemform.selectedFormActionID == -2) {
                    itemform.selectedFormActionID = 0;
                    itemform.isSelected = false;
                }
            });
        });
    }

    public GetCurrentSearchCriteria(): DashboardSearchCriteriaDto {
        let searchCriteria: DashboardSearchCriteriaDto = {
            "formattedGtin": this.vendorDashboardFormGroup.get("formattedGtin").value,
            "searchGTINCheckDigit": this.vendorDashboardFormGroup.get("searchGTINCheckDigit").value,
            "IsIncludeRelatedFromChecked": this.vendorDashboardFormGroup.get("IsIncludeRelatedFormChecked").value,
            "isFavouriteClicked": this.IsFavouriteSectionClicked,
            "searchItemCode": this.vendorDashboardFormGroup.get("searchItemCode").value,
            "searchSubmittedFromDate": this.vendorDashboardFormGroup.get("searchSubmittedFromDate").value,
            "compressedUPC": this.vendorDashboardFormGroup.get("compressedUPC").value,
            "searchItemDescription": this.vendorDashboardFormGroup.get("searchItemDescription").value,
            "searchSubmittedToDate": this.vendorDashboardFormGroup.get("searchSubmittedToDate").value,
            "priceLookupCode": this.vendorDashboardFormGroup.get("priceLookupCode").value,
            "searchFormStatusId": this.vendorDashboardFormGroup.get("searchFormStatusId").value,
            "searchFormId": this.vendorDashboardFormGroup.get("searchFormId").value,
            "searchSelectedOrganization": '',
            "searchSelectedVendors": ' ',
            // TO DO Get it from Drop down
           // "organizationId": 1,
            //"userType": this.vendorDashboardFormGroup.get("userType").value,
            "vendorContactID": this.vendorDashboardFormGroup.get("vendorContactID").value,
            "userType": UserType.Vendor,
            //"vendorContactID": this.vendorDashboardFormGroup.get("vendorContactID").value,
           // "specificVendorContactId": this.vendorDashboardFormGroup.get("specificVendorContactId").value
        }
        return searchCriteria;

    }

    public onSearchCriteriaClick() {
      
        let searchCriteria: DashboardSearchCriteriaDto = this.GetCurrentSearchCriteria();
        // Create a Empty Formstatus DTO of User Selection DTO and persists in DB.
        this.showGridLoadingSpinner = true;
        this.dashboardStatusID = 0;
        this.dashboardService.getItemFormListBySearchCriteria(searchCriteria).subscribe(res => {
            this.itemFormsRows = res;
            this.getInitialItemFormData();
            this.showGridLoadingSpinner = false;
        });
        this.IsFavouriteSectionClicked = false;
        this.IsSearchSectionClicked = true;
        this.displayResultText = " Filter Criteria";      
        this.InsertUserSelections();
    }



    public clearEnteredGtin(e): void {
        this.vendorDashboardFormGroup.controls.searchGTINCheckDigit.setValue(null);
    }


    //public changeGTINCheckdigit(): void {
    //    //let gtin = this.additionalGtinDto.compositionGTIN;
    //    let gtin = this.vendorDashboardFormGroup.controls.formattedGtin.value;
    //    if (gtin.length > 7) {
    //        this.vendorDashboardFormGroup.controls.formattedGtin.markAsTouched({ onlySelf: true });
    //        this.gtinValidationRules(this.isBuyer);
    //    }
    //    this.isGTINValid();
    //    //this.validateShipperItemCompositionByGTIN(gtin.replace(/-/g, ""));
    //}
    public isGTINValid() {
        const formattedGtin = this.vendorDashboardFormGroup.controls.formattedGtin;
        if (formattedGtin.status == "VALID") {
            console.log("IsGTINExists" + formattedGtin.value);
            //this.IsGTINExists();
        }
    }
    private gtinValidationRules(isBuyer: boolean) {
        const formattedGtin = this.vendorDashboardFormGroup.controls.formattedGtin;
        formattedGtin.setValidators([gtinValidator({
            validateCheckDigit: false,
            range: true,
            type2: !isBuyer,
            dummy: true,
            vendorCoupon: true,
            //checkDigitCtrlName: 'searchGTINCheckDigit'
        })]);
        formattedGtin.updateValueAndValidity();
    }


    getErrorMessage(control: FormControl, name: string) {
        for (let propertyName in control.errors) {
            if (control.errors.hasOwnProperty(propertyName) && control.touched) {
                return this.getValidatorErrorMessage(propertyName, control.errors[propertyName]);
            }
        }
        return null;
    }

    getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            'required': 'This field is required.',
            'email': 'This is not a valid email',
            'invalid': 'This is not a valid value',
            'minlength': `This field should have atleast ${validatorValue.requiredLength} characters`,
            'beforePadding': 'This field is required.',
            'range': 'GTIN entered must be in range 000-00010-00000 to 999-99999-99999.',
            'type2': "GTIN entered is reserved for type -2 GTIN's.",
            'dummy': "GTIN entered is reserved for Dummy GTIN's.",
            'vendorCoupon': "GTIN entered is reserved for Vendor Coupons.",            
            'pmdsinvalid': 'Item GTIN is not valid for the Created By  vendor user ',
            'CompositionGTINAlreadyExist': 'GTIN Already Exist',
            'CompositionGTINInvalidSubDept': 'Item does not match the existing Sub Department',
            'CompositionGTINInvalidItemType': 'GTIN does not match the existing Item Type',
            'CompositionItemCodeAlreadyExist': 'Item Code Already Exist',
            'CompositionItemCodeInvalidSubDept': 'Item does not match the existing Sub Department',
            'CompositionItemCodeInvalidItemType': 'Item does not match the existing Item Type'
        };
        return config[validatorName];
    }

    public ConvertPLUToGTIN(newValue) {
        //console.log(newValue);
        this.vendorDashboardFormGroup.patchValue({
            "formattedGtin": '',
            "searchGTINCheckDigit": null
        });
       
        if (newValue && newValue.length == 5) {
            let newValueTwoChar: string = newValue.slice(0, 2);
            if (newValueTwoChar != "83" && newValueTwoChar != "84" && newValueTwoChar != "93" && newValueTwoChar != "94") {
                this.vendorDashboardFormGroup.controls["priceLookupCode"].setErrors({ notvalid: true });
                this.vendorDashboardFormGroup.controls["priceLookupCode"].markAsTouched({ onlySelf: true });
                return;
            }
            this.basicItemDefService.ConvertPLUToGTIN(newValue).subscribe(res => {
                const formattedGtinControl = this.vendorDashboardFormGroup.controls.formattedGtin;
                formattedGtinControl.setValidators([]);
                this.vendorDashboardFormGroup.patchValue({
                    "formattedGtin": res,
                    "searchGTINCheckDigit": null
                });
               
                //this.basicItemDefinitionDto.formattedGtin = res;
                //this.basicItemDefinitionDto.searchGTINCheckDigit = null;
                //this.basicItemDefinitionDto.compressedUPC = '';
                //this.buyerBasicGtinFormGroup.get("searchGTINCheckDigit").disable();
                this.isGTINValid();
            });
            //this.showBuyerItemDetails();
        }
    }

    public ConvertCompressedUPCToGTIN(newValue) {
        this.vendorDashboardFormGroup.patchValue({
            "formattedGtin": '',
            "searchGTINCheckDigit": null
        });
        this.vendorDashboardFormGroup.controls.priceLookupCode.setValue("");
        //console.log(newValue);
        if (newValue && newValue.length == 6) {
            this.basicItemDefService.ConvertCompressedUPCToGTIN(newValue).subscribe(res => {
                const formattedGtinControl = this.vendorDashboardFormGroup.controls.formattedGtin;
                formattedGtinControl.setValidators([]);
                this.vendorDashboardFormGroup.get("searchGTINCheckDigit").enable();
                this.vendorDashboardFormGroup.patchValue({
                    "formattedGtin": res,
                    "searchGTINCheckDigit": this.gtinHelper.getCheckdigit(res)
                });
                this.vendorDashboardFormGroup.controls.priceLookupCode.setValue("");
                //this.basicItemDefinitionDto.formattedGtin = res;
                //this.basicItemDefinitionDto.gtinCheckDigit = this.vendorDashboardFormGroup.controls.gtinCheckDigit.value;
                //this.basicItemDefinitionDto.priceLookupCode = '';
                this.isGTINValid();
            });
            //this.showBuyerItemDetails();

        }
    }



    getItemFormData(gridEvent: GridEvent) {
        //this.gridData = this.performFilter(gridEvent);
        this.data = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }
    getInitialItemFormData() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getItemFormData(gridEvent);
    }
    /**
  * return the filtered or shallow copy without changing the original data
  */
    performFilter(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.itemFormsRows.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.itemFormsRows.slice();
        }
        return this.itemFormsRows.slice();
    }
    /**
     * sort the filtered result based on sort column and order
     */
    sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.data.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.data.reverse();
        }
    }
    /**
       * paginate the result set
       */
    pageData(gridEvent: GridEvent) {
        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.data.length;
        let pageIndex = gridEvent.pageIndex;
        let offset = pageIndex * this.pageSize;
        this.data = this.data.slice(offset, offset + this.pageSize);
    }

    onSubmitClick() {

        let selectedItemForms:IDashboardItemFormDto[] = this.itemFormsRows.filter(item => item.isSelected == true);
        console.log(selectedItemForms);
        let selectedFormActions: FormUserPermittedActionDto[];
        selectedFormActions = [];

        console.log(selectedItemForms);

        if (selectedItemForms.some(form => form.selectedFormActionID == -1)) {
            this.viewItemForm(selectedItemForms[0]);
        }
        else {

            selectedItemForms.forEach(item => {
                let formAction = new FormUserPermittedActionDto();
                formAction.itemFormID = item.itemFormID;
                formAction.formActionID = item.selectedFormActionID;
                formAction.lastUpdatedBy = item.lastUpdatedBy;
                selectedFormActions.push(formAction);
            });


            this.dashboardService.updateItemFormActionAndCurrentStatusList(selectedFormActions).subscribe(res => {
                console.log(res);
                this.LoadDashboardUserSelectionFromDBAfterDropDownLoad();
            });
            //this.CreateFormAndLoadInitialData(this.userId);
        }   
        

    }

    newItemForm(): any {
        

        this.showLoadingSpinner = true;
        let routeDecider = (this.isBuyer) ? "buyer" : "vendor";
        let itemFormDto = new ItemFormDto();
        itemFormDto.createdBy = this.userId;
        itemFormDto.vendorContactID = this.vendorDashboardFormGroup.get("vendorContactID").value;
        itemFormDto.vendorContactName = this.getViewForUserText(itemFormDto.vendorContactID);
        itemFormDto.lastUpdatedBy = this.userId;
        itemFormDto.formTypeID = 1;
        itemFormDto.formStatusID = (this.isBuyer) ? 5 : 1;
        itemFormDto.submittedUserTypeID = (this.isBuyer) ? 2 : 1;
        this.dashboardService.saveItemForm(itemFormDto).subscribe(res => {
            if (res) {
                //this.itemFormDto = res;
                console.log("Item Form Display ID");
                console.log(itemFormDto.itemFormDisplayID);
                //Storing the itemFormDisplayID in the service 
                this.dashboardService.setItemFormDisplayID(res.itemFormDisplayID, res.id);

                this.router.navigate(['/new-item-form/' + routeDecider], { queryParamsHandling: "merge" });
                //    this.newItemFormService.setFormUserDetails(this.itemFormDto.submittedUserTypeID, this.itemFormDto.formStatusID, this.itemFormDto.formTypeID);
            }
            else {
                console.log('Item Form Save Error');
                this.showLoadingSpinner = false;
            }
        },
            (err) => {
                console.log(err);
                this.showLoadingSpinner = false;
            });

    }

    private getViewForUserText(VendorID): string {        

        if (this.relatedVendors != undefined && this.relatedVendors) {
            let selectedVendor: IVendorDto = this.relatedVendors.find(x => x.vendorID == VendorID);
            if (selectedVendor != undefined)
                return selectedVendor.vendorName;
        }
    }

    //openItemForm(selected: number): any {
    //    this.showSpinner = true;
    //    let routeDecider =  (this.isBuyer)? "buyer":"vendor";
    //    this.dashboardService.setItemFormDisplayID(selected, null);
    //    this.router.navigate(['/new-item-form/'+routeDecider], { queryParamsHandling: "merge" });
    //}

    onDsdAuthRequestMaintenanceClick(): any {
        this.showLoadingSpinner = true;
        let routeDecider = (this.isBuyer) ? "buyer" : "vendor";
        //this.router.navigate(['/new-item-form/' + routeDecider + '/dsd-basic-item-definition'], { queryParamsHandling: "merge" });

        let itemFormDto = new ItemFormDto();
        itemFormDto.createdBy = this.userId;
        itemFormDto.vendorContactID = this.userId;
        itemFormDto.lastUpdatedBy = this.userId;
        itemFormDto.formTypeID = 3;
        itemFormDto.formStatusID = (this.isBuyer) ? 5 : 1;
        itemFormDto.submittedUserTypeID = (this.isBuyer) ? 2 : 1;
        this.dashboardService.saveItemForm(itemFormDto).subscribe(res => {
            if (res) {
                //this.itemFormDto = res;
                console.log("Item Form Display ID");
                console.log(itemFormDto.itemFormDisplayID);
                //Storing the itemFormDisplayID in the service 
                this.dashboardService.setItemFormDisplayID(res.itemFormDisplayID, res.id);
                this.router.navigate(['/new-item-form/' + routeDecider + '/dsd-authorization-request'], { queryParamsHandling: "merge" });

            }
            else {
                console.log('Item Form Save Error');
                this.showLoadingSpinner = false;
            }
        },
            (err) => {
                console.log(err);
                this.showLoadingSpinner = false;
            });
    }

    viewItemForm(selectedForm: DashboardItemFormDto): any {
        console.log(selectedForm);

        this.showLoadingSpinner = true;
        let routeDecider = (this.isBuyer) ? "buyer" : "vendor";
        this.dashboardService.setItemFormDisplayID(+selectedForm.itemFormDisplayID, null);
        if (selectedForm.formTypeID == 3) {
            this.router.navigate(['/new-item-form/' + routeDecider + '/dsd-authorization-request'], { queryParamsHandling: "merge" });
        }
        else {
            this.router.navigate(['/new-item-form/' + routeDecider], { queryParamsHandling: "merge" });
        }

    }

 


}
