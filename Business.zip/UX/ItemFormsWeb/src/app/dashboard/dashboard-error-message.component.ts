
import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatPaginatorModule, MatSort, MatPaginator } from '@angular/material';
import { GridEvent } from '../shared/grid/grid-event';
import { IErrorDTO, ErrorDTO } from '../shared/common.interface';
import { DashboardService } from './dashboard.service';


@Component({
  selector: 'ifw-dashboard-error-message',
  templateUrl: './dashboard-error-message.component.html',
  styleUrls: ['./dashboard-error-message.component.scss']
})
export class DashboardErrorMessageComponent implements OnInit {

    public gridData: any[] = [];
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 5;
    public filterable: boolean = true;
    public filterBy: string = "";
    public filterValue: string = "";
    public sortable: boolean = true;
    public active: string = "";
    public direction: string = "";
    public ShowReuseItemCodeGrid = false;

    public ItemFormID: number;
    errorMessageList: IErrorDTO[];



    constructor(public dialogRef: MatDialogRef<DashboardErrorMessageComponent>,
        private fb: FormBuilder,   
        private dashboardService: DashboardService,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) {

    }

    ngOnInit() {
        //this.ItemFormID = this.data.itemFormID;
        this.sortable = true;
        this.filterable = true;
        this.pagination = true;
        this.dashboardService.getDashboardErrorMessageList(this.data.ClickedItemFormID).subscribe(res => {
            this.errorMessageList = res;
            this.getInitialErrorMessageList();
        });
    }

    closeDialog() {
        this.dialog.closeAll();
    }


    getErrorMessageList(gridEvent: GridEvent) {
        this.gridData = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }
  

    performFilter(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.errorMessageList.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.errorMessageList.slice();
        }
        return this.errorMessageList.slice();
    }
    /**
     * sort the filtered result based on sort column and order
     */
    sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }
    /**
       * paginate the result set
       */
    pageData(gridEvent: GridEvent) {
        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

    getInitialErrorMessageList() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 5,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getErrorMessageList(gridEvent);
    }

}
