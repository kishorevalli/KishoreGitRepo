import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import 'rxjs/add/operator/filter';
import { BasicItemDefinitionService } from '../new-item-form/basic-item-definition/basic-item-definition.service';
import { IItemFormDto, ItemFormDto, UserType} from '../new-item-form/new-item-form.interface';
import { DashboardService } from './dashboard.service';
import { ILookupDto, LookupDto } from '../shared/common.interface';
import { AuthService } from '../core/services/auth.service';


@Component({
    selector: 'ifw-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {

    userId: string;
    role: string;
    isBuyer: boolean;
    isMfg: boolean;
    selectedForm: number;
    loading: boolean = false;
    showSpinner: boolean = false;
    public itemFormIds: ILookupDto[];
    public itemForms: IItemFormDto[];

    constructor(private route: ActivatedRoute,
        private router: Router,
        private basicItemDefService: BasicItemDefinitionService,
        private dashboardService: DashboardService,
        private auth: AuthService) { }

    ngOnInit() {
        /*this.route.queryParams
            .filter(params => params.id, params => params.role)
            .subscribe(params => {
                //   console.log(params); //  {id: "PGVSA1", role: "VPMD_VENDORPORTAL_VENDORSUPERADMIN"}
                this.userId = params.id;
                this.role = params.role;
                //console.log(this.userId); // PGVSA1
                if (this.role == 'VPMD_VENDORPORTAL_ITEMFORM_RW') { this.isBuyer = true; }
                else { this.isBuyer = false; }
                this.dashboardService.userType = (this.isBuyer) ? UserType.Buyer : UserType.Vendor;
        });*/
        this.userId = this.auth.currentUser;
        this.isBuyer = !this.auth.isExternal;
        this.isMfg = (this.auth.userType == 4 || this.auth.userType == 5);
        this.dashboardService.userType = (this.isBuyer) ? UserType.Buyer : UserType.Vendor;
        this.loading = true;
        //this.basicItemDefService.GetItemFormsDisplayIDs(this.userId).subscribe(res => {
        //    this.loading = false;
        //    this.itemFormIds = res;
        //});   

        //this.dashboardService.getItemForms(this.userId).subscribe(res => {
        //    this.loading = false;
        //    this.itemForms = res;
        //}); 
       
    }

    newItemForm(): any {
        this.showSpinner = true;
        let routeDecider =  (this.isBuyer ? (this.isMfg ?"mfg": "buyer") :"vendor");
        let itemFormDto = new ItemFormDto();
        itemFormDto.createdBy = this.userId;
        itemFormDto.vendorContactID = this.userId;
        itemFormDto.lastUpdatedBy = this.userId;
        itemFormDto.formTypeID = 1;
        itemFormDto.formStatusID = (this.isBuyer) ? 5 : 1;
        itemFormDto.submittedUserTypeID = (this.isBuyer)? 2 : 1;
        this.dashboardService.saveItemForm(itemFormDto).subscribe(res => {
            if (res) {
                //this.itemFormDto = res;
                console.log("Item Form Display ID");
                console.log(itemFormDto.itemFormDisplayID);
                //Storing the itemFormDisplayID in the service 
                this.dashboardService.setItemFormDisplayID(res.itemFormDisplayID, res.id);
                
                this.router.navigate(['/new-item-form/'+routeDecider], { queryParamsHandling: "merge" });
            //    this.newItemFormService.setFormUserDetails(this.itemFormDto.submittedUserTypeID, this.itemFormDto.formStatusID, this.itemFormDto.formTypeID);
            }
            else {
                console.log('Item Form Save Error');
                this.showSpinner = false;
            }
            },
            (err) => {
                console.log(err);
                this.showSpinner = false;
            });
       
    }

    //openItemForm(selected: number): any {
    //    this.showSpinner = true;
    //    let routeDecider =  (this.isBuyer)? "buyer":"vendor";
    //    this.dashboardService.setItemFormDisplayID(selected, null);
    //    this.router.navigate(['/new-item-form/'+routeDecider], { queryParamsHandling: "merge" });
    //}

    onDsdAuthRequestMaintenanceClick(): any {
        this.showSpinner = true;
        let routeDecider =  (this.isBuyer ? (this.isMfg ?"mfg": "buyer") :"vendor");    
        //this.router.navigate(['/new-item-form/' + routeDecider + '/dsd-basic-item-definition'], { queryParamsHandling: "merge" });

        let itemFormDto = new ItemFormDto();
        itemFormDto.createdBy = this.userId;
        itemFormDto.vendorContactID = this.userId;
        itemFormDto.lastUpdatedBy = this.userId;
        itemFormDto.formTypeID = 3;
        itemFormDto.formStatusID = (this.isBuyer) ? 5 : 1;
        itemFormDto.submittedUserTypeID = (this.isBuyer) ? 2 : 1;
        this.dashboardService.saveItemForm(itemFormDto).subscribe(res => {
            if (res) {
                //this.itemFormDto = res;
                console.log("Item Form Display ID");
                console.log(itemFormDto.itemFormDisplayID);
                //Storing the itemFormDisplayID in the service 
                this.dashboardService.setItemFormDisplayID(res.itemFormDisplayID, res.id);
               this.router.navigate(['/new-item-form/' + routeDecider + '/dsd-authorization-request'], { queryParamsHandling: "merge" });
               
            }
            else {
                console.log('Item Form Save Error');
                this.showSpinner = false;
            }
        },
            (err) => {
                console.log(err);
                this.showSpinner = false;
            });
    }

    viewItemForm(selectedForm: IItemFormDto): any {
        this.showSpinner = true;
        let routeDecider =  (this.isBuyer ? (this.isMfg ?"mfg": "buyer") :"vendor");
        this.dashboardService.setItemFormDisplayID(selectedForm.itemFormDisplayID, null);
        if (selectedForm.formTypeID == 3) {
            this.router.navigate(['/new-item-form/' + routeDecider + '/dsd-authorization-request'], { queryParamsHandling: "merge" });
        }
        else {
            this.router.navigate(['/new-item-form/' + routeDecider], { queryParamsHandling: "merge" });
        }
       
    }
    
}
