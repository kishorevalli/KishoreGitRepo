import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { SharedModule } from './../shared/shared.module';
import { BasicItemDefinitionService } from '../new-item-form/basic-item-definition/basic-item-definition.service';
import { DashboardService } from './dashboard.service';
import { DashboardVendorComponent } from './dashboard-vendor.component';
import { DashboardBuyerComponent } from './dashboard-buyer.component';
import { ReassignVendorcontactComponent } from './reassign-vendorcontact.component';
import { NewItemFormService } from '../new-item-form/new-item-form.service';
import { DashboardErrorMessageComponent } from './dashboard-error-message.component';
import { CategoryReviewReportComponent } from './category-review-report/category-review-report.component';


@NgModule({
  imports: [
    CommonModule,
      DashboardRoutingModule,
      SharedModule,
      
  ],
    declarations: [DashboardComponent, DashboardVendorComponent, DashboardBuyerComponent, ReassignVendorcontactComponent, DashboardErrorMessageComponent, CategoryReviewReportComponent],
  providers: [
      BasicItemDefinitionService,
      DashboardService, NewItemFormService],
    entryComponents: [ReassignVendorcontactComponent, DashboardErrorMessageComponent]
    
})
export class DashboardModule { }
