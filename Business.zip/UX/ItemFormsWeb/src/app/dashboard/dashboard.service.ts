import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { IItemFormDto, ItemFormDto, UserType, FormUserPermittedActionDto, IFormUserPermittedActionDto } from '../new-item-form/new-item-form.interface';
import { IItemValidationDTO,IErrorDTO, ErrorDTO } from '../shared/common.interface';
import { Subject } from 'rxjs/Subject';
import { APP_CONFIG, AppConfig } from '../app.config';


import { IDashboardItemFormDto, DashboardItemFormDto, IDashboardStatusDto, DashboardStatusDto, IDashboardSearchCriteriaDto, DashboardSearchCriteriaDto, IDashboardFormStatusDto, DashboardFormStatusDto, DashboardUserSelectionDto, IDashboardUserSelectionDto, IViewForUserListDto, ViewForUserListDto, IBuyerDto, LoggedInUserDto, ILoggedInUserDto, VendorDto, IVendorDto, ICategoryReviewDto } from './dashboard.interface';



@Injectable()
export class DashboardService {
    private baseUrl: string;
    private serviceBase: string = 'api/Common/';
    private serviceBaseDashboard: string = 'api/Dashboard/';

    private _itemFormDisplayID: number;  
  
    constructor( @Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;
    }

    get itemFormDisplayID(): number {
        if(!this._itemFormDisplayID){
            this._itemFormDisplayID = +sessionStorage.getItem("itemFormDisplayID");
        }
        return this._itemFormDisplayID;
    }     
    set itemFormDisplayID(newValue:number) {
        if(!newValue) return;
        this._itemFormDisplayID = newValue;   
        sessionStorage.setItem("itemFormDisplayID", newValue.toString());     
    }

    private _itemFormID: number;
    get itemFormID(): number {
        if(!this._itemFormID){
            this._itemFormID = +sessionStorage.getItem("itemFormID");
        }
        return this._itemFormID;
    }
     
    set itemFormID(newValue:number) {
        if(!newValue) return;
        this._itemFormID = newValue;   
        sessionStorage.setItem("itemFormID", newValue.toString());     
    }

    private _userType: UserType;
    get userType(): UserType {
        if(!this._userType){
            this._userType = UserType[sessionStorage.getItem("userType")];
        }
        return this._userType;
    }
     
    set userType(newValue:UserType) {
        if(!newValue) return;
        this._userType = newValue;   
        sessionStorage.setItem("userType", newValue.toString());     
    }

    setItemFormDisplayID(itemFormDisplayId : number, itemFormID: number)
    {
        this.itemFormDisplayID = itemFormDisplayId; 
        this.itemFormID = itemFormID;
    }


    deleteItemForm(itemFormDto: IItemFormDto): Observable<boolean> {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'DeleteItemForm', itemFormDto);
    }
    clearAll(){
        sessionStorage.clear();
    }

    saveItemForm(itemFormDto: IItemFormDto): Observable<IItemFormDto> {     
        return this.httpClient.post<IItemFormDto>(this.baseUrl + this.serviceBase + 'SaveItemForm', itemFormDto);
    }

    getItemFormListBySearchCriteria(dashboardSearchCriteriaDto: IDashboardSearchCriteriaDto): Observable<IDashboardItemFormDto[]> {
        return this.httpClient.post<IDashboardItemFormDto[]>(this.baseUrl + this.serviceBaseDashboard + 'GetItemFormListBySearchCriteria', dashboardSearchCriteriaDto);
    }

    getItemFormListBySearchCriteriaInternalUser(dashboardSearchCriteriaDto: IDashboardSearchCriteriaDto): Observable<IDashboardItemFormDto[]> {
        return this.httpClient.post<IDashboardItemFormDto[]>(this.baseUrl + this.serviceBaseDashboard + 'GetItemFormListBySearchCriteriaInternalUser', dashboardSearchCriteriaDto);
    }

    getDashboardStatus(loggedInUserDto: ILoggedInUserDto): Observable<IDashboardStatusDto[]> {
        return this.httpClient.post<IDashboardStatusDto[]>(this.baseUrl + this.serviceBaseDashboard + 'GetDashboardStatus', loggedInUserDto);
    }

    getDashboardStatusCount(dashboardStatusDto: IDashboardStatusDto): Observable<Number> {
        return this.httpClient.post<Number>(this.baseUrl + this.serviceBaseDashboard + 'GetDashboardStatusCount', dashboardStatusDto);
    }
    getDashboardStatusCountInternal(dashboardStatusDto: IDashboardStatusDto): Observable<Number> {
        return this.httpClient.post<Number>(this.baseUrl + this.serviceBaseDashboard + 'GetDashboardStatusCountInternal', dashboardStatusDto);
    }

    getDashboardStatusDetail(dashboardStatusDto: IDashboardStatusDto): Observable<DashboardItemFormDto[]> {
        return this.httpClient.post<DashboardItemFormDto[]>(this.baseUrl + this.serviceBaseDashboard + 'GetDashboardStatusDetail', dashboardStatusDto);
    }

    getDashboardStatusDetailInternal(dashboardStatusDto: IDashboardStatusDto): Observable<DashboardItemFormDto[]> {
        return this.httpClient.post<DashboardItemFormDto[]>(this.baseUrl + this.serviceBaseDashboard + 'GetDashboardStatusDetailInternal', dashboardStatusDto);
    }

    getDashboardFormStatusForVendor(): Observable<IDashboardFormStatusDto[]> {
        return this.httpClient.get<IDashboardFormStatusDto[]>(this.baseUrl + this.serviceBaseDashboard + 'GetDashboardFormStatusForVendor');
    }

    getDashboardFormStatusForBuyer(): Observable<IDashboardFormStatusDto[]> {
        return this.httpClient.get<IDashboardFormStatusDto[]>(this.baseUrl + this.serviceBaseDashboard + 'GetDashboardFormStatusForBuyer');
    }
    //Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForVendor()
    //getUserType(userID: string): Observable<string> {        
    //    return this.httpClient.get<string>(this.baseUrl + this.serviceBase + `GetUserType?userID=${userID}`);
    //}

    updateItemFormActionAndCurrentStatusList(formUserPermittedActionList: IFormUserPermittedActionDto[]): Observable<boolean> {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBaseDashboard + 'UpdateItemFormActionAndCurrentStatusList', formUserPermittedActionList);
    }

    updateItemFormStatusForInternalUser(formUserPermittedActionList: IFormUserPermittedActionDto[]): Observable<boolean> {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBaseDashboard + 'UpdateItemFormStatusForInternalUser', formUserPermittedActionList);
    }

    getDashboardUserSelection(): Observable<DashboardUserSelectionDto> {
        return this.httpClient.get<DashboardUserSelectionDto>(this.baseUrl + this.serviceBaseDashboard + 'GetDashboardUserSelection');
    }

    AddItemFormToGroup(itemFormID: Number): Observable<IDashboardItemFormDto[]> {
        return this.httpClient.get<IDashboardItemFormDto[]>(this.baseUrl + this.serviceBaseDashboard + `AddItemFormToGroup?ItemFormID=${itemFormID}`);
    }

    RemoveItemFormFromGroup(itemFormID: Number): Observable<IDashboardItemFormDto[]> {
        return this.httpClient.get<IDashboardItemFormDto[]>(this.baseUrl + this.serviceBaseDashboard + `RemoveItemFormFromGroup?ItemFormID=${itemFormID}`);
    }

    ParentingItemForm(itemFormID: Number): Observable<IDashboardItemFormDto[]> {
        return this.httpClient.get<IDashboardItemFormDto[]>(this.baseUrl + this.serviceBaseDashboard + `ParentingItemForm?ItemFormID=${itemFormID}`);
    }

    UnParentingItemForm(itemFormID: Number): Observable<IDashboardItemFormDto[]> {
        return this.httpClient.get<IDashboardItemFormDto[]>(this.baseUrl + this.serviceBaseDashboard + `UnParentingItemForm?ItemFormID=${itemFormID}`);
    }

    insertDashboardUserSelection(dashboardUserSelectionDto: DashboardUserSelectionDto): Observable<boolean> {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBaseDashboard + 'InsertDashboardUserSelection', dashboardUserSelectionDto);
    }

    updateReassignVendorContact(vendorContact: IViewForUserListDto ): Observable<boolean> {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBaseDashboard + 'UpdateReassignVendorContact', vendorContact);
    }

    updateVSARelatedForm(): Observable<boolean> {
        return this.httpClient.get<boolean>(this.baseUrl + this.serviceBaseDashboard + 'UpdateVSARelatedForm');
    }



    getDashboardErrorMessageList(itemFormID: Number): Observable<IErrorDTO[]> {
        return this.httpClient.get<IErrorDTO[]>(this.baseUrl + this.serviceBaseDashboard + `GetDashboardErrorMessageList?ItemFormID=${itemFormID}`);
    }

    changeVendorSubmittedFormToReview(itemFormID: Number): Observable<boolean> {
        return this.httpClient.get<boolean>(this.baseUrl + this.serviceBaseDashboard + `ChangeVendorSubmittedFormToReview?ItemFormID=${itemFormID}`);
    }
       

    getDefaultFavouriteForUserType(UserTypeID: Number): Observable<DashboardStatusDto> {
        return this.httpClient.get<DashboardStatusDto>(this.baseUrl + this.serviceBaseDashboard + `GetDefaultFavouriteForUserType?UserTypeID=${UserTypeID}`);
    }

    getParentStatusForGTIN(GTIN: Number): Observable<string> {
        return this.httpClient.get<string>(this.baseUrl + this.serviceBaseDashboard + `GetParentStatusForGTIN?GTIN=${GTIN}`);
    }

    getBuyerRelatedUsers(): Observable<IBuyerDto[]> {
        return this.httpClient.get<IBuyerDto[]>(this.baseUrl + this.serviceBaseDashboard + `GetBuyerRelatedUsers`);
    }

    getVendorRelatedUsers(): Observable<IVendorDto[]> {
        return this.httpClient.get<IVendorDto[]>(this.baseUrl + this.serviceBaseDashboard + `GetVendorRelatedUsers`);
    }

    getFormActionsForItemForm(CurrentUserTypeID: Number, CurrentFormStatusID:Number): Observable<IFormUserPermittedActionDto[]> {
        return this.httpClient.get<IFormUserPermittedActionDto[]>(this.baseUrl + this.serviceBaseDashboard + `GetFormActionsForItemForm/${CurrentUserTypeID}/${CurrentFormStatusID }`);
    }

    getCategoryReviewReport(BuyerID: Number): Observable<ICategoryReviewDto[]> {
        return this.httpClient.get<ICategoryReviewDto[]>(this.baseUrl + this.serviceBaseDashboard + `GetCategoryReviewReport?BuyerID=${BuyerID}`);
    }

    downloadCategoryReviewReport(CategoryReviewList: ICategoryReviewDto[]): Observable<any> {
        return this.httpClient.post<any>(this.baseUrl + this.serviceBaseDashboard + 'DownloadCategoryReviewReport', CategoryReviewList, {responseType: 'blob' as 'json'});
    }

    



}

