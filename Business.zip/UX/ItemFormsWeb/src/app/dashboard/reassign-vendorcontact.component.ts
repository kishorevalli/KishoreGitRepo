import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ViewForUserListDto, IViewForUserListDto } from './dashboard.interface';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { DashboardService } from './dashboard.service';

@Component({
  selector: 'ifw-reassign-vendorcontact',
  templateUrl: './reassign-vendorcontact.component.html',
  styleUrls: ['./reassign-vendorcontact.component.scss']
})
export class ReassignVendorcontactComponent implements OnInit {

    public possibleVendorContactList: IViewForUserListDto[];
    ReassignVendorContactsForm: FormGroup;
    ItemFormID: Number;

    constructor(public dialogRef: MatDialogRef<ReassignVendorcontactComponent>,
        private router: Router,
        private formBuilder: FormBuilder,
        private dashboardService: DashboardService,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) {

    }

    ngOnInit() {
        this.ReassignVendorContactsForm = this.formBuilder.group({
            possibleVendorContact: ''
        });

        this.possibleVendorContactList = this.data.vendorContactList;
        this.ItemFormID = this.data.itemFormID;
    }

    filterVendorContactList() {
        // get the vendors of each vendor contact is valid for the 

    }  

    onReassignVendorContact() {    

        let vendorContact: IViewForUserListDto = {
            "itemFormId": this.ItemFormID,
            "viewForUserId": this.ReassignVendorContactsForm.get("possibleVendorContact").value           
        }
        this.dashboardService.updateReassignVendorContact(vendorContact).subscribe(res => {
            console.log(res);
        });

        this.dialogRef.close(this.data);
    }

    onCancel() {
        this.dialogRef.close();
    }

}
