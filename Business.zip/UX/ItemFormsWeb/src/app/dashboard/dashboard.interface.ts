import { IItemFormDto, ItemFormDto, UserType, IFormUserPermittedActionDto, FormUserPermittedActionDto } from '../new-item-form/new-item-form.interface';

export interface IDashboardItemFormDto {
    rowId: Number;
    itemFormID: Number;
    itemFormDisplayID: string;
    parentFlag: string;
    isInGroup: string;
    groupID: string;
    eligibleForGroupingParenting: string;
    singleGTINItemForm: string;
    showDetails: boolean; 
    vendorItemCode: Number;
    vendorItemDescription: string;
    buyerItemDescription: string;
    itemTypeCode: string;
    formattedGtin: string;
    gtinCheckDigit: Number;
    priceLookUp: Number;
    rSS: string;
    vendorNumber: Number;
    vendorList: string;
    formStatus: string;
    formStatusID: Number;
    buyerStatusNameForLinkedForm: string;
    buyerStatusName: string;
    vendorStatusName: string;    
    isSelected: boolean;
    formActions: IFormUserPermittedActionDto[];
    childGTINItemFormList?: IDashboardItemFormDto[];
    formTypeID: Number;
    formActionID: Number;
    selectedFormActionID: Number;
    selectedFormActionName: String;
    formType: string;
    buyerProductGroupCode: string;
    buyerProductGroupDescription: string;
    rSSProductGroupCode: string;
    rSSProductGroupDescription: string;
    warningCount: Number;
    createdByUserTypeID: Number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}

export class DashboardItemFormDto implements IDashboardItemFormDto {
    rowId: Number;
    itemFormID: Number;
    itemFormDisplayID: string;
    parentFlag: string;
    isInGroup: string;
    groupID: string;
    eligibleForGroupingParenting: string;
    singleGTINItemForm:string
    showDetails: boolean;
    vendorItemCode: Number;
    vendorItemDescription: string;
    buyerItemDescription: string;
    itemTypeCode: string;
    formattedGtin: string;
    gtinCheckDigit: Number;
    priceLookUp: Number;
    rSS: string;
    vendorNumber: Number;
    vendorList: string;
    formStatus: string;
    formStatusID: Number;  
    buyerStatusNameForLinkedForm: string;
    buyerStatusName: string;
    vendorStatusName: string;
    formActions: FormUserPermittedActionDto[];
    childGTINItemFormList?: IDashboardItemFormDto[];
    formTypeID: Number;
    formActionID: Number;
    selectedFormActionID: Number;
    selectedFormActionName: String;
    isSelected: boolean;
    formType: string;
    buyerProductGroupCode: string;
    buyerProductGroupDescription: string;
    rSSProductGroupCode: string;
    rSSProductGroupDescription: string;
    warningCount: Number;
    createdByUserTypeID: Number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}



export interface IDashboardStatusDto {
    dashboardStatusNameId: Number;
    IsIncludeRelatedFromChecked?: Boolean;
    vendorContactID?: string;
    buyerID?: Number;
    isFavouriteClicked?: Boolean;
    status?: string;
    statusID?: Number;
    statusComment?: string;
    statusCount?: Number;
    statusImage?: string;    
    userTypeID?: UserType
    isVSALoggedIn?: Boolean
}

export class DashboardStatusDto implements IDashboardStatusDto{
    dashboardStatusNameId: Number;
    IsIncludeRelatedFromChecked?: Boolean;
    vendorContactID?: string;
    buyerID?: Number;
    isFavouriteClicked?: Boolean;
    status?: string;
    statusID?: Number;
    statusComment?: string;
    statusCount?: Number;
    statusImage?: string;    
    userTypeID?: UserType
    isVSALoggedIn?: Boolean
}
 

export interface IDashboardSearchCriteriaDto {
    buyerID?: Number;
    vendorContactID?: string;
    formattedGtin: string;
    IsIncludeRelatedFromChecked?: Boolean;
    isFavouriteClicked?: Boolean;
    isSearchClicked?: Boolean;
    searchGTINCheckDigit?: Number;
    searchItemCode: Number;
    searchSubmittedFromDate: Date;
    searchSubmittedToDate: Date;
    compressedUPC: Number;
    searchItemDescription: string;
    priceLookupCode: Number;
    searchFormStatusId: string;
    searchFormId: Number;
    searchSelectedVendors: string;
    searchSelectedOrganization: string;
    viewItemFormsForUserID?: string
    userType: UserType;
}

export class DashboardSearchCriteriaDto implements IDashboardSearchCriteriaDto {
    buyerID?: Number;
    vendorContactID?: string;
    formattedGtin: string;
    IsIncludeRelatedFromChecked?: Boolean;  
    isFavouriteClicked?: Boolean;
    isSearchClicked?: Boolean;
    searchGTINCheckDigit?: Number;
    searchItemCode: Number;
    searchSubmittedFromDate: Date;
    searchSubmittedToDate: Date;
    compressedUPC: Number;
    searchItemDescription: string;
    priceLookupCode: Number;
    searchFormStatusId: string;
    searchFormId: Number;     
    searchSelectedVendors: string;
    searchSelectedOrganization: string;
    viewItemFormsForUserID?:string
    userType: UserType;
}

export interface IDashboardFormStatusDto  {
    formStatus: string;
    formStatusIDs: string;
}


export class DashboardFormStatusDto implements IDashboardFormStatusDto {
    formStatus: string;
    formStatusIDs: string;
}

export class IDashboardUserSelectionDto {
    loggedInUserID: string;
    vendorContactID?: string;
    buyerID?: Number;
    isVSARelatedFormChecked?: Boolean;
    isVSAUser?: Boolean;
    isFavouriteClicked?: boolean;
    isSearchClicked?: boolean;
    dashboardStatusQueriesID?: Number;
    dashboardStatusName?: string;
    statusID?: Number;
    searchGTIN?: Number;
    searchFormattedGtin?: string
    searchGTINCheckDigit?: Number;
    searchItemCode?: Number;
    searchFormID?: Number;
    searchSubmittedFromDate?: Date;
    searchSubmittedToDate?: Date;
    compressedUPC?: Number;
    searchItemDescription?: string;
    priceLookupCode?: Number;
    searchFormStatusId?: string;
    searchSelectedOrganization?: string;
    searchSelectedVendors?: string;   
    vendorNumber?: string;
    createdBy?: string;
    createdDate?: Date;
} 


export class DashboardUserSelectionDto implements IDashboardUserSelectionDto{
    loggedInUserID: string;    
    buyerID?: Number;
    vendorContactID?: string;
    isVSARelatedFormChecked?: Boolean;
    isVSAUser?: Boolean;
    isFavouriteClicked?: boolean;
    isSearchClicked?: boolean;
    dashboardStatusQueriesID?: Number;
    dashboardStatusName?: string;
    statusID?: Number;
    searchGTIN?: Number;
    searchFormattedGtin?: string
    searchGTINCheckDigit?: Number;
    searchItemCode?: Number;
    searchFormID?: Number;
    searchSubmittedFromDate?: Date;
    searchSubmittedToDate?: Date;
    compressedUPC?: Number;
    searchItemDescription?: string;
    priceLookupCode?: Number;
    searchFormStatusId?: string;
    searchSelectedOrganization?: string;
    searchSelectedVendors?: string;
    vendorNumber?: string;
    createdBy?: string;
    createdDate?: Date;
}

export interface IViewForUserListDto {
    viewForUserId: string;
    itemFormId?: Number; 
    isValidForAssignment?: Boolean;
}

export class ViewForUserListDto implements IViewForUserListDto {
    itemFormId?: Number; 
    viewForUserId: string;
    isValidForAssignment?: Boolean;
}


export interface IDashboardErrorMessageDto {
   tabName: string;
    errorDescription: string;
}

export interface DashboardErrorMessageDto {
    tabName: string;
    errorDescription: string;
}


export interface IBuyerDto {
    iD: string;
    userId: string;
    buyerName: string;
    displayName: string;    
}



export interface IVendorDto {
    vendorID: string;
    vendorNumber: string;
    vendorName: string;
    groupID?: string;
    organizationTypeID?: string;
    organizationID?: string;
    organizationName?: string;
    vendorType?: string;
    displayName?: string;

}

export class BuyerDto implements BuyerDto{
    iD: string;
    userId: string;
    buyerName: string;
    displayName: string;
}



export class VendorDto implements IVendorDto {
    vendorID: string;
    vendorNumber: string;
    vendorName: string;
    groupID?: string;
    organizationTypeID?: string;
    organizationID?: string;
    organizationName?: string;
    vendorType?: string;
    displayName?: string;

}


export class LoggedInUserDto implements ILoggedInUserDto {
    loggedInUserID: string;
    loggedInUserTypeID: string;
}

export class ILoggedInUserDto  {
    loggedInUserID: string;
    loggedInUserTypeID: string;
}

export class ICategoryReviewDto {
    vendor: string;
    rss: string;
    gtinWithCheckDigit: string;
    itemDescription: string;
    projectedSales52WeeksStr: string;
    unitCostStr: string;
    unitCostUOM: string;
    caseCost: number;
    casePack: number;
    suggestedRetailStr: string;
    suggestedMarginStr: string;
    itemPreviouslyPresented: string;
    availableShipDateStr: string;
    newItemFundsAvailable: string;
    newItemFundsAmountStr: string;
    vendorComments:string;
    buyerComments:string;
    itemFormID: number;
    itemFormDisplayID: string;
}
export class CategoryReviewDto implements ICategoryReviewDto {
    vendor: string;
    rss: string;
    gtinWithCheckDigit: string;
    itemDescription: string;
    projectedSales52WeeksStr: string;
    unitCostStr: string;
    unitCostUOM: string;
    caseCost: number;
    casePack: number;
    suggestedRetailStr: string;
    suggestedMarginStr: string;
    itemPreviouslyPresented: string;
    availableShipDateStr: string;
    newItemFundsAvailable: string;
    newItemFundsAmountStr: string;
    vendorComments:string;
    buyerComments:string;
    itemFormID: number;
    itemFormDisplayID: string;
}







 






 