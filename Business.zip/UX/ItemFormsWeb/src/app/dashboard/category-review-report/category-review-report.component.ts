import { Component, OnInit, OnDestroy } from '@angular/core';

import { IBuyerDto, ICategoryReviewDto } from '../dashboard.interface';
import { UserType } from '../../new-item-form/new-item-form.interface';
import { DashboardService } from '../dashboard.service';
import { AuthService } from '../../core/services/auth.service';
import { GridEvent } from '../../shared/grid/grid-event';
import * as _moment from 'moment';
const moment = _moment;

@Component({
  selector: 'ifw-category-review-report',
  templateUrl: './category-review-report.component.html',
  styleUrls: ['./category-review-report.component.scss']
})
export class CategoryReviewReportComponent implements OnInit, OnDestroy {
  public relatedBuyers: IBuyerDto[] = [];
  userId: any;
  buyerID:any;
  public categoryReviewList: ICategoryReviewDto[] = [];
  showBuyerLoadingSpinner: boolean = false;
  constructor(private dashboardService: DashboardService,
              private auth: AuthService) { }

  ngOnInit() {
    this.userId = this.auth.currentUser;
    this.showBuyerLoadingSpinner = true;
    this.dashboardService.getBuyerRelatedUsers().subscribe(BuyerRelatedUsersRes => {
      this.relatedBuyers = BuyerRelatedUsersRes;   
      this.LoadDashboardUserSelectionFromDB();
      this.showBuyerLoadingSpinner = false;               
    }, (err) => {
        this.showBuyerLoadingSpinner = false;
        this.buyerID = 200;
        this.getCategoryReviewReport();
    });
  }
  public ngOnDestroy (): void {
    //this.subBuyer.unsubscribe();
  }
  changeBuyer(buyerID:any) {
    console.log("changeBuyer: "+ buyerID);
    this.buyerID = buyerID;
    this.getCategoryReviewReport();
  }
  public LoadDashboardUserSelectionFromDB() {
    this.dashboardService.getDashboardUserSelection().subscribe(userSelectionRes => {
      if(userSelectionRes) {
        this.buyerID = userSelectionRes.buyerID;
      }
      else if(this.relatedBuyers.length > 0){
        this.buyerID = this.relatedBuyers[0].userId;
      }
      if(this.buyerID){
        this.getCategoryReviewReport();
      }
    });
  }
  private getCategoryReviewReport(){
    this.gridLoaded = false;
    this.dashboardService.getCategoryReviewReport(this.buyerID).subscribe(res => {
      this.categoryReviewList = res;
      this.populateInitialGridData(); 
      this.gridLoaded = true;
    });
  }
  public isDownloading: boolean = false;
  public generateReport(){
    this.isDownloading = true;
    this.dashboardService.downloadCategoryReviewReport(this.data).subscribe(data=>{
      this.isDownloading = false;
      //console.log(data);
      const file: Blob = new Blob([data], { type: 'application/xlsx' });
      const filename = "CategoryReviewReport_"+this.buyerID+"_"+moment().format("YYYYMMDDHHmmss")+".xlsx";
      this.downloadFile(file,filename);
    },
    (err) => {
      this.isDownloading = false;
    });
  }
  private downloadFile(blob:Blob, fileName: string) {
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, fileName);
      } else {
          // Doing it this way allows you to name the file
          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = fileName;
          link.rel = 'noopener' // tabnabbing
          //link.click();
          setTimeout(function () { link.click(); }, 0);
      }
  }
  // Grid variables
  public data: ICategoryReviewDto[]; // used to hold shallow copy of grid data of each tab.
  public griddata: ICategoryReviewDto[]; // used to hold shallow copy of grid data of each tab.
  length: number; // used to hold count of the entire grid data. 
  pageSize: number;
  gridLoaded: boolean = false;
  showDetails: boolean = true;
  hasChild = (_rowData: ICategoryReviewDto) => { return ( (_rowData.vendorComments && _rowData.vendorComments.length > 0)
                                                         || (_rowData.buyerComments && _rowData.buyerComments.length > 0)) };
  getGridData() {
    if (!this.griddata) return [];
    return this.griddata;
  }
  populateInitialGridData() {
    this.updateData({
      pageIndex: 0,
      pageSize: 10,
      length: 0,
      active: "",
      direction: "",
      filterBy: "",
      filterValue: ""
    });
  }
  updateData(gridEvent: GridEvent) {
    this.data = this.performFilter(gridEvent);
    this.sortData(gridEvent);
    this.pageData(gridEvent);
  }
  /**
  * return the filtered or shallow copy without changing the original data
  */
  performFilter(gridEvent: GridEvent): any[] {
    let filterBy = gridEvent.filterBy;
    let filterValue = gridEvent.filterValue;
    if (filterBy && filterBy.length > 0) {
      if (filterValue && filterValue.length > 0) {
        //console.log(this.filterValue);
        return this.categoryReviewList.filter((row: any) => {
          //Transform the data into a lowercase string of property values.
          const dataStr = ('' + row[filterBy]).toLowerCase();
          // Transform the data into a lowercase string of all property values.
         // const accumulator = (currentTerm, key) => currentTerm + row[key];
         // const dataStr = Object.keys(row).reduce(accumulator, '').toLowerCase();
          // Transform the filter by converting it to lowercase and removing whitespace.
          const transformedFilter = filterValue.trim().toLowerCase();
          return dataStr.indexOf(transformedFilter) != -1;
        }
        );
      }
      return this.categoryReviewList.slice();
    }
    return this.categoryReviewList.slice();
  }
  /**
   * sort the filtered result based on sort column and order
   */
  sortData(gridEvent: GridEvent) {
    let active = gridEvent.active;
    let direction = gridEvent.direction;
    let sortAsc = gridEvent.direction == 'asc';
    let sortDesc = gridEvent.direction == 'desc';
    if (!sortAsc && !sortDesc) return;
    this.data.sort((a, b) => {
      if (typeof a[gridEvent.active] === 'string') {
        return a[active].localeCompare(b[active]);
      } else {
        return a[active] - b[active];
      }
    });
    if (sortAsc === false) {
      this.data.reverse();
    }
  }
  /**
     * paginate the result set
     */
  pageData(gridEvent: GridEvent) {
    this.length = this.data.length;
    this.pageSize = gridEvent.pageSize;
    let pageIndex = gridEvent.pageIndex;
    let offset = pageIndex * this.pageSize;
    this.griddata = this.data.slice(offset, offset + this.pageSize);
  }
}
