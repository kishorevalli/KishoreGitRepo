import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, AbstractControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatPaginatorModule, MatSort, MatPaginator } from '@angular/material';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBarConfig } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { from } from 'rxjs/observable/from';
import { catchError, tap, map } from 'rxjs/operators';
import { forkJoin } from 'rxjs/observable/forkJoin';
import * as _ from 'lodash';


import { NewItemFormService } from '../new-item-form.service';
import { AuthService } from '../../core/services/auth.service';
import { UserType } from '../new-item-form.interface';
import { GridEvent } from '../../shared/grid/grid-event';
import { DsdAuthorizationRequestService } from './dsd-authorization-request.service';
import { DialogLookupDsdVendorOrgsComponent } from './dialog-lookup-dsd-vendor-orgs.component';
import { DialogVendorOrgSearchComponent } from '../common/dialogs/dialog-vendor-org-search.component';
import { IVendorAuthorizationDto, VendorAuthorizationDto, IVendorServiceDto, VendorServiceDto, IDsdVendorStoreAuthorizationDto, DsdVendorStoreAuthorizationDto } from './dsd-authorization-request.interface';
import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto } from '../../shared/common.interface';

@Component({
  selector: 'ifw-dialog-create-vendor-store-authorization',
  templateUrl: './dialog-create-vendor-store-authorization.component.html',
  styleUrls: ['./dialog-create-vendor-store-authorization.component.scss']
})
export class DialogCreateVendorStoreAuthorizationComponent implements OnInit {

    /* Variable Declarations */
    public createVendorStoreAuthForm: FormGroup;
    public vendorList: IVendorAuthorizationDto[] = [];
    public includedVendorList: IVendorAuthorizationDto[] = [];
    public vendorServiceList: IVendorServiceDto[] = [];
    public stateList: ILookupDto[] = [];
    public countyList: ILookupDto[] = [];
    public storeList: ILookupIntDto[] = [];     
    public includedStoreList: any[] = [];
    public vendorOrgDataList: IVendorAuthorizationDto[] = [];
    public selectedVendorNumbers: number[] = [];
    public itemFormID: number;
    public isExternalUser: boolean = false;
    public isAugumentingUser: boolean = false;  
    public showSpinner: boolean = false;
    public isDsdAuthMaintenaceRequest:boolean = false;
    dsdVendorStoreAuthorizationDto: IDsdVendorStoreAuthorizationDto = new DsdVendorStoreAuthorizationDto();   

    //Snack Bar
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    snackbarConfig = new MatSnackBarConfig()

    
     /* Properties */
       

    get selectedStates(): AbstractControl {
        return this.createVendorStoreAuthForm.get('state');
    }

    get selectedCounties(): AbstractControl {
        return this.createVendorStoreAuthForm.get('county');
    }

    get selectedstoreAuthSelectionType(): AbstractControl {
        return this.createVendorStoreAuthForm.get('storeAuthSelectionType');
    }

    /* Constrctor & Events */

    constructor(private newItemFormService: NewItemFormService,
        private dsdAuthRequestService: DsdAuthorizationRequestService,
        private authService: AuthService,
        public dialogRef: MatDialogRef<DialogCreateVendorStoreAuthorizationComponent>,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private formBuilder: FormBuilder,       
        public snackBar: MatSnackBar) {

        this.createForm();
    }

    ngOnInit() {
        this.isDsdAuthMaintenaceRequest = (this.newItemFormService.formTypeID == 3);
        this.Initialize(); 
    }


    /* Private Methods */

    private createForm():void {

        this.createVendorStoreAuthForm = this.formBuilder.group({
            'vendor': [''],
            'storeAuthSelectionType': [1],
            'state': [''],
            'county': [''],
            'storeNumber': ['']
        });
    }


    private Initialize() {

        this.selectedVendorNumbers = [];

        this.itemFormID = this.data.itemFormID;        
        
        if(!this.isDsdAuthMaintenaceRequest){
            this.getDsdVendorsExistForItemForm(this.itemFormID);            
        }
        else {            
            if (this.authService.isExternal) {
                this.isExternalUser = true;
                //this.getDsdVendors();
                this.getDsdVendorsByUserId(this.newItemFormService.vendorContactID);
               
            }
            else {
                this.isExternalUser = false;           
    
                //TODO remove the Hard coded vendor
                if (this.newItemFormService.createdByUserType == UserType.Vendor) {
                    this.isAugumentingUser = true;
    
                    this.getDsdVendorsByUserId(this.newItemFormService.vendorContactID);
    
                    //forkJoin(this.dsdAuthRequestService.getDsdVendorsByUserId(this.newItemFormService.createdBy),
                    //    this.dsdAuthRequestService.getAuthorizedDsdVendorsByItemForm(this.itemFormID)).subscribe(res => {
                    //        this.vendorList = res[0];
                    //        this.getIncludedVendors(res[1]);    
    
                    //        //Remove the included vendor list for Excluded vendors list
                    //        this.includedVendorList.forEach(obj => {
                    //            this.vendorList.splice(this.vendorList.findIndex(e => e.vendorNumber == obj.vendorNumber), 1); 
                    //        });                   
                    //    });
                
                }       
            }
        }
        //Snackbar config
        this.snackbarConfig.verticalPosition = this.verticalPosition;
        this.snackbarConfig.horizontalPosition = this.horizontalPosition;
        this.snackbarConfig.duration = 3000;
        this.snackbarConfig.panelClass = 'custom-class';
      
    }

    /* Events or Public Methods */

    public onStoreAuthSelectionType(): void {

        this.createVendorStoreAuthForm.patchValue({ 'state': '' });   

        this.countyList = [];
        this.storeList = [];
        this.includedStoreList = [];        
    }

 
    public onStateSelect(): void {

        this.countyList = [];
        this.createVendorStoreAuthForm.patchValue({ 'county': '' });

        let state: string = this.selectedStates.value;

        if (state) {

            let tempList: any[] = _.filter(this.vendorServiceList, { 'stateCode': state });
            tempList.forEach(obj => {
                if (!this.countyList.find((self) => self.code === obj.countyCode)) {
                    this.countyList.push({
                        code: obj.countyCode,
                        description: obj.countyName
                    });
                }
            });

            this.countyList = _.orderBy(this.countyList, ['description'], ['asc']);
           
        }
        else {

            this.countyList = [];
          
        }

    }
      
    public onGetStoresByStateCounty(): void {   
   
        let state: string = this.selectedStates.value;
        let counties: any[] = this.selectedCounties.value;

        if (state) {

            if (counties && counties.length > 0) {
                counties.forEach(county => {
                    let tempList: any[] = _.filter(this.vendorServiceList, { 'stateCode': state, 'countyCode': county });

                    tempList.forEach(obj => {
                        if (!this.includedStoreList.find((self) => self.code === obj.storeNumber)) {
                            this.includedStoreList.push({
                                code: obj.storeNumber,
                                description: obj.storeNumber.toString()
                            });
                        }
                    });

                });

            }
            else {
                let tempList: any[] = _.filter(this.vendorServiceList, { 'stateCode': state });                

                tempList.forEach(obj => {
                    if (!this.includedStoreList.find((self) => self.code === obj.storeNumber)) {
                        this.includedStoreList.push({
                            code: obj.storeNumber,
                            description: obj.storeNumber.toString()
                        });
                    }
                });

            }           

            this.storeList = [];
            this.includedStoreList = _.orderBy(this.includedStoreList, ['description'], ['asc']);      
        }       

    }

    public onAddToIncludedStore(): void{

        let storeNumber: any = this.createVendorStoreAuthForm.get('storeNumber').value;

        let showErrorFlag: boolean = true;
        if (!isNaN(storeNumber)) {

            if (this.vendorServiceList.find(e => e.storeNumber == storeNumber)) {

                if (!(this.includedStoreList.find(e => e.code == storeNumber))) {
                    this.includedStoreList.push({
                        code: storeNumber,
                        description: storeNumber.toString()
                    });

                    this.storeList.splice(this.storeList.findIndex(e => e.code == storeNumber), 1);
                    showErrorFlag = false;
                }
               
            }
           
        }
        if (showErrorFlag)
            this.snackBar.open('Invalid Store or Store not serviced by vendor.', undefined, this.snackbarConfig);
        
    }

    public onCreateVendorStoreAuthorization(): void {

        this.showSpinner = true;

        this.dsdVendorStoreAuthorizationDto.itemFormID = this.itemFormID;
        this.dsdVendorStoreAuthorizationDto.vendorNumbers = this.selectedVendorNumbers;
        
        this.dsdVendorStoreAuthorizationDto.storeNumbers = this.includedStoreList.map(x => x.code);

        if (this.selectedstoreAuthSelectionType.value == 1) {
            this.dsdVendorStoreAuthorizationDto.isAllServicedStores = true;
        }
        else {
            this.dsdVendorStoreAuthorizationDto.isAllServicedStores = false;
        }

        this.dsdAuthRequestService.saveDsdVendorStoreAuthorization(this.dsdVendorStoreAuthorizationDto).subscribe(res => {
            this.showSpinner = false;
            if (res) {
                this.dialogRef.close(res);
            }                
            else{
                this.dialogRef.close(res);
            }            
                
        });
        
    }

    public onCancel() {
        this.dialogRef.close(true);
    }
       
    public getIncludedStores(includedStores: any[]) {
       
        this.includedStoreList = [];
        this.includedStoreList = [...includedStores];
    }

    public getIncludedVendors(includedVendors: any[]) {
        
        this.includedVendorList = [];
        this.includedVendorList = [...includedVendors];     

        this.selectedVendorNumbers = this.includedVendorList.map(x => x.vendorNumber)

        this.getStoresServicedByVendor(this.selectedVendorNumbers);
    }

    public onAddVendors(): void {

        let dialogRef = this.dialog.open(DialogVendorOrgSearchComponent, {
            width: '1000px',
            data: { vendorType:'DSD' }
        });

        const sub = dialogRef.componentInstance.onAddVendorEmitEvent.subscribe((result) => {                       

            for (const opl of result) {
                if (!this.includedVendorList.find((self) => self.vendorNumber === opl.vendorNumber)) {
                    this.includedVendorList.push(opl);                    
                    
                } 
                if (this.vendorList.find((self) => self.vendorNumber === opl.vendorNumber)) {
                    this.vendorList.splice(this.vendorList.findIndex(e => e.vendorNumber == opl.vendorNumber), 1);
                }                         
            }          
                     
        });

        dialogRef.afterClosed().subscribe(result => {    

            if (result) {
               
                this.selectedVendorNumbers = this.includedVendorList.map(x => x.vendorNumber)
                this.getStoresServicedByVendor(this.selectedVendorNumbers);
            }   

        });

        //this.snackBar.open('Creating Vendor Store Authorization was not implemented', undefined, this.snackbarConfig);
    }


    /* Private Methods */

    private getDsdVendors(): void {

        this.dsdAuthRequestService.getDsdVendors().subscribe(res => {
            this.vendorList = res;
        })
    }

    private getDsdVendorsByUserId(userId: string): void {

        this.dsdAuthRequestService.getDsdVendorsByUserId(userId).subscribe(res => {
            this.vendorList = res;
        })
    }
    private getDsdVendorsExistForItemForm(itemFormID: number): void {
        this.dsdAuthRequestService.getDsdVendorsExistForItemForm(itemFormID).subscribe(res => {
            this.vendorList = res;
        })
    }


    private getStoresServicedByVendor(selectedVendorNumbers): void {

        this.createVendorStoreAuthForm.patchValue({ 'state': '' }); 

        if (selectedVendorNumbers.length < 1) {

            this.stateList = [];
            this.countyList = [];
            this.storeList = [];
            this.includedStoreList = [];
        }
        else {

            this.dsdAuthRequestService.getStoresServicedByVendor(selectedVendorNumbers).subscribe(res => {
                this.vendorServiceList = res;
                this.populateVendorServicedData();
            })
        }
    }

    private populateVendorServicedData() {

        this.stateList = [];
        this.countyList = [];
        this.storeList = [];
        this.includedStoreList = [];

      
        this.vendorServiceList.forEach(obj => {
            // Check if the id already exists in t 
            if (!this.stateList.find((self) => self.code === obj.stateCode)) {
                // If not, pushes obj to t
                this.stateList.push({
                    code: obj.stateCode,
                    description: obj.stateName
                });
            }
        });

        this.stateList = _.orderBy(this.stateList, ['description'], ['asc']);

    }

  
  }
