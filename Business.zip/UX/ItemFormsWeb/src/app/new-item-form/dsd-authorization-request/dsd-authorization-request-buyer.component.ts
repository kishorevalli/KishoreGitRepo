import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatPaginatorModule, MatSort, MatPaginator } from '@angular/material';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBarConfig } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { catchError, tap, map } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

import { GridEvent } from '../../shared/grid/grid-event';
import { IVendorAuthorizationDto, VendorAuthorizationDto, IVendorServiceDto, VendorServiceDto, IDsdVendorStoreAuthorizationDto, DsdVendorStoreAuthorizationDto } from './dsd-authorization-request.interface';
import { NewItemFormService } from '../new-item-form.service';
import { IItemFormDto, ItemFormDto } from '../new-item-form.interface';
import { IBasicItemDefnitionDto, BasicItemDefnitionDto } from '../basic-item-definition/basic-item-definition-interface';
import { IErrorDTO, ErrorDTO } from '../../shared/common.interface';
import { DsdAuthorizationRequestService } from './dsd-authorization-request.service';
import { DialogCreateVendorStoreAuthorizationComponent } from './dialog-create-vendor-store-authorization.component';
import { DialogViewVendorStoreAuthorizationComponent } from './dialog-view-vendor-store-authorization.component';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { DialogActionComponent } from '../common/dialogs/dialog-action.component';

@Component({
  selector: 'ifw-dsd-authorization-request-buyer',
  templateUrl: './dsd-authorization-request-buyer.component.html',
  styleUrls: ['./dsd-authorization-request-buyer.component.scss']
})
export class DsdAuthorizationRequestBuyerComponent implements OnInit {

    /* Variable Declarations */

    public itemFormDisplayID: number;
    public vendorAuthorizationList: IVendorAuthorizationDto[];

    // GRID
    public gridData: any[] = [];
    public pagination: boolean = true;
    public length: number;
    public pageSize: number = 5;
    public filterable: boolean = false;
    public filterBy: string = '';
    public filterValue: string = '';
    public sortable: boolean = true;
    public active: string = '';
    public direction: string = '';
    private gridEvent: GridEvent;

    public errorMessages: IErrorDTO[];
    //Snack Bar
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    snackbarConfig = new MatSnackBarConfig()

    public isDsdAuthMaintenaceRequest: boolean = false;
    private itemFormID: number;
    showSpinner: boolean = false;
    skipSaveTab: boolean = true;
    dsdErrorsList: string[];
    dsdWarningsList: string[];

     /* Constructor */

    constructor(
        private newItemFormService: NewItemFormService,
        private dsdAuthRequestService: DsdAuthorizationRequestService,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private router: Router,
        private route: ActivatedRoute) {
    }

     /* Events */

    ngOnInit() {

        this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        this.itemFormID = this.newItemFormService.itemFormID;

        if (this.newItemFormService.formTypeID == 3)
          this.isDsdAuthMaintenaceRequest = true;
        else
        this.isDsdAuthMaintenaceRequest = false;

        this.gridEvent = {
            pageIndex: 0,
            pageSize: this.pageSize,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };

        //Snackbar config
        this.snackbarConfig.verticalPosition = this.verticalPosition;
        this.snackbarConfig.horizontalPosition = this.horizontalPosition;
        this.snackbarConfig.duration = 3000;
        this.snackbarConfig.panelClass = 'custom-class';
        // this.snackbarConfig.direction = this.dir.value;        

        this.getVendorAuthorizations(this.gridEvent);
        

        let errorDTO: IErrorDTO = new ErrorDTO();
        errorDTO.tabName = 'DsdAuthRequest';
        errorDTO.severityLevel = 'Message';
        this.newItemFormService.GetErrorMessagesByType(errorDTO).subscribe(res => {
            this.errorMessages = res;
        });

        this.dsdErrorsList = [];
        this.dsdWarningsList = [];
    }


    ngOnDestroy() {
        //TODO Cleanup objects

    }

    public addVendorStoreAuthorizatiopns(): void {

        let dialogRefCreateVendorStoreAuth = this.dialog.open(DialogCreateVendorStoreAuthorizationComponent, {
            width: '1200px',
            height: '850px',
            data: { itemFormID: this.itemFormID }
        });

        dialogRefCreateVendorStoreAuth.afterClosed().subscribe(result => {


            if (result) {

                this.getVendorAuthorizations(this.gridEvent);
            }
            else {

                let data = {
                    title: "",
                    description: this.getMessage('DSD01'),//"There are existing overlapping vendor store Authorizations. Please fix overlaps!",
                    actions: [
                        "Ok"
                    ]
                }
                let dialogRefAction = this.dialog.open(DialogActionComponent, {
                    width: '500px',
                    disableClose: true,
                    hasBackdrop: true,
                    data: data
                });

                dialogRefAction.afterClosed().subscribe(result => {

                    let dialogRef = this.dialog.open(DialogViewVendorStoreAuthorizationComponent, {
                        width: '1200px',
                        disableClose: true,
                        hasBackdrop: true,
                        data: { itemFormID: this.itemFormID, showOnlyVendorAuthStores: false, showOnlyOverlappedStores: true }
                    });

                    dialogRef.afterClosed().subscribe(result => {

                        this.getVendorAuthorizations(this.gridEvent);
                    });
                });        


            }

        });

        //this.snackBar.open('Creating Vendor Store Authorization was not implemented', undefined, this.snackbarConfig);
    }

    public ViewVendorStoreAuthorizatiopns(): void {

        let dialogRef = this.dialog.open(DialogViewVendorStoreAuthorizationComponent, {
            width: '1200px',
            disableClose: true,
            hasBackdrop: true,
            data: { itemFormID: this.itemFormID, showOnlyVendorAuthStores: false }
        });

        dialogRef.afterClosed().subscribe(result => {

            if (result) {
                this.getVendorAuthorizations(this.gridEvent);
            }

        });

        //this.snackBar.open('View /Edit Vendor Store Authorization was not implemented', undefined, this.snackbarConfig);
    }

    public onSelectedVendor(vendorAuthorizationDto: VendorAuthorizationDto): void {

        let dialogRef = this.dialog.open(DialogViewVendorStoreAuthorizationComponent, {
            width: '1200px',
            data: { itemFormID: this.itemFormID, showOnlyVendorAuthStores: true, vendorNumber: vendorAuthorizationDto.vendorNumber, vendorName: vendorAuthorizationDto.vendorName }
        });
    }

    public getExistingVendorStoreAuthorizations(basicItemDef: IBasicItemDefnitionDto) {

      this.gridEvent = {
        pageIndex: 0,
        pageSize: this.pageSize,
        length: 0,
        active: this.active,
        direction: this.direction,
        filterBy: this.filterBy,
        filterValue: this.filterValue
      };
      this.getVendorAuthorizations(this.gridEvent);
    }

     /* Public Methods */

    //get Vendor # of store authrizations
    public getVendorAuthorizations(gridEvent: GridEvent): void {
       
        this.dsdAuthRequestService.getDsdVendorAuthorizations(this.itemFormID).subscribe(res => {
            this.vendorAuthorizationList = res;
            this.newItemFormService.GetItemFormErrors(this.newItemFormService.itemFormID).subscribe(res => {
                const validations: any = this.newItemFormService.getItemValidation("DSD Authorization Request");
                if (validations) {
                    this.handleDSDValidations(validations);
                }
            });
            this.gridData = this.vendorAuthorizationList;
            this.sortData(gridEvent);
            this.pageData(gridEvent);
        });           

    }

    handleDSDValidations(itemValidation) {
        let dsdErrors = itemValidation.errors;
        let dsdWarnings = itemValidation.warnings;
        this.handleDSDValidationErrors(dsdErrors);
        this.handleDSDValidationWarnings(dsdWarnings);

    }

    handleDSDValidationErrors(dsdErrors: any[]) {

        for (var key in dsdErrors) {
            let errorObj = dsdErrors[key];
            //for (var errorObj of gpaErrors) {
            this.dsdErrorsList.push(errorObj.errorDescription)
        }
    }

    handleDSDValidationWarnings(dsdErrors: any[]) {

        for (var key in dsdErrors) {
            let errorObj = dsdErrors[key];
            //for (var errorObj of gpaErrors) {
            this.dsdWarningsList.push(errorObj.errorDescription)
        }
    }

      /* Private Methods */


    private pageData(gridEvent: GridEvent): void {

        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

    /**
* sort the filtered result based on sort column and order
*/
    private sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }

        /* Action Menu methods */

    performAction(action: any) {
        switch (action.actionName) {
            case "Save":
                //TODO any Validations
                this.saveDsdAuthorizationRequest(action.createdFormStatusID, action.actionID);
                break;
            case "Delete":
                this.deleteItemForm();
                break;
            case "Submit":
                //TODO any Validations
                this.saveDsdAuthorizationRequest(action.createdFormStatusID, action.actionID);
                break;

        }
    }

    public saveDsdAuthorizationRequest(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            if (res) {
                this.snackBar.open("Saved successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });

            }
        });
    }

    public saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
        //TODO Validations

        this.showSpinner = true;
        return this.dsdAuthRequestService.isOverlappedVendorStoreAuthExistsByItemForm(this.itemFormID).pipe(
            map(res => {
                if (res) {          

                    let data = {
                        title: "",
                        description: this.getMessage('DSD01'),//"There are existing overlapping vendor store Authorizations. Please fix overlaps!",
                        actions: [
                            "Ok"
                        ]
                    }
                    let dialogRefAction = this.dialog.open(DialogActionComponent, {
                        width: '500px',
                        disableClose: true,
                        hasBackdrop: true,
                        data: data
                    });

                    dialogRefAction.afterClosed().subscribe(result => {

                        let dialogRef = this.dialog.open(DialogViewVendorStoreAuthorizationComponent, {
                            width: '1200px',
                            disableClose: true,
                            hasBackdrop: true,
                            data: { itemFormID: this.itemFormID, showOnlyVendorAuthStores: false, showOnlyOverlappedStores: true }
                        });

                        dialogRef.afterClosed().subscribe(result => {

                            //TODO Optimize
                            const gridEvent: GridEvent = {
                                pageIndex: 0,
                                pageSize: 10,
                                length: 0,
                                active: this.active,
                                direction: this.direction,
                                filterBy: this.filterBy,
                                filterValue: this.filterValue
                            };
                            if (result) {
                                this.getVendorAuthorizations(gridEvent);
                                return true;
                            }
                            else {
                                return false;
                            }
                        });
                    });     
                   
                    

                    this.showSpinner = false;
                }
                else {

                    let itemFormDto: IItemFormDto = new ItemFormDto();

                    itemFormDto.id = this.newItemFormService.itemFormID;
                    itemFormDto.formStatusID = createdFormStatusID == undefined ? this.newItemFormService.formCurrentStatusID : createdFormStatusID;
                    itemFormDto.formActionID = actionID;

                    this.newItemFormService.updateItemForm(itemFormDto).subscribe(res => {

                        this.showSpinner = false;
                    },
                        (err) => {
                            this.showSpinner = false;
                            if (err.status === 400) {
                                // handle validation error
                                let validationErrorDictionary = err.error.modelState;
                                //   this.handleGpaValidationErrors(validationErrorDictionary);
                            } else {
                                // this.formErrors.push("Unhandled expection occured.");
                            }
                            window.scrollTo(0, 0);
                        })

                    this.showSpinner = false;
                    return true;
                }


            }),
            catchError((err) => {
                this.showSpinner = false;
                if (err.status === 400) {
                    this.newItemFormService.addItemValidation(err.error);
                    //this.handleItemGpaValidation(err.error);
                }
                console.log("saved error. " + err.status);
                window.scrollTo(0, 150);
                return of(false);
            })
        );


    }

    public deleteItemForm(): void {
        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.showSpinner = true;
                this.newItemFormService.deleteItemForm().subscribe(res => {

                    this.showSpinner = false;
                    if (res != undefined) {
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" });
                },
                    (err) => {
                        this.showSpinner = false;
                        if (err.status === 400) {
                            // handle validation error
                            let validationErrorDictionary = err.error.modelState;
                            //   this.handleGpaValidationErrors(validationErrorDictionary);
                        } else {
                            // this.formErrors.push("Unhandled expection occured.");
                        }
                        window.scrollTo(0, 0);
                    })
            }
        });
    }

    public reset():void {
        
        this.getVendorAuthorizations(this.gridEvent);
    }

    /* Common methods  TODO Move the methods*/

    getMessage(code: string): string {
        let messageDesc: string = '';
        if (this.errorMessages.some(error => error.errorCode == code))
            messageDesc = this.errorMessages.find(error => error.errorCode == code).errorDescription
        else {
            messageDesc = ''
            console.log('Error code: ' + code + ' not exist in the DB')
        }
        return messageDesc;
    }

}
