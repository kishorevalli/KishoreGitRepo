import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import 'rxjs/add/operator/filter';

import { DsdAuthorizationRequestService } from './dsd-authorization-request.service';
import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto } from '../../shared/common.interface';
import { IBasicItemDefnitionDto, BasicItemDefnitionDto } from '../basic-item-definition/basic-item-definition-interface';
import { BasicItemDefinitionService } from '../basic-item-definition/basic-item-definition.service';
import { AuthService } from '../../core/services/auth.service';

import { DialogContentComponent } from '../basic-item-definition/dialog-content.component';
import { NewItemFormService } from '../new-item-form.service';
import { IGtinDto, GtinDto } from '../common/gtin-header/gtin.interface';
import { gtinValidator, GtinValidatorOptions, GTINValidatorHelper } from '../common/validators/gtin.validator';

@Component({
  selector: 'ifw-dsd-basic-item-definition',
  templateUrl: './dsd-basic-item-definition.component.html',
  styleUrls: ['./dsd-basic-item-definition.component.scss']
})
export class DsdBasicItemDefinitionComponent implements OnInit {

   /* Variable Declarations */
  dsdBasicItemDefFormGroup: FormGroup;
  @Output() onSearchEmitEvent: EventEmitter<IBasicItemDefnitionDto> = new EventEmitter<IBasicItemDefnitionDto>();
  public itemFormDisplayID: number;
  public itemFormID: number;
  public isExternal: boolean;
  public errors: string[];
  public formErrors: any;
  gtinHelper: GTINValidatorHelper;
  skipSaveTab: boolean = false;

  //Lookup dropdownlist
  public retailPackTypesList: ILookupDto[];
  public sizeUomList: ILookupDto[];

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  gtinValidatorOptions: GtinValidatorOptions = {
    validateCheckDigit: true,
    range: true,
    type2: true,
    dummy: true,
    vendorCoupon: true
  }

  /* Constructor */

  constructor(private _formBuilder: FormBuilder,
    private basicItemDefService: BasicItemDefinitionService,
    private dsdAuthRequestService: DsdAuthorizationRequestService,
    private auth: AuthService,
    public dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,
    public snackBar: MatSnackBar,
    private newItemFormService: NewItemFormService) { }

   /* Events */

  ngOnInit() {

    this.gtinHelper = new GTINValidatorHelper({});
    this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
    this.itemFormID = this.newItemFormService.itemFormID;
    this.isExternal = this.auth.isExternal;


    //Form controls
    this.dsdBasicItemDefFormGroup = this._formBuilder.group({
      itemFormID: this.itemFormID,
      formattedGtin: ['', [gtinValidator({
        validateCheckDigit: false,
        range: false,
        type2: this.isExternal,
        dummy: false,
        vendorCoupon: false
      })]],
      gtinCheckDigit: [''],
      existingGtinIndicator: 'Y',
      compressedUPC: ['', [Validators.minLength(6)]],
      priceLookupCode: ['', [Validators.minLength(5)]],
      submissionReasonID: { value: '1', disabled: true },
      itemCaseTypeID: { value: '1', disabled: true },
      retailPackagedItem: { value: '', disabled: true },
      sizeUOM: { value: '', disabled: true },
      retailPackType: { value: '', disabled: true },
      itemCode: [''],
      itemDescription: { value: '', disabled: true },
      brand: { value: '', disabled: true },
      manufacturer: { value: '', disabled: true },
      size: { value: '', disabled: true },
      retailPackSize: { value: '', disabled: true },
      labelAmount: { value: '', disabled: true },
      minorityManufacturer: { value: '', disabled: true },
      packageDescription: { value: '', disabled: true },
      containerType: { value: '', disabled: true },
      formActionID: { value: '', disabled: true },
      formTypeID: 3
    });


    this.getDropdownListData();

    this.getBasicItemDefinitionData();

    //Initialize

    this.errors = [];
    this.formErrors = {};
  }
   

  private getDropdownListData(): void {

    this.basicItemDefService.getRetailPackTypes().subscribe(res => {
      this.retailPackTypesList = res;
    });

    this.basicItemDefService.getUnitOfMeasures().subscribe(res => {
      this.sizeUomList = res;
    });

  }

  private getBasicItemDefinitionData() {

    if (this.itemFormDisplayID != undefined && this.itemFormDisplayID > 0) {
      this.basicItemDefService.getBasicItemDefinitionData(this.itemFormID).subscribe(res => {
        if (res != undefined) {
          this.populateBIDData(res);
          this.populateGtinHeaderDto();          
        }
      });
    }
  }

  private getBasicItemDefnitionDataByGTIN(): void {
    let basicItemDefinition = (<any>Object).assign({}, this.dsdBasicItemDefFormGroup.value);

    basicItemDefinition.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
    basicItemDefinition.existingGtinIndicator = 'Y';
    basicItemDefinition.vendorContactID = this.newItemFormService.vendorContactID;
    this.dsdAuthRequestService.getBasicItemDefnitionDataByGTIN(basicItemDefinition).subscribe(res => {
      this.onSearchEmitEvent.emit(res);
      this.populateGtinHeaderDto();
      //DSD
      this.populateBIDData(res);      
      this.errors = [];
    },
      (err) => {
        this.errors = [];
        this.errors.push("No matching item found. Please enter valid search criteria");
        this.onSearchEmitEvent.emit(basicItemDefinition);
        this.clearItemDetails();
      });

    //get data and populate.
  }
  
  public getBasicItemDefnitionDataByItemCode(itemId: any): void {

    if (itemId) {

      let basicItemDefinition = (<any>Object).assign({}, this.dsdBasicItemDefFormGroup.value);
      basicItemDefinition.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
      basicItemDefinition.formStatusID = 1;
      basicItemDefinition.existingGtinIndicator = 'Y';
      basicItemDefinition.vendorContactID = this.newItemFormService.vendorContactID;

      this.dsdAuthRequestService.getBasicItemDefnitionDataByItemCode(basicItemDefinition).subscribe(res => {
        this.onSearchEmitEvent.emit(res);
        this.populateBIDData(res);
        this.populateGtinHeaderDto();
        this.subscribeGTINValidations(false);
        this.dsdBasicItemDefFormGroup.patchValue({
          'formattedGtin': res.formattedGtin,
          'gtinCheckDigit': this.gtinHelper.getCheckdigit(res.formattedGtin),
          'priceLookupCode': '',
        });
        this.dsdBasicItemDefFormGroup.get('gtinCheckDigit').enable();
        this.errors = [];
      },
        (err) => {
          this.errors = [];
          this.errors.push("No matching item found. Please enter valid search criteria");
          this.onSearchEmitEvent.emit(basicItemDefinition);
          this.clearItemDetails();
        });
    }

  }
  
  private populateBIDData(basicItemDefnitionDto: IBasicItemDefnitionDto) {

    this.dsdBasicItemDefFormGroup.patchValue(basicItemDefnitionDto);
    this.newItemFormService.formTypeID = basicItemDefnitionDto.formTypeID;
    this.newItemFormService.formCurrentStatusID = basicItemDefnitionDto.formStatusID;
    this.showHideControlsOnInit();       
  }
  
  private showHideControlsOnInit() {
    // Disable GTINCheckDigit if there is a price look up value.
    if (this.dsdBasicItemDefFormGroup.get('priceLookupCode').value) {
      this.dsdBasicItemDefFormGroup.get('gtinCheckDigit').disable();
    }
  }
   
  public formatGtin(): void {
    this.clearCompUPCPLU({});// Fix if GTIN is copied instead keying in. Called the keypress event too 
    var formattedGtinControl = this.dsdBasicItemDefFormGroup.get('formattedGtin');
    let gtin = formattedGtinControl.value;
    if (gtin.length > 7) {
      formattedGtinControl.patchValue(this.gtinHelper.padGtin(gtin, 13));
      this.subscribeGTINValidations(true);
    }
    else {
      this.subscribeGTINValidations(false);
    }
    this.clearItemDetails();
  
  }

  public changeGTINCheckdigit(): void {
    let gtin = this.dsdBasicItemDefFormGroup.controls.formattedGtin.value;
    if (gtin.length > 7) {
      this.dsdBasicItemDefFormGroup.controls.formattedGtin.markAsTouched({ onlySelf: true });
      this.subscribeGTINValidations(true);
    }
    else {
      this.subscribeGTINValidations(false);
    }

  }
    
  public subscribeGTINValidations(isSubscribe: boolean) {
    const formattedGtin = this.dsdBasicItemDefFormGroup.controls.formattedGtin;
    if (isSubscribe) {
      formattedGtin.setValidators([gtinValidator(this.gtinValidatorOptions)]);
    }
    else {
      formattedGtin.setValidators([]);
    }
    formattedGtin.updateValueAndValidity();
  }

  public clearCompUPCPLU(e) {
    // Make the CompressedUPC empty if GTIN is manually updated or changed.
    this.dsdBasicItemDefFormGroup.patchValue({
      'compressedUPC': '',
      'priceLookupCode': '',
      'gtinCheckDigit': '',
      'itemCode': ''
    });
    this.dsdBasicItemDefFormGroup.get('gtinCheckDigit').enable();
  }
  
  public onSearch(): void {

    const formattedGtinControl = this.dsdBasicItemDefFormGroup.controls.formattedGtin;
    const compressedUPC = this.dsdBasicItemDefFormGroup.controls.compressedUPC;
    const priceLookupCode = this.dsdBasicItemDefFormGroup.controls.priceLookupCode;
    const itemCode = this.dsdBasicItemDefFormGroup.controls.itemCode;

    this.subscribeGTINValidations(false);

    if (this.dsdBasicItemDefFormGroup.valid) {

      if (formattedGtinControl.value) {
        this.dsdBasicItemDefFormGroup.patchValue({
          'compressedUPC': '',
          'priceLookupCode': '',
          'itemCode': ''
        });

        this.getBasicItemDefnitionDataByGTIN();
      }
      else if (compressedUPC.value) {
        this.ConvertCompressedUPCToGTIN(compressedUPC.value);
        this.dsdBasicItemDefFormGroup.patchValue({
          'formattedGtin': '',
          'gtinCheckDigit': null,
          'priceLookupCode': '',
          'itemCode': ''
        });
        this.getBasicItemDefnitionDataByGTIN();
      }
      else if (priceLookupCode.value) {
        this.ConvertPLUToGTIN(priceLookupCode.value);
        this.dsdBasicItemDefFormGroup.patchValue({
          'formattedGtin': '',
          'gtinCheckDigit': null,
          'compressedUPC': '',
          'itemCode': ''
        });
        this.getBasicItemDefnitionDataByGTIN();
      }
      else if (itemCode.value) {
        this.dsdBasicItemDefFormGroup.patchValue({
          'formattedGtin': '',
          'gtinCheckDigit': null,
          'compressedUPC': '',
          'priceLookupCode': ''
        });
        this.getBasicItemDefnitionDataByItemCode(itemCode.value);
      }
      else {
        //Show error
      }
     
    }

    

  }
    
  public onPriceLookupChange() {

    this.dsdBasicItemDefFormGroup.patchValue({
      'formattedGtin': '',
      'gtinCheckDigit': null,
      'compressedUPC': '',
      'itemCode': ''
    });
    this.errors = [];
    this.clearItemDetails();
    const formattedGtinControl = this.dsdBasicItemDefFormGroup.controls.formattedGtin;
    formattedGtinControl.setValidators(null);

  }

  public onCompressedUpcChange() {

    this.dsdBasicItemDefFormGroup.patchValue({
      'formattedGtin': '',
      'gtinCheckDigit': null,
      'priceLookupCode': '',
      'itemCode': ''
    });
    this.errors = [];
    this.clearItemDetails();
    const formattedGtinControl = this.dsdBasicItemDefFormGroup.controls.formattedGtin;
    formattedGtinControl.setValidators(null);
  }

  public onItemCodeChange() {

    this.dsdBasicItemDefFormGroup.patchValue({
      'formattedGtin': '',
      'gtinCheckDigit': null,
      'compressedUPC': '',
      'priceLookupCode': ''
    });
    this.errors = [];
    this.clearItemDetails();
    const formattedGtinControl = this.dsdBasicItemDefFormGroup.controls.formattedGtin;
    formattedGtinControl.setValidators(null);
  }

  public ConvertCompressedUPCToGTIN(newValue) {
    this.dsdBasicItemDefFormGroup.patchValue({
      'formattedGtin': '',
      'gtinCheckDigit': null,
      'priceLookupCode': '',
      'itemCode': ''
    });
    if (newValue && newValue.length == 6) {
      this.basicItemDefService.ConvertCompressedUPCToGTIN(newValue).subscribe(res => {
        this.subscribeGTINValidations(false);        
       
      });
    }
  }

  public ConvertPLUToGTIN(newValue) {
    this.dsdBasicItemDefFormGroup.patchValue({
      'formattedGtin': '',
      'gtinCheckDigit': null,
      'compressedUPC': '',
      'itemCode': ''
    });
    if (newValue && newValue.length == 5) {
      let newValueTwoChar: string = newValue.slice(0, 2);
      if (newValueTwoChar != '83' && newValueTwoChar != '84' && newValueTwoChar != '93' && newValueTwoChar != '94') {
        this.dsdBasicItemDefFormGroup.controls['priceLookupCode'].setErrors({ notvalid: true });
        this.dsdBasicItemDefFormGroup.controls['priceLookupCode'].markAsTouched({ onlySelf: true });
        return;
      }
      this.basicItemDefService.ConvertPLUToGTIN(newValue).subscribe(res => {
        this.subscribeGTINValidations(false);     
     
      });
    }
  }
    
  public resetBasicItemDef(): void {
    this.resetToInitialState();
    this.basicItemDefService.getBasicItemDefinitionData(this.itemFormID).subscribe(res => {
      if (res) {
        this.dsdBasicItemDefFormGroup.patchValue(res);       
      }
    });
  }

  public resetToInitialState() {

    this.errors = [];
    this.dsdBasicItemDefFormGroup.markAsPristine();
    this.dsdBasicItemDefFormGroup.markAsUntouched();
    
    const formattedGtinControl = this.dsdBasicItemDefFormGroup.controls.formattedGtin;
    formattedGtinControl.setValidators(null);

    this.dsdBasicItemDefFormGroup.patchValue({
      itemFormID: this.itemFormID,
      formattedGtin: '',
      gtinCheckDigit: null,
      existingGtinIndicator: '',
      compressedUPC: '',
      priceLookupCode: '',
      submissionReasonID: 1,
      itemCaseTypeID: 1,
      retailPackagedItem: '',
      sizeUOM: '',
      retailPackType: '',
      itemCode: '',
      itemDescription: '',
      brand: '',
      manufacturer: '',
      size: '',
      retailPackSize: '',
      labelAmount: '',
      minorityManufacturer: '',
      packageDescription: '',
      containerType: '',
      formActionID: ''
    });

  }

  private clearItemDetails() {
    this.dsdBasicItemDefFormGroup.patchValue({
      retailPackagedItem: '',
      sizeUOM: '',
      retailPackType: '',
      itemDescription: '',
      size: '',
      retailPackSize: ''
    });

  }
 
  public populateGtinHeaderDto(): void {
    let gtinDto: GtinDto = new GtinDto();
    gtinDto.formattedGtin = this.dsdBasicItemDefFormGroup.get('formattedGtin').value;
    gtinDto.gtinCheckDigit = this.dsdBasicItemDefFormGroup.get('gtinCheckDigit').value;
    gtinDto.compressedUPC = this.dsdBasicItemDefFormGroup.get('compressedUPC').value;
    gtinDto.priceLookupCode = this.dsdBasicItemDefFormGroup.get('priceLookupCode').value;
    gtinDto.itemCode = this.dsdBasicItemDefFormGroup.get('itemCode').value;
    gtinDto.itemDescription = this.dsdBasicItemDefFormGroup.get('itemDescription').value;

    this.newItemFormService.setGtinHeaderDetails(gtinDto);
  }
  
  public getErrorMessage(control: FormControl, name: string) {
    for (let propertyName in control.errors) {
      if ((propertyName == 'invalid' || propertyName == 'warning') && this.formErrors[name]) {
        return this.formErrors[name];
      }
      if (control.errors.hasOwnProperty(propertyName) && control.touched) {
        return this.getValidatorErrorMessage(propertyName, control.errors[propertyName]);
      }
    }
    return null;
  }

  public getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
    let config = {
      'notvalid': 'This is not a valid value',
      'email': 'This is not a valid email',
      'minlength': `This field should have atleast ${validatorValue.requiredLength} characters`,
      //'beforePadding': 'This field is required.',
      'range': 'GTIN entered must be in range 000-00010-00000 to 999-99999-99999.',
      'type2': 'GTIN entered is reserved for type -2 GTIN&quot;s.',
      'dummy': 'GTIN entered is reserved for Dummy GTIN&quot;s.',
      'vendorCoupon': 'GTIN entered is reserved for Vendor Coupons.',
      'checkDigitRequired': 'GTIN Check digit is required to validate GTIN.',
      'checkDigit': 'GTIN is not valid for the entered check digit.',
    };
    return config[validatorName];
  }

}
