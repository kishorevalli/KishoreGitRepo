type CharBoolean = 'Y' | 'N';
export interface IVendorAuthorizationDto {
    itemFormID?: number;
    vendorNumber: number;
    vendorName: string;
    organizationID?: number;
    organizationName?: string;
    noOfStores?: number;
}

export class VendorAuthorizationDto implements IVendorAuthorizationDto {
    itemFormID?: number;
    vendorNumber: number;
    vendorName: string;
    organizationID?: number;
    organizationName?: string;
    noOfStores?: number;
}

export interface IVendorServiceDto {
    itemFormID?: number;
    itemFormDisplayID?: number;
    vendorNumber: number;
    vendorName: string;
    storeNumber: number;
    stateCode: string;
    stateName: string;
    countyCode: string;
    countyName: string;
    isActive: CharBoolean;
    isDirty: boolean;
    isOnlyOverlappedAuth: boolean;
}

export class VendorServiceDto implements IVendorServiceDto {
    itemFormID?: number;
    itemFormDisplayID?: number;
    vendorNumber: number;
    vendorName: string;
    storeNumber: number;
    stateCode: string;
    stateName: string;
    countyCode: string;
    countyName: string;
    isActive: CharBoolean;
    isDirty: boolean;
    isOnlyOverlappedAuth: boolean = false;
}

export interface IDsdVendorStoreAuthorizationDto {
    itemFormID: number;
    gtin: number;
    vendorNumbers: number[];
    storeNumbers: number[];
    isAllServicedStores: boolean;
}

export class DsdVendorStoreAuthorizationDto implements IDsdVendorStoreAuthorizationDto {
    itemFormID: number;
    gtin: number;
    vendorNumbers: number[];
    storeNumbers: number[];
    isAllServicedStores: boolean = false;
}
