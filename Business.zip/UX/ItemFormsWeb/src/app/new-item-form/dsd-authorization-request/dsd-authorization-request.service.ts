import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { APP_CONFIG, AppConfig } from '../../app.config';
import { IVendorAuthorizationDto, IVendorServiceDto, IDsdVendorStoreAuthorizationDto } from './dsd-authorization-request.interface';

import { IBasicItemDefnitionDto, BasicItemDefnitionDto } from '../basic-item-definition/basic-item-definition-interface';

@Injectable()
export class DsdAuthorizationRequestService {

    private baseUrl;
    private serviceBase: string = 'api/DsdAuthorizationRequest/';

    constructor( @Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {

        this.baseUrl = config.apiEndpoint;
    }


    getDsdVendors(): Observable<IVendorAuthorizationDto[]> {

        return this.httpClient.get<IVendorAuthorizationDto[]>(this.baseUrl + this.serviceBase + 'GetDsdVendors');
    }

    getDsdVendorsByUserId(userId: string): Observable<IVendorAuthorizationDto[]> {

        return this.httpClient.get<IVendorAuthorizationDto[]>(this.baseUrl + this.serviceBase + `GetDsdVendorsByUserId?userId=${userId}`);
    }

    getStoresServicedByVendor(vendorNumbers: any): Observable<IVendorServiceDto[]> {

        return this.httpClient.post<IVendorServiceDto[]>(this.baseUrl + this.serviceBase + 'GetStoresServicedByVendor', vendorNumbers);
    }

    saveDsdVendorStoreAuthorization(dsdVendorStoreAuthorizationDto: IDsdVendorStoreAuthorizationDto): Observable<boolean> {

        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'SaveDsdVendorStoreAuthorization', dsdVendorStoreAuthorizationDto);
    }

    getDsdVendorAuthorizations(itemFormID: number): Observable<IVendorAuthorizationDto[]> {

        return this.httpClient.get<IVendorAuthorizationDto[]>(this.baseUrl + this.serviceBase + `GetDsdVendorAuthorizations?itemFormID=${itemFormID}`);
    }

    getAuthorizedDsdVendorsByItemForm(itemFormID: number): Observable<IVendorAuthorizationDto[]> {

        return this.httpClient.get<IVendorAuthorizationDto[]>(this.baseUrl + this.serviceBase + `GetAuthorizedDsdVendorsByItemForm?itemFormID=${itemFormID}`);
    }

    getDsdVendorStoreAuthorizationsBySearchCriteria(vendorServiceDto: IVendorServiceDto): Observable<IVendorServiceDto[]> {

        return this.httpClient.post<IVendorServiceDto[]>(this.baseUrl + this.serviceBase + 'GetDsdVendorStoreAuthorizationsBySearchCriteria', vendorServiceDto);
    }

    getDSDVendorDataForInternalUser(): Observable<IVendorAuthorizationDto[]> {

        return this.httpClient.get<IVendorAuthorizationDto[]>(this.baseUrl + this.serviceBase + 'GetDSDVendorDataForInternalUser');
    }

    validateAndSaveDsdVendorStoreAuthorization(vendorServiceDtoList: IVendorServiceDto[]): Observable<boolean> {

        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'ValidateAndSaveDsdVendorStoreAuthorization', vendorServiceDtoList);
    }

    getDsdOverlappedVendorStoreAuthorizationsByItemForm(itemFormID: number): Observable<IVendorServiceDto[]> {

        return this.httpClient.get<IVendorServiceDto[]>(this.baseUrl + this.serviceBase + `GetDsdOverlappedVendorStoreAuthorizationsByItemForm?itemFormID=${itemFormID}`);
    }

    isOverlappedVendorStoreAuthExistsByItemForm(itemFormID: number): Observable<IVendorServiceDto[]> {

        return this.httpClient.get<IVendorServiceDto[]>(this.baseUrl + this.serviceBase + `IsOverlappedVendorStoreAuthExistsByItemForm?itemFormID=${itemFormID}`);
    }

    isMultipleDsdVendorsSubmittingSameGtin(dsdVendorStoreAuthorizationDto: IDsdVendorStoreAuthorizationDto): Observable<boolean> {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'IsMultipleDsdVendorsSubmittingSameGtin', dsdVendorStoreAuthorizationDto);
    }

    isOverlappedVendorStoreAuthExistsByGtin(dsdVendorStoreAuthorizationDto: IDsdVendorStoreAuthorizationDto): Observable<boolean> {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'IsOverlappedVendorStoreAuthExistsByGtin', dsdVendorStoreAuthorizationDto);
    }

    getDsdOverlappedVendorStoreAuthorizationsByGtin(gtin: number): Observable<IVendorServiceDto[]> {

        return this.httpClient.get<IVendorServiceDto[]>(this.baseUrl + this.serviceBase + `GetDsdOverlappedVendorStoreAuthorizationsByGtin?gtin=${gtin}`);
    }

    getBasicItemDefnitionDataByItemCode(basicItemDefnitionDto: IBasicItemDefnitionDto) {
        return this.httpClient.post<IBasicItemDefnitionDto>(this.baseUrl + this.serviceBase + 'GetBasicItemDefnitionDataByItemCode', basicItemDefnitionDto);
    }

    getBasicItemDefnitionDataByGTIN(basicItemDefnitionDto: IBasicItemDefnitionDto) {
        return this.httpClient.post<IBasicItemDefnitionDto>(this.baseUrl + this.serviceBase + 'GetBasicItemDefnitionDataByGTIN', basicItemDefnitionDto);
    }
    
    getDsdVendorsExistForItemForm(itemFormID: number): Observable<IVendorAuthorizationDto[]> {
        return this.httpClient.get<IVendorAuthorizationDto[]>(this.baseUrl + this.serviceBase + `GetDsdVendorsExistForItemForm?itemFormID=${itemFormID}`);
    }
}
