import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatPaginatorModule, MatSort, MatPaginator } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, AbstractControl } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBarConfig } from '@angular/material';
import { of } from 'rxjs/observable/of';
import { from } from 'rxjs/observable/from';
import { catchError, tap, map } from 'rxjs/operators';
import * as _ from 'lodash';

import { GridEvent } from '../../shared/grid/grid-event';
import { NewItemFormService } from '../new-item-form.service';
import { DsdAuthorizationRequestService } from './dsd-authorization-request.service';
import { IVendorAuthorizationDto, VendorAuthorizationDto, IVendorServiceDto, VendorServiceDto, IDsdVendorStoreAuthorizationDto, DsdVendorStoreAuthorizationDto } from './dsd-authorization-request.interface';
import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto } from '../../shared/common.interface';


@Component({
  selector: 'ifw-dialog-view-vendor-store-authorization',
  templateUrl: './dialog-view-vendor-store-authorization.component.html',
  styleUrls: ['./dialog-view-vendor-store-authorization.component.scss']
})
export class DialogViewVendorStoreAuthorizationComponent implements OnInit {

    /* Variable Declarations */
    public viewVendorStoreAuthForm: FormGroup;
    public pageTitle: string = '';
    public vendorList: IVendorAuthorizationDto[] = [];
    public stateList: IVendorServiceDto[] = [];
    public countyDbList: IVendorServiceDto[] = [];
    public countyList: IVendorServiceDto[] = [];
    public filteredVendorStoreAuthorizationList: IVendorServiceDto[] = [];
    public vendorStoreAuthorizationList: IVendorServiceDto[] = [];
    public itemFormID: number;
    public showOnlyVendorAuthStores: boolean = false;
    public selectedVendorNumber: number;
    public selectedVendorName: string;
    public showOnlyOverlappedStores: boolean = false;
    public showOverlappedFilter: boolean = false;
    public showSpinner: boolean = false;
    public showSaveSpinner: boolean = false;
    public gtin: number;
    public showItemFormId: boolean = false;

    // GRID
    public gridData: any[] = [];
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = false;
    public filterBy: string = '';
    public filterValue: string = '';
    public sortable: boolean = false;
    public active: string = '';
    public direction: string = '';

    private gridEvent: GridEvent;

    //Snack Bar
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    snackbarConfig = new MatSnackBarConfig()

    /* Properties */

    get selectedVendor(): AbstractControl {
        return this.viewVendorStoreAuthForm.get('vendorNumber');
    }

    get selectedState(): AbstractControl {
        return this.viewVendorStoreAuthForm.get('stateCode');
    }

    get selectedCounty(): AbstractControl {
        return this.viewVendorStoreAuthForm.get('countyCode');
    }

    get selectedStore(): AbstractControl {
        return this.viewVendorStoreAuthForm.get('storeNumber');
    }

    get getOverlappedAuth(): AbstractControl {
        return this.viewVendorStoreAuthForm.get('isOnlyOverlappedAuth');
    }
      
    /* Contructor */

    constructor(private newItemFormService: NewItemFormService,
        private dsdAuthRequestService: DsdAuthorizationRequestService,
        private formBuilder: FormBuilder,
        public dialogRef: MatDialogRef<DialogViewVendorStoreAuthorizationComponent>,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any,               
        public snackBar: MatSnackBar) {

        this.createForm();
    }

    ngOnInit() {

        this.initialize();
  }


    private createForm(): void {

        this.viewVendorStoreAuthForm = this.formBuilder.group({
            'vendorNumber': [''],
            'stateCode': [''],
            'countyCode': [''],
            'storeNumber': '',
            'isOnlyOverlappedAuth': [false]
        });
    }

    private initialize() {

        this.gridEvent = {
            pageIndex: 0,
            pageSize: this.pageSize,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };

        //Snackbar config
        this.snackbarConfig.verticalPosition = this.verticalPosition;
        this.snackbarConfig.horizontalPosition = this.horizontalPosition;
        this.snackbarConfig.duration = 3000;
        this.snackbarConfig.panelClass = 'custom-class';


        this.itemFormID = this.data.itemFormID;
        //View Stores By Vendor
        this.showOnlyVendorAuthStores = this.data.showOnlyVendorAuthStores;
        this.selectedVendorNumber = this.data.vendorNumber;
        this.selectedVendorName = this.data.vendorName;

        this.showOnlyOverlappedStores = this.data.showOnlyOverlappedStores;

        this.gtin = this.data.gtin;

        this.loadData();      
       
    }


    /* Events */
       
   
    public onStateSelect(): void {

        this.countyList = [];
        this.viewVendorStoreAuthForm.patchValue({ 'countyCode': '' });

        let state: string = this.selectedState.value;

        if (state) {

            let tempList: any[] = _.filter(this.vendorStoreAuthorizationList, { 'stateCode': state });

            tempList.forEach(obj => {
                if (!this.countyList.find((self) => self.countyCode === obj.countyCode)) {
                    this.countyList.push(obj);
                }
            });

            this.countyList = _.orderBy(this.countyList, ['countyName'], ['asc']);
        }
        else {
            this.countyList = [];
        }

    }
  
    public onApplyFilter() {           
       

        let tempList: IVendorServiceDto[] = [];        

        tempList = [...this.vendorStoreAuthorizationList];

        if (this.selectedVendor.value) {

            tempList = [... (tempList.filter(x => x.vendorNumber == this.selectedVendor.value))];
        }

        if (this.selectedState.value) {

            tempList = [... (tempList.filter(x => x.stateCode == this.selectedState.value))];
        }
        if (this.selectedCounty.value) {

            tempList = [... (tempList.filter(x => x.countyCode == this.selectedCounty.value))];
        }
        if (this.selectedStore.value) {

            tempList = [... (tempList.filter(x => x.storeNumber == this.selectedStore.value))] ;          
        }
                
        this.filteredVendorStoreAuthorizationList = [];
        tempList.forEach(obj => {
            this.filteredVendorStoreAuthorizationList.push(obj);
        });

        this.gridData = this.performFilter(this.gridEvent);
        this.sortData(this.gridEvent);
        this.pageData(this.gridEvent);

        //this.getDsdVendorStoreAuthorizationsBySearchCriteria(this.gridEvent);
    }

    public onResetFilter() {
        if (this.viewVendorStoreAuthForm.touched && this.viewVendorStoreAuthForm.dirty) {
            this.viewVendorStoreAuthForm.reset();
            this.loadData();
        }       
    }

    public onFilterOverlappingAuth() {        

        this.getDsdVendorStoreAuthorizationsBySearchCriteria(this.gridEvent);
    }

    public onAuthorizedVendorSelect(row: IVendorServiceDto, checked: boolean) {

        if (checked) {
            row.isActive = 'Y';
        }
        else {
            row.isActive = 'N';
        }
        row.isDirty = true;  
    }

    public onSave() {        
        this.showSaveSpinner = true;
        this.dsdAuthRequestService.validateAndSaveDsdVendorStoreAuthorization(this.filteredVendorStoreAuthorizationList).subscribe(res => {
            if (res) {                
                this.snackBar.open('Vendor Store Authorization was updated Successfully', undefined, this.snackbarConfig);
                this.dialogRef.close(true);
                this.showSaveSpinner = false;
            }               
            else {
                this.snackBar.open('Please fix the Overlap Stores and Save', undefined, this.snackbarConfig);
                this.showSaveSpinner = false;
            }               
            
        });
    }

    public onCancel() {
        this.dialogRef.close(false);
    }

    public onClose() {
        this.dialogRef.close(false);
    }

    /* Public Methods */

    

    public getDsdVendorStoreAuthorizationsBySearchCriteria(gridEvent: GridEvent): void {

        this.showSpinner = true;

        let filterSearch: IVendorServiceDto = new VendorServiceDto();

        filterSearch.itemFormID = this.itemFormID;
        if (this.showOnlyVendorAuthStores && this.selectedVendorNumber) {
            filterSearch.vendorNumber = this.selectedVendorNumber
            filterSearch.isActive = 'Y';
        }

        filterSearch.isOnlyOverlappedAuth = this.getOverlappedAuth.value;
        
        this.dsdAuthRequestService.getDsdVendorStoreAuthorizationsBySearchCriteria(filterSearch).subscribe(res => {
            this.vendorStoreAuthorizationList = res;
            this.filteredVendorStoreAuthorizationList = [];
            //this.vendorStoreAuthorizationList.forEach(obj => {
            //    this.filteredVendorStoreAuthorizationList.push(obj);                
            //});
            this.filteredVendorStoreAuthorizationList = [...this.vendorStoreAuthorizationList];
            this.getAuthorizedDsdVendorsByItemForm(this.vendorStoreAuthorizationList);
            this.getAuthorizedDsdStatesByItemForm(this.vendorStoreAuthorizationList);
            this.getAuthorizedDsdCountiesByItemForm(this.vendorStoreAuthorizationList);
          
            this.gridData = this.performFilter(gridEvent);
            this.sortData(gridEvent);
            this.pageData(gridEvent);
            this.showSpinner = false;
        },
            (err) => {
                this.showSpinner = false;
            })
    }

    public getDsdOverlappedVendorStoreAuthorizationsByGtin(gridEvent: GridEvent): void {

        this.showSpinner = true;        

        this.dsdAuthRequestService.getDsdOverlappedVendorStoreAuthorizationsByGtin(this.gtin).subscribe(res => {
            this.vendorStoreAuthorizationList = res;
            this.gridData = this.vendorStoreAuthorizationList;
           
            this.showSpinner = false;
        },
            (err) => {
                this.showSpinner = false;
            })
    }


   
    public getAuthorizedDsdVendorsByItemForm(vendorStoreAuthorizationList: IVendorServiceDto[]): void {

        vendorStoreAuthorizationList.forEach(obj => {
            // Check if the id already exists in t 
            if (!this.vendorList.find((self) => self.vendorNumber === obj.vendorNumber)) {
                // If not, pushes obj to t
                this.vendorList.push({
                    vendorNumber: obj.vendorNumber,
                    vendorName: obj.vendorName
                });
            }
        });

        this.vendorList = _.orderBy(this.vendorList, ['vendorName'], ['asc']);
    }

   
    /* Private Methods */

    private loadData(): void {

        if (this.gtin) {
            this.viewVendorStoreAuthForm.patchValue({ 'isOnlyOverlappedAuth': this.showOnlyOverlappedStores });
            this.pageTitle = 'DSD Authorization - Overlap Resolution';
            this.pagination = false;
            this.sortable = false;
            this.filterable = false;
            this.showItemFormId = true;
            this.getDsdOverlappedVendorStoreAuthorizationsByGtin(this.gridEvent);
        }
        else {
            if (this.showOnlyVendorAuthStores) {
                if (this.selectedVendorNumber && this.data.vendorName) {
                    this.pagination = true;
                    this.sortable = true;
                    this.filterable = true;
                    this.pageTitle = 'Stores Authorized for Vendor: ' + this.selectedVendorNumber.toString() + ' - ' + this.selectedVendorName;
                }

            }
            else {

                if (this.showOnlyOverlappedStores) {
                    this.viewVendorStoreAuthForm.patchValue({ 'isOnlyOverlappedAuth': this.showOnlyOverlappedStores });
                    this.pageTitle = 'DSD Authorization - Overlap Resolution';
                }
                else {
                    this.pagination = false;
                    this.sortable = false;
                    this.filterable = false;
                    this.pageTitle = 'View / Edit Vendor Store Authorizations';
                    this.isOverlappedVendorStoreAuthExistsByItemForm();
                }

            }

            this.getDsdVendorStoreAuthorizationsBySearchCriteria(this.gridEvent);
        }

      
    }

    private getAuthorizedDsdStatesByItemForm(vendorStoreAuthorizationList: IVendorServiceDto[]): void {

        vendorStoreAuthorizationList.forEach(obj => {
            // Check if the id already exists in t 
            if (!this.stateList.find((self) => self.stateCode === obj.stateCode)) {
                // If not, pushes obj to t
                this.stateList.push(obj);
            }
        });

        this.stateList = _.orderBy(this.stateList, ['stateName'], ['asc']);
    }

    private getAuthorizedDsdCountiesByItemForm(vendorStoreAuthorizationList: IVendorServiceDto[]): void {

        vendorStoreAuthorizationList.forEach(obj => {
            // Check if the id already exists in t 
            if (!this.countyList.find((self) => self.countyCode === obj.countyCode)) {
                // If not, pushes obj to t
                this.countyList.push(obj);
            }
        });

        this.countyList = _.orderBy(this.countyList, ['countyName'], ['asc']);
    }

    private isOverlappedVendorStoreAuthExistsByItemForm(): void {

        this.dsdAuthRequestService.isOverlappedVendorStoreAuthExistsByItemForm(this.itemFormID).subscribe(res => {
            if (res)
                this.showOverlappedFilter = true;
            else
                this.showOverlappedFilter = false;
        })
    }

    /* Grid Methods */

    private performFilter(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {

                return this.filteredVendorStoreAuthorizationList.filter((row: any) => {
                    let dataStr;
                    if (this.filterBy == 'isActive') {
                        const accumulator = (currentTerm, key) => currentTerm + row[key];
                        dataStr = Object.keys(row).reduce(accumulator, '').toLowerCase();
                    }
                    else {
                        // Transform the data into a lowercase string of all property values.
                        dataStr = ('' + row[this.filterBy]).toLowerCase();
                    }

                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.filteredVendorStoreAuthorizationList.slice();
        }
        return this.filteredVendorStoreAuthorizationList.slice();
    }

    private pageData(gridEvent: GridEvent): void {

        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

        /**
     * sort the filtered result based on sort column and order
     */
    sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }
}
