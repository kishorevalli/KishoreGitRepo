﻿import { IBasicItemDefnitionDto, BasicItemDefnitionDto } from '../new-item-form/basic-item-definition/basic-item-definition-interface';

export interface IItemFormDto {
    id: number;
    itemFormDisplayID: number;
    formTypeID: number;
    submissionDate: string;
    submittedBy: string;
    submittedUserTypeID: number;
    createdByUserTypeID: number;
    formStatusID: number;
    formActionID: number;
    pendingRoleUserTypeId: number;
    dsdAuthRequestSelectStoreOption: string;
    itemCreatedDateTime: string;
    vendorContactID: string;    
    vendorContactName: string;    
    vendorContactEmail: string;    
    parentFlag: string;
    isInGroup: string;
    groupID: string;
    buyerID?: number;
    buyerName: string;
    createdBy: string;
    createdDate: string;
    lastUpdatedBy: string;
    lastUpdatedDate?: Date;
    itemFormErrorCount?: number;
    basicItemDefinition: IBasicItemDefnitionDto;
}

export class ItemFormDto implements IItemFormDto{
    id: number;
    itemFormDisplayID: number;
    formTypeID: number;
    submissionDate: string;
    submittedBy: string;
    submittedUserTypeID: number;
    createdByUserTypeID: number;
    formStatusID: number;
    formActionID: number;
    pendingRoleUserTypeId: number;
    dsdAuthRequestSelectStoreOption: string;
    itemCreatedDateTime: string;
    vendorContactID: string;      
    vendorContactName: string;    
    vendorContactEmail: string;  
    parentFlag: string;
    isInGroup: string;
    groupID: string;
    buyerID?: number;
    buyerName: string;
    createdBy: string;
    createdDate: string;
    lastUpdatedBy: string;
    lastUpdatedDate?: Date;
    itemFormErrorCount?: number;
    basicItemDefinition: IBasicItemDefnitionDto;
}

export interface NewItemTab{
    id: number;
    name: string;
    link: string;
    disabled: boolean;
}

export enum UserType
{
    ALL = 0,
    Vendor,
    Buyer,
    Clerical,
    MfgClerical,
    MfgBDD,   
    CategoryMgr,
    
};

export interface IFormUserPermittedActionDto {
    rowId: Number;
    itemFormID: Number;
    formTypeId: Number
    currentFormStatusID: Number;
    currentFormStatus: string;
    vendorActionName: string;
    buyerActionName: string;
    formActionID: Number
    createdFormStatusID: Number;
    createdFormStatus: string;
    actionComment: string
    currentStatusId: Number;
    currentStatusName: string;
    currentFormStatusComment: string;
    createdFormStatusComment: string;
    lastUpdatedBy: string;
    userTypeID: string;
}


export class FormUserPermittedActionDto implements IFormUserPermittedActionDto {
    rowId: Number;
    itemFormID: Number;
    formTypeId: Number
    currentFormStatusID: Number;
    currentFormStatus: string;
    vendorActionName: string;
    buyerActionName: string;
    formActionID: Number
    createdFormStatusID: Number;
    createdFormStatus: string;
    actionComment: string
    currentStatusId: Number;
    currentStatusName: string;
    currentFormStatusComment: string;
    createdFormStatusComment: string;
    lastUpdatedBy: string;
    userTypeID: string;
}

export interface IVendorDomainDto {
    vendorNumber: number;
    vendorName: string;
    organizationID?: number;
    organizationName?: string;

    vendorType?: string;
    searchType?: string;
    searchString?: string;
    checked: boolean;
}

export class VendorDomainDto implements IVendorDomainDto {
    vendorNumber: number;
    vendorName: string;
    organizationID?: number;
    organizationName?: string;

    vendorType?: string;
    searchType?: string;
    searchString?: string;
    checked: boolean;
}

export interface IGTINWithCheckdigitDto {    
    formattedGtin: string;
    gtinCheckDigit: number;
}

export class GTINWithCheckdigitDto implements IGTINWithCheckdigitDto{
    formattedGtin: string;
    gtinCheckDigit: number;
}
