import { FormControl } from '@angular/forms';

export interface GtinValidatorOptions {
    range?: boolean;
    type2?: boolean;
    dummy?: boolean;
    vendorCoupon?: boolean;
    validateCheckDigit?: boolean;
    checkDigitCtrlName?:string;
}

export function gtinValidator(options: GtinValidatorOptions) {    
    let thisControl: FormControl;
    let gtinCheckDigitControl: FormControl;
    const validator = new GTINValidatorHelper(options);
    return function validateGTIN(control: FormControl) {
        if (!control.parent) {
            return null;
        }
        // Initializing the validator.
        if (!thisControl) {
            thisControl = control;
            const gtinCheckDigitCtrlName = options.checkDigitCtrlName || "gtinCheckDigit";
            gtinCheckDigitControl = control.parent.get(gtinCheckDigitCtrlName) as FormControl;
            if (options.validateCheckDigit && !gtinCheckDigitControl ) {
                throw new Error('gtinValidator(): GTIN CheckDigit Control is not found in parent group');
            }
            gtinCheckDigitControl.valueChanges.subscribe(() => {
                thisControl.updateValueAndValidity();
            });
            
        }
       
        return validator.validate(control.value, gtinCheckDigitControl);
    }
}

export class GTINValidatorHelper {
    constructor(private options: GtinValidatorOptions) {
    }
    validate(value: string, gtinCheckDigitControl?: FormControl): any {

        if (!value || value.length < 15) {
            return { beforePadding: true };
        }

        // Range.
        if (this.options.range) {
            let rangeValue = value.slice(0, 8);
            let rangeRestrictedValue = value.slice(0, 9);
            if (rangeValue == "000-0000" || rangeRestrictedValue == "000-41415") {
                return { range: true };
            }
        }
        let rangeVendorValue = value.slice(0, 3);

        // type2
        if (this.options.type2 && (rangeVendorValue == "002")) {
            return { type2: true };
        }

        // dummy.
        if (this.options.dummy && (rangeVendorValue == "004")) {
            return { dummy: true };
        }

        // vendor Coupon.
        if (this.options.vendorCoupon && (rangeVendorValue == "005")) {
            return { vendorCoupon: true };
        }
        //Gtin Checkdigit
        if (this.options.validateCheckDigit) {
            if(!gtinCheckDigitControl || (!gtinCheckDigitControl.value  && gtinCheckDigitControl.value !== 0)){
                return {
                    checkDigitRequired: true
                };
            }
            const checkinDigit = this.getCheckdigit(value);
            console.log(checkinDigit);
            if (gtinCheckDigitControl.value != checkinDigit) {
                return {
                    checkDigit: true
                };
            }
        }
        return null;

    }
    getCheckdigit(gtin: string): number {
        let _gtin = gtin.replace(/-/g, "");
        let checkdigit = 0;
        var gtinArray: string[] = _gtin.split('');
        // Lets say the GTIN is 036-00024-14500
        //1.	Add the odd number digits: 0 + 6+ 0 + 2 + 1 + 5 + 0 = 14.
        var oddDigitSum = +gtinArray[0] + +gtinArray[2] + +gtinArray[4] + +gtinArray[6] + +gtinArray[8] + +gtinArray[10] + +gtinArray[12];
        //2.Multiply the result by 3: 14 × 3 = 42.
        var oddDigitMultiply = oddDigitSum * 3;
        //3.Add the even number digits: 3 + 0 + 0 + 4 + 4 + 0 = 11.
        var evenDigitSum = +gtinArray[1] + +gtinArray[3] + +gtinArray[5] + +gtinArray[7] + +gtinArray[9] + +gtinArray[11];
        //4.Add the two results together: 42 + 11 = 53.
        var totalSum = oddDigitMultiply + +evenDigitSum;
        var modValue = totalSum % 10;
        checkdigit = (modValue) ? 10 - modValue : 0;
        return checkdigit;
    }
    padGtin(num: string, size: number): string {
        let s = num.replace(/-/g, "");
        while (s.length < size) s = "0" + s;
        return s.slice(0, 3) + "-" + s.slice(3, 8) + "-" + s.slice(8);
    }
}
