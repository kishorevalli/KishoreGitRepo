﻿export interface IGtinDto {
    itemFormDisplayID: number;
    formattedGtin: string;
    gtinCheckDigit: number;
    compressedUPC: string;
    priceLookupCode: string;
    modelProductItemcode: number;
    modelPackagingItemCode: number;
    itemCode: number;
    itemDescription: string;
    modelItemDescription: string;
}

export class GtinDto implements IGtinDto {
    itemFormDisplayID: number;
    formattedGtin: string;
    gtinCheckDigit: number;
    compressedUPC: string;
    priceLookupCode: string;
    modelProductItemcode: number;
    modelPackagingItemCode: number;
    itemCode: number;
    itemDescription: string;
    modelItemDescription: string;

}
