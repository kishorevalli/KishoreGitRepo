import { Component, OnInit,Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { NewItemFormService } from '../../new-item-form.service';

@Component({
  selector: 'ifw-gtin',
  templateUrl: './gtin.component.html',
  styleUrls: ['./gtin.component.scss']
})
export class GtinComponent implements OnInit {

    gtinHeaderFormGroup: FormGroup;
    //gtinAndCheckDigitFormGroup: FormGroup;
    @Input() showItemFormUser: boolean = true;
    constructor(private fb: FormBuilder, private newItemFormService: NewItemFormService) {

    }

    ngOnInit() {
        this.createForm(); 
        this.SetValues();

  }

    createForm() {
              
        this.gtinHeaderFormGroup = this.fb.group({          
            formattedGtin: {value: '', disabled: true},
            gtinCheckDigit: {value: '', disabled: true},
            compressedUPC: {value: '', disabled: true},
            priceLookupCode: { value: '', disabled: true },
            itemCode: { value: '', disabled: true },
            itemDescription: {value: '', disabled: true},
            modelItem: {value: '', disabled: true},
            modelItemDescription: {value: '', disabled: true}
        });
    }


    SetValues() {
        this.gtinHeaderFormGroup.setValue(
            {
                formattedGtin: this.newItemFormService.formattedGtin != undefined ? this.newItemFormService.formattedGtin : '' ,
                gtinCheckDigit: this.newItemFormService.gtinCheckDigit != undefined ? this.newItemFormService.gtinCheckDigit : '' ,
                compressedUPC: this.newItemFormService.compressedUPC != undefined ? this.newItemFormService.compressedUPC : '',
                priceLookupCode: this.newItemFormService.priceLookupCode != undefined ? this.newItemFormService.priceLookupCode : '',
                itemCode: this.newItemFormService.itemCode != undefined ? this.newItemFormService.itemCode : '',
                itemDescription: this.newItemFormService.itemDescription != undefined ? this.newItemFormService.itemDescription : '',
                modelItem: this.newItemFormService.modelProductItemcode != undefined ? this.newItemFormService.modelProductItemcode : '',
                modelItemDescription: this.newItemFormService.modelItemDescription != undefined ? this.newItemFormService.modelItemDescription : '',

            }
        )
    }

}
