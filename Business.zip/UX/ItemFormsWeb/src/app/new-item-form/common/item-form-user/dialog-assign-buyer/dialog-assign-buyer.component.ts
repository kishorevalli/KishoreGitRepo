import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar  } from '@angular/material';

import { NewItemFormService } from '../../../new-item-form.service';
import { ProductGroupingService } from '../../../product-grouping/product-grouping.service';
import { IProductGroupingDto, ProductGroupingDto } from '../../../product-grouping/product-grouping.interface';

@Component({
  selector: 'ifw-dialog-assign-buyer',
  templateUrl: './dialog-assign-buyer.component.html',
  styleUrls: ['./dialog-assign-buyer.component.scss']
})
export class DialogAssignBuyerComponent implements OnInit {
  public itemFormDisplayID: number;
  public itemFormID: number;
  productGroupingFAM: IProductGroupingDto;
  subDepartment: number;
  category: number;
  familyGroup: number;
  buyerName: string;
  buyerID: number;
  showAssignBuyer: boolean = false;
  enableSave:boolean = false;
  private dirty: boolean = false;
  constructor(public dialogRef: MatDialogRef<DialogAssignBuyerComponent>,
    public snackBar: MatSnackBar,
    private productGroupingService: ProductGroupingService,
    private newItemFormService: NewItemFormService,) { }

  ngOnInit() {
    this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
    this.itemFormID = this.newItemFormService.itemFormID;
    this.productGroupingService.GetProductGrouping(this.itemFormID)
    .subscribe(res => {
      if (res) {
        this.productGroupingFAM = res.find(item => item.productGroupType == "FAM");
        if (this.productGroupingFAM) {
          this.familyGroup = Number((this.productGroupingFAM.productGroupCode + '').slice(-2));
          this.category = Number((this.productGroupingFAM.productGroupCode + '').slice(-4, -2));
          this.subDepartment = Number((this.productGroupingFAM.productGroupCode + '').slice(-6, -4));
          let buyerGroup = (this.productGroupingFAM.parents).find(item => item.productGroupType == "BUY");
          if (buyerGroup) {
            this.buyerName = buyerGroup.productGroupDescription;
            this.buyerID = buyerGroup.productGroupCode;
            this.showAssignBuyer = true;
          }
        }
        else {
          this.showAssignBuyer = true;
        }
      }
    });
  }
  changeFamilyGroup(result: IProductGroupingDto[]) {
    this.dirty = true;
    if (result && result.length > 0) {
      this.enableSave = true;
      this.productGroupingFAM = result[0];
      let buyerGroup = (this.productGroupingFAM.parents).find(item => item.productGroupType == "BUY");
      if (buyerGroup) {
        this.buyerName = buyerGroup.productGroupDescription;
        this.buyerID = buyerGroup.productGroupCode;
      }
    }
    else {
      this.enableSave = false;
      this.productGroupingFAM = null;
    }
  }
  onSave(){
    if(this.dirty && this.enableSave){
       this.enableSave = false;
       let productGroupingList : IProductGroupingDto[] = [];
       if (this.productGroupingFAM){
         productGroupingList.push(this.productGroupingFAM);       
         this.productGroupingService.SaveFAMProductGrouping(productGroupingList,this.itemFormID)
         .subscribe(res=>{
              if(res){
                this.newItemFormService.setFAMBuyer(this.buyerName, this.buyerID);
                this.dialogRef.close();
              }
              // else {
              //    this.openSnackbar("Unhandled exception. Please try again.")
              // }
         },
         (err) => {
          this.enableSave = true;
          this.openSnackbar(err);
        });
       }
    }
    else {
      this.dialogRef.close();
    }
  }
   /**
   * Open snack bar message
   */
  private openSnackbar(message:string){
    this.snackBar.open(message, null, {
           duration: 3000,
           horizontalPosition: 'center',
           verticalPosition: 'top',
       });
 }
}
