import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material';

import { NewItemFormService } from '../../new-item-form.service';
import { DialogAssignBuyerComponent } from './dialog-assign-buyer/dialog-assign-buyer.component';

@Component({
  selector: 'ifw-item-form-user',
  templateUrl: './item-form-user.component.html',
  styleUrls: ['./item-form-user.component.scss']
})
export class ItemFormUserComponent implements OnInit {
  @Input() showItemFormUser: boolean = true;
  constructor(public newItemFormService: NewItemFormService,
    public dialog: MatDialog, ) { }

  ngOnInit() {
  }

  openDialogAssignBuyer() {
    let dialogRef = this.dialog.open(DialogAssignBuyerComponent, {
      width: "1200px"
    });
  }
}
