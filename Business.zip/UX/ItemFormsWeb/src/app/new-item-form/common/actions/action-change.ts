﻿export class ActionChange {
    actionID: Number;
    actionName: string;
    currentFormStatusID: Number;
    createdFormStatusID: Number;
}