
import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { NewItemFormService } from '../../new-item-form.service';
import { FormUserPermittedActionDto, IFormUserPermittedActionDto } from '../../new-item-form.interface';
import { Router, ActivatedRoute } from '@angular/router';
import { ActionChange } from './action-change';





@Component({
    selector: 'ifw-actions',
    templateUrl: './actions.component.html',
    styleUrls: ['./actions.component.scss']
})
export class ActionsComponent implements OnInit {

    actionsFormGroup: FormGroup;
    @Output() actionChange = new EventEmitter<ActionChange>();
    @Output() clickReset = new EventEmitter();
    @Input() currentTab: string;
    formActions: IFormUserPermittedActionDto[];
    previousTab: string;
    nextTab: string;
    public actionId: Number = 3;
    public lastUpdatedBy: string;
    public lastUpdatedDate: Date;



    constructor(private formBuilder: FormBuilder,
        private newItemFormService: NewItemFormService,
        private router: Router,   
    private route: ActivatedRoute) { }

    ngOnInit() {
        this.previousTab = this.newItemFormService.getPreviousTab(this.currentTab);
        this.nextTab = this.newItemFormService.getNextTab(this.currentTab);
        this.getSignatureInfo();
        this.getFormUserPermittedActions(); 
    }

    getFormUserPermittedActions(): void {
        this.newItemFormService.getFormUserPermittedActions().subscribe(res => {
            if (res != undefined) {
                //this.formActions = res.map(a => ({ currentFormStatusID: a.currentFormStatusID, createdFormStatusID: a.createdFormStatusID, formActionID: a.formActionID, actionName: a.buyerActionName }));
                this.formActions = res;
                if (this.formActions && this.formActions.length > 0)
                    this.actionId = this.formActions[0].formActionID;
            }
        });
    }

    getSignatureInfo(): void {
        this.newItemFormService.getItemFormData(this.newItemFormService.itemFormDisplayID).subscribe(res => {
            if(res) {
                this.lastUpdatedBy = res.lastUpdatedBy;
                this.lastUpdatedDate = res.lastUpdatedDate;
                this.newItemFormService.setSignatureData(this.lastUpdatedBy,this.lastUpdatedDate);  
            }            
        });
    }

    emitActionChanged() {
        var actionSelected = this.formActions.find(a => a.formActionID == this.actionId);
        this.actionChange.emit({
            actionID: actionSelected.formActionID,
            actionName: actionSelected.buyerActionName,
            currentFormStatusID: actionSelected.currentFormStatusID,
            createdFormStatusID: actionSelected.createdFormStatusID
        });
    }

    emitClickReset() {
        this.clickReset.emit();
    }

    goToPrevious() {
        this.router.navigate(['../' + this.previousTab], { relativeTo: this.route, queryParamsHandling: "merge" });
    }

    goToNext() {  
        this.nextTab = this.newItemFormService.getNextTab(this.currentTab);   
        this.router.navigate(['../' + this.nextTab], { relativeTo: this.route, queryParamsHandling: "merge" });
    }
}
 