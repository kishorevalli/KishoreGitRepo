import {
    Routes,
    RouterModule,
    Router,
    ActivatedRoute,
    CanActivate,
    CanActivateChild,
    CanDeactivate,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from "@angular/router";
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
export interface CanComponentDeactivate {
  saveTabObservable: () => Observable<boolean> | Promise<boolean> | boolean;
}
export class SaveBeforeDeactivateGuard implements CanDeactivate<CanComponentDeactivate> {
    canDeactivate(component: CanComponentDeactivate,
                  route: ActivatedRouteSnapshot,
                  state: RouterStateSnapshot, nextState: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      //console.log("SaveBeforeGuard");
      //console.log(state.url);
      //console.log(nextState.url);
      if(!component || nextState.url.indexOf("/new-item-form/") == -1) return of(true);
      return component.saveTabObservable? component.saveTabObservable(): of(true);
    }
  }