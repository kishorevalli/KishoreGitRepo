import {
    Routes,
    RouterModule,
    Router,
    ActivatedRoute,
    CanActivate,
    CanActivateChild,
    CanDeactivate,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from "@angular/router";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { AuthService } from '../../../core/services/auth.service';
import { catchError, tap, map } from 'rxjs/operators';
@Injectable()
export class InternalAuthGuard implements CanActivate {

    constructor(private auth: AuthService, private router: Router) {}

    canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot):Observable<boolean>|boolean {
        return this.auth.getAuthData().pipe(
            map((auth) => {
            if (auth && !this.auth.isExternal) {
                console.log('authenticated');
                return true;
            }
            console.log('not authenticated');
            this.router.navigate(['/not-authorized']);
            //this.router.navigateByUrl('/login');            
           // this.router.navigate(['/login'], { queryParamsHandling: "merge" });
            return false;
        },
        (err) => {
           return of(false);
        }
    )
    ); // this might not be necessary - ensure `first` is imported if you use it
    }
}