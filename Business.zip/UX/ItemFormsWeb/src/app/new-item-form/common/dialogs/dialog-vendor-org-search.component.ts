import { Component, Inject, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, AbstractControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatPaginatorModule, MatSort, MatPaginator } from '@angular/material';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBarConfig } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { from } from 'rxjs/observable/from';
import { catchError, tap, map } from 'rxjs/operators';

import { NewItemFormService } from '../../new-item-form.service';
import { IVendorDomainDto, VendorDomainDto } from '../../new-item-form.interface';
import { GridEvent } from '../../../shared/grid/grid-event';


@Component({
  selector: 'ifw-dialog-vendor-org-search',
    templateUrl: './dialog-vendor-org-search.component.html',
    styleUrls: ['./dialog-vendor-org-search.component.scss']
})
export class DialogVendorOrgSearchComponent implements OnInit {

     /* Variable Declarations */

    public lookupVendorOrgForm: FormGroup;
    public vendorOrgDataList: IVendorDomainDto[] = [];
    public selectedVendorOrgDataList: IVendorDomainDto[] = [];
    public onAddVendorEmitEvent: EventEmitter<IVendorDomainDto[]> = new EventEmitter<IVendorDomainDto[]>();
    public vendorDomainSearch: IVendorDomainDto;
    public vendorType: string;
    public showVendorType: boolean = false;

    /* Properties */


    get getSearchString(): AbstractControl {
        return this.lookupVendorOrgForm.get('searchString');
    }

    // GRID
    public gridData: any[] = [];
    public filteredData: any[] = [];
    public pagination: boolean = true;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = true;
    public filterBy: string = '';
    public filterValue: string = '';
    public sortable: boolean = true;
    public active: string = '';
    public direction: string = '';
    private gridEvent: GridEvent;
    public selectAll: boolean = false;
    public DisplaySearchType: string = '';


    constructor(private newItemFormService: NewItemFormService,
        private formBuilder: FormBuilder,   
        public dialogRef: MatDialogRef<DialogVendorOrgSearchComponent>,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) {

        this.createForm();
    }

    ngOnInit() {

        this.initialize();
        if (this.data.DashboardSearchType == "VendorSearch")
            this.DisplaySearchType = "Select Vendors ";
            else if (this.data.DashboardSearchType == "OrgSearch")
            this.DisplaySearchType = "Select Organizations "
            else
            this.DisplaySearchType = "Add to Included Vendors"              
        
    }


     /* Events */

    public onSearch(): void {
          this.vendorDomainSearch = (<any>Object.assign({}, this.lookupVendorOrgForm.value))
         this.vendorDomainSearch.vendorType = this.vendorType;

        this.newItemFormService.getVendorForSearch(this.vendorDomainSearch).subscribe(res => {
            this.vendorOrgDataList = res;
            this.gridData = this.performFilter(this.gridEvent);
            this.sortData(this.gridEvent);
            this.pageData(this.gridEvent);
        })
       /// this.getVendorForSearch(this.gridEvent);   
    }

    public onClearSearchFilter(): void {

        this.lookupVendorOrgForm.patchValue({ 'searchString': '' });
    }

    
    public onSelectAll(checked: boolean) {
        this.selectAll = checked;
        if (checked) {
            for (let row of this.filteredData) {
                row.checked = true;
            }
            this.selectedVendorOrgDataList = this.filteredData;
        }
        else {
            for (let row of this.vendorOrgDataList) {
                row.checked = false;
            }

            this.selectedVendorOrgDataList = [];
           
        }
    }

    public onVendorSelect(row: IVendorDomainDto, checked: boolean) {
        row.checked = checked;
        if (checked) {
            this.selectedVendorOrgDataList.push(row);
        }
        else {
            this.selectedVendorOrgDataList.splice(this.selectedVendorOrgDataList.findIndex(x => x.vendorNumber == row.vendorNumber), 1)
        }
      
    }

    public onAddVendors(): void{

        this.onAddVendorEmitEvent.emit(this.selectedVendorOrgDataList);
        this.dialogRef.close(true);
    }

    public onCancel(): void {

        this.dialogRef.close(false);
    }
    

     /* Public Methods */

  

    public getVendorForSearch(gridEvent: GridEvent): void {
        if (gridEvent.action === "filter") {
            this.selectAll = false;
            this.onSelectAll(false);
        }

        //this.vendorDomainSearch = (<any>Object.assign({}, this.lookupVendorOrgForm.value))
        //this.vendorDomainSearch.vendorType = this.vendorType;

        //this.newItemFormService.getVendorForSearch(this.vendorDomainSearch).subscribe(res => {
        //    this.vendorOrgDataList = res;
        //    this.gridData = this.performFilter(gridEvent);
        //    this.sortData(gridEvent);
        //    this.pageData(gridEvent);
        //})
        this.gridData = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }

    /* Private Methods */

    private initialize() {
        this.gridEvent = {
            pageIndex: 0,
            pageSize: this.pageSize,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };

        this.selectedVendorOrgDataList = [];
        this.vendorDomainSearch = new VendorDomainDto();
        this.vendorType = this.data.vendorType;
        if (this.vendorType && this.vendorType == 'DSD')
            this.showVendorType = false;
        else
            this.showVendorType = true;   

    }

    private createForm(): void {

        this.lookupVendorOrgForm = this.formBuilder.group({
            'searchString': ['']
        });
    }

     /* Grid Methods */

    private performFilter(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {

                return this.vendorOrgDataList.filter((row: any) => {
                    let dataStr;
                    if (this.filterBy == 'isActive') {
                        const accumulator = (currentTerm, key) => currentTerm + row[key];
                        dataStr = Object.keys(row).reduce(accumulator, '').toLowerCase();
                    }
                    else {
                        // Transform the data into a lowercase string of all property values.
                        dataStr = ('' + row[this.filterBy]).toLowerCase();
                    }

                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.vendorOrgDataList.slice();
        }
        return this.vendorOrgDataList.slice();
    }

    private pageData(gridEvent: GridEvent): void {

        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.filteredData = this.gridData.slice();
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

    /**
 * sort the filtered result based on sort column and order
 */
    sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }

}
