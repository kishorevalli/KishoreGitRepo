import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from './../shared/shared.module';

import { NewItemFormRoutingModule } from './new-item-form-routing.module';
import { NewItemFormComponent } from './new-item-form.component';
import { BasicItemDefinitionBuyerComponent } from './basic-item-definition/basic-item-definition-buyer.component';
import { BasicItemDefinitionVendorComponent } from './basic-item-definition/basic-item-definition-vendor.component';
import { BasicItemDefinitionService } from './basic-item-definition/basic-item-definition.service';

import { DialogAdditionalGtinComponent } from './basic-item-definition/dialog-addtional-gtin.component';
//import { DialogContentComponent } from './basic-item-definition/dialog-content.component';

import { GeneralProductAttributesVendorComponent } from './general-product-attributes/general-product-attributes-vendor.component';
import { GeneralProductAttributesBuyerComponent } from './general-product-attributes/general-product-attributes-buyer.component';
import { GtinComponent } from './common/gtin-header/gtin.component';
import { NewItemFormService } from './new-item-form.service';
import { GeneralProductAttributesService } from './general-product-attributes/general-product-attributes.service';
import { NutritionPanelComponent } from './general-product-attributes/nutrition-panel/nutrition-panel.component';
import { DialogLookupIngredientsComponent } from './general-product-attributes/dialog-lookup-ingredients/dialog-lookup-ingredients.component';
import { DialogReuseItemcodeComponent } from './basic-item-definition/dialog-reuse-itemcode.component';
import { ActionsComponent } from './common/actions/actions.component';
import { DialogModeledItemdetailComponent } from './basic-item-definition/dialog-modeled-itemdetail.component';
import { SaveBeforeDeactivateGuard } from './common/guards/SaveBeforeDeactivateGuard';

import { DialogItemDescriptionsComponent } from './basic-item-definition/dialog-item-descriptions.component';

import { DateAdapter, MAT_DATE_FORMATS,  MAT_DATE_LOCALE_PROVIDER, MAT_DATE_LOCALE } from '@angular/material/core';
import { CustomDateAdapter , FORMATS_MMDDYYYY } from '../shared/validators/custom-date.adapter';
import { PackagingHierarchyBuyerComponent } from './packaging-hierarchy/packaging-hierarchy-buyer.component';
import { PackagingHierarchyVendorComponent } from './packaging-hierarchy/packaging-hierarchy-vendor.component';
import { PackagingHierarchyService } from './packaging-hierarchy/packaging-hierarchy.service';
import { DsdAuthorizationRequestVendorComponent } from './dsd-authorization-request/dsd-authorization-request-vendor.component';
import { DsdAuthorizationRequestBuyerComponent } from './dsd-authorization-request/dsd-authorization-request-buyer.component';
import { DsdAuthorizationRequestService } from './dsd-authorization-request/dsd-authorization-request.service';
import { ShipperItemCompositionVendorComponent } from './shipper-item-composition/shipper-item-composition-vendor.component';
import { ShipperItemCompositionBuyerComponent } from './shipper-item-composition/shipper-item-composition-buyer.component';
import { ShipperItemCompositionService } from './shipper-item-composition/shipper-item-composition.service';

import { PackagingHierarchyCaseDetailsComponent } from './packaging-hierarchy/packaging-hierarchy-case-details.component';
import { DialogCompositionItemComponent } from './shipper-item-composition/dialog-composition-item.component';
import { DialogCreateVendorStoreAuthorizationComponent } from './dsd-authorization-request/dialog-create-vendor-store-authorization.component';
import { DialogViewVendorStoreAuthorizationComponent } from './dsd-authorization-request/dialog-view-vendor-store-authorization.component';
//import { ListBuilderComponent } from './common/ListBuilder/list-builder.component';
import { ListBuilderComponent } from '../shared/ListBuilder/list-builder.component';
import { DialogOrderablePackLevelComponent } from './packaging-hierarchy/dialog-orderable-pack-level.component';

import { MarketingSupportBuyerComponent } from './marketing-support/marketing-support-buyer.component';
import { MarketingSupportService } from './marketing-support/marketing-support.service';
import { DialogLookupDsdVendorOrgsComponent } from './dsd-authorization-request/dialog-lookup-dsd-vendor-orgs.component';
//import { DialogVendorOrgSearchComponent } from './common/dialogs/dialog-vendor-org-search.component';
import { DialogActionComponent } from './common/dialogs/dialog-action.component';

import { DialogOrderablePackLevelBuyerComponent } from './packaging-hierarchy/dialog-orderable-pack-levels/dialog-orderable-pack-level-buyer.component';
import { DialogCommentsComponent } from './marketing-support/dialog-comments/dialog-comments.component';
import { DatePipe } from '@angular/common';
import { DsdBasicItemDefinitionComponent } from './dsd-authorization-request/dsd-basic-item-definition.component';
import { ProductGroupingBuyerComponent } from './product-grouping/product-grouping-buyer.component';
import { ProductGroupingVendorComponent } from './product-grouping/product-grouping-vendor.component';
import { DialogProductGroupComponent } from './product-grouping/dialog-product-group/dialog-product-group.component';
import { DialogAdGroupComponent } from './product-grouping/dialog-ad-group/dialog-ad-group.component';
import { DialogPricingGroupComponent } from './product-grouping/dialog-pricing-group/dialog-pricing-group.component';
import { ProductGroupingService } from './product-grouping/product-grouping.service';
import { ProductAttributesBuyerComponent } from './product-attributes/product-attributes-buyer.component';
import { ProductAttributesService } from './product-attributes/product-attributes.service';
import { DialogProductAttributesComponent } from './product-attributes/dialog-product-attribute/dialog-product-attributes.component';
import { ScaleItemDetailsBuyerComponent } from './scale-item-details/scale-item-details-buyer.component';
import { DialogOverrideScaleDescriptionComponent } from './scale-item-details/dialog-override-scale-description/dialog-override-scale-description.component';
import { DialogScaleLocationComponent } from './scale-item-details/dialog-scale-location/dialog-scale-location.component';
import { DialogScaleShelfLifeComponent } from './scale-item-details/dialog-scale-shelf-life/dialog-scale-shelf-life.component';
import { DialogScaleGradeComponent } from './scale-item-details/dialog-scale-grade/dialog-scale-grade.component';
import { ScaleItemDetailsBuyerService } from './scale-item-details/scale-item-details-buyer.service';
import { AssignBuyerComponent } from './product-grouping/assign-buyer/assign-buyer.component';
import { ReviewCreateItemBuyerComponent } from './review-create-item/review-create-item-buyer.component';
import { DialogAssignBuyerComponent } from './common/item-form-user/dialog-assign-buyer/dialog-assign-buyer.component';
import { ItemFormUserComponent } from './common/item-form-user/item-form-user.component';
import { RefreshItemFormComponent } from './refresh-item-form/refresh-item-form.component';
import { ReviewCreateItemService } from './review-create-item/review-create-item.service';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    NewItemFormRoutingModule,
  ],
  declarations: [
    NewItemFormComponent , 
    BasicItemDefinitionBuyerComponent , 
    BasicItemDefinitionVendorComponent,
    DialogAdditionalGtinComponent,
      //DialogContentComponent,
      GeneralProductAttributesVendorComponent,
      GeneralProductAttributesBuyerComponent,
      GtinComponent,
      NutritionPanelComponent,
      DialogReuseItemcodeComponent,
      ActionsComponent,
      DialogModeledItemdetailComponent,
      DialogItemDescriptionsComponent,
      PackagingHierarchyBuyerComponent,
      PackagingHierarchyVendorComponent,
      DsdAuthorizationRequestVendorComponent,
      DsdAuthorizationRequestBuyerComponent,
      ShipperItemCompositionVendorComponent,
      ShipperItemCompositionBuyerComponent,   
      PackagingHierarchyCaseDetailsComponent,   
      DialogCompositionItemComponent,   
      DialogCreateVendorStoreAuthorizationComponent,
      DialogViewVendorStoreAuthorizationComponent,
      ListBuilderComponent,
      DialogOrderablePackLevelComponent,
      DialogLookupIngredientsComponent,
      MarketingSupportBuyerComponent,
      DialogLookupDsdVendorOrgsComponent,
      DialogOrderablePackLevelBuyerComponent,
      DialogCommentsComponent,
      //DialogVendorOrgSearchComponent,
      DialogActionComponent,
      DsdBasicItemDefinitionComponent,
      ProductGroupingBuyerComponent,
      ProductGroupingVendorComponent,
      DialogProductGroupComponent,
      DialogAdGroupComponent,
      DialogPricingGroupComponent,
      ProductAttributesBuyerComponent,
      DialogProductAttributesComponent,
      DialogPricingGroupComponent,
      ScaleItemDetailsBuyerComponent,
      DialogOverrideScaleDescriptionComponent,
      DialogScaleLocationComponent,
      DialogScaleShelfLifeComponent,
      DialogScaleGradeComponent,
      AssignBuyerComponent,
      DialogAssignBuyerComponent,
      ItemFormUserComponent,
      ReviewCreateItemBuyerComponent,
      RefreshItemFormComponent
    ],
    entryComponents: [
        DialogAdditionalGtinComponent,
        //DialogContentComponent,
        DialogReuseItemcodeComponent,
        DialogModeledItemdetailComponent,
        DialogItemDescriptionsComponent,
        DialogCompositionItemComponent,
        DialogCreateVendorStoreAuthorizationComponent,
        DialogViewVendorStoreAuthorizationComponent,
        DialogOrderablePackLevelComponent,
        DialogOrderablePackLevelBuyerComponent,
        DialogLookupIngredientsComponent,
        DialogLookupDsdVendorOrgsComponent,
        DialogCommentsComponent,
        //DialogVendorOrgSearchComponent,
        DialogActionComponent,
        DialogProductGroupComponent,
        DialogAdGroupComponent,
        DialogPricingGroupComponent,
        DialogProductAttributesComponent,
        DialogPricingGroupComponent,
        DialogOverrideScaleDescriptionComponent,
        DialogScaleLocationComponent,
        DialogScaleShelfLifeComponent,
        DialogScaleGradeComponent,
        DialogAssignBuyerComponent
    ],
    providers: [
        NewItemFormService,
        BasicItemDefinitionService,
        GeneralProductAttributesService,        
        SaveBeforeDeactivateGuard, 
        PackagingHierarchyService,
        DsdAuthorizationRequestService,
        ShipperItemCompositionService,
        ScaleItemDetailsBuyerService,
        MarketingSupportService,
        ProductGroupingService,
        DatePipe,
        ProductAttributesService,
        ReviewCreateItemService,
        { provide: DateAdapter, useClass: CustomDateAdapter, deps: [MAT_DATE_LOCALE] },
        { provide: MAT_DATE_FORMATS, useValue: FORMATS_MMDDYYYY}
      ]
})
export class NewItemFormModule { }
