import { Injectable , Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { IRetailPackType, ICaseCodeType , IOrderingLevels , IVendorDomain , IPackagingHierarchy , IWarehouse , IWarehouseGtin} from './packaging-hierarchy.interface';
import { ILookupDto, LookupDto, IItemSaveResponse} from '../../shared/common.interface';
import { APP_CONFIG, AppConfig } from '../../app.config';

@Injectable()
export class PackagingHierarchyService {
    private baseUrl;
    private serviceBase: string = 'api/PackagingHierarchy/';
    public vendorDomainList: IVendorDomain[];    
    
    constructor(@Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;
    }
    
    getRetailPackTypesForItemForm(itemFormID: number): Observable<IRetailPackType[]> {        
        return this.httpClient.get<IRetailPackType[]>(this.baseUrl + this.serviceBase + `GetRetailPackTypesForItemForm?itemFormID=${itemFormID}`);
    }

    getCaseCodeTypes(): Observable<ICaseCodeType[]> {
        return this.httpClient.get<ICaseCodeType[]>(this.baseUrl + this.serviceBase + 'GetCaseCodeTypes');
    }

    getOrderingLevels(): Observable<IOrderingLevels[]> {
        return this.httpClient.get<IOrderingLevels[]>(this.baseUrl + this.serviceBase + 'GetOrderingLevels');
    }

    getVendorOrgs(): Observable<IVendorDomain[]> {
        return this.httpClient.get<IVendorDomain[]>(this.baseUrl + this.serviceBase + 'getVendorOrgs');
    }  

    getVendorsForSelectedOrgs(selectedOrgs : number[]): Observable<IVendorDomain[]> {
        return this.httpClient.get<IVendorDomain[]>(this.baseUrl + this.serviceBase + 'getVendorsForSelectedOrgs');        
    }
    getVendorsDomain(): Observable<IVendorDomain[]> {
        return this.httpClient.get<IVendorDomain[]>(this.baseUrl + this.serviceBase + 'GetVendorsDomain');
    }  

    getVendorOrgsByVendorContactId(userId: string): Observable<IVendorDomain[]> {
        return this.httpClient.get<IVendorDomain[]>(this.baseUrl + this.serviceBase +  `GetVendorOrgsByUserId?userId=${userId}`);
    }  

    getVendorsDomainByVendorContactId(userId: string): Observable<IVendorDomain[]> {
        return this.httpClient.get<IVendorDomain[]>(this.baseUrl + this.serviceBase + `GetVendorsDomainByUserId?userId=${userId}`);
    }  

    savePackagingHierarchies(packagingHierachyList: IPackagingHierarchy[]): Observable<IItemSaveResponse>    {
        return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + 'SavePackagingHierarchies' , packagingHierachyList);
    }

    getPackagingHierarchies(itemFormID: number): Observable<IPackagingHierarchy[]> {
        return this.httpClient.get<IPackagingHierarchy[]>(this.baseUrl + this.serviceBase + `GetPackagingHierarchies?itemFormID=${itemFormID}`)
    }

    getWarehouses(): Observable<IWarehouse[]> {
        return this.httpClient.get<IWarehouse[]>(this.baseUrl + this.serviceBase + 'GetWarehouses');
    }

    isPrimaryVendorExistsForWHByGtin(warehousedetails: IWarehouseGtin): Observable<boolean> {
      //  return true;
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'IsPrimaryVendorExistsForWHByGtin', warehousedetails);
       // return this.httpClient.post<boolean>(true);
    }
    GetDsdVendorsExistInDsdForItemForm(itemFormID: number): Observable<any[]> {
        return this.httpClient.get<any[]>(this.baseUrl + this.serviceBase + `GetDsdVendorsExistInDsdForItemForm?itemFormID=${itemFormID}`);
    }
    
}
