import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { NewItemFormService } from '../new-item-form.service';
import { PackagingHierarchyService } from './packaging-hierarchy.service';
import { IRetailPackType, ICaseCodeType, IOrderablePackLevel, IPackagingHierarchy, PackagingHierarchy, IWarehouseGtin, WarehouseGtin} from './packaging-hierarchy.interface';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogOrderablePackLevelBuyerComponent } from './dialog-orderable-pack-levels/dialog-orderable-pack-level-buyer.component';
import { GridEvent } from '../../shared/grid/grid-event';
import { IItemFormDto, ItemFormDto, UserType, NewItemTab } from '../new-item-form.interface';
import { IErrorDTO, ErrorDTO  } from '../../shared/common.interface';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { catchError, tap, map } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { Subject } from 'rxjs/Subject';
import { DialogActionComponent } from '../common/dialogs/dialog-action.component';

@Component({
    selector: 'ifw-packaging-hierarchy-buyer',
    templateUrl: './packaging-hierarchy-buyer.component.html',
    styleUrls: ['./packaging-hierarchy-buyer.component.scss']

})
export class PackagingHierarchyBuyerComponent implements OnInit {
    itemFormDisplayID: number;
    public itemFormID: number;
    //  public packagingHierarchyFormGroup: FormGroup;
    public packagingHierarchyFormArray: FormArray;
    public retailPackTypesList: IRetailPackType[];
    public orderablePackLevel: IOrderablePackLevel;
    activeTabIndex = 0;
    showSpinner: boolean = false;
    skipSaveTab: boolean = false;
    isShipper: boolean = false;
    vendorListInDsd:any[] = [];
    popUpMessages: IErrorDTO[];
    public errors: string[];
    //public caseCodeTypesList: ICaseCodeType[];
 //   public caseDetailsFormGroup: FormGroup;

    private currentGridPageIndex: number;
    private currentGridDirection: string;
    private currentGridfilterBy: string;
    private currentGridFilterValue: string;

     // GRID
    //public dataTabs: any = [];
    public gridData: IOrderablePackLevel[] = [];
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = true;
    public filterBy: string = '';
    public filterValue: string = '';
    public sortable: boolean = true;
    public active: string = '';
    public direction: string = '';
    public formErrors: any;
    public panelErrorList: any;

    constructor(private formBuilder: FormBuilder,
        private newItemFormService: NewItemFormService,
        private packagingHierarchyService: PackagingHierarchyService,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private router: Router,
        private route: ActivatedRoute) { }



    ngOnInit() {
        this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        this.itemFormID = this.newItemFormService.itemFormID;
        this.createFormArray();
        this.formErrors = {};
        this.panelErrorList = {};
        this.packagingHierarchyService.GetDsdVendorsExistInDsdForItemForm(this.newItemFormService.itemFormID).subscribe(res => {
            this.vendorListInDsd = res;
        });
           
        this.GetPackagingHierarchies(this.itemFormID, false);

        this.errors = [];


        //this.packagingHierarchyService.getRetailPackTypesForItemForm(this.itemFormID).subscribe(res => {
        //    this.retailPackTypesList = res;
        //    if (res.length == 0) {
        //        this.packagingHierarchyFormArray.push(this.buildPackagingHierarchyForDefaultRetailPack());
        //    }
        //    else {
        //        for (var retailPack of this.retailPackTypesList) {
        //            this.packagingHierarchyFormArray.push(this.buildPackagingHierarchyForRetailPack(retailPack));
        //        }
        //    }
        //});     
        this.pagination = true;
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        let errorDTO: IErrorDTO = new ErrorDTO();
        errorDTO.tabName = 'Packaging Hierarchy';
        errorDTO.severityLevel = 'Message';
        this.newItemFormService.GetErrorMessagesByType(errorDTO).subscribe(res => {
            this.popUpMessages = res;
        });
    }

    

    createFormArray() {
        this.packagingHierarchyFormArray = this.formBuilder.array([]);
    }

    

    buildPackagingHierarchyForDefaultRetailPack() {
        let isShipper = this.newItemFormService.itemCaseTypeID == 2 ? true : false;
        return this.formBuilder.group({
            retailPackType: { value: '', disabled: true },
            retailPackSize: { value: '', disabled: true },
            retailPackTypeDescription: { value: 'NON RETAIL', disabled: true },
            size: { value: '', disabled: true },
            sizeUOM: { value: '', disabled: true },
            sizeUOMDescription: { value: '', disabled: true },
            labelAmount: { value: '', disabled: true },
            masterCaseCodeType: 'RG',
            masterCaseGTIN: '',
            masterCaseFormattedGtin: '',
            masterCaseGTINCheckDigit: '',
            masterCaseVendorItemGTIN: '',
            masterCaseSellingUnit: { value: isShipper ? 1 : '', disabled: isShipper } ,
            masterCaseWeight: '',
            masterCaseNetWeight: '',
            masterCaseHeight: '',
            masterCaseLength: '',
            masterCaseDepth: '',
            masterCaseCubicFootage: { value: '', disabled: true },
            innerPackExist: { value: isShipper ? 'N' : '', disabled: isShipper },
            innerCaseCodeType: '',
            innerCaseGTIN: '',
            innerCaseFormattedGtin: '',
            innerCaseGTINCheckDigit: '',
            innerCaseSellingUnits: '',
            innerCaseWeight: '',
            innerCaseNetWeight: '',
            innerCaseHeight: '',
            innerCaseLength: '',
            innerCaseDepth: '',
            innerCaseCubicFootage: { value: '', disabled: true },
            masterCasesInSinglePalletLayer: '',
            layersOnPallet: '',
            palletGTIN: '',
            palletQuantity: { value: '', disabled: true },
            palletCubicFootage: { value: '', disabled: true },
            isDirty: false,
            phName: '',     
            orderablePackLevels: this.formBuilder.array([])          
        });
    }

    buildPackagingHierarchyForExisting(packagingHierarchy: IPackagingHierarchy) : FormGroup {
        let isShipper = this.newItemFormService.itemCaseTypeID == 2 ? true : false;
        return this.formBuilder.group({
            id: packagingHierarchy.id,            
            retailPackType: { value: packagingHierarchy.retailPackType, disabled: true },
            retailPackSize: { value: packagingHierarchy.retailPackSize, disabled: true },
            retailPackTypeDescription: { value: packagingHierarchy.retailPackTypeDescription, disabled: true },
            size: { value: packagingHierarchy.size, disabled: true },
            sizeUOM: { value: packagingHierarchy.sizeUOM, disabled: true },
            sizeUOMDescription: { value: packagingHierarchy.sizeUOMDescription, disabled: true },
            labelAmount: { value: packagingHierarchy.labelAmount, disabled: true },
            masterCaseCodeType: packagingHierarchy.masterCaseCodeType,
            masterCaseGTIN: packagingHierarchy.masterCaseGTIN,
            masterCaseFormattedGtin: packagingHierarchy.masterCaseFormattedGtin,
            masterCaseGTINCheckDigit: packagingHierarchy.masterCaseGTINCheckDigit,
            masterCaseVendorItemGTIN: packagingHierarchy.masterCaseVendorItemGTIN,
            masterCaseSellingUnit: { value: isShipper? 1 : packagingHierarchy.masterCaseSellingUnit , disabled : isShipper},
            masterCaseWeight: packagingHierarchy.masterCaseWeight,
            masterCaseNetWeight: packagingHierarchy.masterCaseNetWeight,
            masterCaseHeight: packagingHierarchy.masterCaseHeight,
            masterCaseLength: packagingHierarchy.masterCaseLength,
            masterCaseDepth: packagingHierarchy.masterCaseDepth,
            masterCaseCubicFootage: { value: packagingHierarchy.masterCaseCubicFootage, disabled: true },
            innerCaseCodeType: packagingHierarchy.innerCaseCodeType,
            innerPackExist: { value: isShipper ? 'N' : packagingHierarchy.innerPackExist, disabled: isShipper },
            innerCaseGTIN: packagingHierarchy.innerCaseGTIN,
            innerCaseFormattedGtin: packagingHierarchy.innerCaseFormattedGtin,
            innerCaseGTINCheckDigit: packagingHierarchy.innerCaseGTINCheckDigit,
            innerCaseSellingUnits: packagingHierarchy.innerCaseSellingUnits,
            innerCaseWeight: packagingHierarchy.innerCaseWeight,
            innerCaseNetWeight: packagingHierarchy.innerCaseNetWeight,
            innerCaseHeight: packagingHierarchy.innerCaseHeight,
            innerCaseLength: packagingHierarchy.innerCaseLength,
            innerCaseDepth: packagingHierarchy.innerCaseDepth,
            innerCaseCubicFootage: { value: isShipper ? '' : packagingHierarchy.innerCaseCubicFootage, disabled: true },   
            masterCasesInSinglePalletLayer: packagingHierarchy.masterCasesInSinglePalletLayer,
            layersOnPallet: packagingHierarchy.layersOnPallet,
            palletGTIN: packagingHierarchy.palletGTIN,
            palletQuantity: { value: packagingHierarchy.palletQuantity, disabled: true },
            palletCubicFootage: { value: packagingHierarchy.palletCubicFootage, disabled: true },
            isDirty: false,
            phName: (packagingHierarchy.retailPackSize != null ? String(packagingHierarchy.retailPackSize) : "") +
                (packagingHierarchy.retailPackType != null ? String(packagingHierarchy.retailPackType) : "") +
                (packagingHierarchy.size != null ? String(packagingHierarchy.size) : "") +
                (packagingHierarchy.sizeUOM != null ? String(packagingHierarchy.sizeUOM) : "") +
                (packagingHierarchy.labelAmount != null ? String(packagingHierarchy.labelAmount) : ""),
            orderablePackLevels: this.buildOrderablePackLevels(packagingHierarchy.orderablePackLevels)

        });
    }

    public isNonRetailPack(val: string): boolean {
        if (val.trim() === "")
            return false;
        else
            return true;
    }


    public isPrePack(val: string): boolean {
        if (val.trim() === "P")
            return true;
        else
            return false;
    }

    public AddOrderablePackLevelsDialog(): void {
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        console.log(this.dialog);
        let dialogRef = this.dialog.open(DialogOrderablePackLevelBuyerComponent, {
            width: '1400px',
            height: '800px',
            data: { orderingPackLevelsList: packagingHierarchy.orderablePackLevels, orderablePackLevelRow: this.orderablePackLevel, packagingHierarchy: packagingHierarchy, isBuyer: false }
        });
        const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {
            var currentFormGroup = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
            var orderablePackFormArrray = <FormArray>currentFormGroup.get('orderablePackLevels');
            this.clearFormArray(orderablePackFormArrray);
            for (const opl of result) {
                orderablePackFormArrray.push(this.buildOrderablePackLevel(opl));
            }
            this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
            this.checkDSDVendorTypeInOrderablePackLevels();
            this.UpdateOrderablePackeLevelsRowId();
            this.getInitialOrderablePackLevelsData();
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                var currentFormGroup = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
                var orderablePackFormArrray = <FormArray>currentFormGroup.get('orderablePackLevels');
                this.clearFormArray(orderablePackFormArrray);
                for (const opl of result) {
                    orderablePackFormArrray.push(this.buildOrderablePackLevel(opl));
                }
                this.UpdateOrderablePackeLevelsRowId();
                this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
            }
            this.checkDSDVendorTypeInOrderablePackLevels();
            this.getInitialOrderablePackLevelsData();
            console.log('The dialog was closed');
        });
    }
    checkDSDVendorTypeInOrderablePackLevels(): void {
        let dsdVendors: boolean = false;
        for (const currentFormGroup of this.packagingHierarchyFormArray.controls) {
            const found = (<FormArray>currentFormGroup.get("orderablePackLevels")).controls.find(op => {
                var formGroup = <FormGroup>op;
                return formGroup.controls.vendorType.value == "DSD";
            });
            if (found) {
                dsdVendors = true;
                console.log("dsdVendors found:"+ found.get("vendorDescription").value);
                break;
            }
        }
        let dsdVendorLink: NewItemTab = this.newItemFormService.links.find(x => x.link == 'dsd-authorization-request');
        dsdVendorLink.disabled = !dsdVendors;
    }

    clearFormArray = (formArray: FormArray) => {
        if (formArray != null || formArray != undefined) {
            while (formArray.length !== 0) {
                formArray.removeAt(0);
            }
        }
    }

    buildOrderablePackLevel(orderablePackLevel: IOrderablePackLevel) {
        return this.formBuilder.group({
            vendorNumber: orderablePackLevel.vendorNumber,
            vendorDescription: orderablePackLevel.vendorDescription,
            vendorType: orderablePackLevel.vendorType,
            orderingPackagingLevelID: orderablePackLevel.orderingPackagingLevelID,
            orderingPackagingLevelDescription: orderablePackLevel.orderingPackagingLevelDescription,
            orderPackQuantity: orderablePackLevel.orderPackQuantity,
            orgId: orderablePackLevel.organizationID,
            orgName: orderablePackLevel.organizationName,
            warehouse: orderablePackLevel.warehouse,
            warehouseDescription: orderablePackLevel.warehouseDescription,
            shippingPackagingLevelID: orderablePackLevel.shippingPackagingLevelID,
            shippingPackagingLevelDescription: orderablePackLevel.shippingPackagingLevelDescription,
            shippingPackQty: orderablePackLevel.shippingPackQty,
            shipMax: orderablePackLevel.shipMax,
            shipPallet: orderablePackLevel.shipPallet,
            effectiveDate: orderablePackLevel.effectiveDate,
            terminationDate: orderablePackLevel.terminationDate,
            primaryVendorBool: {
                value: orderablePackLevel.primaryVendorBool, disabled: orderablePackLevel.vendorType != "WHS" ? true : false
    },
          //  primaryVendorBool: orderablePackLevel.primaryVendor == "Y" ? true : false,            
            rowId: orderablePackLevel.rowId

        });
    }

    buildOrderablePackLevels(orderablePackLevels: IOrderablePackLevel[]): FormArray {
        const formArray = this.formBuilder.array([]);
        let count: number = 1;
        for (const opl of orderablePackLevels) {
            opl.rowId = count++;
            formArray.push(this.buildOrderablePackLevel(opl));
        }
        return formArray;
    }

    public editOrderablePackLevel(rowId: number): void {
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        let orderablePackLevelRow: IOrderablePackLevel = packagingHierarchy.orderablePackLevels.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogOrderablePackLevelBuyerComponent, {
            width: '1400px',
          //  height: '800px',
            data: { orderingPackLevelsList: packagingHierarchy.orderablePackLevels, orderablePackLevelRow: orderablePackLevelRow, packagingHierarchy: packagingHierarchy, isBuyer: false }
        });
        const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {
            var currentFormGroup = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
            var orderablePackFormArrray = <FormArray>currentFormGroup.get('orderablePackLevels');
            this.clearFormArray(orderablePackFormArrray);
            for (const opl of result) {
                orderablePackFormArrray.push(this.buildOrderablePackLevel(opl));
            }
            this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
            this.checkDSDVendorTypeInOrderablePackLevels();
            this.UpdateOrderablePackeLevelsRowId();
            this.getInitialOrderablePackLevelsData();
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.addOrderablePackLevels(result);
                this.checkDSDVendorTypeInOrderablePackLevels();
                this.UpdateOrderablePackeLevelsRowId();
                this.getInitialOrderablePackLevelsData();
                //  console.log('The dialog was closed');
                //  console.log(result);
            }
        });
    }

    private addOrderablePackLevels(orderablePackLevels: IOrderablePackLevel[]): FormArray {

        let currentFormGroup = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
        let orderablePackFormArrray = <FormArray>currentFormGroup.get('orderablePackLevels');
        this.clearFormArray(orderablePackFormArrray);
        for (const opl of orderablePackLevels) {
            orderablePackFormArrray.push(this.buildOrderablePackLevel(opl));
        }
        this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
        return orderablePackFormArrray;
    }

    private UpdateOrderablePackeLevelsRowId() {
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        let count: number = 1;
        if (packagingHierarchy.orderablePackLevels != undefined) {
            for (let orderablePack of packagingHierarchy.orderablePackLevels) {
                orderablePack.rowId = count++;
            }
        }
    }

    public deleteOrderablePackLevel(rowId: number): void {
        //let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        let data = { description: "Are you sure you want to delete Orderable Pack Level ?", actions: ["No", "Yes"] }
        let dialogRef = this.dialog.open(ConfirmDialogComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                var tabData = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
                var orderablePackLevels = <FormArray>tabData.controls.orderablePackLevels;
                var index = orderablePackLevels.value.findIndex(x => x.rowId == rowId);
                if (index > -1) {
                    orderablePackLevels.removeAt(index);
                }
                // orderablePackLevels.removeAt(id);
                this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
                this.checkDSDVendorTypeInOrderablePackLevels();
                this.UpdateOrderablePackeLevelsRowId();
                this.getInitialOrderablePackLevelsData();
            }

        });

    }

    public onPrimaryVendorSelect(row: IOrderablePackLevel, checked: boolean): void {

        if (checked) {
            row.primaryVendorBool = true;  
            let warehouseGtin: IWarehouseGtin = new WarehouseGtin();
            warehouseGtin.itemFormID = this.newItemFormService.itemFormID;
            warehouseGtin.gtin = +this.newItemFormService.formattedGtin.replace(/-/g, "");
            warehouseGtin.warehouseNumber = row.warehouse;

            //Check if the different primary vendor is already set for this WH and GTIN. 
            this.packagingHierarchyService.isPrimaryVendorExistsForWHByGtin(warehouseGtin).subscribe(res => {
          //  let res = true;
                if (res) {
                    let message: string = "There is another Vendor set as Primary Vendor on another Form. Do you want to keep the current Vendor as Primary ?"//this.getMessage('DSD03') 

                    let data = {
                        title: "",
                        description: message,
                        actions: [
                            "Ok",
                            "Cancel"
                        ]
                    }
                    let dialogRefAction = this.dialog.open(DialogActionComponent, {
                        width: '500px',
                        disableClose: true,
                        hasBackdrop: true,
                        data: data
                    });
                    dialogRefAction.afterClosed().subscribe(result => {
                        if (result.action == "Ok") {
                            var packagingHierarchyFrmGrp = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
                            packagingHierarchyFrmGrp.patchValue({ 'isDirty': true });
                            this.setPrimaryVendorForWarehouse(row, checked);
                        }
                        else {
                            row.primaryVendorBool = false;

                        }
                    });


                }
                else { // pop up not required.
                    var packagingHierarchyFrmGrp = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
                    packagingHierarchyFrmGrp.patchValue({ 'isDirty': true });
                    this.setPrimaryVendorForWarehouse(row, checked);         
                }
              });
        }
        else {
           
            this.setPrimaryVendorForWarehouse(row, checked);

        }     

    }
    

    setPrimaryVendorForWarehouse(row: IOrderablePackLevel, checked: boolean) {

        if (checked) {
            //UnCheck if the different primary vendor is already set for the warehouse before and make them all false.
            var orderablePackGrpsforWh = this.getOrderablePackFormGroupsForWarehouse(row.warehouse, this.activeTabIndex);
            for (var orderableFormGrp of orderablePackGrpsforWh) {
                orderableFormGrp.patchValue({
                    'primaryVendorBool': false
                });
            }

            //Check all the rows with the same WH and vendor combination and make the primaryvendor true.
            var orderablePackGrps = this.getOrderablePackFormGroups(row, this.activeTabIndex);
            for (var orderableFormGrp of orderablePackGrps) {
                orderableFormGrp.patchValue({
                    'primaryVendorBool': true
                });
            }
        }
        else {

            var packagingHierarchyFrmGrp = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
            packagingHierarchyFrmGrp.patchValue({ 'isDirty': true });
            var orderablePackGrps = this.getOrderablePackFormGroups(row, this.activeTabIndex);
            for (var orderableFormGrp of orderablePackGrps) {
                orderableFormGrp.patchValue({
                    'primaryVendorBool': false
                });
            }
        }


        const gridEvent: GridEvent = {
            pageIndex: this.currentGridPageIndex,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.currentGridDirection,
            filterBy: this.currentGridfilterBy,
            filterValue: this.currentGridFilterValue
        };
        this.getOrderablePackLevelsData(gridEvent);
    }

    //public onPrimaryVendorSelect(row: IOrderablePackLevel, checked: boolean) {
    //    //let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
    //    var packagingHierarchyFrmGrp = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
    //    packagingHierarchyFrmGrp.patchValue({ 'isDirty': true });
    //    if (checked) {

            
    //            //UnCheck if the different primary vendor is already set for the warehouse before and make them all false.
    //            var orderablePackGrpsforWh = this.getOrderablePackFormGroupsForWarehouse(row.warehouse, this.activeTabIndex);
    //            for (var orderableFormGrp of orderablePackGrpsforWh) {
    //                orderableFormGrp.patchValue({
    //                    'primaryVendorBool': false
    //                });
    //            }

    //            //Check all the rows with the same WH and vendor combination and make the primaryvendor true.
    //            var orderablePackGrps = this.getOrderablePackFormGroups(row, this.activeTabIndex);
    //            for (var orderableFormGrp of orderablePackGrps) {
    //                orderableFormGrp.patchValue({
    //                    'primaryVendorBool': true
    //                });
    //            }
         
    //    }
    //    else {
    //        var orderablePackGrps = this.getOrderablePackFormGroups(row, this.activeTabIndex);
    //        for (var orderableFormGrp of orderablePackGrps) {
    //            orderableFormGrp.patchValue({
    //                'primaryVendorBool': false
    //            });
    //        }
    //    }            

    //    const gridEvent: GridEvent = {
    //        pageIndex: this.currentGridPageIndex,
    //        pageSize: 10,
    //        length: 0,
    //        active: this.active,
    //        direction: this.currentGridDirection,
    //        filterBy: this.currentGridfilterBy,
    //        filterValue: this.currentGridFilterValue
    //    };
    //    this.getOrderablePackLevelsData(gridEvent);
    //}

    private getOrderablePackFormGroupsForWarehouse(warehouse: any, index: number) {
        const data = (<FormArray>this.packagingHierarchyFormArray.controls[index].get('orderablePackLevels')).controls.filter(item => {
            var formGroup = <FormGroup>item;
            return (formGroup.controls["warehouse"].value == warehouse);
        })
        return data;
    }
   
    private getOrderablePackFormGroups(row: any, index: number) {
        const data = (<FormArray>this.packagingHierarchyFormArray.controls[index].get('orderablePackLevels')).controls.filter(item => {
            var formGroup = <FormGroup>item;
            return (formGroup.controls["vendorNumber"].value == row.vendorNumber &&
                formGroup.controls["warehouse"].value == row.warehouse);
        })
        return data;
    }
    performAction(action: any) {
        switch (action.actionName) {
            case "Save":
                this.savePackagingHierarchy(action.createdFormStatusID, action.actionID);
                break;
            case "Delete":
                this.deleteItemForm();
                break;
            case "Submit":
              //  this.submitPackagingHierarchy(action.createdFormStatusID, action.actionID);
                break;

        }
    }

    private createDefaultPackagingHierarchiesByNonRetailpackType() {
        this.packagingHierarchyFormArray.push(this.buildPackagingHierarchyForDefaultRetailPack());
    }

    //Get Packaging Hierarchies
    private GetPackagingHierarchies(itemFormID: number, afterSave: boolean) {
        //get existing packaging hierarchies from the packaging hierarchy table or new packaging hierarchies based on new retail pack types in the BID tables.
        this.packagingHierarchyService.getPackagingHierarchies(this.itemFormID).subscribe(res => {
            if (res.length > 0) {
                this.packagingHierarchyFormArray = this.formBuilder.array([]);
                for (const packagingHierarchy of res) {
                    const packagingHierarchyFormGroup = this.buildPackagingHierarchyForExisting(packagingHierarchy);
                    packagingHierarchyFormGroup.markAsPristine();
                    packagingHierarchyFormGroup.markAsUntouched();
                    this.packagingHierarchyFormArray.push(packagingHierarchyFormGroup);
                }
                //reset the current form status ID in new item form service.
                this.newItemFormService.formCurrentStatusID = res[0].formStatusID;
                this.getInitialOrderablePackLevelsData();
                console.log("GetPackagingHierarchies");
            }
            else {   //Default Packaging Hierarchie will be created for Non Retail pack Type with blank retail pack description.
                this.createDefaultPackagingHierarchiesByNonRetailpackType();
            }
            this.checkDSDVendorTypeInOrderablePackLevels();

            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
                const validations: any = this.newItemFormService.getItemValidation("Packaging Hierarchy");
                if (validations) 
                    this.handlePHValidation(validations);

            });

            //if (afterSave) {
            //    this.showSpinner = false;
            //    // const validations: any = this.newItemFormService.getItemValidation("General Product Attributes");
            //    //  if (validations) {
            //    //  this.handleItemGpaValidation(validations);
            //    //  }
            //}
            //else {
            //    setTimeout(() => {
            //        const validations: any = this.newItemFormService.getItemValidation("Packaging Hierarchy");
            //        if (validations) {
            //            console.log("validations running.")
            //            this.handlePHValidation(validations);
            //            //this.handleValidationRetailPackPHErrors(validations.subTabValidations);
            //        }
            //    }, 0); 
            //}
        },
            (err) => {
                this.showSpinner = false;
            });
    }

    reset() {
        //  this.resetToInitialState();
        this.GetPackagingHierarchies(this.itemFormID, false);
    }

    public submitPackagingHierarchy(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
                this.GetPackagingHierarchies(this.itemFormID, true);
            });
            if (res) {
                this.snackBar.open("Submitted successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
            else {
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });

            }
        });
    }

    public savePackagingHierarchy(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            if (res) {
                this.snackBar.open("Saved successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
                this.GetPackagingHierarchies(this.itemFormID, true);

            }
        });
    }




    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
        // if (this.skipSaveTab) return of(true);

        const packagingHierarchyList: IPackagingHierarchy[] = [];
        this.checkIfDirty();
        for (let idx = 0; idx < this.packagingHierarchyFormArray.controls.length; idx++) {
            //  var packagingHierarchyformGroup = this.packagingHierarchyFormArray.controls[idx];
            let phFromGroup = <FormGroup>this.packagingHierarchyFormArray.at(idx);
            const packagingHierarchy: IPackagingHierarchy = (<any>Object).assign({}, phFromGroup.getRawValue());
            packagingHierarchy.itemFormID = this.newItemFormService.itemFormID;
            //if createdFormStatusID is 0 (when changing tab) , send the currentstatus .
            createdFormStatusID = createdFormStatusID == undefined ? this.newItemFormService.formCurrentStatusID : createdFormStatusID;
            packagingHierarchy.formStatusID = createdFormStatusID;
            packagingHierarchy.formActionID = actionID;
            packagingHierarchy.submittedUserTypeID = UserType.Buyer;
            packagingHierarchy.gtin = +this.newItemFormService.formattedGtin.replace(/-/g, "");
            packagingHierarchyList.push(packagingHierarchy);
        }
        const saveSuccess$: Subject<boolean> = new Subject<boolean>();
        this.validateMappedDsdVendors(packagingHierarchyList).subscribe(res => {
            console.log(res+ " validateMappedDsdVendors");
            if(res){
               this.saveApi(packagingHierarchyList, createdFormStatusID).subscribe(res => {
                   if(res){
                    saveSuccess$.next(true);
                    saveSuccess$.complete();
                   }
                   else {
                    saveSuccess$.next(false);
                    saveSuccess$.complete();
                   }
               });
            }
            else {
                this.reset();
                saveSuccess$.next(false);
                saveSuccess$.complete();
            }
        });
        return saveSuccess$;        
    }
    private saveApi(packagingHierarchyList,createdFormStatusID : number ):Observable<boolean>{
        this.showSpinner = true;
        this.errors = [];
        return this.packagingHierarchyService.savePackagingHierarchies(packagingHierarchyList).pipe(
            map(res => {
                if(res.validation)
                    this.newItemFormService.addItemValidation(res.validation);
                if(res.status)
                    this.newItemFormService.formCurrentStatusID = createdFormStatusID;

                //console.log("saved successfully.");
                this.showSpinner = false;

                if (res.validation) //After save, handle warnings.
                    this.handlePHValidation(res.validation);

               // this.handleValidationRetailPackPHErrors(res.validation.subTabValidations);
                return res.status;
            }),
            catchError((err) => {
            this.showSpinner = false;
                this.showSpinner = false;
                if (err.status === 400) {
                    this.newItemFormService.addItemValidation(err.error);
                    let validationRetailPackPHErrors = err.error.subTabValidations;
                    this.handlePHValidation(err.error);
                    //this.handleValidationRetailPackPHErrors(validationRetailPackPHErrors);
                    // this.handleItemPHTabValidation(err.error);
                }
                console.log("saved error. " + err.status);
                window.scrollTo(0, 150);
                this.snackBar.open("Please correct the errors.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                });
                return of(false);
            })
        );
    }
    private validateMappedDsdVendors(packagingHierarchyList: IPackagingHierarchy[]): Observable<boolean> {
        var vendorList = packagingHierarchyList.map(op => op.orderablePackLevels.map(item => item.vendorNumber));
        var flattened = vendorList.reduce(
            ( accumulator, currentValue ) => accumulator.concat(currentValue),
            []
          );
        let dsdNotMappedList: number[] = [];
        for (var dsdVendor of this.vendorListInDsd) {
            const found = flattened.find(item => {
                return item == dsdVendor.vendorNumber;
            });
            if(!found) dsdNotMappedList.push(found);
        }
        if (dsdNotMappedList.length > 0){
            let data = {
                title: "",
                description: this.showMessage("PCH24") + '\n' + "Please click 'Ok' to continue or 'Cancel' to revert the current changes?",
                actions: [
                    "Cancel",
                    "Ok"
                ]
            }
            let dialog = this.dialog.open(DialogActionComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            return dialog.afterClosed().pipe(
                map(option => {
                    if (option && option.action == "Ok") {
                        return true;
                    }
                    return false;
                })
            );
        }
        else return of(true);
        
    }
    private showMessage(code:string):string{
        let messageDesc:string = '';
        console.log(this.popUpMessages);
        if(this.popUpMessages.some(error => error.errorCode == code))
        messageDesc = this.popUpMessages.find(error => error.errorCode == code).errorDescription
        return messageDesc;
    }

    handlePHValidation(itemValidation) {
        let phErrors = itemValidation.errors;
        let phWarnings = itemValidation.warnings;
        this.handlePHValidationErrors(phErrors);
        this.handlePHValidationWarnings(phWarnings);
        this.handleValidationRetailPackPHErrors(itemValidation.subTabValidations);
    }

    handlePHValidationErrors(phErrors: any[]) {
        for (var key in phErrors) {
            let errorObj = phErrors[key];
            this.errors.push(errorObj.errorDescription);
        }
    }

    handlePHValidationWarnings(phWarnings: any[]) {
        for (var key in phWarnings) {
            let errorObj = phWarnings[key];
            this.errors.push(errorObj.errorDescription);
        }
    }

    handleValidationRetailPackPHErrors(panelErrors: any[]) {
        for (var panelError of panelErrors) {
            var tabName = panelError["subTabName"];
            const _errorCount: number = panelError["errors"].length;
            const _warningCount: number = panelError["warnings"].length;
            var panelGroup = <FormGroup>this.getPackagingHierarchyFormGroup(tabName);
            // go through errors and attach to controls
            let _errors: string[] = [];
            for (const _error of panelError["errors"]) {
                let fieldName = _error.controlName;
                if (fieldName && panelGroup.controls[fieldName]) {
                    panelGroup.controls[fieldName].setErrors({ invalid: true });
                    panelGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = _error.errorDescription;
                }
                else {
                    _errors.push(_error.errorDescription);
                }
            }
            // go through warnings and attach to controls
            let _warnings: string[] = [];
            for (const _warning of panelError["warnings"]) {
                let fieldName = _warning.controlName;
                if (fieldName && panelGroup.controls[fieldName]) {
                    panelGroup.controls[fieldName].setErrors({ warning: true });
                    panelGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = _warning.errorDescription;
                }
                else {
                    _warnings.push(_warning.errorDescription);
                }
            }
            // pass to object to show in UI
            this.populateError(tabName, _errors, _warnings, _errorCount, _warningCount);
        }
        // this.updateChanges();
    }

    populateError(tabName: string, errorList: string[], warningList: string[], errorCount: number, warningCount: number) {
        this.panelErrorList[tabName] = {
            "errors": errorList,
            "warnings": warningList,
            "errorCount": errorCount,
            "warningCount": warningCount
        };
    }

    getPackagingHierarchyFormGroup(tabName: string) {
        const findPH = this.packagingHierarchyFormArray.controls.find(ph => {
            const formGroup = <FormGroup>ph;
            return formGroup.controls["phName"].value === tabName;
        });
        return findPH;
    }



    checkIfDirty() {
        // Set if any specific retail pack - packaging Hierarchy group is dirty          
        for (let idx = 0; idx < this.packagingHierarchyFormArray.controls.length; idx++) {
            var formGroup = this.packagingHierarchyFormArray.controls[idx];
            if (formGroup.dirty === true) { formGroup.patchValue({ 'isDirty': formGroup.dirty }); }            
        }
    }


    public deleteItemForm(): void {
        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.showSpinner = true;
                this.newItemFormService.deleteItemForm().subscribe(res => {

                    this.showSpinner = false;
                    if (res != undefined) {
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" });
                },
                    (err) => {
                        this.showSpinner = false;
                        if (err.status === 400) {
                            // handle validation error
                            let validationErrorDictionary = err.error.modelState;
                            //   this.handleGpaValidationErrors(validationErrorDictionary);
                        } else {
                             this.formErrors.push("Unhandled expection occured.");
                        }
                        window.scrollTo(0, 0);
                    })
            }
        });
    }

    onSelectTabChange(event) {
        this.getInitialOrderablePackLevelsData();
    }

    // Grid specific events
    getGridData() {
        if (!this.gridData) return [];
        return this.gridData;
    }

    getOrderablePackLevelsData(gridEvent: GridEvent) {
        this.currentGridPageIndex = gridEvent.pageIndex;
        this.currentGridDirection = gridEvent.direction;
        this.currentGridfilterBy = gridEvent.filterBy;
        this.currentGridFilterValue = gridEvent.filterValue;

        this.gridData = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }
    getInitialOrderablePackLevelsData() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getOrderablePackLevelsData(gridEvent);
    }
    /**
  * return the filtered or shallow copy without changing the original data
  */
    performFilter(gridEvent: GridEvent): any[] {
        console.log(this.activeTabIndex);
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return packagingHierarchy.orderablePackLevels.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return packagingHierarchy.orderablePackLevels.slice();
        }
        return packagingHierarchy.orderablePackLevels.slice();
    }
   
      /**
       * paginate the result set
       */
    private pageData(gridEvent: GridEvent): void {

        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

    /**
* sort the filtered result based on sort column and order
*/
    private sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }

}