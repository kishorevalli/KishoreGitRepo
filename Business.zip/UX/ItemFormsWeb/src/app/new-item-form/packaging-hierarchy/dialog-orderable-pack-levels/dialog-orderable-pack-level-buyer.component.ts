import { Component, OnInit, Inject, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PackagingHierarchyService } from '../packaging-hierarchy.service';
import { IOrderingLevels, IVendorDomain, IOrderablePackLevel, OrderablePackLevel, IWarehouse } from '../packaging-hierarchy.interface';
import { DialogVendorOrgSearchComponent } from '../../common/dialogs/dialog-vendor-org-search.component';
import { NewItemFormService } from '../../new-item-form.service';
import { AuthService } from '../../../core/services/auth.service';
import { UserType } from '../../new-item-form.interface';
import { DatePipe } from '@angular/common';
import { DialogActionComponent } from '../../common/dialogs/dialog-action.component';
import * as _moment from 'moment';
const moment = _moment;


//import { IListItem } from '../../shared/common.interface';

@Component({
  selector: 'ifw-dialog-orderable-pack-level-buyer',
  templateUrl: './dialog-orderable-pack-level-buyer.component.html',
  styleUrls: ['./dialog-orderable-pack-level-buyer.component.scss']
})
export class DialogOrderablePackLevelBuyerComponent implements OnInit {

    public orderingLevelsList: IOrderingLevels[];
    public shippingLevelList: IOrderingLevels[];
    public filteredShippingLevelsList: IOrderingLevels[];
    public warehouseList: IWarehouse[];
    public orderablePackLevelGroup: FormGroup;
    public fullVendorsDomain: IVendorDomain[];
    //  public vendorOrgsList: IVendorDomain[];
    public vendorOrgsList: any[];
    public excludedOrgs: any[];
    public excludedVendorsForSelectedOrgs: any[];
    public excludedWarehouses: any[];
    public includedWarehouses: any[];

    // public vendors: IListItem[];
    public packagingHierarchy: any;
    public includedVendors: any[];
    public includedOrgs: any[];
    public includedVendorsForSelectedOrgs: any[];
    public isEdit: boolean = false;
    public isAugumentingUser: boolean = false;
    onAddEvent = new EventEmitter<IOrderablePackLevel[]>();
    public orderingPackLevelsList: IOrderablePackLevel[];
  

    constructor(private newItemFormService: NewItemFormService,        
        private authService: AuthService,
        public dialogRef: MatDialogRef<DialogOrderablePackLevelBuyerComponent>,
        private formBuilder: FormBuilder,
        private packagingHierarchyService: PackagingHierarchyService,
        @Inject(MAT_DIALOG_DATA) public data: any,
        public datepipe: DatePipe,
        public dialog: MatDialog,
        ) { }

    ngOnInit() {
        this.excludedVendorsForSelectedOrgs = [];
        this.includedVendorsForSelectedOrgs = [];
        this.includedVendors = [];
        this.includedOrgs = [];
        this.excludedOrgs = [];
        this.excludedWarehouses = [];
        this.includedWarehouses = [];
         

        if (this.data.orderablePackLevelRow != undefined) {
            this.orderablePackLevelGroup = this.formBuilder.group({
                rowId: this.data.orderablePackLevelRow.rowId,
                orderingPackagingLevelID: this.data.orderablePackLevelRow.orderingPackagingLevelID,
                orderPackQuantity: { value: this.data.orderablePackLevelRow.orderPackQuantity, disabled: true },
                vendorNumber: this.data.orderablePackLevelRow.vendorNumber,
                shipMax: this.data.orderablePackLevelRow.shipMax,
                shipPallet: this.data.orderablePackLevelRow.shipPallet,
                shippingPackagingLevelID: this.data.orderablePackLevelRow.shippingPackagingLevelID,
                shippingPackQty: { value: this.data.orderablePackLevelRow.shippingPackQty, disabled: true },
                effectiveDate: this.data.orderablePackLevelRow.effectiveDate,
                terminationDate: this.data.orderablePackLevelRow.terminationDate ,
                warehouse: this.data.orderablePackLevelRow.warehouse,
                primaryVendorBool: this.data.orderablePackLevelRow.primaryVendorBool,

            });
            this.isEdit = true;
            this.orderingPackLevelsList = this.data.orderingPackLevelsList;
        }
        else {
            this.orderablePackLevelGroup = this.formBuilder.group({
                rowId: 0,
                orderingPackagingLevelID: null,
                orderPackQuantity: { value: '', disabled: true },
                shipMax: 50,
                shipPallet: '',
                shippingPackagingLevelID: null,
                shippingPackQty: { value: '', disabled: true },
                effectiveDate: '',
                terminationDate: '',
                warehouse: '',
                primaryVendorBool: false,

            });

            this.orderingPackLevelsList = this.data.orderingPackLevelsList;
        }

        this.packagingHierarchy = this.data.packagingHierarchy;


        this.packagingHierarchyService.getOrderingLevels().subscribe(res => {           
            this.orderingLevelsList = res.map(ol => ({ id: ol.id, name: ol.name, sortOrder: ol.sortOrder }));

            if (this.data.orderablePackLevelRow != undefined) {
                let olvalue = this.data.orderablePackLevelRow.orderingPackagingLevelID
                let selectedOrderingLevel = this.orderingLevelsList.find(ol => ol.id == olvalue);
                if (selectedOrderingLevel) {
                    this.filteredShippingLevelsList = this.orderingLevelsList.filter(ol => ol.sortOrder >= selectedOrderingLevel.sortOrder);
                }
            }
            else {
                this.filteredShippingLevelsList = res;
            }
            //this.shippingLevelList = res;
        })

        this.packagingHierarchyService.getWarehouses().subscribe(res => {

            if ((this.data.orderablePackLevelRow != undefined) && (this.data.orderablePackLevelRow.warehouse != null || this.data.orderablePackLevelRow.warehouse != undefined)) {
                var editRow = res.find(wh => wh.warehouseNumber === this.data.orderablePackLevelRow.warehouse);
                this.includedWarehouses.push({ id: editRow.warehouseNumber, name: editRow.name });

                res.splice(res.indexOf(editRow), 1);
                this.excludedWarehouses = res.map(wh => ({ id: wh.warehouseNumber, name: wh.name }));              
            }
            else {
                this.excludedWarehouses = res.map(wh => ({ id: wh.warehouseNumber, name: wh.name }));
            }                    
               
        })

        
        //    this.isExternalUser = false;

   
        if (this.newItemFormService.createdByUserType == UserType.Vendor) {
            this.isAugumentingUser = true;

            this.getVendorOrgsByVendorContactId();

            this.getVendorsDomainByVendorContactId();
            
        }
        else {

            if (this.isEdit) {
                this.includedVendorsForSelectedOrgs.push({ id: this.data.orderablePackLevelRow.vendorNumber, name: this.data.orderablePackLevelRow.vendorDescription, itemType: this.data.orderablePackLevelRow.vendorType, orgId: this.data.orderablePackLevelRow.organizationID, orgName: this.data.orderablePackLevelRow.organizationName });
                this.includedVendors = [...this.includedVendorsForSelectedOrgs];
            }           

         
        }
        this.subscribeOrderingLevelsChanges();
    }

    subscribeOrderingLevelsChanges() {
        const shippingPackagingLevelID = this.orderablePackLevelGroup.controls.shippingPackagingLevelID;
        // initialize value changes stream
        const changes$ = this.orderablePackLevelGroup.controls.orderingPackagingLevelID.valueChanges;
        // subscribe to the stream
        changes$.subscribe(olValue => {
            // Yes

            let selectedOrderingLevel = this.orderingLevelsList.find(ol => ol.id == olValue);
            if (selectedOrderingLevel) {
                this.filteredShippingLevelsList = this.orderingLevelsList.filter(ol => ol.sortOrder >= selectedOrderingLevel.sortOrder);
            }          

        });
    }

    public onAddVendors(): void {

        let dialogRef = this.dialog.open(DialogVendorOrgSearchComponent, {
            width: '1000px',
            data: { vendorType: '' }
        });

        const sub = dialogRef.componentInstance.onAddVendorEmitEvent.subscribe((result) => {

            for (const vendorDetail of result) {
                if (this.includedVendorsForSelectedOrgs.find((self) => self.id === vendorDetail.vendorNumber) == undefined) {
                    this.includedVendorsForSelectedOrgs.push({ id: vendorDetail.vendorNumber, name: vendorDetail.vendorName, itemType: vendorDetail.vendorType, orgId: vendorDetail.organizationID, orgName: vendorDetail.organizationName });
                  //  this.includedOrgs.push({ id: vendorDetail.organizationID, name: vendorDetail.organizationName });
                }
                if (this.excludedVendorsForSelectedOrgs.find((self) => self.id === vendorDetail.vendorNumber)) {
                    this.excludedVendorsForSelectedOrgs.splice(this.excludedVendorsForSelectedOrgs.findIndex(e => e.id == vendorDetail.vendorNumber), 1);
                }
            }

            this.includedVendors = [...this.includedVendorsForSelectedOrgs];
        });

        dialogRef.afterClosed().subscribe(result => {


        });
        //this.snackBar.open('Creating Vendor Store Authorization was not implemented', undefined, this.snackbarConfig);
    }


    private getVendorOrgsByVendorContactId() {
        this.packagingHierarchyService.getVendorOrgsByVendorContactId(this.newItemFormService.vendorContactID).subscribe(res => {
            if (res) {
                //During edit , Org for that included vendor should be in the included org list , so delete the selected vendororganization from the excluded orgs list.
                if (this.data.orderablePackLevelRow != undefined) {
                    var selectedRowVendorOrg = res.findIndex(vo => (vo.vendorNumber == this.data.orderablePackLevelRow.vendorNumber));
                    res.splice(selectedRowVendorOrg, 1);
                }
                this.vendorOrgsList = res.map(vo => ({ id: vo.organizationID, name: vo.organizationName }));
                this.excludedOrgs = [...this.vendorOrgsList];
            }
        })
    }

   private getVendorsDomainByVendorContactId() {
        this.packagingHierarchyService.getVendorsDomainByVendorContactId(this.newItemFormService.vendorContactID).subscribe(res => {
            this.fullVendorsDomain = res;
            if (this.data.orderablePackLevelRow != undefined) {
                var editRow = this.fullVendorsDomain.find(vo => vo.vendorNumber == this.data.orderablePackLevelRow.vendorNumber);
                this.includedOrgs.push({ id: editRow.organizationID, name: editRow.organizationName });
                let vendorDomainsForEditRowOrg = this.fullVendorsDomain.filter(vo => vo.organizationID == editRow.organizationID);

                //corresponding vendor in the edit row will be in the included vendors list and other vendors will be in the excluded vendor list.
                for (let domain of vendorDomainsForEditRowOrg) {
                    if (domain.vendorNumber === this.data.orderablePackLevelRow.vendorNumber) {
                        this.includedVendorsForSelectedOrgs.push({ id: domain.vendorNumber, name: domain.vendorName, itemType: domain.vendorType, orgId: domain.organizationID, orgName: domain.organizationName });
                    }
                    else {
                        this.excludedVendorsForSelectedOrgs.push({ id: domain.vendorNumber, name: domain.vendorName, itemType: domain.vendorType, orgId: domain.organizationID, orgName: domain.organizationName });
                    }
                    this.includedVendors = [...this.includedVendorsForSelectedOrgs];
                }

            }
        })
    }

    resetToInitialState() {
        this.orderablePackLevelGroup.patchValue({
            rowId: 0,
            orderingPackagingLevelID: null,
            orderPackQuantity: '',
            shipMax: '',
            shipPallet: '',
            shippingPackagingLevelID: null,
            shippingPackQty: '',
            effectiveDate: '',
            terminationDate: '',
            primaryVendorBool: false,
        });
    }

    //On change of included Orgs list
    public getVendorsForSelectedOrgs(selectedOrgs: any[]) {
        this.excludedVendorsForSelectedOrgs = [];
        this.includedVendorsForSelectedOrgs = [];

        if (this.fullVendorsDomain !== undefined) {
            for (let selectedOrg of selectedOrgs) {
                let filteredVendorDomainForOrgs = this.fullVendorsDomain.filter(vo => vo.organizationID == selectedOrg.id);

                //if the vendor is already in the includedVendors list , push the vendor into the included vendor list , otherwise push it into excluded vendor list
                for (let domain of filteredVendorDomainForOrgs) {
                    this.includedVendorsForSelectedOrgs.push({ id: domain.vendorNumber, name: domain.vendorName, itemType: domain.vendorType, orgId: domain.organizationID, orgName: domain.organizationName });

                    //var includedVendor = this.includedVendors.find(v => v.id === vendor.vendorNumber)
                    //if (includedVendor !== undefined) {
                    //    this.includedVendorsForSelectedOrgs.push({ id: vendor.vendorNumber, name: vendor.vendorName , itemType: vendor.vendorType});
                    //}
                    //else {
                    //    this.excludedVendorsForSelectedOrgs.push({ id: vendor.vendorNumber, name: vendor.vendorName, itemType: vendor.vendorType});
                    //}
                }
            }
        }
        this.includedVendors = [...this.includedVendorsForSelectedOrgs];
    }

    getIncludedVendors(includedVendors: any[]) {
        this.includedVendors = [];
        this.includedVendors = [...includedVendors];
    }

    public CalculateOrderQty(): void {
        var orderingLevel = this.orderablePackLevelGroup.get('orderingPackagingLevelID').value
        switch (orderingLevel) {
            case 1: // pallet
                if ((this.packagingHierarchy.layersOnPallet * this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit) == 0) {
                    let message: string = "Orderable Pack Qty is not available for Pallet.";
                    this.validateOrderingPackLevelSelection(message, "OrderingPackLevel");
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.layersOnPallet * this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit });
                }
                break;
            case 2: // Tier
                if ((this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit) == 0) {
                    let message: string = "Orderable Pack Qty is not available for Tier.";
                    this.validateOrderingPackLevelSelection(message , "OrderingPackLevel");
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit });
                }
                break;
            case 3: // MC
                if ((this.packagingHierarchy.masterCaseSellingUnit == 0) || (!this.packagingHierarchy.masterCaseSellingUnit)) {
                    let message: string = "Orderable Pack Qty is not available for Master Case.";
                    this.validateOrderingPackLevelSelection(message, "OrderingPackLevel"); 
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.masterCaseSellingUnit });
                }
                break;
            case 4: //IC
                if ((this.packagingHierarchy.innerCaseSellingUnits == 0) || (!this.packagingHierarchy.innerCaseSellingUnits)) {
                    let message: string = "Orderable Pack Qty is not available for Inner Case.";
                    this.validateOrderingPackLevelSelection(message, "OrderingPackLevel");
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.innerCaseSellingUnits });
                }
                break;
            case 5: //Each
                this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': 1 });
                break;
        }

        this.resetShippingLevel();
    }

    resetShippingLevel() {
        this.orderablePackLevelGroup.get('shippingPackagingLevelID').patchValue(null);
        this.orderablePackLevelGroup.get('shippingPackQty').patchValue('');
    }

    resetOrderingLevel() {
        this.orderablePackLevelGroup.get('orderingPackagingLevelID').patchValue(null);
        this.orderablePackLevelGroup.get('orderPackQuantity').patchValue('');
    }

    public CalculateShippingQty(): void {
        var shippingPackagingLevel = this.orderablePackLevelGroup.get('shippingPackagingLevelID').value
        switch (shippingPackagingLevel) {
            case 1: // pallet
                if ((this.packagingHierarchy.layersOnPallet * this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit) == 0) {
                    let message: string = "Shipping Packing Qty is not available for Pallet.";
                    this.validateOrderingPackLevelSelection(message , "ShippingPackLevel");
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'shippingPackQty': this.packagingHierarchy.layersOnPallet * this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit });
                }
                break;
            case 2: // Tier
                if ((this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit) == 0) {
                    let message: string = "Orderable Pack Qty is not available for Tier.";
                    this.validateOrderingPackLevelSelection(message, "ShippingPackLevel");
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'shippingPackQty': this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit });
                }
                break;
            case 3: // MC
                if ((this.packagingHierarchy.masterCaseSellingUnit == 0) || (!this.packagingHierarchy.masterCaseSellingUnit)) {
                    let message: string = "Shipping Packing Qty is not available for Master Case.";
                    this.validateOrderingPackLevelSelection(message, "ShippingPackLevel");
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'shippingPackQty': this.packagingHierarchy.masterCaseSellingUnit });
                }
                break;
            case 4: //IC
                if ((this.packagingHierarchy.innerCaseSellingUnits == 0) || (!this.packagingHierarchy.innerCaseSellingUnits)) {
                    let message: string = "Shipping Packing Qty is not available for Inner Case.";
                    this.validateOrderingPackLevelSelection(message, "ShippingPackLevel");
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'shippingPackQty': this.packagingHierarchy.innerCaseSellingUnits });
                }
                break;
            case 5: //Each
                this.orderablePackLevelGroup.patchValue({ 'shippingPackQty': 1 });
                break;
        }
    }

    public validateOrderingPackLevelSelection(message : string , packLevelType : string) {
        let data = {
            title: "",
            description: message,
            actions: [
                "Ok",
            ]
        }
        let dialogRefAction = this.dialog.open(DialogActionComponent, {
            width: '500px',
            disableClose: true,
            hasBackdrop: true,
            data: data
        });

        dialogRefAction.afterClosed().subscribe(result => {
            if (result.action == "Ok") {
                if (packLevelType === "OrderingPackLevel") {
                    this.resetOrderingLevel();
                   // this.orderablePackLevelGroup.patchValue({ 'orderingPackagingLevelID': '' });                    
                }
                else {
                    this.resetShippingLevel();
                    //this.orderablePackLevelGroup.patchValue({ 'shippingPackagingLevelID': '' });
                }
            }
        });
    }

    private showErrors(): void {
        if (!this.orderablePackLevelGroup.controls.orderingPackagingLevelID.value) {
            this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].setErrors({ required: true });
            this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].markAsTouched({ onlySelf: true });
        }
        //Object.keys(this.orderablePackLevelGroup.controls).forEach(field => {
        //    const control = this.orderablePackLevelGroup.get(field);
        //    control.markAsTouched({ onlySelf: true });
        //});
        return;
    } 

    public onAdd(): void {
        //this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].setErrors({ notvalid: true });
        //this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].markAsTouched({ onlySelf: true });
        //return this.showErrors();
        this.showErrors();
        if (this.orderablePackLevelGroup.invalid) {
            return
        }  
        let orderablePackLevels = this.getOrderablePackLevelsForIncludedWarehouses();
        if (orderablePackLevels !== undefined) {
            this.dialogRef.close(orderablePackLevels);
        }
    }

    
    public onAddContinue(): void {
        this.showErrors();
        if (this.orderablePackLevelGroup.invalid) {
            return
        }  
        let orderablePackLevels = this.getOrderablePackLevelsForIncludedWarehouses();
        this.onAddEvent.emit(orderablePackLevels);
        this.resetToInitialState();
        //  this.orderablePackLevelGroup.reset();
    }

    private getOrderableLevelDescriptions(orderablePackLevel: IOrderablePackLevel) {
        if (orderablePackLevel.orderingPackagingLevelID) {
            const orderingLevel = this.orderingLevelsList.find(ol => ol.id === orderablePackLevel.orderingPackagingLevelID);
            orderablePackLevel.orderingPackagingLevelDescription = orderingLevel.name;
        }

        if (orderablePackLevel.shippingPackagingLevelID) {
            const orderingLevel = this.filteredShippingLevelsList.find(sl => sl.id === orderablePackLevel.shippingPackagingLevelID);
            orderablePackLevel.shippingPackagingLevelDescription = orderingLevel.name;
        }
        //    return orderablePackLevel;
    }

    private getOrderablePackLevelsForIncludedWarehouses(): IOrderablePackLevel[] {
        let orderablePackLevels: IOrderablePackLevel[] = this.orderingPackLevelsList == undefined ? [] : this.orderingPackLevelsList;
        //let rowId = this.orderablePackLevelGroup.get('rowId').value

        //Delete the selected row and add the new combinations. 
        if (this.isEdit) {
            let IndexOfselectedRowForEdit = orderablePackLevels.indexOf(orderablePackLevels.find(o => (o.rowId == this.data.orderablePackLevelRow.rowId)));
            if (IndexOfselectedRowForEdit > -1) {
                orderablePackLevels.splice(IndexOfselectedRowForEdit, 1);
            }
        }
        for (let includedVendor of this.includedVendors) {
            if (this.includedWarehouses.length > 0) {
                for (let wh of this.includedWarehouses) {
                    orderablePackLevels = this.populateOrderablePackLevels(includedVendor, orderablePackLevels, wh);
                }
            }
            else {
                this.populateOrderablePackLevels(includedVendor, orderablePackLevels, undefined);
            }

            //DSD vendors doesn't need warehouse.
            if (this.includedWarehouses.length === 0) {
                if (includedVendor.itemType === 'DSD') {
                    this.populateOrderablePackLevels(includedVendor, orderablePackLevels , undefined);
                }
            }
        }

        this.orderingPackLevelsList = [...orderablePackLevels];
        return orderablePackLevels;
    }

    private populateOrderablePackLevels(includedVendor: any, orderablePackLevels: IOrderablePackLevel[], wh?: any) : IOrderablePackLevel[] {
        let orderablePackLevel: IOrderablePackLevel = new OrderablePackLevel();
        orderablePackLevel.vendorNumber = includedVendor.id;
        orderablePackLevel.vendorDescription = includedVendor.name;
        orderablePackLevel.vendorType = includedVendor.itemType;
        orderablePackLevel.organizationID = includedVendor.orgId;
        orderablePackLevel.organizationName = includedVendor.organizationName;
        //orderablePackLevel.orderingPackagingLevelID = this.orderablePackLevelGroup.get('orderingPackagingLevelID').value != null ? this.orderablePackLevelGroup.get('orderingPackagingLevelID').value : "" ;
        orderablePackLevel.orderingPackagingLevelID = this.orderablePackLevelGroup.get('orderingPackagingLevelID').value;
        orderablePackLevel.orderPackQuantity = this.orderablePackLevelGroup.get('orderPackQuantity').value;
        orderablePackLevel.shipMax = this.orderablePackLevelGroup.get('shipMax').value;
        orderablePackLevel.shipPallet = this.orderablePackLevelGroup.get('shipPallet').value;
        // orderablePackLevel.shippingPackagingLevelID = this.orderablePackLevelGroup.get('shippingPackagingLevelID').value;
        // orderablePackLevel.shippingPackQty = this.orderablePackLevelGroup.get('shippingPackQty').value;
        if (this.orderablePackLevelGroup.get('effectiveDate').value != undefined && this.orderablePackLevelGroup.get('effectiveDate').value != "") {
            // orderablePackLevel.effectiveDate = this.datepipe.transform(this.orderablePackLevelGroup.get('effectiveDate').value , 'MM-dd-yyyy');
            orderablePackLevel.effectiveDate = this.orderablePackLevelGroup.get('effectiveDate').value;
            orderablePackLevel.terminationDate = new Date('12/31/9999');
        }
        //if (this.orderablePackLevelGroup.get('terminationDate').value != undefined) {           
        //    orderablePackLevel.terminationDate = this.orderablePackLevelGroup.get('terminationDate').value;
        //}
        orderablePackLevel.primaryVendorBool = this.orderablePackLevelGroup.get('primaryVendorBool').value;

        if (includedVendor.itemType === 'WHS') {
          
                orderablePackLevel.warehouse = wh != undefined ? wh.id : null; //warehouseNumber
                orderablePackLevel.warehouseDescription = wh!= undefined ? wh.name : null; //warehouseDescription
           
            orderablePackLevel.shippingPackagingLevelID = this.orderablePackLevelGroup.get('shippingPackagingLevelID').value;
            orderablePackLevel.shippingPackQty = this.orderablePackLevelGroup.get('shippingPackQty').value;
        }
        else { //DSD 
            orderablePackLevel.warehouse = null; //warehouseNumber
            orderablePackLevel.warehouseDescription = null; //warehouseDescription

            //For DSD items shipping level will be same as orderable pack level.
            orderablePackLevel.shippingPackagingLevelID = this.orderablePackLevelGroup.get('orderingPackagingLevelID').value;
            orderablePackLevel.shippingPackQty = this.orderablePackLevelGroup.get('orderPackQuantity').value;
        }

        this.getOrderableLevelDescriptions(orderablePackLevel);
        
        //If the vendor , warehouse , ordering level and shipping level combination is already there in the list/grid , ignore it and don't add it again.
        if (orderablePackLevels.length > 0) {         
                var matchingOrderablePackLevel = orderablePackLevels.find(o => ((o.vendorNumber === orderablePackLevel.vendorNumber) && (o.orderingPackagingLevelID === orderablePackLevel.orderingPackagingLevelID)
                    && (o.warehouse === orderablePackLevel.warehouse) && (o.shippingPackagingLevelID === orderablePackLevel.shippingPackagingLevelID)));
            

            if (matchingOrderablePackLevel == undefined) {
                //Chck if primary vendor is set for the vendor and wh comibination .
                var matchingPrimaryVendorOpl = orderablePackLevels.find(o => ((o.vendorNumber === orderablePackLevel.vendorNumber) && (o.warehouse === orderablePackLevel.warehouse) && (o.primaryVendorBool === true)));
                if (matchingPrimaryVendorOpl != undefined) { orderablePackLevel.primaryVendorBool = true; }
                else { orderablePackLevel.primaryVendorBool = false; }
                orderablePackLevels.push(orderablePackLevel);
            }
        }
        else { orderablePackLevels.push(orderablePackLevel); }

        return orderablePackLevels;
    }

    public onCancel(): void {
        this.dialogRef.close();
    }

}
