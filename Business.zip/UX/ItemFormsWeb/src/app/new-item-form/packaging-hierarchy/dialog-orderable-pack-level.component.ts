import { Component, OnInit, Inject, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PackagingHierarchyService } from './packaging-hierarchy.service';
import { IOrderingLevels , IVendorDomain , IOrderablePackLevel, OrderablePackLevel } from './packaging-hierarchy.interface';
import { IListItem } from '../../shared/common.interface';
import { DialogActionComponent } from '../common/dialogs/dialog-action.component';

@Component({
  selector: 'ifw-dialog-orderable-pack-level',
  templateUrl: './dialog-orderable-pack-level.component.html',
  styleUrls: ['./dialog-orderable-pack-level.component.scss']
})
export class DialogOrderablePackLevelComponent implements OnInit {
    public orderingLevelsList: IOrderingLevels[];
    public orderablePackLevelGroup: FormGroup;
    public fullVendorsDomain: IVendorDomain[];
  //  public vendorOrgsList: IVendorDomain[];
    public vendorOrgsList: any[];
    public excludedOrgs: any[];
    public excludedVendorsForSelectedOrgs: any[];
   // public vendors: IListItem[];
    public packagingHierarchy: any;
    public includedVendors: any[];
    public includedOrgs: any[];
    public includedVendorsForSelectedOrgs: any[];
    public isEdit: boolean = false;
    onAddEvent = new EventEmitter<IOrderablePackLevel[]>();
    public orderingPackLevelsList: IOrderablePackLevel[];

    constructor(public dialogRef: MatDialogRef<DialogOrderablePackLevelComponent>,
        private formBuilder: FormBuilder,
        private packagingHierarchyService: PackagingHierarchyService,        
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialog: MatDialog) { }

    ngOnInit() {
        this.excludedVendorsForSelectedOrgs = [];
        this.includedVendorsForSelectedOrgs = [];
        this.includedVendors = []; 
        this.includedOrgs = [];
        this.excludedOrgs = [];


        if (this.data.orderablePackLevelRow != undefined) {
            this.orderablePackLevelGroup = this.formBuilder.group({
                rowId: this.data.orderablePackLevelRow.rowId,               
                orderingPackagingLevelID: '',//[this.data.orderablePackLevelRow.orderingPackagingLevelID, , [Validators.required]],
                orderPackQuantity: { value: this.data.orderablePackLevelRow.orderPackQuantity, disabled: true },
                vendorNumber: this.data.orderablePackLevelRow.vendorNumber

            });
            this.isEdit = true;
            this.orderingPackLevelsList = this.data.orderingPackLevelsList;
        }
        else {
            this.orderablePackLevelGroup = this.formBuilder.group({             
                rowId: 0,
                orderingPackagingLevelID: '',// [null , [Validators.required]],
                orderPackQuantity: { value: '', disabled: true },             
                
            });
            this.orderingPackLevelsList = this.data.orderingPackLevelsList;
        }

        this.packagingHierarchy = this.data.packagingHierarchy;
       

        this.packagingHierarchyService.getOrderingLevels().subscribe(res => {
            this.orderingLevelsList = res;
        })

          
        this.packagingHierarchyService.getVendorOrgs().subscribe(res => {         
            if (res) {
                //During edit , Org for that included vendor should be in the included org list , so delete the selected vendororganization from the excluded orgs list.
                if (this.data.orderablePackLevelRow != undefined) {
                    var selectedRowVendorOrg = res.indexOf(res.find(vo => (vo.vendorNumber == this.data.orderablePackLevelRow.vendorNumber)));
                    res.splice(selectedRowVendorOrg, 1);
                }
                this.vendorOrgsList = res.map(vo => ({ id: vo.organizationID, name: vo.organizationName }));
                this.excludedOrgs = this.vendorOrgsList;
                
                //if (this.data.orderablePackLevelRow != undefined) {
                //   // let IndexOfselectedRowOrg = this.excludedOrgs.indexOf(this.excludedOrgs.find(vo => (vo.id == this.data.orderablePackLevelRow.orgId)));
                //    let IndexOfselectedRowOrg = this.excludedOrgs.indexOf(this.excludedOrgs.find(vo => (vo.id == this.data.orderablePackLevelRow.orgId)));
                //    if (IndexOfselectedRowOrg > -1) {
                //        this.excludedOrgs.splice(IndexOfselectedRowOrg, 1);
                //    }
                //}
              
            }
        })

        this.packagingHierarchyService.getVendorsDomain().subscribe(res => {
            this.fullVendorsDomain = res;     

            //During edit , pre populate the included Org and included vendor
            //When the row is selected for edit , corresponding vendor in the edit row will be in the included vendors list and other vendors will be 
            //in the excluded vendor list.
            //Org for that included vendor will be in the included org .
            //All the other orgs will be in the excluded org list            
            if (this.data.orderablePackLevelRow != undefined) {
                var editRow = this.fullVendorsDomain.filter(vo => vo.vendorNumber == this.data.orderablePackLevelRow.vendorNumber)[0];
                this.includedOrgs.push({ id: editRow.organizationID, name: editRow.organizationName });                                
              //  this.includedVendorsForSelectedOrgs.push({ id: includedRow[0].vendorNumber, name: includedRow[0].vendorName, itemType: includedRow[0].vendorType, orgId: includedRow[0].organizationID, orgName: includedRow[0].organizationName });
              //  this.includedVendors = [...this.includedVendorsForSelectedOrgs];
                
                let vendorDomainsForEditRowOrg = this.fullVendorsDomain.filter(vo => vo.organizationID == editRow.organizationID);

                //corresponding vendor in the edit row will be in the included vendors list and other vendors will be in the excluded vendor list.
                for (let domain of vendorDomainsForEditRowOrg) {
                    if (domain.vendorNumber === this.data.orderablePackLevelRow.vendorNumber) {                        
                        this.includedVendorsForSelectedOrgs.push({ id: domain.vendorNumber, name: domain.vendorName, itemType: domain.vendorType, orgId: domain.organizationID, orgName: domain.organizationName });
                    }
                    else {
                        this.excludedVendorsForSelectedOrgs.push({ id: domain.vendorNumber, name: domain.vendorName, itemType: domain.vendorType, orgId: domain.organizationID, orgName: domain.organizationName });
                    }
                    this.includedVendors = [...this.includedVendorsForSelectedOrgs];
                }               
               
            }
        })

       
    }


    resetToInitialState() {
        this.orderablePackLevelGroup.patchValue({
            rowId: 0,
            orderingPackagingLevelID: null,
            orderPackQuantity: ''

        });
    }

    //On change of included Orgs list
    public getVendorsForSelectedOrgs(selectedOrgs: any[]) {
        this.excludedVendorsForSelectedOrgs = [];
        this.includedVendorsForSelectedOrgs = [];

        if (this.fullVendorsDomain !== undefined) {
            for (let selectedOrg of selectedOrgs) {
                let filteredVendorDomainForOrgs = this.fullVendorsDomain.filter(vo => vo.organizationID == selectedOrg.id);

                //if the vendor is already in the includedVendors list , push the vendor into the included vendor list , otherwise push it into excluded vendor list
                for (let domain of filteredVendorDomainForOrgs) {
                    this.includedVendorsForSelectedOrgs.push({ id: domain.vendorNumber, name: domain.vendorName, itemType: domain.vendorType, orgId: domain.organizationID , orgName : domain.organizationName });

                    //var includedVendor = this.includedVendors.find(v => v.id === vendor.vendorNumber)
                    //if (includedVendor !== undefined) {
                    //    this.includedVendorsForSelectedOrgs.push({ id: vendor.vendorNumber, name: vendor.vendorName , itemType: vendor.vendorType});
                    //}
                    //else {
                    //    this.excludedVendorsForSelectedOrgs.push({ id: vendor.vendorNumber, name: vendor.vendorName, itemType: vendor.vendorType});
                    //}
                }
            }
        }
        this.includedVendors = [...this.includedVendorsForSelectedOrgs];       
    }

    getIncludedVendors(includedVendors: any[]) {       
        this.includedVendors = [];
        this.includedVendors = [...includedVendors];
    }
  
    public CalculateOrderQty() : void{
        var orderingLevel = this.orderablePackLevelGroup.get('orderingPackagingLevelID').value             
        switch (orderingLevel)
        {
            case 1: // pallet
                if ((this.packagingHierarchy.layersOnPallet * this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit) == 0) {
                    let message: string = "Orderable Pack Qty is not available for Pallet.";
                    this.validateOrderingPackLevelSelection(message);
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.layersOnPallet * this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit });
                }
                break;
            case 2: // Tier
                if ((this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit) == 0) {
                    let message: string = "Orderable Pack Qty is not available for Tier.";
                    this.validateOrderingPackLevelSelection(message);
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.masterCaseSellingUnit * this.packagingHierarchy.masterCasesInSinglePalletLayer });
                }
                break;
            case 3: // MC
                if ((this.packagingHierarchy.masterCaseSellingUnit == 0) || (!this.packagingHierarchy.masterCaseSellingUnit)){
                    let message: string = "Orderable Pack Qty is not available for Master Case.";
                    this.validateOrderingPackLevelSelection(message);
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.masterCaseSellingUnit });
                }
                break;
            case 4: //IC
                if ((this.packagingHierarchy.innerCaseSellingUnits == 0) || (!this.packagingHierarchy.innerCaseSellingUnits)) {
                    let message: string = "Orderable Pack Qty is not available for Inner Case.";
                    this.validateOrderingPackLevelSelection(message);
                }
                else {
                    this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.innerCaseSellingUnits });
                }
                break;
            case 5: //Each
                this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': 1 });
                break;
        }      
    }

    resetOrderingLevel() {
        this.orderablePackLevelGroup.get('orderingPackagingLevelID').patchValue(null);
        this.orderablePackLevelGroup.get('orderPackQuantity').patchValue('');
    }

    public validateOrderingPackLevelSelection(message: string) {
        let data = {
            title: "",
            description: message,
            actions: [
                "Ok",
            ]
        }
        let dialogRefAction = this.dialog.open(DialogActionComponent, {
            width: '500px',
            disableClose: true,
            hasBackdrop: true,
            data: data
        });

        dialogRefAction.afterClosed().subscribe(result => {
            if (result.action == "Ok") {
                this.resetOrderingLevel();
                //this.orderablePackLevelGroup.patchValue({ 'orderingPackagingLevelID': '' });
            }
        });
    }

    //public onAdd(): void {
    //    if (this.orderablePackLevelGroup.invalid) {
    //       // return this.showErrors();
    //    }
    //    let orderablePackLevel: IOrderablePackLevel = (<any>Object).assign({}, this.orderablePackLevelGroup.value);
    //    if (this.CheckGTINExistInCurrentForm(additionalGTIN.formattedGtin)) {
    //        let data = { description: "GTIN Already exist cannot add the addtional GTIN", options: ["Ok"] }
    //        let dialogRef = this.dialog.open(DialogContentComponent, {
    //            disableClose: true,
    //            width: '400px',
    //            data: data
    //        });
    //        console.log("GTIN Already exist cannot add the addtional GTIN");
    //    }

    //    else {
    //        this.getAdditionalGtinDropdownSelectionData(additionalGTIN);
    //        this.dialogRef.close(additionalGTIN);
    //    }

    //}
    private showErrors(): void {
        if (!this.orderablePackLevelGroup.controls.orderingPackagingLevelID.value) {
            this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].setErrors({ required: true });
            this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].markAsTouched({ onlySelf: true });
        }
        //Object.keys(this.orderablePackLevelGroup.controls).forEach(field => {
        //    const control = this.orderablePackLevelGroup.get(field);
        //    control.markAsTouched({ onlySelf: true });
        //});
        return;
    } 

    validate(orderablePackLevel: IOrderablePackLevel): boolean {      
        if (!orderablePackLevel.orderingPackagingLevelID) {
            this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].setErrors({ notvalid: true });
            this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].markAsTouched({ onlySelf: true });
            return false;
        }
        return true;
    }
    public onAdd(): void {       
        
        this.showErrors();
        if (this.orderablePackLevelGroup.invalid) {
            return
        }    
        let orderablePackLevels = this.getOrderablePackLevelsForIncludedVendors();             
       if(orderablePackLevels !== undefined){            
           this.dialogRef.close(orderablePackLevels);
        }
    }

   



    public onAddContinue(): void {
        this.showErrors();
       if (this.orderablePackLevelGroup.invalid) {
            return 
       }
        let orderablePackLevels = this.getOrderablePackLevelsForIncludedVendors();                 
        this.onAddEvent.emit(orderablePackLevels);
        this.resetToInitialState();
      //  this.orderablePackLevelGroup.reset();
        
    }

    private getOrderableLevelDescriptions(orderablePackLevel: IOrderablePackLevel) {
        if (orderablePackLevel.orderingPackagingLevelID) {
            const orderingLevel = this.orderingLevelsList.find(ol => ol.id === orderablePackLevel.orderingPackagingLevelID);
            orderablePackLevel.orderingPackagingLevelDescription = orderingLevel.name;
        }
        //    return orderablePackLevel;
    }

    //validate(): void {
    //        this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].setErrors({ notvalid: true });
    //        this.orderablePackLevelGroup.controls["orderingPackagingLevelID"].markAsTouched({ onlySelf: true });
    //}
    private getOrderablePackLevelsForIncludedVendors(): IOrderablePackLevel[] {
        let orderablePackLevels: IOrderablePackLevel[] = this.orderingPackLevelsList == undefined ? [] : this.orderingPackLevelsList;
        //let rowId = this.orderablePackLevelGroup.get('rowId').value

        //Delete the selected row and add the new combinations. 
        if (this.isEdit) {
            let IndexOfselectedRowForEdit = orderablePackLevels.indexOf(orderablePackLevels.find(o => (o.rowId == this.data.orderablePackLevelRow.rowId)));
            if (IndexOfselectedRowForEdit > -1) {
                orderablePackLevels.splice(IndexOfselectedRowForEdit, 1);
            }
        }

        for (let includedVendor of this.includedVendors) {
            let orderablePackLevel: IOrderablePackLevel = new OrderablePackLevel();
            
            orderablePackLevel.vendorNumber = includedVendor.id;
            orderablePackLevel.vendorDescription = includedVendor.name;
            orderablePackLevel.vendorType = includedVendor.itemType;
            orderablePackLevel.organizationID = includedVendor.orgId;
            orderablePackLevel.organizationName = includedVendor.organizationName;
            //orderablePackLevel.orderingPackagingLevelID = this.orderablePackLevelGroup.get('orderingPackagingLevelID').value != null ? this.orderablePackLevelGroup.get('orderingPackagingLevelID').value : "" ;
            orderablePackLevel.orderingPackagingLevelID = this.orderablePackLevelGroup.get('orderingPackagingLevelID').value;
            orderablePackLevel.orderPackQuantity = this.orderablePackLevelGroup.get('orderPackQuantity').value;
            orderablePackLevel.isDirty = true;
            this.getOrderableLevelDescriptions(orderablePackLevel);
            //if (!this.validate(orderablePackLevel)) {
            //    return;
            //}

            //If the vendor and ordering level combination is already there in the list/grid , ignore it and don't add it again.
            if (orderablePackLevels.length > 0) {              
                var matchingOrderablePackLevel = orderablePackLevels.find(o => (o.vendorNumber == orderablePackLevel.vendorNumber && o.orderingPackagingLevelID == orderablePackLevel.orderingPackagingLevelID));
                if (matchingOrderablePackLevel == undefined) {
                    orderablePackLevels.push(orderablePackLevel);
                }
            }
            else { orderablePackLevels.push(orderablePackLevel); }
           
        }

        this.orderingPackLevelsList = orderablePackLevels;
        return orderablePackLevels;
    }

    public onCancel(): void {
        this.dialogRef.close();
    }
}
