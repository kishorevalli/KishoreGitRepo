import { Component, OnInit, Inject, forwardRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { NewItemFormService } from '../new-item-form.service';
import { PackagingHierarchyService } from './packaging-hierarchy.service';
import { IRetailPackType, ICaseCodeType , IVendorDomain , IOrderablePackLevel , IPackagingHierarchy } from './packaging-hierarchy.interface';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogOrderablePackLevelComponent } from './dialog-orderable-pack-level.component';
import { GridEvent } from '../../shared/grid/grid-event';
import { gtinValidator, GtinValidatorOptions, GTINValidatorHelper } from '../common/validators/gtin.validator'; 
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { IItemFormDto, ItemFormDto, UserType, IGTINWithCheckdigitDto, NewItemTab} from '../new-item-form.interface';
import { IErrorDTO, ErrorDTO  } from '../../shared/common.interface';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import { catchError, tap, map } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { Subject } from 'rxjs/Subject';
import { DialogActionComponent } from '../common/dialogs/dialog-action.component';
//import { DialogContentComponent } from './dialog-content.component';

@Component({
    selector: 'ifw-packaging-hierarchy-vendor',
    templateUrl: './packaging-hierarchy-vendor.component.html',
    styleUrls: ['./packaging-hierarchy-vendor.component.scss']
})
export class PackagingHierarchyVendorComponent implements OnInit {
    itemFormDisplayID: number;
    public itemFormID: number;
    public packagingHierarchyFormArray: FormArray;
    public retailPackTypesList: IRetailPackType[];
    public vendorOrgsList: IVendorDomain[];
    public orderablePackLevel: IOrderablePackLevel;
    activeTabIndex = 0;
    public orderablePackLevelsList: IOrderablePackLevel[];
   // data: IOrderablePackLevel[];
    gtinHelper: GTINValidatorHelper;
    showSpinner: boolean = false;
    skipSaveTab: boolean = false;
    formErrors: any;
    public panelErrorList: any;
    isShipper: boolean = false;
    vendorListInDsd:any[] = [];
    popUpMessages: IErrorDTO[];

    

    // GRID
    //public dataTabs: any = [];
    public gridData: IOrderablePackLevel[] = [];
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = true;
    public filterBy: string = '';
    public filterValue: string = '';
    public sortable: boolean = true;
    public active: string = '';
    public direction: string = '';
    public errors: string[];
    public GTINList: IGTINWithCheckdigitDto[];


    constructor(private formBuilder: FormBuilder,
        private newItemFormService: NewItemFormService,
        private packagingHierarchyService: PackagingHierarchyService,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private router: Router,
        private route: ActivatedRoute) { }

    ngOnInit() {
        this.gtinHelper = new GTINValidatorHelper({});
        this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        this.itemFormID = this.newItemFormService.itemFormID;
        this.createFormArray();
        this.formErrors = {};
        this.panelErrorList = {};
        this.errors = [];
      //  this.orderablePackLevelsList = [];
        this.packagingHierarchyService.GetDsdVendorsExistInDsdForItemForm(this.newItemFormService.itemFormID).subscribe(res => {
            this.vendorListInDsd = res;
        });
  
        this.GetPackagingHierarchies(this.itemFormID, false);

      

        //this.packagingHierarchyService.getRetailPackTypesForItemForm(this.itemFormID).subscribe(res => {
        //    this.retailPackTypesList = res;
        //    if (res.length == 0) {
        //        this.packagingHierarchyFormArray.push(this.buildPackagingHierarchyForDefaultRetailPack());
        //    }
        //    else {
        //        for (var retailPack of this.retailPackTypesList) {
        //            this.packagingHierarchyFormArray.push(this.buildPackagingHierarchyForRetailPack(retailPack));
        //        }
        //    }
        //});


        this.pagination = true;
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        let errorDTO: IErrorDTO = new ErrorDTO();
        errorDTO.tabName = 'Packaging Hierarchy';
        errorDTO.severityLevel = 'Message';
        this.newItemFormService.GetErrorMessagesByType(errorDTO).subscribe(res => {
            this.popUpMessages = res;
        });
      
  //      this.LoadOrderablePackLevelsList();
    }

    createFormArray() {
        this.packagingHierarchyFormArray = this.formBuilder.array([]);
    }

    

    buildPackagingHierarchyForDefaultRetailPack() {
        let isShipper = this.newItemFormService.itemCaseTypeID == 2 ? true : false;
        return this.formBuilder.group({
            id: 0,
            retailPackType: { value: '', disabled: true },
            retailPackSize: { value: '', disabled: true },
            retailPackTypeDescription: { value: 'NON RETAIL', disabled: true },
            size: { value: '', disabled: true },
            sizeUOM: { value: '', disabled: true },
            sizeUOMDescription: { value: '', disabled: true },
            labelAmount: { value: '', disabled: true },
            masterCaseCodeType: 'RG',
            masterCaseGTIN: '',
            masterCaseFormattedGtin: '',
            masterCaseGTINCheckDigit: '',
            masterCaseVendorItemGTIN: '',
            masterCaseSellingUnit: { value: isShipper ? 1 : '', disabled: isShipper },
            masterCaseWeight: '',
            masterCaseNetWeight: '',
            masterCaseHeight: '',
            masterCaseLength: '',
            masterCaseDepth: '',
            masterCaseCubicFootage: { value: '', disabled: true },
            innerCaseCodeType: '',
            innerPackExist: { value: isShipper ? 'N' : '', disabled: isShipper },
            innerCaseGTIN: '',
            innerCaseFormattedGtin: '',
            innerCaseGTINCheckDigit: '',
            innerCaseSellingUnits: '',
            innerCaseWeight: '',
            innerCaseNetWeight: '',
            innerCaseHeight: '',
            innerCaseLength: '',
            innerCaseDepth: '',
            innerCaseCubicFootage: { value: '', disabled: true },
            masterCasesInSinglePalletLayer: '',
            layersOnPallet: '',
            palletGTIN: '',
            palletQuantity: { value: '', disabled: true },
            palletCubicFootage: { value: '', disabled: true },
            isDirty: false,     
            phName: '',                 
            orderablePackLevels: this.formBuilder.array([])                
        });
    }


    buildPackagingHierarchyForExisting(packagingHierarchy: IPackagingHierarchy) : FormGroup {
        // let caseDetailsFormGroup: FormGroup;
        let isShipper = this.newItemFormService.itemCaseTypeID == 2 ? true : false;
        return this.formBuilder.group({
            id: packagingHierarchy.id,            
            retailPackType: { value: packagingHierarchy.retailPackType, disabled: true },
            retailPackSize: { value: packagingHierarchy.retailPackSize, disabled: true },
            retailPackTypeDescription: { value: packagingHierarchy.retailPackTypeDescription, disabled: true },
            size: { value: packagingHierarchy.size, disabled: true },
            sizeUOM: { value: packagingHierarchy.sizeUOM, disabled: true },
            sizeUOMDescription: { value: packagingHierarchy.sizeUOMDescription, disabled: true },
            labelAmount: { value: packagingHierarchy.labelAmount, disabled: true },
            masterCaseCodeType: packagingHierarchy.masterCaseCodeType,
            masterCaseGTIN: packagingHierarchy.masterCaseGTIN,
            masterCaseFormattedGtin: packagingHierarchy.masterCaseFormattedGtin,
            masterCaseGTINCheckDigit: packagingHierarchy.masterCaseGTINCheckDigit,
            masterCaseVendorItemGTIN: packagingHierarchy.masterCaseVendorItemGTIN,
            masterCaseSellingUnit: { value: isShipper ? 1 : packagingHierarchy.masterCaseSellingUnit, disabled: isShipper },
            masterCaseWeight: packagingHierarchy.masterCaseWeight,
            masterCaseNetWeight: packagingHierarchy.masterCaseNetWeight,
            masterCaseHeight: packagingHierarchy.masterCaseHeight,
            masterCaseLength: packagingHierarchy.masterCaseLength,
            masterCaseDepth: packagingHierarchy.masterCaseDepth,
            masterCaseCubicFootage: { value: packagingHierarchy.masterCaseCubicFootage, disabled: true },
            innerCaseCodeType: packagingHierarchy.innerCaseCodeType,
            innerPackExist: { value: isShipper ? 'N' : packagingHierarchy.innerPackExist, disabled: isShipper },
            innerCaseGTIN: { value: isShipper ? '' : packagingHierarchy.innerCaseGTIN, disabled: isShipper }, 
            innerCaseFormattedGtin: { value: isShipper ? '' : packagingHierarchy.innerCaseFormattedGtin, disabled: isShipper }, 
            innerCaseGTINCheckDigit: { value: isShipper ? '' : packagingHierarchy.innerCaseGTINCheckDigit, disabled: isShipper },
            innerCaseSellingUnits: { value: isShipper ? '' : packagingHierarchy.innerCaseSellingUnits, disabled: isShipper },
            innerCaseWeight: { value: isShipper ? '' : packagingHierarchy.innerCaseWeight, disabled: isShipper }, 
            innerCaseNetWeight: { value: isShipper ? '' : packagingHierarchy.innerCaseNetWeight, disabled: isShipper }, 
            innerCaseHeight: { value: isShipper ? '' : packagingHierarchy.innerCaseHeight, disabled: isShipper },  
            innerCaseLength: { value: isShipper ? '' : packagingHierarchy.innerCaseLength, disabled: isShipper },    
            innerCaseDepth: { value: isShipper ? '' : packagingHierarchy.innerCaseDepth, disabled: isShipper },    
            innerCaseCubicFootage: { value: isShipper ? '' : packagingHierarchy.innerCaseCubicFootage, disabled: true },   
            masterCasesInSinglePalletLayer: packagingHierarchy.masterCasesInSinglePalletLayer,
            layersOnPallet: packagingHierarchy.layersOnPallet,
            palletGTIN:  packagingHierarchy.palletGTIN,
            palletQuantity: { value: packagingHierarchy.palletQuantity, disabled: true },
            palletCubicFootage: { value: packagingHierarchy.palletCubicFootage, disabled: true },
            isDirty: false,
            phName: (packagingHierarchy.retailPackSize != null ? String(packagingHierarchy.retailPackSize) : "") +
                (packagingHierarchy.retailPackType != null ? String(packagingHierarchy.retailPackType) : "") +
                    (packagingHierarchy.size != null ? String(packagingHierarchy.size) : "") +
                        (packagingHierarchy.sizeUOM != null ? String(packagingHierarchy.sizeUOM) : "") +
                            (packagingHierarchy.labelAmount != null ? String(packagingHierarchy.labelAmount) : ""),
            orderablePackLevels: this.buildOrderablePackLevels(packagingHierarchy.orderablePackLevels)

        });
    }

    public isNonRetailPack(val : string) : boolean
    {
        if (val.trim() === "")
            return false;
        else
            return true;
    }


    public isPrePack(val: string): boolean {
        if (val.trim() === "P")
            return true;
        else
            return false;
    }

    public AddOrderablePackLevelsDialog(): void {
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
     //   console.log(this.dialog);
        let dialogRef = this.dialog.open(DialogOrderablePackLevelComponent, {
            width: '1400px',
           // height: '600px',
            data: { orderingPackLevelsList: packagingHierarchy.orderablePackLevels , orderablePackLevelRow: this.orderablePackLevel, packagingHierarchy: packagingHierarchy, isBuyer: false }
        });
        const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {                 
            var currentFormGroup = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
            var orderablePackFormArrray = <FormArray>currentFormGroup.get('orderablePackLevels');
            this.clearFormArray(orderablePackFormArrray);
            for (const opl of result) {
                orderablePackFormArrray.push(this.buildOrderablePackLevel(opl));
            }        
            this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
            this.checkDSDVendorTypeInOrderablePackLevels();
            this.UpdateOrderablePackeLevelsRowId();            
            this.getInitialOrderablePackLevelsData();            
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {               
                var currentFormGroup = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
                var orderablePackFormArrray = <FormArray>currentFormGroup.get('orderablePackLevels');
                this.clearFormArray(orderablePackFormArrray);
                for (const opl of result) {
                    orderablePackFormArrray.push(this.buildOrderablePackLevel(opl));                  
                }                
                this.UpdateOrderablePackeLevelsRowId();
                this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
            }
            this.checkDSDVendorTypeInOrderablePackLevels();
            this.getInitialOrderablePackLevelsData();
            console.log('The dialog was closed');            
        });
    }
    checkDSDVendorTypeInOrderablePackLevels(): void {
        let dsdVendors: boolean = false;
        for (const currentFormGroup of this.packagingHierarchyFormArray.controls) {
            const found = (<FormArray>currentFormGroup.get("orderablePackLevels")).controls.find(op => {
                var formGroup = <FormGroup>op;
                return formGroup.controls.vendorType.value == "DSD";
            });
            if (found) {
                dsdVendors = true;
                console.log("dsdVendors found:"+ found.get("vendorDescription").value);
                break;
            }
        }
        let dsdVendorLink: NewItemTab = this.newItemFormService.links.find(x => x.link == 'dsd-authorization-request');
        dsdVendorLink.disabled = !dsdVendors;
    }
    clearFormArray = (formArray: FormArray) => {
        while (formArray.length !== 0) {
            formArray.removeAt(0);
        }
    }

    buildOrderablePackLevel(orderablePackLevel: IOrderablePackLevel) {  
        return this.formBuilder.group({            
            vendorNumber: orderablePackLevel.vendorNumber,
            vendorDescription: orderablePackLevel.vendorDescription,
            vendorType: orderablePackLevel.vendorType,
            orderingPackagingLevelID: orderablePackLevel.orderingPackagingLevelID,
            orderingPackagingLevelDescription: orderablePackLevel.orderingPackagingLevelDescription,
            orderPackQuantity: orderablePackLevel.orderPackQuantity,
            orgId: orderablePackLevel.organizationID,
            orgName: orderablePackLevel.organizationName ,
            rowId: orderablePackLevel.rowId       
        });      
    }

    buildOrderablePackLevels(orderablePackLevels: IOrderablePackLevel[]): FormArray {
        const formArray = this.formBuilder.array([]);
        let count: number = 1;
        for (const opl of orderablePackLevels) {    
            opl.rowId = count++;        
            formArray.push(this.buildOrderablePackLevel(opl));         
        }
        return formArray;
    }

    public editOrderablePackLevel(rowId: number): void {
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        let orderablePackLevelRow: IOrderablePackLevel = packagingHierarchy.orderablePackLevels.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogOrderablePackLevelComponent, {
            width: '1400px',
          //  height: '800px',
            data: { orderingPackLevelsList: packagingHierarchy.orderablePackLevels , orderablePackLevelRow: orderablePackLevelRow, packagingHierarchy: packagingHierarchy,isBuyer: false }
        });
        const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {            
            var currentFormGroup = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
            var orderablePackFormArrray = <FormArray>currentFormGroup.get('orderablePackLevels');
            this.clearFormArray(orderablePackFormArrray);
            for (const opl of result) {
                orderablePackFormArrray.push(this.buildOrderablePackLevel(opl));
            }        
            this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
            this.checkDSDVendorTypeInOrderablePackLevels();
            this.UpdateOrderablePackeLevelsRowId();
            this.getInitialOrderablePackLevelsData();
        });
        dialogRef.afterClosed().subscribe(result => {           
            if (result) {                
                this.addOrderablePackLevels(result);      
                this.checkDSDVendorTypeInOrderablePackLevels();       
                this.UpdateOrderablePackeLevelsRowId();
                this.getInitialOrderablePackLevelsData();
              //  console.log('The dialog was closed');
              //  console.log(result);
            }
        });
    }

    private addOrderablePackLevels(orderablePackLevels: IOrderablePackLevel[]): FormArray {

        let currentFormGroup = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
        let orderablePackFormArrray = <FormArray>currentFormGroup.get('orderablePackLevels');
        this.clearFormArray(orderablePackFormArrray);
        for (const opl of orderablePackLevels) {
            orderablePackFormArrray.push(this.buildOrderablePackLevel(opl));
        }        
        this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
        return orderablePackFormArrray;
    }

    private UpdateOrderablePackeLevelsRowId() {
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        let count: number = 1;
        if (packagingHierarchy.orderablePackLevels != undefined) {
            for (let orderablePack of packagingHierarchy.orderablePackLevels) {
                orderablePack.rowId = count++;
            }
        }
    }
   
    LoadOrderablePackLevelsList(): void {
        //this.shipperItemCompositionService.getShipperCompositionItems(this.itemFormID).subscribe(
        //    res => {
        //        this.shipperItemCompositionList = res;
        //        this.UpdateShipperItemCompositionRowId();
        this.getInitialOrderablePackLevelsData();
              
            //}
        //);
    }



    onSelectTabChange(event) {        
        this.getInitialOrderablePackLevelsData();        
    }

    // Grid specific events
    getGridData() {
        if (!this.gridData) return [];
        return this.gridData;
        //let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        //return packagingHierarchy.orderablePackLevels;    
    }

    getOrderablePackLevelsData(gridEvent: GridEvent) {
        this.gridData = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }
    getInitialOrderablePackLevelsData() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getOrderablePackLevelsData(gridEvent);
    }
    /**
  * return the filtered or shallow copy without changing the original data
  */
    performFilter(gridEvent: GridEvent): any[] {
        console.log(this.activeTabIndex);
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return packagingHierarchy.orderablePackLevels.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return packagingHierarchy.orderablePackLevels.slice();
        }
        return packagingHierarchy.orderablePackLevels.slice();
    }
   
      /**
       * paginate the result set
       */
    private pageData(gridEvent: GridEvent): void {

        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

    /**
* sort the filtered result based on sort column and order
*/
    private sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }

    performAction(action: any) {
        switch (action.actionName) {
            case "Save":
                this.savePackagingHierarchy(action.createdFormStatusID, action.actionID);
                break;
            case "Delete":
                this.deleteItemForm();
                break;
            case "Submit":
                this.submitPackagingHierarchy(action.createdFormStatusID, action.actionID);
                break;

        }
    }


    public savePackagingHierarchy(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            if (res) {
                this.snackBar.open("Saved successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
                this.GetPackagingHierarchies(this.itemFormID, true);
              
            }
        });
    }

    public submitPackagingHierarchy(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            //this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
            //    this.GetPackagingHierarchies(this.itemFormID, true);
            //});
            if (res) {
                this.snackBar.open("Submitted successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
            else {               
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });

            }
        });
    }



    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
       // if (this.skipSaveTab) return of(true);
        
        const packagingHierarchyList: IPackagingHierarchy[] = [];
        this.checkIfDirty();      
        for (let idx = 0; idx < this.packagingHierarchyFormArray.controls.length; idx++) {
          //  var packagingHierarchyformGroup = this.packagingHierarchyFormArray.controls[idx];
            let phFromGroup = <FormGroup>this.packagingHierarchyFormArray.at(idx);
            const packagingHierarchy: IPackagingHierarchy = (<any>Object).assign({}, phFromGroup.getRawValue());
            packagingHierarchy.itemFormID = this.newItemFormService.itemFormID;
            //if createdFormStatusID is 0 (when changing tab) , send the currentstatus .
            createdFormStatusID = createdFormStatusID == undefined ? this.newItemFormService.formCurrentStatusID : createdFormStatusID;
            packagingHierarchy.formStatusID = createdFormStatusID;
            packagingHierarchy.formActionID = actionID;
            packagingHierarchy.submittedUserTypeID = UserType.Vendor;
            packagingHierarchyList.push(packagingHierarchy);
        }
        const saveSuccess$: Subject<boolean> = new Subject<boolean>();
        this.validateMappedDsdVendors(packagingHierarchyList).subscribe(res => {
            console.log(res+ " validateMappedDsdVendors");
            if(res){
               this.saveApi(packagingHierarchyList, createdFormStatusID , actionID).subscribe(res => {
                   if(res){
                    saveSuccess$.next(true);
                    saveSuccess$.complete();
                   }
                   else {
                    saveSuccess$.next(false);
                    saveSuccess$.complete();
                   }
               });
            }
            else {
                this.reset();
                saveSuccess$.next(false);
                saveSuccess$.complete();
            }
        });
        return saveSuccess$
    }
    private saveApi(packagingHierarchyList,createdFormStatusID : number,actionID: number ):Observable<boolean>{
        this.showSpinner = true;
        this.newItemFormService.showLoadingSpinner = true;
        this.errors = [];
        return this.packagingHierarchyService.savePackagingHierarchies(packagingHierarchyList).pipe(
            map(res => {

                if(res.validation)
                    this.newItemFormService.addItemValidation(res.validation);
                if(res.status)
                    this.newItemFormService.formCurrentStatusID = createdFormStatusID;

                console.log("saved/submited successfully.");
                this.showSpinner = false;

                //if (res.validation) {
                //    this.handlePHValidation(res.validation);                  
                //}


                if (actionID)
                    this.GetPackagingHierarchies(this.itemFormID, true);



                this.newItemFormService.showLoadingSpinner = false;
                return res.status;
            }),
            catchError((err) => {
                this.showSpinner = false;
                this.newItemFormService.showLoadingSpinner = false;
                this.showSpinner = false;
                if (err.status === 400) {
                    this.newItemFormService.addItemValidation(err.error);
                    let validationRetailPackPHErrors = err.error.subTabValidations;
                    this.handlePHValidation(err.error);     
                    //this.handleValidationRetailPackPHErrors(validationRetailPackPHErrors);
                    // this.handleItemPHTabValidation(err.error);
                }
                console.log("saved error. " + err.status);
                window.scrollTo(0, 150);
                this.snackBar.open("Please correct the errors.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                });
                return of(false);
            })
        );
    }
    private validateMappedDsdVendors(packagingHierarchyList: IPackagingHierarchy[]): Observable<boolean> {
        var vendorList = packagingHierarchyList.map(op => op.orderablePackLevels.map(item => item.vendorNumber));
        var flattened = vendorList.reduce(
            ( accumulator, currentValue ) => accumulator.concat(currentValue),
            []
          );
        let dsdNotMappedList: number[] = [];
        for (var dsdVendor of this.vendorListInDsd) {
            const found = flattened.find(item => {
                return item == dsdVendor.vendorNumber;
            });
            if(!found) dsdNotMappedList.push(found);
        }
        if (dsdNotMappedList.length > 0){
            let data = {
                title: "",
                description: this.showMessage("PCH24") + '\n' + "Please click 'Ok' to continue or 'Cancel' to revert the current changes?",
                actions: [
                    "Cancel",
                    "Ok"
                ]
            }
            let dialog = this.dialog.open(DialogActionComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            return dialog.afterClosed().pipe(
                map(option => {
                    if (option && option.action == "Ok") {
                        return true;
                    }
                    return false;
                })
            );
        }
        else return of(true);
        
    }
    private showMessage(code:string):string{
        let messageDesc:string = '';
        console.log(this.popUpMessages);
        if(this.popUpMessages.some(error => error.errorCode == code))
        messageDesc = this.popUpMessages.find(error => error.errorCode == code).errorDescription
        return messageDesc;
    }

    //handleItemPHTabValidation(itemValidation) {
    //    //let gpaErrors = itemValidation.errors;
    //    //let gpaWarnings = itemValidation.warnings;
    //    //this.handleGpaValidationErrors(gpaErrors);
    //    //this.handleGpaValidationWarnings(gpaWarnings);
    //    let validationRetailPackPHErrors = itemValidation.subTabValidations;
    //    if (this.panel) {
    //        this.panel.handleValidationErrors(validationPanelErrors);
    //    }
    //}
    handlePHValidation(itemValidation) {
        let phErrors = itemValidation.errors;
        let phWarnings = itemValidation.warnings;
        this.handlePHValidationErrors(phErrors);
        this.handlePHValidationWarnings(phWarnings);
        this.handleValidationRetailPackPHErrors(itemValidation.subTabValidations);
    }

    handlePHValidationErrors(phErrors: any[]) {
        for (var key in phErrors) {
            let errorObj = phErrors[key];
            this.errors.push(errorObj.errorDescription);
        }
    }

    handlePHValidationWarnings(phWarnings: any[]) {
        for (var key in phWarnings) {
            let errorObj = phWarnings[key];
            this.errors.push(errorObj.errorDescription);
        }
    }

    handleValidationRetailPackPHErrors(panelErrors: any[]) {
        for (var panelError of panelErrors) {
            var tabName = panelError["subTabName"];
            const _errorCount: number = panelError["errors"].length;
            const _warningCount: number = panelError["warnings"].length;
            var panelGroup = <FormGroup>this.getPackagingHierarchyFormGroup(tabName);
            // go through errors and attach to controls
            let _errors: string[] = [];
            for (const _error of panelError["errors"]) {
                let fieldName = _error.controlName;
                if (fieldName && panelGroup.controls[fieldName]) {
                    panelGroup.controls[fieldName].setErrors({ invalid: true });
                    panelGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = _error.errorDescription;
                }
                else {
                    _errors.push(_error.errorDescription);
                }
            }
            // go through warnings and attach to controls
            let _warnings: string[] = [];
            for (const _warning of panelError["warnings"]) {
                let fieldName = _warning.controlName;
                if (fieldName && panelGroup.controls[fieldName]) {
                    panelGroup.controls[fieldName].setErrors({ warning: true });
                    panelGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = _warning.errorDescription;
                }
                else {
                    _warnings.push(_warning.errorDescription);
                }
            }
            // pass to object to show in UI
            this.populateError(tabName, _errors, _warnings, _errorCount, _warningCount);
        }
       // this.updateChanges();
    }

    populateError(tabName: string, errorList: string[], warningList: string[], errorCount: number, warningCount: number) {
        this.panelErrorList[tabName] = {
            "errors": errorList,
            "warnings": warningList,
            "errorCount": errorCount,
            "warningCount": warningCount
        };
    }

    getPackagingHierarchyFormGroup(tabName: string) {
        const findPH = this.packagingHierarchyFormArray.controls.find(ph => {
            const formGroup = <FormGroup>ph;
            return formGroup.controls["phName"].value === tabName;
        });
        return findPH;
    }


    private createDefaultPackagingHierarchiesByNonRetailpackType() {
        this.packagingHierarchyFormArray.push(this.buildPackagingHierarchyForDefaultRetailPack());
    }

    //Get Packaging Hierarchies
    private GetPackagingHierarchies(itemFormID: number, afterSave: boolean) {
        //get existing packaging hierarchies from the packaging hierarchy table or new packaging hierarchies based on new retail pack types in the BID tables.
        this.packagingHierarchyService.getPackagingHierarchies(this.itemFormID).subscribe(res => {
            if (res.length > 0) { 
                this.packagingHierarchyFormArray = this.formBuilder.array([]);
                for (const packagingHierarchy of res) {
                    const packagingHierarchyFormGroup = this.buildPackagingHierarchyForExisting(packagingHierarchy);
                    packagingHierarchyFormGroup.markAsPristine();
                    packagingHierarchyFormGroup.markAsUntouched();
                    this.packagingHierarchyFormArray.push(packagingHierarchyFormGroup);
                }            
                //reset the current form status ID in new item form service.
                this.newItemFormService.formCurrentStatusID = res[0].formStatusID;
                this.getInitialOrderablePackLevelsData();
                console.log("GetPackagingHierarchies");
            }
            else {   //Default Packaging Hierarchie will be created for Non Retail pack Type with blank retail pack description.
                this.createDefaultPackagingHierarchiesByNonRetailpackType();
            }

            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
                const validations: any = this.newItemFormService.getItemValidation("Packaging Hierarchy");
                if (validations) {
                    this.handlePHValidation(validations);
                }
            });
            //if (afterSave) {
            //    this.showSpinner = false;
            //   // const validations: any = this.newItemFormService.getItemValidation("General Product Attributes");
            //  //  if (validations) {
            //      //  this.handleItemGpaValidation(validations);
            //  //  }
            //}
            //else {
            //    setTimeout(() => {
            //        const validations: any = this.newItemFormService.getItemValidation("Packaging Hierarchy");
            //        if (validations) {
            //            console.log("validations running.")
            //            this.handlePHValidation(validations);
            //            //this.handleValidationRetailPackPHErrors(validations.subTabValidations);
            //        }
            //    }, 0); 
            //}
        },
            (err) => {
                this.showSpinner = false;
            });
    }

    reset() {
      //  this.resetToInitialState();
        this.GetPackagingHierarchies(this.itemFormID, false);
    }


    checkIfDirty() {
        // Set if any specific retail pack - packaging Hierarchy group is dirty          
        for (let idx = 0; idx < this.packagingHierarchyFormArray.controls.length; idx++) {
            var formGroup = this.packagingHierarchyFormArray.controls[idx];
            if (formGroup.dirty === true) { formGroup.patchValue({ 'isDirty': formGroup.dirty }); }
        }
    }


    //checkIfDirty() {
    //    // Set if any GPA is dirty
    //    this.GeneralProductAttributesvendorFormGroup.patchValue({ 'isDirty': this.GeneralProductAttributesvendorFormGroup.dirty });
    //    // Set if any specific nutritional panel is dirty  
    //    var formArray = (<FormArray>this.GeneralProductAttributesvendorFormGroup.get('nutritionalPanelList'));
    //    for (let idx = 0; idx < formArray.controls.length; idx++) {
    //        var formGroup = formArray.controls[idx];
    //        formGroup.patchValue({ 'isDirty': formGroup.dirty });
    //    }
    //}

    public deleteOrderablePackLevel(rowId: number): void {
        //let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        let data = { description: "Are you sure you want to delete Orderable Pack Level ?", actions: ["No", "Yes"] }
        let dialogRef = this.dialog.open(ConfirmDialogComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                var tabData = <FormGroup>(this.packagingHierarchyFormArray.at(this.activeTabIndex));
                var orderablePackLevels = <FormArray>tabData.controls.orderablePackLevels;
                var index = orderablePackLevels.value.findIndex(x => x.rowId == rowId);
                if (index > -1) {
                    orderablePackLevels.removeAt(index);
                }
               // orderablePackLevels.removeAt(id);
                this.packagingHierarchyFormArray.at(this.activeTabIndex).markAsDirty();
                this.checkDSDVendorTypeInOrderablePackLevels();
                this.UpdateOrderablePackeLevelsRowId();
                this.getInitialOrderablePackLevelsData();
            }

        });
        
    }

    public deleteItemForm(): void {
        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.showSpinner = true;
                this.newItemFormService.deleteItemForm().subscribe(res => {

                    this.showSpinner = false;
                    if (res != undefined) {                           
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" });
                },
                    (err) => {
                        this.showSpinner = false;
                        if (err.status === 400) {
                            // handle validation error
                            let validationErrorDictionary = err.error.modelState;
                         //   this.handleGpaValidationErrors(validationErrorDictionary);
                        } else {
                             this.formErrors.push("Unhandled expection occured.");
                        }
                        window.scrollTo(0, 0);
                    })
            }
        });
    }

    //public calculatePalletQty(): void {
    //    let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
    //    packagingHierarchy.palletQuantity = packagingHierarchy.layersOnPallet * packagingHierarchy.masterCasesInSinglePalletLayer;   
    //}

    public ReCalculateOrderQty(): void {
        let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        for (var pack of this.orderablePackLevelsList) {
            switch (pack.orderingPackagingLevelID) {
                case 1: // pallet                    
                    pack.orderPackQuantity = packagingHierarchy.layersOnPallet * packagingHierarchy.masterCasesInSinglePalletLayer * packagingHierarchy.masterCaseSellingUnit;
                    break;
                case 2: // Tier                    
                    pack.orderPackQuantity = packagingHierarchy.layersOnPallet * packagingHierarchy.masterCasesInSinglePalletLayer;
                    break;
                case 3: // MC                    
                    pack.orderPackQuantity = packagingHierarchy.masterCaseSellingUnit;
                    break;
                case 4: //IC                    
                    pack.orderPackQuantity = packagingHierarchy.innerCaseSellingUnit;
                    break;
                case 5: //Each
                    pack.orderPackQuantity = 1;
                    break;
            }
        }
    }
    
        //var orderingLevel = this.orderablePackLevelGroup.get('orderingPackagingLevelID').value
        //switch (orderingLevel) {
        //    case "1": // pallet
        //        this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.layersOnPallet * this.packagingHierarchy.masterCasesInSinglePalletLayer * this.packagingHierarchy.masterCaseSellingUnit });
        //        break;
        //    case "2": // Tier
        //        this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.layersOnPallet * this.packagingHierarchy.masterCasesInSinglePalletLayer });
        //        break;
        //    case "3": // MC
        //        this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.masterCaseSellingUnit });
        //        break;
        //    case "4": //IC
        //        this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': this.packagingHierarchy.innerCaseSellingUnit });
        //        break;
        //    case "5": //Each
        //        this.orderablePackLevelGroup.patchValue({ 'orderPackQuantity': 1 });
        //        break;
        //}
    }






    //public deleteAddtionalGtin(rowId: number): void {
    //    let data = { description: "Are you sure you want to delete Orderable Pack Level ?", actions: ["No", "Yes"] }
    //    let dialogRef = this.dialog.open(DialogContentComponent, {
    //        disableClose: true,
    //        width: '800px',
    //        data: data
    //    });

    //    dialogRef.afterClosed().subscribe(result => {
    //        if (result.action === "Yes") {
    //            var index = this.additionalGtinRows.findIndex(x => x.rowId == rowId);
    //            if (index > -1) {
    //                this.additionalGtinRows.splice(index, 1);
    //            }
    //            this.getInitialAdditionalGtinData();
    //        }

    //    });
    //}


//}
