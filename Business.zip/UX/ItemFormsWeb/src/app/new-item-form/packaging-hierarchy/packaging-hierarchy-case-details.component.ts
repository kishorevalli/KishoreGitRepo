import { Component, OnInit , Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { ICaseCodeType } from './packaging-hierarchy.interface';
import { PackagingHierarchyService } from './packaging-hierarchy.service';
import { NewItemFormService } from '../new-item-form.service';
import { IItemFormDto, ItemFormDto, UserType, IGTINWithCheckdigitDto } from '../new-item-form.interface';
import { gtinValidator, GtinValidatorOptions, GTINValidatorHelper } from '../common/validators/gtin.validator'; 

@Component({
  selector: 'ifw-packaging-hierarchy-case-details',
  templateUrl: './packaging-hierarchy-case-details.component.html',
  styleUrls: ['./packaging-hierarchy-case-details.component.scss']
})
export class PackagingHierarchyCaseDetailsComponent implements OnInit {

    @Input('packagingHierarchyFormGroup')
    public packagingHierarchyForm: FormGroup;

    @Input()
    public formErrors: any;
    public caseCodeTypesList: ICaseCodeType[];
    public mcCubicFootage: number;
    gtinHelper: GTINValidatorHelper;
    public GTINList: IGTINWithCheckdigitDto[];
     

    constructor(private packagingHierarchyService: PackagingHierarchyService,
        private newItemFormService: NewItemFormService) { }

    ngOnInit() {

        this.packagingHierarchyService.getCaseCodeTypes().subscribe(res => {
            this.caseCodeTypesList = res;
           }
        );

        this.newItemFormService.GetBasicItemDefinitionGTIN(this.newItemFormService.itemFormID).subscribe(res => {
            this.GTINList = res;
        });

        this.gtinHelper = new GTINValidatorHelper({});        
        //this.isShipper = this.newItemFormService.itemCaseTypeID == 2 ? true : false;

     //   this.formErrors = {};
    }

 
    changeInnerPackExists() {
        this.packagingHierarchyForm.patchValue({
            "innerCaseCodeType": '',
            "innerCaseGTIN": '',
            "innerCaseFormattedGtin": '',
            "innerCaseGTINCheckDigit": '',
            "innerCaseSellingUnits": '',
            "innerCaseWeight": '',
            "innerCaseNetWeight": '',
            "innerCaseHeight": '',
            "innerCaseLength": '',
            "innerCaseDepth": '',
            "innerCaseCubicFootage" : ''
        });
    }

    calculateMCCubicFootage() {    
        let cubicFootage = (this.packagingHierarchyForm.get("masterCaseHeight").value * this.packagingHierarchyForm.get("masterCaseLength").value * this.packagingHierarchyForm.get("masterCaseDepth").value) / 1728;    
        cubicFootage = +cubicFootage.toFixed(3);
        this.packagingHierarchyForm.patchValue({ "masterCaseCubicFootage": cubicFootage });
        this.calculatePalletCubicFootage();
    }

    calculateICCubicFootage() {
        let cubicFootage = (this.packagingHierarchyForm.get("innerCaseHeight").value * this.packagingHierarchyForm.get("innerCaseLength").value * this.packagingHierarchyForm.get("innerCaseDepth").value) / 1728;
        cubicFootage = +cubicFootage.toFixed(3);
        this.packagingHierarchyForm.patchValue({ "innerCaseCubicFootage": cubicFootage });
    }

   public calculatePalletCubicFootage() {
       let palletCubicFootage = (this.packagingHierarchyForm.get("masterCaseCubicFootage").value * this.packagingHierarchyForm.get("masterCasesInSinglePalletLayer").value * this.packagingHierarchyForm.get("layersOnPallet").value);
       palletCubicFootage = +palletCubicFootage.toFixed(3);
        this.packagingHierarchyForm.patchValue({ 'palletCubicFootage': palletCubicFootage});
    }

   public calculatePalletQuantity() : void{
       this.packagingHierarchyForm.patchValue({ 'palletQuantity': (this.packagingHierarchyForm.get("masterCasesInSinglePalletLayer").value * this.packagingHierarchyForm.get("layersOnPallet").value) });       
       this.calculatePalletCubicFootage();
    }
    public get masterCaseCheckDigitDisplay(): number {
        var formattedGtinControl = this.packagingHierarchyForm.get("masterCaseFormattedGtin");
        let gtin = formattedGtinControl.value;
        if(gtin.length == 15){
            return this.gtinHelper.getCheckdigit(gtin)
        }
        return null;
    }
    public FormatMasterCaseGtin(): void {        
        var formattedGtinControl = this.packagingHierarchyForm.get("masterCaseFormattedGtin");
        let gtin = formattedGtinControl.value;
        if (gtin.length > 7) {
            formattedGtinControl.patchValue(this.gtinHelper.padGtin(gtin, 13));
            this.gtinMCValidationRules();
        }        
    }
    private gtinMCValidationRules() {
        const formattedGtinControl = this.packagingHierarchyForm.controls.masterCaseFormattedGtin;
        formattedGtinControl.setValidators([gtinValidator({
            validateCheckDigit: true,
            range: true,
            type2: false,
            dummy: true,
            vendorCoupon: true,
            checkDigitCtrlName: 'masterCaseGTINCheckDigit'
        })]);
        formattedGtinControl.updateValueAndValidity();
    }
    public get innerCaseCheckDigitDisplay(): number {
        var formattedGtinControl = this.packagingHierarchyForm.get("innerCaseFormattedGtin");
        let gtin = formattedGtinControl.value;
        if(gtin.length == 15){
            return this.gtinHelper.getCheckdigit(gtin)
        }
        return null;
    }
    public FormatInnerCaseGtin(): void {
        var formattedGtinControl = this.packagingHierarchyForm.get("innerCaseFormattedGtin");
        let gtin = formattedGtinControl.value;
        if (gtin.length > 7) {
            formattedGtinControl.patchValue(this.gtinHelper.padGtin(gtin, 13));
            this.gtinInnerCaseValidationRules();
        }
    }
    private gtinInnerCaseValidationRules() {
        const formattedGtinControl = this.packagingHierarchyForm.controls.innerCaseFormattedGtin;
        formattedGtinControl.setValidators([gtinValidator({
            validateCheckDigit: true,
            range: true,
            type2: false,
            dummy: true,
            vendorCoupon: true,
            checkDigitCtrlName: 'innerCaseGTINCheckDigit'
        })]);
        formattedGtinControl.updateValueAndValidity();
    }


    getErrorMessage(control: FormControl, name: string) {
        for (let propertyName in control.errors) {
            if ((propertyName == "invalid" || propertyName == "warning") && this.formErrors[name]) {
                return this.formErrors[name];
            }
            if (control.errors.hasOwnProperty(propertyName) && control.touched) {
                return this.getValidatorErrorMessage(propertyName, control.errors[propertyName]);
            }
        }
        return null;
    }
    getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            'required': 'This field is required.',
            'email': 'This is not a valid email',
            'minlength': `This field should have atleast ${validatorValue.requiredLength} characters`,
            'beforePadding': 'This field is required.',
            'range': 'GTIN entered must be in range 000-00010-00000 to 999-99999-99999.',
            'type2': "GTIN entered is reserved for type -2 GTIN's.",
            'dummy': "GTIN entered is reserved for Dummy GTIN's.",
            'vendorCoupon': "GTIN entered is reserved for Vendor Coupons.",
            'checkDigitRequired': "GTIN Check digit is required to validate GTIN.",
            'checkDigit': 'GTIN is not valid for the entered check digit.',
            'notvalid': 'This is not a valid value',
        };
        return config[validatorName];
    }



}
