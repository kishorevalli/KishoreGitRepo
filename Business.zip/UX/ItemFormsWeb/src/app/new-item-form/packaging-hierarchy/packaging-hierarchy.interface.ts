﻿import { IItemFormDto, ItemFormDto, UserType } from '../new-item-form.interface';


export interface IRetailPackType {
    retailPackType: string;
    retailPackTypeDescription: string;
    retailPackSize: number;
    size: number
    sizeUOM: string;
    sizeUOMDescription: string;
    labelAmount: number;
}

export class  RetailPackType implements IRetailPackType{
    retailPackType: string;
    retailPackTypeDescription: string;
    retailPackSize: number;
    size: number
    sizeUOM: string;
    sizeUOMDescription: string;
    labelAmount: number;
}

export interface ICaseCodeType {
    caseCodeType: string;
    caseTypeDesc: string;
    sortOrder: number;
}

export class CaseCodeType implements ICaseCodeType {
    caseCodeType: string;
    caseTypeDesc: string;
    sortOrder: number;
}

export interface IOrderingLevels {
    id: number;
    name: string;
    sortOrder: number;

}

export class OrderingLevels implements IOrderingLevels {
    id: number;
    name: string;
    sortOrder: number;
}


export interface IVendorDomain {
    vendorNumber: number;
    vendorName: string;
    vendorType: string;
    organizationID: number;
    organizationName: string;
}

export class VendorDomain implements IVendorDomain {
    vendorNumber: number;
    vendorName: string;
    vendorType: string;
    organizationID: number;
    organizationName: string;
}

export interface IOrderablePackLevel {
    //includedVendors: string[];
    rowId: number;
    vendorNumber: number;
    vendorDescription: string;
    vendorType: string;
    warehouse: number;
    warehouseDescription: string;    
    shippingPackagingLevelID: number;
    shippingPackQty: number;
    shipMax: number;
    shipPallet: string;
    effectiveDate: Date;
    terminationDate: Date;
    primaryVendor: string;
    primaryVendorBool: boolean;
    organizationID: number;
    organizationName: string;    
    orderingPackagingLevelID?: number;
    orderingPackagingLevelDescription: string;
    shippingPackagingLevelDescription: string;
    isDirty: boolean;
    orderPackQuantity: number
    createdBy: string;
    lastUpdatedBy: string;   

}

export class OrderablePackLevel implements IOrderablePackLevel{
    //includedVendors: string[];
    rowId: number;
    vendorNumber: number;
    vendorDescription: string;
    vendorType: string;
    warehouse: number;
    warehouseDescription: string;    
    shippingPackagingLevelID: number;
    shippingPackQty: number;
    shipMax: number;
    shipPallet: string;
    effectiveDate: Date;
    terminationDate: Date;
    primaryVendor: string;
    primaryVendorBool: boolean;
    organizationID: number;
    organizationName: string;  
    orderingPackagingLevelID?: number;
    orderingPackagingLevelDescription: string;
    shippingPackagingLevelDescription: string;
    isDirty: boolean;
    orderPackQuantity: number
    createdBy: string;
    lastUpdatedBy: string;   
}


export interface IPackagingHierarchy {
    id: number;
    itemFormID: number;
    retailPackType: string;
    retailPackTypeDescription: string;
    retailPackSize: number;
    size: number;
    sizeUOM: string;
    sizeUOMDescription: string;
    labelAmount: number;
    masterCaseCodeType: string;
    masterCaseGTIN: number;
    masterCaseFormattedGtin: string;
    masterCaseGTINCheckDigit: number;
    masterCaseVendorItemGTIN: string;
    masterCaseSellingUnit: number;
    masterCaseWeight: number;
    masterCaseNetWeight: number;
    masterCaseHeight: number;
    masterCaseLength: number;
    masterCaseDepth: number;
    masterCaseCubicFootage: number;
    innerPackExist: string;
    innerCaseCodeType: string;
    innerCaseGTIN: number;
    innerCaseFormattedGtin: string;
    innerCaseGTINCheckDigit: number;
    innerCaseSellingUnits: number;
    innerCaseWeight: number;
    innerCaseNetWeight: number;
    innerCaseHeight: number;
    innerCaseLength: number;
    innerCaseDepth: number;
    innerCaseCubicFootage: number;
    masterCasesInSinglePalletLayer: number;
    layersOnPallet: number;
    palletGTIN: string;
    palletQuantity: number;
    palletCubicFootage: number;
    orderablePackLevels: IOrderablePackLevel[];
    formActionID: number;
    formStatusID: number;
    isDirty: boolean;
    submittedUserTypeID: UserType;
    gtin: number;
}



export class PackagingHierarchy implements IPackagingHierarchy {   
    id: number; 
    itemFormID: number;
    retailPackType: string;
    retailPackTypeDescription: string;
    retailPackSize: number;
    size: number;
    sizeUOM: string;
    sizeUOMDescription: string;
    labelAmount: number;
    masterCaseCodeType: string;
    masterCaseGTIN: number;
    masterCaseFormattedGtin: string;
    masterCaseGTINCheckDigit: number;
    masterCaseVendorItemGTIN: string;
    masterCaseSellingUnit: number;
    masterCaseWeight: number;
    masterCaseNetWeight: number;
    masterCaseHeight: number;
    masterCaseLength: number;
    masterCaseDepth: number;
    masterCaseCubicFootage: number;
    innerPackExist: string;
    innerCaseCodeType: string;
    innerCaseGTIN: number;
    innerCaseFormattedGtin: string;
    innerCaseGTINCheckDigit: number;
    innerCaseSellingUnits: number;
    innerCaseWeight: number;
    innerCaseNetWeight: number;
    innerCaseHeight: number;
    innerCaseLength: number;
    innerCaseDepth: number;
    innerCaseCubicFootage: number;
    masterCasesInSinglePalletLayer: number;
    layersOnPallet: number;
    palletGTIN: string;
    palletQuantity: number;
    palletCubicFootage: number;
    orderablePackLevels: IOrderablePackLevel[];
    formActionID: number;
    formStatusID: number;
    isDirty: boolean;
    submittedUserTypeID: UserType;
    gtin: number;
}

export interface IWarehouse{
    warehouseNumber: number;
    name: string;
}

export class Warehouse implements IWarehouse {
    warehouseNumber: number;
    name: string;
}


export interface IWarehouseGtin {
    itemFormID: number;
    gtin: number;
    warehouseNumber: number;
    name: string;
}

export class WarehouseGtin implements IWarehouseGtin {
    itemFormID: number;
    gtin: number;
    warehouseNumber: number;
    name: string;
}