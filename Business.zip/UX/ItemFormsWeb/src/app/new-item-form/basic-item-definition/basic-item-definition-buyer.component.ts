
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormControl } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import 'rxjs/add/operator/filter';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { catchError, tap, map } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';

import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto, IErrorDTO, ErrorDTO } from '../../shared/common.interface';
import { IBasicItemDefnitionDto, BasicItemDefnitionDto, IAdditionalGtinDto, AdditionalGtinDto, ItemTypeDto, IItemTypeDto, IReuseItemCodeDto, ReuseItemCodeDto, IItemDescriptionDto, ItemDescriptionDto, IGTINRetailPackInfoDto} from './basic-item-definition-interface';
import { BasicItemDefinitionService } from './basic-item-definition.service';
import { IItemFormDto, ItemFormDto, UserType, IGTINWithCheckdigitDto, NewItemTab } from '../new-item-form.interface';
import { DialogContentComponent } from './dialog-content.component';
import { DialogReuseItemcodeComponent } from './dialog-reuse-itemcode.component';
import { DialogModeledItemdetailComponent } from './dialog-modeled-itemdetail.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, fadeInContent, transformMenu } from '@angular/material';
import { DialogAdditionalGtinComponent } from './dialog-addtional-gtin.component';
import { GridEvent } from '../../shared/grid/grid-event';
import { NewItemFormService } from '../new-item-form.service';
import { Console } from '@angular/core/src/console';
import { IGtinDto, GtinDto } from '../common/gtin-header/gtin.interface';
import { Element } from '@angular/compiler';
import { AbstractControl } from '@angular/forms/src/model';
import { gtinValidator, GtinValidatorOptions, GTINValidatorHelper } from '../common/validators/gtin.validator'; 
import { DialogItemDescriptionsComponent } from './dialog-item-descriptions.component';


import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { IPackagingHierarchy } from '../packaging-hierarchy/packaging-hierarchy.interface';
import * as _ from 'lodash';


@Component({
    selector: 'ifw-basic-item-definition-buyer',
    templateUrl: './basic-item-definition-buyer.component.html',
    styleUrls: ['./basic-item-definition-buyer.component.scss']
})
export class BasicItemDefinitionBuyerComponent implements OnInit {

    itemFormDisplayId: number;
    private sub: any;
    userId: any;
    buyerBIDDynamicFormGroup: FormGroup;
    buyerBasicGtinFormGroup: FormGroup;
    buyerBasicItemDetailGroup: FormGroup;
    buyerBIDFormStaticGroup: FormGroup;
    //buyerBIDDynamicFormGroup: FormGroup;
    buyerBIDActionsFormGroup: FormGroup;
    itemNotPackagedForRetail: number;

    gtinHelper: GTINValidatorHelper;
    isTaxExemptionReqd: number;
    PreviousItemType: string;
    showModelSpinner: boolean = false;
    links: NewItemTab[];


    public basicItemDefinitionDto: BasicItemDefnitionDto;
    public itemFormDto: IItemFormDto;

    public submissionReasonsList: ILookupIntDto[];
    public itemTypesList: IItemTypeDto[];
    public retailPackTypesList: ILookupDto[];
    public sizeUomList: ILookupDto[];
    public IsEditMode:boolean; 
    selectedItem: ItemTypeDto;
    showBIDDetailExpectItemtype: boolean;
    showAutoGenerateType4GTIN: boolean;
    showGTINRelatedRow: boolean;
    showstaticBIDdiv: boolean;
    showIsReceipeRequired: boolean;
    showIsIngredientItemRequired: boolean;
    showReuseItemCodeAndPriceLookUp: boolean;
    showRetailPackTypePackSizeLabel: boolean;
    showReceiptDescription: boolean;
    showViewAndCopyModelItem: boolean;

    errors: string[];
    popUpMessages: IErrorDTO[];
    formErrors: any;
    skipSaveTab: boolean = false;
    private nutritionalPanelMappedGTINList: IGTINWithCheckdigitDto[] = [];
    private existingPackagingHierarchies: IPackagingHierarchy[] = [];

    //Grid
    public additionalGtinRows: IAdditionalGtinDto[];
    public data: IAdditionalGtinDto[] = [];
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = true;
    public filterBy: string = "";
    public filterValue: string = "";
    public sortable: boolean = true;
    public active: string = "";
    public direction: string = "";
    public isItemPackedForRetail: boolean = false;
    public isReadOnly: boolean = false; 

    constructor(private _formBuilder: FormBuilder,
        private router: Router,
        private route: ActivatedRoute,
        public dialog: MatDialog,
        private basicItemDefService: BasicItemDefinitionService,
        private newItemFormService: NewItemFormService) { }

    ngOnInit() {
        this.gtinHelper = new GTINValidatorHelper({});
        this.isReadOnly = this.newItemFormService.isReadOnly;
        this.route.queryParams
            .filter(params => params.id)
            .subscribe(params => {
                //  console.log(params); //  {id: "PGVSA1", role: "VPMD_VENDORPORTAL_VENDORSUPERADMIN"}             
                this.userId = params.id;

                console.log(this.userId); // PGVSA1
            });
        this.itemFormDto = new ItemFormDto();
        this.basicItemDefinitionDto = new BasicItemDefnitionDto();
        this.createForm();
        this.additionalGtinRows = [];
        this.errors = [];
        this.formErrors = {};
        this.hideAll();
        this.subscribeGTINChanges();
        this.subscribePLUChanges();
        forkJoin(this.basicItemDefService.GetItemTypes(),
            this.basicItemDefService.getSubmissionReasons(),
            this.basicItemDefService.getRetailPackTypes(),
            this.basicItemDefService.getUnitOfMeasures()).subscribe(res => {
                this.itemTypesList = res[0];
                this.submissionReasonsList = res[1].map(item => ({ code: Number(item.code), description: item.description }));
                this.retailPackTypesList = res[2];
                this.sizeUomList = res[3];
                this.getBasicItemDefinitionData();
               
            });
        let errorDTO: IErrorDTO = new ErrorDTO();
        errorDTO.tabName = 'BasicItemDef';
        errorDTO.severityLevel = 'Message';
        this.newItemFormService.GetErrorMessagesByType(errorDTO).subscribe(res => {
            console.log("GetErrorMessagesByType" + res)
            this.popUpMessages = res;
            console.log(this.popUpMessages);
            //this.popUpMessages = res
        });
        this.basicItemDefService.GetNutritionalPanelGTIN(this.newItemFormService.itemFormID).subscribe(res => {
            this.nutritionalPanelMappedGTINList = res;
        });

        this.basicItemDefService.GetExistingPackagingHierarchies(this.newItemFormService.itemFormID).subscribe(res => {
            this.existingPackagingHierarchies = res;
        });
    }    

    hideAll() {
        this.showBIDDetailExpectItemtype = false;
        this.showstaticBIDdiv = false;
        this.showAutoGenerateType4GTIN = false;
        this.showGTINRelatedRow = false;
        this.showIsReceipeRequired = false;
        this.showIsIngredientItemRequired = false;
    }

   private CheckType2InCurrentForm():boolean {       
    if(this.additionalGtinRows.some(r => r.formattedGtin.toString().slice(0,3) == "002"))
        return true;
    else if(this.buyerBasicGtinFormGroup.get('formattedGtin').value.slice(0,3) == "002")
        return true;
    return false;
    }

    private getBasicItemDefinitionData() {

        this.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;     
        this.basicItemDefService.getBasicItemDefinitionData(this.newItemFormService.itemFormID).subscribe(res => {
            if (res != undefined) {
                    //Existing  BID data
                    this.IsEditMode = true;
                    this.showBuyerItemDetails();
                    this.showGTINRelatedRow = true;
                this.basicItemDefinitionDto = res;
            
                this.additionalGtinRows = this.basicItemDefinitionDto.addtionalGtinList || [];
                this.populateExisingBIDDetails();
                //var gtinHeaderDto = this.populateGtinHeaderDto();
                //this.newItemFormService.setItemFormDisplayID(this.itemFormDto.itemFormDisplayID, null);
                //this.newItemFormService.setGtinHeaderDetails(gtinHeaderDto);
                this.UpdateAdditionalGtinRowId();
                this.getInitialAdditionalGtinData();
                this.showBuyerItemDetails();
                this.itemFormDto.lastUpdatedBy = this.userId;
                this.basicItemDefinitionDto.lastUpdatedBy = this.userId;
                this.newItemFormService.formTypeID = res.formTypeID;
                this.newItemFormService.formCurrentStatusID = res.formStatusID;
                if (this.buyerBIDFormStaticGroup.get("modelProductItemCode").value)
                    this.showViewAndCopyModelItem = true;
                else
                    this.showViewAndCopyModelItem = false;

                this.showHideControlsOnInit();

                this.newItemFormService.GetItemFormErrors(this.newItemFormService.itemFormID).subscribe(res => {
                    const validations: any = this.newItemFormService.getItemValidation("Basic Item Definition");
                    if (validations) {
                        this.handleBasicItemDefValidations(validations);
                    }
                });
                //setTimeout(()=> {
                //this.handleItemValidations();
                //}, 100);
                
            }
            else {
                //No BID data
                this.IsEditMode = false;
                this.hideBuyerItemDetails();
                this.basicItemDefinitionDto.itemFormID = this.newItemFormService.itemFormID;
                this.basicItemDefinitionDto.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;

                this.basicItemDefinitionDto.formTypeID = this.newItemFormService.formTypeID;
                this.basicItemDefinitionDto.formStatusID = this.newItemFormService.formCurrentStatusID;               
             
                this.basicItemDefinitionDto.lastUpdatedBy = this.userId;                
            }

            this.basicItemDefinitionDto.submittedUserTypeID = UserType.Buyer; 
        });  
    }    

    showMessage(code:string):string{
        let messageDesc:string = '';
        console.log(this.popUpMessages);
        if(this.popUpMessages.some(error => error.errorCode == code))
        messageDesc = this.popUpMessages.find(error => error.errorCode == code).errorDescription
        return messageDesc;
    }

    createForm() {
        this.buyerBasicGtinFormGroup = this._formBuilder.group({
            formattedGtin: ['', [gtinValidator({
                validateCheckDigit: false,
                range: false,
                type2: false,
                dummy: false,
                vendorCoupon: false
            })]],
            gtinCheckDigit: ['']
        });

        this.buyerBIDDynamicFormGroup = this._formBuilder.group({
            itemTypes: [''],
            IsRecipe: '0',
            IsIngredientItemRequired: '2',
            AutoGenerateType4GTIN: '0',
            compressedUPC: ['',[Validators.minLength(6)]],
            priceLookupCode: ['',[Validators.minLength(5)]],
            reuseItemCode: ''
        });

        this.buyerBIDFormStaticGroup = this._formBuilder.group({
            submissionReasons: 1,
            itemCaseTypeID: "1",
            modelProductItemCode: '',
            modelPackagingItemCode: ''
        });

        //this.buyerBIDFormStaticGroup.patchValue({ "itemCaseTypeID": "1" });
        //this.buyerBIDFormStaticGroup.patchValue({ "submissionReasons": 1 }); 

        this.buyerBasicItemDetailGroup = this._formBuilder.group({
            itemDescription: '',
            receiptDescription: '',
            scaleDescription1: {value: '', disabled: true},
            scaleDescription2: {value: '', disabled: true},
            adDescription: '',
            productCatalogShortDescription1: '',
            productCatalogShortDescription2: '',
            backroomScaleIndicator: {value: '', disabled: true},
            vendorItemCode: '',
            vendorItemDescription: '',
            brand: '',
            manufacturer: '',
            isItemPackagedForRetail: [''],
            size: '',
            sizeUOM: [''],
            retailPackType: [''],
            retailPackSize: '',
            labelAmount: '',
            nonDiscountable: '',
            pIItemFlag: '',
            minorityManufacturer: ['N'],
            packageDescription: '',
            containerType: '',
            isAdditionalGtinReqd: "N"
        });

        this.buyerBIDActionsFormGroup = this._formBuilder.group({ actionId: 1 });


    }


    onIsIngredientItemRequiredChange(IsIngredientItemRequired) {
        // BID22 "Please first create ingredient items."
        this.setGTINRelatedFlag();
        if (IsIngredientItemRequired === 'Y') {
            let data = {
                description: this.showMessage("BID22"),
                options: [
                    "Ok"
                ]
            }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '400px',
                data: data
            });
        }
    }

    onItemTypeChange(selectedItemTypeCode) {        
        this.PreviousItemType = this.basicItemDefinitionDto.itemTypeCode;
        console.log(selectedItemTypeCode);
        console.log(this.basicItemDefinitionDto.itemTypeDescription);
        this.selectedItem = this.itemTypesList.find(item => item.code === selectedItemTypeCode);

        // Check the previous item type and the current item type
        console.log(this.itemTypesList.find(item => item.code === this.basicItemDefinitionDto.itemTypeCode));
        let PreviousItemTypeDto:ItemTypeDto = this.itemTypesList.find(item => item.code === this.basicItemDefinitionDto.itemTypeCode);
        
        let CurrentItemTypeDto:ItemTypeDto = this.selectedItem;
        this.basicItemDefinitionDto.itemTypeCode = this.selectedItem.code;
        // if previous is Retail  and current is NON retails show pop up ask user do they want loss the retail pack info
        // if the previous is null(Vendor submitted form) check the current IsItempack for retail is true and if the current  item type is non retail shoe pop up.
        //if(this.buyerBIDFormStaticGroup.get("modelProductItemCode").value){
            if(this.basicItemDefinitionDto.modelProductItemTypeCode != null && this.basicItemDefinitionDto.modelProductItemTypeCode != selectedItemTypeCode){
            let data = { description: "Cannot change Item Type. Please delete the existing Model Item",options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '600px',
                data: data
            });
            dialogRef.afterClosed().subscribe(result => {               
                if (result.action === "Ok") {                 
                    this.buyerBIDDynamicFormGroup.patchValue({ "itemTypes": PreviousItemTypeDto.code });
                    this.basicItemDefinitionDto.itemTypeCode = PreviousItemTypeDto.code;
                    }
            });
        }
        else if(this.buyerBIDDynamicFormGroup.get('priceLookupCode').value != null && (this.CheckType2InCurrentForm() || this.buyerBIDDynamicFormGroup.get('priceLookupCode').value.length > 0) && CurrentItemTypeDto.subtypeIndicator == "NONRETAIL" ){
            let desc = "Cannot move to Non Retail Type. Please delete the existing Type 2 GTIN";

            if(this.buyerBIDDynamicFormGroup.get('priceLookupCode').value.length > 0)
            desc = "Cannot move to Non Retail Type.please delete the existing GTIN Generated from Pricelookup";
            
            let data = { description: desc,options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '600px',
                data: data
            });
            dialogRef.afterClosed().subscribe(result => {               
                if (result.action === "Ok") {                 
                    this.buyerBIDDynamicFormGroup.patchValue({ "itemTypes": PreviousItemTypeDto.code });
                    this.basicItemDefinitionDto.itemTypeCode = PreviousItemTypeDto.code;
                    }
            });
        }
        else if(PreviousItemTypeDto == undefined || this.showBIDDetailExpectItemtype == false){
            this.ChangeItemType();            
        }        
        else if((PreviousItemTypeDto.subtypeIndicator.trim() == "RETAIL" && CurrentItemTypeDto.subtypeIndicator == "NONRETAIL" && this.showBIDDetailExpectItemtype)
         || (PreviousItemTypeDto == undefined && CurrentItemTypeDto.subtypeIndicator == "NONRETAIL" && this.isItemPackedForRetail && this.showBIDDetailExpectItemtype) ){
            
            // find the formatted GTIN is Type 2 if dont allow the movement from retail else inform the user and proceed
            let IsType2GTIN = this.CheckType2InCurrentForm();
            let desc = "Moving from Retail to NON retail Item types will remove retail type information ?"
            let buttonOptions = ["Ok","Cancel"];

            if(IsType2GTIN) {
                desc = "Cannot Move from Retail to NON retail Item types when Type2 GTIN Exist";
                buttonOptions = ["Ok"];
            }

            let data = {
                description: desc,
                options: buttonOptions
            }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '600px',
                data: data
            });

            dialogRef.afterClosed().subscribe(result => {
                if(IsType2GTIN) {
                    this.buyerBIDDynamicFormGroup.patchValue({ "itemTypes": PreviousItemTypeDto.code });
                    this.basicItemDefinitionDto.itemTypeCode = PreviousItemTypeDto.code;
                }
                else if (result.action === "Ok")
                   this.ChangeItemType();
                   else { //itemTypes
                    this.buyerBIDDynamicFormGroup.patchValue({ "itemTypes": PreviousItemTypeDto.code });
                    this.basicItemDefinitionDto.itemTypeCode = PreviousItemTypeDto.code;
                   }

            });
        }
        else {
            this.ChangeItemType();
        }

        

    }

    /* RevertItemTypeForInvalidModelItemCode(PreviousItemType:string){
        this.buyerBIDDynamicFormGroup.patchValue({ "itemTypes": PreviousItemType });
        this.basicItemDefinitionDto.itemTypeCode = PreviousItemType;


    } */

    ChangeItemType(){
        this.basicItemDefinitionDto = new BasicItemDefnitionDto();
        this.basicItemDefinitionDto.itemTypeCode = this.selectedItem.code;
        this.basicItemDefinitionDto.itemTypeDescription = this.selectedItem.description;

        //this.DisplayBasicItemDefinitionFromDTO();
        this.buyerBIDDynamicFormGroup.patchValue({ "AutoGenerateType4GTIN": "N" })
        this.showAutoGenerateType4GTIN = false;
        this.buyerBIDDynamicFormGroup.patchValue({ "IsIngredientItemRequired": "2" })
        this.showIsIngredientItemRequired = false;
        this.buyerBIDDynamicFormGroup.patchValue({ "IsRecipe": "N" })
        this.showIsReceipeRequired = false;
        this.showGTINRelatedRow = false;

        this.ShowHideControlBasedOnIsRetail(this.selectedItem);

        if (this.selectedItem.code === "FG" || this.selectedItem.code === "WP")
            this.showIsReceipeRequired = true;
        else
            this.showIsReceipeRequired = false;

        if (this.selectedItem.code === "RI") {
            //this.showAutoGenerateType4GTIN = false;
            this.showIsReceipeRequired = false;
            this.showGTINRelatedRow = true;
            this.isItemPackedForRetail = true;
            //this.hideBuyerItemDetails();
        }
        else {
            this.isItemPackedForRetail = false;
            this.setGTINRelatedFlag();
        }

        // SET Standard for NON Retail Item and disable it
        if(this.selectedItem.code === "FG" || this.selectedItem.code === "RI"){
            this.buyerBIDFormStaticGroup.patchValue({ "itemCaseTypeID": "1" });
            this.buyerBIDFormStaticGroup.get("itemCaseTypeID").enable() ;
        }
        else
        this.buyerBIDFormStaticGroup.get("itemCaseTypeID").disable() ;

    }

    ShowHideControlBasedOnIsRetail(type: ItemTypeDto) {
        if (type.subtypeIndicator.trim() === "NONRETAIL") {
            this.showReuseItemCodeAndPriceLookUp = false;
            this.showAutoGenerateType4GTIN = true;
            this.buyerBasicItemDetailGroup.patchValue({
                "isItemPackagedForRetail": "N",
                "retailPackSize": null,
                "retailPackType": '',
                "labelAmount": null,
            });
            for(var additionalRow of this.additionalGtinRows){
                additionalRow.retailPackSize = null;
                additionalRow.retailPackType = '';
                additionalRow.retailPackTypeDescription = '';
                additionalRow.labelAmount = null;
            }
            this.buyerBasicItemDetailGroup.get("isItemPackagedForRetail").disable();
            this.showRetailPackTypePackSizeLabel = false;
            this.showReceiptDescription = false;
        }
        else {
            this.showReuseItemCodeAndPriceLookUp = true;
            this.showAutoGenerateType4GTIN = false;
            this.buyerBasicItemDetailGroup.patchValue({
                 "isItemPackagedForRetail": "Y",
                 //"retailPackSize": 1,
                 "retailPackType": 'R', 
             });
            this.buyerBasicItemDetailGroup.get("isItemPackagedForRetail").disable();
            this.showRetailPackTypePackSizeLabel = true;
            this.showReceiptDescription = true;
        }

    }

    onAutoGenerateType4GTINChange(selectedAutoGenerateGTIN) {
        console.log(selectedAutoGenerateGTIN);
        this.setGTINRelatedFlag();
        if(selectedAutoGenerateGTIN == "Y"){
            this.showBuyerItemDetails();
            this.basicItemDefinitionDto.additionalGTINPresent = "N";
            this.buyerBasicItemDetailGroup.patchValue({isAdditionalGtinReqd: this.basicItemDefinitionDto.additionalGTINPresent });
            this.buyerBasicItemDetailGroup.get("isAdditionalGtinReqd").disabled;
    }
        else{
            this.hideBuyerItemDetails();
            this.buyerBasicGtinFormGroup.patchValue({ 'formattedGtin': ''});
            this.buyerBasicGtinFormGroup.patchValue({ 'gtinCheckDigit': ''});
            this.basicItemDefinitionDto.formattedGtin ='';
            this.basicItemDefinitionDto.additionalGTINPresent = "";
            this.buyerBasicItemDetailGroup.patchValue({isAdditionalGtinReqd: this.basicItemDefinitionDto.additionalGTINPresent });
            this.buyerBasicItemDetailGroup.get("isAdditionalGtinReqd").enabled;
        }
    }

    onIsReceipeRequiredChange(selectedIsReceipeRequiredChange) {
        if (selectedIsReceipeRequiredChange === '0') {
            this.buyerBIDDynamicFormGroup.patchValue({ "IsIngredientItemRequired": "N" })
            this.showIsIngredientItemRequired = false;
        }
        else
            this.showIsIngredientItemRequired = true;

        this.setGTINRelatedFlag();
    }

    setGTINRelatedFlag() {
        let selectedItemType = this.buyerBIDDynamicFormGroup.get('itemTypes').value;
        let AutoGenerateType4GTIN = this.buyerBIDDynamicFormGroup.get('AutoGenerateType4GTIN').value;
        let IsRecipe = this.buyerBIDDynamicFormGroup.get('IsRecipe').value;
        let IsIngredientItemRequired = this.buyerBIDDynamicFormGroup.get('IsIngredientItemRequired').value;

        if (this.showAutoGenerateType4GTIN && this.showIsReceipeRequired) {
            if (AutoGenerateType4GTIN === "N" && IsRecipe === "N") {
                this.showGTINRelatedRow = true;
                //this.hideBuyerItemDetails();
            }
            else if (AutoGenerateType4GTIN === "N" && IsRecipe === "Y" && IsIngredientItemRequired === "N") {
                this.showGTINRelatedRow = true;
                //this.hideBuyerItemDetails();
            }
            else if (AutoGenerateType4GTIN === "Y" && IsRecipe === "Y" && IsIngredientItemRequired === "N") {
                this.showGTINRelatedRow = false;
                //this.showBuyerItemDetails();
            }
            else if (AutoGenerateType4GTIN === "Y" && IsRecipe === "N") {
                this.showGTINRelatedRow = false;
                //this.showBuyerItemDetails();
            }
            else if (IsRecipe === "Y" && (IsIngredientItemRequired === "Y" || IsIngredientItemRequired === "2")) {
                this.showGTINRelatedRow = false;
                //this.hideBuyerItemDetails();
            }
            else if (IsRecipe === "Y" && IsIngredientItemRequired === "N") { }
                //this.showBuyerItemDetails();
        }
        else if (this.showAutoGenerateType4GTIN && AutoGenerateType4GTIN === 'Y') {
            this.showGTINRelatedRow = false;
            //this.showBuyerItemDetails()
        }
        else if (this.showIsIngredientItemRequired && (IsIngredientItemRequired === "Y" || IsIngredientItemRequired === "2")) {
            this.showGTINRelatedRow = false;
            //this.hideBuyerItemDetails();
        }
        else if (this.showIsReceipeRequired && IsRecipe === "N") {
            this.showGTINRelatedRow = true;
            //this.hideBuyerItemDetails();
        }
        else if (this.showIsReceipeRequired && !this.showIsIngredientItemRequired) {
            this.showGTINRelatedRow = false;
            //this.showBuyerItemDetails();
        }
        else {
            this.showGTINRelatedRow = true;
            //this.hideBuyerItemDetails();
        }

    }
    showBuyerItemDetails() {
        this.showBIDDetailExpectItemtype = true;
        if (this.buyerBIDFormStaticGroup.get("itemCaseTypeID").value == "1")
            this.EnableShipperItemComposition(false);
        else
            this.EnableShipperItemComposition(true);
    }

    hideBuyerItemDetails() {
        if(this.IsEditMode == false)
        this.showBIDDetailExpectItemtype = false;
        else
        this.showBIDDetailExpectItemtype = true;
        

    }

    padLeft(text: string, padChar: string, size: number): string {
        return (String(padChar).repeat(size) + text).substr((size * -1), size);
    }

    onFindClick() {

        let gtin = this.buyerBasicGtinFormGroup.get('formattedGtin').value;
        let reuseItemCode  =  this.buyerBIDDynamicFormGroup.get('reuseItemCode').value;
        let retailPackType:string = this.buyerBasicItemDetailGroup.get("retailPackType").value
        
        //let IsAddReuseItemCodeAsAddtionalGTIN =  (gtin.length > 0 && gtin.slice(0, 3) != "002") ? true : false
        let IsAddReuseItemCodeAsAddtionalGTIN =  (gtin.length > 0) ? true : false
     
        let IsAddtionalGtinCanBeAdded:boolean = false;
        
        let itemTypeCode = this.buyerBIDDynamicFormGroup.get("itemTypes").value;
        // BID15 -"Cannot Add the reuse item code as Addtional GTIN.Please select the Retail Pack Type"
        if(IsAddReuseItemCodeAsAddtionalGTIN && 
            (itemTypeCode == "RI" || itemTypeCode == "FG") && gtin.slice(0,3) != "002"
            && retailPackType.length == 0){
                this.showPopupValidateForReuseItemCode(this.showMessage("BID15"),gtin.slice(4, 9));
            }
            else {

        let dialogRef = this.dialog.open(DialogReuseItemcodeComponent, {
            width: '800px',
            data: {
                formId: this.newItemFormService.itemFormID,                       
                SelectedReuseItemCode: 0,
                PreviousReuseItemCode : reuseItemCode  ,
                popUpMessages : this.popUpMessages,
                AddReuseItemCodeAsAddtionalGTIN:  (gtin.length > 0 && gtin.slice(0,3) != "002") ? true : false,
                IsEnteredPrimaryGTINType2 : (gtin.slice(0, 3) == "002" || gtin.length == 0) ? true : false
            }
        });

        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            console.log(result);
            let gtin = this.buyerBasicGtinFormGroup.get('formattedGtin').value;
            result.itemcode = result.SelectedReuseItemCode
            let generateType2Gtin: string = "002" + this.padLeft(result.itemcode, '0', 5) + "00000"
            if (result.AddReuseItemCodeAsAddtionalGTIN ){                
                 let additionalGtinDto:AdditionalGtinDto =  this.ValidateAndGetAddtionalGTIN(result.SelectedReuseItemCode,generateType2Gtin);
                 if(additionalGtinDto != null) {
                    if(this.CheckReuseItemCodeAlreadyExist()) 
                    this.CheckReuseItemCodeType2GTINAlreadyExistAndAdd(result.SelectedReuseItemCode,additionalGtinDto);              
                    else{
                        let reuseItemCodeDto:ReuseItemCodeDto = new ReuseItemCodeDto();
                        reuseItemCodeDto.itemCode =result.SelectedReuseItemCode; 
                        this.basicItemDefService.saveReuseItemCode(reuseItemCodeDto).subscribe(res =>{
                            if (res) {
                                this.AddSelectedReuseItemCodeToAddtionalGTIN(additionalGtinDto);
                                console.log('Save Success');
                                this.buyerBIDDynamicFormGroup.patchValue({ 'reuseItemCode': reuseItemCodeDto.itemCode });
                                this.basicItemDefinitionDto.backroomScaleIndicator = "Y";
                                this.buyerBasicItemDetailGroup.patchValue({backroomScaleIndicator: this.basicItemDefinitionDto.backroomScaleIndicator});
                                
                            }
                            else {
                                console.log('Save failure');
                                console.log(res);
                            }
        
                        })
                    }
                     
                 }
                 else
                 console.log("reuse item code did not pass regular validation");                
            }
            else if(this.additionalGtinRows.some(addtionalgtinrow => addtionalgtinrow.formattedGtin.startsWith("002")))
            this.showPopupValidateForReuseItemCode("Please delete the existing Type 2 GTIN in addtional GTIN to add this reuse item code as primary GTIN",gtin.slice(4,9)); 
            else {
                this.buyerBIDDynamicFormGroup.patchValue({ 'reuseItemCode': result.itemcode });
                this.buyerBasicGtinFormGroup.patchValue({ 'formattedGtin': this.gtinHelper.padGtin(generateType2Gtin, 13), 'gtinCheckDigit': this.gtinHelper.getCheckdigit(generateType2Gtin) });
                this.basicItemDefinitionDto.backroomScaleIndicator = "Y";
                this.buyerBasicItemDetailGroup.patchValue({backroomScaleIndicator: this.basicItemDefinitionDto.backroomScaleIndicator});
                this.showBuyerItemDetails();
            }

        });
    }

    }

  

    CheckReuseItemCodeType2GTINAlreadyExistAndAdd(reuseItemCode :Number,additionalGtinDto:AdditionalGtinDto){
        let ReuseItemCodeExistPrimary:boolean = false;
        let ReuseItemCodeExistAddtional:boolean = false;
        let gtin = this.buyerBasicGtinFormGroup.get('formattedGtin').value;
        gtin = this.gtinHelper.padGtin(gtin, 13).toString();
        this.basicItemDefinitionDto.formattedGtin = gtin;
            let gtintype: string = gtin.slice(0, 3);
            if (gtintype === "002")
            ReuseItemCodeExistPrimary = true;           
            ReuseItemCodeExistAddtional = this.additionalGtinRows.some(addtionalgtinrow => addtionalgtinrow.formattedGtin.startsWith("002"));
            if(ReuseItemCodeExistPrimary || ReuseItemCodeExistAddtional){
                let popupdescription:string; 
                if(ReuseItemCodeExistPrimary) 
                popupdescription = "Reuse ItemCode Type2GTIN Already Exist As Primary GTIN .Do you want to replace it ?";
                else
                popupdescription = "Reuse ItemCode Type2GTIN Already Exist As Addtional GTIN .Do you want to replace it ?";
                let data = {
                    title: "",
                    description: popupdescription,
                    actions: [
                        "No",
                        "Yes"
                    ]
                }
                let dialogRef = this.dialog.open(DialogContentComponent, {
                    disableClose: true,
                    width: '800px',
                    data: data
                });


                dialogRef.afterClosed().subscribe(result => {
                    console.log('The dialog was closed');
                    if (result.action === "Yes") {
                         let reuseItemCodeDto:ReuseItemCodeDto = new ReuseItemCodeDto();
                         reuseItemCodeDto.itemCode = +reuseItemCode;
                         let generateType2Gtin: string = "002" + this.padLeft(reuseItemCodeDto.itemCode.toString(), '0', 5) + "00000"
                        this.basicItemDefService.saveReuseItemCode(reuseItemCodeDto).subscribe(res =>{
                            if (res) {
                                if(ReuseItemCodeExistAddtional) {
                                    this.additionalGtinRows.splice(this.additionalGtinRows.findIndex(r => r.formattedGtin.startsWith("002")));
                                this.AddSelectedReuseItemCodeToAddtionalGTIN(additionalGtinDto);
                                }
                                else if(ReuseItemCodeExistPrimary)
                                this.buyerBasicGtinFormGroup.patchValue({ 'formattedGtin': this.gtinHelper.padGtin(generateType2Gtin, 13), 'gtinCheckDigit': this.gtinHelper.getCheckdigit(generateType2Gtin) });
                                
                                this.buyerBIDDynamicFormGroup.patchValue({ 'reuseItemCode': reuseItemCodeDto.itemCode });
                                console.log('Save Success');
                            }
                            else {
                                console.log('Save failure');
                                console.log(res);
                            }
        
                        });
                        
                    }
                    else
                    this.buyerBIDDynamicFormGroup.patchValue({ 'reuseItemCode': "" });            
                });
            }
            


    }

    /*  isParentEnteredGTINExistInPDMS():boolean
     {
         let gtin :string = this.basicItemDefinitionDto.formattedGtin;
         let isGTINExist:boolean;
         if (gtin.length > 0)  
              this.basicItemDefService.IsGTINExists(+gtin).subscribe(res => {isGTINExist = res;});  
              
         return isGTINExist;
     } */

     CheckReuseItemCodeAlreadyExist():boolean{
        let gtin = this.buyerBasicGtinFormGroup.get('formattedGtin').value;
        gtin = this.gtinHelper.padGtin(gtin, 13).toString();     
            let gtintype: string = gtin.slice(0, 3);
            if (gtintype === "002" || this.additionalGtinRows.some(addtionalgtinrow => addtionalgtinrow.formattedGtin.startsWith("002")))
           return true;
           else
           return false;
    }

    ValidateAndSaveReuseItemCode(reuseItemCodeDto: ReuseItemCodeDto,optionToAddAddtionalGtin:boolean): void { 
        let gtin = this.buyerBasicGtinFormGroup.get('formattedGtin').value;
        let IsAddReuseItemCodeAsAddtionalGTIN =  (gtin.length > 0 && gtin.slice(0,3) != "002") ? true : false
        reuseItemCodeDto.itemFormID = this.newItemFormService.itemFormID;
        let generateType2Gtin: string = "002" + this.padLeft(reuseItemCodeDto.itemCode.toString(), '0', 5) + "00000"
        this.basicItemDefService.isSelectedReuseItemCodeAlreadyUsed(reuseItemCodeDto).subscribe(res => {
            if (!res.isAvailable) // check errorDescription is invaild reuse item code if so set GTIN and reuse item code to previous value.
            this.showPopupValidateForReuseItemCode(res.validationErrors.errors[0].errorDescription,gtin.slice(4,9));                    
            else if(IsAddReuseItemCodeAsAddtionalGTIN && optionToAddAddtionalGtin && reuseItemCodeDto.itemCode > 0 ) {
                // this validation has to be done before while checking on addtional gtin per form rule
               let addtionalgtin:AdditionalGtinDto = this.ValidateAndGetAddtionalGTIN(reuseItemCodeDto.itemCode,generateType2Gtin);
               // BID 25 "Entered Reuse ItemCode cannot be added as Addtional GTIN"
               if(addtionalgtin == null)
               this.showPopupValidateForReuseItemCode(this.showMessage("BID25"),gtin.slice(4,9)); 
               else if(this.CheckReuseItemCodeAlreadyExist()) 
               this.CheckReuseItemCodeType2GTINAlreadyExistAndAdd(reuseItemCodeDto.itemCode,addtionalgtin);              
               else
                this.showPopupToAddReuseItemCodeAsAddtionalGTIN(addtionalgtin,reuseItemCodeDto);                          
            }   
            else if(reuseItemCodeDto.itemCode > 0 && this.additionalGtinRows.some(addtionalgtinrow => addtionalgtinrow.formattedGtin.startsWith("002")))
            this.showPopupValidateForReuseItemCode("Please delete the existing Type 2 GTIN in addtional GTIN to add this reuse item code as primary GTIN",gtin.slice(4,9)); 
            else if(reuseItemCodeDto.itemCode > 0) {
                this.LockReuseItemCodePopUp(reuseItemCodeDto,generateType2Gtin,gtin.slice(4,9));
            }
        })
    }

    LockReuseItemCodePopUp(reuseItemCodeDto:ReuseItemCodeDto,generateType2Gtin:string,previousReuseItemCode:number) {
        let desc: string = "Do you want to add the Reuse Item Code  " + reuseItemCodeDto.itemCode + "  as Primary GTIN";
        let data = {           
            description: desc,
            options: [
                "Add",
                "Cancel"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '400px',
            data: data
        });
       
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            if (result.action === "Add"){
                this.basicItemDefService.saveReuseItemCode(reuseItemCodeDto).subscribe(res => {
                    if (res) {                      
                      
                        this.buyerBasicGtinFormGroup.patchValue({ 'formattedGtin': this.gtinHelper.padGtin(generateType2Gtin, 13), 'gtinCheckDigit': this.gtinHelper.getCheckdigit(generateType2Gtin) });                               
                        this.buyerBIDDynamicFormGroup.patchValue({ reuseItemCode: reuseItemCodeDto.itemCode });
                        this.showBuyerItemDetails();
                        console.log('Save Success');
                        this.basicItemDefinitionDto.backroomScaleIndicator = "Y"
                        this.buyerBasicItemDetailGroup.patchValue({backroomScaleIndicator: this.basicItemDefinitionDto.backroomScaleIndicator})
                    }
                    else {
                        console.log('Save failure');
                        console.log(res);
                    }
                }) 
                //dialogRef.close(this.data);
            }                       
            else {
                // BID 24 "Please select some other reuse item code to add as addtional gtin"
                if(this.CheckReuseItemCodeAlreadyExist())
                this.buyerBIDDynamicFormGroup.patchValue({ reuseItemCode: previousReuseItemCode });
                else
                this.buyerBIDDynamicFormGroup.patchValue({ reuseItemCode: "" });
                console.log(this.showMessage("BID24"));
            }
    })
}    

    ValidatePrimaryGTIN(){
        // Check the item is Type 2
        // 1. Check is there an already Type 2 GTIN entred in the  addtional GTIN collection ..if zero..true else reject the entry say rule one addtional GTIN per form
       let  gtin = this.basicItemDefinitionDto.formattedGtin.replace(/-/g, "");
        let IsAddtionalGTINAlreadyExist:boolean = false;
        if (this.additionalGtinRows != undefined) 
            IsAddtionalGTINAlreadyExist = this.additionalGtinRows.some(addtionalgtin => addtionalgtin.formattedGtin.startsWith("002"));

            if(!IsAddtionalGTINAlreadyExist){
                 // 2. Check the Type 2 GTIN entered is avaiable in database if yes..
                this.basicItemDefService.isGTINExists(+gtin).subscribe(response =>{
                    console.log(response);
                    // 3.Run the scan date rule if Scan date > 2 --> pop up for New or mantain item
                    this.basicItemDefinitionDto.reuseItemCode = +this.basicItemDefinitionDto.formattedGtin.slice(4,9);
                    if(response.isGTINExist){
                        this.basicItemDefinitionDto.lastScanDate = response.lastScanDate.toString();                        
                     this.lastScanDateRules(this.basicItemDefinitionDto,true);
                                        
                    }
                    else{                        
                        let reuseItemCodeDto: ReuseItemCodeDto = new ReuseItemCodeDto();
                        reuseItemCodeDto.itemCode = this.basicItemDefinitionDto.reuseItemCode;        
                        this.ValidateAndSaveReuseItemCode(reuseItemCodeDto, false);
                    }    
                });
            }
           
        
       
        
        // 4.for New item --> Run the Reuse item code and give a spefic messasge as invalid or consumed by user if so reject GTIN..
        //   else accept the entered GTIN and set the reuse item code in the re use item code text box
        // 5.for maintain item which user accept for scan date > 2 or all scan date < 2...No need to check the reuse avaiablilty logic
        // 6. once GTIN is accepeted.. then display the Exiting Details of the Type 2 GTIN (From PMDS) to the user interface

    }

    //public isPrePack(val: string): boolean {
    //    if (val.trim() === "P")
    //        return true;
    //    else
    //        return false;
    //}


    public onRetailPackTypeChange(val: string) {

        this.buyerBasicItemDetailGroup.patchValue({
            "labelAmount": null
        });
    }

    AddSelectedReuseItemCodeToAddtionalGTIN(additionalGtinDto: AdditionalGtinDto) {        
      
        this.basicItemDefinitionDto.additionalGTINPresent = "Y";
        this.buyerBasicItemDetailGroup.patchValue({ isAdditionalGtinReqd: "Y" });
        this.additionalGtinRows.push(additionalGtinDto);
        this.UpdateAdditionalGtinRowId();
        this.getInitialAdditionalGtinData();        
    }

    ValidateAndGetAddtionalGTIN(reuseItemCode: number, generatedType2Gtin: string) : AdditionalGtinDto {
        // copy all the content of 7 columsn from primary gtin to addtional GTIN+ formid,gtin,check digit
        this.PopulateBasicItemDefinitionDTO();
        this.getBasicItemDefDropdownSelectionData();
        let additionalGtinDto: AdditionalGtinDto = new AdditionalGtinDto();
        additionalGtinDto.itemFormID = this.newItemFormService.itemFormID;
        additionalGtinDto.formattedGtin = generatedType2Gtin;
        additionalGtinDto.gtinCheckDigit = this.gtinHelper.getCheckdigit(generatedType2Gtin);
        additionalGtinDto.retailPackType = this.basicItemDefinitionDto.retailPackType;
        additionalGtinDto.retailPackTypeDescription = this.basicItemDefinitionDto.retailPackTypeDescription;
        additionalGtinDto.retailPackSize = this.basicItemDefinitionDto.retailPackSize;
        additionalGtinDto.labelAmount = this.basicItemDefinitionDto.labelAmount;
        //additionalGtinDto.overrideReceiptDescription = this.basicItemDefinitionDto.receiptDescription;
        additionalGtinDto.size = this.basicItemDefinitionDto.size;
        additionalGtinDto.sizeUOM = this.basicItemDefinitionDto.sizeUOM;
        additionalGtinDto.sizeUOMDescription = this.basicItemDefinitionDto.sizeUOMDescription;
        additionalGtinDto.nonDiscountable = this.basicItemDefinitionDto.nonDiscountable;

        if(this.basicItemDefinitionDto.itemTypeCode == "RI" || this.basicItemDefinitionDto.itemTypeCode == "FG"){
            if(this.basicItemDefinitionDto.retailPackType.length == 0 )
            return null;
        }
        

        if(additionalGtinDto.retailPackType == "R")
        {
        // regular GTIN check 1.get all the regular gtin pack 2. for each pack check new added gtin all column are matching expect gtin 3.if so accept else reject
                let regularAddtionalGtins :IAdditionalGtinDto[]  = this.additionalGtinRows.filter(gtinrow => gtinrow.retailPackType == "R")
        var IsRegularGtinValid = regularAddtionalGtins.every(RegGtinRow => RegGtinRow.formattedGtin != additionalGtinDto.formattedGtin &&
            RegGtinRow.retailPackType == additionalGtinDto.retailPackType &&
            RegGtinRow.retailPackSize == additionalGtinDto.retailPackSize &&
            RegGtinRow.labelAmount == additionalGtinDto.labelAmount &&
            RegGtinRow.size == additionalGtinDto.size &&
            RegGtinRow.sizeUOM == additionalGtinDto.sizeUOM );
            //&& RegGtinRow.nonDiscountable == additionalGtinDto.nonDiscountable);
         
        if(IsRegularGtinValid)    
        return additionalGtinDto;
        else
        return null;
        }
        else
        return additionalGtinDto; 

    }

    public handleItemValidations() {
        const validations: any = this.newItemFormService.getItemValidation("Basic Item Definition");
        if (validations) {
            this.handleBasicItemDefValidations(validations);
        }
    }

    handleBasicItemDefValidations(bidValidation) {
        let bidErrors = bidValidation.errors;
        let bidWarnings = bidValidation.warnings;
        this.handleBIDValidationErrors(bidErrors);
        this.handleBIDValidationWarnings(bidWarnings);
    }

    handleBIDValidationErrors(bidErrors: any[]) {

        for (var key in bidErrors) {
            let errorObj = bidErrors[key];
            //for (var errorObj of gpaErrors) {
            let fieldName = errorObj.controlName;
            if (fieldName) {

                if (this.buyerBasicItemDetailGroup.controls[fieldName]) {

                    this.buyerBasicItemDetailGroup.controls[fieldName].setErrors({ invalid: true });
                    this.buyerBasicItemDetailGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;

                }
                else if (this.buyerBasicGtinFormGroup.controls[fieldName]) {
                    this.buyerBasicGtinFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.buyerBasicGtinFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;
                }
                else if (this.buyerBIDDynamicFormGroup.controls[fieldName]) {
                    this.buyerBIDDynamicFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.buyerBIDDynamicFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;
                }
                else if (this.buyerBIDFormStaticGroup.controls[fieldName]) {
                    this.buyerBIDFormStaticGroup.controls[fieldName].setErrors({ invalid: true });
                    this.buyerBIDFormStaticGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;
                }
                else {
                    this.errors.push(errorObj.errorDescription);
                }
            }
        }
    }

    handleBIDValidationWarnings(bidErrors: any[]) {

        for (var key in bidErrors) {
            let errorObj = bidErrors[key];
            //for (var errorObj of gpaErrors) {
            let fieldName = errorObj.controlName;
            if (fieldName) {
                if (this.buyerBasicItemDetailGroup.controls[fieldName]) {
                    this.buyerBasicItemDetailGroup.controls[fieldName].setErrors({ warning: true });
                    this.buyerBasicItemDetailGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;
                }
                else if (this.buyerBasicGtinFormGroup.controls[fieldName]) {
                    this.buyerBasicGtinFormGroup.controls[fieldName].setErrors({ warning: true });
                    this.buyerBasicGtinFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;
                }
                else if (this.buyerBIDDynamicFormGroup.controls[fieldName]) {
                    this.buyerBIDDynamicFormGroup.controls[fieldName].setErrors({ warning: true });
                    this.buyerBIDDynamicFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;
                }
                else if (this.buyerBIDFormStaticGroup.controls[fieldName]) {
                    this.buyerBIDFormStaticGroup.controls[fieldName].setErrors({ warning: true });
                    this.buyerBIDFormStaticGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;
                }
                else {
                    this.errors.push(errorObj.errorDescription);
                }

            }
        }
    }


    showPopupToAddReuseItemCodeAsAddtionalGTIN(additionalGtinDto:AdditionalGtinDto,reuseItemCodeDto: ReuseItemCodeDto) {
        // BID18 - "Do you want to add the Type 2 GTIN  {0}  as Additional GTIN"
        let data = {
            description: this.showMessage("BID18").replace("{0}",additionalGtinDto.formattedGtin) ,
            options: [
                "Ok",
                "Cancel"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '400px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            if (result.action === "Ok") {
                this.basicItemDefService.saveReuseItemCode(reuseItemCodeDto).subscribe(res =>{
                    if (res) {
                        this.AddSelectedReuseItemCodeToAddtionalGTIN(additionalGtinDto);
                        console.log('Save Success');
                    }
                    else {
                        console.log('Save failure');
                        console.log(res);
                    }

                });
                
            }            
        });

    }

    showPopupValidateForReuseItemCode(resultMessage: string,previousReuseItemCode:number) {
        let data = {
            description: resultMessage,
            options: [
                "Ok"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '400px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {            
            if(this.CheckReuseItemCodeAlreadyExist())
            this.buyerBIDDynamicFormGroup.patchValue({ reuseItemCode: previousReuseItemCode });
            else
            this.buyerBIDDynamicFormGroup.patchValue({ reuseItemCode: "" });
            console.log(this.showMessage("BID24"));
        });

        

    }


    onReuseItemCodeChange(reuseItemCode: number) {
        let gtin = this.buyerBasicGtinFormGroup.get('formattedGtin').value;        
        let retailPackType:string = this.buyerBasicItemDetailGroup.get("retailPackType").value;
        let IsAddReuseItemCodeAsAddtionalGTIN =  (gtin.length > 0 && gtin.slice(0,3) != "002") ? true : false     
        let IsAddtionalGtinCanBeAdded:boolean = false;
        
        let itemTypeCode = this.buyerBIDDynamicFormGroup.get("itemTypes").value;
        // BID15 -"Cannot Add the reuse item code as Addtional GTIN.Please select the Retail Pack Type"
        if (IsAddReuseItemCodeAsAddtionalGTIN &&
            (itemTypeCode == "RI" || itemTypeCode == "FG")
            && retailPackType.length == 0) {
            this.showPopupValidateForReuseItemCode(this.showMessage("BID15"), gtin.slice(4, 9));
        }
        else {
            let reuseItemCodeDto: ReuseItemCodeDto = new ReuseItemCodeDto();
            reuseItemCodeDto.itemCode = reuseItemCode;
            if (reuseItemCode.toString().length > 0)
                this.ValidateAndSaveReuseItemCode(reuseItemCodeDto, true);
        }
    }

    private showHideControlsOnInit(){
        // Disable GTINCheckDigit if there is a price look up value.
        if (this.buyerBIDDynamicFormGroup.get("priceLookupCode").value) {
            this.buyerBasicGtinFormGroup.get("gtinCheckDigit").disable();
        }     
    }
    disablebackroomScaleIndicator:boolean = false;
    //Back Room Scale Indicator should be defaulted to 'Y' for Type-2 GTIN, N for others
    subscribeGTINChanges() {
        const formattedGtin = this.buyerBasicGtinFormGroup.controls.formattedGtin;
        // initialize value changes stream
        const changes$ = formattedGtin.valueChanges;
        // subscribe to the stream
        changes$.subscribe(gtin => {
            // Type 2 gtin
            if(gtin.slice(0,3) == "002"){
                this.buyerBasicItemDetailGroup.controls.backroomScaleIndicator.setValue("Y");
                //this.buyerBasicItemDetailGroup.controls.backroomScaleIndicator.disable();
                this.disablebackroomScaleIndicator = true;
            }
            else {
                //this.buyerBasicItemDetailGroup.controls.backroomScaleIndicator.setValue("N");
                //this.buyerBasicItemDetailGroup.controls.backroomScaleIndicator.enable();
                this.disablebackroomScaleIndicator = false;
            }
            
        });
    }
    disableShipper:boolean = false;
    subscribePLUChanges() {
        const priceLookupCode = this.buyerBIDDynamicFormGroup.controls.priceLookupCode;
        // initialize value changes stream
        const changes$ = priceLookupCode.valueChanges;
        // subscribe to the stream
        changes$.subscribe(plu => {
            // Type 2 gtin
            if(plu){
                this.buyerBIDFormStaticGroup.controls.itemCaseTypeID.setValue("1");
                this.disableShipper = true;
                //this.buyerBIDFormStaticGroup.controls.itemCaseTypeID.disable();
            }
            else {
                this.disableShipper = false;
               // this.buyerBIDFormStaticGroup.controls.itemCaseTypeID.enable();
            }
            
        });
    }

    clearCompUPCPLU(e) {
        // Make the CompressedUPC empty if GTIN is manually updated or changed.
        this.basicItemDefinitionDto.compressedUPC = '';
        this.basicItemDefinitionDto.priceLookupCode = '';
        this.basicItemDefinitionDto.gtinCheckDigit = null;
        this.buyerBIDDynamicFormGroup.controls.priceLookupCode.setValue("");
        this.buyerBIDDynamicFormGroup.controls.compressedUPC.setValue("");
        this.buyerBasicGtinFormGroup.controls.gtinCheckDigit.setValue(null);
        this.buyerBasicGtinFormGroup.get("gtinCheckDigit").enable();
        // this.buyerBIDDynamicFormGroup.patchValue({ 
        //     "priceLookupCode":"",
        //     "compressedUPC": ""
        // });
       
    }
    public get checkDigitDisplay(): number {
        var formattedGtinControl = this.buyerBasicGtinFormGroup.controls.formattedGtin;
        let gtin = formattedGtinControl.value;
        if(gtin && gtin.length == 15){
            return this.gtinHelper.getCheckdigit(gtin)
        }
        return null;
    }
    public FormatGtin(): void {
        this.clearCompUPCPLU({});// Fix if GTIN is copied instead keying in. Calling the keypress event here.
        const formattedGtinControl = this.buyerBasicGtinFormGroup.controls.formattedGtin;
        let gtin = formattedGtinControl.value;     
        if (gtin.length > 7) {
            formattedGtinControl.patchValue(this.gtinHelper.padGtin(gtin,13));
            this.gtinValidationRules();
        }
        this.isGTINValid();

        //this.GetItemDataByGTIN();
    }
    public changeGTINCheckdigit(): void {
        let gtin = this.buyerBasicGtinFormGroup.controls.formattedGtin.value;   
        if(gtin.length > 7){
            this.buyerBasicGtinFormGroup.controls.formattedGtin.markAsTouched({ onlySelf: true });
            this.gtinValidationRules();
        }
        this.isGTINValid();
    }
    private gtinValidationRules(){
        const formattedGtinControl = this.buyerBasicGtinFormGroup.controls.formattedGtin;
        formattedGtinControl.setValidators([gtinValidator({
            validateCheckDigit: true,
            range: true,
            type2: false,
            dummy: true,
            vendorCoupon: true
        })]);
        formattedGtinControl.updateValueAndValidity();
    }
    public isGTINValid(){
        const formattedGtinControl = this.buyerBasicGtinFormGroup.controls.formattedGtin;
        if(formattedGtinControl.status == "VALID"){
            this.showBuyerItemDetails();
            // if (this.basicItemDefinitionDto.itemDescription != undefined)
            // this.ShowConfirmationBox(this.showMessage("BID19"), "Gtin", 0);
            // else
            // this.GetItemDataByGTIN();
            this.basicItemDefinitionDto.formattedGtin = formattedGtinControl.value;
            let gtintype: string = formattedGtinControl.value.slice(0, 3);
            let itemTypeCode = this.basicItemDefinitionDto.itemTypeCode;
            if(gtintype === "002" && (itemTypeCode != "RI" && itemTypeCode != "FG")){
                let data = {
                    description: "Type 2 GTIN is Available only for Retail Item Types.",
                    options: [
                        "Ok"
                    ]
                }
                let dialogRef = this.dialog.open(DialogContentComponent, {
                    disableClose: true,
                    width: '400px',
                    data: data
                });
        
                dialogRef.afterClosed().subscribe(result => {
                    this.buyerBIDDynamicFormGroup.patchValue({ formattedGtin: this.basicItemDefinitionDto.formattedGtin });                 
                });
            } 
            else if (gtintype === "002" && (itemTypeCode == "RI" || itemTypeCode == "FG" ))            
            this.ValidatePrimaryGTIN();
            else {
                let  gtin = this.basicItemDefinitionDto.formattedGtin.replace(/-/g, "");
                this.basicItemDefService.isGTINExists(+gtin).subscribe(response =>{                                        
                    this.basicItemDefinitionDto.reuseItemCode = +this.basicItemDefinitionDto.formattedGtin.slice(4,9);
                    if(response.isGTINExist){
                      this.basicItemDefinitionDto.lastScanDate = response.lastScanDate.toString();                        
                     this.lastScanDateRules(this.basicItemDefinitionDto,false);
                                                          
                    }
                    else {
                        //this.showBuyerItemDetails(); 
                    }
                });
            }
            if (this.buyerBIDFormStaticGroup.get("modelProductItemCode").value)
            this.showViewAndCopyModelItem = true;
            else
            this.showViewAndCopyModelItem = false;
        }
    }
    public ConvertCompressedUPCToGTIN(newValue) {
        this.buyerBasicGtinFormGroup.patchValue({
            "formattedGtin": '',
            "gtinCheckDigit": null
        });
        this.buyerBIDDynamicFormGroup.controls.priceLookupCode.setValue("");
        //console.log(newValue);
        if (newValue && newValue.length == 6) {
            this.basicItemDefService.ConvertCompressedUPCToGTIN(newValue).subscribe(res => {
                const formattedGtinControl = this.buyerBasicGtinFormGroup.controls.formattedGtin;
                formattedGtinControl.setValidators([]);
                this.buyerBasicGtinFormGroup.get("gtinCheckDigit").enable();
                this.buyerBasicGtinFormGroup.patchValue({ 
                    "formattedGtin":res,
                    "gtinCheckDigit": this.gtinHelper.getCheckdigit(res)
                });
                this.buyerBIDDynamicFormGroup.controls.priceLookupCode.setValue("");
                this.basicItemDefinitionDto.formattedGtin = res;
                this.basicItemDefinitionDto.gtinCheckDigit = this.buyerBasicGtinFormGroup.controls.gtinCheckDigit.value;
                this.basicItemDefinitionDto.priceLookupCode = '';
                this.isGTINValid();
            });
            //this.showBuyerItemDetails();
            
        }
    }

    public ConvertPLUToGTIN(newValue) {
        //console.log(newValue);
        this.buyerBasicGtinFormGroup.patchValue({
            "formattedGtin": '',
            "gtinCheckDigit": null
        });
        this.buyerBIDDynamicFormGroup.controls.compressedUPC.setValue("");
        if (newValue && newValue.length == 5) {
            let newValueTwoChar: string = newValue.slice(0, 2);
            if(newValueTwoChar != "83" &&  newValueTwoChar != "84" && newValueTwoChar != "93" &&  newValueTwoChar != "94" ){
                this.buyerBIDDynamicFormGroup.controls["priceLookupCode"].setErrors({ notvalid: true });
                this.buyerBIDDynamicFormGroup.controls["priceLookupCode"].markAsTouched({ onlySelf: true });
                return;
            }
            this.basicItemDefService.ConvertPLUToGTIN(newValue).subscribe(res => {
                const formattedGtinControl = this.buyerBasicGtinFormGroup.controls.formattedGtin;
                formattedGtinControl.setValidators([]);
                this.buyerBasicGtinFormGroup.patchValue({ 
                    "formattedGtin":res,
                    "gtinCheckDigit": null
                });
                this.buyerBIDDynamicFormGroup.controls.compressedUPC.setValue("");
                this.basicItemDefinitionDto.formattedGtin = res; 
                this.basicItemDefinitionDto.gtinCheckDigit = null;
                this.basicItemDefinitionDto.compressedUPC = '';
                this.buyerBasicGtinFormGroup.get("gtinCheckDigit").disable();
                this.isGTINValid();
            });
             //this.showBuyerItemDetails();
        }
    }

    getErrorMessage(control: FormControl, name: string){
        for (let propertyName in control.errors) {
            if ((propertyName == "invalid" || propertyName == "warning") && this.formErrors[name]) {
                return this.formErrors[name];
            }
            if (control.errors.hasOwnProperty(propertyName) && control.touched) {
              return this.getValidatorErrorMessage(propertyName, control.errors[propertyName]);
            }
          }          
          return null;
    }
    getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            'required': 'This field is required.',
            'email': 'This is not a valid email',
            'minlength': `This field should have atleast ${validatorValue.requiredLength} characters`,
            'beforePadding' : 'This field is required.',
            'range' : 'Invalid GTIN.',
            'type2' : "GTIN entered is reserved for type -2 GTIN's.",
            'dummy' : "GTIN entered is reserved for Dummy GTIN's.",
            'vendorCoupon': "GTIN entered is reserved for Vendor Coupons.",
            'checkDigitRequired':"GTIN Check digit is required to validate GTIN.",
            'checkDigit' : 'GTIN is not valid for the entered check digit.',            
            'notvalid': 'This is not a valid value',
        };
        return config[validatorName];
    }

    private handleValidationErrors(validationErrorDictionary: any[]) {
        for (var key in validationErrorDictionary) {
            let obj = validationErrorDictionary[key];
            let fieldName = obj.controlName;
            if (fieldName) {
                if (this.buyerBIDDynamicFormGroup.controls[fieldName]) {
                    //integrate into angular's validation if we have field validation
                    this.buyerBIDDynamicFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.buyerBIDDynamicFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = obj.errorDescription;
                }
                else if (fieldName == "formattedGtin" || fieldName == "gtinCheckDigit") {
                    this.buyerBasicGtinFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.buyerBasicGtinFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = obj.errorDescription;
                }
                else if (fieldName == "modelProductItemCode") {
                    this.buyerBIDFormStaticGroup.controls[fieldName].setErrors({ invalid: true });
                    this.buyerBIDFormStaticGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = obj.errorDescription;
                }
                else {
                    this.errors.push(obj.errorDescription);
                }
            }
        }
    }

    public onIsStandardOrShipperChange(IsStandardOrShipper) {       
        if (IsStandardOrShipper == "1")             
            this.EnableShipperItemComposition(false);        
        else 
            this.EnableShipperItemComposition(true);
    }

    public EnableShipperItemComposition(EnableSICLink) {
        let dsdVendorLink: NewItemTab = this.newItemFormService.links.find(x => x.link == 'shipper-item-composition');
        if (EnableSICLink)
            dsdVendorLink.disabled = false;
        else
            dsdVendorLink.disabled = true;
    }

    // private IsItemDataByGtin: boolean = false;
    // specificGtinValidator(group: FormGroup) {
    //     let compressedUPC = this.basicItemDefinitionDto ? this.basicItemDefinitionDto.compressedUPC : null;
    //     let priceLookupCode = this.basicItemDefinitionDto ? this.basicItemDefinitionDto.priceLookupCode : null;
    //     var result = ValidateGtin.specificGtinValidatorFn(group, compressedUPC, priceLookupCode);
    //     // && this.showBIDDetailExpectItemtype && this.basicItemDefinitionDto.itemDescription != undefined
    //     console.log(this.basicItemDefinitionDto.itemDescription);
    //     if (result == -1 && group.dirty && !this.IsItemDataByGtin) {
    //         //if(result == -1 && group.dirty){ 
    //             // BID 19 Do you want to Clear the Existing GTIN Item Details
    //         if (this.basicItemDefinitionDto.itemDescription != undefined)
    //             this.ShowConfirmationBox(this.showMessage("BID19"), "Gtin", 0);
    //         else
    //             this.GetItemDataByGTIN();
    //         return;
    //     }
    //     return result;
    // }

    private ShowConfirmationBox(descriptions: string, GtinOrItemCode: string, itemid: number) {
        let data = {
            description: descriptions,
            options: [
                "Ok",
                "Cancel"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '400px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            if (result.action === "Ok") {
                if (GtinOrItemCode === "Gtin")
                    this.GetItemDataByGTIN();
                else
                    this.saveItemDataByPmdsItemCode(itemid);
            }

            if (result != undefined) {

            }
        });

    }


    public openDialog(): void {

        
        let dialogRef = this.dialog.open(DialogAdditionalGtinComponent, {
            width: '1000px',
            data: { additionalGtinList: this.additionalGtinRows, showRetailPackTypePackSizeLabel: this.showRetailPackTypePackSizeLabel, isBuyer:true}
        });
        const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {
            this.additionalGtinRows.push(result);
            this.UpdateAdditionalGtinRowId();
            this.getInitialAdditionalGtinData();
        });
        dialogRef.afterClosed().subscribe(result => {
            sub.unsubscribe();
            if (result && result.formattedGtin) {
                this.additionalGtinRows.push(result);
                this.UpdateAdditionalGtinRowId();
            }
            this.getInitialAdditionalGtinData();
            // console.log('The dialog was closed');
            // console.log(result);
            // if (result != undefined) {
            //     this.additionalGtinRows = (this.additionalGtinRows == undefined) ? [] : this.additionalGtinRows;
            //     for (let additionalGtinDto of result.additionalGtinList) {
            //         this.additionalGtinRows.push(additionalGtinDto);
            //     }
            //     this.UpdateAdditionalGtinRowId();
            //     this.getInitialAdditionalGtinData();
            // }


        });
    }

    private UpdateAdditionalGtinRowId() {
        let count: number = 1;
        if (this.additionalGtinRows != undefined) {
            for (let additionalGtin of this.additionalGtinRows) {
                additionalGtin.rowId = count++;
            }
        }
    }

    onIsAdditionalGtinReqdChange(IsAdditionalGtinReqd) {
        if (IsAdditionalGtinReqd === 'Y') {
            this.basicItemDefinitionDto.additionalGTINPresent = 'Y'
            this.openDialog();
        }
        else
            this.basicItemDefinitionDto.additionalGTINPresent = 'N'

        console.log(this.basicItemDefinitionDto.additionalGTINPresent);
    }

    // Grid specific events
    getAdditionalGtinData(gridEvent: GridEvent) {
        this.data = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }
    getInitialAdditionalGtinData() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 0,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getAdditionalGtinData(gridEvent);
    }
    /**
  * return the filtered or shallow copy without changing the original data
  */
    performFilter(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.additionalGtinRows.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.additionalGtinRows.slice();
        }
        return this.additionalGtinRows.slice();
    }
    /**
     * sort the filtered result based on sort column and order
     */
    sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.data.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.data.reverse();
        }
    }
    /**
       * paginate the result set
       */
    pageData(gridEvent: GridEvent) {
        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.data.length;
        let pageIndex = gridEvent.pageIndex;
        let offset = pageIndex * this.pageSize;
        this.data = this.data.slice(offset, offset + this.pageSize);
    }

    GetItemDataByGTIN() {
        let gtin = this.basicItemDefinitionDto.formattedGtin.replace(/-/g, "");
        // BID19 "Do you want to clear existing GTIN details"
        this.basicItemDefService.isGTINExists(+gtin).subscribe(response => {
            if (response.isGTINExist) {
                if (this.basicItemDefinitionDto.itemDescription == undefined )
                    this.SaveAndDisplayItemDataByPmdsGTIN();
                else {
                    let data = {
                        description: this.showMessage("BID19"),
                        options: [
                            "Ok",
                            "Cancel"
                        ]
                    }
                    let dialogRef = this.dialog.open(DialogContentComponent, {
                        disableClose: true,
                        width: '400px',
                        data: data
                    });

                    dialogRef.afterClosed().subscribe(result => {
                        console.log('The dialog was closed');
                        if (result.action === "Ok")
                            this.SaveAndDisplayItemDataByPmdsGTIN();

                    });
                }
            }

            this.showBuyerItemDetails();

        })



        //get data and populate.
    }

    SaveAndDisplayItemDataByPmdsGTIN() {
        this.basicItemDefinitionDto.itemFormDisplayId = this.itemFormDisplayId;
        this.basicItemDefinitionDto.itemFormID = this.newItemFormService.itemFormID;

        this.basicItemDefinitionDto.itemTypeCode = this.buyerBIDDynamicFormGroup.get("itemTypes").value;
        if (this.basicItemDefinitionDto.itemTypeCode != undefined) {
            let itemType: ILookupDto = this.itemTypesList.find(x => x.code == this.basicItemDefinitionDto.itemTypeCode);
            if (itemType != undefined)
                this.basicItemDefinitionDto.itemTypeDescription = itemType.description;
        }

        this.basicItemDefinitionDto.autoGenerateType4GTIN = this.buyerBIDDynamicFormGroup.get("AutoGenerateType4GTIN").value;
        this.basicItemDefinitionDto.recipeRequired = this.buyerBIDDynamicFormGroup.get("IsRecipe").value;
        this.basicItemDefinitionDto.ingredientItemRequired = this.buyerBIDDynamicFormGroup.get("IsIngredientItemRequired").value;
        this.basicItemDefinitionDto.formattedGtin = this.buyerBasicGtinFormGroup.get("formattedGtin").value;
        this.basicItemDefinitionDto.gtinCheckDigit = this.buyerBasicGtinFormGroup.get("gtinCheckDigit").value;
        this.basicItemDefinitionDto.compressedUPC = this.buyerBIDDynamicFormGroup.get("compressedUPC").value;
        this.basicItemDefinitionDto.priceLookupCode = this.buyerBIDDynamicFormGroup.get("priceLookupCode").value;
        this.basicItemDefinitionDto.reuseItemCode = this.buyerBIDDynamicFormGroup.get("reuseItemCode").value;            

        this.basicItemDefinitionDto.createdBy = this.userId;
        this.basicItemDefinitionDto.lastUpdatedBy = this.userId;
        this.basicItemDefinitionDto.submittedUserTypeID = UserType.Buyer;
        this.basicItemDefinitionDto.vendorContactID = this.newItemFormService.vendorContactID;

        this.basicItemDefService.saveItemDataByPmdsGTIN(this.basicItemDefinitionDto).subscribe(res => {
            //this.IsItemDataByGtin = true;
            //it will be done before calling this function
            //this.lastScanDateRules(res);
            this.basicItemDefinitionDto = res;
            this.DisplayBasicItemDefinitionFromDTO();
            //var gtinHeaderDto = this.populateGtinHeaderDto();
            //this.newItemFormService.setItemFormDisplayID(this.itemFormDto.itemFormDisplayID, null);
            //this.newItemFormService.setGtinHeaderDetails(gtinHeaderDto);
        });
        this.showBuyerItemDetails();

    }
    
    
    getItemDataByItemCode(itemId: any): void {

        if (this.buyerBIDFormStaticGroup.get("modelProductItemCode").value) {
            this.ShowConfirmationBox(this.showMessage("BID19"), "ItemId", itemId);
        }
        else {
            this.showViewAndCopyModelItem = false;
            this.basicItemDefinitionDto.modelProductItemDescription = ''; 
            this.basicItemDefinitionDto.modelProductItemTypeCode = null;  
            this.basicItemDefinitionDto.modelPackagingItemTypeCode = null;

            this.basicItemDefService.deleteModelProductItemValues(this.basicItemDefinitionDto.itemFormID).subscribe(res => {  
                if (res)
                    console.log('Deleted ModelProductItemValues Successfully');
                else
                    console.log('Deleted ModelProductItemValues failed');
            });
        }
               

        // BID19 "Do you want to Clear the Existing Item Details"
        //if (this.basicItemDefinitionDto.itemDescription != undefined)
       
      
    //else
    //this.saveItemDataByPmdsItemCode(itemId);
    }
 

    public saveItemDataByPmdsItemCode(itemId: any): void {

        this.basicItemDefinitionDto.itemFormID = this.newItemFormService.itemFormID;
        this.basicItemDefinitionDto.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;

        this.basicItemDefinitionDto.itemTypeCode = this.buyerBIDDynamicFormGroup.get("itemTypes").value;
        this.basicItemDefinitionDto.autoGenerateType4GTIN = this.buyerBIDDynamicFormGroup.get("AutoGenerateType4GTIN").value;
        this.basicItemDefinitionDto.recipeRequired = this.buyerBIDDynamicFormGroup.get("IsRecipe").value;
        this.basicItemDefinitionDto.ingredientItemRequired = this.buyerBIDDynamicFormGroup.get("IsIngredientItemRequired").value;
        this.basicItemDefinitionDto.formattedGtin = this.buyerBasicGtinFormGroup.get("formattedGtin").value;
        this.basicItemDefinitionDto.gtinCheckDigit = this.buyerBasicGtinFormGroup.get("gtinCheckDigit").value;
        this.basicItemDefinitionDto.compressedUPC = this.buyerBIDDynamicFormGroup.get("compressedUPC").value;
        this.basicItemDefinitionDto.priceLookupCode = this.buyerBIDDynamicFormGroup.get("priceLookupCode").value;
        this.basicItemDefinitionDto.reuseItemCode = this.buyerBIDDynamicFormGroup.get("reuseItemCode").value;

        this.basicItemDefinitionDto.modelProductItemCode = itemId;
        this.basicItemDefinitionDto.itemCaseTypeID = this.buyerBIDFormStaticGroup.get("itemCaseTypeID").value == null ? "1" : this.buyerBIDFormStaticGroup.get("itemCaseTypeID").value;
        this.basicItemDefinitionDto.submissionReasonID = this.buyerBIDFormStaticGroup.get("submissionReasons").value;

        if (this.basicItemDefinitionDto.itemTypeCode != undefined) {
            let itemType: ILookupDto = this.itemTypesList.find(x => x.code == this.basicItemDefinitionDto.itemTypeCode);
            if (itemType != undefined)
                this.basicItemDefinitionDto.itemTypeDescription = itemType.description;
        }

        this.basicItemDefinitionDto.createdBy = this.userId;
        this.basicItemDefinitionDto.lastUpdatedBy = this.userId;
        this.basicItemDefinitionDto.submittedUserTypeID = UserType.Buyer;
        this.basicItemDefinitionDto.vendorContactID = this.newItemFormService.vendorContactID;

        if (this.buyerBIDFormStaticGroup.get("modelProductItemCode").value) {

            this.basicItemDefService.saveItemDataByPmdsItemCode(this.basicItemDefinitionDto).subscribe(res => {
                this.populateBIDData(res);
                //this.IsItemDataByGtin = true;
                this.basicItemDefinitionDto = res;
                this.showViewAndCopyModelItem = true;
                this.DisplayBasicItemDefinitionFromDTO();
                this.showBuyerItemDetails();
                //this.ShowItemDetails();           
            },
                (err) => {
                    if (err.status === 400) {

                        this.showViewAndCopyModelItem = false;
                        // handle validation error
                        let validationErrorDictionary = err.error;
                        //let validationErrorDictionary = err.error.modelState;
                        this.handleValidationErrors(validationErrorDictionary);

                    } else {
                        this.errors.push("Unhandled expection occured.");
                    }
                    if(this.PreviousItemType != null){
                    this.buyerBIDDynamicFormGroup.patchValue({ "itemTypes": this.PreviousItemType });
                    this.basicItemDefinitionDto.itemTypeCode = this.PreviousItemType;
                }
                    window.scrollTo(0, 0);
                });

        }
       
        else {

            this.showViewAndCopyModelItem = false;
            this.basicItemDefinitionDto.modelProductItemDescription = '';             

            /*      

            //TODO Remove Mandatory field validation before save
            this.buyerBasicItemDetailGroup.patchValue({
                itemDescription: '',
                receiptDescription: '',
                scaleDescription1: '',
                scaleDescription2: '',
                adDescription: '',
                productCatalogShortDescription1: '',
                productCatalogShortDescription2: '',
                backroomScaleIndicator: '',
                vendorItemCode: '',
                vendorItemDescription: '',
                //brand: '',
                //manufacturer: '',
                isItemPackagedForRetail: '',
                size: '',
                sizeUOM: '',
                retailPackType: '',
                retailPackSize: '',
                labelAmount: '',
                nonDiscountable: '',
                pIItemFlag: '',
                //minorityManufacturer: '',
                //packageDescription: '',
                containerType: '',
                isAdditionalGtinReqd: '0'
            });

            this.PopulateBasicItemDefinitionDTO();

            this.basicItemDefService.saveBasicItemDefinition(this.basicItemDefinitionDto).subscribe(res => {
                if (res != undefined) {

                    //Storing the itemFormDisplayID and GTIn fields in the service 
                    var gtinHeaderDto = this.populateGtinHeaderDto();
                    //this.newItemFormService.setItemFormDisplayID(this.itemFormDto.itemFormDisplayID, null);
                    this.newItemFormService.setGtinHeaderDetails(gtinHeaderDto);
                }
                else {
                    console.log('Changes Saved Successfully');
                }
            },
                (err) => {
                    if (err.status === 400) {
                        // handle validation error
                        let validationErrorDictionary = err.error;
                        //let validationErrorDictionary = err.error.modelState;
                        this.handleValidationErrors(validationErrorDictionary);

                    } else {
                        this.errors.push("Unhandled expection occured.");
                    }
                    window.scrollTo(0, 0);
                })
                */
        }

     
    }


    public saveModelDataForPackagingHierarchy(itemCode: any): void {

        if (itemCode) {
            let basicItemDefinition = (<any>Object).assign({}, this.buyerBIDFormStaticGroup.value);
            basicItemDefinition.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
            basicItemDefinition.submittedUserTypeID = UserType.Buyer;
            basicItemDefinition.lastUpdatedBy = this.userId; //NOT Used
            basicItemDefinition.createdBy = this.userId;
            basicItemDefinition.vendorContactID = this.newItemFormService.vendorContactID;
            basicItemDefinition.formStatusID = 1;
            basicItemDefinition.itemFormId = this.newItemFormService.itemFormID;
            this.showModelSpinner = true;
            this.basicItemDefService.saveModelDataForPackagingHierarchy(basicItemDefinition).subscribe(res => {
                this.showModelSpinner = false;
                //   this.populateBIDData(res);
                // this.ShowItemDetails();           
            },
                (err) => {
                    this.buyerBIDFormStaticGroup.controls["modelPackagingItemCode"].setErrors({ notvalid: true });
                    this.buyerBIDFormStaticGroup.controls["modelPackagingItemCode"].markAsTouched({ onlySelf: true });
                    this.showModelSpinner = false;
                });
        }

    }

    private lastScanDateRules(basicItemDefinition: IBasicItemDefnitionDto,checkReuseItemValid:boolean) {
        if (basicItemDefinition) {
            const lastScanDate = basicItemDefinition.lastScanDate;
            const age = this.diffInyears(lastScanDate);
            if (age >= 2) {
                this.openGtinExitsGT2Dialog(basicItemDefinition,checkReuseItemValid);
                
            }
            else if (age === 0 || age === 1) {
                this.openGtinExitsLT2Dialog(basicItemDefinition);
            }
        }

    }

    private populateBIDData(basicItemDefinition: IBasicItemDefnitionDto) {
        this.basicItemDefinitionDto = basicItemDefinition;
        if (this.basicItemDefinitionDto.itemTypeCode == "RI" || this.basicItemDefinitionDto.itemTypeCode == "FG") {
            this.basicItemDefinitionDto.retailPackagedItem = "Y";
        }
        this.additionalGtinRows = basicItemDefinition.addtionalGtinList || [];
        this.UpdateAdditionalGtinRowId();
        this.getInitialAdditionalGtinData();
    }
    private openGtinExitsGT2Dialog(basicItemDefinition: IBasicItemDefnitionDto,checkReuseItemValid:boolean): void {
        // BID20 "Last scan date is greater than 2 years. Do you want to enter a New Item or Item Maintanence"
        let data = {
            title: "",
            description: this.showMessage("BID20"),
            options: [
                "New Item",
                "Item Maintanence"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            this.populateBIDData(basicItemDefinition);
              
            if (result && result.action == "New Item") {
                this.basicItemDefinitionDto.formTypeID = 1;
                this.newItemFormService.formTypeID = this.basicItemDefinitionDto.formTypeID;
                if(checkReuseItemValid){
                    let reuseItemCodeDto: ReuseItemCodeDto = new ReuseItemCodeDto();
                     reuseItemCodeDto.itemCode = this.basicItemDefinitionDto.reuseItemCode;
                     this.ValidateAndSaveReuseItemCode(reuseItemCodeDto,false); 
                }              
      
            }
            else {
                this.basicItemDefinitionDto.formTypeID = 2;
                this.newItemFormService.formTypeID = this.basicItemDefinitionDto.formTypeID;

            }
            this.GetItemDataByGTIN();
            this.basicItemDefinitionDto.existingGtinIndicator = "Y";
        });
    }
    private openGtinExitsLT2Dialog(basicItemDefinition: IBasicItemDefnitionDto): void {
        
        //BID21 "Item already exits. Do you want to continue as Item Maintanence?"
        let data = {
            title: "",
            description:this.showMessage("BID21") ,
            actions: [
                "No",
                "Yes"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result && result.action == "Yes") {
                this.populateBIDData(basicItemDefinition);
                this.basicItemDefinitionDto.formTypeID = 2;
                this.newItemFormService.formTypeID = this.basicItemDefinitionDto.formTypeID;
                this.basicItemDefinitionDto.existingGtinIndicator = "Y";
                this.GetItemDataByGTIN();  
               
            }
            else {
                // Make sure Dto is empty
                this.basicItemDefinitionDto.formattedGtin = "";
                this.buyerBasicGtinFormGroup.patchValue({ 'formattedGtin':this.basicItemDefinitionDto.formattedGtin });
                this.basicItemDefinitionDto.gtinCheckDigit = null;
                //this.hideBuyerItemDetails();
            }
        });
    }


    private diffInyears(calcDate: string) {
        var timeDiff = Math.abs(Date.now() - Date.parse(calcDate));
        const years = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365);
        return years;
    }

    public deleteAddtionalGtin(rowId: number): void {


        let data = {description:"Are you sure you want to delete addtional GTIN ?" ,actions: ["No","Yes"]}
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result.action === "Yes"){
                var index = this.additionalGtinRows.findIndex(x => x.rowId == rowId);
                if (index > -1) {
                    this.additionalGtinRows.splice(index, 1);
                }
                this.getInitialAdditionalGtinData();
            }

        });

       
    }

    public editAddtionalGtin(rowId: number): void {

        let additionalGtinRow: IAdditionalGtinDto = this.additionalGtinRows.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogAdditionalGtinComponent, {
            width: '800px',
            data: { additionalGtinList: this.additionalGtinRows, additionalGtinRow: additionalGtinRow, showRetailPackTypePackSizeLabel: this.showRetailPackTypePackSizeLabel, isBuyer: true }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result && result.rowId) {
                this.additionalGtinRows.splice(result.rowId-1,1,result)
                this.getInitialAdditionalGtinData();
            }
            // console.log('The dialog was closed');
            // console.log(result);
            // if (result != undefined) {
            //     for (let additionalGtinDto of this.additionalGtinRows) {
            //         if (additionalGtinDto.formattedGtin == result.additionalGtinRow.formattedGtin) {
            //             additionalGtinDto = result.additionalGtinRow;
            //         }
            //     }
            //     this.getInitialAdditionalGtinData();
            // }
        });
    }
    PopulateBasicItemDefinitionDTO() {

        this.basicItemDefinitionDto.itemFormID = this.newItemFormService.itemFormID;
        this.basicItemDefinitionDto.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
        this.basicItemDefinitionDto.lastUpdatedBy = this.userId;
        this.basicItemDefinitionDto.submittedUserTypeID = UserType.Buyer;
        this.basicItemDefinitionDto.formStatusID = 1;
        

        // buyerBasicGtinFormGroup
        this.basicItemDefinitionDto.formattedGtin = this.buyerBasicGtinFormGroup.get("formattedGtin").value;
        this.basicItemDefinitionDto.gtinCheckDigit = this.buyerBasicGtinFormGroup.get("gtinCheckDigit").value;

        // buyerBIDDynamicFormGroup
        this.basicItemDefinitionDto.itemTypeCode = this.buyerBIDDynamicFormGroup.get("itemTypes").value;
        this.basicItemDefinitionDto.autoGenerateType4GTIN = this.buyerBIDDynamicFormGroup.get("AutoGenerateType4GTIN").value;
        this.basicItemDefinitionDto.recipeRequired = this.buyerBIDDynamicFormGroup.get("IsRecipe").value;
        this.basicItemDefinitionDto.ingredientItemRequired = this.buyerBIDDynamicFormGroup.get("IsIngredientItemRequired").value;
        this.basicItemDefinitionDto.compressedUPC = this.buyerBIDDynamicFormGroup.get("compressedUPC").value;
        this.basicItemDefinitionDto.priceLookupCode = this.buyerBIDDynamicFormGroup.get("priceLookupCode").value;
        this.basicItemDefinitionDto.reuseItemCode = this.buyerBIDDynamicFormGroup.get("reuseItemCode").value;


        //   this.buyerBIDDynamicFormGroup                
        

        // buyerBasicItemDetailGroup 
        this.basicItemDefinitionDto.itemDescription = this.buyerBasicItemDetailGroup.get("itemDescription").value;
        this.basicItemDefinitionDto.receiptDescription = this.buyerBasicItemDetailGroup.get("receiptDescription").value;
        this.basicItemDefinitionDto.scaleDescription1 = this.buyerBasicItemDetailGroup.get("scaleDescription1").value;
        this.basicItemDefinitionDto.scaleDescription2 = this.buyerBasicItemDetailGroup.get("scaleDescription2").value;
        this.basicItemDefinitionDto.adDescription = this.buyerBasicItemDetailGroup.get("adDescription").value;
        this.basicItemDefinitionDto.productCatalogShortDescription1 = this.buyerBasicItemDetailGroup.get("productCatalogShortDescription1").value;
        this.basicItemDefinitionDto.productCatalogShortDescription2 = this.buyerBasicItemDetailGroup.get("productCatalogShortDescription2").value;
        this.basicItemDefinitionDto.backroomScaleIndicator = this.buyerBasicItemDetailGroup.get("backroomScaleIndicator").value;
        this.basicItemDefinitionDto.vendorItemCode = this.buyerBasicItemDetailGroup.get("vendorItemCode").value;
        this.basicItemDefinitionDto.vendorItemDescription = this.buyerBasicItemDetailGroup.get("vendorItemDescription").value;
        this.basicItemDefinitionDto.brand = this.buyerBasicItemDetailGroup.get("brand").value;
        this.basicItemDefinitionDto.manufacturer = this.buyerBasicItemDetailGroup.get("manufacturer").value;
        this.basicItemDefinitionDto.retailPackagedItem = this.buyerBasicItemDetailGroup.get("isItemPackagedForRetail").value;
        this.basicItemDefinitionDto.size = this.buyerBasicItemDetailGroup.get("size").value;
        this.basicItemDefinitionDto.sizeUOM = this.buyerBasicItemDetailGroup.get("sizeUOM").value;
        this.basicItemDefinitionDto.retailPackType = this.buyerBasicItemDetailGroup.get("retailPackType").value;
        this.basicItemDefinitionDto.retailPackSize = this.buyerBasicItemDetailGroup.get("retailPackSize").value;
        this.basicItemDefinitionDto.labelAmount = this.buyerBasicItemDetailGroup.get("labelAmount").value;
        this.basicItemDefinitionDto.nonDiscountable = this.buyerBasicItemDetailGroup.get("nonDiscountable").value;
        this.basicItemDefinitionDto.perpetualInventoryFlag = this.buyerBasicItemDetailGroup.get("pIItemFlag").value;
        this.basicItemDefinitionDto.minorityManufacturer = this.buyerBasicItemDetailGroup.get("minorityManufacturer").value;
        this.basicItemDefinitionDto.packageDescription = this.buyerBasicItemDetailGroup.get("packageDescription").value;
        this.basicItemDefinitionDto.containerType = this.buyerBasicItemDetailGroup.get("containerType").value;
        this.basicItemDefinitionDto.additionalGTINPresent = this.buyerBasicItemDetailGroup.get("isAdditionalGtinReqd").value;

    
        this.basicItemDefinitionDto.submissionReasonID = this.buyerBIDFormStaticGroup.get("submissionReasons").value;
        this.basicItemDefinitionDto.itemCaseTypeID = this.buyerBIDFormStaticGroup.get("itemCaseTypeID").value == null ? "1" : this.buyerBIDFormStaticGroup.get("itemCaseTypeID").value;
        this.basicItemDefinitionDto.modelProductItemCode = this.buyerBIDFormStaticGroup.get("modelProductItemCode").value;
        this.basicItemDefinitionDto.modelPackagingItemCode = this.buyerBIDFormStaticGroup.get("modelPackagingItemCode").value;

    }

    private populateExisingBIDDetails():void {

        // buyerBIDDynamicFormGroup
        this.buyerBIDDynamicFormGroup.patchValue({
             itemTypes: this.basicItemDefinitionDto.itemTypeCode,
            AutoGenerateType4GTIN: this.basicItemDefinitionDto.autoGenerateType4GTIN ,
            IsRecipe: this.basicItemDefinitionDto.recipeRequired ,
            IsIngredientItemRequired: this.basicItemDefinitionDto.ingredientItemRequired ,
            compressedUPC: this.basicItemDefinitionDto.compressedUPC ,
            priceLookupCode: this.basicItemDefinitionDto.priceLookupCode ,
            reuseItemCode: this.basicItemDefinitionDto.reuseItemCode ,            
            isAdditionalGtinReqd: this.basicItemDefinitionDto.additionalGTINPresent
        });

        // buyerBasicGtinFormGroup
        this.buyerBasicGtinFormGroup.patchValue({
            formattedGtin: this.basicItemDefinitionDto.formattedGtin,
            gtinCheckDigit: this.basicItemDefinitionDto.gtinCheckDigit
        });


      

        //   this.buyerBIDFormStaticGroup
        this.buyerBIDFormStaticGroup.patchValue({
            submissionReasons: this.basicItemDefinitionDto.submissionReasonID,
            itemCaseTypeID: this.basicItemDefinitionDto.itemCaseTypeID.toString(),
            modelProductItemCode: this.basicItemDefinitionDto.modelProductItemCode,
            modelPackagingItemCode: this.basicItemDefinitionDto.modelPackagingItemCode
        });

        // buyerBasicItemDetailGroup 

        this.buyerBasicItemDetailGroup.patchValue({
            itemDescription: this.basicItemDefinitionDto.itemDescription,
            receiptDescription: this.basicItemDefinitionDto.receiptDescription,
            scaleDescription1: this.basicItemDefinitionDto.scaleDescription1,
            scaleDescription2: this.basicItemDefinitionDto.scaleDescription2,
            adDescription: this.basicItemDefinitionDto.adDescription,
            productCatalogShortDescription1: this.basicItemDefinitionDto.productCatalogShortDescription1,
            productCatalogShortDescription2: this.basicItemDefinitionDto.productCatalogShortDescription2,
            backroomScaleIndicator: this.basicItemDefinitionDto.backroomScaleIndicator,
            vendorItemCode: this.basicItemDefinitionDto.vendorItemCode,
            vendorItemDescription: this.basicItemDefinitionDto.vendorItemDescription,
            brand: this.basicItemDefinitionDto.brand,
            manufacturer: this.basicItemDefinitionDto.manufacturer,
            isItemPackagedForRetail: this.basicItemDefinitionDto.retailPackagedItem,
            size: this.basicItemDefinitionDto.size,
            sizeUOM: this.basicItemDefinitionDto.sizeUOM,
            retailPackType: this.basicItemDefinitionDto.retailPackType,
            retailPackSize: this.basicItemDefinitionDto.retailPackSize,
            labelAmount: this.basicItemDefinitionDto.labelAmount,
            nonDiscountable: this.basicItemDefinitionDto.nonDiscountable,
            pIItemFlag: this.basicItemDefinitionDto.perpetualInventoryFlag,
            minorityManufacturer: this.basicItemDefinitionDto.minorityManufacturer,
            packageDescription: this.basicItemDefinitionDto.packageDescription,
            containerType: this.basicItemDefinitionDto.containerType,
            isAdditionalGtinReqd: this.basicItemDefinitionDto.additionalGTINPresent,
            reuseItemCode: this.basicItemDefinitionDto.reuseItemCode,
            retailPackTypeDescription: this.basicItemDefinitionDto.retailPackTypeDescription,
            sizeUOMDescription: this.basicItemDefinitionDto.sizeUOMDescription
        });
        if (this.basicItemDefinitionDto.itemTypeCode != null) {
            this.ShowHideControlBasedOnIsRetail(this.itemTypesList.find(item => item.code === this.basicItemDefinitionDto.itemTypeCode));

            console.log("this.basicItemDefinitionDto.isBrandChanged" + this.basicItemDefinitionDto.isBrandChanged);
            console.log("this.basicItemDefinitionDto.isManufacturerChanged" + this.basicItemDefinitionDto.isManufacturerChanged);


            if (this.basicItemDefinitionDto.itemTypeCode === "FG" || this.basicItemDefinitionDto.itemTypeCode === "WP") {
                this.showIsReceipeRequired = true;
                this.showIsIngredientItemRequired = true;
            }
            else {
                this.showIsReceipeRequired = false;
                this.showIsIngredientItemRequired = false;
            }

            if (this.basicItemDefinitionDto.itemTypeCode === "RI") {
                //this.showAutoGenerateType4GTIN = false;
                this.showIsReceipeRequired = false;
                this.showGTINRelatedRow = true;
                this.isItemPackedForRetail = true;
            }
            else {
                this.isItemPackedForRetail = false;
                this.setGTINRelatedFlag();
            }

            if (this.basicItemDefinitionDto.retailPackagedItem)
                this.showRetailPackTypePackSizeLabel = this.basicItemDefinitionDto.retailPackagedItem.trim() == "Y" ? true : false;
        }

        this.showBuyerItemDetails();
    }

    changeManufactureBackground(): any {
        let color = "#E5E5E5";
        if(this.basicItemDefinitionDto.isManufacturerChanged && this.buyerBIDFormStaticGroup.get("modelProductItemCode").value)
         color = "coral";
        return { 'background-color': color };
    }

    changeBrandBackground(): any {       

        let color = "#E5E5E5";
        if(this.basicItemDefinitionDto.isBrandChanged && this.buyerBIDFormStaticGroup.get("modelProductItemCode").value)
        color = "coral";
        return { 'background-color': color };
        
    }

    DisplayBasicItemDefinitionFromDTO() {


        // buyerBasicGtinFormGroup
        this.buyerBasicGtinFormGroup.patchValue({
            formattedGtin: this.basicItemDefinitionDto.formattedGtin,
            gtinCheckDigit: this.basicItemDefinitionDto.gtinCheckDigit
        });


        // buyerBIDDynamicFormGroup
        this.buyerBIDDynamicFormGroup.patchValue({
            //itemTypes: this.basicItemDefinitionDto.formattedGtin,
            //AutoGenerateType4GTIN: this.basicItemDefinitionDto.autoGenerateType4GTIN ,
            //IsRecipe: this.basicItemDefinitionDto.recipeRequired ,
            //IsIngredientItemRequired: this.basicItemDefinitionDto.ingredientItemRequired ,
            //compressedUPC: this.basicItemDefinitionDto.compressedUPC ,
            //priceLookupCode: this.basicItemDefinitionDto.priceLookupCode ,
            //reuseItemCode: this.basicItemDefinitionDto.reuseItemCode ,            
            isAdditionalGtinReqd: this.basicItemDefinitionDto.additionalGTINPresent
        });

        //   this.buyerBIDFormStaticGroup
        this.buyerBIDFormStaticGroup.patchValue({
            //submissionReasons: this.basicItemDefinitionDto.submissionReasonID,
            //itemCaseTypeID: this.basicItemDefinitionDto.itemCaseTypeID,
            modelProductItemCode: this.basicItemDefinitionDto.modelProductItemCode,
            modelPackagingItemCode: this.basicItemDefinitionDto.modelPackagingItemCode
        });

        // buyerBasicItemDetailGroup 

        this.buyerBasicItemDetailGroup.patchValue({
            itemDescription: this.basicItemDefinitionDto.itemDescription,
            receiptDescription: this.basicItemDefinitionDto.receiptDescription,
            scaleDescription1: this.basicItemDefinitionDto.scaleDescription1,
            scaleDescription2: this.basicItemDefinitionDto.scaleDescription2,
            adDescription: this.basicItemDefinitionDto.adDescription,
            productCatalogShortDescription1: this.basicItemDefinitionDto.productCatalogShortDescription1,
            productCatalogShortDescription2: this.basicItemDefinitionDto.productCatalogShortDescription2,
            backroomScaleIndicator: this.basicItemDefinitionDto.backroomScaleIndicator,
            vendorItemCode: this.basicItemDefinitionDto.vendorItemCode,
            vendorItemDescription: this.basicItemDefinitionDto.vendorItemDescription,
            brand: this.basicItemDefinitionDto.brand,
            manufacturer: this.basicItemDefinitionDto.manufacturer,
            //isItemPackagedForRetail: this.basicItemDefinitionDto.retailPackagedItem,
            size: this.basicItemDefinitionDto.size,
            sizeUOM: this.basicItemDefinitionDto.sizeUOM,
            retailPackType: this.basicItemDefinitionDto.retailPackType,
            retailPackSize: this.basicItemDefinitionDto.retailPackSize,
            labelAmount: this.basicItemDefinitionDto.labelAmount,
            nonDiscountable: this.basicItemDefinitionDto.nonDiscountable,
            pIItemFlag: this.basicItemDefinitionDto.perpetualInventoryFlag,
            minorityManufacturer: this.basicItemDefinitionDto.minorityManufacturer,
            packageDescription: this.basicItemDefinitionDto.packageDescription,
            containerType: this.basicItemDefinitionDto.containerType,
            isAdditionalGtinReqd: this.basicItemDefinitionDto.additionalGTINPresent,
            reuseItemCode: this.basicItemDefinitionDto.reuseItemCode,
            retailPackTypeDescription: this.basicItemDefinitionDto.retailPackTypeDescription,
            sizeUOMDescription: this.basicItemDefinitionDto.sizeUOMDescription
        });
        console.log("this.basicItemDefinitionDto.isBrandChanged"+this.basicItemDefinitionDto.isBrandChanged);
        console.log("this.basicItemDefinitionDto.isManufacturerChanged" +this.basicItemDefinitionDto.isManufacturerChanged);
        if(this.basicItemDefinitionDto.isBrandChanged)
            //alert(this.buyerBasicItemDetailGroup.get("brand"));
        if(this.basicItemDefinitionDto.isManufacturerChanged)
           // alert(this.buyerBasicItemDetailGroup.get("manufacturer"));        

        this.ShowHideControlBasedOnIsRetail(this.itemTypesList.find(item => item.code === this.buyerBIDDynamicFormGroup.get("itemTypes").value));


    }




    //public performAction(): void {
    //    let selectedAction = this.buyerBIDActionsFormGroup.get("actionId").value;

    //    switch (selectedAction) {
    //        case 1:
    //            this.saveBasicItemDefinition();
    //            break;
    //        case 2:
    //            this.deleteItemForm();
    //            break;
    //        case 3:
    //            //TODO Submit Item Form
    //            break;
    //    }
    //}

    performAction(action: any) {
        switch (action.actionName) {
            case "Save":
                this.saveBasicItemDefinition(action.createdFormStatusID, action.actionID);
                break;
            case "Delete":
                this.deleteItemForm();
                break;
            case "Submit":
             //   this.saveBasicItemDefinition(action.createdFormStatusID, action.actionID);
                break;
        }
    }

    public saveBasicItemDefinition(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            console.log(res);
            //if(res){
            //    this.handleItemValidations();
            //  //  this.getBasicItemDefinitionData();
            //}

        });
    }

    saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
        if (this.skipSaveTab || this.isReadOnly) return of(true);
        this.PopulateBasicItemDefinitionDTO();
        this.errors = [];     
        console.log('Save Submitted!');
        
        //if createdFormStatusID is 0 (when changing tab) , send the currentstatus .
        createdFormStatusID = createdFormStatusID == undefined ? this.newItemFormService.formCurrentStatusID : createdFormStatusID;
        this.basicItemDefinitionDto.formStatusID = createdFormStatusID;
        this.basicItemDefinitionDto.formActionID = actionID;
        this.basicItemDefinitionDto.formTypeID = this.newItemFormService.formTypeID;

        if(this.newItemFormService.formTypeID != 2)
            this.basicItemDefinitionDto.itemCode = null;
     
        this.basicItemDefinitionDto.addtionalGtinList = this.additionalGtinRows;
        if (this.basicItemDefinitionDto.addtionalGtinList != undefined) {
            for (let additionalGtin of this.basicItemDefinitionDto.addtionalGtinList) {
                additionalGtin.createdBy = this.userId;           
            }
        }
        //Get the user dropdown selection data
        this.getBasicItemDefDropdownSelectionData();

        const saveSuccess$: Subject<boolean> = new Subject<boolean>();
        this.validateMappedGTINRetailPack(this.basicItemDefinitionDto).subscribe(
            (res => {
                console.log(res+ " ValidateMappedGTIN");
                if(res){
                   this.saveApi(this.basicItemDefinitionDto, createdFormStatusID , actionID).subscribe(res => {
                       if(res){
                        saveSuccess$.next(true);
                        saveSuccess$.complete();
                       }
                       else {
                        saveSuccess$.next(false);
                        saveSuccess$.complete();
                       }
                   });
                }
                else {
                    //this.resetBasicItemDef();
                    this.getBasicItemDefinitionData();
                    saveSuccess$.next(false);
                    saveSuccess$.complete();
                }
            })
        );
        return saveSuccess$;
    }
    saveApi(basicItemDefinition, createdFormStatusID: number, actionID: number ):Observable<boolean> {
       this.newItemFormService.showLoadingSpinner = true;
       return this.basicItemDefService.saveBasicItemDefinition(basicItemDefinition).pipe(
            map(res => {
                this.newItemFormService.showLoadingSpinner = false;
                this.newItemFormService.addItemValidation(res.validation);
                this.newItemFormService.formCurrentStatusID = createdFormStatusID;
                console.log('Changes Saved Successfully');
                //Storing the itemFormDisplayID and GTIn fields in the service 
                //var gtinHeaderDto = this.populateGtinHeaderDto();
                //this.newItemFormService.setItemFormDisplayID(this.itemFormDto.itemFormDisplayID, null);
                //this.newItemFormService.setGtinHeaderDetails(gtinHeaderDto);
               this.newItemFormService.setBIDData(basicItemDefinition);


               if (actionID)
                   this.getBasicItemDefinitionData();

                return true;
            }),
            catchError((err) => {
                if (err.status === 400) {
                    this.newItemFormService.showLoadingSpinner = false;
                    // handle validation error
                    this.newItemFormService.addItemValidation(err.error);
                    this.handleItemValidations();
                    //let validationErrorDictionary = err.error;
                    //let validationErrorDictionary = err.error.modelState;
                    //this.handleBasicItemDefValidations(validationErrorDictionary);

                } else {
                    this.errors.push("Unhandled expection occured.");
                }

                window.scrollTo(0, 0);
                return of(false);
            })
        );
    }
    private getBasicItemDefDropdownSelectionData(): void {

        if (this.basicItemDefinitionDto.itemTypeCode != undefined && this.itemTypesList) {
            let itemType: ILookupDto = this.itemTypesList.find(x => x.code == this.basicItemDefinitionDto.itemTypeCode);
            if (itemType != undefined)
                this.basicItemDefinitionDto.itemTypeDescription = itemType.description;
        }

        if (this.basicItemDefinitionDto.retailPackType != undefined && this.retailPackTypesList) {
            let retailPackType: ILookupDto = this.retailPackTypesList.find(x => x.code == this.basicItemDefinitionDto.retailPackType);
            if (retailPackType != undefined)
                this.basicItemDefinitionDto.retailPackTypeDescription = retailPackType.description;
        }

        if (this.basicItemDefinitionDto.sizeUOM != undefined && this.sizeUomList) {
            let sizeUOM: ILookupDto = this.sizeUomList.find(x => x.code == this.basicItemDefinitionDto.sizeUOM);
            if (sizeUOM != undefined)
                this.basicItemDefinitionDto.sizeUOMDescription = sizeUOM.description;
        }
       

    }

    private validateMappedGTINRetailPack(basicItemDefinition: IBasicItemDefnitionDto): Observable<boolean> {
        const gtinList: string[] = [basicItemDefinition.formattedGtin, ...basicItemDefinition.addtionalGtinList.map(a => a.formattedGtin)];
        let gtinNotMappedList: string[] = [];
        let phNotFoundList: number[] = [];
        for (var gtin of this.nutritionalPanelMappedGTINList) {
            const gtinFound = gtinList.find(item => {
                return item == gtin.formattedGtin;
            });
            if (!gtinFound) {
                gtinNotMappedList.push(gtin.formattedGtin.replace(/-/g, ""));
            }
        }


        for (var ph of this.existingPackagingHierarchies) {

            //first check if primary retail pack matches , if not check if any of the additional retail packs matches. If nothing matches ,
            ///add it toolbar the phNotFoundList.
            console.log("retailPackType: " + basicItemDefinition.retailPackType+ ph.retailPackType+ (basicItemDefinition.retailPackType == ph.retailPackType));
            console.log("retailPackSize: " + +basicItemDefinition.retailPackSize+ +ph.retailPackSize+ (basicItemDefinition.retailPackSize == ph.retailPackSize));
            console.log("labelAmount: " + +basicItemDefinition.labelAmount+ +ph.labelAmount+ (basicItemDefinition.labelAmount == ph.labelAmount));
            console.log("size: " + basicItemDefinition.size+ ph.size+ (basicItemDefinition.size == ph.size));
            console.log("sizeUOM: " + basicItemDefinition.sizeUOM+ ph.sizeUOM+ (basicItemDefinition.sizeUOM == ph.sizeUOM));
            let bidSize = '';
            let phSize = '';
            if(basicItemDefinition.size){
                bidSize = basicItemDefinition.size.toString();
            }
            if(ph.size){
                phSize = ph.size.toString();
            }
            console.log("size: " + bidSize+ phSize + (phSize == bidSize));
            if (!(basicItemDefinition.retailPackType == ph.retailPackType && basicItemDefinition.retailPackSize == ph.retailPackSize
                && basicItemDefinition.labelAmount == ph.labelAmount && bidSize == phSize
                && basicItemDefinition.sizeUOM == ph.sizeUOM)) {
                let matchingPh = basicItemDefinition.addtionalGtinList.find(item => {
                    let itemSize = '';
                    if(item.size){
                        itemSize = item.size.toString();
                    }
                    return item.retailPackType == ph.retailPackType && item.retailPackSize == ph.retailPackSize
                        && item.labelAmount == ph.labelAmount && itemSize == phSize && item.sizeUOM == ph.sizeUOM
                });

                if (!matchingPh)
                    phNotFoundList.push(ph.id);

            }
        }


        if ((gtinNotMappedList.length > 0) || (phNotFoundList.length > 0)) {

            let desc: string ='';
            if (gtinNotMappedList.length > 0)
                desc = this.showMessage("BID48");
            if (phNotFoundList.length > 0)
                desc = desc + '\n' + this.showMessage("BID49"); //"Retail Packs have been modified or deleted. Corresponding Packaging Hierarchies will be deleted. "

            let data = {
                title: "",
                description: desc + '\n' +"Please click 'Ok' to continue or 'Cancel' to revert the current changes?",
                actions: [
                    "Cancel",
                    "Ok"
                ]
            }
            let dialog = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            return dialog.afterClosed().pipe(
                map(option => {
                    if (option && option.action == "Ok") {
                        const gtinRetailPackInfo: IGTINRetailPackInfoDto = {
                            nutritionalPanelGTINList: gtinNotMappedList,
                            packagingHierarchiesList: phNotFoundList,
                            itemFormID: this.newItemFormService.itemFormID
                        }
                        this.basicItemDefService.removeGTINRetailPackRelatedInfo(gtinRetailPackInfo).subscribe(res => {
                            console.log("removeGTINRetailPackRelatedInfo " + res);
                        })
                        return true;
                    }
                    return false;
                })
            );
        }
        else {
            return of(true);
        }

    }
    // public populateGtinHeaderDto(): GtinDto {
    //     let gtinDto: GtinDto = new GtinDto();
    //     gtinDto.formattedGtin = this.basicItemDefinitionDto.formattedGtin;
    //     gtinDto.gtinCheckDigit = this.basicItemDefinitionDto.gtinCheckDigit;
    //     gtinDto.compressedUPC = this.basicItemDefinitionDto.compressedUPC;
    //     gtinDto.priceLookupCode = this.basicItemDefinitionDto.priceLookupCode;
    //     gtinDto.itemCode = this.basicItemDefinitionDto.itemCode;
    //     gtinDto.itemDescription = this.basicItemDefinitionDto.vendorItemDescription;
    //     gtinDto.modelProductItemcode = this.basicItemDefinitionDto.modelProductItemCode;
    //     gtinDto.modelPackagingItemCode = this.basicItemDefinitionDto.modelPackagingItemCode;
    //     gtinDto.modelItemDescription = this.basicItemDefinitionDto.modelProductItemDescription;

    //     return gtinDto;
    // }

   

    deleteItemForm() {

        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.newItemFormService.deleteItemForm().subscribe(res => {
                    if (res != undefined) {
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" });
                },
                    (err) => {
                        if (err.status === 400) {
                            // handle validation error
                            //  let validationErrorDictionary = err.error.modelState;
                            this.handleBasicItemDefValidations(err.error);
                        } else {
                            this.errors.push("Unhandled expection occured.");
                        }
                        window.scrollTo(0, 0);
                    })
                // TO DO: re-direct to dashboard to start the flow of New or existing item form
               
               
            }
        });
    }

    OpenModeledItemDetails() {
        let modeledItemCode = this.buyerBIDFormStaticGroup.get("modelProductItemCode").value;
        //let CurrentItemTypeDto:ItemTypeDto = this.itemTypesList.find(item => item.code === this.buyerBIDDynamicFormGroup.get("itemTypes").value);
            let itemtypecode =this.buyerBIDDynamicFormGroup.get("itemTypes").value;

        this.basicItemDefService.getModelProductItemValues(this.newItemFormService.itemFormID).subscribe(res => {
            console.log(res);            
            let selectedfileds: Element[] = [];
            let dialogRef = this.dialog.open(DialogModeledItemdetailComponent, {
                width: '800px',
                data: { ModelProductDetails: res, SelectedFileds: selectedfileds,IsRetail : itemtypecode == "RI" || itemtypecode == "FS" }
            });

            dialogRef.afterClosed().subscribe(result => {
                console.log('The dialog was closed');
                console.log(result); 
                if(result != undefined) 
                {                             
                this.buyerBasicItemDetailGroup.patchValue({
                    itemDescription: result.SelectedFileds.some(field => field.name == "Item Description") ? result.SelectedFileds.find(field => field.name == "Item Description").value : this.basicItemDefinitionDto.itemDescription,
                    receiptDescription: result.SelectedFileds.some(field => field.name == "Receipt Description") ? result.SelectedFileds.find(field => field.name == "Receipt Description").value : this.basicItemDefinitionDto.receiptDescription,
                    scaleDescription1: result.SelectedFileds.some(field => field.name == "Scale Description1") ?  result.SelectedFileds.find(field => field.name == "Scale Description1").value : this.basicItemDefinitionDto.scaleDescription1,
                    scaleDescription2: result.SelectedFileds.some(field => field.name == "Scale Description2")   ? result.SelectedFileds.find(field => field.name == "Scale Description2").value: this.basicItemDefinitionDto.scaleDescription2,
                    adDescription: result.SelectedFileds.some(field => field.name == "Ad Description")   ? result.SelectedFileds.find(field => field.name == "Ad Description").value : this.basicItemDefinitionDto.adDescription,
                    productCatalogShortDescription1: result.SelectedFileds.some(field => field.name == "ProductCatalog ShortDescription1")   ? result.SelectedFileds.find(field => field.name == "ProductCatalog ShortDescription1").value : this.basicItemDefinitionDto.productCatalogShortDescription1,
                    productCatalogShortDescription2: result.SelectedFileds.some(field => field.name == "ProductCatalog ShortDescription2")   ? result.SelectedFileds.find(field => field.name == "ProductCatalog ShortDescription1").value : this.basicItemDefinitionDto.productCatalogShortDescription2,                    
                    brand: result.SelectedFileds.some(field => field.name == "Brand")   ? result.SelectedFileds.find(field => field.name == "Brand").value : this.basicItemDefinitionDto.brand,
                    manufacturer: result.SelectedFileds.some(field => field.name == "Manufacturer")   ? result.SelectedFileds.find(field => field.name == "Manufacturer").value : this.basicItemDefinitionDto.manufacturer                    
                });
                }

            });

        });

    }

    


    
    public onItemDescriptionChange(): void {

        let selectedItemType = this.buyerBIDDynamicFormGroup.get('itemTypes').value;
        if (this.showAutoGenerateType4GTIN) {

            let autoGenerateType4GTIN = this.buyerBIDDynamicFormGroup.get('AutoGenerateType4GTIN').value;
            let itemDescription = this.buyerBasicItemDetailGroup.get('itemDescription').value;

            if (autoGenerateType4GTIN && itemDescription) {

                let itemDescriptionDto = new ItemDescriptionDto();
                itemDescriptionDto.itemTypeCode = selectedItemType;            
                itemDescriptionDto.description = itemDescription;
                this.basicItemDefService.getItemsMatchingDescription(itemDescriptionDto).subscribe(res => {
                    let itemDescriptionList: IItemDescriptionDto[] = res;

                    if (itemDescriptionList && itemDescriptionList.length > 0) {

                        let popupTitle: string;
                        popupTitle = 'Below are the matching existing item(s) for the selected Item type ' + this.basicItemDefinitionDto.itemTypeDescription ;                        
                        let data = {
                            title: popupTitle,
                            description:'Do you want to proceed with this Item description?',
                            actions: [
                                "No",
                                "Yes"
                            ],
                            itemDescriptionList: itemDescriptionList
                        };
                        let dialogRef = this.dialog.open(DialogItemDescriptionsComponent, {
                            width: '600px',
                            data: data
                        });

                        dialogRef.afterClosed().subscribe(result => {
                            if (result.action === "No") {
                                //this.buyerBasicItemDetailGroup.patchValue({
                                //    itemDescription: ''
                                //})
                                //TODO Set the focus
                            }
                           

                        });
                    }
                   
                })
               
                
            }
            
        }
       

    }


}
