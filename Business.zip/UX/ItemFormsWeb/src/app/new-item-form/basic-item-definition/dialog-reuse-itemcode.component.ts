
import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatTableDataSource,MatPaginatorModule,MatSort,MatPaginator } from '@angular/material';
import { IReuseItemCodeDto,ReuseItemCodeDto,IAdditionalGtinDto, AdditionalGtinDto } from './basic-item-definition-interface';
import { GridEvent } from '../../shared/grid/grid-event';

import { ILookupDto, LookupDto } from '../../shared/common.interface';
import { BasicItemDefinitionService } from './basic-item-definition.service';
import { DialogContentComponent } from './dialog-content.component';

@Component({
  selector: 'ifw-dialog-reuse-itemcode',
  templateUrl: './dialog-reuse-itemcode.component.html',
  styleUrls: ['./dialog-reuse-itemcode.component.scss']
})
export class DialogReuseItemcodeComponent implements OnInit {

  reuseItemCodeForm: FormGroup;
  reuseItemCodeList :  IReuseItemCodeDto[];
  reuseItemCodeDto: IReuseItemCodeDto
  public subDepartmentList: ILookupDto[];
  public IsAddReuseItemCodeAsAddtionalGTIN : boolean;
  public ItemFormID: number;

  // GRID
  public gridData: any[] =[];
  public pagination: boolean = false;
  public length: number;
  public pageSize: number = 5;
  public filterable: boolean = true;
  public filterBy: string = "";
  public filterValue: string = "";
  public sortable: boolean = true;
  public active: string = "";
  public direction: string = "";
  public ShowReuseItemCodeGrid = false;


  
  constructor(public dialogRef: MatDialogRef<DialogReuseItemcodeComponent>,
    private fb: FormBuilder,
    private basicItemDefService: BasicItemDefinitionService,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {        

     }    

  ngOnInit() {
    console.log('Popup Log');
    console.log(this.data.formId);
    console.log(this.data);
    this.IsAddReuseItemCodeAsAddtionalGTIN = this.data.AddReuseItemCodeAsAddtionalGTIN;
    this.ItemFormID = this.data.formId;
    this.pagination = true;
    //this.ShowReuseItemCodeGrid = false;

    this.reuseItemCodeForm = this.fb.group({
      subDepartment: ['', Validators.required],          
      reuseItemCodes:  ''     
  });

  

  this.basicItemDefService.getReuseItemSubDepartments().subscribe(res => {
    this.subDepartmentList = res;
    console.log(res);
    if(this.data.PreviousReuseItemCode.length > 0){
        this.basicItemDefService.IsReuseItemCodeExist(this.data.PreviousReuseItemCode).subscribe(result => {
            this.reuseItemCodeForm.patchValue({ subDepartment : result.subDeptCode.toString() });
            //this.reuseItemCodeForm = this.fb.group({subDepartment: 21})
            console.log(result.subDeptCode);
           this.onSubDepartmentChange(result.subDeptCode); 
        })
    }
})

      this.reuseItemCodeDto = new ReuseItemCodeDto()
  }


  getReuseItemCodes(gridEvent: GridEvent) {
    this.gridData = this.performFilter(gridEvent);
    this.sortData(gridEvent);
    this.pageData(gridEvent);
}

showMessage(code:string):string{
    let messageDesc:string = '';
    if(this.data.popUpMessages.some(error => error.errorCode == code))
    messageDesc = this.data.popUpMessages.find(error => error.errorCode == code).errorDescription
    return messageDesc;
}

performFilter(gridEvent: GridEvent): any[] {
    this.filterBy = gridEvent.filterBy;
    this.filterValue = gridEvent.filterValue;
    if (this.filterBy && this.filterBy.length > 0) {
        if (this.filterValue && this.filterValue.length > 0) {
            console.log(this.filterValue);
            return this.reuseItemCodeList.filter((row: any) => {
                // Transform the data into a lowercase string of property values.
                const dataStr = ('' + row[this.filterBy]).toLowerCase();
                // Transform the filter by converting it to lowercase and removing whitespace.
                const transformedFilter = this.filterValue.trim().toLowerCase();
                return dataStr.indexOf(transformedFilter) != -1;
            }
            );
        }
        return this.reuseItemCodeList.slice();
    }
    return this.reuseItemCodeList.slice();
}
/**
 * sort the filtered result based on sort column and order
 */
sortData(gridEvent: GridEvent) {
    this.active = gridEvent.active;
    this.direction = gridEvent.direction;
    let sortAsc = gridEvent.direction == 'asc';
    let sortDesc = gridEvent.direction == 'desc';
    if (!sortAsc && !sortDesc) return;
    this.gridData.sort((a, b) => {
        if (typeof a[gridEvent.active] === 'string') {
            return a[this.active].localeCompare(b[this.active]);
        } else {
            return a[this.active] - b[this.active];
        }
    });
    if (sortAsc === false) {
        this.gridData.reverse();
    }
}
/**
   * paginate the result set
   */
pageData(gridEvent: GridEvent) {
    if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
    this.length = this.gridData.length;
    let pageIndex = gridEvent.pageIndex;
    this.pageSize = gridEvent.pageSize;
    let offset = pageIndex * gridEvent.pageSize;
    this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
}

getInitialReuseItemCodes() {
    const gridEvent: GridEvent = {
        pageIndex: 0,
        pageSize: 5,
        length: 0,
        active: this.active,
        direction: this.direction,
        filterBy: this.filterBy,
        filterValue: this.filterValue
    };
    this.getReuseItemCodes(gridEvent);
}


  onSubDepartmentChange(subDepartment) {
    this.ShowReuseItemCodeGrid = true;
    this.reuseItemCodeDto.subDeptCode = subDepartment;
    this.basicItemDefService.getAvailableItemFormReuseItemCodesBySubDept(this.reuseItemCodeDto).subscribe(res => {
      this.reuseItemCodeList = res; 
      this.getInitialReuseItemCodes();
      })
     
  }
    

    ValidateAndSaveReuseItemCode(reuseItemCodeDto: ReuseItemCodeDto,optionToAddAddtionalGtin:boolean): void { 
        console.log(this.data);
        reuseItemCodeDto.itemFormID = this.ItemFormID;
        this.basicItemDefService.isSelectedReuseItemCodeAlreadyUsed(reuseItemCodeDto).subscribe(res => {
            if (!res.isAvailable) 
            this.showPopupValidateAndSaveReuseItemCode(res.validationErrors.errors[0].errorDescription);
            else  
                this.showPopupToAddReuseItemCode(reuseItemCodeDto);
        })


    }

    showPopupToAddReuseItemCode(reuseItemCodeDto:ReuseItemCodeDto){
        // BID 23 "Do you want to add the Reuse Item Code  "+ reuseItemCodeDto.itemCode + "  as Additional GTIN"
        let desc: string = "Do you want to add the Reuse Item Code  " + reuseItemCodeDto.itemCode + "  as Additional GTIN";
        if (this.data.IsEnteredPrimaryGTINType2)
            desc = "Do you want to add the Reuse Item Code  " + reuseItemCodeDto.itemCode + "  as Primary GTIN";
        let data = {           
            description: desc,
            options: [
                "Add",
                "Cancel"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '400px',
            data: data
        });
       
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            if (result.action === "Add"){
                if (this.data.IsEnteredPrimaryGTINType2) {
                this.basicItemDefService.saveReuseItemCode(reuseItemCodeDto).subscribe(res => {
                    if (res) {
                        console.log('Save Success');
                        console.log(res);
                        this.data = this.reuseItemCodeDto;
                        this.data.SelectedReuseItemCode = reuseItemCodeDto.itemCode;
                        this.data.AddReuseItemCodeAsAddtionalGTIN = false;
                        this.dialogRef.close(this.data);
                    }
                    else {
                        console.log('Save failure');
                        console.log(res);
                    }               
            })
        }
        else {
            this.data.SelectedReuseItemCode = reuseItemCodeDto.itemCode;
            this.data.AddReuseItemCodeAsAddtionalGTIN = true;
            this.dialogRef.close(this.data);
        }

            }                       
            else {
                // BID 24 "Please select some other reuse item code to add as addtional gtin"
                console.log(this.showMessage("BID24"));
            }
        });

    }

    showPopupValidateAndSaveReuseItemCode(resultMessage:string)
    {       
        let data = {                
            description: resultMessage,
            options: [
                "Ok"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '400px',
            data: data
        });
        
    }

    onSelectedReuseItemCode(reuseItemCodeDto:ReuseItemCodeDto)
    {
        console.log(reuseItemCodeDto);
        this.ValidateAndSaveReuseItemCode(reuseItemCodeDto,true);
    }

}
