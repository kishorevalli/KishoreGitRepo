﻿
import { Component, OnInit, Inject,EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { ILookupDto, LookupDto } from '../../shared/common.interface';
import { IAdditionalGtinDto, AdditionalGtinDto } from './basic-item-definition-interface';
import { BasicItemDefinitionService } from './basic-item-definition.service';
import { DialogContentComponent } from './dialog-content.component';
import { gtinValidator, GtinValidatorOptions, GTINValidatorHelper } from '../common/validators/gtin.validator'; 

@Component({
    selector: 'dialog-additional-gtin',
    templateUrl: './dialog-addtional-gtin.component.html',
    styleUrls: ['./dialog-addtional-gtin.component.scss']
})
export class DialogAdditionalGtinComponent implements OnInit{

    //Form control variables
    onAddEvent = new EventEmitter<IAdditionalGtinDto>();
    additionalGtinFormGroup: FormGroup;
    //gtinControlFormGroup: FormGroup;

    gtinHelper: GTINValidatorHelper;
    //public additionalGtinDto: IAdditionalGtinDto;
    //public additionalGtinList: IAdditionalGtinDto[];   
    //public parentAdditionalGtinList: IAdditionalGtinDto[];   

    //Lookup dropdownlist
    public retailPackTypesList: ILookupDto[];
    public sizeUomList: ILookupDto[];
    public isEdit: boolean = false;

    public isBuyer: boolean;
    public primaryGtin : string;
    
   

    constructor(public dialogRef: MatDialogRef<DialogAdditionalGtinComponent>,
        private formBuilder: FormBuilder,
        private basicItemDefService: BasicItemDefinitionService,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) {
                       

         }
    gtinValidatorOptions: GtinValidatorOptions =  {
            validateCheckDigit: true,
            range: true,
            type2: true,
            dummy: true,
            vendorCoupon: true
    }
    ngOnInit() {
        this.gtinHelper = new GTINValidatorHelper({});
        
        //this.additionalGtinDto = new AdditionalGtinDto();

        if (this.data.additionalGtinRow != undefined) {
            //this.additionalGtinDto = this.data.additionalGtinRow;
            this.additionalGtinFormGroup = this.formBuilder.group({
                rowId: this.data.additionalGtinRow.rowId,
                formattedGtin: [this.data.additionalGtinRow.formattedGtin,[gtinValidator({
                    validateCheckDigit: false,
                    range: false,
                    type2: false,
                    dummy: false,
                    vendorCoupon: false
                })]],
                gtinCheckDigit: this.data.additionalGtinRow.gtinCheckDigit,
                compressedUPC: [this.data.additionalGtinRow.compressedUPC,[Validators.minLength(6)]],
                priceLookupCode: [this.data.additionalGtinRow.priceLookupCode,[Validators.minLength(5)]],
                retailPackType: this.data.additionalGtinRow.retailPackType,
                size: this.data.additionalGtinRow.size,
                sizeUOM: this.data.additionalGtinRow.sizeUOM,
                retailPackSize: this.data.additionalGtinRow.retailPackSize,
                labelAmount: this.data.additionalGtinRow.labelAmount,
                nonDiscountable : this.data.additionalGtinRow.nonDiscountable,
                overrideReceiptDescription : this.data.additionalGtinRow.overrideReceiptDescription,
                existingGtinIndicator:this.data.additionalGtinRow.existingGtinIndicator     
            });
            this.isEdit = true;
            this.showHideControlsOnInit();
        }
        else
        {
            this.additionalGtinFormGroup = this.formBuilder.group({
                rowId: 0,
                formattedGtin: ['',[gtinValidator({
                    validateCheckDigit: false,
                    range: false,
                    type2: false,
                    dummy: false,
                    vendorCoupon: false
                })]],
                gtinCheckDigit: '',
                compressedUPC: ['',[Validators.minLength(6)]],
                priceLookupCode: ['',[Validators.minLength(4)]],
                retailPackType: '',
                size: '',
                sizeUOM: '',
                retailPackSize: '',
                labelAmount: '',
                nonDiscountable : '',
                overrideReceiptDescription : '',
                existingGtinIndicator:''    
            });
            this.isEdit = false;
        }

       
        this.isBuyer = this.data.isBuyer;

        console.log(this.data.showRetailPackTypePackSizeLabel);
      
        // this.additionalGtinList = [];     

        // this.parentAdditionalGtinList = [];

        // for (let additionalGtinDto of this.data.additionalGtinList) {
        //     this.parentAdditionalGtinList.push(additionalGtinDto);
        // }
        //this.data.additionalGtinList = [];

        this.basicItemDefService.getRetailPackTypes().subscribe(res => {
            this.retailPackTypesList = res;
        })

        this.basicItemDefService.getUnitOfMeasures().subscribe(res => {
            this.sizeUomList = res;
        })
    }
   /* specificGtinValidator(group: FormGroup) {
        let compressedUPC = this.additionalGtinDto ? this.additionalGtinDto.compressedUPC : null;
        let priceLookupCode = this.additionalGtinDto ? this.additionalGtinDto.priceLookupCode : null;
        var result = ValidateGtin.specificGtinValidatorFn(group, compressedUPC, priceLookupCode);
        if (result == -1 && group.dirty) {
            this.IsGTINExists();
            return;
        }
        return result;
        
    }*/
    public subscribeGTINValidations(isSubscribe:boolean) {
        const formattedGtin = this.additionalGtinFormGroup.controls.formattedGtin;
        if(isSubscribe){
            formattedGtin.setValidators([gtinValidator(this.gtinValidatorOptions)]);
        }
        else {
            formattedGtin.setValidators([]);
        }
        formattedGtin.updateValueAndValidity();
    }
    private showHideControlsOnInit(){
        // Disable GTINCheckDigit if there is a price look up value.
        if (this.additionalGtinFormGroup.get("priceLookupCode").value) {
            this.additionalGtinFormGroup.get("gtinCheckDigit").disable();
        }     
    }
    IsGTINExists() {
        let gtin = this.additionalGtinFormGroup.get("formattedGtin").value.replace(/-/g, "");
        this.basicItemDefService.isGTINExists(+gtin).subscribe(res => {
            if (res.isGTINExist) {
                this.openGtinExitsDialog();
            }
            else {
                this.additionalGtinFormGroup.controls['existingGtinIndicator'].setValue('N');        
                //this.additionalGtinDto.existingGtinIndicator = "N";
            }
        });
    }
    public get checkDigitDisplay(): number {
        var formattedGtinControl = this.additionalGtinFormGroup.controls.formattedGtin;
        let gtin = formattedGtinControl.value;
        if(gtin && gtin.length == 15){
            return this.gtinHelper.getCheckdigit(gtin)
        }
        return null;
    }
    public FormatGtin(): void {
        this.clearCompUPCPLU({});// Fix if GTIN is copied instead keying in. Called the keypress event too
        var formattedGtinControl = this.additionalGtinFormGroup.get("formattedGtin");
        let gtin = formattedGtinControl.value;
        if (gtin.length > 7) {
           // this.additionalGtinDto.formattedGtin = this.gtinHelper.padGtin(this.additionalGtinDto.formattedGtin, 13);
           formattedGtinControl.patchValue(this.gtinHelper.padGtin(gtin,13));
            //this.subscribeGTINValidations(true);
            this.gtinValidationRules(this.isBuyer);
        }
        this.isGTINValid();
    }
    public changeGTINCheckdigit(): void {
        //let gtin = this.additionalGtinDto.formattedGtin;
        let gtin = this.additionalGtinFormGroup.controls.formattedGtin.value;      
        if(gtin.length > 7){
            this.additionalGtinFormGroup.controls.formattedGtin.markAsTouched({ onlySelf: true });
            //this.subscribeGTINValidations(true);
            this.gtinValidationRules(this.isBuyer);
        }
        this.isGTINValid();
    }
    public isGTINValid(){
        const formattedGtin = this.additionalGtinFormGroup.controls.formattedGtin;
        if(formattedGtin.status == "VALID"){
            console.log("IsGTINExists" + formattedGtin.value);
            this.IsGTINExists();
        }
    }
    private gtinValidationRules(isBuyer:boolean) {
        const formattedGtinControl = this.additionalGtinFormGroup.controls.formattedGtin;
        formattedGtinControl.setValidators([gtinValidator({
            validateCheckDigit: true,
            range: true,
            type2: !isBuyer,
            dummy: true,
            vendorCoupon: true
        })]);
        formattedGtinControl.updateValueAndValidity();
    }
    openGtinExitsDialog(): void {
        let data ={
            title: "",
            description: "GTIN entered already exists in the system.",
            actions:[ 
                "Ok"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
          width: '500px',
          data: data
        });
    
        dialogRef.afterClosed().subscribe(result => {
          //this.additionalGtinDto.existingGtinIndicator = "Y";
          this.additionalGtinFormGroup.controls['existingGtinIndicator'].setValue('Y');
        });
      }

    clearCompUPCPLU(e) {
        // Make the CompressedUPC empty if GTIN is manually updated or changed.
        // this.additionalGtinDto.compressedUPC = '';
        // this.additionalGtinDto.priceLookupCode = '';
        this.additionalGtinFormGroup.patchValue({
            "compressedUPC":'',
            "priceLookupCode":'',
            "gtinCheckDigit":''
        });
        this.additionalGtinFormGroup.get("gtinCheckDigit").enable();
    }
    public ConvertCompressedUPCToGTIN(newValue) {
        this.additionalGtinFormGroup.patchValue({
            "formattedGtin":'',
            "gtinCheckDigit": null,
            "priceLookupCode": ''
        });
        if (newValue && newValue.length == 6) {
            this.basicItemDefService.ConvertCompressedUPCToGTIN(newValue).subscribe(res => {   
                this.subscribeGTINValidations(false);
                this.additionalGtinFormGroup.patchValue({
                    "formattedGtin":res,
                    "gtinCheckDigit": this.gtinHelper.getCheckdigit(res),
                    "priceLookupCode": ''
                });
                this.additionalGtinFormGroup.get("gtinCheckDigit").enable();
                // this.additionalGtinDto.formattedGtin = res;
                // this.additionalGtinDto.gtinCheckDigit = this.gtinHelper.getCheckdigit(res);
                // this.additionalGtinDto.priceLookupCode = '';
                this.isGTINValid();
            });
        }
    }

    public ConvertPLUToGTIN(newValue) {
        this.additionalGtinFormGroup.patchValue({
            "formattedGtin":'',
            "gtinCheckDigit": null,
            "compressedUPC": ''
        });
        if (newValue && newValue.length == 5) {
            let newValueTwoChar: string = newValue.slice(0, 2);
            if(newValueTwoChar != "83" &&  newValueTwoChar != "84" && newValueTwoChar != "93" &&  newValueTwoChar != "94" ){
                this.additionalGtinFormGroup.controls["priceLookupCode"].setErrors({ notvalid: true });
                this.additionalGtinFormGroup.controls["priceLookupCode"].markAsTouched({ onlySelf: true });
                return;
            }
            this.basicItemDefService.ConvertPLUToGTIN(newValue).subscribe(res => {
                this.subscribeGTINValidations(false);
                this.additionalGtinFormGroup.patchValue({
                    "formattedGtin":res,
                    "gtinCheckDigit": null,
                    "compressedUPC": ''
                });
                this.additionalGtinFormGroup.get("gtinCheckDigit").disable();
                // this.additionalGtinDto.formattedGtin = res;
                // this.additionalGtinDto.gtinCheckDigit = this.gtinHelper.getCheckdigit(res);
                // this.additionalGtinDto.compressedUPC = '';
                this.isGTINValid();
            });
        }
    }
    getErrorMessage(control: FormControl, name: string){
        for (let propertyName in control.errors) {
            if (control.errors.hasOwnProperty(propertyName) && control.touched) {
              return this.getValidatorErrorMessage(propertyName, control.errors[propertyName]);
            }
          }          
          return null;
    }
    getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            'required': 'This field is required.',
            'email': 'This is not a valid email',
            'minlength': `This field should have atleast ${validatorValue.requiredLength} characters`,
            'beforePadding' : 'This field is required.',
            'range' : 'Invalid GTIN.',
            'type2' : "GTIN entered is reserved for type -2 GTIN's.",
            'dummy' : "GTIN entered is reserved for Dummy GTIN's.",
            'vendorCoupon': "GTIN entered is reserved for Vendor Coupons.",
            'checkDigitRequired':"GTIN Check digit is required to validate GTIN.",
            'checkDigit' : 'GTIN is not valid for the entered check digit.',
            'notvalid': 'This is not a valid data',
        };
        return config[validatorName];
    }
    /* Events */
    public onCancel(): void {
        this.dialogRef.close();
    }

    private CheckGTINExistInCurrentForm(GTIN:string):boolean {
                
        if(this.data.additionalGtinList.some(r => r.formattedGtin.toString() == GTIN))
            return true;
        else if(this.data.primaryGtin == GTIN)
            return true;
        return false;
        }

    public onAdd(): void {
        if(this.additionalGtinFormGroup.invalid){
            return this.showErrors();
        }
        let additionalGTIN: IAdditionalGtinDto = (<any>Object).assign({}, this.additionalGtinFormGroup.value);
        if(this.CheckGTINExistInCurrentForm(additionalGTIN.formattedGtin)){
            let data = {description: "GTIN Already exist cannot add the addtional GTIN",options: ["Ok"]}
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '400px',
                data: data
            });
            console.log("GTIN Already exist cannot add the addtional GTIN");            
        }
                   
        else {
            this.getAdditionalGtinDropdownSelectionData(additionalGTIN);        
            this.dialogRef.close(additionalGTIN);
        }
    
    }
    public onAddContinue(): void {
        if(this.additionalGtinFormGroup.invalid){
            return this.showErrors();
        } 
        let additionalGTIN: IAdditionalGtinDto = (<any>Object).assign({}, this.additionalGtinFormGroup.value);
        
        if(this.CheckGTINExistInCurrentForm(additionalGTIN.formattedGtin))
        {
            let data = {description: "GTIN Already exist cannot add the addtional GTIN",options: ["Ok"]}
        let dialogRef = this.dialog.open(DialogContentComponent, {
            disableClose: true,
            width: '400px',
            data: data
        });
        console.log("GTIN Already exist cannot add the addtional GTIN"); 
        }
        else {
        this.getAdditionalGtinDropdownSelectionData(additionalGTIN);        
        this.onAddEvent.emit(additionalGTIN);
        this.additionalGtinFormGroup.reset();
        }
    }

    public onSave(): void {
        if(this.additionalGtinFormGroup.invalid){
            return this.showErrors();
        } 
        let additionalGTIN: IAdditionalGtinDto = (<any>Object).assign({}, this.additionalGtinFormGroup.value);
        this.getAdditionalGtinDropdownSelectionData(additionalGTIN);
        //this.data.additionalGtinRow = this.additionalGtinDto;
        this.dialogRef.close(additionalGTIN);
    }
    private showErrors(): void {
        Object.keys(this.additionalGtinFormGroup.controls).forEach(field => { 
            const control = this.additionalGtinFormGroup.get(field);           
            control.markAsTouched({ onlySelf: true });      
          });
          return;
    } 
    // private getAdditionalGtinDropdownSelectionData_Old(): void {        

    //     if (this.additionalGtinDto.retailPackType != undefined) {
    //         this.additionalGtinDto.retailPackTypeDescription = this.retailPackTypesList.find(x => x.code == this.additionalGtinDto.retailPackType).description;
    //     }

    //     if (this.additionalGtinDto.sizeUOM != undefined) {
    //         console.log(this.additionalGtinDto.sizeUOM);
            
    //         this.additionalGtinDto.sizeUOMDescription = this.sizeUomList.find(x => x.code == this.additionalGtinDto.sizeUOM).description;
    //     }

    // }
    private getAdditionalGtinDropdownSelectionData(additionalGTIN: IAdditionalGtinDto): void {        
        
                if (additionalGTIN.retailPackType && this.retailPackTypesList) {
                    const retailPackLookupDto = this.retailPackTypesList.find(x => x.code == additionalGTIN.retailPackType);
                    additionalGTIN.retailPackTypeDescription = (retailPackLookupDto)? retailPackLookupDto.description : additionalGTIN.retailPackType;
                }
        
                if (additionalGTIN.sizeUOM && this.sizeUomList) {
                    const sizeUOMLookupDto = this.sizeUomList.find(x => x.code == additionalGTIN.sizeUOM);
                    additionalGTIN.sizeUOMDescription = (sizeUOMLookupDto)?sizeUOMLookupDto.description : additionalGTIN.sizeUOM;
                }
        
    }


    public onRetailPackTypeChange(val: string) {

        this.additionalGtinFormGroup.patchValue({
            "labelAmount": null
        });
    }
    //public isPrePack(val: string): boolean {
    //    if (val.trim() === "P")
    //        return true;
    //    else
    //        return false;
    //}

}