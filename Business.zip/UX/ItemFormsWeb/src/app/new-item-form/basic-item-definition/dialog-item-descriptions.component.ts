﻿
import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatPaginatorModule, MatSort, MatPaginator } from '@angular/material';

import { IItemDescriptionDto, ItemDescriptionDto } from './basic-item-definition-interface';
import { BasicItemDefinitionService } from './basic-item-definition.service';
import { GridEvent } from '../../shared/grid/grid-event';

@Component({
    selector: 'ifw-dialog-item-descriptions',
    templateUrl: './dialog-item-descriptions.component.html',
    styleUrls: ['./dialog-item-descriptions.component.scss']
})
export class DialogItemDescriptionsComponent implements OnInit {   


    public itemDescriptionList: IItemDescriptionDto[];   
    // GRID
    public gridData: any[] = [];
    public pagination: boolean = true;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = false;
    public filterBy: string = "";
    public filterValue: string = "";
    public sortable: boolean = false;
    public active: string = "";
    public direction: string = "";


    constructor(public dialogRef: MatDialogRef<DialogItemDescriptionsComponent>,
        private formBuilder: FormBuilder,
        private basicItemDefService: BasicItemDefinitionService,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) {


    }
  
    ngOnInit() {
        
        this.itemDescriptionList = this.data.itemDescriptionList;       

        //if (this.data.itemDescriptionList && this.data.itemDescriptionList.length > 10) {
        //    this.pagination = true;
        //}
        //else {
        //    this.pagination = false;
        //}
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getItemDescriptions(gridEvent);
        
    }

    getItemDescriptions(gridEvent: GridEvent) {
        this.gridData = this.data.itemDescriptionList;
        //if (this.pagination)
            this.pageData(gridEvent);

    }


    pageData(gridEvent: GridEvent) {
        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

   
    public confirmSelection(action: string): void {

        if (action)
            this.data.action = action;
        this.dialogRef.close(this.data);
    }

}