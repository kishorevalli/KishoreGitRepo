﻿import { IItemFormDto, ItemFormDto, UserType } from '../new-item-form.interface';
import { IItemValidationDTO,ItemValidationDTO } from '../../shared/common.interface';

export interface IBasicItemDefnitionDto {
    itemFormID: number;
    itemFormDisplayId: number;
    itemTypeCode: string;
    itemTypeDescription: string;
    formattedGtin: string;
    gtinCheckDigit: number;
    existingGtinIndicator: string;
    compressedUPC: string;
    priceLookupCode: string;
    reuseItemCode: number;
    submissionReasonID: number;
    itemCaseTypeID: number;
    recipeRequired: string;
    ingredientItemRequired: string;
    modelProductItemCode: number;
    modelProductItemDescription: string;
    modelProductItemTypeCode:string;
    modelPackagingItemCode: number;
    modelPackagingItemDescription: string;
    modelPackagingItemTypeCode:string;
    vendorItemCode: string;
    vendorItemDescription: string;
    itemDescription: string;
    brand: string;
    manufacturer: string;
    retailPackagedItem: string;
    retailPackType: string;
    retailPackTypeDescription: string;
    retailPackSize: number;
    size: number;
    sizeUOM: string;
    sizeUOMDescription: string;
    minorityManufacturer: string;
    packageDescription: string;
    containerType: string;
    labelAmount: number;
    perpetualInventoryFlag: string;
    receiptDescription: string;
    adDescription: string;
    productCatalogShortDescription1: string;
    productCatalogShortDescription2: string;
    nonDiscountable: string;
    additionalGTINPresent: string;
    createdBy: string;
    lastUpdatedBy: string;
    lastScanDate: string;
    backroomScaleIndicator : string;
    autoGenerateType4GTIN : string;
    
    addtionalGtinList: IAdditionalGtinDto[];
    isStandardCaseOrShipperCase : string
    scaleDescription1 : string
    scaleDescription2 : string
    formTypeID: number;
    formStatusID: number;
    formActionID: number;
    submittedUserTypeID: UserType;
    itemCode?: number;
    vendorContactID: string;
    isBrandChanged : boolean;
    isManufacturerChanged: boolean;
    shipperFlag: string;
}

export class BasicItemDefnitionDto implements IBasicItemDefnitionDto {
    itemFormID: number;
    itemFormDisplayId: number;
    itemTypeCode: string;
    itemTypeDescription: string;
    formattedGtin: string;
    gtinCheckDigit: number;
    existingGtinIndicator: string;
    compressedUPC: string;
    priceLookupCode: string;
    reuseItemCode: number;
    submissionReasonID: number;
    itemCaseTypeID: number;
    recipeRequired: string;
    ingredientItemRequired: string;
    modelProductItemCode: number;
    modelProductItemDescription: string;
    modelProductItemTypeCode:string;
    modelPackagingItemCode: number;
    modelPackagingItemDescription: string;
    modelPackagingItemTypeCode:string;
    vendorItemCode: string;
    vendorItemDescription: string;
    itemDescription: string;
    brand: string;
    manufacturer: string;
    retailPackagedItem: string;
    retailPackType: string;
    retailPackTypeDescription: string;
    retailPackSize: number;
    size: number;
    sizeUOM: string;
    sizeUOMDescription: string;
    minorityManufacturer: string;
    packageDescription: string;
    containerType: string;
    labelAmount: number;
    perpetualInventoryFlag: string;
    receiptDescription: string;
    backroomScaleIndicator : string;
    adDescription: string;
    productCatalogShortDescription1: string;
    productCatalogShortDescription2: string;
    nonDiscountable: string;
    additionalGTINPresent: string;
    createdBy: string;
    lastUpdatedBy: string;
    lastScanDate: string;
    autoGenerateType4GTIN : string;
    isStandardCaseOrShipperCase : string
    scaleDescription1 : string
    scaleDescription2 : string

    addtionalGtinList: IAdditionalGtinDto[];
    formTypeID: number;
    formStatusID: number;
    formActionID: number;
    submittedUserTypeID: UserType;
    itemCode?: number;
    vendorContactID: string;
    isBrandChanged : boolean;
    isManufacturerChanged: boolean;
    shipperFlag: string;
}

export interface IAdditionalGtinDto {
    id?: number;
    rowId: number;
    itemFormID: number;
    formattedGtin: string;
    gtinCheckDigit?: number;
    existingGtinIndicator?: string;
    compressedUPC?: string;
    priceLookupCode: string;    
    overrideReceiptDescription?: string;
    retailPackType: string;
    retailPackTypeDescription?: string;
    retailPackSize: number;
    size: number;
    sizeUOM: string;
    sizeUOMDescription: string;
    labelAmount: number;
    nonDiscountable?: string;
    createdBy?: string;
    createdDate?: string;
    lastUpdatedBy?: string;
    lastUpdatedDate?: string;
}

export class AdditionalGtinDto implements IAdditionalGtinDto {
    id?: number;
    rowId: number;
    itemFormID: number;
    formattedGtin: string;
    gtinCheckDigit?: number;
    existingGtinIndicator: string;
    compressedUPC?: string;
    priceLookupCode: string;
    overrideReceiptDescription?: string;
    retailPackType: string;
    retailPackTypeDescription?: string;
    retailPackSize: number;
    size: number;
    sizeUOM: string;
    sizeUOMDescription: string;
    labelAmount: number;
    nonDiscountable?: string;
    createdBy?: string;
    createdDate?: string;
    lastUpdatedBy?: string;
    lastUpdatedDate?: string;
}

export interface IItemTypeDto {
    code: string;
    description: string;
    subtypeIndicator: string;
}

export class ItemTypeDto implements IItemTypeDto {
    code: string;
    description: string;
    subtypeIndicator: string;
}

export interface IReuseItemCodeDto {
    itemCode: number;
    itemDescription: string;
    subDeptCode : number;
    itemFormID?: number;
     isAvailable?:boolean;
     validationErrors:ItemValidationDTO;
    createdBy: string; 
    lastUpdatedBy: string;
}

export class ReuseItemCodeDto implements IReuseItemCodeDto {
    itemCode: number;
    itemDescription: string;
    subDeptCode : number;
    itemFormID?: number;
    isAvailable?:boolean;
    validationErrors:ItemValidationDTO;
    createdBy: string;
    lastUpdatedBy: string;    
}

export interface IModelProductItemValueDto {
    itemFormID: number;
    brand: string;
    manufacturer: string;
    itemDescription: string;
    receiptDescription: string;
    scaleDescription1: string;
    scaleDescription2: string;
    adDescription: string;
    productCatalogShortDescription1: string;
    productCatalogShortDescription2: string;    
    createdBy: string;
    lastUpdatedBy: string;
}

export class ModelProductItemValueDto implements IModelProductItemValueDto {
    itemFormID: number;
    brand: string;
    manufacturer: string;
    itemDescription: string;
    receiptDescription: string;
    scaleDescription1: string;
    scaleDescription2: string;
    adDescription: string;
    productCatalogShortDescription1: string;
    productCatalogShortDescription2: string;
    createdBy: string;
    lastUpdatedBy: string;
}

export class PMDSGTINDto implements IPMDSGTINDto{
    isGTINExist: boolean;
    GTIN:number;
    CheckDigit:number;
    GTINTypeCode:string;
    GTINTypeDescription:string;
    CategoryOfGTIN:string
    lastScanDate:Date
}

export class IPMDSGTINDto{
    isGTINExist: boolean;
    GTIN:number;
    CheckDigit:number;
    GTINTypeCode:string;
    GTINTypeDescription:string;
    CategoryOfGTIN:string
    lastScanDate:Date
}


export interface IItemDescriptionDto {    
    code: string;
    description: string;
    itemTypeCode: string;
    itemTypeDescription: string;
}

export class ItemDescriptionDto implements IItemDescriptionDto{
    code: string;
    description: string;
    itemTypeCode: string;
    itemTypeDescription: string;
}

export interface IGTINRetailPackInfoDto{
    nutritionalPanelGTINList: string[];
    packagingHierarchiesList: number[];
    itemFormID: number;

}
export class GTINRetailPackInfoDto implements IGTINRetailPackInfoDto{
    nutritionalPanelGTINList: string[];
    packagingHierarchiesList: number[];
    itemFormID: number;
}


