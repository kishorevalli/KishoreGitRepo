import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import { ActivatedRoute, Params, Router } from '@angular/router';
import 'rxjs/add/operator/filter';
import { Subject } from 'rxjs/Subject';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';

import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto, IErrorDTO, ErrorDTO  } from '../../shared/common.interface';
import { IBasicItemDefnitionDto, BasicItemDefnitionDto, IAdditionalGtinDto, AdditionalGtinDto, IGTINRetailPackInfoDto } from './basic-item-definition-interface';
import { BasicItemDefinitionService } from './basic-item-definition.service';
import { IItemFormDto, ItemFormDto, UserType, IGTINWithCheckdigitDto, NewItemTab } from '../new-item-form.interface';

import { DialogAdditionalGtinComponent } from './dialog-addtional-gtin.component';
import { GridEvent } from '../../shared/grid/grid-event';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';

import { DialogContentComponent } from './dialog-content.component';
import { NewItemFormService } from '../new-item-form.service';
import { IGtinDto, GtinDto } from '../common/gtin-header/gtin.interface';
import { gtinValidator, GtinValidatorOptions, GTINValidatorHelper } from '../common/validators/gtin.validator'; 
import { IPackagingHierarchy } from '../packaging-hierarchy/packaging-hierarchy.interface';



@Component({
    selector: 'ifw-basic-item-definition-vendor',
    templateUrl: './basic-item-definition-vendor.component.html',
    styleUrls: ['./basic-item-definition-vendor.component.scss']
})
export class BasicItemDefinitionVendorComponent implements OnInit {

    userId: any;

    itemFormDisplayID: number;
    public itemFormID : number;
    private sub: any;
    //Form control variables
    vendorBasicItemDefFormGroup: FormGroup;
    //public variables
    popUpMessages: IErrorDTO[];
    errors: string[];
    formErrors: any;
    gtinHelper: GTINValidatorHelper;
    //public itemFormDto: IItemFormDto;
    public showItemDetails: boolean = false;
    skipSaveTab: boolean = false;
    private nutritionalPanelMappedGTINList: IGTINWithCheckdigitDto[] = [];

    //Lookup dropdownlist
    public submissionReasonsList: ILookupIntDto[];
    public itemCaseTypesList: ILookupIntDto[];
    public retailPackTypesList: ILookupDto[];
    public sizeUomList: ILookupDto[];
    private existingPackagingHierarchies: IPackagingHierarchy[] = [];
    showModelSpinner: boolean = false;
     
    //Grid
    public additionalGtinRows: IAdditionalGtinDto[];
    public data: IAdditionalGtinDto[] = [];
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = true;
    public filterBy: string = "";
    public filterValue: string = "";
    public sortable: boolean = true;
    public active: string = "";
    public direction: string = "";

    constructor(private _formBuilder: FormBuilder,
        private basicItemDefService: BasicItemDefinitionService,
        public dialog: MatDialog,
        private router: Router,
        private route: ActivatedRoute,
        public snackBar: MatSnackBar,
        private newItemFormService: NewItemFormService) {

    }

    gtinValidatorOptions: GtinValidatorOptions =  {
        validateCheckDigit: true,
        range: true,
        type2: true,
        dummy: true,
        vendorCoupon: true
    }
    ngOnInit() {
        this.gtinHelper = new GTINValidatorHelper({});
        this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        this.itemFormID = this.newItemFormService.itemFormID;
               
        //Form controls
        this.vendorBasicItemDefFormGroup = this._formBuilder.group({
            itemFormID: this.itemFormID,
            formattedGtin: ['',[gtinValidator({
                                                validateCheckDigit: false,
                                                range: false,
                                                type2: false,
                                                dummy: false,
                                                vendorCoupon: false
                                            })]],
            gtinCheckDigit: [''],
            existingGtinIndicator: '',
            compressedUPC: ['',[Validators.minLength(6)]],
            priceLookupCode: ['',[Validators.minLength(5)]],
            submissionReasonID: [1],
            itemCaseTypeID: [1],
            modelProductItemCode: [''],
            modelProductItemDescription: [''],
            modelPackagingItemCode: [''],
            retailPackagedItem: [''],
            additionalGTINPresent: ['N'],
            sizeUOM: [''],
            retailPackType: [''],
            vendorItemCode: [''],
            vendorItemDescription: [''],
            brand: [''],
            manufacturer: [''],
            size: [''],
            retailPackSize: [''],
            labelAmount: [''],
            minorityManufacturer: [''],
            packageDescription: [''],
            containerType: [''],
            taxExemptionVendorEmail: [''],
            taxExemptionPublixEmail: [''],
            formActionID: [''],
            formTypeID: 1,
            itemCode: [''],
            submittedUserTypeID: UserType.Vendor,
        });

        this.route.queryParams
            .filter(params => params.id)
            .subscribe(params => {
                //  console.log(params); //  {id: "PGVSA1", role: "VPMD_VENDORPORTAL_VENDORSUPERADMIN"}             
                this.userId = params.id;
            });

        //this.itemFormDto = new ItemFormDto();

        this.getDropdownListData();
        let errorDTO: IErrorDTO = new ErrorDTO();
        errorDTO.tabName = 'BasicItemDef';
        errorDTO.severityLevel = 'Message';
        this.newItemFormService.GetErrorMessagesByType(errorDTO).subscribe(res => {
            console.log("GetErrorMessagesByType" + res)
            this.popUpMessages = res;
            console.log(this.popUpMessages);
            //this.popUpMessages = res
        });
        this.getBasicItemDefinitionData();
        this.subscribePLUChanges();
        
        //Initialize
        
       // this.basicItemDefnitionDto = new BasicItemDefnitionDto();
        /*this.basicItemDefnitionDto.submissionReasonID = 1;
        this.basicItemDefnitionDto.itemCaseTypeID = 1;
        this.basicItemDefnitionDto.additionalGTINPresent = "N";
        this.basicItemDefnitionDto.createdBy = this.userId;
        this.basicItemDefnitionDto.lastUpdatedBy = this.userId;

        this.basicItemDefnitionDto.submittedUserTypeID = UserType.Vendor;
        this.basicItemDefnitionDto.formStatusID = 1;*/

        this.additionalGtinRows = [];       
               
        this.errors = [];
        this.formErrors = {};

     
    }


    private getDropdownListData(): void {

        this.basicItemDefService.getSubmissionReasons().subscribe(res => {
            this.submissionReasonsList = res.map(item => ({ code: Number(item.code), description: item.description }));
        });

        this.basicItemDefService.getItemCaseTypes().subscribe(res => {
            this.itemCaseTypesList = res.map(item => ({ code: Number(item.code), description: item.description }));
        });

        this.basicItemDefService.getRetailPackTypes().subscribe(res => {
            this.retailPackTypesList = res;
        });

        this.basicItemDefService.getUnitOfMeasures().subscribe(res => {
            this.sizeUomList = res;
        });

        this.basicItemDefService.GetNutritionalPanelGTIN(this.newItemFormService.itemFormID).subscribe(res => {
            this.nutritionalPanelMappedGTINList = res;
        });


        this.basicItemDefService.GetExistingPackagingHierarchies(this.newItemFormService.itemFormID).subscribe(res => {
            this.existingPackagingHierarchies = res;
        });

    }

    private getBasicItemDefinitionData() {
        if (this.itemFormDisplayID != undefined && this.itemFormDisplayID > 0) {
            this.basicItemDefService.getBasicItemDefinitionData(this.newItemFormService.itemFormID).subscribe(res => {
                if (res != undefined) {
                    this.populateBIDData(res);
                    if (this.vendorBasicItemDefFormGroup.get("itemCaseTypeID").value == "1")
                        this.EnableShipperItemComposition(false);
                    else
                        this.EnableShipperItemComposition(true);

                    this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {                     
                            const validations: any = this.newItemFormService.getItemValidation("Basic Item Definition");
                        if (validations) {
                            this.handleBasicItemDefValidations(validations);
                        }
                    });
                    //setTimeout(() => {
                    //    this.handleItemValidations();
                    //}, 100);
                }
            });
        }
    }
    private showMessage(code:string):string{
        let messageDesc:string = '';
        console.log(this.popUpMessages);
        if(this.popUpMessages.some(error => error.errorCode == code))
        messageDesc = this.popUpMessages.find(error => error.errorCode == code).errorDescription
        return messageDesc;
    }
    // Need to find a way to call saveItemDataByPmdsGTIN after the GTIN is valid
    /*specificGtinValidator(group: FormGroup) {
        let compressedUPC = this.basicItemDefnitionDto ? this.basicItemDefnitionDto.compressedUPC : null;
        let priceLookupCode = this.basicItemDefnitionDto ? this.basicItemDefnitionDto.priceLookupCode : null;
        var result = ValidateGtin.specificGtinValidatorFn(group, compressedUPC, priceLookupCode);
        if(result == -1 && group.dirty && !this.IsItemDataByGtin){
            this.saveItemDataByPmdsGTIN();
            return;
        }
        return result;
    }*/
    private saveItemDataByPmdsGTIN():void {
        //let gtin = this.vendorBasicItemDefFormGroup.get("formattedGtin").value.replace(/-/g, "");
        let basicItemDefinition = (<any>Object).assign({}, this.vendorBasicItemDefFormGroup.value);
       /* this.basicItemDefnitionDto.formattedGtin = this.vendorBasicItemDefFormGroup.get("formattedGtin").value;
        this.basicItemDefnitionDto.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
        this.basicItemDefnitionDto.itemFormID = this.newItemFormService.itemFormID;
        this.basicItemDefnitionDto.submittedUserTypeID = UserType.Vendor;
        this.basicItemDefnitionDto.lastUpdatedBy = this.userId;
        this.basicItemDefnitionDto.createdBy = this.userId;*/
        basicItemDefinition.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
        basicItemDefinition.submittedUserTypeID = UserType.Vendor;
        basicItemDefinition.lastUpdatedBy = this.userId;
        basicItemDefinition.createdBy = this.userId;
        basicItemDefinition.existingGtinIndicator = 'Y';
        basicItemDefinition.vendorContactID = this.newItemFormService.vendorContactID;
        this.showModelSpinner = true;
        this.basicItemDefService.saveItemDataByPmdsGTIN(basicItemDefinition).subscribe(res => {
            this.lastScanDateRules(res);
            //this.populateGtinHeaderDto();
            this.showModelSpinner = false;
        },
            (err) => {

                this.showModelSpinner = false;
            }
        );        
        this.showItemDetails = true;
        //get data and populate.
    }


    public saveItemDataByPmdsItemCode(itemId: any): void {

        if (itemId) {
            let basicItemDefinition = (<any>Object).assign({}, this.vendorBasicItemDefFormGroup.value);
            basicItemDefinition.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
            basicItemDefinition.submittedUserTypeID = UserType.Vendor;
            basicItemDefinition.lastUpdatedBy = this.userId; //NOT Used
            basicItemDefinition.createdBy = this.userId;
            basicItemDefinition.vendorContactID = this.newItemFormService.vendorContactID;
            basicItemDefinition.formStatusID = 1;
            this.showModelSpinner = true;
            this.basicItemDefService.saveItemDataByPmdsItemCode(basicItemDefinition).subscribe(res => {
                this.populateBIDData(res);
                this.showModelSpinner = false;
                // this.ShowItemDetails();           
            },
            (err) => {
                this.vendorBasicItemDefFormGroup.controls["modelProductItemCode"].setErrors({ notvalid: true });
                this.vendorBasicItemDefFormGroup.controls["modelProductItemCode"].markAsTouched({ onlySelf: true });
                this.showModelSpinner = false;
            });   
        }
               
     }

    public saveModelDataForPackagingHierarchy(itemCode: any): void {

        if (itemCode) {
            let basicItemDefinition = (<any>Object).assign({}, this.vendorBasicItemDefFormGroup.value);
            basicItemDefinition.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
            basicItemDefinition.submittedUserTypeID = UserType.Vendor;
            basicItemDefinition.lastUpdatedBy = this.userId; //NOT Used
            basicItemDefinition.createdBy = this.userId;
            basicItemDefinition.vendorContactID = this.newItemFormService.vendorContactID;
            basicItemDefinition.formStatusID = 1;
            this.showModelSpinner = true;
            this.basicItemDefService.saveModelDataForPackagingHierarchy(basicItemDefinition).subscribe(res => {
                this.showModelSpinner = false;
             //   this.populateBIDData(res);
                // this.ShowItemDetails();           
            },
                (err) => {
                    this.vendorBasicItemDefFormGroup.controls["modelPackagingItemCode"].setErrors({ notvalid: true });
                    this.vendorBasicItemDefFormGroup.controls["modelPackagingItemCode"].markAsTouched({ onlySelf: true });
                    this.showModelSpinner = false;
                });
        }

    }

    private lastScanDateRules(response: any){
      if(response){
        const lastScanDate = response.lastScanDate;
        const age = this.diffInyears(lastScanDate);
        if(age >= 2){
           this.openGtinExitsGT2Dialog(response);
        }
        else if(age === 0 || age === 1){
          this.openGtinExitsLT2Dialog(response);
        }
      }
      
    }

    private populateBIDData(response: any) {

        this.vendorBasicItemDefFormGroup.patchValue(response);
        this.newItemFormService.formTypeID = response.formTypeID;
        this.newItemFormService.formCurrentStatusID = response.formStatusID;
        //this.basicItemDefnitionDto = res;
        this.additionalGtinRows = response.addtionalGtinList || [];
        this.UpdateAdditionalGtinRowId();
        this.getInitialAdditionalGtinData();
        this.showItemDetails = true;
        this.showHideControlsOnInit();
        //this.populateGtinHeaderDto();
  //      this.itemFormDto.lastUpdatedBy = this.userId;
  
    }
    

    private showHideControlsOnInit(){
        // Disable GTINCheckDigit if there is a price look up value.
        if (this.vendorBasicItemDefFormGroup.get("priceLookupCode").value) {
            this.vendorBasicItemDefFormGroup.get("gtinCheckDigit").disable();
        }     
    }
    private openGtinExitsGT2Dialog(response: any): void {
        let data ={
            title: "",
            description: "Last scan date is greater than 2 years. Do you want to enter a New Item or Item Maintanence",
            options:[  
                "New Item",           
                "Item Maintanence"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
          disableClose: true,
          width: '800px',
          data: data
        });
    
        dialogRef.afterClosed().subscribe(result => {            
          this.populateBIDData(response);
            if (result && result.action == "New Item") {
                this.vendorBasicItemDefFormGroup.controls['formTypeID'].setValue(1);
                this.newItemFormService.formTypeID = 1;            
                this.newItemFormService.itemCode = null;
            //this.itemFormDto.formTypeID = 1;
          }
            else {
                this.vendorBasicItemDefFormGroup.controls['formTypeID'].setValue(2);
                this.newItemFormService.formTypeID = 2;
            //this.itemFormDto.formTypeID = 2;
          }
          this.vendorBasicItemDefFormGroup.controls['existingGtinIndicator'].setValue('Y');
          //this.basicItemDefinitionDto.existingGtinIndicator = "Y";
        });
    }

      private openGtinExitsLT2Dialog(response: any): void {
        let data ={
            title: "",
            description: "Item already exits. Do you want to continue as Item Maintanence?",
            actions:[               
                "Cancel",
                "Ok"
            ]
        }
        let dialogRef = this.dialog.open(DialogContentComponent, {
          disableClose: true,
          width: '800px',
          data: data
        });
    
        dialogRef.afterClosed().subscribe(result => { 
          if(result && result.action == "Ok"){                         
            this.populateBIDData(response);
              this.vendorBasicItemDefFormGroup.controls['formTypeID'].setValue(2);
              this.newItemFormService.formTypeID = 2;
            //this.itemFormDto.formTypeID = 2;                  
            this.vendorBasicItemDefFormGroup.controls['existingGtinIndicator'].setValue('Y');        
            //this.basicItemDefnitionDto.existingGtinIndicator = "Y";
          }
          else {             
              this.newItemFormService.itemCode = null;
            this.vendorBasicItemDefFormGroup.patchValue({
                "formattedGtin": "",
                "gtinCheckDigit": null
            });
          }
        });
      }

    private diffInyears(calcDate: string){
        var timeDiff = Math.abs(Date.now() - Date.parse(calcDate));
        const years = Math.floor((timeDiff / (1000 * 3600 * 24))/365);
        return years;
    }
    disableShipper:boolean = false;
    subscribePLUChanges() {
        const priceLookupCode = this.vendorBasicItemDefFormGroup.controls.priceLookupCode;
        // initialize value changes stream
        const changes$ = priceLookupCode.valueChanges;
        // subscribe to the stream
        changes$.subscribe(plu => {
            // Type 2 gtin
            if(plu){
                this.vendorBasicItemDefFormGroup.controls.itemCaseTypeID.setValue(1);
                //this.vendorBasicItemDefFormGroup.controls.itemCaseTypeID.disable();
                this.disableShipper = true;
            }
            else {
                //this.vendorBasicItemDefFormGroup.controls.itemCaseTypeID.enable();
                this.disableShipper = false;
            }
            
        });
    }
    isShipperDisabled(val:number){
        return (val == 2 && this.disableShipper);
    }
    public get checkDigitDisplay(): number {
        var formattedGtinControl = this.vendorBasicItemDefFormGroup.get("formattedGtin");
        let gtin = formattedGtinControl.value;
        if(gtin && gtin.length == 15){
            return this.gtinHelper.getCheckdigit(gtin)
        }
        return null;
    } 
    public FormatGtin(): void {
        this.clearCompUPCPLU({});// Fix if GTIN is copied instead keying in. Called the keypress event too 
        var formattedGtinControl = this.vendorBasicItemDefFormGroup.get("formattedGtin");
        let gtin = formattedGtinControl.value;
        if(gtin.length>7) {
            formattedGtinControl.patchValue(this.gtinHelper.padGtin(gtin,13));
            this.subscribeGTINValidations(true);
        }
        this.isGTINValid();
    }
    public changeGTINCheckdigit(): void {
        let gtin = this.vendorBasicItemDefFormGroup.controls.formattedGtin.value;   
        if(gtin.length > 7){
            this.vendorBasicItemDefFormGroup.controls.formattedGtin.markAsTouched({ onlySelf: true });
            this.subscribeGTINValidations(true);
        }
        this.isGTINValid();
    }
    public isGTINValid(){
        const formattedGtinControl = this.vendorBasicItemDefFormGroup.controls.formattedGtin;
        if(formattedGtinControl.status == "VALID"){
            console.log("saveItemDataByPmdsGTIN" + formattedGtinControl.value);
            this.saveItemDataByPmdsGTIN();

            if (this.vendorBasicItemDefFormGroup.get("itemCaseTypeID").value == "1")
                this.EnableShipperItemComposition(false);
            else
                this.EnableShipperItemComposition(true);
        }
    }

    public EnableShipperItemComposition(EnableSICLink) {
        let ShipperItemCompositionLink: NewItemTab = this.newItemFormService.links.find(x => x.link == 'shipper-item-composition');
        if (EnableSICLink)
            ShipperItemCompositionLink.disabled = false;
        else
            ShipperItemCompositionLink.disabled = true;
    }

    public onIsStandardOrShipperChange(IsStandardOrShipper) {
        if (IsStandardOrShipper == "1")
            this.EnableShipperItemComposition(false);
        else
            this.EnableShipperItemComposition(true);
    }

    public subscribeGTINValidations(isSubscribe:boolean) {
        const formattedGtin = this.vendorBasicItemDefFormGroup.controls.formattedGtin;
        if(isSubscribe){
            formattedGtin.setValidators([gtinValidator(this.gtinValidatorOptions)]);
        }
        else {
            formattedGtin.setValidators([]);
        }
        formattedGtin.updateValueAndValidity();
    }
    clearCompUPCPLU(e) { 
        //console.log("clearCompUPCPLU");
        // Make the CompressedUPC empty if GTIN is manually updated or changed.
        this.vendorBasicItemDefFormGroup.patchValue({
            "compressedUPC":'',
            "priceLookupCode":'',
            "gtinCheckDigit":''
        });
        this.vendorBasicItemDefFormGroup.get("gtinCheckDigit").enable();
    }

    private ShowItemDetails(): void {
        this.showItemDetails = true;
    }

    public ConvertCompressedUPCToGTIN(newValue) {
        this.vendorBasicItemDefFormGroup.patchValue({
            "formattedGtin":'',
            "gtinCheckDigit": null,
            "priceLookupCode": ''
        });
        if(newValue && newValue.length ==6) {
            this.basicItemDefService.ConvertCompressedUPCToGTIN(newValue).subscribe(res => {
                this.subscribeGTINValidations(false);
                // this.vendorBasicItemDefFormGroup.controls['formattedGtin'].setValue(res);
                // this.vendorBasicItemDefFormGroup.controls['gtinCheckDigit'].setValue(this.gtinHelper.getCheckdigit(res));
                // this.vendorBasicItemDefFormGroup.controls['priceLookupCode'].setValue('');
                this.vendorBasicItemDefFormGroup.patchValue({
                    "formattedGtin":res,
                    "gtinCheckDigit": this.gtinHelper.getCheckdigit(res),
                    "priceLookupCode": ''
                });
                this.vendorBasicItemDefFormGroup.get("gtinCheckDigit").enable();
                /*this.basicItemDefnitionDto.formattedGtin = res;
                this.basicItemDefnitionDto.gtinCheckDigit = this.gtinHelper.getCheckdigit(res);
                this.basicItemDefnitionDto.priceLookupCode = '';*/                
                this.isGTINValid();
            });
            //this.ShowItemDetails();
        }        
    }

    public ConvertPLUToGTIN(newValue) {        
        this.vendorBasicItemDefFormGroup.patchValue({
            "formattedGtin":'',
            "gtinCheckDigit": null,
            "compressedUPC": ''
        });
        if(newValue && newValue.length == 5) {
            let newValueTwoChar: string = newValue.slice(0, 2);
            if(newValueTwoChar != "83" &&  newValueTwoChar != "84" && newValueTwoChar != "93" &&  newValueTwoChar != "94" ){
                this.vendorBasicItemDefFormGroup.controls["priceLookupCode"].setErrors({ notvalid: true });
                this.vendorBasicItemDefFormGroup.controls["priceLookupCode"].markAsTouched({ onlySelf: true });
                return;
            }
            this.basicItemDefService.ConvertPLUToGTIN(newValue).subscribe(res => {
                this.subscribeGTINValidations(false);
                this.vendorBasicItemDefFormGroup.patchValue({
                    "formattedGtin":res,
                    "gtinCheckDigit": null,
                    "compressedUPC": ''
                });
                this.vendorBasicItemDefFormGroup.get("gtinCheckDigit").disable();
                this.isGTINValid();
            });
            //this.ShowItemDetails();
        }        
    }

    public deleteAddtionalGtin(rowId: number): void {

        var index = this.additionalGtinRows.findIndex(x => x.rowId == rowId);
        if (index > -1) {
            this.additionalGtinRows.splice(index, 1);
        }
        this.getInitialAdditionalGtinData();
    }

    public editAddtionalGtin(rowId: number): void {

        let additionalGtinRow: IAdditionalGtinDto = this.additionalGtinRows.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogAdditionalGtinComponent, {
            width: '800px',
            data: { additionalGtinList: this.additionalGtinRows, additionalGtinRow: additionalGtinRow, showRetailPackTypePackSizeLabel: this.vendorBasicItemDefFormGroup.get('retailPackagedItem').value == 'Y', isBuyer: false }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result && result.rowId) {
                this.additionalGtinRows.splice(result.rowId-1,1,result)
                this.getInitialAdditionalGtinData();
            }
            // if (result != undefined) {
            //     for (let additionalGtinDto of this.additionalGtinRows) {
            //         if (additionalGtinDto.formattedGtin == result.additionalGtinRow.formattedGtin) {
            //             additionalGtinDto = result.additionalGtinRow;
            //         }
            //     }
            //     this.getInitialAdditionalGtinData();
            // }
        });
    }

    public openDialog(): void {
        let dialogRef = this.dialog.open(DialogAdditionalGtinComponent, {
            width: '1000px',
            data: { additionalGtinList: this.additionalGtinRows, showRetailPackTypePackSizeLabel: this.vendorBasicItemDefFormGroup.get('retailPackagedItem').value == 'Y'  , isBuyer: false, primaryGtin : this.vendorBasicItemDefFormGroup.get('formattedGtin').value}
        });
        const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {
            
            this.additionalGtinRows.push(result);
            this.UpdateAdditionalGtinRowId();
            this.getInitialAdditionalGtinData();
          });
        dialogRef.afterClosed().subscribe(result => {
            sub.unsubscribe();
            console.log('The dialog was closed');
            console.log(result);
            if (result && result.formattedGtin) {
                // this.additionalGtinRows = (this.additionalGtinRows == undefined) ? [] : this.additionalGtinRows;
                // for (let additionalGtinDto of result.additionalGtinList) {
                //     this.additionalGtinRows.push(additionalGtinDto);
                // }
                this.additionalGtinRows.push(result);
                this.UpdateAdditionalGtinRowId();
            }
            this.getInitialAdditionalGtinData();
        });
    }

    private UpdateAdditionalGtinRowId() {
        let count: number = 1;
        if (this.additionalGtinRows != undefined) {
            for (let additionalGtin of this.additionalGtinRows) {
                additionalGtin.rowId = count++;
            }
        }
    }

    public IsItemPackedForRetailChanged(val:string): void {
        if (val == "Y") {
            this.vendorBasicItemDefFormGroup.controls['retailPackSize'].setValue(1);
            this.vendorBasicItemDefFormGroup.controls['retailPackType'].setValue("R");            
        }
        if (val == "N") {
            this.vendorBasicItemDefFormGroup.patchValue({
                "retailPackSize": null,
                "retailPackType": '',
                "labelAmount": null,
            });
            for(var additionalRow of this.additionalGtinRows){
                additionalRow.retailPackSize = null;
                additionalRow.retailPackType = '';
                additionalRow.retailPackTypeDescription = '';
                additionalRow.labelAmount = null;
            }
            // this.basicItemDefnitionDto.retailPackSize = null;
            // this.basicItemDefnitionDto.size = null;
            // this.basicItemDefnitionDto.sizeUOM = '';
            // this.basicItemDefnitionDto.retailPackType = '';
            // this.basicItemDefnitionDto.labelAmount = null;
        }
    }
    
  
    performAction(action: any) {
        switch (action.actionName) {
            case "Save":
                this.saveBasicItemDefinition(action.createdFormStatusID, action.actionID);
                break;
            case "Delete":
                this.deleteItemForm();
                break
            case "Submit":
                this.submitBasicItemDefinition(action.createdFormStatusID, action.actionID);
                break;
        }
    }


    public resetBasicItemDef(): void {
        this.resetToInitialState();
        this.basicItemDefService.getBasicItemDefinitionData(this.newItemFormService.itemFormID).subscribe(res => {
            if (res) {
                this.vendorBasicItemDefFormGroup.patchValue(res);
                //this.basicItemDefnitionDto = res;
                this.additionalGtinRows = res.addtionalGtinList || [];
                this.UpdateAdditionalGtinRowId();
                this.getInitialAdditionalGtinData();
                this.showItemDetails = true;
                //this.itemFormDto.lastUpdatedBy = this.userId;
                //this.basicItemDefnitionDto.lastUpdatedBy = this.userId;
            }
        });
    }
    resetToInitialState(){
        //this.vendorBasicItemDefFormGroup.markAsPristine();
        //this.vendorBasicItemDefFormGroup.markAsUntouched();
        this.vendorBasicItemDefFormGroup.patchValue({
            itemFormID: this.itemFormID,
            formattedGtin: '',
            gtinCheckDigit: null,
            existingGtinIndicator: '',
            compressedUPC: '',
            priceLookupCode: '',
            submissionReasonID: 1,
            itemCaseTypeID: 1,
            modelProductItemCode: '',
            modelProductItemDescription: '',
            modelPackagingItemCode: '',
            retailPackagedItem: '',
            additionalGTINPresent: 'N',
            sizeUOM: '',
            retailPackType: '',
            vendorItemCode: '',
            vendorItemDescription: '',
            brand: '',
            manufacturer: '',
            size: '',
            retailPackSize: '',
            labelAmount: '',
            minorityManufacturer: '',
            packageDescription: '',
            containerType: '',
            taxExemptionVendorEmail: '',
            taxExemptionPublixEmail: '',
            formActionID: '',
            formTypeID: '',
            itemCode: '',
            submittedUserTypeID: UserType.Vendor,
        });
        this.additionalGtinRows = [];
        this.showItemDetails = false;
    }

    private CheckGTINExistInCurrentForm(GTIN:string):boolean {
                
        if(this.additionalGtinRows.some(r => r.formattedGtin.toString() == GTIN))
            return true;
        else if(this.vendorBasicItemDefFormGroup.get('formattedGtin').value == GTIN)
            return true;
        return false;
        }

    public saveBasicItemDefinition(createdFormStatusID : number , actionID : number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            console.log(res +"saveBasicItemDefinition");
            if (res) {
                this.snackBar.open("Saved successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
                //this.handleItemValidations();
                //this.getBasicItemDefinitionData();
            }
        }); 
    }


    public submitBasicItemDefinition(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            console.log(res + "submitBasicItemDefinition");
            //this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
            //    this.handleItemValidations();
            //    this.getBasicItemDefinitionData();
            //});
            if (res) {
                this.snackBar.open("Submitted successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });              
            }
            else {
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
        });
    }

    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    
    saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean>{
        if (this.skipSaveTab) return of(true);
        this.errors = [];
        console.log('Save Submitted!');
        let basicItemDefinition: IBasicItemDefnitionDto = (<any>Object).assign({}, this.vendorBasicItemDefFormGroup.value);
        basicItemDefinition.itemFormID = this.newItemFormService.itemFormID;
        basicItemDefinition.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
        basicItemDefinition.itemDescription = basicItemDefinition.vendorItemDescription;
        basicItemDefinition.lastUpdatedBy = this.userId;
        basicItemDefinition.submittedUserTypeID = UserType.Vendor;

        //if createdFormStatusID is 0 (when changing tab) , send the currentstatus .
        createdFormStatusID = createdFormStatusID == undefined ? this.newItemFormService.formCurrentStatusID : createdFormStatusID;
        basicItemDefinition.formStatusID = createdFormStatusID;
        basicItemDefinition.formActionID = actionID;
        basicItemDefinition.itemCode = this.newItemFormService.itemCode;

        basicItemDefinition.addtionalGtinList = this.additionalGtinRows;
        if (basicItemDefinition.addtionalGtinList != undefined) {
            for (let additionalGtin of basicItemDefinition.addtionalGtinList) {
                additionalGtin.createdBy = this.userId;               
            }
        }
        //Get the user dropdown selection data
        this.getBasicItemDefDropdownSelectionData(basicItemDefinition);
        const saveSuccess$: Subject<boolean> = new Subject<boolean>();
        this.validateMappedGTINRetailPack(basicItemDefinition).subscribe(
            (res => {
                console.log(res+ " ValidateMappedGTIN");
                if(res){
                    this.saveApi(basicItemDefinition, createdFormStatusID, actionID).subscribe(res => {
                       if(res){
                        saveSuccess$.next(true);
                        saveSuccess$.complete();
                       }                       
                       else {
                        saveSuccess$.next(false);
                        saveSuccess$.complete();
                       }
                   });
                }
                else {
                    this.resetBasicItemDef();
                    saveSuccess$.next(false);
                    saveSuccess$.complete();
                }
            })
        );
        return saveSuccess$;
    }

    saveApi(basicItemDefinition, createdFormStatusID: number,actionID : number): Observable<boolean> {
        this.newItemFormService.showLoadingSpinner = true;
        return this.basicItemDefService.saveBasicItemDefinition(basicItemDefinition).pipe(
            map(res => {
                if (res.validation) {
                    this.newItemFormService.addItemValidation(res.validation);
                }

                if (res.status)
                    this.newItemFormService.formCurrentStatusID = createdFormStatusID;

                console.log("saved successfully.");
                //this.populateGtinHeaderDto();
                this.newItemFormService.setBIDData(basicItemDefinition);   
                this.newItemFormService.showLoadingSpinner = false;  
                if (actionID)
                    this.getBasicItemDefinitionData();         
                return res.status;
            }),
            catchError((err) => {
                if (err.status === 400) {
                    // handle validation error
                    this.newItemFormService.showLoadingSpinner = false;   
                    this.newItemFormService.addItemValidation(err.error);
                    this.handleItemValidations();
                    //let validationErrorDictionary = err.error;                    
                    //this.handleBasicItemDefValidations(validationErrorDictionary);
                    
                } else {
                    this.errors.push("Unhandled expection occured.");
                }
                window.scrollTo(0,150);
                this.snackBar.open("Please correct the errors before navigating.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                  });
                return of(false);
            })
        );
    }  

    // public populateGtinHeaderDto() : void {
    //     let gtinDto: GtinDto = new GtinDto();
    //     gtinDto.formattedGtin = this.vendorBasicItemDefFormGroup.get("formattedGtin").value;
    //     gtinDto.gtinCheckDigit = this.vendorBasicItemDefFormGroup.get("gtinCheckDigit").value; 
    //     gtinDto.compressedUPC = this.vendorBasicItemDefFormGroup.get("compressedUPC").value;
    //     gtinDto.priceLookupCode = this.vendorBasicItemDefFormGroup.get("priceLookupCode").value;
    //     gtinDto.modelProductItemcode = this.vendorBasicItemDefFormGroup.get("modelProductItemCode").value;
    //     gtinDto.modelItemDescription = this.vendorBasicItemDefFormGroup.get("modelProductItemDescription").value;
    //     gtinDto.itemCode = this.vendorBasicItemDefFormGroup.get("itemCode").value;
    //     gtinDto.itemDescription = this.vendorBasicItemDefFormGroup.get("vendorItemDescription").value;

    //     //this.newItemFormService.setItemFormDisplayID(this.itemFormDto.itemFormDisplayID, null);
    //     this.newItemFormService.setGtinHeaderDetails(gtinDto);       

    // }

    // public setBIDData(): void {
    //     let basicItemDefinitionDto: BasicItemDefnitionDto = new BasicItemDefnitionDto();
    //     let basicItemDefinition = (<any>Object).assign({}, this.vendorBasicItemDefFormGroup.value);
    //     basicItemDefinitionDto.itemTypeCode = basicItemDefinition.itemTypeCode;
    //     basicItemDefinitionDto.retailPackagedItem = basicItemDefinition.retailPackagedItem;
    //     basicItemDefinitionDto.itemCaseTypeID = basicItemDefinition.itemCaseTypeID;
    //     basicItemDefinitionDto.size = basicItemDefinition.size;
    //     basicItemDefinitionDto.sizeUOM = basicItemDefinition.sizeUOM;
    //     this.newItemFormService.setBIDData(basicItemDefinitionDto);          
    // }

    public deleteItemForm(): void {

        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.newItemFormService.deleteItemForm().subscribe(res => {
                    if (res != undefined) {
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" });                    
                },
                    (err) => {
                        if (err.status === 400) {
                            // handle validation error
                           //  let validationErrorDictionary = err.error.modelState;
                            this.handleBasicItemDefValidations(err.error);
                        } else {
                            this.errors.push("Unhandled expection occured.");
                        }
                        window.scrollTo(0, 0);
                    })
                // TO DO: re-direct to dashboard to start the flow of New or existing item form
               // this.itemFormDto = new ItemFormDto();
               // this.basicItemDefnitionDto = new BasicItemDefnitionDto();              
            }
        });
        
    }



    public handleItemValidations() {
        const validations: any = this.newItemFormService.getItemValidation("Basic Item Definition");
        if (validations) {
            this.handleBasicItemDefValidations(validations);
        }
    }

    handleBasicItemDefValidations(bidValidation) {
        let bidErrors = bidValidation.errors;
        let bidWarnings = bidValidation.warnings;
        this.handleBIDValidationErrors(bidErrors);
        this.handleBIDValidationWarnings(bidWarnings);        
    }

    handleBIDValidationErrors(bidErrors: any[]) {

        for (var key in bidErrors) {
            let errorObj = bidErrors[key];
            //for (var errorObj of gpaErrors) {
            let fieldName = errorObj.controlName;
            if (fieldName) {
                if (this.vendorBasicItemDefFormGroup.controls[fieldName]) {

                    this.vendorBasicItemDefFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.vendorBasicItemDefFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;

                }
                else {
                    this.errors.push(errorObj.errorDescription);
                }
            }
        }
    }

    handleBIDValidationWarnings(bidErrors: any[]) {

        for (var key in bidErrors) {
            let errorObj = bidErrors[key];
            //for (var errorObj of gpaErrors) {
            let fieldName = errorObj.controlName;
            if (fieldName) {
                if (this.vendorBasicItemDefFormGroup.controls[fieldName]) {
                    this.vendorBasicItemDefFormGroup.controls[fieldName].setErrors({ warning: true });
                    this.vendorBasicItemDefFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;

                }
                else {
                    this.errors.push(errorObj.errorDescription);
                }

            }
        }
    }

    //private handleValidationErrors(validationErrorDictionary: any[]) {
    //    for (var key in validationErrorDictionary) {
    //        let obj = validationErrorDictionary[key];
    //        let fieldName = obj.controlName;
    //        if (fieldName) {
    //            if (this.vendorBasicItemDefFormGroup.controls[fieldName]) {
    //                //integrate into angular's validation if we have field validation
    //                this.vendorBasicItemDefFormGroup.controls[fieldName].setErrors({ invalid: true });
    //                this.vendorBasicItemDefFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
    //                this.formErrors[fieldName] = obj.errorDescription;
    //            }
    //            else {
    //                this.errors.push(obj.errorDescription);
    //            }
    //        }
    //    }
    //}

    private getBasicItemDefDropdownSelectionData(basicItemDefinition:IBasicItemDefnitionDto): void {        

        if (basicItemDefinition.retailPackType && this.retailPackTypesList) {
            const retailPackLookupDto = this.retailPackTypesList.find(x => x.code == basicItemDefinition.retailPackType);
            basicItemDefinition.retailPackTypeDescription = (retailPackLookupDto)? retailPackLookupDto.description : basicItemDefinition.retailPackType;
        }

        if (basicItemDefinition.sizeUOM && this.sizeUomList) {
            const sizeUOMLookupDto = this.sizeUomList.find(x => x.code == basicItemDefinition.sizeUOM);
            basicItemDefinition.sizeUOMDescription = (sizeUOMLookupDto)?sizeUOMLookupDto.description : basicItemDefinition.sizeUOM;
        }
       
    }

    //public isPrePrice(val: string): boolean {
    //    if (val.trim() === "P")
    //        return true;
    //    else
    //        return false;
    //}

    public onRetailPackTypeChange(val: string) {

        this.vendorBasicItemDefFormGroup.patchValue({
            "labelAmount": null
        });
    }

    private validateMappedGTINRetailPack(basicItemDefinition:IBasicItemDefnitionDto): Observable<boolean> {  
        const gtinList: string[] = [basicItemDefinition.formattedGtin,...basicItemDefinition.addtionalGtinList.map(a=>a.formattedGtin)];
        let gtinNotMappedList: string[] = [];
        let phNotFoundList: number[] = [];
        for(var gtin of this.nutritionalPanelMappedGTINList){
            const gtinFound = gtinList.find(item => {
                return item == gtin.formattedGtin;
            });
            if(!gtinFound){
                gtinNotMappedList.push(gtin.formattedGtin.replace(/-/g, ""));
            }
        }

     
        for (var ph of this.existingPackagingHierarchies) {

            //first check if primary retail pack matches , if not check if any of the additional retail packs matches. If nothing matches ,
            ///add it toolbar the phNotFoundList.
            console.log("retailPackType: " + basicItemDefinition.retailPackType+ ph.retailPackType+ (basicItemDefinition.retailPackType == ph.retailPackType));
            console.log("retailPackSize: " + +basicItemDefinition.retailPackSize+ +ph.retailPackSize+ (basicItemDefinition.retailPackSize == ph.retailPackSize));
            console.log("labelAmount: " + +basicItemDefinition.labelAmount+ +ph.labelAmount+ (basicItemDefinition.labelAmount == ph.labelAmount));
            console.log("size: " + basicItemDefinition.size+ ph.size+ (basicItemDefinition.size == ph.size));
            console.log("sizeUOM: " + basicItemDefinition.sizeUOM+ ph.sizeUOM+ (basicItemDefinition.sizeUOM == ph.sizeUOM));
            let bidSize = '';
            let phSize = '';
            if(basicItemDefinition.size){
                bidSize = basicItemDefinition.size.toString();
            }
            if(ph.size){
                phSize = ph.size.toString();
            }
            console.log("size: " + bidSize+ phSize + (phSize == bidSize));
            if (!(basicItemDefinition.retailPackType == ph.retailPackType && basicItemDefinition.retailPackSize == ph.retailPackSize
                && basicItemDefinition.labelAmount == ph.labelAmount && bidSize == phSize
                && basicItemDefinition.sizeUOM == ph.sizeUOM))
            {           
                let matchingPh = basicItemDefinition.addtionalGtinList.find(item => {
                    let itemSize = '';
                    if(item.size){
                        itemSize = item.size.toString();
                    }
                    return item.retailPackType == ph.retailPackType && item.retailPackSize == ph.retailPackSize
                        && item.labelAmount == ph.labelAmount && itemSize == phSize && item.sizeUOM == ph.sizeUOM
                });

                if (!matchingPh)              
                    phNotFoundList.push(ph.id);
                
            }          
        }

       
        if ((gtinNotMappedList.length > 0) || (phNotFoundList.length > 0)) {

            let desc: string = '';
            if (gtinNotMappedList.length > 0)
                desc = this.showMessage("BID48");
            if (phNotFoundList.length > 0)
                desc = desc + '\n'  + this.showMessage("BID49"); //"Retail Packs have been modified or deleted. Corresponding Packaging Hierarchies will be deleted. "

            let data ={
                title: "",
                description: desc + '\n' +"Please click 'Ok' to continue or 'Cancel' to revert the current changes?",
                actions:[               
                    "Cancel",
                    "Ok"
                ]
            }
            let dialog = this.dialog.open(DialogContentComponent, {
              disableClose: true,
              width: '800px',
              data: data
            });
            return dialog.afterClosed().pipe(
                map(option => {
                     if(option && option.action == "Ok"){
                        const gtinRetailPackInfo: IGTINRetailPackInfoDto = {
                            nutritionalPanelGTINList: gtinNotMappedList,
                            packagingHierarchiesList: phNotFoundList,
                            itemFormID : this.newItemFormService.itemFormID
                        }
                         this.basicItemDefService.removeGTINRetailPackRelatedInfo(gtinRetailPackInfo).subscribe(res => {
                             console.log("removeGTINRetailPackRelatedInfo "+res);
                         })
                         return true;
                     }
                     return false;
                })
            );
        }
        else{
            return of(true);
        }
        
    }
    getErrorMessage(control: FormControl, name: string){
        for (let propertyName in control.errors) {
            if ((propertyName == "invalid" || propertyName == "warning") && this.formErrors[name]){
                return this.formErrors[name]; 
            }
            if (control.errors.hasOwnProperty(propertyName) && control.touched) {
              return this.getValidatorErrorMessage(propertyName, control.errors[propertyName]);
            }
          }          
          return null;
    }
    getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            'required': 'This field is required.',
            'notvalid': 'This is not a valid value',
            'email': 'This is not a valid email',
            'minlength': `This field should have atleast ${validatorValue.requiredLength} characters`,
            'beforePadding' : 'This field is required.',
            'range' : 'Invalid GTIN.',
            'type2' : "GTIN entered is reserved for type -2 GTIN's.",
            'dummy' : "GTIN entered is reserved for Dummy GTIN's.",
            'vendorCoupon': "GTIN entered is reserved for Vendor Coupons.",
            'checkDigitRequired':"GTIN Check digit is required to validate GTIN.",
            'checkDigit' : 'GTIN is not valid for the entered check digit.',
        };
        return config[validatorName];
    }
    // Grid specific events
    getGridData() {
        if (!this.data) return [];
        return this.data;
      }
    getAdditionalGtinData(gridEvent: GridEvent) {
        this.data = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }
    getInitialAdditionalGtinData() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 0,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getAdditionalGtinData(gridEvent);
    }
    /**
  * return the filtered or shallow copy without changing the original data
  */
    performFilter(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.additionalGtinRows.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.additionalGtinRows.slice();
        }
        return this.additionalGtinRows.slice();
    }
    /**
     * sort the filtered result based on sort column and order
     */
    sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.data.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.data.reverse();
        }
    }
    /**
       * paginate the result set
       */
    pageData(gridEvent: GridEvent) {
        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.data.length;
        let pageIndex = gridEvent.pageIndex;
        let offset = pageIndex * this.pageSize;
        this.data = this.data.slice(offset, offset + this.pageSize);
    }

    onadditionalGTINPresentChange(additionalGTINPresent) {
        if (additionalGTINPresent === 'Y') {
            //this.basicItemDefnitionDto.additionalGTINPresent = "N";
            this.vendorBasicItemDefFormGroup.patchValue({ "additionalGTINPresent": "Y" });
            this.openDialog();
        }
        else
            this.vendorBasicItemDefFormGroup.patchValue({ "additionalGTINPresent": "N" });
       
    }
}
