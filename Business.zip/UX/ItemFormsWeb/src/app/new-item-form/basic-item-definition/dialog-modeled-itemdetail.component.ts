import { Component, OnInit,Inject } from '@angular/core';
import {MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { IModelProductItemValueDto, ModelProductItemValueDto } from './basic-item-definition-interface';

@Component({
  selector: 'ifw-dialog-modeled-itemdetail',
  templateUrl: './dialog-modeled-itemdetail.component.html',
  styleUrls: ['./dialog-modeled-itemdetail.component.scss']
})

export class DialogModeledItemdetailComponent implements OnInit  {

  public modelProductItemValueDto: ModelProductItemValueDto 
  constructor(public dialogRef: MatDialogRef<DialogModeledItemdetailComponent>,
   
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {        

     }    

  ngOnInit() {
    console.log('Popup Log');
    console.log(this.data);
    this.modelProductItemValueDto = this.data.ModelProductDetails;

  }

  LoadElements():Element[]
{
  let ELEMENT_DATA = [];
  console.log("this.data.ModelProductDetails"+this.data.ModelProductDetails);
  if(this.data.ModelProductDetails != undefined)
  {
     ELEMENT_DATA = [   
      //{name: 'ItemForm ID',  value: this.data.ModelProductDetails.itemFormID},
      //{ name: 'Brand',  value: this.data.ModelProductDetails.brand},
      //{ name: 'Manufacturer',  value: this.data.ModelProductDetails.manufacturer},
      { name: 'Item Description',  value: this.data.ModelProductDetails.itemDescription},     
      {name: 'Scale Description1', value: this.data.ModelProductDetails.scaleDescription1},
      {name: 'Scale Description2', value: this.data.ModelProductDetails.scaleDescription2},
      {name: 'Ad Description',  value: this.data.ModelProductDetails.adDescription},
      {name: 'ProductCatalog ShortDescription1',  value: this.data.ModelProductDetails.productCatalogShortDescription1},
      {name: 'ProductCatalog ShortDescription2',  value: this.data.ModelProductDetails.productCatalogShortDescription2}
      
      ]; 
      if(this.data.IsRetail)
      ELEMENT_DATA.push({ name: 'Receipt Description', value: this.data.ModelProductDetails.receiptDescription });
      
    // TESTING only
     /*
    ELEMENT_DATA = [   
      {name: 'ItemForm ID',  value: this.data.ModelProductDetails.itemFormID},
      { name: 'Brand',  value: "Check Brand"},
      { name: 'Manufacturer',  value: "Check Manufacturer"},
      { name: 'Item Description',  value:  "Check Item Description"},
      { name: 'Receipt Description',  value: "Check Receipt Description"},
      {name: 'Scale Description1',  value: "Check Scale Description1"},
      {name: 'Scale Description2',  value:"Check Scale Description2"},
      {name: 'Ad Description',  value: "Check Ad Description"},
      { name: 'ProductCatalog ShortDescription1',  value: "Check ProductCatalog ShortDescription1"},
      {name: 'ProductCatalog ShortDescription2',  value: "Check ProductCatalog ShortDescription2"}
      
    ];   
     */ 

  }
  return ELEMENT_DATA
  
}

displayedColumns = ['select',  'name', 'value'];
  dataSource = new MatTableDataSource<Element>(this.LoadElements());
  selection = new SelectionModel<Element>(true, []);
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  onCopyModeledItemDetails(){
    console.log(this.selection.selected);
    this.data.SelectedFileds = this.selection.selected;
    this.dialogRef.close(this.data);    
  }

    onCancel() {
        this.dialogRef.close();
    }
}

export interface Element {
  name: string; 
  value: string;
}




