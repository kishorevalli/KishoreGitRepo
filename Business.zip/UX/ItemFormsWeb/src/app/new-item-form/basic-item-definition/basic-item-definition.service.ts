import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { ILookupDto, LookupDto, IItemSaveResponse } from '../../shared/common.interface';
import { IItemFormDto, ItemFormDto, IGTINWithCheckdigitDto } from '../new-item-form.interface';
import {
    IBasicItemDefnitionDto, BasicItemDefnitionDto, IAdditionalGtinDto, AdditionalGtinDto,
    IItemTypeDto, ItemTypeDto, IReuseItemCodeDto, ReuseItemCodeDto, IModelProductItemValueDto, ModelProductItemValueDto,
    IPMDSGTINDto, PMDSGTINDto, IItemDescriptionDto, ItemDescriptionDto, IGTINRetailPackInfoDto
} from './basic-item-definition-interface';
import {IPackagingHierarchy } from '../packaging-hierarchy/packaging-hierarchy.interface';

import { APP_CONFIG, AppConfig } from '../../app.config';

@Injectable()
export class BasicItemDefinitionService {
    private baseUrl: string;

    private serviceBase: string = 'api/BasicItemDefinition/';

    constructor( @Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;
    }

    getSubmissionReasons(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetSubmissionReasons');
    }

    getItemCaseTypes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetItemCaseTypes');
    }

    getRetailPackTypes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetRetailPackTypes');
    }

    getUnitOfMeasures(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetUnitOfMeasures');
    }

    saveBasicItemDefinition(basicItemDefnitionDto: IBasicItemDefnitionDto): Observable<IItemSaveResponse> {
        return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + 'SaveBasicItemDefinition', basicItemDefnitionDto );
    }

    //saveItemForm(itemFormDto: IItemFormDto): Observable<IItemFormDto> {
    //    return this.httpClient.post<IItemFormDto>(this.baseUrl + 'api/Common/' + 'SaveItemForm', itemFormDto);
    //}

    //deleteItemForm(itemFormDto: IItemFormDto): Observable<boolean> {
    //    return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'DeleteItemForm', itemFormDto);
    //}

    GetItemFormsDisplayIDs(userId:string): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + `GetItemFormsDisplayIDs?userId=${userId}`);
    }

    getBasicItemDefinitionData(itemFormId: number){
        return this.httpClient.get<IBasicItemDefnitionDto>(this.baseUrl + this.serviceBase + `GetBasicItemDefinitionData?itemFormID=${itemFormId}`);
    }

    saveItemDataByPmdsGTIN(basicItemDefnitionDto: IBasicItemDefnitionDto){
        return this.httpClient.post<IBasicItemDefnitionDto>(this.baseUrl + this.serviceBase + 'SaveItemDataByPmdsGTIN', basicItemDefnitionDto);
    }

    saveItemDataByPmdsItemCode(basicItemDefnitionDto: IBasicItemDefnitionDto) {
        return this.httpClient.post<IBasicItemDefnitionDto>(this.baseUrl + this.serviceBase + 'SaveItemDataByPmdsItemCode', basicItemDefnitionDto);
    }

    saveModelDataForPackagingHierarchy(basicItemDefnitionDto: IBasicItemDefnitionDto) {
        return this.httpClient.post<IBasicItemDefnitionDto>(this.baseUrl + this.serviceBase + 'SaveModelDataForPackagingHierarchy', basicItemDefnitionDto);
    }


    ConvertCompressedUPCToGTIN(compressedUPC: string): Observable<string> {
        return this.httpClient.get<string>(this.baseUrl + this.serviceBase + `ConvertCompressedUPCToGTIN?compressedUPC=${compressedUPC}`);
    }

    ConvertPLUToGTIN(priceLookUp: string): Observable<string> {
        return this.httpClient.get<string>(this.baseUrl + this.serviceBase + `ConvertPLUToGTIN?priceLookUp=${priceLookUp}`);
    }
    
    isGTINExists(GTIN: number): Observable<IPMDSGTINDto> {
        return this.httpClient.get<IPMDSGTINDto>(this.baseUrl + this.serviceBase + `IsGTINExists?GTIN=${GTIN}`);
    }

    isGTINExistInPMDS(GTIN: number) {
        return this.httpClient.get<boolean>(this.baseUrl + this.serviceBase + `isGTINExistInPMDS?GTIN=${GTIN}`);
    }    

    IsReuseItemCodeExist(reuseItemCode: number) {
        return this.httpClient.get<IReuseItemCodeDto>(this.baseUrl + this.serviceBase + `IsReuseItemCodeExist?reuseItemCode=${reuseItemCode}`);
    }
    

    GetItemTypes(): Observable<IItemTypeDto[]> {
        return this.httpClient.get<IItemTypeDto[]>(this.baseUrl + this.serviceBase + `GetItemTypes`);
    }

    getAvailableItemFormReuseItemCodesBySubDept(reuseItemCodeDto :ReuseItemCodeDto ): Observable<IReuseItemCodeDto[]> {
        console.log(reuseItemCodeDto);
       
        return this.httpClient.post<IReuseItemCodeDto[]>(this.baseUrl + this.serviceBase + 'GetAvailableItemFormReuseItemCodesBySubDept',reuseItemCodeDto);
    }

    getReuseItemSubDepartments(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetReuseItemSubDepartments');
    }
    getReuseItemCodesBySubDept(reuseItemCodeDto :ReuseItemCodeDto ): Observable<IReuseItemCodeDto[]> {
        console.log(reuseItemCodeDto);
       
        return this.httpClient.post<IReuseItemCodeDto[]>(this.baseUrl + this.serviceBase + 'GetReuseItemCodesBySubDept',reuseItemCodeDto);
    }
 
    updateReuseItemCodeToFormID(selectedReuseItemCodeDto: ReuseItemCodeDto): Observable<boolean> {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'updateReuseItemCode', selectedReuseItemCodeDto);
    }

    isSelectedReuseItemCodeAlreadyUsed(selectedReuseItemCodeDto: ReuseItemCodeDto): Observable<IReuseItemCodeDto> {
        console.log("IsSelectedReuseItemCodeAlreadyUsed");
        console.log(selectedReuseItemCodeDto);
        return this.httpClient.post<IReuseItemCodeDto>(this.baseUrl + this.serviceBase + 'IsSelectedReuseItemCodeAlreadyUsed', selectedReuseItemCodeDto);
    }

    saveReuseItemCode(selectedReuseItemCodeDto: ReuseItemCodeDto) {
        console.log("saveReuseItemCode");
        console.log(selectedReuseItemCodeDto);
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'SaveReuseItemCode', selectedReuseItemCodeDto);
    }

    getModelProductItemValues(itemFormID: number) {
        return this.httpClient.get<IModelProductItemValueDto>(this.baseUrl + this.serviceBase + `GetModelProductItemValues?itemFormID=${itemFormID}`);
    }

    deleteModelProductItemValues(itemFormID: number) {
        return this.httpClient.get<IModelProductItemValueDto>(this.baseUrl + this.serviceBase + `deleteModelProductItemValues?itemFormID=${itemFormID}`);
    }

    getItemsMatchingDescription(itemDescriptionDto: ItemDescriptionDto): Observable<IItemDescriptionDto[]> {
        
        return this.httpClient.post<IItemDescriptionDto[]>(this.baseUrl + this.serviceBase + 'GetItemsMatchingDescription', itemDescriptionDto);
    }
    
    GetNutritionalPanelGTIN(itemFormID: number): Observable<IGTINWithCheckdigitDto[]> {
        return this.httpClient.get<IGTINWithCheckdigitDto[]>(this.baseUrl + this.serviceBase + `GetNutritionalPanelGTIN?itemFormID=${itemFormID}`);
    }
    removeGTINRetailPackRelatedInfo(mismatchedBIDDto: IGTINRetailPackInfoDto) {
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'RemoveGTINRetailPackRelatedInfo',mismatchedBIDDto);
    }

    GetExistingPackagingHierarchies(itemFormID: number): Observable<IPackagingHierarchy[]> {
        return this.httpClient.get<IPackagingHierarchy[]>(this.baseUrl + this.serviceBase + `GetExistingPackagingHierarchies?itemFormID=${itemFormID}`);
    }

}
