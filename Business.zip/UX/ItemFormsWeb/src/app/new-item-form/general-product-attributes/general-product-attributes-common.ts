﻿export class GeneralProductAttributesCommon {



}