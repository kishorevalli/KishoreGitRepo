import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ILookupDto, LookupDto, IItemSaveResponse } from '../../shared/common.interface';
import { INutritionalAllergenInfo, INutritionalInfo, IGeneralProductAttributes, IDrugScheduleCode, IVariableWeightIndicator, IUnacceptableIngredient } from './general-product-attributes.interface';
import { NewItemFormService } from '../new-item-form.service';
import { APP_CONFIG, AppConfig } from '../../app.config';

@Injectable()
export class GeneralProductAttributesService {
    private baseUrl;

    private serviceBase: string = 'api/GeneralProductAttributes/';

    constructor( @Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;
    }
    getProductDateTypes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetProductDateTypes');
    }
    getNDCFormats(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetNDCFormats');
    }
    getNutritionalPanelTypes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetNutritionalPanelTypes');
    }
    getOrganicTypes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetOrganicTypes');
    }
    GetDrugScheduleCodes(): Observable<IDrugScheduleCode[]> {
        return this.httpClient.get<IDrugScheduleCode[]>(this.baseUrl + this.serviceBase + 'GetDrugScheduleCodes');
    }
    GetNutrientDetails(): Observable<INutritionalInfo[]> {
        return this.httpClient.get<INutritionalInfo[]>(this.baseUrl + this.serviceBase + 'GetNutrientDetails');
    }
    GetAllergensDetails(): Observable<INutritionalAllergenInfo[]> {
        return this.httpClient.get<INutritionalAllergenInfo[]>(this.baseUrl + this.serviceBase + 'GetAllergensDetails');
    }
    SaveGeneralProductAttributes(generalProductAttributes: IGeneralProductAttributes): Observable<IItemSaveResponse> {
        return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + 'SaveGeneralProductAttributes', generalProductAttributes);
    }
    GetGeneralProductAttributes(itemFormID: number): Observable<IGeneralProductAttributes> {
        return this.httpClient.get<IGeneralProductAttributes>(this.baseUrl + this.serviceBase + `GetGeneralProductAttributes?itemFormID=${itemFormID}`);
    }
    getVariableWeightIndicators(): Observable<IVariableWeightIndicator[]> {
        return this.httpClient.get<IVariableWeightIndicator[]>(this.baseUrl + this.serviceBase + 'GetVariableWeightIndicators');
    }
    getLiquorTypes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetLiquorTypes');
    }
    getShelfTagSizes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetShelfTagSizes');
    }
    getUnacceptableIngredientList(): Observable<IUnacceptableIngredient[]> {
        return this.httpClient.get<IUnacceptableIngredient[]>(this.baseUrl + this.serviceBase + 'GetUnacceptableIngredientList');
    }
}