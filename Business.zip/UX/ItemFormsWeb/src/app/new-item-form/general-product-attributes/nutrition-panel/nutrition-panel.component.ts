import { Component, OnInit, Input, ViewEncapsulation, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { PageEvent, Sort, MatDialog } from '@angular/material';
import { GridEvent } from '../../../shared/grid/grid-event'
import { INutritionalAllergenInfo , INutritionalInfo, INutritionalPanel } from '../general-product-attributes.interface';
import { ConfirmDialogComponent } from '../../../shared/dialog/confirm-dialog.component';
import { NewItemFormService } from '../../new-item-form.service';
import { IGTINWithCheckdigitDto } from '../../new-item-form.interface';

@Component({
  selector: 'ifw-nutrition-panel',
  templateUrl: './nutrition-panel.component.html',
  styleUrls: ['./nutrition-panel.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NutritionPanelComponent implements OnInit {
  @Input()
  public PanelFormArray: FormArray;
  @Input()
  public InputFieldColor : string;
  @Input() 
  public Nutrients : INutritionalInfo[];
  @Input() 
  public Allergens : INutritionalAllergenInfo[];
  @Input() 
  public ExistingPanels : INutritionalPanel[];
  @Input() 
  public ItemFormID : number;
  public deletedPanels: INutritionalPanel[];
  activeTabIndex = 0;
  public panelErrorList: any;
  formErrors: any;
  public isReadOnly: boolean = false; 
  @Input()
  public GTINList : IGTINWithCheckdigitDto[];
  constructor(private formBuilder: FormBuilder,
              private newItemFormService: NewItemFormService,
              private dialog: MatDialog,
              private cdr: ChangeDetectorRef) { }

  ngOnInit() {
    this.deletedPanels = [];
    this.panelErrorList = {};
    this.formErrors = {};
    this.isReadOnly = this.newItemFormService.isReadOnly;
    if(this.ExistingPanels && this.ExistingPanels.length > 0){
      this.InitNutrientsPanel(this.ExistingPanels);
    }
    else {
      this.addNewVariety();
    }
  }
  ngAfterViewInit(){
    console.log("Child ngAfterViewInit.")
    
  } 
  buildNutrient(val: INutritionalInfo) {
    return this.formBuilder.group({
      id: val.id,
      nutritionalPanelID: val.nutritionalPanelID,
      nutrDictionaryID: val.nutrDictionaryID,
      nutrientName: val.nutrientName,
      uom: val.uom,
      isRequired: val.isRequired,
      sortOrder: val.sortOrder,
      quantity: val.quantity,
      dailyValuePercentage: val.dailyValuePercentage
    });
  }
  buildAllergen(val: INutritionalAllergenInfo) {
    return this.formBuilder.group({
      id: val.id,
      nutritionalPanelID: val.nutritionalPanelID,
      nutrDictionaryID: val.nutrDictionaryID,
      allergenName: val.allergenName,
      value: val.value,
      sortOrder: val.sortOrder,
    });
  }
  buildNutrientsPanel(val: INutritionalPanel) {
    let arrayAllergens = [];
    if(val.nutritionalAllergenInfoList) {
      for(const _existAllergen of val.nutritionalAllergenInfoList){
        arrayAllergens.push(this.buildAllergen(_existAllergen));
      }
    }
    else {
      for (const _allergen of this.Allergens) {
        arrayAllergens.push(this.buildAllergen(_allergen));
      }
    }
    let arrayNutrients = [];
    if(val.nutritionalInfoList) {
      for(const _existNutritional of val.nutritionalInfoList){
        arrayNutrients.push(this.buildNutrient(_existNutritional));
      }
    }
    else {
      for (const _nutrient of this.Nutrients) {
        arrayNutrients.push(this.buildNutrient(_nutrient));
      }
    } 
    return this.formBuilder.group({
      id: val.id,
      itemFormID: val.itemFormID,
      nutritionalPanelName: val.nutritionalPanelName,
      formattedGtin: val.formattedGtin,
      gtinCheckDigit: val.gtinCheckDigit,
      servingSize: val.servingSize,
      isDirty: false,
      isDeleted: false,
      sortOrder: val.sortOrder,
      servingsPerContainer: val.servingsPerContainer,
      containsAllergen: val.containsAllergen,
      nutritionalInfoList: this.formBuilder.array(arrayNutrients),
      nutritionalAllergenInfoList: this.formBuilder.array(arrayAllergens),
      errorList: this.formBuilder.array([])
    });
  }
  InitNutrientsPanel(existPanels:INutritionalPanel[]){
    for(const nutrientsPanel of existPanels){
      this.PanelFormArray.push(this.buildNutrientsPanel(nutrientsPanel));
      const index = this.PanelFormArray.length - 1;
      this.populateInitialGridData(index);
    }
  }
  addNewVariety() {
    let sortOrder = 0;
    if(this.PanelFormArray.length == 0) sortOrder = 1;
    else {
      sortOrder = (this.PanelFormArray.controls[this.PanelFormArray.length - 1].get('sortOrder').value) + 1;
    }

    this.PanelFormArray.push(this.buildNutrientsPanel({
                              id:0,
                              itemFormID: this.ItemFormID,
                              nutritionalPanelName: '',
                              formattedGtin:'',
                              gtinCheckDigit: null,
                              containsAllergen: 'N',
                              servingSize:'',
                              servingsPerContainer: null,
                              isDirty: false,
                              isDeleted: false,
                              sortOrder: sortOrder,
                              nutritionalInfoList: null,
                              nutritionalAllergenInfoList: null
                            }));
    const index = this.PanelFormArray.length - 1;
    this.populateInitialGridData(index);
    this.activeTabIndex = index;
  }
  deleteRow(index: number) {
    let dialog = this.dialog.open(ConfirmDialogComponent);
    dialog.afterClosed().subscribe(option => {
      if (option && option === true) {
        // If it is a Panel that is already saved, push this in deleted panels  
        var formGroup = this.PanelFormArray.controls[index];
        const id = formGroup.get('id').value;     
        if(id > 0){
          this.deletedPanels.push({
            id: id,
            itemFormID: this.ItemFormID,
            nutritionalPanelName: formGroup.get('nutritionalPanelName').value,
            formattedGtin:'',
            gtinCheckDigit: null,
            containsAllergen: 'N',
            servingSize:'',
            servingsPerContainer: null,
            isDirty: true,
            isDeleted: true,
            sortOrder: 0,
            nutritionalInfoList: null,
            nutritionalAllergenInfoList: null
          });
        }
        this.panelErrorList[formGroup.get('sortOrder').value] = null;
        this.PanelFormArray.removeAt(index);
        this.activeTabIndex = (this.activeTabIndex > 0) ? this.activeTabIndex - 1 : this.activeTabIndex;
        this.populateGridOnAllTabs();
        this.cdr.markForCheck();
      }
    });
  }
  updateChanges(){
    this.cdr.markForCheck();
  }
  handleValidationErrors(panelErrors:any[]){
     for (var panelError of panelErrors){
       var tabName = panelError["subTabName"];
       const _errorCount: number = panelError["errors"].length;
       const _warningCount: number = panelError["warnings"].length;
       var panelGroup = <FormGroup>this.getPanelFormGroup(tabName);
       // go through errors and attach to controls
       let _errors: string[] = []; 
       for(const _error of panelError["errors"]){
        let fieldName = _error.controlName;
        if (fieldName && panelGroup.controls[fieldName]) {
          panelGroup.controls[fieldName].setErrors({ invalid: true });
          panelGroup.controls[fieldName].markAsTouched({ onlySelf: true });
          this.formErrors[fieldName] = _error.errorDescription;
        }
        else {
          _errors.push(_error.errorDescription);
        }
       }
       // go through warnings and attach to controls
       let _warnings: string[] = []; 
       for(const _warning of panelError["warnings"]){
        let fieldName = _warning.controlName;
        if (fieldName && panelGroup.controls[fieldName]) {
          panelGroup.controls[fieldName].setErrors({ warning: true });
          panelGroup.controls[fieldName].markAsTouched({ onlySelf: true });
          this.formErrors[fieldName] = _warning.errorDescription;
        }
        else {
          _warnings.push(_warning.errorDescription);
        }
       }
       // pass to object to show in UI
       this.populateError(tabName,_errors,_warnings,_errorCount,_warningCount);
     }
     this.updateChanges();
  }
  populateError(tabName: string, errorList: string[], warningList: string[], errorCount: number, warningCount: number){
    this.panelErrorList[tabName] =  {
      "errors": errorList,
      "warnings": warningList,
      "errorCount": errorCount,
      "warningCount": warningCount
    };
  }
  
  getErrorMessage(control: FormControl, name: string){
      for (let propertyName in control.errors) {
          if((propertyName == "invalid" || propertyName == "warning")&& this.formErrors[name]){
              return this.formErrors[name]; 
          }
        }          
        return null;
  }
  getPanelFormGroup(tabName: string){
    const findPanel = this.PanelFormArray.controls.find(item => {
      const formGroup = <FormGroup>item;
      return formGroup.controls["sortOrder"].value == tabName;
    });
    return findPanel
  }
  clearPanelErrorList(){
    this.panelErrorList = {};
  }
  changeContainsAllergenValue(panel: FormGroup){
    //Check if none of the other allergens are selected before making it false.
    const allergenYes = (<FormArray>panel.get('nutritionalAllergenInfoList')).controls.find(item => {
      const formGroup = <FormGroup>item;
      return formGroup.controls["value"].value == "Y";
    });
    if(allergenYes)  {
      panel.patchValue({'containsAllergen':'Y'});
    }
    else {
      panel.patchValue({'containsAllergen':'N'});
    }
  }
  addNewDisabled() {
    const nutritionalPanelName = this.PanelFormArray.controls.find(item => {
      return item.get("nutritionalPanelName").value.length == 0
    });
    // const formattedGtin = this.PanelFormArray.controls.find(item => {
    //   return item.get("formattedGtin").value.length == 0
    // });
    if (!nutritionalPanelName)// && !formattedGtin)
      return false;
    return true;
  }
 
  changeGTINColumn(panel:FormGroup, val:string){
    const gtinWithCheckdigit:IGTINWithCheckdigitDto = this.GTINList.find(item => {
       return item.formattedGtin == val;
    });
    panel.get("gtinCheckDigit").setValue(gtinWithCheckdigit.gtinCheckDigit);
  }
  
  // This is a workaround for "Automatically page scrolls to top when switching between some tabs"
  // The Issue reported here : https://github.com/angular/material2/issues/9592
  /* onSelectChange(event) {
    console.log("onSelectChange. Height: "+ document.body.scrollHeight);   
    window.scrollTo(0,500);
 } */
 
  /* grid variables */

  dataTabs = []; // used to hold shallow copy of grid data of each tab.
  length = []; // used to hold count of the entire grid data. No need for array as all the tabs grid has the same length
  pageSize = [];
  populateInitialGridData(index: number) {
    this.updateData({
      pageIndex: 0,
      pageSize: 10,
      length: 0,
      active: "",
      direction: "",
      filterBy: "",
      filterValue: ""
    }, index);
  }
  populateGridOnAllTabs(){
    for(let idx = 0; idx < this.PanelFormArray.controls.length; idx++){
        this.populateInitialGridData(idx);
    }
 }
  getGridData(index: number) {
    if (this.dataTabs.length < index) return [];
    return this.dataTabs[index];
  }
  updateData(gridEvent: GridEvent, index: number) {
    this.dataTabs[index] = this.performFilter(gridEvent, index);
    this.sortData(gridEvent, index);
    this.pageData(gridEvent, index);
  }
  /**
     * return the filtered or shallow copy without changing the original data
     */
  performFilter(gridEvent: GridEvent, index: number): any[] {
    let filterBy = gridEvent.filterBy;
    let filterValue = gridEvent.filterValue;
    const data = (<FormArray>this.PanelFormArray.controls[index].get('nutritionalInfoList')).value;
    if (filterBy && filterBy.length > 0) {
      if (filterValue && filterValue.length > 0) {
        return data.filter((row: any) => {
          // Transform the data into a lowercase string of property values.
          const dataStr = ('' + row[filterBy]).toLowerCase();
          // Transform the filter by converting it to lowercase and removing whitespace.
          const transformedFilter = filterValue.trim().toLowerCase();
          return dataStr.indexOf(transformedFilter) != -1;
        }
        );
      }
      return data.slice();
    }
    return data.slice();
  }
  /**
   *  There is a issue with sort header showing as T when moving between tabs
   *   https://github.com/angular/material2/issues/7291
   */
  /**
   * sort the filtered result based on sort column and order
   */
  sortData(gridEvent: GridEvent, index: number) {
    let sortBy = gridEvent.active;
    let sortAsc = gridEvent.direction == 'asc';
    let sortDesc = gridEvent.direction == 'desc';
    if (!sortAsc && !sortDesc) return;
    this.dataTabs[index].sort((a, b) => {
      if (gridEvent.active == "nutrientName") {
        return a[sortBy].localeCompare(b[sortBy]);
      } else {
        return (a[sortBy] ? a[sortBy] : -1) - (b[sortBy] ? b[sortBy] : -1);
      }
    });
    if (sortAsc === false) {
      this.dataTabs[index].reverse();
    }
  }
  /**
     * paginate the result set
     */
  pageData(gridEvent: GridEvent, index: number) {
    //if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
    this.length[index] = this.dataTabs[index].length;
    this.pageSize[index] = gridEvent.pageSize;
    let pageIndex = gridEvent.pageIndex;
    let offset = pageIndex * gridEvent.pageSize;
    this.dataTabs[index] = this.dataTabs[index].slice(offset, offset + gridEvent.pageSize);
  }
 /**
  * 
  * @param column -- this is the formControlName that is being updated
  * @param val -- update this value in reactive form
  * @param row -- This identifies the formGroup of the row
  * @param index -- This identifies the tab of the grid that is in use right now
  */
  editColumn(column: string, val: string, row: any, index: number) {
    row[column] = val;
    let formGroup = <FormGroup>this.getFormGroup(row, index);
    if(!formGroup) {
      console.log("Edit Grid Column : Could not find form Group of column: "+ column);
      return;
    }
    formGroup.patchValue(row);
    formGroup.controls[column].markAsDirty();
    formGroup.controls[column].markAsTouched();
    //console.log(column + " change " + val);
  }
  /**
   * This is used to get the formGroup of that particular row
   * @param row 
   * @param index 
   */
  private getFormGroup(row: any, index: number) {
    const data = (<FormArray>this.PanelFormArray.controls[index].get('nutritionalInfoList')).controls.find(item => {
      var formGroup = <FormGroup>item;
      return formGroup.controls["nutrDictionaryID"].value == row.nutrDictionaryID;
    })
    return data;
  }

}
