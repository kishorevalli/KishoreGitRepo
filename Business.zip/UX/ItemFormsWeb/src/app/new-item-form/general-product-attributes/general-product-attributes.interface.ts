import { IItemFormDto, ItemFormDto, UserType } from '../new-item-form.interface';


type CharBoolean = 'Y' | 'N';
export interface IGeneralProductAttributes {
    itemFormID: number;
    perishableItem: string;
    productDate: string;
    bornOnDays: number;
    countryOfOrigin: string;    
    ignitable: CharBoolean;
    corrosive: CharBoolean;
    reactive: CharBoolean;
    toxic: CharBoolean;
    epaListedWaste: CharBoolean;
    containsBattery: CharBoolean;
    eMailForBatterySurvey: string;
    deaRegulated: CharBoolean;
    narcotic: CharBoolean;
    drugScheduleCode: string;
    ndcNumber: number;
    ndcFormat: string;
    ndcFormatDescription: string;
    disinfectant: CharBoolean;
    allergic: string;
    glutenFree: CharBoolean;
    organicTypesID: number;
    greenLeaf: CharBoolean;
    pesticide: CharBoolean;
    liquor: CharBoolean;
    liquorDescription: string;
    tobacco: CharBoolean;
    variableWeightIndicator: CharBoolean;
    randomWeight: CharBoolean;
    foodStamp: CharBoolean;
    unitPricingCount: number;
    unitPricingUOM: string;
    tagCount: number;
    tagSize: string;
    seasonalItem: CharBoolean;
    seasonBeginDate: string;
    seasonEndDate: string;
    minDaysRequired: number;
    maxDaysRequired: number;
    whseShelfLife: number;
    ignoreQuantityCheck: CharBoolean;
    bioFlag: CharBoolean;
    activationProtectionEndDate: string;
    manuallyOrderedItem: CharBoolean;
    nutritionalPanelTypeID: number;
    nutritionalInfoNotAvailableUntil: string;
    isDirty: boolean;
    formStatusID: number;
    formActionID: number;
    submittedUserTypeID: UserType;
    nutritionalPanelList: INutritionalPanel[];
    retailPackagedItem: string;
}
export class GeneralProductAttributes implements IGeneralProductAttributes {
    itemFormID: number;
    perishableItem: string;
    productDate: string;
    bornOnDays: number;
    countryOfOrigin: string;    
    ignitable: CharBoolean;
    corrosive: CharBoolean;
    reactive: CharBoolean;
    toxic: CharBoolean;
    epaListedWaste: CharBoolean;
    containsBattery: CharBoolean;
    eMailForBatterySurvey: string;
    deaRegulated: CharBoolean;
    narcotic: CharBoolean;
    drugScheduleCode: CharBoolean;
    ndcNumber: number;
    ndcFormat: string;
    ndcFormatDescription: string;
    disinfectant: CharBoolean;
    allergic: string;
    glutenFree: CharBoolean;
    organicTypesID: number;
    greenLeaf: CharBoolean;
    pesticide: CharBoolean;
    liquor: CharBoolean;
    liquorDescription: string;
    tobacco: CharBoolean;
    variableWeightIndicator: CharBoolean;
    randomWeight: CharBoolean;
    foodStamp: CharBoolean;
    unitPricingCount: number;
    unitPricingUOM: string;
    tagCount: number;
    tagSize: string;
    seasonalItem: CharBoolean;
    seasonBeginDate: string;
    seasonEndDate: string;
    minDaysRequired: number;
    maxDaysRequired: number;
    whseShelfLife: number;
    ignoreQuantityCheck: CharBoolean;
    bioFlag: CharBoolean;
    activationProtectionEndDate: string;
    manuallyOrderedItem: CharBoolean;
    nutritionalPanelTypeID: number;
    nutritionalInfoNotAvailableUntil: string;
    isDirty: boolean;
    formStatusID: number;
    formActionID: number;
    submittedUserTypeID: UserType;
    nutritionalPanelList: INutritionalPanel[];
    retailPackagedItem: string;
}
export interface INutritionalPanel {
    id: number;
    itemFormID: number;
    nutritionalPanelName: string;
    formattedGtin: string;
    gtinCheckDigit: number;
    containsAllergen : CharBoolean;
    servingSize: string;
    servingsPerContainer: number;
    isDirty: boolean;
    isDeleted: boolean;  
    sortOrder: number;
    nutritionalInfoList: INutritionalInfo[];
    nutritionalAllergenInfoList: INutritionalAllergenInfo[];
}
export class NutritionalPanel implements INutritionalPanel {
    id: number;
    itemFormID: number;
    nutritionalPanelName: string;
    formattedGtin: string;
    gtinCheckDigit: number;
    containsAllergen : CharBoolean;
    servingSize: string;
    servingsPerContainer: number;
    isDirty: boolean;
    isDeleted: boolean;   
    sortOrder: number;
    nutritionalInfoList: INutritionalInfo[];
    nutritionalAllergenInfoList: INutritionalAllergenInfo[]; 
}
export interface INutritionalInfo {
    id: number;
    nutritionalPanelID: number;
    nutrDictionaryID: number;
    nutrientName : string;
    quantity: number;
    uom: string;
    uomDescription : string;
    dailyValuePercentage : number;
    isRequired : CharBoolean;
    sortOrder: number;
}
export class NutritionalInfo implements INutritionalInfo {
    id: number;
    nutritionalPanelID: number;
    nutrDictionaryID: number;
    nutrientName : string;
    quantity: number;
    uom: string;
    uomDescription : string;
    dailyValuePercentage : number;
    isRequired : CharBoolean;
    sortOrder: number;
}
export interface INutritionalAllergenInfo {
    id: number;
    nutritionalPanelID: number;
    nutrDictionaryID: number;
    allergenName : string;
    value: CharBoolean;
    sortOrder: number;
}
export class NutritionalAllergenInfo implements INutritionalAllergenInfo {
    id: number;
    nutritionalPanelID: number;
    nutrDictionaryID: number;
    allergenName : string;
    value: CharBoolean;
    sortOrder: number;
}

export interface IDrugScheduleCode {
    id: number;
    drugScheduleCode: string;
    narcotic: boolean;
}

export class DrugScheduleCode {
    id: number;
    drugScheduleCode: string;
    narcotic: boolean;
}

export interface IVariableWeightIndicator {
    id: number;
    code: string;
    shortDescription: string;
    description: string;
    validForShipper: boolean;
}

export class VariableWeightIndicator {
    id: number;
    code: string;
    shortDescription: string;
    description: string;
    validForShipper: boolean;
}

export interface IUnacceptableIngredient {
    id: number;
    ingredient: string;
    description: string;
}

export class UnacceptableIngredient {
    id: number;
    ingredient: string;
    description: string;
}




