import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { GeneralProductAttributesService } from '../general-product-attributes.service';
import { GridEvent } from '../../../shared/grid/grid-event'
import { IUnacceptableIngredient } from '../general-product-attributes.interface';


@Component({
  selector: 'ifw-dialog-lookup-ingredients',
  templateUrl: './dialog-lookup-ingredients.component.html',
  styleUrls: ['./dialog-lookup-ingredients.component.scss']
})
export class DialogLookupIngredientsComponent implements OnInit {

  public unacceptableIngredientList: IUnacceptableIngredient[];
  public data: IUnacceptableIngredient[]; // used to hold shallow copy of grid data of each tab.
  length: number; // used to hold count of the entire grid data. 
  pageSize: number;
  showSpinner: boolean = false;

  constructor(private generalproductAttributesService: GeneralProductAttributesService) { }

  ngOnInit() {
    this.showSpinner = true;
    this.generalproductAttributesService.getUnacceptableIngredientList().subscribe(res => {
      this.showSpinner = false;
      this.unacceptableIngredientList = res;
      this.populateInitialGridData();
    },
      (err) => {
        this.showSpinner = false;
      });
  }
  /* grid variables */


  getGridData() {
    if (!this.data) return [];
    return this.data;
  }
  populateInitialGridData() {
    this.updateData({
      pageIndex: 0,
      pageSize: 10,
      length: 0,
      active: "",
      direction: "",
      filterBy: "",
      filterValue: ""
    });
  }
  updateData(gridEvent: GridEvent) {
    this.data = this.performFilter(gridEvent);
    this.sortData(gridEvent);
    this.pageData(gridEvent);
  }
  /**
  * return the filtered or shallow copy without changing the original data
  */
  performFilter(gridEvent: GridEvent): any[] {
    let filterBy = gridEvent.filterBy;
    let filterValue = gridEvent.filterValue;
    if (filterBy && filterBy.length > 0) {
      if (filterValue && filterValue.length > 0) {
        //console.log(this.filterValue);
        return this.unacceptableIngredientList.filter((row: any) => {
          // Transform the data into a lowercase string of property values.
         // const dataStr = ('' + row[filterBy]).toLowerCase();
          // Transform the data into a lowercase string of all property values.
          const accumulator = (currentTerm, key) => currentTerm + row[key];
          const dataStr = Object.keys(row).reduce(accumulator, '').toLowerCase();
          // Transform the filter by converting it to lowercase and removing whitespace.
          const transformedFilter = filterValue.trim().toLowerCase();
          return dataStr.indexOf(transformedFilter) != -1;
        }
        );
      }
      return this.unacceptableIngredientList.slice();
    }
    return this.unacceptableIngredientList.slice();
  }
  /**
   * sort the filtered result based on sort column and order
   */
  sortData(gridEvent: GridEvent) {
    let active = gridEvent.active;
    let direction = gridEvent.direction;
    let sortAsc = gridEvent.direction == 'asc';
    let sortDesc = gridEvent.direction == 'desc';
    if (!sortAsc && !sortDesc) return;
    this.data.sort((a, b) => {
      if (typeof a[gridEvent.active] === 'string') {
        return a[active].localeCompare(b[active]);
      } else {
        return a[active] - b[active];
      }
    });
    if (sortAsc === false) {
      this.data.reverse();
    }
  }
  /**
     * paginate the result set
     */
  pageData(gridEvent: GridEvent) {
    this.length = this.data.length;
    this.pageSize = gridEvent.pageSize;
    let pageIndex = gridEvent.pageIndex;
    let offset = pageIndex * this.pageSize;
    this.data = this.data.slice(offset, offset + this.pageSize);
  }
}
