import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormArray, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';

import { NewItemFormService } from '../new-item-form.service';
import { GeneralProductAttributesService } from './general-product-attributes.service';
import { BasicItemDefinitionService } from '../basic-item-definition/basic-item-definition.service';
import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto } from '../../shared/common.interface';
import { IGeneralProductAttributes, INutritionalAllergenInfo, NutritionalAllergenInfo, INutritionalInfo, NutritionalInfo, INutritionalPanel, IDrugScheduleCode, IVariableWeightIndicator } from './general-product-attributes.interface';
import { NutritionPanelComponent } from './nutrition-panel/nutrition-panel.component';
import { DialogLookupIngredientsComponent } from './dialog-lookup-ingredients/dialog-lookup-ingredients.component';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { IItemFormDto, ItemFormDto, UserType, IGTINWithCheckdigitDto } from '../new-item-form.interface';
import * as _moment from 'moment';
const moment = _moment;

@Component({
  selector: 'ifw-general-product-attributes-buyer',
  templateUrl: './general-product-attributes-buyer.component.html',
    styleUrls: ['./general-product-attributes.component.scss']
})
export class GeneralProductAttributesBuyerComponent implements OnInit {

    itemFormDisplayID: number;
    public itemFormID: number;
    GPABuyerFormGroup: FormGroup;
    isContainsBatteryChecked: boolean = false;
    inputFieldColor = "custom-input-field-color";
    showSpinner: boolean = false;
    //Lookup dropdownlist
    public organicTypesList: ILookupIntDto[];
    public drugScheduleCodesList: IDrugScheduleCode[];
    public filteredDrugScheduleCodesList: IDrugScheduleCode[];
    public nutritionalPanelTypesList: ILookupIntDto[];
    public productDateTypesList: ILookupDto[];
    public ndcFormatsList: ILookupDto[];
    public listAllergens: INutritionalAllergenInfo[];
    public listNutrients: INutritionalInfo[];
    // **** START Buyer specific lookups
    public sizeUomList: ILookupDto[];
    public variableWeightIndicatorsList: ILookupDto[];
    public liquorTypesList: ILookupDto[];
    public shelfTagSizesList: ILookupDto[];
    // **** END Buyer specific lookups

    public existingPanels: INutritionalPanel[];
    public clearedPanels: INutritionalPanel[];
    public errors: string[];
    public formErrors: any;
    public defaultDate:Date;
    public futureDate:Date;
    public future6MonthsDate:Date;
    public itemFormDto: IItemFormDto;
    skipSaveTab: boolean = false;
    public isShipper: boolean = false;
    public isRetail: boolean = false;
    public isType2Gtin: boolean = false;
    public manuallyOrderedItem: string = 'N';
    public GTINList: IGTINWithCheckdigitDto[];
    public isReadOnly: boolean = false; 
    @ViewChild(NutritionPanelComponent) panel: NutritionPanelComponent;

    // public dialog: MatDialog;

    constructor(private fb: FormBuilder,
        public dialog: MatDialog,
        private newItemFormService: NewItemFormService,
        private generalproductAttributesService: GeneralProductAttributesService,
        private basicItemDefService: BasicItemDefinitionService,
        public snackBar: MatSnackBar,
        private router: Router,
        private route: ActivatedRoute,
    ) { }


    ngOnInit() {
        //Initialize
        this.listAllergens = [];
        this.listNutrients = [];
        this.existingPanels = [];
        this.clearedPanels = [];
        this.errors = [];
        this.formErrors = {};

        this.defaultDate = moment().toDate();
        this.futureDate = moment().add(1,"days").toDate();
        this.future6MonthsDate = moment().add(6,"months").toDate();

        this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        this.itemFormID = this.newItemFormService.itemFormID;
        this.isReadOnly = this.newItemFormService.isReadOnly;
        this.isShipper = this.newItemFormService.isShipper();
        this.isRetail = this.newItemFormService.isRetail();
        this.isType2Gtin = this.newItemFormService.isType2Gtin();
        const itemTypeCode = this.newItemFormService.itemTypeCode;
        console.log("itemTypeCode "+ itemTypeCode);
        if(itemTypeCode == "RS" || itemTypeCode == "RM" || itemTypeCode == "SI"){
            this.manuallyOrderedItem = 'Y';
        }
        //console.log("isShipper : "+ this.isShipper);
        this.createForm();

        this.generalproductAttributesService.getOrganicTypes().subscribe(res => {
            this.organicTypesList = res.map(ot => ({ code: Number(ot.code), description: ot.description }))
        });
        this.generalproductAttributesService.GetNutrientDetails().subscribe(res => {
            this.listNutrients = res;
        });
        this.generalproductAttributesService.GetAllergensDetails().subscribe(res => {
            this.listAllergens = res;
        });
        this.generalproductAttributesService.GetDrugScheduleCodes().subscribe(res => {
            this.drugScheduleCodesList = res.map(dsc => ({ id: dsc.id, drugScheduleCode: dsc.drugScheduleCode, narcotic: dsc.narcotic }));
            this.filteredDrugScheduleCodesList = this.drugScheduleCodesList.slice();
        });
        this.generalproductAttributesService.getNutritionalPanelTypes().subscribe(res => {
            this.nutritionalPanelTypesList = res.map(nt => ({ code: Number(nt.code), description: nt.description }))
        });
        this.generalproductAttributesService.getProductDateTypes().subscribe(res => {
            this.productDateTypesList = res.map(nt => ({ code: nt.code, description: nt.description }))
        });

        this.generalproductAttributesService.getNDCFormats().subscribe(res => {
            this.ndcFormatsList = res.map(nt => ({ code: nt.code, description: nt.description }))
        });
        /*** Buyer specific lookups */
        this.basicItemDefService.getUnitOfMeasures().subscribe(res => {
            this.sizeUomList = res;
        });
        this.generalproductAttributesService.getVariableWeightIndicators().subscribe(res => {
            let variableWeightIndicator:IVariableWeightIndicator[] = res.filter(item => {
                return (!this.isShipper || (this.isShipper && item.validForShipper == true));
            });
            this.variableWeightIndicatorsList = variableWeightIndicator.map(nt => ({ code: nt.code, description: nt.shortDescription }))
        });
        this.generalproductAttributesService.getLiquorTypes().subscribe(res => {
            this.liquorTypesList = res.map(nt => ({ code: nt.code, description: nt.description }))
        });
        this.generalproductAttributesService.getShelfTagSizes().subscribe(res => {
            this.shelfTagSizesList = res.map(nt => ({ code: nt.code, description: nt.description }))
        });
        this.newItemFormService.GetBasicItemDefinitionGTIN(this.itemFormID).subscribe(res =>{
            this.GTINList = res;
        });
        
        this.subscribeBatteryChanges();
        this.subscribeNarcoticChanges();
        this.subscribeProductDateChanges();
        this.GetGeneralProductAttributes(this.itemFormID, false);
    }
    ngAfterViewInit() {
        console.log("ngAfterViewInit.");
    }
    createForm() {
        this.GPABuyerFormGroup = this.fb.group({
            itemFormID: this.itemFormID,
            perishableItem: '',
            productDate: '',
            bornOnDays: '',
            countryOfOrigin: '',
            hazardous: 'N',
            ignitable: '',
            corrosive: '',
            reactive: '',
            toxic: '',
            epaListedWaste: '',
            containsBattery: '',
            eMailForBatterySurvey: '',
            deaRegulated: '',
            narcotic: '',
            drugScheduleCode: '',
            ndcNumber: '',
            ndcFormat: '',
            ndcFormatDescription: '',
            disinfectant: '',
            allergic: '',
            glutenFree: 'N',
            organicTypesID: 4,
            pesticide: '', 
            /**** START ***Buyer specific fields *****/
            greenLeaf: "",
            liquor: "",
            liquorDescription: "",
            tobacco:"",
            variableWeightIndicator:"N", // N/F/A. Must be N or F for shipper
            randomWeight: this.isType2Gtin? "Y":"", // This is "Y" for type-2 GTIN`s
            foodStamp: null, // Y/N only for retail items
            unitPricingCount: this.newItemFormService.size || null, // Default to Size in BID
            unitPricingUOM: this.newItemFormService.sizeUOM || '', // Default to size UOM in BID
            tagCount: null,
            tagSize: null,
            seasonalItem:"",
            seasonBeginDate:null,
            seasonEndDate:null,
            minDaysRequired: "",
            maxDaysRequired:"",
            whseShelfLife:"",
            ignoreQuantityCheck:"", // This is for a retail item. Should be empty for Non-retail item
            bioFlag: "",
            activationProtectionEndDate: "", // Must be between current date and + 6 months
            manuallyOrderedItem: this.manuallyOrderedItem, //If item type is "RS","RM","SI", then set to "Y"
             /**** END ***Buyer specific fields *****/
            nutritionalInfoNotAvailableUntil: '',
            nutritionalPanelTypeID: 5,
            isDirty: false,
            nutritionalPanelList: this.fb.array([]),
        });
    }
    private GetGeneralProductAttributes(itemFormID: number, afterSave: boolean) {
        this.generalproductAttributesService.GetGeneralProductAttributes(this.itemFormID).subscribe(res => {
            this.GPABuyerFormGroup.markAsPristine();
            this.GPABuyerFormGroup.markAsUntouched();
            this.GPABuyerFormGroup.patchValue(res);
            if(this.isType2Gtin){
                this.GPABuyerFormGroup.controls.randomWeight.setValue("Y");
                this.GPABuyerFormGroup.controls.randomWeight.markAsDirty();
            }
            if(this.manuallyOrderedItem == "Y"){
                this.GPABuyerFormGroup.controls.manuallyOrderedItem.setValue("Y");
                this.GPABuyerFormGroup.controls.manuallyOrderedItem.markAsDirty();
            }
            //reset the current form status ID in new item form service.
            this.newItemFormService.formCurrentStatusID = res.formStatusID;
            this.existingPanels = res.nutritionalPanelList;
            if (this.existingPanels && this.existingPanels.length > 0) {
                this.showNutritionPanel = true;
            }
            console.log("GetGeneralProductAttributes");
            if (afterSave) {
                this.showSpinner = false;
                const validations: any = this.newItemFormService.getItemValidation("General Product Attributes");
                if (validations) {
                    this.handleItemGpaValidation(validations);
                }
            }
            else {
                setTimeout(() => {
                    const validations: any = this.newItemFormService.getItemValidation("General Product Attributes");
                    if (validations) {
                        console.log("validations running.")
                        this.handleItemGpaValidation(validations);
                    }
                }, 0);
            }
        },
            (err) => {
                this.showSpinner = false;
            });
    }
    reset() {
        this.resetToInitialState();
        this.GetGeneralProductAttributes(this.itemFormID, false);
    }
    resetToInitialState() {
        //this.GPABuyerFormGroup.reset();
        this.GPABuyerFormGroup.markAsPristine();
        this.GPABuyerFormGroup.markAsUntouched();
        this.GPABuyerFormGroup.patchValue({
            itemFormID: this.itemFormID,
            perishableItem: '',
            productDate: '',
            bornOnDays: '',
            countryOfOrigin: '',
            hazardous: 'N',
            ignitable: '',
            corrosive: '',
            reactive: '',
            toxic: '',
            epaListedWaste: '',
            containsBattery: '',
            eMailForBatterySurvey: '',
            deaRegulated: '',
            narcotic: '',
            drugScheduleCode: '',
            ndcNumber: '',
            ndcFormat: '',
            ndcFormatDescription: '',
            disinfectant: '',
            allergic: '',
            glutenFree: 'N',
            organicTypesID: 4,
            pesticide: '',
            liquor: "",
            liquorDescription: "",
            unitPricingUOM: "",
            tagSize: "",
            nutritionalInfoNotAvailableUntil: '',
            nutritionalPanelTypeID: 5,
            isDirty: false
        });
        this.GPABuyerFormGroup.setControl('nutritionalPanelList', this.fb.array([]));
        this.showNutritionPanel = false;
    }
    subscribeBatteryChanges() {
        const eMailForBatterySurvey = this.GPABuyerFormGroup.controls.eMailForBatterySurvey;
        // initialize value changes stream
        const changes$ = this.GPABuyerFormGroup.controls.containsBattery.valueChanges;
        // subscribe to the stream
        changes$.subscribe(containsBattery => {
            // Yes
            if (containsBattery === 'Y') {
                eMailForBatterySurvey.setValidators([Validators.email]);
            }
            else {
                eMailForBatterySurvey.patchValue('');
                eMailForBatterySurvey.setValidators([]);
            }
            eMailForBatterySurvey.updateValueAndValidity();
        });
    }
    subscribeNarcoticChanges() {
        const drugScheduleCode = this.GPABuyerFormGroup.controls.drugScheduleCode;
        // initialize value changes stream
        const changes$ = this.GPABuyerFormGroup.controls.narcotic.valueChanges;
       // subscribe to the stream
        changes$.subscribe(narcoticValue => {
            // Yes
            if (narcoticValue === 'Y') {
                //drugScheduleCode.setValue('');                
                this.filteredDrugScheduleCodesList = this.drugScheduleCodesList.filter(item => {
                    return (item.narcotic == true);
                });
            }
            else {
                this.filteredDrugScheduleCodesList = this.drugScheduleCodesList;
            }           
        });
    }
    subscribeProductDateChanges() {
        const bornOnDays = this.GPABuyerFormGroup.controls.bornOnDays;
        bornOnDays.disable();
        // initialize value changes stream
        const changes$ = this.GPABuyerFormGroup.controls.productDate.valueChanges;
       // subscribe to the stream
        changes$.subscribe(productDate => {
             // Yes
            if (productDate === 'M') {
                bornOnDays.enable();
                bornOnDays.setValidators(Validators.required);
            }
            else {
                bornOnDays.setValue('');
                bornOnDays.setValidators([]);
                bornOnDays.disable();
            }
            bornOnDays.updateValueAndValidity();
        });
    }
   get seasonalItem(): string {
        return this.GPABuyerFormGroup.controls.seasonalItem.value;
   } 

    clearDate(ctrlName: string) {
        const formControl = this.GPABuyerFormGroup.get(ctrlName);
        formControl.patchValue('');
        formControl.markAsDirty();
        formControl.markAsTouched();
    }
    changeDEARegulated(val: string) {
        if (val == "N") {
            this.GPABuyerFormGroup.patchValue({
                narcotic: '',
                drugScheduleCode: '',
                ndcNumber: '',
                ndcFormat: '',
                ndcFormatDescription: '',
            });
        }
    }
    changeNarcotic(val: string) {
        //Narcotic -- can be 'Y' only when the drug schedule is 2 or 3
        if (val == "Y") {
            var formControl = this.GPABuyerFormGroup.get("drugScheduleCode");
            formControl.patchValue('');
            //if(formControl.value != "2" && formControl.value != "3"){
            //    formControl.patchValue('');
            //}
            this.filteredDrugScheduleCodesList = this.drugScheduleCodesList.filter(item => {
                return (item.narcotic == true);
            });
        }
        else {
            this.filteredDrugScheduleCodesList = this.drugScheduleCodesList.slice();
        }
    }
    changeSeasonalItem(val: string) {
        if (val == "N") {
            this.GPABuyerFormGroup.patchValue({
                seasonBeginDate: '',
                seasonEndDate: '',
            });
        }
    }
    showNutritionPanel: boolean = false;
    changeNutritionPanelType(val: number) {
        if (val == 1) {
            this.showNutritionPanel = true;
        }
        else {
            this.showNutritionPanel = false;
            this.clearFormArray(<FormArray>this.GPABuyerFormGroup.get('nutritionalPanelList'))
        }
    }
    clearFormArray = (formArray: FormArray) => {
        while (formArray.length !== 0) {
            formArray.removeAt(0);
        }
        // Move all the existing panels to the clearedPanels to send them to API as deleted
        for (const clrPanel of this.existingPanels) {
            this.clearedPanels.push({
                id: clrPanel.id,
                itemFormID: clrPanel.itemFormID,
                nutritionalPanelName: clrPanel.nutritionalPanelName,
                formattedGtin:'',
                gtinCheckDigit: null,
                containsAllergen: 'N',
                servingSize: '',
                servingsPerContainer: null,
                isDirty: true,
                isDeleted: true,
                sortOrder: 0,
                nutritionalInfoList: null,
                nutritionalAllergenInfoList: null
            });
        }
        this.existingPanels = [];
    }
    //changeYNValue(val:boolean, formControl: FormControl){
    //    formControl.patchValue(val?'Y':'N');
    //    formControl.markAsDirty();
    //    formControl.markAsTouched();
    //    this.updateHazardousFlag();
    //}
    //updateHazardousFlag() {
    //    const hazardousItems = ['ignitable', 'corrosive', 'reactive', 'toxic', 'epaListedWaste', 'containsBattery']
    //    const hazardousYes = hazardousItems.find(item => {
    //        const formControl = this.GPABuyerFormGroup.get(item);
    //        return formControl.value == "Y";
    //    })
    //    if (hazardousYes) {
    //        this.GPABuyerFormGroup.patchValue({ 'hazardous': 'Y' });
    //    }
    //    else {
    //        this.GPABuyerFormGroup.patchValue({ 'hazardous': 'N' });
    //    }
    //}
    checkIfPastDateEntered(): boolean {
        const nutritionalInfoNotAvailableUntilCtrl = this.GPABuyerFormGroup.controls.nutritionalInfoNotAvailableUntil;
        const activationProtectionEndDateCtrl = this.GPABuyerFormGroup.controls.activationProtectionEndDate;
        // const newValue = nutritionalInfoNotAvailableUntilCtrl.value;
        if (nutritionalInfoNotAvailableUntilCtrl.dirty && nutritionalInfoNotAvailableUntilCtrl.invalid) {
            return false;
        }
        if(activationProtectionEndDateCtrl.dirty && activationProtectionEndDateCtrl.invalid){
            return false;
        }
        return true;

       
    }
    checkIfDirty() {
        // Set if any GPA is dirty
        this.GPABuyerFormGroup.patchValue({ 'isDirty': this.GPABuyerFormGroup.dirty });
        // Set if any specific nutritional panel is dirty  
        var formArray = (<FormArray>this.GPABuyerFormGroup.get('nutritionalPanelList'));
        for (let idx = 0; idx < formArray.controls.length; idx++) {
            var formGroup = formArray.controls[idx];
            formGroup.patchValue({ 'isDirty': formGroup.dirty });
        }
    }
    getGPADropdownSelectionData(generalProductAttributes:IGeneralProductAttributes): void {
        // Code here if any description fields need to be populated
        if (generalProductAttributes.liquor && this.liquorTypesList) {
            const liquorTypeLookupDto = this.liquorTypesList.find(x => x.code == generalProductAttributes.liquor);
            generalProductAttributes.liquorDescription= (liquorTypeLookupDto)? liquorTypeLookupDto.description : generalProductAttributes.liquor;
        }
        if (generalProductAttributes.ndcFormat && this.ndcFormatsList) {
            const ndcFormatLookupDto = this.ndcFormatsList.find(x => x.code == generalProductAttributes.ndcFormat);
            generalProductAttributes.ndcFormatDescription = (ndcFormatLookupDto)? ndcFormatLookupDto.description : generalProductAttributes.ndcFormat;
        }
    }
    performAction(action: any) {
        switch (action.actionName) {
            case "Save":
                this.saveGeneralProductAttributes(action.createdFormStatusID, action.actionID);
                break;
            case "Delete":
                this.deleteItemForm();
                break;
            case "Submit":  // Create Item for buyer is only from Review screen.
               // this.submitGeneralProductAttributes(action.createdFormStatusID, action.actionID);
                break;

        }
    }

    public saveGeneralProductAttributes(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            if (res) {
                this.GetGeneralProductAttributes(this.itemFormID, true);
            }
        });
    }

    public submitGeneralProductAttributes(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
                this.GetGeneralProductAttributes(this.itemFormID, true);
            });
            if (res) {
                this.snackBar.open("Submitted successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
            else {
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
        });
    }

    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
        if (this.skipSaveTab || this.isReadOnly) return of(true);
        this.errors = [];
        var result = this.checkIfPastDateEntered();
        if (!result) {
            this.snackBar.open("Please correct the errors.", null, {
                duration: 3000,
                horizontalPosition: this.horizontalPosition,
                verticalPosition: this.verticalPosition,
            });
            return of(false);
        }
        this.checkIfDirty();
        // Getting the deleted panels by clicking delete button on the nutritional panel
        const deletedPanels = (this.panel) ? this.panel.deletedPanels : [];
        // clicking delete button will not trigger the dirty flag. so updating this manually. 
        if (deletedPanels.length > 0) {
            this.GPABuyerFormGroup.patchValue({ 'isDirty': true });
        }
        const generalProductAttributes: IGeneralProductAttributes = (<any>Object).assign({}, this.GPABuyerFormGroup.value);
        // Use Spread operator to merge the deleted list with flag
        generalProductAttributes.nutritionalPanelList.push(...deletedPanels, ...this.clearedPanels);
        this.showSpinner = true;
        if (this.panel) {
            this.panel.clearPanelErrorList();
        }

        //if createdFormStatusID is 0 (when changing tab) , send the currentstatus .
        createdFormStatusID = createdFormStatusID == undefined ? this.newItemFormService.formCurrentStatusID : createdFormStatusID;
        generalProductAttributes.formStatusID = createdFormStatusID;
        generalProductAttributes.formActionID = actionID;
        generalProductAttributes.submittedUserTypeID = UserType.Buyer;
        //Get the user dropdown selection data
        this.getGPADropdownSelectionData(generalProductAttributes);
        generalProductAttributes.retailPackagedItem = this.newItemFormService.retailPackagedItem;
        this.newItemFormService.showLoadingSpinner = true;
        return this.generalproductAttributesService.SaveGeneralProductAttributes(generalProductAttributes).pipe(
            map(res => {
                this.newItemFormService.showLoadingSpinner = false;
                if (res.validation) //In submit , validation object will be null.
                    this.newItemFormService.addItemValidation(res.validation);
                if(res.status)
                    this.newItemFormService.formCurrentStatusID = createdFormStatusID;

                //console.log("saved successfully.");
                this.showSpinner = false;
                return res.status;
            }),
            catchError((err) => {
                this.newItemFormService.showLoadingSpinner = false;
                this.showSpinner = false;
                if (err.status === 400) {
                    this.newItemFormService.addItemValidation(err.error);
                    this.handleItemGpaValidation(err.error);
                }
                else {
                    this.errors.push("Unhandled expection occured.");
                }
                console.log("saved error. " + err.status);
                window.scrollTo(0, 150);
                this.snackBar.open("Please correct the errors.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: this.verticalPosition,
                });
                return of(false);
            })
        );
    }
    public openLookupIngredients(){
        let dialog = this.dialog.open(DialogLookupIngredientsComponent);
    }
    public deleteItemForm(): void {
        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.showSpinner = true;
                this.newItemFormService.deleteItemForm().subscribe(res => {

                    this.showSpinner = false;
                    if (res != undefined) {
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" });
                },
                    (err) => {
                        this.showSpinner = false;
                        if (err.status === 400) {
                            // handle validation error
                            let validationErrorDictionary = err.error.modelState;
                            this.handleGpaValidationErrors(validationErrorDictionary);
                        } 
                        else if (err.status === 401) {
                            console.log("saved error. " + err.status);
                            let message = err.error.exceptionMessage || err.error.message;
                            this.errors.push(message);
                        }
                        else {
                            this.errors.push("Unhandled expection occured.");
                        }
                        window.scrollTo(0, 0);
                    })
            }
        });
    }

    getErrorMessage(control: FormControl, name: string) {
        for (let propertyName in control.errors) {
            if ((propertyName == "invalid" || propertyName == "warning") && this.formErrors[name]) {
                return this.formErrors[name];
            }
        }
        return null;
    }
    handleItemGpaValidation(itemValidation) {
        let gpaErrors = itemValidation.errors;
        let gpaWarnings = itemValidation.warnings;
        this.handleGpaValidationErrors(gpaErrors);
        this.handleGpaValidationWarnings(gpaWarnings);
        let validationPanelErrors = itemValidation.subTabValidations;
        if (this.panel) {
            this.panel.handleValidationErrors(validationPanelErrors);
        }
    }
    handleGpaValidationErrors(gpaErrors: any[]) {

        for (var key in gpaErrors) {
            let errorObj = gpaErrors[key];
            //for (var errorObj of gpaErrors) {
            let fieldName = errorObj.controlName;
            if (fieldName) {
                if (this.GPABuyerFormGroup.controls[fieldName]) {

                    this.GPABuyerFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.GPABuyerFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;

                }
            }
        }
    }
    handleGpaValidationWarnings(gpaErrors: any[]) {

        for (var key in gpaErrors) {
            let errorObj = gpaErrors[key];
            //for (var errorObj of gpaErrors) {
            let fieldName = errorObj.controlName;
            if (fieldName) {
                if (this.GPABuyerFormGroup.controls[fieldName]) {
                    this.GPABuyerFormGroup.controls[fieldName].setErrors({ warning: true });
                    this.GPABuyerFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;

                }
            }
        }
    }

    /*showEmailasInvalid(){
        const fieldName = "eMailForBatterySurvey";
        this.GPABuyerFormGroup.controls[fieldName].setErrors({ invalid: true });
        this.GPABuyerFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
        this.formErrors[fieldName] = "Please enter the email address";
    }
    showEmailasWarning(){
        const fieldName = "eMailForBatterySurvey";
        this.GPABuyerFormGroup.controls[fieldName].setErrors({ warning: true });
        this.GPABuyerFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
        this.formErrors[fieldName] = "Please enter the email address";
    }*/
    //onChanges(): void {
    //    this.GPABuyerFormGroup.get('EPAGroup').get('ContainsBattery').valueChanges.subscribe(val => {
    //        this.isContainsBatteryChecked = val;        })

    //}

}
