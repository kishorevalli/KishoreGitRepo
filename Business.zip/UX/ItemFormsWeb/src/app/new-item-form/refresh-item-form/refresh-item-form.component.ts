import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import { NewItemFormService } from '../new-item-form.service';

@Component({
  selector: 'ifw-refresh-item-form',
  templateUrl: './refresh-item-form.component.html',
  styleUrls: ['./refresh-item-form.component.scss']
})
export class RefreshItemFormComponent implements OnInit {

  constructor(
    private router: Router,
    public newItemFormService: NewItemFormService) { }

  ngOnInit() {
    this.newItemFormService.setRefreshItemFormID();
    this.router.navigate(['/new-item-form/buyer/'+this.newItemFormService.refreshItemFormUrl], { queryParamsHandling: "merge" });
  }

}
