import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NewItemFormComponent } from './new-item-form.component';
import { BasicItemDefinitionBuyerComponent } from './basic-item-definition/basic-item-definition-buyer.component';
import { BasicItemDefinitionVendorComponent } from './basic-item-definition/basic-item-definition-vendor.component';
import { GeneralProductAttributesVendorComponent } from './general-product-attributes/general-product-attributes-vendor.component';
import { PackagingHierarchyBuyerComponent } from './packaging-hierarchy/packaging-hierarchy-buyer.component';
import { PackagingHierarchyVendorComponent } from './packaging-hierarchy/packaging-hierarchy-vendor.component';
import { DsdAuthorizationRequestVendorComponent } from './dsd-authorization-request/dsd-authorization-request-vendor.component';
import { DsdAuthorizationRequestBuyerComponent } from './dsd-authorization-request/dsd-authorization-request-buyer.component';
import { GeneralProductAttributesBuyerComponent } from './general-product-attributes/general-product-attributes-buyer.component';
import { ShipperItemCompositionVendorComponent } from './shipper-item-composition/shipper-item-composition-vendor.component';
import { ShipperItemCompositionBuyerComponent } from './shipper-item-composition/shipper-item-composition-buyer.component';
import { MarketingSupportBuyerComponent } from './marketing-support/marketing-support-buyer.component';
import { DsdBasicItemDefinitionComponent } from './dsd-authorization-request/dsd-basic-item-definition.component';
import { ProductGroupingBuyerComponent } from './product-grouping/product-grouping-buyer.component';
import { ProductGroupingVendorComponent } from './product-grouping/product-grouping-vendor.component';
import { ProductAttributesBuyerComponent } from './product-attributes/product-attributes-buyer.component';
import { ScaleItemDetailsBuyerComponent } from './scale-item-details/scale-item-details-buyer.component';
import { ReviewCreateItemBuyerComponent } from './review-create-item/review-create-item-buyer.component';
import { RefreshItemFormComponent } from './refresh-item-form/refresh-item-form.component';


import { PageNotFoundComponent } from '../shared/page-not-found.component';
import { SaveBeforeDeactivateGuard } from './common/guards/SaveBeforeDeactivateGuard';
import { InternalAuthGuard } from './common/guards/internal.guard';
import { VendorAuthGuard } from './common/guards/vendor.guard';

const VENDOR_TAB_ROUTES: Routes = [
  { path: '', redirectTo: 'basic-item-definition', pathMatch: 'full' },
  { path: 'basic-item-definition', component: BasicItemDefinitionVendorComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'general-product-attributes', component: GeneralProductAttributesVendorComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'shipper-item-composition', component: ShipperItemCompositionVendorComponent },
  { path: 'packaging-hierarchy', component: PackagingHierarchyVendorComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'dsd-authorization-request', component: DsdAuthorizationRequestVendorComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'marketing-support', component: MarketingSupportBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'product-grouping', component: ProductGroupingVendorComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'product-attributes', component: PageNotFoundComponent },
  { path: 'scale-item-attributes', component: PageNotFoundComponent },
  { path: 'review-create-item', component: PageNotFoundComponent },
];
const BUYER_TAB_ROUTES: Routes = [
  { path: '', redirectTo: 'basic-item-definition', pathMatch: 'full' },
  { path: 'basic-item-definition', component: BasicItemDefinitionBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'general-product-attributes', component: GeneralProductAttributesBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'shipper-item-composition', component: ShipperItemCompositionVendorComponent },
  { path: 'packaging-hierarchy', component: PackagingHierarchyBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'dsd-authorization-request', component: DsdAuthorizationRequestBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'marketing-support', component: MarketingSupportBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'product-grouping', component: ProductGroupingBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'product-attributes', component: ProductAttributesBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
    { path: 'scale-item-attributes', component: ScaleItemDetailsBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
    { path: 'extra-text', component: PageNotFoundComponent },
    { path: 'review-create-item', component: ReviewCreateItemBuyerComponent, canDeactivate:[SaveBeforeDeactivateGuard] },
];
const MFG_TAB_ROUTES: Routes = [
  { path: '', redirectTo: 'basic-item-definition', pathMatch: 'full' },
  { path: 'basic-item-definition', component: BasicItemDefinitionBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'general-product-attributes', component: GeneralProductAttributesBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'shipper-item-composition', component: ShipperItemCompositionVendorComponent },
  { path: 'packaging-hierarchy', component: PackagingHierarchyBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'dsd-authorization-request', component: DsdAuthorizationRequestBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'marketing-support', component: MarketingSupportBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'product-grouping', component: ProductGroupingVendorComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'product-attributes', component: ProductAttributesBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
  { path: 'scale-item-attributes', component: ScaleItemDetailsBuyerComponent, canDeactivate: [SaveBeforeDeactivateGuard] },
    { path: 'review-create-item', component: ReviewCreateItemBuyerComponent, canDeactivate:[SaveBeforeDeactivateGuard] },
];
const routes: Routes = [
  { path: 'vendor', component: NewItemFormComponent, children: VENDOR_TAB_ROUTES, canActivate: [VendorAuthGuard], },
  { path: 'buyer', component: NewItemFormComponent, children: BUYER_TAB_ROUTES, canActivate: [InternalAuthGuard], },
  { path: 'mfg', component: NewItemFormComponent, children: MFG_TAB_ROUTES, canActivate: [InternalAuthGuard], },
  { path: 'redirect', component: RefreshItemFormComponent, }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [
    VendorAuthGuard,
    InternalAuthGuard
  ]
})
export class NewItemFormRoutingModule { }
