import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormArray, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';

import { NewItemFormService } from '../new-item-form.service';
import { IItemFormDto, ItemFormDto, UserType, NewItemTab } from '../new-item-form.interface';
import { IProductGroupingDto, ProductGroupingDto, IProductGroupingLinearDto, ProductGroupingLinearDto, IProductGroupType, ProductGroupType } from './product-grouping.interface';
import { GridEvent } from '../../shared/grid/grid-event';
import { DialogProductGroupComponent } from './dialog-product-group/dialog-product-group.component';
import { DialogAdGroupComponent } from './dialog-ad-group/dialog-ad-group.component';
import { DialogPricingGroupComponent } from './dialog-pricing-group/dialog-pricing-group.component';
import { ProductGroupingService } from './product-grouping.service';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { DialogContentComponent } from '../basic-item-definition/dialog-content.component';
import { IItemValidationDTO } from '../../shared/common.interface';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';

@Component({
  selector: 'ifw-product-grouping-buyer',
  templateUrl: './product-grouping-buyer.component.html',
  styleUrls: ['./product-grouping-buyer.component.scss']
})
export class ProductGroupingBuyerComponent implements OnInit {
  public itemFormDisplayID: number;
  public itemFormID: number;
  public modelProductItemcode: number;
  public modelPackagingItemCode: number;
  public modelProductGroupItemCode: number;
  public count: number = 0;
  productGroupingList: IProductGroupingDto[] = [];
  productGroupingModelList: IProductGroupingDto[] = [];
  productGroupingModel3List: IProductGroupingDto[] = [];
  productGroupTypeList: IProductGroupType[] = []
  showSpinnerSearchButton: boolean = false;
  loadingInitData:boolean = false;
  private dirty:boolean = false;
  public errors: any[];
  public warnings: any[];
  constructor(private fb: FormBuilder,
    private newItemFormService: NewItemFormService,
    private productGroupingService: ProductGroupingService,
    public snackBar: MatSnackBar,
    public dialog: MatDialog, 
    private router: Router,) { }

  ngOnInit() {
    this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
    this.itemFormID = this.newItemFormService.itemFormID;
    this.modelProductItemcode = this.newItemFormService.modelProductItemcode;
    this.modelPackagingItemCode = this.newItemFormService.modelPackagingItemCode;
    this.errors = [];
    this.warnings = [];
    this.getProductGrouping();   
  }
  getProductGrouping(){
    this.loadingInitData = true;
    this.modelProductGroupItemCode = null;
    forkJoin(this.productGroupingService.GetProductGrouping(this.itemFormID).catch(this.emptyOnError),
      this.productGroupingService.GetProductGroupingByItemCode(this.modelProductItemcode, 1).catch(this.emptyOnError),
      this.productGroupingService.GetProductGroupingByItemCode(this.modelPackagingItemCode, 2).catch(this.emptyOnError))
      .subscribe(results => {
        this.loadingInitData = false;
        this.dirty = false;
        this.updateIsSelected(results[0]);
        this.productGroupingList = results[0]
        this.productGroupingModelList = [...results[1], ...results[2]];
        this.productGroupingList = this.mergeProductGroupingModelList(this.productGroupingList, this.productGroupingModelList);
        this.populateInitialGridData();
        setTimeout(() => { //TODO: check if this can be solved without setTimeout.
          const validations: IItemValidationDTO = this.newItemFormService.getItemValidation("Product Grouping");
          if (validations) {
            console.log("validations running.")
            this.handleValidationErrors(validations);
          }
        }, 0);
      });
  }
  /**
   * get all product group codes of the entered item code.
   */
  getProductGroupsItemCode() {
    if (this.modelProductGroupItemCode) {
      this.showSpinnerSearchButton = true;
      this.newItemFormService.isItemCodeValid(this.modelProductGroupItemCode).subscribe(isValid => {
        if (isValid) {
          this.productGroupingService.GetProductGroupingByItemCode(this.modelProductGroupItemCode, 3).subscribe(res => {
            this.showSpinnerSearchButton = false;
            if (!res) res = [];
            this.productGroupingModel3List = res;
            this.clearModelGroupCode3(this.productGroupingList);
            this.productGroupingList = this.mergeProductGroupingModelList(this.productGroupingList, this.productGroupingModel3List);
            this.populateInitialGridData();
          },
            (err) => {
              this.showSpinnerSearchButton = false;
              this.openSnackbar(err);
            });
        }
        else {
          this.showSpinnerSearchButton = false;
          this.openSnackbar("Invalid Item Code.");
        }
      },
        (err) => {
          this.showSpinnerSearchButton = false;
          this.openSnackbar(err);
        });
    }
  }
  /**
   * assign group code based on model group code
   * @param row 
   * @param modelGroupCode  //property used to assign the groupCode (modelgroupcode1,modelgroupcode2,..)
   * @param modelGroupDescription //property used to assign the groupDescription (modelGroupDescription1,modelGroupDescription2,..)
   */
  updateProductGroupCodeByItem(row: IProductGroupingDto, modelGroupCode: string, modelGroupDescription: string) {
    row.productGroupCode = row[modelGroupCode];
    row.productGroupDescription = row[modelGroupDescription];
    if(row.parents){
      for (let childRow of row.parents) {
        childRow.productGroupCode = childRow[modelGroupCode];
        childRow.productGroupDescription = childRow[modelGroupDescription];
        for (let grandChildRow of childRow.parents) {
          grandChildRow.productGroupCode = grandChildRow[modelGroupCode];
          grandChildRow.productGroupDescription = grandChildRow[modelGroupDescription];  
        }
      }
    }
    this.productGroupingList = this.removeDuplicates(this.productGroupingList); 
    this.dirty = true;
      this.populateInitialGridData();
      this.checkFAMProductGroup();
  }
  /**
   * Clear the product group codes of item code before assigning the retreived codes of new item code
   * @param productGroupingList 
   */
  clearModelGroupCode3(productGroupingList: IProductGroupingDto[]): IProductGroupingDto[]{
    for(let productGrouping of productGroupingList){
       productGrouping.modelGroupCode3 = null;
       productGrouping.modelGroupDescription3 = '';
       if(productGrouping.parents){
        productGrouping.parents = this.clearModelGroupCode3(productGrouping.parents);
       }       
    }
    return productGroupingList;
  }
  /**
   * Assign modelGroupCode1,modelGroupCode2,modelGroupCode3 in productGroupingList with group codes in productGroupingModelList
   * @param productGroupingList // This is the list of current product group codes assigned
   * @param productGroupingModelList // This is the model group codes of all/any item codes (Product, Packaging, Entered)
   */
  mergeProductGroupingModelList(productGroupingList: IProductGroupingDto[], productGroupingModelList: IProductGroupingDto[]): IProductGroupingDto[] {
    for (let productGrouping of productGroupingModelList) {
      let found = productGroupingList.find(item => item.productGroupType == productGrouping.productGroupType
                                            && !item.isNew && !item[`modelGroupCode${productGrouping.modelGroupCodeType}`]);
      if (found) {
        found[`modelGroupCode${productGrouping.modelGroupCodeType}`] = productGrouping.productGroupCode;
        found[`modelGroupDescription${productGrouping.modelGroupCodeType}`] = productGrouping.productGroupDescription;
        if(productGrouping.parents){
          found.parents = this.mergeProductGroupingModelList(found.parents, productGrouping.parents);
        }        
      }
      else {
        productGroupingList.push(this.addEmptyProductGroupWithModel(productGrouping));
      }
    }
    return productGroupingList;
  }
  /**
   * Create a dummy entry with product group type to display modelGroupCode values in the grid
   */
  addEmptyProductGroupWithModel(productGrouping: IProductGroupingDto){
    let productGroupingNew:IProductGroupingDto = new ProductGroupingDto();
    productGroupingNew.productGroupType = productGrouping.productGroupType;
    productGroupingNew.modelGroupCodeType = 0;
    productGroupingNew[`modelGroupCode${productGrouping.modelGroupCodeType}`] = productGrouping.productGroupCode;
    productGroupingNew[`modelGroupDescription${productGrouping.modelGroupCodeType}`] = productGrouping.productGroupDescription;
    productGroupingNew.isMandatory = productGrouping.isMandatory;
    productGroupingNew.isSelected = productGrouping.isMandatory;
    if(productGrouping.parents) {
      productGroupingNew.parents = [];
      for(var parentProductGrouping of productGrouping.parents){
        productGroupingNew.parents.push(this.addEmptyProductGroupWithModel(parentProductGrouping));
      }
    }
    return productGroupingNew;
  }
  /**
   * This is "Add Product Group" event
   */
  openProductGroupDialog() {
    let dialogRef = this.dialog.open(DialogProductGroupComponent, {
      width: "1000px"
    });
    const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {
      //console.log(result);
      if(result && result.length>0){
        this.productGroupingList = this.removeDuplicates([...this.productGroupingList,...result]);
        this.dirty = true;
        this.populateInitialGridData();
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      sub.unsubscribe();
      console.log('The dialog was closed');
      //console.log(result);
      if(result && result.length>0){
        // Add this to the list with out merging with model item codes
        this.productGroupingList = this.removeDuplicates([...this.productGroupingList,...result]);
          this.dirty = true;
          this.checkFAMProductGroup();
        this.populateInitialGridData();
      }
    });
  }

  /**
   * This is "Edit Product Group" event
   */
  editProductGroupDialog(data: IProductGroupingDto, index: number) {
    let dialogRef = this.dialog.open(DialogProductGroupComponent, {
      width: "1000px",
      data: data
    });
    dialogRef.afterClosed().subscribe(result => {
      if(result && result.length>0){
        let mergeResult = []
        for(let item of result){
          mergeResult.push(this.mergeEditProductGroup(item, data));
        }
        this.productGroupingList.splice(index, 1, ...mergeResult);
        // Add this to the list with out merging with model item codes
        this.productGroupingList = this.removeDuplicates(this.productGroupingList);
          this.dirty = true;
          this.checkFAMProductGroup();
        this.populateInitialGridData();
      }
    });
  }

    //Enable Product Attributes tab only if "FAM" product group type is added.
    checkFAMProductGroup(): void {
        let famGroup: boolean = false;
        let found  = this.productGroupingList.find(pg => pg.productGroupType == 'FAM');
        
        if (found) {
            famGroup = true;
            let productAttributesLink: NewItemTab = this.newItemFormService.links.find(x => x.link == 'product-attributes');
            productAttributesLink.disabled = !famGroup;
        }
    }

  mergeEditProductGroup(newProductGroup:IProductGroupingDto, oldProductGroup:IProductGroupingDto){
    // Assign model group values only if there is any model code at root level.
    if(   (newProductGroup.productGroupType == oldProductGroup.productGroupType)
       && (oldProductGroup.modelGroupCode1 || oldProductGroup.modelGroupCode2 || oldProductGroup.modelGroupCode3) ){
      newProductGroup.modelGroupCode1 = oldProductGroup.modelGroupCode1;
      newProductGroup.modelGroupCode2 = oldProductGroup.modelGroupCode2;
      newProductGroup.modelGroupCode3 = oldProductGroup.modelGroupCode3;
      newProductGroup.modelGroupDescription1 = oldProductGroup.modelGroupDescription1;
      newProductGroup.modelGroupDescription2 = oldProductGroup.modelGroupDescription2;
      newProductGroup.modelGroupDescription3 = oldProductGroup.modelGroupDescription3; 
      if(oldProductGroup.parents){
        newProductGroup.parents = this.mergeEditProductGroupList(newProductGroup.parents, oldProductGroup.parents);
      }      
    }
    return newProductGroup;
  }
  mergeEditProductGroupList(newProductGroupList:IProductGroupingDto[], oldProductGroupList:IProductGroupingDto[]){
    for (let oldProductGroup of oldProductGroupList){
      // If there is a model group code already assigned to the new product group, do not use the same row.
      // Example: There is 10 SMG for FAM  item code 110232. If we donot have this logic , there will only one SMG copied to new group.
      let newProductGroup = newProductGroupList.find(item => !(item.modelGroupCode1) && !(item.modelGroupCode2) && !(item.modelGroupCode3) &&(item.productGroupType == oldProductGroup.productGroupType) );
      if(newProductGroup){
        newProductGroup.modelGroupCode1 = oldProductGroup.modelGroupCode1;
        newProductGroup.modelGroupCode2 = oldProductGroup.modelGroupCode2;
        newProductGroup.modelGroupCode3 = oldProductGroup.modelGroupCode3;
        newProductGroup.modelGroupDescription1 = oldProductGroup.modelGroupDescription1;
        newProductGroup.modelGroupDescription2 = oldProductGroup.modelGroupDescription2;
        newProductGroup.modelGroupDescription3 = oldProductGroup.modelGroupDescription3; 
        newProductGroup.parents = this.mergeEditProductGroupList(newProductGroup.parents, oldProductGroup.parents);
      }
      else {
        oldProductGroup.productGroupCode = null;
        oldProductGroup.productGroupDescription = null;
        newProductGroupList.push(oldProductGroup);
      }
    }
    return newProductGroupList;
  }
  /**
   * This is "Add Ad Group" event
   */
  openAdGroupDialog() {
    let dialogRef = this.dialog.open(DialogAdGroupComponent, {
      width: "1200px"
    });
    const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {
      //console.log(result);
      if(result && result.length>0){
        this.productGroupingList = this.removeDuplicates([...this.productGroupingList,...result]);
        this.dirty = true;
        this.populateInitialGridData();
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      sub.unsubscribe();
      //console.log(result);
      if(result && result.length>0){
        // Add this to the list with out merging with model item codes
        this.productGroupingList = this.removeDuplicates([...this.productGroupingList,...result]);
          this.dirty = true;
          this.checkFAMProductGroup();
        this.populateInitialGridData();
      }
    });
  }
  /**
   * This is "Edit Ad Group" event
   */
  editAdGroupDialog(data: IProductGroupingDto, index: number) {
    let dialogRef = this.dialog.open(DialogAdGroupComponent, {
      width: "1200px",
      data: data
    });
    dialogRef.afterClosed().subscribe(result => {
      //console.log(result);
      if(result && result.length>0){
        this.productGroupingList.splice(index, 1, ...result);
        // Add this to the list with out merging with model item codes
        this.productGroupingList = this.removeDuplicates(this.productGroupingList);
        this.dirty = true;
        this.populateInitialGridData();
      }
    });
  }
  /**
   * This is "Add Existing Pricing Group" event
   */
  openPricingGroupDialog() {
    let dialogRef = this.dialog.open(DialogPricingGroupComponent, {
      width: "1200px"
    });
    const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {
      //console.log(result);
      if(result && result.length>0){
        this.productGroupingList = this.removeDuplicates([...this.productGroupingList,...result]);
        this.dirty = true;
        this.populateInitialGridData();
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      sub.unsubscribe();
      //console.log(result);
      if(result && result.length>0){
        // Add this to the list with out merging with model item codes
        this.productGroupingList = this.removeDuplicates([...this.productGroupingList,...result]);
        this.dirty = true;
        this.populateInitialGridData();
      }
    });
  }
  /**
   * This is "Edit Pricing Group" event
   */
  editPricingGroupDialog(data: IProductGroupingDto, index: number) {
    let dialogRef = this.dialog.open(DialogPricingGroupComponent, {
      width: "1200px",
      data: data
    });
    dialogRef.afterClosed().subscribe(result => {
      //console.log(result);
      if(result && result.length>0){
        this.productGroupingList.splice(index, 1,...result);
        // Add this to the list with out merging with model item codes
        this.productGroupingList = this.removeDuplicates(this.productGroupingList);
        this.dirty = true;
        this.populateInitialGridData();
      }
    });
  }
  /**
   * Remove Duplicates if same code type and description is entered. This is called when new item is added and also before saving.
   */
  removeDuplicates(productGroupingList: IProductGroupingDto[]) {
    if(productGroupingList){
      return productGroupingList.filter(function (item: IProductGroupingDto, index: number, list: IProductGroupingDto[]) {
        // if product group code or description is empty, ( e,g RSS), then  donot treat as duplicates.
        return (!item.productGroupCode && !item.productGroupDescription) || (list.findIndex(i => i.productGroupType == item.productGroupType && i.productGroupCode == item.productGroupCode&& i.productGroupDescription == item.productGroupDescription) == index)
      });
    }
  }
  /**
   *  I add a catch to each request in the forkJoin. This allows for partial failures in the detail requests. 
   *  Basically, we don't want to fail all requests just because a single call has an issue.
   * @param err 
   */
  private emptyOnError(err: any) {
    return of([]);
  }
  /**
   * If it is from DB, select this by default
   */
  updateIsSelected(productGroupingList: IProductGroupingDto[]) {
    for (let productGrouping of productGroupingList) {
      productGrouping.isSelected = true;
    }
  }
  /**
   * Open snack bar message
   */
  private openSnackbar(message:string){
     this.snackBar.open(message, null, {
            duration: 3000,
            horizontalPosition: 'center',
            verticalPosition: 'top',
        });
  }
  /* grid variables */
  showDetails: boolean = false;
  length: number; // used to hold count of the entire grid data. 
  pageSize: number = 10;
  pageIndex: number = 0;
  public data: IProductGroupingDto[]; // used to hold shallow copy of grid data of each tab.
  /** This is the event when "delete" action is fired */
  delete(index: number) {
    //console.log("Delete row of product group with index : " + index);
      let productGrp = this.productGroupingList.find(pg => pg.index == index);
      let deleteConfirmDesc = "Are you sure you want to delete?";
      if (productGrp.isMandatory) {
        deleteConfirmDesc = "This is a mandatory item. Are you sure you want to delete?"
      }
      let data = {
        title: "",
        description: deleteConfirmDesc,
        options: [
          "Yes",
          "No"
        ]
      }
      let dialogRef = this.dialog.open(DialogContentComponent, {
        disableClose: true,
        data: data
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
        if (result.action === "Yes") {
          this.productGroupingList.splice(index, 1);
          this.dirty = true;
          this.checkFAMProductGroup();
          this.populateInitialGridData();
        }
      });
  }
  /** This is the method when "edit" action is fired */
  edit(index:number) {
    //console.log("Edit row of product group with index : " + index);
    let selectedRow:IProductGroupingDto = this.productGroupingList[index];
    if(selectedRow.productGroupType == "FLEX"){
      this.editPricingGroupDialog(selectedRow, index);
    }
    else if (selectedRow.productGroupType == "PPMS"){
      this.editAdGroupDialog(selectedRow, index);
    }      
    else {
      this.editProductGroupDialog(selectedRow, index);
    }
  }
  hasChild = (_rowData: IProductGroupingDto) => { return (_rowData.parents && this.getDetailData(_rowData.parents).length > 0); };
  getGridData() {
    if (!this.data) return [];
    return this.data;
  }
  getDetailData(rows: IProductGroupingDto[]) {
    return rows.filter(item => item.productGroupCode);
    //return rows;
  }
  changeIsSelected(row:IProductGroupingDto, checked: boolean) {
    row.isSelected = checked;
    this.dirty = true;
  }
  populateInitialGridData() {
    this.updateData({
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      length: 0,
      active: "",
      direction: "",
      filterBy: "",
      filterValue: ""
    });
  }
  updateData(gridEvent: GridEvent) {
    this.updateIndex();
    this.data = this.performFilter(gridEvent);
    this.sortData(gridEvent);
    this.pageData(gridEvent);
  }
  /**
  * return the filtered or shallow copy without changing the original data
  */
  performFilter(gridEvent: GridEvent): any[] {
    let filterBy = gridEvent.filterBy;
    let filterValue = gridEvent.filterValue;
    if (filterBy && filterBy.length > 0) {
      if (filterValue && filterValue.length > 0) {
        //console.log(this.filterValue);
        return this.productGroupingList.filter((row: any) => {
          // Transform the data into a lowercase string of property values.
          const dataStr = ('' + row[filterBy]).toLowerCase();
          // Transform the data into a lowercase string of all property values.
          //const accumulator = (currentTerm, key) => currentTerm + row[key];
          //const dataStr = Object.keys(row).reduce(accumulator, '').toLowerCase();
          // Transform the filter by converting it to lowercase and removing whitespace.
          const transformedFilter = filterValue.trim().toLowerCase();
          return dataStr.indexOf(transformedFilter) != -1;
        }
        );
      }
      return this.productGroupingList.slice();
    }
    return this.productGroupingList.slice();
  }
  /**
   * sort the filtered result based on sort column and order
   */
  sortData(gridEvent: GridEvent) {
    let active = gridEvent.active;
    let direction = gridEvent.direction;
    let sortAsc = gridEvent.direction == 'asc';
    let sortDesc = gridEvent.direction == 'desc';
    if (!sortAsc && !sortDesc) return;
    this.data.sort((a, b) => {
      if (typeof a[gridEvent.active] === 'string') {
        return a[active].localeCompare(b[active]);
      } else {
        return a[active] - b[active];
      }
    });
    if (sortAsc === false) {
      this.data.reverse();
    }
  }
  /**
     * paginate the result set
     */
  pageData(gridEvent: GridEvent) {
    this.length = this.data.length;
    this.pageSize = gridEvent.pageSize;
    this.pageIndex = gridEvent.pageIndex;
    let offset = this.pageIndex * this.pageSize;
    this.data = this.data.slice(offset, offset + this.pageSize);
  }
  /**
   * Assign index of the grid collection used to edit and delete the rows
   */
  updateIndex() {
    let count: number = 0;
    if (this.productGroupingList) {
      for (let productGrouping of this.productGroupingList) {
        productGrouping.index = count++;
      }
    }
  }
  /** END Grid code block*/  
  /****** START Action Component Events *****/
  public showSpinner: boolean = false;
  public skipSaveTab: boolean = false;
  performAction(action: any) {
    switch (action.actionName) {
      case "Save":
        this.saveTab(action.createdFormStatusID, action.actionID);
        break;
      case "Submit":
       //     this.submitTab(action.createdFormStatusID, action.actionID);
        break;
    }
  }
  public saveTab(createdFormStatusID: number, actionID: number): void {
    this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
      if (res) {
        this.getProductGrouping();
        this.openSnackbar("Saved successfully.");
      }
    });
  }

    public submitTab(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
                this.getProductGrouping();
            });
            if (res) {
                this.snackBar.open("Submitted successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
            else {
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
        });
    }
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

  saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
    if (this.skipSaveTab) return of(true);
    if (!createdFormStatusID && !this.dirty) return of(true);
    this.showSpinner = true;
    this.errors = [];
    this.warnings = [];
    var filteredProductGroupList = this.productGroupingList.filter(item => item.productGroupCode || item.productGroupDescription);
    const finalSaveProductGroupList = this.removeDuplicates(filteredProductGroupList);
    return this.productGroupingService.SaveProductGrouping(finalSaveProductGroupList,this.itemFormID,createdFormStatusID,actionID).pipe(
      map(res => {
        if (createdFormStatusID && res.status) {
          this.newItemFormService.formCurrentStatusID = createdFormStatusID;
        }
            if(res.validation)
                this.newItemFormService.addItemValidation(res.validation);

        let buyerName = null;
        let buyerID = null;
        const productGroupingFAM = finalSaveProductGroupList.find(item => item.productGroupType == "FAM");
        if (productGroupingFAM) {
          let buyerGroup = (productGroupingFAM.parents).find(item => item.productGroupType == "BUY");
          if (buyerGroup) {
            buyerName = buyerGroup.productGroupDescription;
            buyerID = buyerGroup.productGroupCode;
          }
        }
        this.newItemFormService.setFAMBuyer(buyerName, buyerID);
        console.log("saved successfully.");
        this.showSpinner = false;
        return res.status;
      }),
      catchError((err) => {
        this.showSpinner = false;
        if (err.status === 400) {
          this.newItemFormService.addItemValidation(err.error);
          this.handleValidationErrors(err.error);
        }
        else if (err.status === 401) {
          console.log("saved error. " + err.status);
          let message = err.error.exceptionMessage || err.error.message;
          this.errors.push(message);
        }
        else {
          console.log("saved error. " + err.status);
          let message = err.error.exceptionMessage || err.error.message;
          this.errors.push(message);
        }
        window.scrollTo(0, 150);
        this.openSnackbar("Please correct the errors.");
        return of(false);
      })
    );
  }
  public deleteItemForm(): void {
    let dialog = this.dialog.open(ConfirmDialogComponent);
    dialog.afterClosed().subscribe(option => {
      if (option && option === true) {
        this.showSpinner = true;
        this.newItemFormService.deleteItemForm().subscribe(res => {
          this.showSpinner = false;
          if (res != undefined) {
            if (res == true)
              console.log('Deleted Successfully');
            else
              console.log('Delete Failed');
          }
          this.skipSaveTab = true;
          this.router.navigate(['/dashboard'], { queryParamsHandling: 'merge' });
        },
          (err) => {
            this.showSpinner = false;
          })
      }
    });
  }
  reset() {
    this.getProductGrouping();
  }
  handleValidationErrors(validationDTO: IItemValidationDTO){
    let errorDTOs = validationDTO.errors;
    let warningDTOs = validationDTO.warnings;
    for(let errorDTO of errorDTOs){
      this.errors.push(errorDTO.errorDescription);
    }
    for(let warningDTO of warningDTOs){
      this.warnings.push(warningDTO.errorDescription);
    }
  }
  /******* END Action Component Events *****/
}
