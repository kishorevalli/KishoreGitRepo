import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormArray, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';

import { NewItemFormService } from '../new-item-form.service';
import { ProductGroupingService } from './product-grouping.service';
import { ILookupIntDto, ILookupDto } from '../../shared/common.interface';
import { IProductGroupingDto, ProductGroupingDto } from './product-grouping.interface';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { IItemValidationDTO } from '../../shared/common.interface';

@Component({
  selector: 'ifw-product-grouping-vendor',
  templateUrl: './product-grouping-vendor.component.html',
  styleUrls: ['./product-grouping-vendor.component.scss']
})
export class ProductGroupingVendorComponent implements OnInit {
  public itemFormDisplayID: number;
  public itemFormID: number;
  productGroupingRSS: IProductGroupingDto;
  productGroupingFAM: IProductGroupingDto;
  public retailSubSectionList: ILookupIntDto[];
  retailSubSection: number;
  subDepartment: number;
  category: number;
  familyGroup: number;
  buyerName: string;
  showAssignBuyer: boolean = false;
  submittedBuyerExists: boolean = false;
  private dirty: boolean = false;
  public errors: any[];
  public warnings: any[];
  constructor(private fb: FormBuilder,
    public snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router,
    private productGroupingService: ProductGroupingService,
    private newItemFormService: NewItemFormService, ) { }

  ngOnInit() {
    this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
    this.itemFormID = this.newItemFormService.itemFormID;
    this.errors = [];
    this.warnings = [];
    this.productGroupingService.GetItemGroupCodes("RSS").subscribe(res => {
      this.retailSubSectionList = res.map(item => ({ code: Number(item.code), description: item.description }));
    });
    this.getProductGrouping();
  }
  getProductGrouping() {
    let itemFormID = this.itemFormID;
    this.showAssignBuyer = false;
    this.productGroupingService.GetProductGrouping(this.itemFormID)
      .subscribe(res => {
        if (res && res.length > 0) {
          this.splitFamilyGroup(res);
        }
        else { // Find if there is any submitted Item Form with same GTIN and populate in first take
          this.productGroupingService.GetSubmittedItemFormIDWithSameGTIN(this.itemFormID)
            .subscribe(submittedItemFormId => {
              if (submittedItemFormId) {
                this.dirty = true;
                this.submittedBuyerExists = true;
                this.productGroupingService.GetProductGrouping(submittedItemFormId)
                  .subscribe(res => {
                    if (res) {
                      this.splitFamilyGroup(res);
                    }
                  },
                  err => {
                    this.openSnackbar(err);
                    this.showAssignBuyer = true;
                  });
              }
              else {
                this.showAssignBuyer = true;
              }
            });
        }
          this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
              const validations: any = this.newItemFormService.getItemValidation("Product Grouping");
              if (validations) {
                  this.handleValidationErrors(validations);
              }
          });
        //setTimeout(() => {
        //  const validations: IItemValidationDTO = this.newItemFormService.getItemValidation("Product Grouping");
        //  if (validations) {
        //    console.log("validations running.")
        //    this.handleValidationErrors(validations);
        //  }
        //}, 0);
      },
      err => {
        this.openSnackbar(err);
        this.showAssignBuyer = true;
      });
  }
  splitFamilyGroup(res: IProductGroupingDto[]){
    this.productGroupingFAM = res.find(item => item.productGroupType == "FAM");
    this.productGroupingRSS = res.find(item => item.productGroupType == "RSS");
    if (this.productGroupingRSS) {
      this.retailSubSection = this.productGroupingRSS.productGroupCode;
    }
    if (this.productGroupingFAM) {
      this.familyGroup = Number((this.productGroupingFAM.productGroupCode + '').slice(-2));
      this.category = Number((this.productGroupingFAM.productGroupCode + '').slice(-4, -2));
      this.subDepartment = Number((this.productGroupingFAM.productGroupCode + '').slice(-6, -4));
      let buyerGroup = (this.productGroupingFAM.parents).find(item => item.productGroupType == "BUY");
      if (buyerGroup) {
        this.buyerName = buyerGroup.productGroupDescription;
        let buyerID = buyerGroup.productGroupCode;
        this.newItemFormService.setFAMBuyer(this.buyerName,buyerID);
      }
    }
    this.showAssignBuyer = true;
  }
  changeFamilyGroup(result: IProductGroupingDto[]) {
    this.dirty = true;
    if (result && result.length > 0) {
      this.productGroupingFAM = result[0];
    }
    else {
      this.productGroupingFAM = null;
    }
  }
  changeRetailSubSection(retailSubSection: number) {
    this.dirty = true;
    this.retailSubSection = retailSubSection;
    this.productGroupingService.GetParentGroupTypesAndCodes("RSS", this.retailSubSection).subscribe(res => {
      if (res && res.length > 0) {
        this.productGroupingRSS = res[0]
      }
    });
  }
  /**
  * Open snack bar message
  */
  private openSnackbar(message: string) {
    this.snackBar.open(message, null, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  }
  //  /****** START Action Component Events *****/
  public showSpinner: boolean = false;
  public skipSaveTab: boolean = false;
  performAction(action: any) {
    switch (action.actionName) {
      case "Save":
        this.saveTab(action.createdFormStatusID, action.actionID);
        break;
      case "Delete":
        this.deleteItemForm();
        break;
      case "Submit":
        this.submitTab(action.createdFormStatusID, action.actionID);
        break;
    }
  }
  public saveTab(createdFormStatusID: number, actionID: number): void {
    this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
      if (res) {
       // this.getProductGrouping();
        this.openSnackbar("Saved successfully.");
      }
    });
  }

    public submitTab(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            //this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
            //    this.getProductGrouping();
            //});
            if (res) {
                this.openSnackbar("Submitted successfully.");
            }
            else {
                this.openSnackbar("Submitted failed.");
            }
        });
    }

  saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
    if (this.skipSaveTab) return of(true);
    if (!createdFormStatusID && !this.dirty) return of(true);
    this.showSpinner = true;
    this.errors = [];
    this.warnings = [];
    const finalSaveProductGroupList: IProductGroupingDto[] = [];
    if (this.productGroupingFAM) {
      finalSaveProductGroupList.push(this.productGroupingFAM);
    }
    if (this.productGroupingRSS) {
      finalSaveProductGroupList.push(this.productGroupingRSS);
    }
      this.newItemFormService.showLoadingSpinner = true;   
    return this.productGroupingService.SaveProductGrouping(finalSaveProductGroupList, this.itemFormID, createdFormStatusID, actionID).pipe(
      map(res => {
        if (createdFormStatusID && res.status) {
          this.newItemFormService.formCurrentStatusID = createdFormStatusID;
        }
            if(res.validation)
                this.newItemFormService.addItemValidation(res.validation);

        let buyerName = null;
        let buyerID = null;
        if (this.productGroupingFAM) {
          let buyerGroup = (this.productGroupingFAM.parents).find(item => item.productGroupType == "BUY");
          if (buyerGroup) {
            buyerName = buyerGroup.productGroupDescription;
            buyerID = buyerGroup.productGroupCode;
          }
        }
        this.newItemFormService.setFAMBuyer(buyerName,buyerID);
        console.log("saved/submitted successfully.");
            this.showSpinner = false;
            this.newItemFormService.showLoadingSpinner = false;     

            if (actionID)
                this.getProductGrouping();
        return res.status;
      }),
        catchError((err) => {
            this.newItemFormService.showLoadingSpinner = false;         
        this.showSpinner = false;
        if (err.status === 400) {
          this.newItemFormService.addItemValidation(err.error);
          this.handleValidationErrors(err.error);
        }
        else if (err.status === 401) {
          console.log("saved error. " + err.status);
          let message = err.error.exceptionMessage || err.error.message;
          this.errors.push(message);
        }
        else {
          console.log("saved error. " + err.status);
          let message = err.error.exceptionMessage || err.error.message;
          this.errors.push(message);
        }
        window.scrollTo(0, 150);
        this.openSnackbar("Please correct the errors.");
        return of(false);
      })
    );
  }
  public deleteItemForm(): void {
    let dialog = this.dialog.open(ConfirmDialogComponent);
    dialog.afterClosed().subscribe(option => {
      if (option && option === true) {
        this.showSpinner = true;
        this.newItemFormService.deleteItemForm().subscribe(res => {
          this.showSpinner = false;
          if (res != undefined) {
            if (res == true)
              console.log('Deleted Successfully');
            else
              console.log('Delete Failed');
          }
          this.skipSaveTab = true;
          this.router.navigate(['/dashboard'], { queryParamsHandling: 'merge' });
        },
          (err) => {
            this.showSpinner = false;
          })
      }
    });
  }
  reset() {
    this.retailSubSection = null;
  }
  handleValidationErrors(validationDTO: IItemValidationDTO) {
    let errorDTOs = validationDTO.errors;
    let warningDTOs = validationDTO.warnings;
    for (let errorDTO of errorDTOs) {
      this.errors.push(errorDTO.errorDescription);
    }
    for (let warningDTO of warningDTOs) {
      this.warnings.push(warningDTO.errorDescription);
    }
  }
  /******* END Action Component Events *****/
}
