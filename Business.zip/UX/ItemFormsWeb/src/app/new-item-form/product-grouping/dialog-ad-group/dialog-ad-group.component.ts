import { Component, OnInit, Inject, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { IProductAdGroupDto, ProductAdGroupDto, IProductGroupingDto, ProductGroupingDto } from '../product-grouping.interface';
import { ProductGroupingService } from '../product-grouping.service';
import { GridEvent } from '../../../shared/grid/grid-event';
import { ILookupDto, LookupDto } from '../../../shared/common.interface';

@Component({
  selector: 'ifw-dialog-ad-group',
  templateUrl: './dialog-ad-group.component.html',
  styleUrls: ['./dialog-ad-group.component.scss']
})
export class DialogAdGroupComponent implements OnInit {
  // modelItemCode:number;
  searchBy: string;
  searchValue: string;
  isEdit: boolean = false;
  isNew: boolean = false;
  showSpinnerSearchButton: boolean = false;
  showGrid: boolean = false;
  adGroupList: IProductAdGroupDto[] = [];
  adGroupName: string;
  onAddEvent = new EventEmitter<IProductGroupingDto[]>();
  public searchByList: ILookupDto[];
  public errors: any[];
  constructor(private productGroupingService: ProductGroupingService,
    public dialogRef: MatDialogRef<DialogAdGroupComponent>,
    public snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public dialogdata: IProductGroupingDto, ) { }

  ngOnInit() {
    this.errors = [];
    this.isEdit = (this.dialogdata) ? true : false;
    this.searchValue = null;
    this.adGroupName = '';
    this.createSearchByList();
    if (this.isEdit && !this.dialogdata.productGroupCode && this.dialogdata.productGroupDescription) {
      this.isNew = true;
      this.dialogRef.updateSize("800px");
      this.adGroupName = this.dialogdata.productGroupDescription;
    }
  }
  changeIsNew(isNew: boolean) {
    this.errors = [];
    this.isNew = isNew;
    if (this.isNew) {
      this.dialogRef.updateSize("800px");
    }
    else {
      this.dialogRef.updateSize("1200px");
    }
  }
  createSearchByList() {
    this.searchByList = [];
    this.searchByList.push({ code: "ItemCode", description: "Item Code" });
    this.searchByList.push({ code: "ItemDescription", description: "Item Description" });
    this.searchByList.push({ code: "AdGroupID", description: "Ad Group ID" });
    this.searchByList.push({ code: "AdGroupName", description: "Ad Group Name" });
    this.searchBy = "ItemCode";
  }
  /**
     * get all ad group codes of the entered item code.
     */
  getAdGroupsItemCode() {
    if (this.searchBy && this.searchValue) {
      this.showSpinnerSearchButton = true;
      this.showGrid = false;
      const search:ILookupDto = {
        code : this.searchBy,
        description : this.searchValue
      };
      this.productGroupingService.GetProductAdGroup(search).subscribe(res => {
        this.showSpinnerSearchButton = false;
        if (!res) res = [];
        this.adGroupList = res;
        this.showGrid = true;
        this.populateInitialGridData();
      },
        (err) => {
          this.openSnackbar(err);
          this.showSpinnerSearchButton = false;
        });
    }
  }
  public onAdd(): void {
    let productGroupingList: IProductGroupingDto[] = [];
    if (this.isNew) {
      if (!this.adGroupName) {
        this.errors = [];
        this.errors.push("New Ad Group Name is required.");
        return;
      }
      let productGrouping: IProductGroupingDto = new ProductGroupingDto();
      productGrouping.productGroupType = "PPMS";
      productGrouping.productGroupCode = null;
      productGrouping.productGroupDescription = this.adGroupName;
      productGrouping.parents = [];
      productGroupingList.push(productGrouping);
    }
    else {
      var filteredAdGroupList = this.adGroupList.filter(item => item.isSelected);
      if (filteredAdGroupList.length == 0) {
        this.errors = [];
        this.errors.push("Please select a PPMS Ad Group.");
        return;
      }
      productGroupingList = filteredAdGroupList.map(item => {
        let productGrouping: IProductGroupingDto = new ProductGroupingDto();
        productGrouping.productGroupType = "PPMS";
        productGrouping.productGroupCode = item.adGroupID;
        productGrouping.productGroupDescription = item.adGroupName;
        productGrouping.parents = [];
        return productGrouping;
      });
    }
    this.dialogRef.close(productGroupingList);
  }
  public onAddContinue(): void {
    let productGroupingList: IProductGroupingDto[] = [];
    if (this.isNew) {
      if (!this.adGroupName) {
        this.errors = [];
        this.errors.push("New Ad Group Name is required.")
        return;
      }
      let productGrouping: IProductGroupingDto = new ProductGroupingDto();
      productGrouping.productGroupType = "PPMS";
      productGrouping.productGroupCode = null;
      productGrouping.productGroupDescription = this.adGroupName;
      productGrouping.parents = [];
      productGroupingList.push(productGrouping);
    }
    else {
      var filteredAdGroupList = this.adGroupList.filter(item => item.isSelected);
      if (filteredAdGroupList.length == 0) {
        this.errors = [];
        this.errors.push("Please select a PPMS Ad Group.");
        return;
      }
      productGroupingList = filteredAdGroupList.map(item => {
        let productGrouping: IProductGroupingDto = new ProductGroupingDto();
        productGrouping.productGroupType = "PPMS";
        productGrouping.productGroupCode = item.adGroupID;
        productGrouping.productGroupDescription = item.adGroupName;
        productGrouping.parents = [];
        return productGrouping;
      });
    }
    this.onAddEvent.emit(productGroupingList);
    this.reset();
  }
  reset() {
    this.searchValue = null;
    this.adGroupName = '';
    this.adGroupList = [];
    this.errors = [];
    this.populateInitialGridData();
  }
  /**
 * Open snack bar message
 */
  private openSnackbar(message: string) {
    this.snackBar.open(message, null, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  }
  /* grid variables */
  showDetails: boolean = true;
  length: number; // used to hold count of the entire grid data. 
  pageSize: number = 10;
  pageIndex: number = 0;
  public data: IProductAdGroupDto[]; // used to hold shallow copy of grid data of each tab.
  hasChild = (_rowData: IProductAdGroupDto) => { return (_rowData.adGroupItems && _rowData.adGroupItems.length > 0); };
  getGridData() {
    if (!this.data) return [];
    return this.data;
  }
  getDetailData(rows: IProductAdGroupDto[]) {
    return rows;
  }
  populateInitialGridData() {
    this.updateData({
      pageIndex: 0,
      pageSize: this.pageSize,
      length: 0,
      active: "",
      direction: "",
      filterBy: "",
      filterValue: ""
    });
  }
  updateData(gridEvent: GridEvent) {
    //this.updateIndex();
    this.data = this.performFilter(gridEvent);
    this.sortData(gridEvent);
    this.pageData(gridEvent);
  }
  /**
  * return the filtered or shallow copy without changing the original data
  */
  performFilter(gridEvent: GridEvent): any[] {
    let filterBy = gridEvent.filterBy;
    let filterValue = gridEvent.filterValue;
    if (filterBy && filterBy.length > 0) {
      if (filterValue && filterValue.length > 0) {
        //console.log(this.filterValue);
        return this.adGroupList.filter((row: any) => {
          // Transform the data into a lowercase string of property values.
          const dataStr = ('' + row[filterBy]).toLowerCase();
          // Transform the data into a lowercase string of all property values.
          // const accumulator = (currentTerm, key) => currentTerm + row[key];
          // const dataStr = Object.keys(row).reduce(accumulator, '').toLowerCase();
          // Transform the filter by converting it to lowercase and removing whitespace.
          const transformedFilter = filterValue.trim().toLowerCase();
          return dataStr.indexOf(transformedFilter) != -1;
        }
        );
      }
      return this.adGroupList.slice();
    }
    return this.adGroupList.slice();
  }
  /**
   * sort the filtered result based on sort column and order
   */
  sortData(gridEvent: GridEvent) {
    let active = gridEvent.active;
    let direction = gridEvent.direction;
    let sortAsc = gridEvent.direction == 'asc';
    let sortDesc = gridEvent.direction == 'desc';
    if (!sortAsc && !sortDesc) return;
    this.data.sort((a, b) => {
      if (typeof a[gridEvent.active] === 'string') {
        return a[active].localeCompare(b[active]);
      } else {
        return a[active] - b[active];
      }
    });
    if (sortAsc === false) {
      this.data.reverse();
    }
  }
  /**
     * paginate the result set
     */
  pageData(gridEvent: GridEvent) {
    this.length = this.data.length;
    this.pageSize = gridEvent.pageSize;
    this.pageIndex = gridEvent.pageIndex;
    let offset = this.pageIndex * this.pageSize;
    this.data = this.data.slice(offset, offset + this.pageSize);
  }
}
