import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar  } from '@angular/material';

import { IProductGroupingDto, ProductGroupingDto, IProductGroupType, ProductGroupType, IVBGVendorDto, IProductVBGGroupVendorDto } from '../product-grouping.interface';
import { ILookupIntDto } from '../../../shared/common.interface';
import { NewItemFormService } from '../../new-item-form.service';
import { ProductGroupingService } from '../product-grouping.service';
import { GridEvent } from '../../../shared/grid/grid-event';

@Component({
  selector: 'ifw-dialog-product-group',
  templateUrl: './dialog-product-group.component.html',
  styleUrls: ['./dialog-product-group.component.scss']
})
export class DialogProductGroupComponent implements OnInit {
  productGroupingList: IProductGroupingDto[] = [];
  productGroupTypeList: IProductGroupType[] = []
  productGroupCodeList: ILookupIntDto[] = []
  dsdVendorList: IVBGVendorDto[] = []
  //dsdVBGCodeVendorList: IVBGVendorDto[] = []
  productVBGGroupVendorList: IProductVBGGroupVendorDto[] =[];
  groupType: IProductGroupType;
  groupCode: ILookupIntDto;
  loadingGroupCode: boolean = false;
  loadingParentGroupTypeCodes: boolean = false;
  onAddEvent = new EventEmitter<IProductGroupingDto[]>();
  isEdit: boolean = false;
  showVendorList: boolean = false;
  public itemFormID: number;
  public errors: any[];
  constructor(public dialogRef: MatDialogRef<DialogProductGroupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: IProductGroupingDto,
    public snackBar: MatSnackBar,
    private newItemFormService: NewItemFormService,
    private productGroupingService: ProductGroupingService, ) { }

  ngOnInit() {
    this.errors = [];
    this.isEdit = (this.data) ? true : false;
    this.itemFormID = this.newItemFormService.itemFormID;
    this.productGroupingService.GetChildItemGroupTypes().subscribe(res => {
      this.productGroupTypeList = res;
      if (this.isEdit) {
        const groupType = this.productGroupTypeList.find(item => item.code == this.data.productGroupType);
        if (groupType) {
          this.changeProductGroupType(groupType, this.data.productGroupCode);
        }
      }
    },
      err => {
        this.openSnackbar(err);
      });
  }

  changeProductGroupType(groupType: IProductGroupType, productGroupCode?: number) {
    this.reset();
    this.groupType = groupType;
    this.loadingGroupCode = true;
    this.showVendorList = false;
    if (groupType.code != "VBG") {
      this.productGroupingService.GetItemGroupCodes(groupType.code).subscribe(res => {
        this.loadingGroupCode = false;
        this.productGroupCodeList = res.map(nt => ({ code: Number(nt.code), description: nt.description }));
        if(productGroupCode) this.mapGroupCodeWhenEdit(productGroupCode);
      },
        (err) => {
          this.loadingGroupCode = false;
          this.openSnackbar(err);
        });    
    }
    else {
        this.productGroupingService.GetVBGVendors(this.itemFormID).subscribe(res => {
          if(res && res.length> 0){
            this.dsdVendorList = res;  
            this.showVendorList = true; 
            this.productGroupingService.GetVBGGroupCodes(res).subscribe(res => {
              this.loadingGroupCode = false;
              this.productVBGGroupVendorList = res;
              this.productGroupCodeList = res.map(nt => ({ code: Number(nt.code), description: nt.description }));
              if(productGroupCode) this.mapGroupCodeWhenEdit(productGroupCode);
            },
              (err) => {
                this.loadingGroupCode = false;
                this.openSnackbar(err);
              });
          }
          else {
            this.loadingGroupCode = false;
            this.openSnackbar("DSD Vendors list is empty.");
          }       
        },
        (err) => {
          this.loadingGroupCode = false;
          this.openSnackbar(err);
        }); 
    }
  }
  mapGroupCodeWhenEdit(productGroupCode: number){
    const groupCode: ILookupIntDto = this.productGroupCodeList.find(item => item.code == productGroupCode);
    this.changeProductGroupCode(groupCode);
  }
  changeProductGroupCode(groupCode: ILookupIntDto) {
    this.loadingParentGroupTypeCodes = true;
    this.groupCode = groupCode;
    this.productGroupingService.GetParentGroupTypesAndCodes(this.groupType.code, this.groupCode.code).subscribe(res => {
      if (res.length == 0) {
        let productGroupingNew: IProductGroupingDto = new ProductGroupingDto();
        productGroupingNew.productGroupType = this.groupType.code;
        productGroupingNew.productGroupCode = this.groupCode.code;
        productGroupingNew.productGroupDescription = this.groupCode.description;
        productGroupingNew.isMandatory = this.groupType.isMandatory;
        productGroupingNew.isSelected = this.groupType.isMandatory;
        productGroupingNew.isNew = (this.isEdit && !this.data.isNew)? this.data.isNew : true;
        productGroupingNew.modelGroupCodeType = 0;
        productGroupingNew.parents = [];
        this.productGroupingList = [productGroupingNew];
      }
      else {
        this.productGroupingList = res;
        this.updateIsSelected();
      }
      this.loadingParentGroupTypeCodes = false;
    },
      (err) => {
        this.loadingParentGroupTypeCodes = false;
        this.openSnackbar(err);
      });
     
    // if(this.groupType.code == "VBG"){
    //    var found = this.productVBGGroupVendorList.find(item => item.code == this.groupCode.code);
    //    if(found){
    //     this.dsdVBGCodeVendorList = found.vendors;
    //    }
    // }  
  }
  public onAdd(): void {
    if (!this.groupType || !this.groupCode) {
      this.errors = [];
      this.errors.push("Please select Product Group Type and Product Group Code.");
      return;
    }
    this.dialogRef.close(this.productGroupingList);
  }
  public onAddContinue(): void {
    if (!this.groupType || !this.groupCode) {
      this.errors = [];
      this.errors.push("Please select Product Group Type and Product Group Code.");
      return;
    }
    this.onAddEvent.emit(this.productGroupingList);
    this.reset();
  }
  updateIsSelected() {
    for (let productGrouping of this.productGroupingList) {
      productGrouping.isSelected = productGrouping.isMandatory;
      productGrouping.isNew = (this.isEdit && !this.data.isNew)? this.data.isNew : true;
    }
  }
  reset() {
    this.groupType = null;
    this.groupCode = null;
    this.productGroupingList = []
  }
  openSnackbar(message: string) {
    this.snackBar.open(message, null, {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  }
}
