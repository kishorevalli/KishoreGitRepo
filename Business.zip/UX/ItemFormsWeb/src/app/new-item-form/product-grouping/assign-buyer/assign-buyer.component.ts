import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';

import { NewItemFormService } from '../../new-item-form.service';
import { ProductGroupingService } from '../product-grouping.service';
import { ILookupIntDto, ILookupDto } from '../../../shared/common.interface';
import { IProductGroupingDto, ProductGroupingDto } from '../product-grouping.interface';


@Component({
  selector: 'ifw-assign-buyer',
  templateUrl: './assign-buyer.component.html',
  styleUrls: ['./assign-buyer.component.scss']
})
export class AssignBuyerComponent implements OnInit {
  public itemFormID: number;
  productGroupingList: IProductGroupingDto[] = [];
  //Lookup dropdownlist
  public subDepartmentList: ILookupIntDto[];
  public categoryList: ILookupIntDto[];
  public familyGroupList: ILookupIntDto[];

  showCategory: boolean = false;
  showFamilyGroup: boolean = false;
  showBuyer: boolean = false;
  showSpinner: boolean = false;
  // Data fields
  @Input() subDepartment: number;
  @Input() category: number;
  @Input() familyGroup: number;
  @Input() buyerName: string;
  // Combined FAM code
  familyGroupCode: number;
  @Output() buyerChange = new EventEmitter<IProductGroupingDto[]>();
  constructor(private productGroupingService: ProductGroupingService,
    public snackBar: MatSnackBar,
    private newItemFormService: NewItemFormService,) { }

  ngOnInit() {
    this.itemFormID = this.newItemFormService.itemFormID;
    this.productGroupingService.GetSubDepartments().subscribe(res => {
      this.subDepartmentList = res.map(item => ({ code: Number(item.code), description: item.description }));
    });
    if (this.subDepartment && this.category && this.familyGroup) {
      this.familyGroupCode = Number(this.formatFamilyGroupCode(this.subDepartment, this.category, this.familyGroup));
      forkJoin(this.productGroupingService.GetCategory(this.subDepartment).catch(this.emptyOnError),
        this.productGroupingService.GetFamilyGroup(this.subDepartment, this.category).catch(this.emptyOnError))
        .subscribe(results => {
          var categoryLookupDto: ILookupDto[] = results[0];
          this.categoryList = categoryLookupDto.map(item => ({ code: Number(item.code), description: item.description }));
          this.showCategory = true;
          var familyGroupLookupDto: ILookupDto[] = results[1];
          this.familyGroupList = familyGroupLookupDto.map(item => ({ code: Number(item.code), description: item.description }));
          this.showFamilyGroup = true;
          this.showBuyer = true;
        });
    }  
  }
  changeSubDepartment(subDepartment: number) {
    this.subDepartment = subDepartment;
    this.category = null;
    this.familyGroup = null;
    this.familyGroupCode = null;
    this.buyerName = '';
    this.showCategory = false;
    this.showFamilyGroup = false;
    this.showBuyer = false;
    this.buyerChange.emit([]);
    this.productGroupingService.GetCategory(subDepartment).subscribe(res => {
      this.categoryList = res.map(item => ({ code: Number(item.code), description: item.description }));
      this.showCategory = true;
    });
  }
  changeCategory(category: number) {
    this.category = category;
    this.familyGroup = null;
    this.familyGroupCode = null;
    this.buyerName = '';
    this.showFamilyGroup = false;
    this.showBuyer = false;
    this.buyerChange.emit([]);
    this.productGroupingService.GetFamilyGroup(this.subDepartment,category).subscribe(res => {
      this.familyGroupList = res.map(item => ({ code: Number(item.code), description: item.description }));
      this.showFamilyGroup = true;
    });
  }
  changefamilyGroup(familyGroup: number) {
    this.familyGroup = familyGroup;
    this.buyerName = '';
    this.showBuyer = false;
    this.showSpinner = true;
    this.buyerChange.emit([]);
    this.familyGroupCode = Number(this.formatFamilyGroupCode(this.subDepartment, this.category, this.familyGroup));
    this.productGroupingService.GetParentGroupTypesAndCodes("FAM", this.familyGroupCode).subscribe(res => {
      this.showSpinner = false;
      if (res && res.length > 0) {
        this.productGroupingList = res;
        let buyerGroup = (this.productGroupingList[0].parents).find(item => item.productGroupType == "BUY");
        if (buyerGroup) {
          this.showBuyer = true;
          this.buyerName = buyerGroup.productGroupDescription;
        }
        this.buyerChange.emit(this.productGroupingList);
      }
    },
      (err) => {
        this.showSpinner = false;
        this.openSnackbar(err);
      });
  }
  formatFamilyGroupCode(subDepartment: number, category: number, familyGroup: number){
    return ('0'+subDepartment).slice(-2) + ('0'+category).slice(-2) + ('0'+familyGroup).slice(-2);
  }
  /**
   *  I add a catch to each request in the forkJoin. This allows for partial failures in the detail requests. 
   *  Basically, we don't want to fail all requests just because a single call has an issue.
   * @param err 
   */
  private emptyOnError(err: any) {
    this.openSnackbar(err);
    return of([]);
  }
   /**
   * Open snack bar message
   */
  private openSnackbar(message:string){
    this.snackBar.open(message, null, {
           duration: 3000,
           horizontalPosition: 'center',
           verticalPosition: 'top',
       });
 }
}
