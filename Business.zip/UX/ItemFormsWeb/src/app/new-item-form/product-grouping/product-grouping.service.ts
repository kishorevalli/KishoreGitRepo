import { Injectable, Inject } from '@angular/core'
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import { of } from 'rxjs/observable/of';

import { IProductGroupingDto, ProductGroupingDto, IProductGroupType, IProductPriceGroupDto, IProductAdGroupDto, IVBGVendorDto, IProductVBGGroupVendorDto } from './product-grouping.interface';
import { ILookupDto, IItemSaveResponse } from '../../shared/common.interface';
import { APP_CONFIG, AppConfig } from '../../app.config';

@Injectable()
export class ProductGroupingService {
    private baseUrl;

    private serviceBase: string = 'api/ProductGrouping/';

    constructor( @Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;
    }
    GetProductGrouping(itemFormID: number): Observable<IProductGroupingDto[]> {
        return this.httpClient.get<IProductGroupingDto>(this.baseUrl + this.serviceBase + `GetProductGrouping?itemFormID=${itemFormID}`)
            .catch(this.handleError);
    }
    GetProductGroupingByItemCode(itemCode: number, modelGroupCodeType: number): Observable<IProductGroupingDto[]> {
        return this.httpClient.get<IProductGroupingDto>(this.baseUrl + this.serviceBase + `GetProductGroupingByItemCode?itemCode=${itemCode}&modelGroupCodeType=${modelGroupCodeType}`)
            .catch(this.handleError);
    }
    GetChildItemGroupTypes(): Observable<IProductGroupType[]> {
        return this.httpClient.get<IProductGroupingDto>(this.baseUrl + this.serviceBase + `GetChildItemGroupTypes`)
        .catch(this.handleError);
    }
    GetItemGroupCodes(groupType: string): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto>(this.baseUrl + this.serviceBase + `GetItemGroupCodes?groupType=${groupType}`)
        .catch(this.handleError);
    }
    GetVBGVendors(itemFormID: number): Observable<IVBGVendorDto[]> {
        return this.httpClient.get<IVBGVendorDto>(this.baseUrl + this.serviceBase + `GetVBGVendors?itemFormID=${itemFormID}`)
            .catch(this.handleError);
    }
    GetVBGGroupCodes(vendors: IVBGVendorDto[]): Observable<IProductVBGGroupVendorDto[]> {
        return this.httpClient.post<IProductVBGGroupVendorDto>(this.baseUrl + this.serviceBase + `GetVBGGroupCodes`,vendors)
        .catch(this.handleError);
    }
    GetParentGroupTypesAndCodes(groupType: string, groupCode: number): Observable<IProductGroupingDto[]> {
        return this.httpClient.get<IProductGroupingDto>(this.baseUrl + this.serviceBase + `GetParentGroupTypesAndCodes?groupType=${groupType}&groupCode=${groupCode}`)
        .catch(this.handleError);
    }
    GetProductPriceGroup(search:ILookupDto): Observable<IProductPriceGroupDto[]> {
        return this.httpClient.post<IProductPriceGroupDto>(this.baseUrl + this.serviceBase + 'GetProductPriceGroup' , search)
        .catch(this.handleError);
    }
    GetProductAdGroup(search:ILookupDto): Observable<IProductAdGroupDto[]> {
        return this.httpClient.post<IProductAdGroupDto>(this.baseUrl + this.serviceBase + `GetProductAdGroup`, search)
        .catch(this.handleError);
    }
    GetSubDepartments(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto>(this.baseUrl + this.serviceBase + 'GetSubDepartments')
        .catch(this.handleError);
    }
    GetCategory(subDepartment: number): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto>(this.baseUrl + this.serviceBase + `GetCategory?SubDepartment=${subDepartment}`)
        .catch(this.handleError);
    }
    GetFamilyGroup(subDepartment: number, category: number): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto>(this.baseUrl + this.serviceBase + `GetFamilyGroup?SubDepartment=${subDepartment}&Category=${category}`)
        .catch(this.handleError);
    }
    GetSubmittedItemFormIDWithSameGTIN(itemFormID: number): Observable<number> {
        return this.httpClient.get<number>(this.baseUrl + this.serviceBase + `GetSubmittedItemFormIDWithSameGTIN?itemFormID=${itemFormID}`)
            .catch(this.handleError);
    }
    SaveProductGrouping(productGroupingList: IProductGroupingDto[], itemFormID: number, formStatusID?: number, formActionID?: number): Observable<IItemSaveResponse> {
        let url = `SaveProductGrouping/${itemFormID}`;
        if(formStatusID && formActionID){
            url = url + `/${formStatusID}/${formActionID}`;
        }
        return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + url, productGroupingList);
    }

    SaveFAMProductGrouping(productGroupingList: IProductGroupingDto[], itemFormID: number): Observable<boolean> {
        let url = `SaveFAMProductGrouping/${itemFormID}`;
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + url, productGroupingList)
            .catch(this.handleError);;
    }
    
    handleError(err: HttpErrorResponse) {
        console.log(err.message);
        let message = err.error.exceptionMessage || err.error.message;
        console.log("snackBar: "+ message);
        return Observable.throw(message);
    }
}