export interface IProductGroupingDto {
    id?: number;
    itemFormID?: number;
    index?: number;
    productGroupType: string;
    productGroupCode?: number;
    productGroupDescription?: string;
    modelGroupCodeType?: number;
    isNew?: boolean;
    isMandatory?: boolean;
    isSelected?: boolean;
    modelGroupCode1?: number;
    modelGroupDescription1?: string;
    modelGroupCode2?: number;
    modelGroupDescription2?: string;
    modelGroupCode3?: number;
    modelGroupDescription3?: string;
    parents?: IProductGroupingDto[];
}
export class ProductGroupingDto implements IProductGroupingDto {
    id?: number;
    itemFormID?: number;
    index?:number;
    productGroupType: string;
    productGroupCode?: number;
    productGroupDescription?: string;
    modelGroupCodeType?: number;
    isNew?: boolean;
    isMandatory?: boolean;
    isSelected?: boolean;
    modelGroupCode1?: number;
    modelGroupDescription1?: string;
    modelGroupCode2?: number;
    modelGroupDescription2?: string;
    modelGroupCode3?: number;
    modelGroupDescription3?: string;
    parents?: IProductGroupingDto[];
}
export interface IProductGroupingLinearDto {
    id?: number;
    itemFormID?: number;
    childProductGroupType: string;
    childProductGroupCode?: number;
    childProductGroupDescription?: string;
    parentProductGroupType?: string;
    parentProductGroupCode?: number;
    parentProductGroupDescription?: string;
    grandParentProductGroupType?: string;
    grandParentProductGroupCode?: number;
    grandParentProductGroupDescription?: string;
    isMandatory?: boolean;
    isSelected?: boolean;
}
export class ProductGroupingLinearDto implements IProductGroupingLinearDto {
    id?: number;
    itemFormID?: number;
    childProductGroupType: string;
    childProductGroupCode?: number;
    childProductGroupDescription?: string;
    parentProductGroupType?: string;
    parentProductGroupCode?: number;
    parentProductGroupDescription?: string;
    grandParentProductGroupType?: string;
    grandParentProductGroupCode?: number;
    grandParentProductGroupDescription?: string;
    isMandatory?: boolean;
    isSelected?: boolean;
}
export interface IProductGroupType {
    code: string;
    description?: string;
    isMandatory: boolean;
}
export class ProductGroupType implements IProductGroupType {
    code: string;
    description?: string;
    isMandatory: boolean;
}
export interface IProductPriceGroupDto {
    priceGroupID: number;
    priceGroupName?: string;
    leadItemCode: number;
    itemCode: number;
    itemDescription?: string;
    vendorNumber?: number;
    vendorName?: string;
    isSelected?: boolean;
    priceGroupItems: IProductPriceGroupDto[];
}
export class ProductPriceGroupDto implements IProductPriceGroupDto {
    priceGroupID: number;
    priceGroupName?: string;
    leadItemCode: number;
    itemCode: number;
    itemDescription?: string;
    vendorNumber?: number;
    vendorName?: string;
    isSelected?: boolean;
    priceGroupItems: IProductPriceGroupDto[];
}
export interface IProductAdGroupDto {
    adGroupID: number;
    adGroupName?: string;
    itemCode: number;
    itemDescription?: string;
    leadCode?: string;
    isSelected?: boolean;
    adGroupItems: IProductAdGroupDto[];
}
export class ProductAdGroupDto implements IProductAdGroupDto {
    adGroupID: number;
    adGroupName?: string;
    itemCode: number;
    itemDescription?: string;
    leadCode?: string;
    isSelected?: boolean;
    adGroupItems: IProductAdGroupDto[];
}
export interface IVBGVendorDto {
    vendorNumber: number;
    vendorDescription: string;
}
export class VBGVendorDto implements IVBGVendorDto {
    vendorNumber: number;
    vendorDescription: string;
}
export interface IProductVBGGroupVendorDto {
    code: number;
    description: string;
    vendors: IVBGVendorDto[];
}
export class ProductVBGGroupVendorDto implements IProductVBGGroupVendorDto {
    code: number;
    description: string;
    vendors: IVBGVendorDto[];
}