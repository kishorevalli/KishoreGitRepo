import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import { IGtinDto, GtinDto } from './common/gtin-header/gtin.interface';
import { IItemFormDto, ItemFormDto, NewItemTab, UserType, FormUserPermittedActionDto, IFormUserPermittedActionDto ,IVendorDomainDto, VendorDomainDto, IGTINWithCheckdigitDto } from './new-item-form.interface';
import { IBasicItemDefnitionDto, BasicItemDefnitionDto } from '../new-item-form/basic-item-definition/basic-item-definition-interface';
import { IItemValidationDTO, ErrorDTO,IErrorDTO } from '../shared/common.interface';
import { APP_CONFIG, AppConfig } from '../app.config';
import { AuthService } from '../core/services/auth.service';




@Injectable()
export class NewItemFormService {
    private baseUrl: string;  
    //public baseUrl: string = '/ItemFormsApi/';

    private serviceBase: string = 'api/Common/';
    private workFlowServiceBase: string = 'api/WorkFlow/';
    private basicItemDefServiceBase: string = 'api/BasicItemDefinition/';
    private _itemFormDisplayID: number;    
    public itemValidations = {};
    public showLoadingSpinner:boolean = false; 
    links: NewItemTab[] = [
        { id: 0, name: 'Basic Item Definition', link: 'basic-item-definition', disabled: false },
        { id: 1, name: 'General Product Attributes', link: 'general-product-attributes', disabled: false },
        { id: 2, name: 'Shipper Item Composition', link: 'shipper-item-composition', disabled: false },
        { id: 3, name: 'Packaging Hierarchy', link: 'packaging-hierarchy', disabled: false },
        { id: 4, name: 'DSD Authorization Request', link: 'dsd-authorization-request', disabled: false },
        { id: 5, name: 'Marketing Support', link: 'marketing-support', disabled: false },
        { id: 6, name: 'Product Grouping', link: 'product-grouping', disabled: false },
        { id: 7, name: 'Product Attributes', link: 'product-attributes', disabled: true },
        { id: 8, name: 'Scale Item Details', link: 'scale-item-attributes', disabled: false },
        { id: 9, name: 'Review/Create Item', link: 'review-create-item', disabled: false },
    ];        


    get itemFormDisplayID(): number {
        this._itemFormDisplayID = +sessionStorage.getItem("itemFormDisplayID");
        return this._itemFormDisplayID;
    }     
    set itemFormDisplayID(newValue:number) {
        if(!newValue) return;
        this._itemFormDisplayID = newValue;   
        sessionStorage.setItem("itemFormDisplayID", newValue.toString());     
    }

    private _itemFormID: number;
    get itemFormID(): number {
        if(!this._itemFormID){
            this._itemFormID = +sessionStorage.getItem("itemFormID");
        }
        return this._itemFormID;
    }
     
    set itemFormID(newValue:number) {
        if(!newValue) return;
        this._itemFormID = newValue;   
        sessionStorage.setItem("itemFormID", newValue.toString());     
    }
    private _userType: UserType;
    get userType(): UserType {
        this._userType = +sessionStorage.getItem("userType");
        return this._userType;
    }

    private _loggedInUser: string;
    get loggedInUser(): string {
        if (!this._loggedInUser) {
            this._loggedInUser = sessionStorage.getItem("loggedInUser");
        }
        return this._loggedInUser;
    }

    set loggedInUser(newValue: string) {
        if (!newValue) return;
        this._loggedInUser = newValue;
        sessionStorage.setItem("loggedInUser", newValue.toString());
    }

    public formattedGtin: string;
    public gtinCheckDigit: number;
    public compressedUPC: string;
    public priceLookupCode: string;
    public itemCode: number;
    public itemDescription: string;
    public modelProductItemcode: number;
    public modelPackagingItemCode: number;
    public modelItemDescription: string;

    public currentUserType: UserType;
    public formCurrentStatusID: number;
    public formTypeID: number;
    public createdByUserType: UserType;
    public createdBy: string;
    public vendorContactID: string;
    public vendorContactName: string;
    public vendorContactEmail: string;
    buyerID: number;
    buyerName: string;
    public itemForm: ItemFormDto;
    public itemFormGroup: ItemFormDto[]=[];
    public refreshItemFormUrl: string;
    public refreshItemFormID: number;
    public refreshItemFormDisplayID: number;
    public parentFlag: string = "N";
    public isInGroup: string = "N";
   // public loggedInUser: string;

   /** START fields needed in GPA buyer from BID */
    public itemTypeCode: string;
    public retailPackagedItem: string;
    public itemCaseTypeID: number;
    public size: number;
    public sizeUOM: string;    
    /** END  */
    /**START Signature Information */
    public lastUpdatedBy: string;
    public lastUpdatedDate: Date;
    /** END  */
    constructor(@Inject(APP_CONFIG) config: AppConfig, 
        private httpClient: HttpClient
       ) {
        this.baseUrl = config.apiEndpoint;
     }

    //getGtinDetailsByFormDisplayID(): Observable<GtinDto> {
    //    return this.httpClient.get<GtinDto>(this.baseUrl + this.serviceBase + 'getGtinDetailsByFormDisplayID');
    //}

    setGtinHeaderDetails(gtinHeader : GtinDto) {
        this.formattedGtin = gtinHeader.formattedGtin;
        this.gtinCheckDigit = gtinHeader.gtinCheckDigit;
        this.compressedUPC = gtinHeader.compressedUPC;
        this.priceLookupCode = gtinHeader.priceLookupCode;
        this.itemDescription = gtinHeader.itemDescription;
        this.itemCode = gtinHeader.itemCode;
        this.modelItemDescription = gtinHeader.modelItemDescription;
        this.modelProductItemcode = gtinHeader.modelProductItemcode;
        this.modelPackagingItemCode = gtinHeader.modelPackagingItemCode;
    }

    setBIDData(basicItemDefinition: IBasicItemDefnitionDto){
        this.itemTypeCode = basicItemDefinition.itemTypeCode;
        this.retailPackagedItem = basicItemDefinition.retailPackagedItem;
        this.itemCaseTypeID = basicItemDefinition.itemCaseTypeID;
        this.size = basicItemDefinition.size;
        this.sizeUOM = basicItemDefinition.sizeUOM;
        //Extra information

        this.formattedGtin = basicItemDefinition.formattedGtin;
        this.gtinCheckDigit = basicItemDefinition.gtinCheckDigit;
        this.compressedUPC = basicItemDefinition.compressedUPC;
        this.priceLookupCode = basicItemDefinition.priceLookupCode;
        this.itemCode = basicItemDefinition.itemCode
        this.itemDescription = basicItemDefinition.vendorItemDescription;
        this.modelProductItemcode = basicItemDefinition.modelProductItemCode;;
        this.modelItemDescription = basicItemDefinition.modelProductItemDescription;
        this.modelPackagingItemCode = basicItemDefinition.modelPackagingItemCode;
    }

    setFormUserDetails(itemFormDto: ItemFormDto) {
        const loggedInUserStatus = this.userType;
        console.log("loggedInUserStatus: " + loggedInUserStatus);

        this.currentUserType = loggedInUserStatus;
        this.formCurrentStatusID = itemFormDto.formStatusID;
        this.formTypeID = itemFormDto.formTypeID;
        this.createdByUserType = itemFormDto.createdByUserTypeID;
        this.createdBy = itemFormDto.createdBy;
        this.vendorContactID = itemFormDto.vendorContactID; 
        this.vendorContactName = itemFormDto.vendorContactName;
        this.vendorContactEmail = itemFormDto.vendorContactEmail;
        this.buyerID = itemFormDto.buyerID;
        this.buyerName = itemFormDto.buyerName;
        this.parentFlag = itemFormDto.parentFlag;
        this.isInGroup = itemFormDto.isInGroup;
    }
    get isReadOnly():boolean{
         return (this.parentFlag == "N" && this.isInGroup == "Y");
    }
    setFAMBuyer(buyerName: string, buyerID: number) {
        this.buyerName = buyerName;
        this.buyerID =  buyerID;
    }
    setSignatureData(lastUpdatedBy: string, lastUpdatedDate: Date){
        this.lastUpdatedBy = lastUpdatedBy;
        this.lastUpdatedDate = lastUpdatedDate;
    }
    setItemFormDisplayID(itemFormDisplayId : number, itemFormID: number)
    {
        this.itemFormDisplayID = itemFormDisplayId; 
        this.itemFormID = itemFormID;
    }
    setRefreshItemFormDisplayID(itemFormDisplayId : number, itemFormID: number)
    {
        this.refreshItemFormDisplayID = itemFormDisplayId; 
        this.refreshItemFormID = itemFormID;
    }
    setRefreshItemFormID(){
        if(this.refreshItemFormID){
            this.itemFormID =  this.refreshItemFormID;
            this.refreshItemFormID = null;
        }
        if(this.refreshItemFormDisplayID){
            this.itemFormDisplayID =  this.refreshItemFormDisplayID;
            this.refreshItemFormDisplayID = null;
        }        
    }
    deleteItemForm(): Observable<boolean> {
        this.itemForm = new ItemFormDto;
        this.itemForm.itemFormDisplayID = this.itemFormDisplayID;
        this.itemForm.id = this.itemFormID;
        return this.httpClient.post<boolean>(this.baseUrl + this.serviceBase + 'DeleteItemForm', this.itemForm);
    }
    clearAll(){
        sessionStorage.clear();
    }
    //public async Task<IEnumerable<ErrorDTO>> GetErrorMessagesByType(ErrorDTO errors)
    GetErrorMessagesByType(errors:IErrorDTO ): Observable<IErrorDTO[]> {     
        return this.httpClient.post<IErrorDTO[]>(this.baseUrl + this.serviceBase + 'GetErrorMessagesByType', errors);
    }

    saveItemForm(itemFormDto: IItemFormDto): Observable<IItemFormDto> {
        return this.httpClient.post<IItemFormDto>(this.baseUrl + this.serviceBase + 'SaveItemForm', itemFormDto);
    }

    updateItemForm(itemFormDto: IItemFormDto): Observable<IItemFormDto> {
        return this.httpClient.post<IItemFormDto>(this.baseUrl + this.serviceBase + 'UpdateItemForm', itemFormDto);
    }

    getItemFormData(itemFormDisplayId: number) {
        return this.httpClient.get<IItemFormDto>(this.baseUrl + this.serviceBase +  `GetItemFormData?itemFormDisplayId=${itemFormDisplayId}`);
    }

    isDsdVendorsExistForUser(userId: string) {
        return this.httpClient.get<boolean>(this.baseUrl + this.serviceBase + `IsDsdVendorsExistForUser?userId=${userId}`);
    }

    isDsdVendorsExistForItemForm(itemFormId: number) {
        return this.httpClient.get<boolean>(this.baseUrl + this.serviceBase + `IsDsdVendorsExistForItemForm?itemFormId=${itemFormId}`);
    }

    isFAMCodeExistsInProductGrouping(itemFormId: number) {
        return this.httpClient.get<boolean>(this.baseUrl + this.serviceBase + `IsFAMCodeExistsInProductGrouping?itemFormId=${itemFormId}`);
    }

    getFormUserPermittedActions(): Observable<FormUserPermittedActionDto[]> {
        return this.httpClient.get<FormUserPermittedActionDto[]>(this.baseUrl + this.workFlowServiceBase + `GetFormUserPermittedAction/${this.currentUserType}/${this.formCurrentStatusID}/${this.formTypeID}`);
        //this.currentUserType = UserType.Vendor;
        //return this.httpClient.get<FormUserPermittedActionDto[]>(this.baseUrl + this.workFlowServiceBase + `GetFormUserPermittedAction/${this.currentUserType}/1/1`);
    }

    getVendorForSearch(vendorDomainDto: IVendorDomainDto ): Observable<IVendorDomainDto[]> {
        return this.httpClient.post<IVendorDomainDto[]>(this.baseUrl + this.serviceBase + 'GetVendorForSearch', vendorDomainDto);
    }
    GetBasicItemDefinitionGTIN(itemFormID: number): Observable<IGTINWithCheckdigitDto[]> {
        return this.httpClient.get<IGTINWithCheckdigitDto[]>(this.baseUrl + this.serviceBase + `GetBasicItemDefinitionGTIN?itemFormID=${itemFormID}`);
    }
    GetPmdsBasicItemDefinitionDetailsByItemID(ItemCode: number): Observable<IBasicItemDefnitionDto> {
        return this.httpClient.get<IBasicItemDefnitionDto>(this.baseUrl + this.basicItemDefServiceBase + `GetPmdsBasicItemDefinitionDetailsByItemID?ItemCode=${ItemCode}`); 
    }
    GetItemFormErrors(ItemFormID: number): Observable<boolean> {
        return this.httpClient.get<IItemValidationDTO[]>(this.baseUrl + this.serviceBase + `GetItemFormErrors?ItemFormID=${ItemFormID}`)
         .pipe(
            map(res => {
                this.itemValidations = {};
                if(res){
                    for(var validation of res){
                        this.addItemValidation(validation);
                    }
                }
                return true;
            }),
            catchError((err) => {
                return of(false);
            })
         );
    }
    GetItemFormGroup(ItemFormID: number): Observable<boolean> {
        return this.httpClient.get<IItemFormDto[]>(this.baseUrl + this.serviceBase + `GetItemFormGroup?ItemFormID=${ItemFormID}`)
         .pipe(
            map(res => {
                if(res){
                    this.itemFormGroup = res.filter(item => item.id != this.itemFormID)
                }
                else {
                    this.itemFormGroup = []; 
                }
                return true;
            }),
            catchError((err) => {
                this.itemFormGroup = [];
                return of(false);
            })
         );
    }


    getUserType(): Observable<string> {        
        return this.httpClient.get<string>(this.baseUrl + this.serviceBase + `GetUserType?userID=${this.loggedInUser}`);
    }

    isItemCodeValid(ItemCode: number): Observable<boolean>{
        return this.GetPmdsBasicItemDefinitionDetailsByItemID(ItemCode).pipe(
            map(res => {
                if(res){
                   if((res.shipperFlag && res.shipperFlag == "Y" && this.isShipper())
                    || res.itemTypeCode === this.itemTypeCode)
                    return true;
                   else if ((res.shipperFlag && res.shipperFlag == "N" && !this.isShipper())
                    || res.itemTypeCode === this.itemTypeCode)
                    return true;
                }
                return false;
            }),
            catchError((err) => {
                return of(false);
            })
        );
    }
    getNextTab(currentTabRoute: string): string {
        var visibleTabs = this.links.filter(tab => tab.disabled == false);
        var curentTab = visibleTabs.find(tab => tab.link === currentTabRoute);       
              
        var next = visibleTabs[visibleTabs.findIndex(tab => tab.id == curentTab.id) + 1];       
        return (next)? next.link : null;

    }


    getPreviousTab(currentTabRoute: string): string {
        var visibleTabs = this.links.filter(tab => tab.disabled == false);
        var curentTab = visibleTabs.find(tab => tab.link === currentTabRoute);
       
        var previous = visibleTabs[visibleTabs.findIndex(tab => tab.id == curentTab.id) - 1];  
            return (previous) ? previous.link : null;            
    }

    addItemValidation(validation:IItemValidationDTO){
        this.itemValidations[validation.tabName] = validation;
        this.tabWarningsCount$.next({
            "tabName": validation.tabName,
            "value" : {
                "warningsCount":this.getWarningsCount(validation.tabName),
                "errorsCount":this.getErrorsCount(validation.tabName)
            }
        })
    }

    getItemValidation(tabName:string): IItemValidationDTO{
       return this.itemValidations[tabName];
    }
    clearItemValidation(tabName?:string){
        this.itemValidations = {};
    }
    tabWarningsCount$: Subject<object> = new Subject<object>();
    getWarningsCount(tabName:string){
        let count = 0;
        var tab:IItemValidationDTO =  this.itemValidations[tabName];
        if (tab && (tab.warnings)) {
            count = tab.warnings.length;
        }
        if (tab && tab.subTabValidations) {
           count += tab.subTabValidations
                    .reduce(function(a, b){
                        return a + b.warnings.length;
                    }, 0)
        }
        return count;
    }

    getErrorsCount(tabName:string){
        let count = 0;
        var tab:IItemValidationDTO =  this.itemValidations[tabName];
        if (tab && (tab.errors)) {
            count = tab.errors.length;
        }
        if (tab && tab.subTabValidations)
            {
           count += tab.subTabValidations
                    .reduce(function(a, b){
                        return a + b.errors.length;
                    }, 0)
        }

        return count;
    }

     

   
    // Methods for Buyer GPA
    isShipper():boolean {
        return (this.itemCaseTypeID && this.itemCaseTypeID == 2);
    }
    isRetail():boolean {
        return (this.retailPackagedItem && this.retailPackagedItem == "Y");
    }
    isType2Gtin():boolean {
        return (this.formattedGtin && this.formattedGtin.slice(0,3) == "002");
    }

    getNavigationLinks(itemForm: IItemFormDto, isExternal?:boolean): NewItemTab[] {

        let defaultLinks: NewItemTab[] = [
            { id: 0, name: 'Basic Item Definition', link: 'basic-item-definition', disabled: false },
            { id: 1, name: 'General Product Attributes', link: 'general-product-attributes', disabled: false },
            { id: 2, name: 'Shipper Item Composition', link: 'shipper-item-composition', disabled: false },
            { id: 3, name: 'Packaging Hierarchy', link: 'packaging-hierarchy', disabled: false },
            { id: 4, name: 'DSD Authorization Request', link: 'dsd-authorization-request', disabled: true },
            { id: 5, name: 'Product Grouping', link: 'product-grouping', disabled: false },
            { id: 6, name: 'Product Attributes', link: 'product-attributes', disabled: true },
            { id: 7, name: 'Scale Item Details', link: 'scale-item-attributes', disabled: false },
            { id: 8, name: 'Marketing Support', link: 'marketing-support', disabled: false },
            { id: 9, name: 'Extra Text', link: 'extra-text', disabled: false },
            { id: 10, name: 'Review/Create Item', link: 'review-create-item', disabled: false },
        ];
        let vendorLinks: NewItemTab[] = [
            { id: 0, name: 'Basic Item Definition', link: 'basic-item-definition', disabled: false },
            { id: 1, name: 'General Product Attributes', link: 'general-product-attributes', disabled: false },
            { id: 2, name: 'Shipper Item Composition', link: 'shipper-item-composition', disabled: false },
            { id: 3, name: 'Packaging Hierarchy', link: 'packaging-hierarchy', disabled: false },
            { id: 4, name: 'DSD Authorization Request', link: 'dsd-authorization-request', disabled: true },
            { id: 5, name: 'Product Grouping', link: 'product-grouping', disabled: false },
            { id: 6, name: 'Marketing Support', link: 'marketing-support', disabled: false },
        ];

        let dsdLinks: NewItemTab[] = [
            //{ id: 0, name: 'Basic Item Details', link: 'dsd-basic-item-definition', disabled: false },
            { id: 0, name: 'DSD Authorization Maintenance Request', link: 'dsd-authorization-request', disabled: false }
        ];
        //TODO remove hard code of form type for DSD Itemform
        if (itemForm.formTypeID == 3) {
            this.links = [...dsdLinks];
        }
        else if(isExternal){
            this.links = [...vendorLinks];
        }
        else {
            this.links = [...defaultLinks];
        }
       
        return this.links;

    }




}

