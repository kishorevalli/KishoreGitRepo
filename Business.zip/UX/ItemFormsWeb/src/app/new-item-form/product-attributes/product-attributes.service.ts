import { Injectable , Inject} from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ILookupDto, LookupDto, IItemSaveResponse } from '../../shared/common.interface';
import { APP_CONFIG, AppConfig } from '../../app.config';
import { IState, IProductAttribute, IProductMandatoryAttributesRequestDto, ProductMandatoryAttributesRequestDto , IProductAttributeScopingDto } from './product-attributes.interface';

@Injectable()
export class ProductAttributesService {
    private baseUrl;
    private serviceBase: string = "api/ProductAttributes/";
    constructor(@Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;
    }

    getStates(): Observable<IState[]> {
        return this.httpClient.get<IState[]>(this.baseUrl + this.serviceBase + 'GetStates');
    }

    getCounties(stateShortName: string): Observable<IState[]> {
        return this.httpClient.get<IState[]>(this.baseUrl + this.serviceBase + `GetCounties?stateShortName=${stateShortName}`);
    }

    getCities(state: IState): Observable<IState[]> {
        return this.httpClient.post<IState[]>(this.baseUrl + this.serviceBase + 'GetCities' , state);
    }

    getFacilityGroupTypes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetFacilityGroupTypes');
    }
    getFacilityGroupByType(groupType: string): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + `GetFacilityGroupByType?groupType=${groupType}` );

    }


    getMandatoryAttributes(mandatoryAttributesRequest: ProductMandatoryAttributesRequestDto, modelGroupCodeType: number , itemFormID: number) {    
        let url = `GetMandatoryAttributes/${modelGroupCodeType}/${itemFormID}`;        
      //  url = url + `/${mandatoryAttributesRequest.itemFormID}`;       
       // mandatoryAttributesRequest.modelGroupCodeType = modelGroupCodeType;    
        return this.httpClient.post<IProductAttribute[]>(this.baseUrl + this.serviceBase + url, mandatoryAttributesRequest).catch(this.handleError);
    }

    

    getProductAttributes(itemFormID: number) {
        return this.httpClient.get<IProductAttribute[]>(this.baseUrl + this.serviceBase + `GetProductAttributes?itemFormID=${itemFormID}`);
    }

    getProductAttributesScopingDetails(itemFormID: number) {
        return this.httpClient.get<IProductAttributeScopingDto[]>(this.baseUrl + this.serviceBase + `GetProductAttributesScopingDetails?itemFormID=${itemFormID}`);
    }

    SaveProductAttributes(productAttributes: IProductAttribute[] , itemFormID: number , formStatusID?: number, formActionID?: number) :Observable<IItemSaveResponse> {     
        let url = `SaveProductAttributes/${itemFormID}`;
        if (formStatusID && formActionID) {
            url = url + `/${formStatusID}/${formActionID}`;
        }
        return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + url, productAttributes);
    }
    
    private handleError(err: HttpErrorResponse) {
        console.error(err.message);
        return Observable.throw(err.message);
    }
}
