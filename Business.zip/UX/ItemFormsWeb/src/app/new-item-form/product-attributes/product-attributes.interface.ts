﻿import { ILookupDto, ILookupIntDto, LookupDto, IItemSaveResponse } from '../../shared/common.interface';
export interface IProductAttribute {
    ID: number;
    itemFormID: number;
    itemGroupType?: string;
    itemGroupCode?: number;   
    currentFamilyNo: string;
    productAttributeGroupCode?: number;
    productAttributeGroupDescription?: string;
    productAttributeType: string;
    attributeCode: number;
    attributeDescription?: string;
    attributeValueSequenceNumber : number;
    attributeValueDisplayText? : string;
    newAttributeValue? : string;
    attributeCodeStatus?: string;    
    newAttributeApprovalIndicator?: string;
    newAttributeApprovedBy?: string;
    newAttributeApprovedDate?: Date;
    effectiveDate?: Date;
    terminationDate?: Date;  
    modelCodeValue1?: number;
    modelCodeValueDescription1?: string;
    modelCodeValue2?: number;
    modelCodeValueDescription2?: string;
    modelCodeValue3?: number;
    modelCodeValueDescription3?: string;
    dataType: string;
    createdBy?: string;
    createdDate?: Date;
    lastUpdatedBy?: string;
    lastUpdatedDate?: Date;
    modelGroupCodeType: number;
    permittedValues: ILookupIntDto[];
    rowId: number;
    visible: string;
    readOnly: string;
 //   isApproved: boolean;
}


export class ProductAttribute implements IProductAttribute {
    ID: number;
    itemFormID: number;
    productAttributeGroupCode: number;
    productAttributeGroupDescription: string;
    productAttributeType: string;
    attributeCode: number;
    attributeDescription: string;
    attributeValueSequenceNumber: number;
    attributeValueDisplayText: string;
    newAttributeValue: string;
    attributeCodeStatus: string;    
    newAttributeApprovalIndicator: string;
    newAttributeApprovedBy: string;
    newAttributeApprovedDate: Date;
    effectiveDate: Date;
    terminationDate: Date;
    itemGroupType: string;
    itemGroupCode?: number;
    currentFamilyNo: string;
    modelCodeValue1?: number;
    modelCodeValueDescription1?: string;
    modelCodeValue2?: number;
    modelCodeValueDescription2?: string;
    modelCodeValue3?: number;
    modelCodeValueDescription3?: string;
    dataType: string;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
    modelGroupCodeType: number;
    permittedValues: ILookupIntDto[];
    rowId: number;
    visible: string;
    readOnly: string;
   // isApproved: boolean;
}

export interface IState {
    stateShortName: string;
    stateFullName: string;
    countyName: string;
    cityName: string;
}

export class State implements IState {
    stateShortName: string;
    stateFullName: string;
    countyName: string;
    cityName: string;
}

export interface IProductMandatoryAttributesRequestDto {
  //  itemFormID: number;
    currentFamNo: number;
    itemCode: number;
  //  modelGroupCodeType: number;
    itemGroupTypes: IItemGroupType[];
}

export class ProductMandatoryAttributesRequestDto implements IProductMandatoryAttributesRequestDto{
 //   itemFormID: number;
    currentFamNo: number;
    itemCode: number;
  //  modelGroupCodeType: number;
    itemGroupTypes: IItemGroupType[];
}

export interface IProductAttributeScopingDto {
    ID: number;
    productAttributeGroupCode: number;
    productAttributeGroupDescription: string;
    attributeCode?: number;
    attributeDescription: string;
    tableName: string;
    columnName: string;
    readOnly: string;
    visible: string;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
    columnValue: string;
}

export class ProductAttributeScopingDto implements IProductAttributeScopingDto {
    ID: number;
    productAttributeGroupCode: number;
    productAttributeGroupDescription: string;
    attributeCode?: number;
    attributeDescription: string;
    tableName: string;
    columnName: string;
    readOnly: string;
    visible: string;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
    columnValue: string;
}


export interface IItemGroupType {
    itemGroupCode: number;
    itemGroupTypeCode: string;
}

export class ItemGroupType implements IItemGroupType {
    itemGroupCode: number;
    itemGroupTypeCode: string;
}
