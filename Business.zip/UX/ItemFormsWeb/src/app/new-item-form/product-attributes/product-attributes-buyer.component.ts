import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormArray, FormGroup, Validators } from '@angular/forms';
import { NewItemFormService } from '../new-item-form.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { DialogProductAttributesComponent } from './dialog-product-attribute/dialog-product-attributes.component';
import { GridEvent } from '../../shared/grid/grid-event';
import { IErrorDTO, ErrorDTO } from '../../shared/common.interface';
import { Router, ActivatedRoute } from '@angular/router';
import {
    IProductAttribute, ProductAttribute, IProductMandatoryAttributesRequestDto,
    ProductMandatoryAttributesRequestDto, IItemGroupType, ItemGroupType, IProductAttributeScopingDto
} from './product-attributes.interface';
import { ProductAttributesService } from './product-attributes.service';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { of } from 'rxjs/observable/of';
import { Observable } from 'rxjs/Observable';
import { catchError, tap, map } from 'rxjs/operators';
import { IItemFormDto, ItemFormDto, NewItemTab, UserType, FormUserPermittedActionDto } from '../new-item-form.interface';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import * as _moment from 'moment';
const moment = _moment;

@Component({
  selector: 'ifw-product-attributes-buyer',
  templateUrl: './product-attributes-buyer.component.html',
  styleUrls: ['./product-attributes-buyer.component.scss']
})
export class ProductAttributesBuyerComponent implements OnInit {
    itemFormDisplayID: number;
    itemFormID: number;
    modelProductItemCode: number;
    modelPackagingItemCode: number;
    productAttributesBuyerFormGroup: FormGroup;
    itemGroupModelItem: number;
    public errors: any[];
    public warnings: any[];
    dirty: boolean;
    showSpinnerSearchButton: boolean = false;

    // GRID
    //public dataTabs: any = [];
    public gridData: IProductAttribute[] = [];
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 10;
    public filterable: boolean = true;
    public filterBy: string = '';
    public filterValue: string = '';
    public sortable: boolean = true;
    public active: string = '';
    public direction: string = '';
    public productAttributes: IProductAttribute[] = [];
    public productAttributesModelList: IProductAttribute[] = [];
    public productAttributesModel3List: IProductAttribute[] = [];
    public productAttributesItemForms: IProductAttribute[] = [];
    public productAttributesInvisible: IProductAttribute[] = [];
    public isCategoryManager: boolean = false;

    public showSpinner: boolean = false;
    public skipSaveTab: boolean = false;

    constructor(private fb: FormBuilder,
        private newItemFormService: NewItemFormService,
        private productAttributeService: ProductAttributesService,
        private router: Router,
        public snackBar : MatSnackBar,
    public dialog: MatDialog) { }


    ngOnInit() {
        this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        this.itemFormID = this.newItemFormService.itemFormID;
       // this.modelProductItemCode = this.newItemFormService.modelProductItemcode;
       // this.modelPackagingItemCode = this.newItemFormService.modelPackagingItemCode;
        this.createFormGroup();
       

        this.pagination = true;
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };

        this.errors = [];
        this.warnings = [];

        
       
        
        this.getProductAttributes();
        

    }

    getProductAttributes() {
        let modelProductItemCodeReq: ProductMandatoryAttributesRequestDto = new ProductMandatoryAttributesRequestDto();
        modelProductItemCodeReq.itemCode = this.newItemFormService.modelProductItemcode;

        let modelPackagingItemCodeReq: ProductMandatoryAttributesRequestDto = new ProductMandatoryAttributesRequestDto();
        modelPackagingItemCodeReq.itemCode = this.newItemFormService.modelPackagingItemCode;

        let mandatoryProductAttributesReq: ProductMandatoryAttributesRequestDto = new ProductMandatoryAttributesRequestDto();

        forkJoin(this.productAttributeService.getProductAttributes(this.itemFormID),
            this.productAttributeService.getMandatoryAttributes(modelProductItemCodeReq, 1, this.itemFormID).catch(this.emptyOnError),
            this.productAttributeService.getMandatoryAttributes(modelPackagingItemCodeReq, 2, this.itemFormID).catch(this.emptyOnError),
            this.productAttributeService.getMandatoryAttributes(mandatoryProductAttributesReq, 4, this.itemFormID).catch(this.emptyOnError),
            this.productAttributeService.getProductAttributesScopingDetails(this.itemFormID).catch(this.emptyOnError),
            this.newItemFormService.getUserType().catch(this.emptyOnError),
        ).subscribe(results => {
            this.productAttributesItemForms = results[0];
            this.productAttributesModelList = [...results[1], ...results[2]];
            this.mergeProductAttributesModelList(this.productAttributesModelList, results[3]);
            this.mergeProductAttributesScoping(results[4]); // scoping
            console.log(results[5]);
            if (results[5] == 'MGR')
                this.isCategoryManager = true;
            this.setRowId();
            this.populateInitialProductAttributeData();
            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
                const validations: any = this.newItemFormService.getItemValidation("Product Attributes");
                if (validations) {
                    this.handleValidationErrors(validations);
                }
            });
            //setTimeout(() => {
            //    const validations: any = this.newItemFormService.getItemValidation("Product Attributes");
            //    if (validations) {
            //        console.log("validations running.")
            //        this.handleValidationErrors(validations);
            //    }
            //}, 0);
           
            });
     
    }

    checkIsCategoryManager() {
        this.newItemFormService.getUserType().subscribe(res => {
            if (res == 'MGR')
                this.isCategoryManager = true;
        });        
    }

 createFormGroup()
{
    this.productAttributesBuyerFormGroup = this.fb.group({
        itemFormID: this.itemFormID,
        modelProductItemCode: { value: this.newItemFormService.modelProductItemcode, disabled: true },
        modelPackagingItemCode: { value: this.newItemFormService.modelPackagingItemCode, disabled: true },
        productAttributeModelItem: ''
     
    });
 }
    itemGroupModelItemChanged(modelItem: number) {
        this.productAttributesBuyerFormGroup.patchValue({ itemGroupModelItem: modelItem });
    }
    /**
   * get all product attribute codes of the entered item code.
   */
    getProductAttributesByItemCode() {
        let productAttributeModelItem = this.productAttributesBuyerFormGroup.get('productAttributeModelItem').value;
        if (productAttributeModelItem) {
            this.showSpinnerSearchButton = true;
            this.newItemFormService.isItemCodeValid(productAttributeModelItem).subscribe(isValid => {
             if (isValid) {
            let itemGroupModelItemReq: ProductMandatoryAttributesRequestDto = new ProductMandatoryAttributesRequestDto();
                 itemGroupModelItemReq.itemCode = productAttributeModelItem;
            this.productAttributeService.getMandatoryAttributes(itemGroupModelItemReq, 3, this.itemFormID).subscribe(res => {
                        this.showSpinnerSearchButton = false;
                        if (!res) res = [];
                        this.productAttributesModel3List = res;
                        this.clearModelCodeValue3(this.productAttributes);
                        this.mergeProductAttributesModelList(this.productAttributesModel3List, this.productAttributes);
                        this.populateInitialProductAttributeData();
                    },
                        (err) => {
                            this.showSpinnerSearchButton = false;
                            this.openSnackbar(err);
                        });
                }
                else {
                    this.showSpinnerSearchButton = false;
                    this.openSnackbar("Invalid Item Code.");
                }
            },
                (err) => {
                    this.showSpinnerSearchButton = false;
                    this.openSnackbar(err);
                });
        }
    }

    mergeProductAttributesModelList(productAttributesModelList: IProductAttribute[] , mandatroyAttributes : IProductAttribute[]) //: IProductAttribute[] {
    {        
        for (let productAttribute of productAttributesModelList) {
            let found = mandatroyAttributes.find(item => item.productAttributeGroupCode == productAttribute.productAttributeGroupCode
                && item.attributeCode == productAttribute.attributeCode && item.itemGroupType == productAttribute.itemGroupType 
                && item.itemGroupCode == productAttribute.itemGroupCode); // && !item[`modelCodeValue${productAttribute.modelGroupCodeType}`]
            if (found) {             
                if (productAttribute.permittedValues.length > 0) {
                    found[`modelCodeValue${productAttribute.modelGroupCodeType}`] = productAttribute.permittedValues[0].code;      
                    found[`modelCodeValueDescription${productAttribute.modelGroupCodeType}`] = productAttribute.permittedValues[0].description; 
                  //  found['visible'] = 'Y';
                  //  found['readOnly'] = 'N';                       
                        }             
            }
        }

        for (let productAttribute of this.productAttributesItemForms) {
            let found = mandatroyAttributes.find(item => item.productAttributeGroupCode == productAttribute.productAttributeGroupCode
                && item.attributeCode == productAttribute.attributeCode && item.itemGroupType == productAttribute.itemGroupType
                && item.itemGroupCode == productAttribute.itemGroupCode);
            if (found) {
                found['attributeValueDisplayText'] = productAttribute.attributeValueDisplayText;
                found['attributeValueSequenceNumber'] = productAttribute.attributeValueSequenceNumber;
                found['newAttributeValue'] = productAttribute.newAttributeValue;
                found['newAttributeApprovalIndicator'] = productAttribute.newAttributeApprovalIndicator;        
               // found['isApproved'] = productAttribute.isApproved;        
                found['newAttributeApprovedDate'] = productAttribute.newAttributeApprovedDate;     
                found['newAttributeApprovedBy'] = productAttribute.newAttributeApprovedBy;     
               // found['visible'] = 'Y';
              //  found['readOnly'] = 'N';        
               }
        }

        this.productAttributes = mandatroyAttributes;
    //    return productAttributes;
    }

    mergeProductAttributesScoping(productScopingDetails: IProductAttributeScopingDto[]) {
        for (let productAttribute of this.productAttributes) {
            if (productScopingDetails.length > 0) {
                let found = productScopingDetails.find(ps => (ps.attributeCode == productAttribute.attributeCode && ps.productAttributeGroupCode == productAttribute.productAttributeGroupCode));
                if (found) {
                    productAttribute.visible = found.visible;
                    productAttribute.readOnly = found.readOnly;
                    productAttribute.attributeValueDisplayText = found.columnValue;
                }
            }
        }        
    }

    updateSelectedValue(row: IProductAttribute, modelCodeValueType: string) {
        row.attributeValueSequenceNumber = row[`modelCodeValue${modelCodeValueType}`];    
        row.attributeValueDisplayText = row[`modelCodeValueDescription${modelCodeValueType}`];  
        row.newAttributeValue = null;
        row.newAttributeApprovalIndicator = null;
        row.newAttributeApprovedBy = null;
        row.newAttributeApprovedDate = null;
        this.dirty = true;
        this.populateInitialProductAttributeData();
    }

    clearModelCodeValue3(productAttributes: IProductAttribute[]): IProductAttribute[] {
        for (let pa of productAttributes) {
            pa.modelCodeValue3 = null;   
            pa.modelCodeValueDescription3 = null;                     
        }
        return productAttributes;
    }
    

    setRowId() {
        let count: number = 1;
        for (const pa of this.productAttributes) {
            pa.rowId = count++;
        } 
    }

    changeIsApproved(row: IProductAttribute, checked: boolean) {
      //  row.isApproved = checked;
        if (checked) {
            row.newAttributeApprovalIndicator = 'Y';
         //   row.newAttributeApprovedBy = this.newItemFormService.loggedInUser;
          //  row.newAttributeApprovedDate = new Date(moment().format("MM/DD/YYYY"));
        }
        else {
            row.newAttributeApprovedBy = null;
            row.newAttributeApprovedDate = null;
            row.newAttributeApprovalIndicator = null;
        }
        this.dirty = true;
    }

    /**
 *  I add a catch to each request in the forkJoin. This allows for partial failures in the detail requests. 
 *  Basically, we don't want to fail all requests just because a single call has an issue.
 * @param err 
 */
    private emptyOnError(err: any) {
        return of([]);
    }
     
    getProductAttributesForItemCode() {


    }

    public addProductAttributesDialog(): void {      
        let dialogRef = this.dialog.open(DialogProductAttributesComponent,  {
                width: '1000px',
                data: { isBuyer : true}
            });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                console.log('The dialog was closed');
            }
          
            console.log('The dialog was closed');
        });

    }


    public editProductAttributesDialog(rowId: number): void {
        let productAttributesRow: IProductAttribute = this.productAttributes.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogProductAttributesComponent, {
            width: '1000px',
            data: { isBuyer: true, productAttributesRow: productAttributesRow}
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                console.log('The dialog was closed');
                if (result && result.rowId) {
                    let productAttributesRow: IProductAttribute = this.productAttributes.find(x => x.rowId == rowId);
                    if (result.newAttributeValue) {
                        productAttributesRow.attributeValueSequenceNumber = null;
                        productAttributesRow.attributeValueDisplayText = null;
                        productAttributesRow.newAttributeValue = result.newAttributeValue;
                      //  productAttributesRow.newAttributeApprovalIndicator = 'Y';
                        
                    }
                    else {
                        productAttributesRow.newAttributeValue = null;
                        productAttributesRow.newAttributeApprovalIndicator = null;
                        productAttributesRow.attributeValueSequenceNumber = result.attributeSelectedValue;
                        productAttributesRow.attributeValueDisplayText = productAttributesRow.permittedValues.find(pv => pv.code == result.attributeSelectedValue).description; 
                    }
                    
                   // this.productAttributes.splice(result.rowId - 1, 1, result)
                    this.dirty = true;
                    this.populateInitialProductAttributeData();
                }
            }

            console.log('The dialog was closed');
        });
    }
    performAction(action: any) {
        switch (action.actionName) {
            case "Save":            
                    this.saveTab(action.createdFormStatusID, action.actionID);
                    break;                
            case "Delete":
                this.deleteItemForm();
                break;
            case "Submit":
                //this.saveTab(action.createdFormStatusID, action.actionID);
                break;

        }
    }

    reset() { }


    public saveTab(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            if (res) {
                this.getProductAttributes();
                this.openSnackbar("Saved successfully.");
            }
        });
    }
    saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
        if (this.skipSaveTab) return of(true);
        if (!createdFormStatusID && !this.dirty) return of(true);
        this.showSpinner = true;
        
        return this.productAttributeService.SaveProductAttributes(this.productAttributes, this.itemFormID, createdFormStatusID, actionID).pipe(
            map(res => {                
                if (createdFormStatusID) {
                    this.newItemFormService.formCurrentStatusID = createdFormStatusID;
                }               
                this.newItemFormService.addItemValidation(res.validation);
                this.handleValidationErrors(res.validation); // for handling warnings.
                console.log("saved successfully.");
                this.showSpinner = false;
                return true;
            }),
            catchError((err) => {
                this.showSpinner = false;
                if (err.status === 400) {
                    this.newItemFormService.addItemValidation(err.error);
                    this.handleValidationErrors(err.error);
                }
                else if (err.status === 401) {
                    console.log("saved error. " + err.status);
                    let message = err.error.exceptionMessage || err.error.message;
                    this.errors.push(message);
                }
                else {
                    console.log("saved error. " + err.status);
                    let message = err.error.exceptionMessage || err.error.message;
                    this.errors.push(message);
                }
                window.scrollTo(0, 150);
                this.openSnackbar("Please correct the errors.");
                return of(false);
            })
        );
    }

    public deleteItemForm(): void {
        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.showSpinner = true;
                this.newItemFormService.deleteItemForm().subscribe(res => {
                    this.showSpinner = false;
                    if (res != undefined) {
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: 'merge' });
                },
                    (err) => {
                        this.showSpinner = false;
                    })
            }
        });
    }

    /**
  * OPen snack bar message
  */
    private openSnackbar(message: string) {
        this.snackBar.open(message, null, {
            duration: 3000,
            horizontalPosition: 'center',
            verticalPosition: 'top',
        });
    }

    handleValidationErrors(validationDTO: any) {
        let errorDTOs = validationDTO.errors;
        let warningDTOs = validationDTO.warnings;

        this.errors = [];
        for (let errorDTO of errorDTOs) {
            this.errors.push(errorDTO.errorDescription);
        }

         this.warnings = [];
        for (let warningDTO of warningDTOs) {
            this.warnings.push(warningDTO.errorDescription);
        }
    }

    // Grid specific events
    getGridData() {
        if (!this.gridData) return [];
        return this.gridData.filter(pa => pa.visible == 'Y');
        //let packagingHierarchy = (<any>Object).assign({}, this.packagingHierarchyFormArray.at(this.activeTabIndex).value);
        //return packagingHierarchy.orderablePackLevels;    
    }

    updateData(gridEvent: GridEvent) {
        this.gridData = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }
    populateInitialProductAttributeData() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 10,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.updateData(gridEvent);
    }

    /**
  * return the filtered or shallow copy without changing the original data
  */
    performFilter(gridEvent: GridEvent): any[] {              
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.productAttributes.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.productAttributes.slice();
        }
        return this.productAttributes.slice();
    }

    /**
     * paginate the result set
     */
    private pageData(gridEvent: GridEvent): void {

        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

    /**
* sort the filtered result based on sort column and order
*/
    private sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }

}
