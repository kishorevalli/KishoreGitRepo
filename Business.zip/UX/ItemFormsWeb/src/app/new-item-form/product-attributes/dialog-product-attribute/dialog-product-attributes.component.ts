import { Component, OnInit , Inject} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ProductAttributesService } from '../product-attributes.service';
import { IState, State , IProductAttribute} from '../product-attributes.interface';
import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto } from '../../../shared/common.interface';

@Component({
  selector: 'ifw-dialog-product-attributes',
  templateUrl: './dialog-product-attributes.component.html',
  styleUrls: ['./dialog-product-attributes.component.scss']
})
export class DialogProductAttributesComponent implements OnInit {
    productAttributeFormGroup: FormGroup;
    statesList: IState[];
    countiesList: IState[];
    citiesList: IState[];
    facilityGroupTypesList: ILookupDto[];
    facilityGroupsList: ILookupDto[];
    permittedValuesList: ILookupDto[];
    newValueIsNumeric: boolean;
    constructor(private fb: FormBuilder,        
        public dialogRef: MatDialogRef<DialogProductAttributesComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private productAttributesService: ProductAttributesService) { }

    ngOnInit() {

        if (this.data.productAttributesRow) {
            this.productAttributeFormGroup = this.fb.group({
                itemAttributeGroup: {value : `${this.data.productAttributesRow.productAttributeGroupCode} - ${this.data.productAttributesRow.productAttributeGroupDescription}` , disabled: true },
                attributeType: { value: this.data.productAttributesRow.productAttributeType , disabled: true },
                attributeCode: { value: this.data.productAttributesRow.attributeCode, disabled: true },
                attributeDescription: { value: this.data.productAttributesRow.attributeDescription, disabled: true },
                attributeSelectedValue: this.data.productAttributesRow.attributeValueSequenceNumber,
               // attributeValueDisplayText: this.data.productAttributesRow.attributeValueDisplayText,
                newAttributeValue: this.data.productAttributesRow.newAttributeValue,
                effectiveDate: '',               
                rowId: this.data.productAttributesRow.rowId

            });

            this.permittedValuesList = this.data.productAttributesRow.permittedValues;
            this.newValueIsNumeric = (this.data.productAttributesRow.dataType == 'S' || this.data.productAttributesRow.dataType == 'V') ? false : true;
        }
        //else {
        //    this.productAttributeFormGroup = this.fb.group({
        //        itemAttributeGroup: { value: '', disabled: true },
        //        attributeType: { value: '', disabled: true },
        //        attributeCode: { value: '', disabled: true },
        //        attributeDescription: { value: '', disabled: true },
        //        attributeSelectedValue: '',
        //        newAttributeValue: '',
        //        effectiveDate: ''
        //    });
        //}

        this.productAttributesService.getStates().subscribe(res => {
            this.statesList = res;
        });

        this.productAttributesService.getFacilityGroupTypes().subscribe(res => {
            this.facilityGroupTypesList = res.map(gt => ({ code: gt.code, description: gt.description}));            
        });
        
    }

    onStateChange(stateShortName : string) {
        this.productAttributesService.getCounties(stateShortName).subscribe(res => {
            this.countiesList = res;
        });
    }


    onPermittedValueChange(permittedValue: number) {
        this.productAttributeFormGroup.patchValue({ 'attributeSelectedValue': permittedValue });        
    }

    onNewValueChange(value: number) {
        this.productAttributeFormGroup.patchValue({ 'newAttributeValue': value });    }

    public onSave(): void {
        if (this.productAttributeFormGroup.invalid) {
       //     return this.showErrors();
        }
        let productAttribute: IProductAttribute = (<any>Object).assign({}, this.productAttributeFormGroup.value);
        this.dialogRef.close(productAttribute);
    }

    //onCountyChange(countyName: string) {
    //    let state: IState = new State();
    //        state.stateShortName = this.newProductAttributeFormGroup.get('state').value;
    //        state.countyName = countyName;
    //    this.productAttributesService.getCities(state).subscribe(res => {
    //        this.citiesList = res;
    //    });
    //}

    onFacGrpTypeChange(grpType : string) {
        this.productAttributesService.getFacilityGroupByType(grpType).subscribe(res => {
            this.facilityGroupsList = res.map(fg => ({ code: fg.code, description: fg.description }));      
        });
    }

    public onCancel(): void {
        this.dialogRef.close();
    }


    public onAdd(): void {
        
    }
   
    public onAddContinue(): void {

    }

}
