import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { APP_CONFIG, AppConfig } from '../../app.config';
import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto, IScaleItemFacilityLookupDto, ScaleItemFacilityLookupDto, ILookupIntFlagDto, LookupIntFlagDto, IItemSaveResponse } from '../../shared/common.interface';
import { IScaleInfoDto, ScaleInfoDto } from './scale-item-details.interface';

@Injectable()
export class ScaleItemDetailsBuyerService {

    private baseUrl;
    private serviceBase: string = 'api/ScaleItemDetails/';
    private type: string = 'SD';
    constructor(@Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {

        this.baseUrl = config.apiEndpoint;
    }


    getFacilityGroupByTypeScaleDescription(): Observable<IScaleItemFacilityLookupDto[]> {
        
        return this.httpClient.get<IScaleItemFacilityLookupDto[]>(this.baseUrl + this.serviceBase + 'GetFacilityGroupByType?Type=SD');

    }

    getFacilityGroupByTypeScaleShelfLife(): Observable<IScaleItemFacilityLookupDto[]> {
        return this.httpClient.get<IScaleItemFacilityLookupDto[]>(this.baseUrl + this.serviceBase + 'GetFacilityGroupByType?Type=SS');

    }

    getFacilityGroupByTypeScaleGrade(): Observable<IScaleItemFacilityLookupDto[]> {
        return this.httpClient.get<IScaleItemFacilityLookupDto[]>(this.baseUrl + this.serviceBase + 'GetFacilityGroupByType?Type=SG');

    }

    getScaleLocation(): Observable<ILookupIntFlagDto[]> {
        return this.httpClient.get<ILookupIntFlagDto[]>(this.baseUrl + this.serviceBase + 'GetScaleLocation');

    }

    getScaleGrade(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetScaleGrade');

    }

    getScaleActionCodes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetScaleActionCodes');

    }

    getFacilityGroupTypes(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetFacilityGroupTypes');

    }

    saveScaleInfo(scaleInfo: IScaleInfoDto): Observable<IItemSaveResponse> {
        return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + 'SaveScaleInfo', scaleInfo);
    }

    getScaleInfo(itemFormId:number): Observable<IScaleInfoDto> {
        return this.httpClient.get<IScaleInfoDto>(this.baseUrl + this.serviceBase + `GetScaleInfo?itemFormID=${itemFormId}`);
    }

    
}
