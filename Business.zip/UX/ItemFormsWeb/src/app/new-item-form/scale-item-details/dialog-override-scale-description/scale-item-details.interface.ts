﻿export class IScaleItemOverrideDetailsDto {
    rowId: number;
    itemFormID: number;
    facilityGroupType: string;
    facilityGroupTypeDescription: string;
    facilityGroupCode: number;
    facilityGroupDescription: string;
    overrideDescriptionLine1: string;
    overrideDescriptionLine2: string;
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}

export class ScaleItemOverrideDetailsDto implements IScaleItemOverrideDetailsDto {
    rowId: number;
    itemFormID: number;
    facilityGroupType: string;
    facilityGroupTypeDescription: string;
    facilityGroupCode: number;
    facilityGroupDescription: string;
    overrideDescriptionLine1: string;
    overrideDescriptionLine2: string;
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}