import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { IScaleItemOverrideDetailsDto, ScaleItemOverrideDetailsDto } from './scale-item-details.interface';
import { IScaleItemFacilityLookupDto, ScaleItemFacilityLookupDto } from '../../../shared/common.interface';
import { ScaleItemDetailsBuyerService } from '../scale-item-details-buyer.service';
import { DialogContentComponent } from '../../basic-item-definition/dialog-content.component';


@Component({
  selector: 'ifw-dialog-override-scale-description',
  templateUrl: './dialog-override-scale-description.component.html',
  styleUrls: ['./dialog-override-scale-description.component.scss']
})
export class DialogOverrideScaleDescriptionComponent implements OnInit {

    onAddEvent = new EventEmitter<IScaleItemOverrideDetailsDto>();
    public isEdit: boolean = false;
    overrideScaleDescription: FormGroup;
    public facilityGroupType: string;
    public facilityGroupTypeDescription: string;

    public facilityGroupScaleDescriptionList: IScaleItemFacilityLookupDto[];
    public scaleItemOverrideDetails: IScaleItemOverrideDetailsDto;
    public scaleItemOverrideDetailslist: IScaleItemOverrideDetailsDto[];
    public parentScaleItemOverrideDetails: IScaleItemOverrideDetailsDto[];
    public createdByUserTypeID: number;

    constructor(public dialogRef: MatDialogRef<DialogOverrideScaleDescriptionComponent>,
        private formBuilder: FormBuilder,
        private scaleItemDetailsBuyerService: ScaleItemDetailsBuyerService,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    ngOnInit() {

        this.parentScaleItemOverrideDetails = this.data.parentScaleItemOverrideDetails;
        this.scaleItemDetailsBuyerService.getFacilityGroupByTypeScaleDescription().subscribe(res => {
            this.facilityGroupScaleDescriptionList = res.map(fgd => ({
                code: Number(fgd.code),
                description: fgd.description,
                facilityGroup: fgd.facilityGroup,
                facilityGroupDescription: fgd.facilityGroupDescription,
                facilityCodeDescription: fgd.facilityCodeDescription
            }));
            if (res != undefined) {
                this.facilityGroupType = res[0].facilityGroup;
                this.facilityGroupTypeDescription = res[0].facilityGroupDescription;
            }
        });


        if (this.data.scaleItemOverrideDetailsRow != undefined) {
            this.overrideScaleDescription = this.formBuilder.group({
                rowId: this.data.scaleItemOverrideDetailsRow.rowId,
                facilityGroupSD: this.data.scaleItemOverrideDetailsRow.facilityGroupCode,
                ovrDesc1: this.data.scaleItemOverrideDetailsRow.overrideDescriptionLine1,
                ovrDesc2: this.data.scaleItemOverrideDetailsRow.overrideDescriptionLine2
                
            });
            this.scaleItemOverrideDetailslist = this.data.scaleItemOverrideDetailslist;
            this.isEdit = true;
        }
        else {
            this.overrideScaleDescription = this.formBuilder.group({
                facilityGroupSD: '',
                ovrDesc1: '',
                    ovrDesc2: ''
                
            });
            this.scaleItemOverrideDetailslist = [];
        }

        
        
        

  }

    public onCancel(): void {
        this.dialogRef.close();
    }

    public onAdd(): void {

        
            let scaleItemOverrideDetailsDto = this.getScaleItemOverrideDetailsDto();
            scaleItemOverrideDetailsDto.rowId = this.scaleItemOverrideDetailslist.length + 1;
            if (!this.checkDuplicateOverrideScaleDescription(scaleItemOverrideDetailsDto)) {
                this.scaleItemOverrideDetailslist.push(scaleItemOverrideDetailsDto);
                this.data.scaleItemOverrideDetailslist = this.scaleItemOverrideDetailslist;
                this.dialogRef.close(scaleItemOverrideDetailsDto);
            } else {
                let data = { description: "Override Scale Descriptin already exists", options: ["Ok"] }
                let dialogRef = this.dialog.open(DialogContentComponent, {
                    disableClose: true,
                    width: '800px',
                    data: data
                });
                console.log("Override Scale Descriptin already exists");
            }
        
    }
    public onAddContinue(): void {

        
            let scaleItemOverrideDetailsDto = this.getScaleItemOverrideDetailsDto();
            scaleItemOverrideDetailsDto.rowId = this.scaleItemOverrideDetailslist.length + 1;
            if (!this.checkDuplicateOverrideScaleDescription(scaleItemOverrideDetailsDto)) {
                this.scaleItemOverrideDetailslist.push(scaleItemOverrideDetailsDto);
                this.data.scaleItemOverrideDetailslist = this.scaleItemOverrideDetailslist;

                this.overrideScaleDescription.reset();
                this.onAddEvent.emit(scaleItemOverrideDetailsDto);
                this.overrideScaleDescription.reset();
            }
            else {
                let data = { description: "Override Scale Descriptin already exists", options: ["Ok"] }
                let dialogRef = this.dialog.open(DialogContentComponent, {
                    disableClose: true,
                    width: '800px',
                    data: data
                });
                console.log("Override Scale Descriptin already exists");
            }
       

    }

    public getScaleItemOverrideDetailsDto(): ScaleItemOverrideDetailsDto {
        let scaleItemOverrideDetailsDto = new ScaleItemOverrideDetailsDto();

        let refCode = this.overrideScaleDescription.get("facilityGroupSD").value;
        var refObject = this.facilityGroupScaleDescriptionList.find(x => x.code == refCode);
        scaleItemOverrideDetailsDto.facilityGroupType = refObject.facilityGroup;
        scaleItemOverrideDetailsDto.facilityGroupTypeDescription = refObject.facilityGroupDescription;
        scaleItemOverrideDetailsDto.facilityGroupCode = refObject.code;
        scaleItemOverrideDetailsDto.facilityGroupDescription = refObject.description;
        scaleItemOverrideDetailsDto.overrideDescriptionLine1 = this.overrideScaleDescription.get("ovrDesc1").value;
        scaleItemOverrideDetailsDto.overrideDescriptionLine2 = this.overrideScaleDescription.get("ovrDesc2").value;
        
        
        return scaleItemOverrideDetailsDto;
    }


    public onSave(): void {

        
            let scaleItemOverrideDetailsDto = this.getScaleItemOverrideDetailsDto();
            scaleItemOverrideDetailsDto.rowId = this.data.scaleItemOverrideDetailsRow.rowId;
            if (!this.checkDuplicateOverrideScaleDescription(scaleItemOverrideDetailsDto)) {
                this.data.scaleItemOverrideDetailsRow = scaleItemOverrideDetailsDto;
                this.dialogRef.close(scaleItemOverrideDetailsDto);
            } else {
                let data = { description: "Override Scale Descriptin already exists", options: ["Ok"] }
                let dialogRef = this.dialog.open(DialogContentComponent, {
                    disableClose: true,
                    width: '800px',
                    data: data
                });
                console.log("Override Scale Descriptin already exists");
            }
        
    }

    public checkDuplicateOverrideScaleDescription(scaleItemOverrideDetailsDto: ScaleItemOverrideDetailsDto): boolean {
        if (this.parentScaleItemOverrideDetails.find(x => x.facilityGroupCode == scaleItemOverrideDetailsDto.facilityGroupCode && x.overrideDescriptionLine1 == scaleItemOverrideDetailsDto.overrideDescriptionLine1 && x.overrideDescriptionLine2 == scaleItemOverrideDetailsDto.overrideDescriptionLine2) != undefined) {
            return true;
        }
        return false;
    }

   

}


