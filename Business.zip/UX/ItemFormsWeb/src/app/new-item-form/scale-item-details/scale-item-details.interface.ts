﻿import { IScaleItemOverrideDetailsDto, ScaleItemOverrideDetailsDto } from './dialog-override-scale-description/scale-item-details.interface';
import { IScaleGradeDto, ScaleGradeDto } from './dialog-scale-grade/dialog-scale-grade.interface';
import { IScaleItemLocationDetailsDto, ScaleItemLocatinDetailsDto } from './dialog-scale-location/scale-item-location-details.interface';
import { IScaleShelfLifeDto, ScaleShelfLifeDto } from './dialog-scale-shelf-life/scale-shelf-life.interface';

export class IScaleInfoDto{
    itemFormID: number;
    backroomScaleIndicator: string;
    scaleDescription1: string;
    scaleDescription2: string;
    calorieInformation: number;
    tare: number;
    scaleExtraTextRequired: string;
    priceModifier: string;
    nutritionCodeRequired: string;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
    isDirty: boolean;
    isDirtyItemOverride: boolean;
    isDirtyScaleLocation: boolean;
    isDirtyScaleGrade: boolean;
    isDirtyScaleShelfLife: boolean;
    scaleOverrideDescriptionList: IScaleItemOverrideDetailsDto[];
    scaleShelfLifeList: IScaleShelfLifeDto[];
    scaleLocationList: IScaleItemLocationDetailsDto[];
    scaleGradeList: IScaleGradeDto[]
}


export class ScaleInfoDto implements IScaleInfoDto {
    itemFormID: number;
    backroomScaleIndicator: string;
    scaleDescription1: string;
    scaleDescription2: string;
    calorieInformation: number;
    tare: number;
    scaleExtraTextRequired: string;
    priceModifier: string;
    nutritionCodeRequired: string;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
    isDirty: boolean;
    isDirtyItemOverride: boolean;
    isDirtyScaleLocation: boolean;
    isDirtyScaleGrade: boolean;
    isDirtyScaleShelfLife: boolean;
    scaleOverrideDescriptionList: IScaleItemOverrideDetailsDto[];
    scaleShelfLifeList: IScaleShelfLifeDto[];
    scaleLocationList: IScaleItemLocationDetailsDto[];
    scaleGradeList: IScaleGradeDto[]
}