import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormArray, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { IScaleItemOverrideDetailsDto, ScaleItemOverrideDetailsDto } from './dialog-override-scale-description/scale-item-details.interface';
import { IScaleItemLocationDetailsDto, ScaleItemLocatinDetailsDto } from './dialog-scale-location/scale-item-location-details.interface'
import { IScaleShelfLifeDto, ScaleShelfLifeDto } from './dialog-scale-shelf-life/scale-shelf-life.interface';
import { IScaleGradeDto, ScaleGradeDto } from './dialog-scale-grade/dialog-scale-grade.interface';
import { GridEvent } from '../../shared/grid/grid-event';
import { NewItemFormService } from '../new-item-form.service';
import { DialogOverrideScaleDescriptionComponent } from './dialog-override-scale-description/dialog-override-scale-description.component';
import { DialogScaleLocationComponent } from './dialog-scale-location/dialog-scale-location.component';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { DialogScaleShelfLifeComponent } from './dialog-scale-shelf-life/dialog-scale-shelf-life.component';
import { DialogScaleGradeComponent } from './dialog-scale-grade/dialog-scale-grade.component';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { IScaleInfoDto, ScaleInfoDto } from './scale-item-details.interface';
import { ScaleItemDetailsBuyerService } from './scale-item-details-buyer.service';
import { catchError, tap, map } from 'rxjs/operators';
import { ILookupIntFlagDto, LookupIntFlagDto } from '../../shared/common.interface';
import { DialogContentComponent } from '../basic-item-definition/dialog-content.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'ifw-scale-item-details-buyer',
  templateUrl: './scale-item-details-buyer.component.html',
  styleUrls: ['./scale-item-details-buyer.component.scss']
})
export class ScaleItemDetailsBuyerComponent implements OnInit {

    public gridData: any[] = [];
    public gridScaleLocationData: any[] = [];
    public gridScaleShelfLife: any[] = [];
    public gridScaleGrade: any[] = [];
    public scaleDescription1Length: number;
    public scaleDescription2Length: number;
    public tbscaleDescription2Length: boolean;

    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 5;
    public filterable: boolean = true;
    public filterBy: string = "";
    public filterValue: string = "";
    public sortable: boolean = true;
    public active: string = "";
    public direction: string = "";
    public ShowReuseItemCodeGrid = true;
    public isType2Gtin = false;
    userId: any; 

    errors: string[];
    OverrideScaleDescErrors: string[];
    ScaleLocationErrors: string[];
    ScaleGradeErrors: string[];
    OverrideScaleDescWarnings: string[];
    ScaleLocationWarnings: string[];
    ScaleGradeWarnings: string[];
    formErrors: any;
    //popUpMessages: IErrorDTO[];
    //formErrors: any;
    showSpinner: boolean = false;
    skipSaveTab: boolean = false;
    createdByUserTypeID: number;
    public itemFormDisplayID: number;
    public itemFormID: number;
    public count: number = 0;
    ScaleItemDetailsFormGroup: FormGroup;

    scaleItemOverrideDetailList: IScaleItemOverrideDetailsDto[];
    scaleItemOverrideDetail: IScaleItemOverrideDetailsDto;

    scaleItemLocationDetailsList: IScaleItemLocationDetailsDto[];
    scaleItemLocationDetailsDto: IScaleItemLocationDetailsDto;

    scaleShelfLifeItemList: IScaleShelfLifeDto[];
    scaleShelfLifeItem: IScaleShelfLifeDto;

    scaleGradeItemsList: IScaleGradeDto[];
    scaleGradeItem: IScaleGradeDto;

    scaleLocationLookup: ILookupIntFlagDto[];

    public scaleItemOverrideDetailsForm: FormArray;
    public isReadOnly: boolean = false; 
    constructor(private fb: FormBuilder,
        private newItemFormService: NewItemFormService,
        private scaleItemDetailsBuyerService: ScaleItemDetailsBuyerService,
        public snackBar: MatSnackBar,
        private router: Router,
        public dialog: MatDialog ) { }

    ngOnInit() {
        this.scaleDescription1Length = 32;
        this.scaleDescription2Length = 32;
        this.formErrors = {};
        this.tbscaleDescription2Length = false;
        this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        this.itemFormID = this.newItemFormService.itemFormID;
        this.isReadOnly = this.newItemFormService.isReadOnly;
        this.newItemFormService.getItemFormData(this.itemFormDisplayID).subscribe(res => { this.createdByUserTypeID = res.createdByUserTypeID });
        this.isType2Gtin = this.newItemFormService.isType2Gtin();
        this.createForm();
        this.scaleItemOverrideDetailList = [];
        this.scaleItemLocationDetailsList = [];
        this.scaleShelfLifeItemList = [];
        this.scaleGradeItemsList = [];
        this.errors = [];
        this.OverrideScaleDescErrors = [];
        this.ScaleLocationErrors = [];
        this.ScaleGradeErrors = [];
        this.OverrideScaleDescWarnings= [];
        this.ScaleLocationWarnings= [];
        this.ScaleGradeWarnings= [];
        this.scaleLocationLookup = [];
        
        this.GetScaleItemDetails(this.itemFormID, false);
        
        
        
    }


    createForm() {
        this.ScaleItemDetailsFormGroup = this.fb.group({
            itemFormID: this.itemFormID,
            backroomScaleIndicator: '',
            tare: '',
            scaleExtraTextRequired: '',
            scaleDescription1: [],
            scaleDescription2:'',
            priceModifier: '',
            calorieInformation: '',
            nutritionCodeRequired: '',
            scaleItemOverrideList: this.fb.array([]),
            isDirty: false,
            isDirtyItemOverride: false,
            isDirtyScaleLocation: false,
            isDirtyScaleGrade: false,
            isDirtyScaleShelfLife: false            
        });

       

    }

    reset() {
        this.scaleDescription1Length = 32;
        this.scaleDescription2Length = 32;
        this.tbscaleDescription2Length = false;
        this.ScaleItemDetailsFormGroup.controls.scaleDescription2.enable();
        this.createForm();
        this.GetScaleItemDetails(this.itemFormID, false);
        this.scaleItemOverrideDetailList = [];
        this.scaleItemLocationDetailsList = [];
        this.scaleShelfLifeItemList = [];
        this.scaleGradeItemsList = [];
        this.errors = [];
        this.scaleLocationLookup = [];
        this.OverrideScaleDescErrors = [];
        this.ScaleLocationErrors = [];
        this.ScaleGradeErrors = [];
        this.OverrideScaleDescWarnings = [];
        this.ScaleLocationWarnings = [];
        this.ScaleGradeWarnings = [];
    }


    private GetScaleItemDetails(itemFormId: number, afterSave: boolean) {
        this.scaleItemDetailsBuyerService.getScaleInfo(this.itemFormID).subscribe(res => {
            if (res != undefined) {
                // this.ScaleItemDetailsFormGroup = this.fb.group({
                //     itemFormID: this.itemFormID,
                //     backRoomScaleIndicator: (this.isType2Gtin && res.backroomScaleIndicator == undefined) ? 'Y': res.backroomScaleIndicator,
                //     tare: res.tare,
                //     scaleExtraTextRequired: (res.scaleExtraTextRequired == undefined) ? 'N' : res.scaleExtraTextRequired,
                //     scaleDescription1: res.scaleDescription1,
                //     scaleDescription2: res.scaleDescription2,
                //     priceModifier: (res.priceModifier == undefined) ? 'Y' : res.priceModifier,
                //     calorieInformation: res.calorieInformation,
                //     nutritionCodeRequired: (res.nutritionCodeRequired == undefined) ? 'Y' : res.nutritionCodeRequired,
                //     isDirty: false,
                //     isDirtyItemOverride: false,
                //     isDirtyScaleLocation: false,
                //     isDirtyScaleGrade: false,
                //     isDirtyScaleShelfLife: false,
                      
                // });
                this.ScaleItemDetailsFormGroup.patchValue(res);
                this.scaleItemOverrideDetailList = (res.scaleOverrideDescriptionList != undefined) ? res.scaleOverrideDescriptionList : [];
                this.scaleItemLocationDetailsList = (res.scaleLocationList != undefined) ? res.scaleLocationList : [];
                this.scaleShelfLifeItemList = (res.scaleShelfLifeList != undefined) ? res.scaleShelfLifeList : [];
                this.scaleGradeItemsList = (res.scaleGradeList != undefined) ? res.scaleGradeList : [];

                this.getScaleLocationLookupList();
                              

                if (this.scaleItemOverrideDetailList.length > 0) {
                    this.updateScaleItemOverrideRowId();
                    this.getInitialScaleItemOverrideDetails();
                }
                if (this.scaleItemLocationDetailsList.length > 0) {
                    this.updateScaleItemLocationRowId();
                    this.getInitialScaleItemLocationDetails();
                }
                if (this.scaleShelfLifeItemList.length > 0) {
                    this.updateScaleShelfLifeRowId();
                    this.getInitialScaleScaleShelfLifeItems();
                }
                if (this.scaleGradeItemsList.length > 0) {
                    this.updateScaleGradeRowId();
                    this.getInitialScaleGradeItems();
                }
            }

            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
                const validations: any = this.newItemFormService.getItemValidation("Scale Item Details");
                if (validations) 
                    this.handleItemSidValidation(validations);
            });

            //if (afterSave) {
            //    this.showSpinner = false;
            //    const validations: any = this.newItemFormService.getItemValidation("Scale Item Details");
            //    if (validations) {
            //        this.handleItemSidValidation(validations);
            //    }
            //} else {
            //    setTimeout(() => {
            //        const validations: any = this.newItemFormService.getItemValidation("Scale Item Details");
            //        if (validations) {
            //            console.log("validations running.")
            //            this.handleItemSidValidation(validations);
            //        }
            //    }, 0);
            //}
           
           
        },
            (err) => {
                this.showSpinner = false;
            });

        

        
    }


    public AddOverrideScaleDescriptionDialog(): void{
        
        let dialogOverrideDesc = this.dialog.open(DialogOverrideScaleDescriptionComponent, {
            width: '800px',
            data: { createdByUserTypeID: this.createdByUserTypeID, parentScaleItemOverrideDetails: this.scaleItemOverrideDetailList }
        });

        const sub = dialogOverrideDesc.componentInstance.onAddEvent.subscribe((result) => {
            
            this.scaleItemOverrideDetailList.push(result);
            this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyItemOverride': true });
            this.updateScaleItemOverrideRowId();
            this.getInitialScaleItemOverrideDetails();
        });

        dialogOverrideDesc.afterClosed().subscribe((result) => {
            sub.unsubscribe();
            if (result) {
                this.scaleItemOverrideDetailList.push(result);
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyItemOverride': true });
                this.updateScaleItemOverrideRowId();
            }
            this.getInitialScaleItemOverrideDetails();
        });

        dialogOverrideDesc.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
        });
    }


    public EditOverrideScaleDescriptionDialog(rowId: number): void {

        let scaleItemOverrideDetailsRow: IScaleItemOverrideDetailsDto = this.scaleItemOverrideDetailList.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogOverrideScaleDescriptionComponent, {
            width: '800px',
            data: { scaleItemOverrideDetailList: this.scaleItemOverrideDetailList, scaleItemOverrideDetailsRow: scaleItemOverrideDetailsRow, parentScaleItemOverrideDetails: this.scaleItemOverrideDetailList }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result && result.rowId) {
                this.scaleItemOverrideDetailList.splice(result.rowId - 1, 1, result)
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyItemOverride': true });
                this.getInitialScaleItemOverrideDetails();
            }
            console.log('The dialog was closed');
            console.log(result);
            
        });
    }

    public deleteOverrideScaleDescriptionDialog(rowId: number): void {


        let data = { description: "Are you sure you want to delete override scale descriptin ?", actions: ["No", "Yes"] }
        let dialogRef = this.dialog.open(ConfirmDialogComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                var index = this.scaleItemOverrideDetailList.findIndex(x => x.rowId == rowId);
                if (index > -1) {
                    this.scaleItemOverrideDetailList.splice(index, 1);
                }
                this.getInitialScaleItemOverrideDetails();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyItemOverride': true });
            }

        });


    }


    private updateScaleItemOverrideRowId() {
        let count: number = 1;
        if (this.scaleItemOverrideDetailList != undefined) {
            for (let scaleItemOverrideDetail of this.scaleItemOverrideDetailList) {
                scaleItemOverrideDetail.rowId = count++;
            }
        }
    }

    getInitialScaleItemOverrideDetails() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 5,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getScaleItemOverrideDetails(gridEvent);
    }

    getScaleItemOverrideDetails(gridEvent: GridEvent) {
        this.gridData = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }

    /**
  * sort the filtered result based on sort column and order
  */
    sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }
    /**
       * paginate the result set
       */
    pageData(gridEvent: GridEvent) {
        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

    performFilter(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.scaleItemOverrideDetailList.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.scaleItemOverrideDetailList.slice();
        }
        return this.scaleItemOverrideDetailList.slice();
    }


    public AddScaleItemLocationDetailsDialog(): void {
        let dialogScaleItemLocationDetails = this.dialog.open(DialogScaleLocationComponent, {
            width: '800px',
            data: { createdByUserTypeID: this.createdByUserTypeID, parentScaleItemLocatinDetails: this.scaleItemLocationDetailsList }

        });

        const sub = dialogScaleItemLocationDetails.componentInstance.onAddEvent.subscribe((result) => {
            this.scaleItemLocationDetailsList.push(result);
            this.updateScaleItemLocationRowId();
            this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleLocation': true });
            this.getInitialScaleItemLocationDetails();
        });

        dialogScaleItemLocationDetails.afterClosed().subscribe((result) => {
            sub.unsubscribe();
            if (result) {
                this.scaleItemLocationDetailsList.push(result);
                this.updateScaleItemLocationRowId();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleLocation': true });
                this.setScaleDescription1LengthByResult(result);
            }
            this.getInitialScaleItemLocationDetails();
            //this.setScaleDescription1Length();
        });

        dialogScaleItemLocationDetails.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
        });

        
    }


    private updateScaleItemLocationRowId() {
        let count: number = 1;
        if (this.scaleItemLocationDetailsList != undefined) {
            for (let scaleItemLocationDetails of this.scaleItemLocationDetailsList) {
                scaleItemLocationDetails.rowId = count++;
            }
        }
    }

    getInitialScaleItemLocationDetails() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 5,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getScaleItemLocationDetails(gridEvent);
    }

    getScaleItemLocationDetails(gridEvent: GridEvent) {
        this.gridScaleLocationData = this.performFilterScaleLocation(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }

    performFilterScaleLocation(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.scaleItemLocationDetailsList.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.scaleItemLocationDetailsList.slice();
        }
        return this.scaleItemLocationDetailsList.slice();
    }

    public EditScaleLocationComponentDialog(rowId: number): void {

        let scaleItemLocatinDetailsRow: IScaleItemLocationDetailsDto = this.scaleItemLocationDetailsList.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogScaleLocationComponent, {
            width: '800px',
            data: { scaleItemLocatinDetailsList: this.scaleItemLocationDetailsList, scaleItemLocatinDetailsRow: scaleItemLocatinDetailsRow, parentScaleItemLocatinDetails: this.scaleItemLocationDetailsList}
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result && result.rowId) {
                this.scaleItemLocationDetailsList.splice(result.rowId - 1, 1, result)
                this.getInitialScaleItemLocationDetails();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleLocation': true });
                this.setScaleDescription1LengthByResult(result);
                //this.setScaleDescription1Length();
            }
            console.log('The dialog was closed');
            console.log(result);

        });

        
    }

    public deleteScaleLocationComponentDialog(rowId: number): void {


        let data = { description: "Are you sure you want to delete override scale descriptin ?", actions: ["No", "Yes"] }
        let dialogRef = this.dialog.open(ConfirmDialogComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                var index = this.scaleItemLocationDetailsList.findIndex(x => x.rowId == rowId);
                if (index > -1) {
                    this.scaleItemLocationDetailsList.splice(index, 1);
                }
                this.getInitialScaleItemLocationDetails();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleLocation': true });
                this.setScaleDescription1Length();
            }

        });

        

    }


    public AddScaleGradeDialog(): void {

        let dialogScaleGrade = this.dialog.open(DialogScaleGradeComponent, {
            width: '800px',
            data: { createdByUserTypeID: this.createdByUserTypeID, parentscaleGradeItems: this.scaleGradeItemsList }
        });

        const sub = dialogScaleGrade.componentInstance.onAddEvent.subscribe((result) => {
            this.scaleGradeItemsList.push(result);
            this.updateScaleGradeRowId();
            this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleGrade': true });
            this.getInitialScaleGradeItems();
        });

        dialogScaleGrade.afterClosed().subscribe((result) => {
            sub.unsubscribe();
            if (result) {
                this.scaleGradeItemsList.push(result);
                this.updateScaleGradeRowId();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleGrade': true });
            }
            this.getInitialScaleGradeItems();
        });

        dialogScaleGrade.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
        });
    }

    private updateScaleGradeRowId() {
        let count: number = 1;
        if (this.scaleGradeItemsList != undefined) {
            for (let scaleGradeItem of this.scaleGradeItemsList) {
                scaleGradeItem.rowId = count++;
            }
        }
    }

    getInitialScaleGradeItems() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 5,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getScaleGrade(gridEvent);
    }

    getScaleGrade(gridEvent: GridEvent) {
        this.gridScaleGrade = this.performFilterScaleGrade(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }

    performFilterScaleGrade(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.scaleGradeItemsList.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.scaleGradeItemsList.slice();
        }
        return this.scaleGradeItemsList.slice();
    }

    public EditScaleGradeComponentDialog(rowId: number): void {

        let scaleGradeItemRow: IScaleGradeDto = this.scaleGradeItemsList.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogScaleGradeComponent, {
            width: '800px',
            data: { scaleGradeItemsList: this.scaleGradeItemsList, scaleGradeItemRow: scaleGradeItemRow, parentscaleGradeItems: this.scaleGradeItemsList }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result && result.rowId) {
                this.scaleGradeItemsList.splice(result.rowId - 1, 1, result)
                this.getInitialScaleGradeItems();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleGrade': true });
            }
            console.log('The dialog was closed');
            console.log(result);

        });
    }

    public deleteScaleGradeComponentDialog(rowId: number): void {


        let data = { description: "Are you sure you want to delete override scale descriptin ?", actions: ["No", "Yes"] }
        let dialogRef = this.dialog.open(ConfirmDialogComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                var index = this.scaleGradeItemsList.findIndex(x => x.rowId == rowId);
                if (index > -1) {
                    this.scaleGradeItemsList.splice(index, 1);
                }
                this.getInitialScaleGradeItems();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleGrade': true });
            }

        });


    }





    public AddScaleShelfLifeDialog(): void {

        let dialogScaleShelfLife = this.dialog.open(DialogScaleShelfLifeComponent, {
            width: '800px',
            data: { createdByUserTypeID: this.createdByUserTypeID, parentscaleShelfLifeItems: this.scaleShelfLifeItemList }
        });

        const sub = dialogScaleShelfLife.componentInstance.onAddEvent.subscribe((result) => {
            this.scaleShelfLifeItemList.push(result);
            this.updateScaleShelfLifeRowId();
            this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleShelfLife': true });
            this.getInitialScaleScaleShelfLifeItems();
        });

        dialogScaleShelfLife.afterClosed().subscribe((result) => {
            sub.unsubscribe();
            if (result) {
                this.scaleShelfLifeItemList.push(result);
                this.updateScaleShelfLifeRowId();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleShelfLife': true });
            }
            this.getInitialScaleScaleShelfLifeItems();
        });

        dialogScaleShelfLife.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
        });
    }

    private updateScaleShelfLifeRowId() {
        let count: number = 1;
        if (this.scaleShelfLifeItemList != undefined) {
            for (let scaleShelfLifeItem of this.scaleShelfLifeItemList) {
                scaleShelfLifeItem.rowId = count++;
            }
        }
    }

    getInitialScaleScaleShelfLifeItems() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 5,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getScaleShelfLife(gridEvent);
    }

    getScaleShelfLife(gridEvent: GridEvent) {
        this.gridScaleShelfLife = this.performFilterScaleShelfLife(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }

    performFilterScaleShelfLife(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.scaleShelfLifeItemList.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.scaleShelfLifeItemList.slice();
        }
        return this.scaleShelfLifeItemList.slice();
    }

    public EditScaleShelfLifeComponentDialog(rowId: number): void {

        let scaleShelfLifeDetailsRow: IScaleShelfLifeDto = this.scaleShelfLifeItemList.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogScaleShelfLifeComponent, {
            width: '800px',
            data: { scaleShelfLifeItemList: this.scaleShelfLifeItemList, scaleShelfLifeItemRow: scaleShelfLifeDetailsRow, parentscaleShelfLifeItems: this.scaleShelfLifeItemList }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result && result.rowId) {
                this.scaleShelfLifeItemList.splice(result.rowId - 1, 1, result)
                this.getInitialScaleScaleShelfLifeItems();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleShelfLife': true });
            }
            console.log('The dialog was closed');
            console.log(result);

        });
    }

    public deleteScaleShelfLifeComponentDialog(rowId: number): void {
        let data = { description: "Are you sure you want to delete override scale descriptin ?", actions: ["No", "Yes"] }
        let dialogRef = this.dialog.open(ConfirmDialogComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                var index = this.scaleShelfLifeItemList.findIndex(x => x.rowId == rowId);
                if (index > -1) {
                    this.scaleShelfLifeItemList.splice(index, 1);
                }
                this.getInitialScaleScaleShelfLifeItems();
                this.ScaleItemDetailsFormGroup.patchValue({ 'isDirtyScaleShelfLife': true });
            }

        });
    }


    performAction(action: any) {
        switch (action.actionName) {
            case "Save":
                this.scaleItems(action.createdFormStatusID, action.actionID);
                break;
            case "Delete":
                this.deleteItemForm();
                break;
            case "Submit":
                this.scaleItems(action.createdFormStatusID, action.actionID);
                break;
        }
    }

    public submitScaleItems(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
                //this.GetScaleItemDetails(this.itemFormID, true);
            });
            if (res) {
                this.snackBar.open("Submitted successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
            else {
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
        });
    }

    public scaleItems(createdFormStatusID: number, actionID: number): void {
        
            this.saveTabObservable (createdFormStatusID, actionID).subscribe(res => {
                if (res) {

                    this.snackBar.open("Saved successfully.", null, {
                        duration: 500,
                        horizontalPosition: this.horizontalPosition,
                        verticalPosition: 'bottom',
                    });

                    this.GetScaleItemDetails(this.itemFormID, true);
                }
            });
        
    }


    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    saveTabObservable (createdFormStatusID: number, actionID: number): Observable<boolean> {

           if (this.skipSaveTab || this.isReadOnly) return of(true);

            this.checkIfDirty();
            this.errors = [];
            this.OverrideScaleDescErrors = [];
            this.ScaleLocationErrors = [];
            this.ScaleGradeErrors = [];
            this.OverrideScaleDescWarnings= [];
            this.ScaleLocationWarnings= [];
            this.ScaleGradeWarnings= [];
            console.log('Save Submitted!');
            const scaleInfoDto: IScaleInfoDto = (<any>Object).assign({}, this.ScaleItemDetailsFormGroup.value);
            if (scaleInfoDto.tare == undefined || String(scaleInfoDto.tare) == "") {
                scaleInfoDto.tare = 99.99;
            }
            scaleInfoDto.scaleOverrideDescriptionList = this.scaleItemOverrideDetailList;
            scaleInfoDto.scaleLocationList = this.scaleItemLocationDetailsList;
            scaleInfoDto.scaleGradeList = this.scaleGradeItemsList;
            scaleInfoDto.scaleShelfLifeList = this.scaleShelfLifeItemList;

            createdFormStatusID = createdFormStatusID == undefined ? this.newItemFormService.formCurrentStatusID : createdFormStatusID;


            this.showSpinner = true;

            return this.scaleItemDetailsBuyerService.saveScaleInfo(scaleInfoDto).pipe(
                map(res => {

                    if(res.validation)
                    this.newItemFormService.addItemValidation(res.validation);

                    if(res.status)
                    this.newItemFormService.formCurrentStatusID = createdFormStatusID;
                     //console.log("saved successfully.");
                    this.showSpinner = false;
                    //this.GetScaleItemDetails(this.itemFormID, true);
                    return res.status;
                }), catchError((err) => {
                    this.showSpinner = false;
                    if (err.status === 400) {
                        this.newItemFormService.addItemValidation(err.error);
                        //this.handleItemGpaValidation(err.error);
                    }
                    else {
                        this.errors.push("Unhandled expection occured.");
                    }
                    console.log("saved error. " + err.status);
                    window.scrollTo(0, 150);
                    this.snackBar.open("Please correct the errors.", null, {
                        duration: 3000,
                        horizontalPosition: this.horizontalPosition,
                        verticalPosition: this.verticalPosition,
                    });
                    return of(false);
                })
            );
        

    }

    checkIfDirty() {

        this.ScaleItemDetailsFormGroup.patchValue({ 'isDirty': this.ScaleItemDetailsFormGroup.dirty });
        
    }



    public deleteItemForm(): void {
        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.showSpinner = true;
                this.newItemFormService.deleteItemForm().subscribe(res => {
                    this.showSpinner = false;
                    if (res != undefined) {
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: 'merge' });
                },
                    (err) => {
                        this.showSpinner = false;
                    })
            }
        });
    }

    public getScaleLocationLookupList(): void {

        this.scaleItemDetailsBuyerService.getScaleLocation().subscribe(res => {
            this.scaleLocationLookup = res.map(sl => ({
                code: Number(sl.code),
                description: sl.description,
                receiptDescFlag: sl.receiptDescFlag

            }));

            for (let scaleLocation of this.scaleItemLocationDetailsList) {
                if (this.scaleLocationLookup.find(x => x.code == scaleLocation.scaleLocation && x.receiptDescFlag == 'Y')) {
                    this.ScaleItemDetailsFormGroup.controls.scaleDescription2.setValue('');
                    this.scaleDescription1Length = 18;
                    this.scaleDescription2Length = 0;
                    this.tbscaleDescription2Length = true;
                    this.ScaleItemDetailsFormGroup.controls.scaleDescription2.disable();

                    
                    return;
                }
            }
        });


        this.scaleDescription1Length = this.setScaleDescription1Length() ? 18 : 32;

    }

    public setScaleDescription1Length(): void {

        for (let scaleLocation of this.scaleItemLocationDetailsList) {
            if (this.scaleLocationLookup.find(x => x.code == scaleLocation.scaleLocation && x.receiptDescFlag == 'Y')) {
                this.ScaleItemDetailsFormGroup.controls.scaleDescription2.setValue('');
                this.scaleDescription1Length = 18;
                this.scaleDescription2Length = 0;
                this.tbscaleDescription2Length = true;    
                this.ScaleItemDetailsFormGroup.controls.scaleDescription2.disable();

                return;
            }
        }
        this.scaleDescription1Length = 32;
        this.scaleDescription2Length = 32;
        this.tbscaleDescription2Length = false;
        this.ScaleItemDetailsFormGroup.controls.scaleDescription2.enable();
    }

    public setScaleDescription1LengthByResult(scaleLocation: IScaleItemLocationDetailsDto): void {

        
            if (this.scaleLocationLookup.find(x => x.code == scaleLocation.scaleLocation && x.receiptDescFlag == 'Y')) {
                this.ScaleItemDetailsFormGroup.controls.scaleDescription2.setValue('');
                
                this.scaleDescription2Length = 0;
                this.tbscaleDescription2Length = true;
                this.ScaleItemDetailsFormGroup.controls.scaleDescription2.disable();
                if (this.scaleDescription1Length == 32) {
                    this.scaleDescription1Length = 18;
                    this.ScaleItemDetailsFormGroup.controls.scaleDescription1.setValue('');
                }

                let data = { description: "Add of Scale Location requires Scale Description Line 1 length changed to 18 characters", options: ["Ok"] }
                let dialogRef = this.dialog.open(DialogContentComponent, {
                    disableClose: true,
                    width: '800px',
                    data: data
                });

                return;
            }
       
        this.scaleDescription1Length = 32;
        this.scaleDescription2Length = 32;
        this.tbscaleDescription2Length = false;
        this.ScaleItemDetailsFormGroup.controls.scaleDescription2.enable();
    }

    handleItemSidValidation(itemValidation) {
        let sidErrors = itemValidation.errors;
        let sidWarnings = itemValidation.warnings;
        this.handleSidValidationErrors(sidErrors);
        this.handleSidValidationWarnings(sidWarnings);
        let validationPanelErrors = itemValidation.subTabValidations;
        this.handleValidationErrors(validationPanelErrors);
        
    }

    handleValidationErrors(sidErrors: any[]) {

        for (var key in sidErrors) {
            let errorObj = sidErrors[key];
            //for (var errorObj of gpaErrors) {
            
            for (var error of errorObj.errors) {
                

                let fieldName = error.controlName;
                if (fieldName == "OverrideScaleDescErrors") {
                    this.OverrideScaleDescErrors.push(error.errorDescription)

                }
                if (fieldName == "ScaleLocationErrors") {
                    this.ScaleLocationErrors.push(error.errorDescription)

                }
                if (fieldName == "ScaleGradeErrors") {
                    this.ScaleGradeErrors.push(error.errorDescription)

                }
            }

            for (var error of errorObj.warnings) {

               
                let fieldName = error.controlName;
                if (fieldName == "OverrideScaleDescErrors") {
                    this.OverrideScaleDescWarnings.push(error.errorDescription)

                }
                if (fieldName == "ScaleLocationErrors") {
                    this.ScaleLocationWarnings.push(error.errorDescription)

                }
                if (fieldName == "ScaleGradeErrors") {
                    this.ScaleGradeWarnings.push(error.errorDescription)

                }
            }
        }
        
    }


    handleSidValidationErrors(sidErrors: any[]) {

        for (var key in sidErrors) {
            let errorObj = sidErrors[key];
            //for (var errorObj of gpaErrors) {
            let fieldName = errorObj.controlName;
            if (fieldName) {
                if (this.ScaleItemDetailsFormGroup.controls[fieldName]) {

                    this.ScaleItemDetailsFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.ScaleItemDetailsFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;

                }
            }
        }
    }
    handleSidValidationWarnings(sidErrors: any[]) {

        for (var key in sidErrors) {
            let errorObj = sidErrors[key];
            //for (var errorObj of gpaErrors) {
            let fieldName = errorObj.controlName;
            if (fieldName) {
                if (this.ScaleItemDetailsFormGroup.controls[fieldName]) {
                    this.ScaleItemDetailsFormGroup.controls[fieldName].setErrors({ warning: true });
                    this.ScaleItemDetailsFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = errorObj.errorDescription;

                }
            }
        }
    }
    getErrorMessage(control: FormControl, name: string) {
        for (let propertyName in control.errors) {
            if ((propertyName == "invalid" || propertyName == "warning") && this.formErrors[name]) {
                return this.formErrors[name];
            }
        }
        return null;
    }

}
