import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { IScaleGradeDto, ScaleGradeDto } from './dialog-scale-grade.interface';
import { ILookupIntDto, LookupIntDto, IScaleItemFacilityLookupDto, ScaleItemFacilityLookupDto } from '../../../shared/common.interface';
import { ScaleItemDetailsBuyerService } from '../scale-item-details-buyer.service';
import { DialogContentComponent } from '../../basic-item-definition/dialog-content.component';

@Component({
    selector: 'ifw-dialog-scale-grade',
    templateUrl: './dialog-scale-grade.component.html',
    styleUrls: ['./dialog-scale-grade.component.scss']
})
export class DialogScaleGradeComponent implements OnInit {


    onAddEvent = new EventEmitter<IScaleGradeDto>();
    public isEdit: boolean = false;
    scaleGradeForm: FormGroup;
    public scaleGradeItem: IScaleGradeDto;
    public scaleGradeItemsList: IScaleGradeDto[];
    public parentscaleGradeItems: IScaleGradeDto[];
    public facilityScaleGradeList: IScaleItemFacilityLookupDto[];
    public gradeList: ILookupIntDto[];

    public facilityGroupType: string;
    public facilityGroupTypeDescription: string;

    constructor(public dialogRef: MatDialogRef<DialogScaleGradeComponent>,
        private formBuilder: FormBuilder,
        private scaleItemDetailsBuyerService: ScaleItemDetailsBuyerService,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) { }


    ngOnInit() {
        this.parentscaleGradeItems = this.data.parentscaleGradeItems;
        this.scaleItemDetailsBuyerService.getFacilityGroupByTypeScaleGrade().subscribe(res => {
            this.facilityScaleGradeList = res.map(fgd => ({
                code: Number(fgd.code),
                description: fgd.description,
                facilityGroup: fgd.facilityGroup,
                facilityGroupDescription: fgd.facilityGroupDescription,
                facilityCodeDescription: fgd.facilityCodeDescription
            }));
            if (res != undefined) {
                this.facilityGroupType = res[0].facilityGroup;
                this.facilityGroupTypeDescription = res[0].facilityGroupDescription;
            }
        });

        if (this.data.scaleGradeItemRow != undefined) {
            this.scaleGradeForm = this.formBuilder.group({
                rowId: this.data.scaleGradeItemRow.rowId,
                facilityGroupSG: this.data.scaleGradeItemRow.facilityGroupCode,
                grade: this.data.scaleGradeItemRow.grade
            });

            this.isEdit = true;
            this.scaleGradeItemsList = this.data.scaleGradeItemsList;
        }
        else {
            this.scaleGradeForm = this.formBuilder.group({
                rowId: '',
                facilityGroupSG: '',
                grade: ''
            });

            this.scaleGradeItemsList = [];
        }

        this.scaleItemDetailsBuyerService.getScaleGrade().subscribe(res => {
            this.gradeList = res.map(gl => ({
                code: Number(gl.code),
                description: gl.description
            }));
        });

    }


    public onCancel(): void {
        this.dialogRef.close();
    }

    public onAdd(): void {

        let scaleGradeDto = this.getScaleGradeDto();
        scaleGradeDto.rowId = this.scaleGradeItemsList.length + 1;
        if (!this.checkDuplicateOverrideScaleDescription(scaleGradeDto)) {
            this.scaleGradeItemsList.push(scaleGradeDto);
            this.data.scaleGradeItemsList = this.scaleGradeItemsList;
            this.dialogRef.close(scaleGradeDto);
        } else {
            let data = { description: "Scale Grade already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Grade already exists");
        }


    }
    public onAddContinue(): void {

        let scaleGradeDto = this.getScaleGradeDto();
        scaleGradeDto.rowId = this.scaleGradeItemsList.length + 1;

        if (!this.checkDuplicateOverrideScaleDescription(scaleGradeDto)) {
            this.scaleGradeItemsList.push(scaleGradeDto);
            this.data.scaleGradeItemsList = this.scaleGradeItemsList;

            this.scaleGradeForm.reset();
            this.onAddEvent.emit(scaleGradeDto);
            this.scaleGradeForm.reset();
        } else {
            let data = { description: "Scale Grade already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Grade already exists");
        }


    }

    public getScaleGradeDto(): ScaleGradeDto {
        let scaleGradeDto = new ScaleGradeDto();

        let refCode = this.scaleGradeForm.get("facilityGroupSG").value;
        var refObject = this.facilityScaleGradeList.find(x => x.code == refCode);
        scaleGradeDto.facilityGroupType = refObject.facilityGroup;
        scaleGradeDto.facilityGroupTypeDescription = refObject.facilityGroupDescription;
        scaleGradeDto.facilityGroupCode = refObject.code;
        scaleGradeDto.facilityGroupDescription = refObject.description;

        var gradeObj = this.gradeList.find(x => x.code == scaleGradeDto.grade)
        scaleGradeDto.grade = this.scaleGradeForm.get("grade").value;
        if (scaleGradeDto.grade != undefined) {
            scaleGradeDto.gradeDescription = this.gradeList.find(x => x.code == scaleGradeDto.grade).description;
        }


        return scaleGradeDto;
    }

    public onSave(): void {

        let scaleGradeDto = this.getScaleGradeDto();
        scaleGradeDto.rowId = this.data.scaleGradeItemRow.rowId;
        if (!this.checkDuplicateOverrideScaleDescription(scaleGradeDto)) {
            this.data.scaleGradeItemRow = scaleGradeDto;
            this.dialogRef.close(scaleGradeDto);
        }
        else {
            let data = { description: "Scale Grade already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Grade already exists");
        }

    }

    public checkDuplicateOverrideScaleDescription(scaleGradeDto: ScaleGradeDto): boolean {
        if (this.parentscaleGradeItems.find(x => x.facilityGroupCode == scaleGradeDto.facilityGroupCode && x.grade == scaleGradeDto.grade) != undefined) {
            return true;
        }
        return false;
    }


}
