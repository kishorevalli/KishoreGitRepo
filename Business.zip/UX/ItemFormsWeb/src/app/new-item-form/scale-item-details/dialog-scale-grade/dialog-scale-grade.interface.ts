﻿export class IScaleGradeDto {
    rowId: number;
    itemFormID: number;
    facilityGroupType: string;
    facilityGroupTypeDescription: string;
    facilityGroupCode: number;
    facilityGroupDescription: string;
    grade: number;
    gradeDescription: string;
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}
export class ScaleGradeDto implements IScaleGradeDto {
    rowId: number;
    itemFormID: number;
    facilityGroupType: string;
    facilityGroupTypeDescription: string;
    facilityGroupCode: number;
    facilityGroupDescription: string;
    grade: number;
    gradeDescription: string;
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}