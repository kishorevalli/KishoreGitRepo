﻿export class IScaleItemLocationDetailsDto {
    rowId: number;
    itemFormID: number;
    scaleLocation: number;
    scaleLocationDescription: string;
    pluNumber: number;
    action: number;
    actionDescription: string
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}

export class ScaleItemLocatinDetailsDto implements IScaleItemLocationDetailsDto {

    rowId: number;
    itemFormID: number;
    scaleLocation: number;
    scaleLocationDescription: string;
    pluNumber: number;
    action: number;
    actionDescription: string
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;

}