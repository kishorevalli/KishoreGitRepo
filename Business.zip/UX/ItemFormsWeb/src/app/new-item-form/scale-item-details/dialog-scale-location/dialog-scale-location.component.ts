import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { IScaleItemLocationDetailsDto, ScaleItemLocatinDetailsDto } from './scale-item-location-details.interface';
import { ILookupIntDto, LookupIntDto, ILookupIntFlagDto, LookupIntFlagDto } from '../../../shared/common.interface';
import { ScaleItemDetailsBuyerService } from '../scale-item-details-buyer.service';
import { DialogContentComponent } from '../../basic-item-definition/dialog-content.component';

@Component({
    selector: 'ifw-dialog-scale-location',
    templateUrl: './dialog-scale-location.component.html',
    styleUrls: ['./dialog-scale-location.component.scss']
})
export class DialogScaleLocationComponent implements OnInit {

    onAddEvent = new EventEmitter<IScaleItemLocationDetailsDto>();
    public isEdit: boolean = false;
    scaleLocation: FormGroup;
    public scaleItemLocatinDetails: IScaleItemLocationDetailsDto;
    public scaleItemLocatinDetailsList: IScaleItemLocationDetailsDto[];
    public parentScaleItemLocatinDetails: IScaleItemLocationDetailsDto[];
    public scaleLocationList: ILookupIntFlagDto[];
    public actionCodeList: ILookupIntDto[];

    constructor(public dialogRef: MatDialogRef<DialogScaleLocationComponent>,
        private formBuilder: FormBuilder,
        private scaleItemDetailsBuyerService: ScaleItemDetailsBuyerService,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    ngOnInit() {

        this.parentScaleItemLocatinDetails = this.data.parentScaleItemLocatinDetails;
        this.scaleItemDetailsBuyerService.getScaleLocation().subscribe(res => {
            this.scaleLocationList = res.map(sl => ({
                code: Number(sl.code),
                description: sl.description,
                receiptDescFlag: sl.receiptDescFlag

            }));
        });
        this.scaleItemDetailsBuyerService.getScaleActionCodes().subscribe(res => {
            this.actionCodeList = res.map(acl => ({
                code: Number(acl.code),
                description: acl.description
            }));
        });
        if (this.data.scaleItemLocatinDetailsRow != undefined) {
            this.scaleLocation = this.formBuilder.group({
                rowId: this.data.scaleItemLocatinDetailsRow.rowId,
                scaleLocationDescription: this.data.scaleItemLocatinDetailsRow.scaleLocation,
                plu: this.data.scaleItemLocatinDetailsRow.pluNumber,
                actionCode: this.data.scaleItemLocatinDetailsRow.action

            });
            this.scaleItemLocatinDetailsList = this.data.scaleItemLocatinDetailsList;
            this.isEdit = true;
        } else {
            this.scaleLocation = this.formBuilder.group({

                scaleLocationDescription: '',
                plu: '',
                actionCode: ''
            });
            this.scaleItemLocatinDetailsList = [];
        }





    }

    public onCancel(): void {
        this.dialogRef.close();
    }

    public onAdd(): void {

        let scaleItemLocatinDetailsDto = this.getScaleItemLocatinDetailsDto();
        scaleItemLocatinDetailsDto.rowId = this.scaleItemLocatinDetailsList.length + 1;

        if (!this.checkDuplicateScaleLocation(scaleItemLocatinDetailsDto)) {
            this.scaleItemLocatinDetailsList.push(scaleItemLocatinDetailsDto);
            this.data.scaleItemLocatinDetailsList = this.scaleItemLocatinDetailsList;
            this.dialogRef.close(scaleItemLocatinDetailsDto);
        }
        else {
            let data = { description: "Scale Location already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Location already exists");
        }

    }
    public onAddContinue(): void {

        let scaleItemLocatinDetailsDto = this.getScaleItemLocatinDetailsDto();
        scaleItemLocatinDetailsDto.rowId = this.scaleItemLocatinDetailsList.length + 1;

        if (!this.checkDuplicateScaleLocation(scaleItemLocatinDetailsDto)) {
            this.scaleItemLocatinDetailsList.push(scaleItemLocatinDetailsDto);
            this.data.scaleItemLocatinDetailsList = this.scaleItemLocatinDetailsList;

            this.scaleLocation.reset();
            this.onAddEvent.emit(scaleItemLocatinDetailsDto);
            this.scaleLocation.reset();
        }
        else {
            let data = { description: "Scale Location already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Location already exists");
        }


    }

    public getScaleItemLocatinDetailsDto(): ScaleItemLocatinDetailsDto {
        let scaleItemLocatinDetailsDto = new ScaleItemLocatinDetailsDto();

        scaleItemLocatinDetailsDto.scaleLocation = this.scaleLocation.get("scaleLocationDescription").value;
        scaleItemLocatinDetailsDto.scaleLocationDescription = this.scaleLocationList.find(x => x.code == this.scaleLocation.get("scaleLocationDescription").value).description;
        scaleItemLocatinDetailsDto.action = this.scaleLocation.get("actionCode").value;
        if (scaleItemLocatinDetailsDto.action) {
            scaleItemLocatinDetailsDto.actionDescription = this.actionCodeList.find(x => x.code == scaleItemLocatinDetailsDto.action).description;
        }
        scaleItemLocatinDetailsDto.pluNumber = this.scaleLocation.get("plu").value;

        return scaleItemLocatinDetailsDto;
    }

    public onSave(): void {

        let scaleItemLocatinDetailsDto = this.getScaleItemLocatinDetailsDto();
        scaleItemLocatinDetailsDto.rowId = this.data.scaleItemLocatinDetailsRow.rowId;
        if (!this.checkDuplicateScaleLocation(scaleItemLocatinDetailsDto)) {
            this.data.scaleItemLocatinDetailsRow = scaleItemLocatinDetailsDto;
            this.dialogRef.close(scaleItemLocatinDetailsDto);
        } else {
            let data = { description: "Scale Location already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Location already exists");
        }


    }

    public checkDuplicateScaleLocation(scaleItemLocatinDetailsDto: ScaleItemLocatinDetailsDto): boolean {
        if (this.parentScaleItemLocatinDetails.find(x => x.scaleLocation == scaleItemLocatinDetailsDto.scaleLocation && x.action == scaleItemLocatinDetailsDto.action && x.pluNumber == scaleItemLocatinDetailsDto.pluNumber) != undefined) {
            return true;
        }
        return false;
    }
}
