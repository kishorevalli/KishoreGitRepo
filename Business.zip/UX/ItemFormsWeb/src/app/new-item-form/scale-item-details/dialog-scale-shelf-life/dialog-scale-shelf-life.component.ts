import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { IScaleShelfLifeDto, ScaleShelfLifeDto } from './scale-shelf-life.interface';
import { IScaleItemFacilityLookupDto, ScaleItemFacilityLookupDto } from '../../../shared/common.interface';
import { ScaleItemDetailsBuyerService } from '../scale-item-details-buyer.service';
import { DialogContentComponent } from '../../basic-item-definition/dialog-content.component';


@Component({
    selector: 'ifw-dialog-scale-shelf-life',
    templateUrl: './dialog-scale-shelf-life.component.html',
    styleUrls: ['./dialog-scale-shelf-life.component.scss']
})
export class DialogScaleShelfLifeComponent implements OnInit {


    onAddEvent = new EventEmitter<IScaleShelfLifeDto>();
    public isEdit: boolean = false;
    scaleShelfLife: FormGroup;
    public scaleShelfLifeItem: IScaleShelfLifeDto;
    public scaleShelfLifeItemList: IScaleShelfLifeDto[];
    public parentscaleShelfLifeItems: IScaleShelfLifeDto[];
    public facilityGroupShelfLifeList: IScaleItemFacilityLookupDto[];
    public facilityGroupType: string;
    public facilityGroupTypeDescription: string;


    constructor(public dialogRef: MatDialogRef<DialogScaleShelfLifeComponent>,
        private formBuilder: FormBuilder,
        private scaleItemDetailsBuyerService: ScaleItemDetailsBuyerService,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) { }


    ngOnInit() {
        this.parentscaleShelfLifeItems = this.data.parentscaleShelfLifeItems;
        this.scaleItemDetailsBuyerService.getFacilityGroupByTypeScaleShelfLife().subscribe(res => {
            this.facilityGroupShelfLifeList = res.map(fgd => ({
                code: Number(fgd.code),
                description: fgd.description,
                facilityGroup: fgd.facilityGroup,
                facilityGroupDescription: fgd.facilityGroupDescription,
                facilityCodeDescription: fgd.facilityCodeDescription
            }));;
            if (res != undefined) {
                this.facilityGroupType = res[0].facilityGroup;
                this.facilityGroupTypeDescription = res[0].facilityGroupDescription;
            }
        });
        if (this.data.scaleShelfLifeItemRow != undefined) {
            this.scaleShelfLife = this.formBuilder.group({
                rowId: this.data.scaleShelfLifeItemRow.rowId,
                facilityGroupSS: this.data.scaleShelfLifeItemRow.facilityGroupCode,
                shelfLifeDays: this.data.scaleShelfLifeItemRow.shelfLifeDay,
            });

            this.isEdit = true;
            this.scaleShelfLifeItemList = this.data.scaleShelfLifeItemList;
        }
        else {
            this.scaleShelfLife = this.formBuilder.group({
                rowId: '',
                facilityGroupSS: '',
                shelfLifeDays: ''
            });

            this.scaleShelfLifeItemList = [];
        }

    }


    public onCancel(): void {
        this.dialogRef.close();
    }

    public onAdd(): void {

        let scaleShelfLifeDto = this.getscaleShelfLifeDto();
        scaleShelfLifeDto.rowId = this.scaleShelfLifeItemList.length + 1;

        if (!this.checkDuplicateScaleShelfLife(scaleShelfLifeDto)) {
            this.scaleShelfLifeItemList.push(scaleShelfLifeDto);
            this.data.scaleShelfLifeItemList = this.scaleShelfLifeItemList;
            this.dialogRef.close(scaleShelfLifeDto);
        } else {
            let data = { description: "Scale Shelf Life already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Shelf Life already exists");
        }


    }
    public onAddContinue(): void {

        let scaleShelfLifeDto = this.getscaleShelfLifeDto();
        scaleShelfLifeDto.rowId = this.scaleShelfLifeItemList.length + 1;

        if (!this.checkDuplicateScaleShelfLife(scaleShelfLifeDto)) {
            this.scaleShelfLifeItemList.push(scaleShelfLifeDto);
            this.data.scaleShelfLifeItemList = this.scaleShelfLifeItemList;

            this.scaleShelfLife.reset();
            this.onAddEvent.emit(scaleShelfLifeDto);
            this.scaleShelfLife.reset();
        } else {
            let data = { description: "Scale Shelf Life already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Shelf Life already exists");
        }


    }

    public getscaleShelfLifeDto(): ScaleShelfLifeDto {

        let scaleShelfLifeDto = new ScaleShelfLifeDto();



        let refCode = this.scaleShelfLife.get("facilityGroupSS").value;
        var refObject = this.facilityGroupShelfLifeList.find(x => x.code == refCode);
        scaleShelfLifeDto.facilityGroupType = refObject.facilityGroup;
        scaleShelfLifeDto.facilityGroupTypeDescription = refObject.facilityGroupDescription;
        scaleShelfLifeDto.facilityGroupCode = refObject.code;
        scaleShelfLifeDto.facilityGroupDescription = refObject.description;

        scaleShelfLifeDto.shelfLifeDay = this.scaleShelfLife.get("shelfLifeDays").value;


        return scaleShelfLifeDto;
    }

    public onSave(): void {

        let scaleShelfLifeDto = this.getscaleShelfLifeDto();
        scaleShelfLifeDto.rowId = this.data.scaleShelfLifeItemRow.rowId;

        if (!this.checkDuplicateScaleShelfLife(scaleShelfLifeDto)) {
            this.data.scaleShelfLifeItemRow = scaleShelfLifeDto;
            this.dialogRef.close(scaleShelfLifeDto);
        } else {
            let data = { description: "Scale Shelf Life already exists", options: ["Ok"] }
            let dialogRef = this.dialog.open(DialogContentComponent, {
                disableClose: true,
                width: '800px',
                data: data
            });
            console.log("Scale Shelf Life already exists");
        }

    }

    public checkDuplicateScaleShelfLife(scaleShelfLifeDto: ScaleShelfLifeDto): boolean {
        if (this.parentscaleShelfLifeItems.find(x => x.facilityGroupCode == scaleShelfLifeDto.facilityGroupCode && x.shelfLifeDay == scaleShelfLifeDto.shelfLifeDay) != undefined) {
            return true;
        }
        return false;
    }

    public setErrors(): void {
        this.scaleShelfLife.controls.facilityGroupSS.markAsTouched({ onlySelf: true });
        this.scaleShelfLife.controls.shelfLifeDays.markAsTouched({ onlySelf: true });
    }

}
