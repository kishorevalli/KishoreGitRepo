﻿export class IScaleShelfLifeDto {
    rowId: number;
    itemFormID: number;
    facilityGroupType: string;
    facilityGroupTypeDescription: string;
    facilityGroupCode: number;
    facilityGroupDescription: string;
    shelfLifeDay: number;
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}
export class ScaleShelfLifeDto implements IScaleShelfLifeDto {
    rowId: number;
    itemFormID: number;
    facilityGroupType: string;
    facilityGroupTypeDescription: string;
    facilityGroupCode: number;
    facilityGroupDescription: string;
    shelfLifeDay: number;
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
}