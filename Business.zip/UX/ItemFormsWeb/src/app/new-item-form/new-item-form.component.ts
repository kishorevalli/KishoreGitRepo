import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Params, Router, UrlTree, UrlSegmentGroup, UrlSegment,PRIMARY_OUTLET,NavigationEnd  } from '@angular/router';
import 'rxjs/add/operator/filter';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { MatDialog, MatDialogConfig } from '@angular/material';

import { NewItemTab, IItemFormDto, ItemFormDto, UserType } from './new-item-form.interface';
import { NewItemFormService } from './new-item-form.service';
import { BasicItemDefinitionService } from './basic-item-definition/basic-item-definition.service';
import { DialogCommentsComponent } from './marketing-support/dialog-comments/dialog-comments.component';
import { AuthService } from '../core/services/auth.service';

@Component({
    templateUrl: './new-item-form.component.html',
    styleUrls: ['./new-item-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class NewItemFormComponent implements OnInit {

    public itemFormDto: IItemFormDto;
    public validationCount = {};
    links: NewItemTab[];

    public showPrintButton: boolean = false;
    public showCommentButton: boolean = true;
    constructor(private route: ActivatedRoute,
        private router: Router,
        public newItemFormService: NewItemFormService,
        private basicItemDefService: BasicItemDefinitionService,
        public dialog: MatDialog,
        private authService: AuthService) {
    }

    ngOnInit() {
        const itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        if (!itemFormDisplayID) {
            this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" });
        }
        else {
            this.validationCount = {};
            this.itemFormDto = new ItemFormDto();
            this.newItemFormService.tabWarningsCount$.subscribe(validation => {
                this.validationCount[validation["tabName"]] = validation["value"];
            });
            this.showHideButtons(this.router.url);
            this.router.events.subscribe((event) => {
                if (event instanceof NavigationEnd) {
                   this.showHideButtons(event.url);
                }
              });
            this.newItemFormService.getItemFormData(itemFormDisplayID).subscribe(res => {
                this.newItemFormService.setItemFormDisplayID(res.itemFormDisplayID, res.id);
                this.newItemFormService.setFormUserDetails(res);
                this.links = this.newItemFormService.getNavigationLinks(res, this.authService.isExternal);            
                forkJoin(this.newItemFormService.isDsdVendorsExistForItemForm(res.id),
                    this.basicItemDefService.getBasicItemDefinitionData(res.id),
                    this.newItemFormService.isFAMCodeExistsInProductGrouping(res.id))
                        .subscribe(results => {
                            if (results[0]) {
                                let dsdVendorLink: NewItemTab = this.links.find(x => x.link == 'dsd-authorization-request');
                                dsdVendorLink.disabled = false;
                            }
                            if(results[1]){
                                this.newItemFormService.setBIDData(results[1]);
                                let ShipperItemCompositionLink: NewItemTab = this.links.find(x => x.link == 'shipper-item-composition');
                                if(this.newItemFormService.isShipper())
                                    ShipperItemCompositionLink.disabled = false;
                                else
                                    ShipperItemCompositionLink.disabled = true;
                            }
                            if (results[2]) {
                                let productAttributesLink: NewItemTab = this.links.find(x => x.link == 'product-attributes');
                                if(productAttributesLink)
                                productAttributesLink.disabled = false;
                            }
                            this.itemFormDto = res;
                        });
                        this.newItemFormService.GetItemFormErrors(res.id).subscribe(res=>{
                             if(res){
                                 console.log("GetItemFormErrors Sucess");
                             }
                        });
                        if(this.authService.userType == 2 || this.authService.userType == 3 || this.authService.userType == 6){
                            this.newItemFormService.GetItemFormGroup(res.id).subscribe(res =>{
                                if(res){
                                    console.log("GetItemFormGroup Sucess");
                                }
                            }); 
                        }
            });
        }
    }
    openDialog() {
        // const tree: UrlTree = this.router.parseUrl(this.router.url);
        // const g: UrlSegmentGroup = tree.root.children[PRIMARY_OUTLET];
        // const s: UrlSegment[] = g.segments;
        // if(s[s.length-1].path == "marketing-support") return;
        const dialogConfig = new MatDialogConfig();
        dialogConfig.position = {
            top: '10',
            right: '0'
        };
        dialogConfig.width = "500px";
        this.dialog.open(DialogCommentsComponent, dialogConfig);
    }
    showHideButtons(url:string){
        if(url.includes('marketing-support')){
            this.showCommentButton = false;
        }
        else {
            this.showCommentButton = true;
        }
        if(url.includes('review-create-item')){
            this.showPrintButton = true;
        }
        else {
            this.showPrintButton = false;
        }
    }
    print() {
        window.print();
    }
    redirect(itemFormDisplayID:number,itemFormID:number){
        this.newItemFormService.setRefreshItemFormDisplayID(itemFormDisplayID,itemFormID);
        // console.log("redirect: "+this.router.url);
        const tree: UrlTree = this.router.parseUrl(this.router.url);
        const g: UrlSegmentGroup = tree.root.children[PRIMARY_OUTLET];
        const s: UrlSegment[] = g.segments;
        //console.log("redirect path: "+ s[s.length-1].path);
        this.newItemFormService.refreshItemFormUrl = s[s.length-1].path;
        this.router.navigate(['/new-item-form/redirect'], { queryParamsHandling: "merge" });
    }
   
}
