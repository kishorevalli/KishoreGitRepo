type CharBoolean = 'Y' | 'N';
export interface IMarketingInfo {
    itemFormID: number;
    projectedSales52Weeks?: number;
    unitCost?: number;
    unitCostUOM: string;
    suggestedRetail?: number;
    suggestedMargin?: number;
    itemPreviouslyPresented: CharBoolean;
    availableShipDate?: string;
    newItemFundsAvailable: CharBoolean;
    newItemFundsAmount?: number;
    promoSupportFrequency?: number;
    mediaSupport: string;
    localChainPresentlyStocking : string;
    formStatusID?: number;
    formActionID?: number;
    vendorContactEmail: string;
    similarItemGTINList: ISimilarItemGTIN[]; 
}
export class MarketingInfo implements IMarketingInfo {
    itemFormID: number;
    projectedSales52Weeks?: number;
    unitCost?: number;
    unitCostUOM: string;
    suggestedRetail?: number;
    suggestedMargin?: number;
    itemPreviouslyPresented: CharBoolean;
    availableShipDate?: string;
    newItemFundsAvailable: CharBoolean;
    newItemFundsAmount?: number;
    promoSupportFrequency?: number;
    mediaSupport: string;
    localChainPresentlyStocking : string;
    formStatusID?: number;
    formActionID?: number;
    vendorContactEmail: string;
    similarItemGTINList: ISimilarItemGTIN[]; 
}

export interface ISimilarItemGTIN {
    id: number;
    itemFormID: number;
    formattedSimilarGtin: string;
    similarGTINCheckDigit?: number;
    similarGTINNewItemFormID?: number;
    similarGTINNewItemFormDisplayID?: string;
}
export class SimilarItemGTIN implements ISimilarItemGTIN {
    id: number;
    itemFormID: number;
    formattedSimilarGtin: string;
    similarGTINCheckDigit?: number;
    similarGTINNewItemFormID?: number;
    similarGTINNewItemFormDisplayID?: string;
}
export interface IFormComment {
    id?: number;
    itemFormID: number;
    comment: string;
    createdByUserTypeID?: number;
    showVendor: boolean;
    createdBy?: string;
    createdDate?: Date;
}