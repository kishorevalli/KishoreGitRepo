import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ILookupDto, IItemSaveResponse } from '../../shared/common.interface';
import { IMarketingInfo, IFormComment } from './marketing-support.interface';
import { NewItemFormService } from '../new-item-form.service';
import { APP_CONFIG, AppConfig } from '../../app.config';

@Injectable()
export class MarketingSupportService {
    private baseUrl;
    private serviceBase: string = 'api/MarketingSupport/';

    constructor( @Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;
    }
    
    GetPromoSupportFrequency(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetPromoSupportFrequency');
    }
    GetUnitCostUOM(): Observable<ILookupDto[]> {
        return this.httpClient.get<ILookupDto[]>(this.baseUrl + this.serviceBase + 'GetUnitCostUOM');
    }
    GetMarketingInfo(itemFormID: number): Observable<IMarketingInfo> {
        return this.httpClient.get<IMarketingInfo>(this.baseUrl + this.serviceBase + `GetMarketingInfo?itemFormID=${itemFormID}`);
    }
    SaveMarketingInfo(marketingInfo: IMarketingInfo): Observable<IItemSaveResponse> {
        return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + 'SaveMarketingInfo', marketingInfo);
    }
    GetFormComment(itemFormID: number): Observable<IFormComment[]> {
        return this.httpClient.get<IFormComment[]>(this.baseUrl + this.serviceBase + `GetFormComment?itemFormID=${itemFormID}`);
    }
    SaveFormComment(formComment: IFormComment): Observable<IItemSaveResponse> {
        return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + 'SaveFormComment', formComment);
    }
}
