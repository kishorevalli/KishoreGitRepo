import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, Input } from '@angular/core';
import { FormBuilder, FormControl, FormArray, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { IFormComment } from '../marketing-support.interface';
import { MarketingSupportService } from '../marketing-support.service';
import { NewItemFormService } from '../../new-item-form.service';

@Component({
  selector: 'app-dialog-comments',
  templateUrl: './dialog-comments.component.html',
  styleUrls: ['./dialog-comments.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DialogCommentsComponent implements OnInit {

  public FormCommentFormGroup: FormGroup;
  public FormComments: IFormComment[] = [];
  public VendorFormComments: IFormComment[] = [];
  public BuyerFormComments: IFormComment[] = [];
  public itemFormID: number;
  public isExternal: boolean;
  public showSpinner: boolean = false;
  public showSpinnerOnLoad: boolean = false;
  public showVisibilityIcon: boolean = false;
  public showNoVendorComments: boolean = false;
  public showNoBuyerComments: boolean = false;
  @Input() showOnScreen: boolean = false;
  constructor(private fb: FormBuilder,
    private newItemFormService: NewItemFormService,
    private marketingSupportService: MarketingSupportService,
    private auth: AuthService, 
    private cdr: ChangeDetectorRef,) { }

  ngOnInit() {
    this.isExternal = this.auth.isExternal;
    this.itemFormID = this.newItemFormService.itemFormID;
    this.FormCommentFormGroup = this.fb.group({
      comment: '',
      showVendor: null
    });
    this.GetFormComment();
  }
  GetFormComment() {
    this.showSpinnerOnLoad = true;
    this.marketingSupportService.GetFormComment(this.itemFormID).subscribe(res => {
      this.showSpinnerOnLoad = false;
      this.FormComments = res;
      this.VendorFormComments = res.filter(item => item.createdByUserTypeID === 1);
      this.showNoVendorComments = this.VendorFormComments.length === 0;
      this.BuyerFormComments = res.filter(item => item.createdByUserTypeID !== 1);
      this.showNoBuyerComments = this.BuyerFormComments.length === 0;
      this.cdr.markForCheck();
    },
    (err) => {
        this.showSpinnerOnLoad = false;
        this.cdr.markForCheck();
    });
  }
  changeShowVendor(checked:boolean){
    this.showVisibilityIcon = checked;
    this.cdr.markForCheck();
  }
  AddChatMessage() {
    if (this.FormCommentFormGroup.controls.comment.value.trim().length == 0) return;
    const newComment: IFormComment = {
      itemFormID: this.itemFormID,
      comment: this.FormCommentFormGroup.controls.comment.value,
      showVendor: this.FormCommentFormGroup.controls.showVendor.value
    }
    this.SaveFormComment(newComment);
  }
  SaveFormComment(formComment: IFormComment) {
    this.showSpinner = true;
    this.marketingSupportService.SaveFormComment(formComment).subscribe(res => {
      this.showSpinner = false;
      if (res && res.status) {
        console.log("Saved Successfully!");
        this.FormCommentFormGroup.setValue({
          comment: '',
          showVendor: null
        });
        this.showVisibilityIcon = false;
        this.GetFormComment();
      }
      this.cdr.markForCheck();
    },
      (err) => {
        this.showSpinner = false;
        this.cdr.markForCheck();
      });
  }
}