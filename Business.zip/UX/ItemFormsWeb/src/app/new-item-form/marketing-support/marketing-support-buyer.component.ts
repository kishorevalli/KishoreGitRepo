import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormArray, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition  } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

import { NewItemFormService } from '../new-item-form.service';
import { AuthService } from '../../core/services/auth.service';
import { BasicItemDefinitionService } from '../basic-item-definition/basic-item-definition.service';
import { IMarketingInfo, ISimilarItemGTIN } from './marketing-support.interface';
import { MarketingSupportService } from './marketing-support.service';
import { ILookupDto, LookupDto, ILookupIntDto, LookupIntDto } from '../../shared/common.interface';
import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component';
import { gtinValidator, GTINValidatorHelper } from '../common/validators/gtin.validator';
import { IItemValidationDTO } from '../../shared/common.interface';
import * as _moment from 'moment';
const moment = _moment;



@Component({
  selector: 'ifw-marketing-support-buyer',
  templateUrl: './marketing-support-buyer.component.html',
  styleUrls: ['./marketing-support-buyer.component.scss']
})
export class MarketingSupportBuyerComponent implements OnInit {

  public itemFormDisplayID: number;
  public itemFormID: number;
  public isExternal: boolean;
  MarketingSupportFormGroup: FormGroup;
  SimilarGTINFormGroup: FormGroup;
  public promoSupportFrequencyList: ILookupDto[];
  public unitCostUOMList: ILookupDto[];
  public defaultDate: Date;
  public enableAddButton: boolean = false;
  public showSpinnerAddButton: boolean = false;
  gtinHelper: GTINValidatorHelper;
  public isReadOnly: boolean = false; 
  public formErrors: any;
  public errors: any[];
  public warnings: any[];
  constructor(private fb: FormBuilder,
    public dialog: MatDialog,
    private newItemFormService: NewItemFormService,
    private auth: AuthService,
    private marketingSupportService: MarketingSupportService,
    private basicItemDefService: BasicItemDefinitionService,
    private router: Router,
    private route: ActivatedRoute,
    public snackBar: MatSnackBar,
  ) { }

  ngOnInit() {
    this.defaultDate = moment().toDate();
    this.gtinHelper = new GTINValidatorHelper({});
    this.isExternal = this.auth.isExternal;
    this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
    this.itemFormID = this.newItemFormService.itemFormID;
    //this.isReadOnly = this.newItemFormService.isReadOnly;
    this.createForm();
    this.marketingSupportService.GetPromoSupportFrequency().subscribe(res => {
      this.promoSupportFrequencyList = res;
    });
    this.marketingSupportService.GetUnitCostUOM().subscribe(res => {
      this.unitCostUOMList = res;
    });
    this.calculateSuggestedMarginChanges();
    this.errors = [];
    this.warnings = [];
    this.formErrors = {};
    this.GetMarketingSupport(this.itemFormID, false);
  }
  createForm() {
    this.MarketingSupportFormGroup = this.fb.group({
      itemFormID: this.itemFormID,
      projectedSales52Weeks: null,
      unitCost: null,
      unitCostUOM: '',
      suggestedRetail: '',
      suggestedMargin: { value: null, disabled: true },
      itemPreviouslyPresented: '',
      availableShipDate: null,
      newItemFundsAvailable: '',
      newItemFundsAmount: null,
      promoSupportFrequency: null,
      mediaSupport: '',
      localChainPresentlyStocking: '',
      formStatusID: null,
      formActionID: null,
      similarItemsYN: '',
      vendorContactID: { value: this.newItemFormService.vendorContactID, disabled: true },
      vendorContactName: { value: this.newItemFormService.vendorContactName, disabled: true },
      vendorContactEmail: this.newItemFormService.vendorContactEmail,
      similarItemGTINList: this.fb.array([]),
    });
    this.SimilarGTINFormGroup = this.fb.group({
      formattedGtin: '',
      gtinCheckDigit: null,
    })
  }
  private GetMarketingSupport(itemFormID: number, afterSave: boolean) {
    this.marketingSupportService.GetMarketingInfo(this.itemFormID).subscribe(res => {
      this.MarketingSupportFormGroup.markAsPristine();
      this.MarketingSupportFormGroup.markAsUntouched();      
      this.MarketingSupportFormGroup.setControl('similarItemGTINList', this.fb.array([]));
      this.MarketingSupportFormGroup.patchValue(res);
      //reset the current form status ID in new item form service.
      this.newItemFormService.formCurrentStatusID = res.formStatusID;
      const similarItemGTINList = res.similarItemGTINList;
      if (similarItemGTINList && similarItemGTINList.length > 0) {
        this.MarketingSupportFormGroup.controls.similarItemsYN.setValue("Y");
        this.similarItemsShow = true;
        this.InitSimilarItemGTIN(similarItemGTINList);
      }
      //console.log("GetMarketingSupport");


        this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
            const validations: any = this.newItemFormService.getItemValidation("Marketing Support");
            if (validations) {
              this.handleValidationErrors(validations);
            }
        });

    },
      (err) => {
        this.showSpinner = false;
      });
  }
  InitSimilarItemGTIN(existingGTINList: ISimilarItemGTIN[]) {
    for (const similarItemGTIN of existingGTINList) {
      this.similarItemGTINList.push(this.buildSimilarItemGTIN(similarItemGTIN));
    }
  }
  buildSimilarItemGTIN(val: ISimilarItemGTIN) {
    return this.fb.group({
      id: val.id,
      itemFormID: val.itemFormID,
      formattedSimilarGtin: val.formattedSimilarGtin,
      similarGTINCheckDigit: val.similarGTINCheckDigit,
      similarGTINNewItemFormID: val.similarGTINNewItemFormID,
      similarGTINNewItemFormDisplayID: val.similarGTINNewItemFormDisplayID
    });
  }
  get similarItemGTINList(): FormArray {
    return <FormArray>(this.MarketingSupportFormGroup.controls.similarItemGTINList)
  }

  AddSimilarGTIN() {
    if (this.enableAddButton) {
      this.enableAddButton = false;
      this.showSpinnerAddButton = true;
      const formattedSimilarGtin = this.SimilarGTINFormGroup.controls.formattedGtin.value;
      if (this.IsGTINExists(formattedSimilarGtin)) {
        this.showSpinnerAddButton = false;
        this.SimilarGTINFormGroup.controls["formattedGtin"].setErrors({ gtinexists: true });
        this.SimilarGTINFormGroup.controls["formattedGtin"].markAsTouched({ onlySelf: true });
        return;
      }
      this.IsGTINExistsInPMDS(formattedSimilarGtin).subscribe(res => {
        this.showSpinnerAddButton = false;
        if (res) {
          this.SimilarGTINFormGroup.controls["formattedGtin"].setErrors({ gtinexists: true });
          this.SimilarGTINFormGroup.controls["formattedGtin"].markAsTouched({ onlySelf: true });
          return;
        }
        else {
          const similarGTIN = this.buildSimilarItemGTIN({
            id: 0,
            itemFormID: this.itemFormID,
            formattedSimilarGtin: this.SimilarGTINFormGroup.controls.formattedGtin.value,
            similarGTINCheckDigit: this.SimilarGTINFormGroup.controls.gtinCheckDigit.value,
          });
          //var formArray = <FormArray>(this.MarketingSupportFormGroup.controls.similarItemGTINList);
          this.similarItemGTINList.push(similarGTIN);
          similarGTIN.markAsDirty();
          this.resetSimilarGTINFormGroup();
        }
      });
    }
  }
  resetSimilarGTINFormGroup() {
    this.SimilarGTINFormGroup.reset();
    this.clearGtinValidationRules();
  }
  IsGTINExists(enteredGTIN: string): boolean {
    if(enteredGTIN == this.newItemFormService.formattedGtin) return true;
    return this.similarItemGTINList.controls.some(item => {
      var formGroup = <FormGroup>item;
      return formGroup.controls.formattedSimilarGtin.value == enteredGTIN;
    });
  }
  // This will return true if the item exists and last scan date is less than 2 years.
  IsGTINExistsInPMDS(enteredGTIN: string): Observable<boolean> {
    let gtin = enteredGTIN.replace(/-/g, "");
    return this.basicItemDefService.isGTINExists(+gtin).pipe(
      map(res => {
        if (res.isGTINExist) {
          const age = moment().diff(res.lastScanDate, 'years');
          if (age < 2) {
            return true;
          }
        }
        return false;
      }),
      catchError((err) => {
        return of(false);
      })
    );
  }
  calculateSuggestedMarginChanges() {
    // initialize value changes stream
    const changesSuggestedRetail$ = this.MarketingSupportFormGroup.controls.suggestedRetail.valueChanges;
    const changesunitCost$ = this.MarketingSupportFormGroup.controls.unitCost.valueChanges;
    // subscribe to the stream
    changesSuggestedRetail$
      .debounceTime(1200)
      .distinctUntilChanged()
      .subscribe(suggestedRetail => {
        const unitCost = this.MarketingSupportFormGroup.controls.unitCost.value;
        this.setSuggestedMargin(suggestedRetail, unitCost);
      });
    changesunitCost$
      .debounceTime(1200)
      .distinctUntilChanged()
      .subscribe(unitCost => {
        const suggestedRetail = this.MarketingSupportFormGroup.controls.suggestedRetail.value;
        this.setSuggestedMargin(suggestedRetail, unitCost);
      });
  }
  private setSuggestedMargin(suggestedRetail, unitCost) {
    const suggestedRetailNumber: number = parseFloat(suggestedRetail);
    const unitCostNumber: number = parseFloat(unitCost);
    const suggestedMargin = this.MarketingSupportFormGroup.controls.suggestedMargin;
    if (suggestedRetailNumber && unitCostNumber) {
      let suggestedMarginValue = (suggestedRetailNumber - unitCostNumber) / suggestedRetailNumber;
      suggestedMarginValue = +suggestedMarginValue.toFixed(2);
      suggestedMargin.setValue(suggestedMarginValue);
    }
    else {
      suggestedMargin.setValue(null);
    }
  }
  changeNewItemFundsAvailable(val: string) {
    if (val == "N") {
      this.MarketingSupportFormGroup.patchValue({
        newItemFundsAmount: ''
      });
    }
  }
  similarItemsShow: boolean = false;
  changeAreSimilarItems(val: string) {
    if (val == 'Y') {
      this.similarItemsShow = true;
    }
    else {
      this.similarItemsShow = false;
      this.clearFormArray(this.similarItemGTINList);
    }
  }
  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }
  deleteRow(index: number) {
    let dialog = this.dialog.open(ConfirmDialogComponent);
    dialog.afterClosed().subscribe(option => {
      if (option && option === true) {
        this.similarItemGTINList.removeAt(index);
        this.similarItemGTINList.markAsDirty();
      }
    });
  }
  /*** START GTIN validation rules */
  public get checkDigitDisplay(): number {
    var formattedGtinControl = this.SimilarGTINFormGroup.controls.formattedGtin;
    let gtin = formattedGtinControl.value;
    if (gtin && gtin.length == 15) {
      return this.gtinHelper.getCheckdigit(gtin)
    }
    return null;
  }
  public FormatGtin(): void {
    this.clearGTINCheckdigit();// Fix if GTIN is copied instead keying in. Called the keypress event too
    var formattedGtinControl = this.SimilarGTINFormGroup.get("formattedGtin");
    let gtin = formattedGtinControl.value;
    if (gtin.length > 7) {
      formattedGtinControl.patchValue(this.gtinHelper.padGtin(gtin, 13));
    }
    else {
      this.clearGtinValidationRules();
    }
  }
  public clearGTINCheckdigit(): void {
    this.SimilarGTINFormGroup.controls.gtinCheckDigit.setValue('');
    this.enableAddButton = false;
  }
  public changeGTINCheckdigit(): void {
    this.gtinValidationRules(this.isExternal);
    this.isGTINValid();
  }
  public isGTINValid() {
    const formattedGtin = this.SimilarGTINFormGroup.controls.formattedGtin;
    if (formattedGtin.status == "VALID") {
      console.log("Valid GTIN" + formattedGtin.value);
      this.enableAddButton = true;
    }
  }
  private gtinValidationRules(isExternal: boolean) {
    const formattedGtinControl = this.SimilarGTINFormGroup.controls.formattedGtin;
    formattedGtinControl.setValidators([gtinValidator({
      validateCheckDigit: true,
      range: true,
      type2: isExternal,
      dummy: true,
      vendorCoupon: true
    })]);
    formattedGtinControl.updateValueAndValidity();
  }
  private clearGtinValidationRules() {
    const formattedGtinControl = this.SimilarGTINFormGroup.controls.formattedGtin;
    formattedGtinControl.setValidators(null);
    formattedGtinControl.updateValueAndValidity();
  }
  checkIfPastDateEntered(): boolean {
    const availableShipDateCtrl = this.MarketingSupportFormGroup.controls.availableShipDate;
    // const newValue = nutritionalInfoNotAvailableUntilCtrl.value;
    if (availableShipDateCtrl.dirty && availableShipDateCtrl.invalid) {
      return false;
    }
    return true;
  }
  getErrorMessage(control: FormControl, name: string) {
    for (let propertyName in control.errors) {
      if ((propertyName == "invalid" || propertyName == "warning") && this.formErrors[name]){
          return this.formErrors[name]; 
      }
      if (control.errors.hasOwnProperty(propertyName) && control.touched) {
        return this.getValidatorErrorMessage(propertyName, control.errors[propertyName]);
      }
    }
    return null;
  }
  getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
    let config = {
      'required': 'This field is required.',
      'notvalid': 'This is not a valid value',
      'email': 'This is not a valid email',
      'minlength': `This field should have atleast ${validatorValue.requiredLength} characters`,
      'beforePadding': 'This field is required.',
      'range': 'GTIN entered must be in range 000-00010-00000 to 999-99999-99999.',
      'type2': "GTIN entered is reserved for type -2 GTIN's.",
      'dummy': "GTIN entered is reserved for Dummy GTIN's.",
      'vendorCoupon': "GTIN entered is reserved for Vendor Coupons.",
      'checkDigitRequired': "GTIN Check digit is required to validate GTIN.",
      'checkDigit': 'GTIN Check digit is not valid for the GTIN.',
      'gtinexists': 'GTIN already exists.',
    };
    return config[validatorName];
  }

  /** END GTIN validation rules */
  /**** START Action Component Events ***/

  public showSpinner: boolean = false;
  public skipSaveTab: boolean = false;
  performAction(action: any) {
    switch (action.actionName) {
      case "Save":
        this.saveMarketingSupport(action.createdFormStatusID, action.actionID);
        break;
      case "Delete":
        this.deleteItemForm();
        break;
      case "Submit":
            this.submitMarketingSupport(action.createdFormStatusID, action.actionID);
        break;

    }
  }

  public saveMarketingSupport(createdFormStatusID: number, actionID: number): void {
    this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
      if (res) {
        this.snackBar.open("Saved successfully.", null, {
          duration: 500,
          horizontalPosition: 'center',
          verticalPosition: 'bottom',
        });
      }
    });
  }


    public submitMarketingSupport(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            //this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
            //    this.GetMarketingSupport(this.itemFormID, true);
            //});
            if (res) {
                this.snackBar.open("Submit successfully.", null, {
                    duration: 500,
                    horizontalPosition: 'center',
                    verticalPosition: 'bottom',
                });
            }
            else {
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
        });
    }

    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

  saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
    if (this.skipSaveTab || this.isReadOnly) return of(true);
    if (!createdFormStatusID && !this.MarketingSupportFormGroup.dirty) return of(true);
    var result = this.checkIfPastDateEntered();
    if (!result) {
      this.snackBar.open("Please correct the errors.", null, {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
      });
      return of(false);
    }
    this.errors = [];
    this.warnings = [];
    if (createdFormStatusID && actionID) {
      this.MarketingSupportFormGroup.controls.formStatusID.setValue(createdFormStatusID);
      this.MarketingSupportFormGroup.controls.formActionID.setValue(actionID);
    }
    const marketingInfo: IMarketingInfo = (<any>Object).assign({}, this.MarketingSupportFormGroup.getRawValue());
    this.showSpinner = true;
    this.newItemFormService.showLoadingSpinner = true;
    return this.marketingSupportService.SaveMarketingInfo(marketingInfo).pipe(
      map(res => {
        this.newItemFormService.showLoadingSpinner = false;
        if (createdFormStatusID && res.status) {
          this.newItemFormService.formCurrentStatusID = createdFormStatusID;
        }
        if(res.validation)
          this.newItemFormService.addItemValidation(res.validation);
        console.log("saved successfully.");
            this.showSpinner = false;
            if(actionID)
                this.GetMarketingSupport(this.itemFormID, true);

        return res.status;
      }),
      catchError((err) => {
        this.newItemFormService.showLoadingSpinner = false;
        this.showSpinner = false;
        if (err.status === 400) {
          this.newItemFormService.addItemValidation(err.error);
          this.handleValidationErrors(err.error);
        }
        else if (err.status === 401) {
          console.log("saved error. " + err.status);
          let message = err.error.exceptionMessage || err.error.message;
          this.errors.push(message);
        }
        else {
          console.log("saved error. " + err.status);
          let message = err.error.exceptionMessage || err.error.message;
          this.errors.push(message);
        }
        console.log("saved error. " + err.status);
        window.scrollTo(0, 150);
        this.snackBar.open("Please correct the errors.", null, {
            duration: 3000,
            horizontalPosition: 'center',
            verticalPosition: 'top',
        });
        return of(false);
      })
    );
  }

  reset() {
    this.resetToInitialState();
    this.GetMarketingSupport(this.itemFormID, false);
  }
  resetToInitialState() {
    this.MarketingSupportFormGroup.markAsPristine();
    this.MarketingSupportFormGroup.markAsUntouched();
    this.MarketingSupportFormGroup.patchValue({
      itemFormID: this.itemFormID,
      projectedSales52Weeks: null,
      unitCost: null,
      unitCostUOM: '',
      suggestedRetail: '',
      suggestedMargin: null,
      itemPreviouslyPresented: '',
      availableShipDate: null,
      newItemFundsAvailable: '',
      newItemFundsAmount: null,
      promoSupportFrequency: null,
      mediaSupport: '',
      localChainPresentlyStocking: '',
      formStatusID: null,
      formActionID: null,
      similarItemsYN: ''
    });
    this.MarketingSupportFormGroup.setControl('similarItemGTINList', this.fb.array([]));
    this.similarItemsShow = false;
    this.resetSimilarGTINFormGroup();
  }
  public deleteItemForm(): void {
    let dialog = this.dialog.open(ConfirmDialogComponent);
    dialog.afterClosed().subscribe(option => {
      if (option && option === true) {
        this.showSpinner = true;
        this.newItemFormService.deleteItemForm().subscribe(res => {

          this.showSpinner = false;
          if (res != undefined) {
            if (res == true)
              console.log('Deleted Successfully');
            else
              console.log('Delete Failed');
          }
          this.skipSaveTab = true;
          this.router.navigate(['/dashboard'], { queryParamsHandling: 'merge' });
        },
          (err) => {
            this.showSpinner = false;
            if (err.status === 400) {
              // handle validation error
              let validationErrorDictionary = err.error.modelState;
              //this.handleGpaValidationErrors(validationErrorDictionary);
            } else {
              // this.formErrors.push("Unhandled expection occured.");
            }
            window.scrollTo(0, 0);
          })
      }
    });
  }
  handleValidationErrors(validationDTO: IItemValidationDTO){
    let errorDTOs = validationDTO.errors;
    let warningDTOs = validationDTO.warnings;
    for(let errorDTO of errorDTOs){
      let fieldName = errorDTO.controlName;
      if (fieldName && this.MarketingSupportFormGroup.controls[fieldName]) {
        this.MarketingSupportFormGroup.controls[fieldName].setErrors({ invalid: true });
        this.MarketingSupportFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
        this.formErrors[fieldName] = errorDTO.errorDescription;    
      }
      else {
        this.errors.push(errorDTO.errorDescription);
      }      
    }
    for(let warningDTO of warningDTOs){
      let fieldName = warningDTO.controlName;
      if (fieldName && this.MarketingSupportFormGroup.controls[fieldName]) {
        this.MarketingSupportFormGroup.controls[fieldName].setErrors({ warning: true });
        this.MarketingSupportFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
        this.formErrors[fieldName] = warningDTO.errorDescription;
      }
      else {
        this.warnings.push(warningDTO.errorDescription);
      }      
    }
  }
}
