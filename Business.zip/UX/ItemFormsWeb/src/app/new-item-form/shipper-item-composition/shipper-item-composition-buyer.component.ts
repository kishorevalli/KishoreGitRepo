import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ifw-shipper-item-composition-buyer',
  templateUrl: './shipper-item-composition-buyer.component.html',
  styleUrls: ['./shipper-item-composition-buyer.component.scss']
})
export class ShipperItemCompositionBuyerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
