import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { IShipperItemCompositionDto, ShipperItemCompositionDto } from './shipper-item-composition.interface';
import { BasicItemDefinitionService } from '../basic-item-definition/basic-item-definition.service';
import { DialogContentComponent } from '../basic-item-definition/dialog-content.component';
import { gtinValidator, GtinValidatorOptions, GTINValidatorHelper } from '../common/validators/gtin.validator';
import { ShipperItemCompositionService } from './shipper-item-composition.service';

import { ILookupDto, LookupDto } from '../../shared/common.interface';
import { NewItemFormService } from '../new-item-form.service';
import { ItemFormDto } from '../new-item-form.interface';

@Component({
  selector: 'ifw-dialog-composition-item',
  templateUrl: './dialog-composition-item.component.html',
  styleUrls: ['./dialog-composition-item.component.scss']
})

export class DialogCompositionItemComponent implements OnInit {

    //Form control variables
    onAddEvent = new EventEmitter<IShipperItemCompositionDto>();
    compositionItemFormGroup: FormGroup;
    gtinControlFormGroup: FormGroup;

    gtinHelper: GTINValidatorHelper;
    public shipperItemComposition: IShipperItemCompositionDto;
    public shipperItemCompositionList: IShipperItemCompositionDto[];   
    public parentShipperItemCompositionList: IShipperItemCompositionDto[];   

    //Lookup dropdownlist

    public sizeUomList: ILookupDto[];
    public isEdit: boolean = false;

    public subDepartment: string;
    public subDepartmentID: string;
    public compositionItemTypeCode: string; 
    public createdByUserTypeID: number;

    public isBuyer: boolean;
    errors: string[];
    formErrors: any;


    constructor(public dialogRef: MatDialogRef<DialogCompositionItemComponent>,
        private formBuilder: FormBuilder,
        private basicItemDefService: BasicItemDefinitionService,
        private shipperItemCompositionService: ShipperItemCompositionService,
        public dialog: MatDialog,
        private newItemFormService: NewItemFormService,
        @Inject(MAT_DIALOG_DATA) public data: any) {


    }
    gtinValidatorOptions: GtinValidatorOptions = {
        validateCheckDigit: true,
        range: true,
        type2: true,
        dummy: true,
        vendorCoupon: true
    }
    ngOnInit() {
        this.gtinHelper = new GTINValidatorHelper({});
        this.errors = [];
        this.formErrors = {};
       
        //this.additionalgtindto = new additionalgtindto();
        this.parentShipperItemCompositionList = this.data.parentShipperItemCompositionList;
        this.createdByUserTypeID = this.data.createdByUserTypeID;

        if (this.data.shipperItemCompositionRow != undefined) {
            //this.additionalGtinDto = this.data.shipperItemCompositionRow;
            this.compositionItemFormGroup = this.formBuilder.group({
                rowId: this.data.shipperItemCompositionRow.rowId,
                formattedCompositionGtin: [this.data.shipperItemCompositionRow.formattedCompositionGtin,[gtinValidator({
                    validateCheckDigit: false,
                    range: false,
                    type2: false,
                    dummy: false,
                    vendorCoupon: false,
                    checkDigitCtrlName: 'compositionGTINCheckDigit'
                })]],
                compositionGTINCheckDigit: this.data.shipperItemCompositionRow.compositionGTINCheckDigit,               
                compositionItemCode: this.data.shipperItemCompositionRow.compositionItemCode,
                compositionItemDescription: this.data.shipperItemCompositionRow.compositionItemDescription,
                size: this.data.shipperItemCompositionRow.size,
                compositionUOM: this.data.shipperItemCompositionRow.compositionUOM,                
                quantity: this.data.shipperItemCompositionRow.quantity,               
                existingGtinIndicator:this.data.shipperItemCompositionRow.existingGtinIndicator     
            });
            this.isEdit = true;
            this.subDepartment = this.data.shipperItemCompositionRow.subDepartment;
            this.subDepartmentID = this.data.shipperItemCompositionRow.subDepartmentID;
            this.shipperItemCompositionList = this.data.shipperItemCompositionList;
            //this.showHideControlsOnInit();
        }        
        else {
            this.compositionItemFormGroup = this.formBuilder.group({
                rowId: 0,
                formattedCompositionGtin: ['', [gtinValidator({
                    validateCheckDigit: false,
                    range: false,
                    type2: false,
                    dummy: false,
                    vendorCoupon: false,
                    checkDigitCtrlName: 'compositionGTINCheckDigit'
                })]],
                compositionGTINCheckDigit: '',               
                size: '',
                compositionUOM: '', 
                compositionItemCode: [''],
                compositionItemDescription: '',
                quantity: [''],                    
                existingGtinIndicator: ''
            });
            this.isEdit = false;
            this.shipperItemCompositionList = [];
           
        }


        this.isBuyer = this.data.isBuyer;
       
        this.compositionItemFormGroup.get("compositionItemDescription").disable();

        this.basicItemDefService.getUnitOfMeasures().subscribe(res => {
            this.sizeUomList = res;
        })
    }

    

    public subscribeGTINValidations(isSubscribe: boolean) {
        const formattedCompositionGtin = this.compositionItemFormGroup.controls.formattedCompositionGtin;
        if (isSubscribe) {
            formattedCompositionGtin.setValidators([gtinValidator(this.gtinValidatorOptions)]);
        }
        else {
            formattedCompositionGtin.setValidators([]);
        }
        formattedCompositionGtin.updateValueAndValidity();
    }

    IsGTINExists() {
        let gtin = this.compositionItemFormGroup.get("formattedCompositionGtin").value.replace(/-/g, "");       
        this.validateShipperItemCompositionByGTIN(gtin);
    }

    public FormatGtin(): void {
        var compositionGTINControl = this.compositionItemFormGroup.get("formattedCompositionGtin");
        let gtin = compositionGTINControl.value;
        //this.validateShipperItemCompositionByGTIN(gtin.replace(/-/g, ""));
        if (gtin.length > 7) {
            // this.additionalGtinDto.compositionGTIN = this.gtinHelper.padGtin(this.additionalGtinDto.compositionGTIN, 13);
            compositionGTINControl.patchValue(this.gtinHelper.padGtin(gtin, 13));
            this.gtinValidationRules(this.isBuyer);
        }
        this.isGTINValid();
       
    }

    public clearEnteredGtin(e): void {
        this.compositionItemFormGroup.controls.compositionGTINCheckDigit.setValue(null);
    }
    

    public changeGTINCheckdigit(): void {
        //let gtin = this.additionalGtinDto.compositionGTIN;
        let gtin = this.compositionItemFormGroup.controls.formattedCompositionGtin.value;
        if (gtin.length > 7) {
            this.compositionItemFormGroup.controls.formattedCompositionGtin.markAsTouched({ onlySelf: true });
            this.gtinValidationRules(this.isBuyer);
        }
        this.isGTINValid();
        //this.validateShipperItemCompositionByGTIN(gtin.replace(/-/g, ""));
    }
    public isGTINValid() {
        const formattedCompositionGtin = this.compositionItemFormGroup.controls.formattedCompositionGtin;
        if (formattedCompositionGtin.status == "VALID") {
            console.log("IsGTINExists" + formattedCompositionGtin.value);
            this.IsGTINExists();
        }
    }
    private gtinValidationRules(isBuyer: boolean) {
        const formattedCompositionGtin = this.compositionItemFormGroup.controls.formattedCompositionGtin;
        formattedCompositionGtin.setValidators([gtinValidator({
            validateCheckDigit: true,
            range: true,
            type2: !isBuyer,
            dummy: true,
            vendorCoupon: true,
            checkDigitCtrlName: 'compositionGTINCheckDigit'
        })]);
        formattedCompositionGtin.updateValueAndValidity();
    }    
 

    getErrorMessage(control: FormControl, name: string) {
        for (let propertyName in control.errors) {
            if (control.errors.hasOwnProperty(propertyName) && control.touched) {
                return this.getValidatorErrorMessage(propertyName, control.errors[propertyName]);
            }
        }
        return null;
    } 

    getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            'required': 'This field is required.',
            'email': 'This is not a valid email',
            'invalid': 'This is not a valid value',
            'minlength': `This field should have atleast ${validatorValue.requiredLength} characters`,
            'beforePadding': 'This field is required.',
            'range': 'GTIN entered must be in range 000-00010-00000 to 999-99999-99999.',
            'type2': "GTIN entered is reserved for type -2 GTIN's.",
            'dummy': "GTIN entered is reserved for Dummy GTIN's.",
            'vendorCoupon': "GTIN entered is reserved for Vendor Coupons.",
            'checkDigitRequired': "GTIN Check digit is required to validate GTIN.",
            'checkDigit': 'GTIN is not valid for the entered check digit.',
            'pmdsinvalid': 'Item GTIN is not valid for the Created By  vendor user ',
            'CompositionGTINAlreadyExist': 'GTIN Already Exist',
            'CompositionGTINInvalidSubDept': 'Item does not match the existing Sub Department',
            'CompositionGTINInvalidItemType': 'GTIN does not match the existing Item Type',
            'CompositionItemCodeAlreadyExist': 'Item Code Already Exist',
            'CompositionItemCodeInvalidSubDept': 'Item does not match the existing Sub Department',
            'CompositionItemCodeInvalidItemType': 'Item does not match the existing Item Type'
        };
        return config[validatorName];
    }
    /* Events */
    public onCancel(): void {
        this.dialogRef.close();
    }
    public onAdd(): void {
        if (this.compositionItemFormGroup.invalid) {
            return this.showErrors();
        }
        //let additionalGTIN: IAdditionalGtinDto = (<any>Object).assign({}, this.compositionItemFormGroup.value);
         // buyerBIDDynamicFormGroup
         let shipperItemCompositionDto =  this.getShipperItemCompositionDto();
        this.getShipperItemCompositionDropdownSelectionData(shipperItemCompositionDto);
        shipperItemCompositionDto.subDepartment = this.subDepartment;
        shipperItemCompositionDto.subDepartmentID = this.subDepartmentID;
        shipperItemCompositionDto.compositionItemTypeCode = this.compositionItemTypeCode;
        shipperItemCompositionDto.rowId = this.shipperItemCompositionList.length + 1; 

        if (this.CheckGTINDuplicateAndSubDepartment(shipperItemCompositionDto)) {
            this.shipperItemCompositionList.push(shipperItemCompositionDto);
            this.data.shipperItemCompositionList = this.shipperItemCompositionList;
            this.dialogRef.close(shipperItemCompositionDto);
        }
    }

    public CheckGTINDuplicateAndSubDepartment(shipperItemCompositionDto: ShipperItemCompositionDto) :boolean {
        if (this.parentShipperItemCompositionList.some(Item => Item.formattedCompositionGtin == shipperItemCompositionDto.formattedCompositionGtin)) {
            console.log("Already Exist");
            this.compositionItemFormGroup.controls["formattedCompositionGtin"].setErrors({ CompositionGTINAlreadyExist: true });
            this.compositionItemFormGroup.controls["formattedCompositionGtin"].markAsTouched({ onlySelf: true });
            return false;
        }
        else if (this.parentShipperItemCompositionList.some(Item => Item.subDepartmentID != shipperItemCompositionDto.subDepartmentID)) {
            console.log("Cannot Add the because sub department is diffrent ");
            this.compositionItemFormGroup.controls["formattedCompositionGtin"].setErrors({ CompositionGTINInvalidSubDept: true });
            this.compositionItemFormGroup.controls["formattedCompositionGtin"].markAsTouched({ onlySelf: true });
            return false;
        }
        else if (this.parentShipperItemCompositionList.some(Item => Item.compositionItemTypeCode != shipperItemCompositionDto.compositionItemTypeCode)) {
            console.log("Cannot Add the because composition Item type is diffrent is diffrent ");
            this.compositionItemFormGroup.controls["formattedCompositionGtin"].setErrors({ CompositionGTINInvalidItemType: true });
            this.compositionItemFormGroup.controls["formattedCompositionGtin"].markAsTouched({ onlySelf: true });
            return false;
        }
        else
            return true;     

    }

    public CheckGTINDuplicateAndSubDepartmentByItemCode(shipperItemCompositionDto: ShipperItemCompositionDto): boolean {
        if (this.parentShipperItemCompositionList.some(Item => Item.formattedCompositionGtin == shipperItemCompositionDto.formattedCompositionGtin)) {
            console.log("Already Exist");
            this.compositionItemFormGroup.controls["compositionItemCode"].setErrors({ CompositionItemCodeAlreadyExist: true });
            this.compositionItemFormGroup.controls["compositionItemCode"].markAsTouched({ onlySelf: true });
            return false;
        }
        else if (this.parentShipperItemCompositionList.some(Item => Item.subDepartmentID != shipperItemCompositionDto.subDepartmentID)) {
            console.log("Cannot Add the because sub department is diffrent ");
            this.compositionItemFormGroup.controls["compositionItemCode"].setErrors({ CompositionItemCodeInvalidSubDept: true });
            this.compositionItemFormGroup.controls["compositionItemCode"].markAsTouched({ onlySelf: true });
            return false;
        }
        else if (this.parentShipperItemCompositionList.some(Item => Item.compositionItemTypeCode != shipperItemCompositionDto.compositionItemTypeCode)) {
            console.log("Cannot Add the because composition Item type is diffrent is diffrent ");
            this.compositionItemFormGroup.controls["compositionItemCode"].setErrors({ CompositionItemCodeInvalidItemType: true });
            this.compositionItemFormGroup.controls["compositionItemCode"].markAsTouched({ onlySelf: true });
            return false;
        }
        else
            return true;

    }

    public onAddContinue(): void {
        if (this.compositionItemFormGroup.invalid) {
            return this.showErrors();
        }
        let shipperItemCompositionDto =  this.getShipperItemCompositionDto();       
       this.getShipperItemCompositionDropdownSelectionData(shipperItemCompositionDto);
        shipperItemCompositionDto.rowId = this.shipperItemCompositionList.length + 1;
        shipperItemCompositionDto.subDepartment = this.subDepartment;
        shipperItemCompositionDto.subDepartmentID = this.subDepartmentID;
        shipperItemCompositionDto.compositionItemTypeCode = this.compositionItemTypeCode;
        if (this.CheckGTINDuplicateAndSubDepartment(shipperItemCompositionDto)) {
            this.shipperItemCompositionList.push(shipperItemCompositionDto);
            this.data.shipperItemCompositionList = this.shipperItemCompositionList;
            this.compositionItemFormGroup.reset();
            this.onAddEvent.emit(shipperItemCompositionDto);
            this.compositionItemFormGroup.reset();
        }
    }

    public getShipperItemCompositionDto() : ShipperItemCompositionDto {
        let shipperItemCompositionDto = new ShipperItemCompositionDto();
        shipperItemCompositionDto.compositionItemCode = this.compositionItemFormGroup.get("compositionItemCode").value;
        shipperItemCompositionDto.compositionItemDescription = this.compositionItemFormGroup.get("compositionItemDescription").value;
        shipperItemCompositionDto.formattedCompositionGtin = this.compositionItemFormGroup.get("formattedCompositionGtin").value;
        shipperItemCompositionDto.compositionGTINCheckDigit = this.compositionItemFormGroup.get("compositionGTINCheckDigit").value;         
        shipperItemCompositionDto.quantity = this.compositionItemFormGroup.get("quantity").value;
        //shipperItemCompositionDto.SubDepartment = this.compositionItemFormGroup.get("itemcode").value;
        shipperItemCompositionDto.compositionUOM = this.compositionItemFormGroup.get("compositionUOM").value;
        return shipperItemCompositionDto;
    }

    public onSave(): void {
        if (this.compositionItemFormGroup.invalid) {
            return this.showErrors();
        }
        let shipperItemCompositionDto =  this.getShipperItemCompositionDto();
        shipperItemCompositionDto.rowId = this.data.shipperItemCompositionRow.rowId;
        this.getShipperItemCompositionDropdownSelectionData(shipperItemCompositionDto);
        shipperItemCompositionDto.subDepartment = this.subDepartment;
        shipperItemCompositionDto.subDepartmentID = this.subDepartmentID;
        shipperItemCompositionDto.compositionItemTypeCode = this.compositionItemTypeCode;
        this.data.shipperItemCompositionRow = shipperItemCompositionDto;
        this.dialogRef.close(shipperItemCompositionDto);      
    }
    private showErrors(): void {
        Object.keys(this.compositionItemFormGroup.controls).forEach(field => {
            const control = this.compositionItemFormGroup.get(field);
            control.markAsTouched({ onlySelf: true });
        });
        return;
    }

    private getShipperItemCompositionDropdownSelectionData(shipperItemCompositionDto: IShipperItemCompositionDto): void {       

        if (shipperItemCompositionDto.compositionUOM) {
            const sizeUOMLookupDto = this.sizeUomList.find(x => x.code == shipperItemCompositionDto.compositionUOM);
            shipperItemCompositionDto.compositionUOMDescription = (sizeUOMLookupDto) ? sizeUOMLookupDto.description : shipperItemCompositionDto.compositionUOM;
       }

    }

    public validateShipperItemCompositionByItemCode(itemCode: number) {
        console.log("test");  
        let shipperCompositionItem: ShipperItemCompositionDto = new ShipperItemCompositionDto();

        shipperCompositionItem.compositionItemCode = itemCode.toString();
        shipperCompositionItem.createdByUserTypeID = this.createdByUserTypeID;
        shipperCompositionItem.itemFormID = this.newItemFormService.itemFormID;  

        this.shipperItemCompositionService.validateShipperItemCompositionByItemCode(shipperCompositionItem).subscribe(
            res => {
                console.log(res);
                if (res == null) {
                    //console.log("Invalid item code");
                    //this.errors.push("Invalid item code");
                    
                    this.compositionItemFormGroup.controls["compositionItemCode"].setErrors({ invalid: true });
                    this.compositionItemFormGroup.controls["compositionItemCode"].markAsTouched({ onlySelf: true });
                     //   this.showErrors();
                    
                }
                else {
                    if (this.CheckGTINDuplicateAndSubDepartmentByItemCode(res)) {
                        this.compositionItemFormGroup.patchValue({
                            formattedCompositionGtin: res.formattedCompositionGtin,
                            compositionGTINCheckDigit: res.compositionGTINCheckDigit,
                            compositionItemDescription: res.compositionItemDescription
                        });
                        this.subDepartmentID = res.subDepartmentID;
                        this.subDepartment = res.subDepartment;
                        this.compositionItemTypeCode = res.compositionItemTypeCode;
                    }
                    else {
                        //this.compositionItemFormGroup.controls["formattedCompositionGtin"].markAsTouched({ onlySelf: false });
                        this.showErrors();
                    }
                }

            }
        );

    }

    public validateShipperItemCompositionByGTIN(GTIN: string) {
        console.log("test");
        let shipperCompositionItem: ShipperItemCompositionDto = new ShipperItemCompositionDto();

        shipperCompositionItem.formattedCompositionGtin = GTIN;
        shipperCompositionItem.createdByUserTypeID = this.createdByUserTypeID;
        shipperCompositionItem.itemFormID = this.newItemFormService.itemFormID;
        
        this.shipperItemCompositionService.validateShipperItemCompositionByGTIN(shipperCompositionItem).subscribe(
            res => {
                console.log(res);
               
                if (res == null) {
                    this.compositionItemFormGroup.controls["formattedCompositionGtin"].setErrors({ pmdsinvalid: true });
                    this.compositionItemFormGroup.controls["formattedCompositionGtin"].markAsTouched({ onlySelf: true });
                    this.compositionItemFormGroup.patchValue({                       
                        compositionItemCode: '',                        
                        compositionItemDescription: ''
                    });
                }
                else {
                    if (this.CheckGTINDuplicateAndSubDepartment(res)) {
                        this.compositionItemFormGroup.patchValue({
                            formattedCompositionGtin: res.formattedCompositionGtin,
                            compositionItemCode: res.compositionItemCode,
                            compositionGTINCheckDigit: res.compositionGTINCheckDigit,
                            compositionItemDescription: res.compositionItemDescription
                        });
                        this.subDepartmentID = res.subDepartmentID;
                        this.subDepartment = res.subDepartment;
                        this.compositionItemTypeCode = res.compositionItemTypeCode;
                    }
                    else
                        this.showErrors();
                }

            }
        );

    }



    

    private handleValidationErrors(validationErrorDictionary: any[]) {
        for (var key in validationErrorDictionary) {
            let obj = validationErrorDictionary[key];
            let fieldName = obj.controlName;
            if (fieldName) {
                if (this.compositionItemFormGroup.controls[fieldName]) {
                    //integrate into angular's validation if we have field validation
                    this.compositionItemFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.compositionItemFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = obj.errorDescription;
                }
                else if (fieldName == "formattedCompositionGtin" || fieldName == "compositionGTINCheckDigit") {
                    this.compositionItemFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.compositionItemFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = obj.errorDescription;
                }
                else if (fieldName == "compositionItemCode") {
                    this.compositionItemFormGroup.controls[fieldName].setErrors({ invalid: true });
                    this.compositionItemFormGroup.controls[fieldName].markAsTouched({ onlySelf: true });
                    this.formErrors[fieldName] = obj.errorDescription;
                }
                else {
                    this.errors.push(obj.errorDescription);
                }
            }
        }
    }




}


