import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { APP_CONFIG, AppConfig } from '../../app.config';
import { IShipperItemCompositionDto, ShipperItemCompositionDto } from './shipper-item-composition.interface';
import { IItemSaveResponse } from '../../shared/common.interface';

@Injectable()
export class ShipperItemCompositionService {

    private baseUrl;
    private serviceBase: string = 'api/ShipperItemComposition/';


    constructor(@Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;       
    }

    getShipperCompositionItems(itemFormID: number): Observable<IShipperItemCompositionDto[]> {
        return this.httpClient.get<IShipperItemCompositionDto[]>(this.baseUrl + this.serviceBase + `GetShipperCompositionItems?ItemFormID=${itemFormID}`);
    }

    validateShipperItemCompositionByItemCode(shipperCompositionItem: IShipperItemCompositionDto): Observable<IShipperItemCompositionDto> {
        return this.httpClient.post<IShipperItemCompositionDto>(this.baseUrl + this.serviceBase + 'ValidateShipperItemCompositionByItemCode', shipperCompositionItem);
    }

    validateShipperItemCompositionByGTIN(shipperCompositionItem: ShipperItemCompositionDto): Observable<ShipperItemCompositionDto> {
        return this.httpClient.post<IShipperItemCompositionDto>(this.baseUrl + this.serviceBase + 'ValidateShipperItemCompositionByGTIN', shipperCompositionItem);
    }

    saveShipperItemCompositions(shipperCompositionList: IShipperItemCompositionDto[]): Observable<IItemSaveResponse>  {
        return this.httpClient.post <IItemSaveResponse>(this.baseUrl + this.serviceBase + 'SaveShipperItemCompositions', shipperCompositionList);
    }
    
}
