
import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import {
    MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatPaginatorModule, MatSort, MatPaginator,
    fadeInContent, transformMenu, MatSnackBar
} from '@angular/material';

//import { IReuseItemCodeDto, ReuseItemCodeDto, IAdditionalGtinDto, AdditionalGtinDto } from '../../basic-item-definition-interface';
import { GridEvent } from '../../shared/grid/grid-event';
import { IItemFormDto, ItemFormDto, NewItemTab, UserType, FormUserPermittedActionDto } from '../new-item-form.interface';
import { DialogCompositionItemComponent } from './dialog-composition-item.component';

import { ConfirmDialogComponent } from '../../shared/dialog/confirm-dialog.component' ;

import { NewItemFormService } from '../new-item-form.service';

import { ShipperItemCompositionService } from './shipper-item-composition.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

import { IShipperItemCompositionDto, ShipperItemCompositionDto } from './shipper-item-composition.interface';
import 'rxjs/add/operator/filter';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { catchError, tap, map } from 'rxjs/operators';

@Component({
  selector: 'ifw-shipper-item-composition-vendor',
  templateUrl: './shipper-item-composition-vendor.component.html',
  styleUrls: ['./shipper-item-composition-vendor.component.scss']
})
export class ShipperItemCompositionVendorComponent implements OnInit {


    // GRID
    public gridData: any[] = [];
    public pagination: boolean = false;
    public length: number;
    public pageSize: number = 5;
    public filterable: boolean = true;
    public filterBy: string = "";
    public filterValue: string = "";
    public sortable: boolean = true;
    public active: string = "";
    public direction: string = "";
    public ShowReuseItemCodeGrid = true;
    userId: any;    
    showShipperCompositionType: boolean;
    showBIDDetailExpectItemtype: boolean;

    errors: string[];
    formErrors: any;
    //popUpMessages: IErrorDTO[];
    //formErrors: any;
    skipSaveTab: boolean = false;
    createdByUserTypeID: number;

    shipperItemCompositionList: IShipperItemCompositionDto[];
    shipperItemCompositionDto: IShipperItemCompositionDto;
    public isReadOnly: boolean = false; 


    constructor(private _formBuilder: FormBuilder, 
        public snackBar: MatSnackBar,
        private router: Router,
        private route: ActivatedRoute,     
        public dialog: MatDialog,
        private shipperItemCompositionService: ShipperItemCompositionService,
        private newItemFormService: NewItemFormService) { }

  public itemFormDisplayID: number;

    private itemFormID: number;


    ngOnInit() {

        // this.route.queryParams
        //     .filter(params => params.id)
        //     .subscribe(params => {
        //         //  console.log(params); //  {id: "PGVSA1", role: "VPMD_VENDORPORTAL_VENDORSUPERADMIN"}             
        //         this.userId = params.id;

        //         console.log(this.userId); // PGVSA1
        //     });

        this.pagination = true;
        this.itemFormDisplayID = this.newItemFormService.itemFormDisplayID;
        this.newItemFormService.getItemFormData(this.itemFormDisplayID).subscribe(res => { this.createdByUserTypeID = res.createdByUserTypeID });
        this.itemFormID = this.newItemFormService.itemFormID;
        this.isReadOnly = this.newItemFormService.isReadOnly;
        this.LoadShipperItemCompositionList();
        //if (this.shipperItemCompositionList == undefined)
        //    this.shipperItemCompositionList = [];
        if(this.newItemFormService.currentUserType == UserType.Buyer)
            this.showShipperCompositionType = true;

        console.log(this.newItemFormService.currentUserType);
      
       
    }

   
  getShipperItemCompositionItems(gridEvent: GridEvent) {
        this.gridData = this.performFilter(gridEvent);
        this.sortData(gridEvent);
        this.pageData(gridEvent);
    }

    performFilter(gridEvent: GridEvent): any[] {
        this.filterBy = gridEvent.filterBy;
        this.filterValue = gridEvent.filterValue;
        if (this.filterBy && this.filterBy.length > 0) {
            if (this.filterValue && this.filterValue.length > 0) {
                console.log(this.filterValue);
                return this.shipperItemCompositionList.filter((row: any) => {
                    // Transform the data into a lowercase string of property values.
                    const dataStr = ('' + row[this.filterBy]).toLowerCase();
                    // Transform the filter by converting it to lowercase and removing whitespace.
                    const transformedFilter = this.filterValue.trim().toLowerCase();
                    return dataStr.indexOf(transformedFilter) != -1;
                }
                );
            }
            return this.shipperItemCompositionList.slice();
        }
        return this.shipperItemCompositionList.slice();
    }
    /**
     * sort the filtered result based on sort column and order
     */
    sortData(gridEvent: GridEvent) {
        this.active = gridEvent.active;
        this.direction = gridEvent.direction;
        let sortAsc = gridEvent.direction == 'asc';
        let sortDesc = gridEvent.direction == 'desc';
        if (!sortAsc && !sortDesc) return;
        this.gridData.sort((a, b) => {
            if (typeof a[gridEvent.active] === 'string') {
                return a[this.active].localeCompare(b[this.active]);
            } else {
                return a[this.active] - b[this.active];
            }
        });
        if (sortAsc === false) {
            this.gridData.reverse();
        }
    }
    /**
       * paginate the result set
       */
    pageData(gridEvent: GridEvent) {
        if (!this.pagination) return; // if pagination is false, just skip the slice of the page data.
        this.length = this.gridData.length;
        let pageIndex = gridEvent.pageIndex;
        this.pageSize = gridEvent.pageSize;
        let offset = pageIndex * gridEvent.pageSize;
        this.gridData = this.gridData.slice(offset, offset + gridEvent.pageSize);
    }

    getInitialShipperItemCompositionItems() {
        const gridEvent: GridEvent = {
            pageIndex: 0,
            pageSize: 5,
            length: 0,
            active: this.active,
            direction: this.direction,
            filterBy: this.filterBy,
            filterValue: this.filterValue
        };
        this.getShipperItemCompositionItems(gridEvent);
        this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
            const validations: any = this.newItemFormService.getItemValidation("Shipper Item Composition");
            if (validations) {
                  //this.handleShipperErrors();
            }
        });
    }

    LoadShipperItemCompositionList():void {
        this.shipperItemCompositionService.getShipperCompositionItems(this.itemFormID).subscribe(
            res => {
                this.shipperItemCompositionList = res;
                this.UpdateShipperItemCompositionRowId();
                this.getInitialShipperItemCompositionItems();
                this.showBIDDetailExpectItemtype = true;
                
                    }
        );
        // this.shipperItemCompositionList = [
        //     {"rowId" : 1, "itemCode": "522 -Motts Original", "itemGtin": "122-12345-12345 1", "quantity": 10, "UOM": "EA","SubDepartment": "Dry Grocery" },
        //     { "rowId": 2, "itemCode": "622 -Motts Original2", "itemGtin": "122-12345-12345 1", "quantity": 20, "UOM": "EA", "SubDepartment": "Dry Grocery" },
        //     { "rowId": 3, "itemCode": "722 -Motts Original3", "itemGtin": "122-12345-12345 1", "quantity": 30, "UOM": "EA", "SubDepartment": "Dry Grocery" },
        //     { "rowId": 4, "itemCode": "822 -Motts Original4", "itemGtin": "122-12345-12345 1", "quantity": 40, "UOM": "EA", "SubDepartment": "Dry Grocery" },
        //     { "rowId": 5, "itemCode": "922 -Motts Original5", "itemGtin": "122-12345-12345 1", "quantity": 50, "UOM": "EA", "SubDepartment": "Dry Grocery" },
        //     { "rowId": 6, "itemCode": "122 -Motts Original6", "itemGtin": "122-12345-12345 1", "quantity": 60, "UOM": "EA", "SubDepartment": "Dry Grocery" },
        //     { "rowId": 7, "itemCode": "322 -Motts Original7", "itemGtin": "122-12345-12345 1", "quantity": 70, "UOM": "EA", "SubDepartment": "Dry Grocery" }
        // ];
       
       
    
    }

    private UpdateShipperItemCompositionRowId() {
        let count: number = 1;
        if (this.shipperItemCompositionList != undefined) {
            for (let shipperItemComposition of this.shipperItemCompositionList) {
                shipperItemComposition.rowId = count++;
            }
        }
    }

    public reset(e) { }


    public AddShipperItemCompositionDialog(): void {

        console.log(this.dialog);
        let dialogRef = this.dialog.open(DialogCompositionItemComponent, {
            width: '800px',
            data: { parentShipperItemCompositionList: this.shipperItemCompositionList, isBuyer: false, createdByUserTypeID: this.createdByUserTypeID }
        });
        const sub = dialogRef.componentInstance.onAddEvent.subscribe((result) => {     
            this.shipperItemCompositionList.push(result);
            this.UpdateShipperItemCompositionRowId();
            this.getInitialShipperItemCompositionItems();
        });
        dialogRef.afterClosed().subscribe(result => {
            sub.unsubscribe();
            if (result) {
                if (this.shipperItemCompositionList.some(Item => Item.formattedCompositionGtin == result.formattedCompositionGtin))
                    console.log("Already Exist");
                if (this.shipperItemCompositionList.some(Item => Item.subDepartmentID != result.subDepartmentID))
                    console.log("Cannot Add the because sub department is diffrent ");
                this.shipperItemCompositionList.push(result);
                this.UpdateShipperItemCompositionRowId();
            }
            this.getInitialShipperItemCompositionItems();
            // console.log('The dialog was closed');
            // console.log(result);
             //if (result != undefined) {
             //    this.shipperItemCompositionList = (this.shipperItemCompositionList == undefined) ? [] : this.shipperItemCompositionList;
             //    //for (let shipperItemCompositionDto of result.shipperItemCompositionList) {
             //    //    this.shipperItemCompositionList.push(shipperItemCompositionDto);
             //    //}
             //    this.UpdateShipperItemCompositionRowId();
             //    this.getInitialShipperItemCompositionItems();
             //}


        });

        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
        });
    }

    
    public EditShipperItemCompositionDialog(rowId: number): void {

        let shipperItemCompositionRow: IShipperItemCompositionDto = this.shipperItemCompositionList.find(x => x.rowId == rowId);
        let dialogRef = this.dialog.open(DialogCompositionItemComponent, {
            width: '800px',
            data: { shipperItemCompositionList: this.shipperItemCompositionList, shipperItemCompositionRow: shipperItemCompositionRow, isBuyer: false }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result && result.rowId) {
                this.shipperItemCompositionList.splice(result.rowId-1,1,result)
                this.getInitialShipperItemCompositionItems();
            }
            console.log('The dialog was closed');
            console.log(result);
            // if (result != undefined) {
            //     for (let shipperItemCompositionDto of this.shipperItemCompositionList) {
            //         if (additionalGtinDto.formattedGtin == result.additionalGtinRow.formattedGtin) {
            //             additionalGtinDto = result.additionalGtinRow;
            //         }
            //     }
            //     this.getInitialAdditionalGtinData();
            // }
        });
    }

    public deleteShipperItemComposition(rowId: number): void {


        let data = {description:"Are you sure you want to delete addtional GTIN ?" ,actions: ["No","Yes"]}
        let dialogRef = this.dialog.open(ConfirmDialogComponent, {
            disableClose: true,
            width: '800px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result){
                var index = this.shipperItemCompositionList.findIndex(x => x.rowId == rowId);
                if (index > -1) {
                    this.shipperItemCompositionList.splice(index, 1);
                }
                this.getInitialShipperItemCompositionItems();
            }

        });

       
    }
    
    performAction(action: any) {
        switch (action.actionName) {
            case "Save":
                this.shipperItemCompositions(action.createdFormStatusID, action.actionID);
                break;
            case "Delete":
                this.deleteItemForm();
                break;
            case "Submit":
                this.SubmitshipperItemCompositions(action.createdFormStatusID, action.actionID);
                break;
        }
    }

    public shipperItemCompositions(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            console.log(res);
            if (res) {
                //this.handleItemValidations();
                //this.getBasicItemDefinitionData();
            }

        });
    }


    public SubmitshipperItemCompositions(createdFormStatusID: number, actionID: number): void {
        this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
            console.log(res);
            if (res) {
                this.snackBar.open("Submitted successfully.", null, {
                    duration: 500,
                    horizontalPosition: 'center',
                    verticalPosition: 'bottom',
                });
            }
            else {
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: 'center',
                    verticalPosition: 'bottom',
                });
            }

        });
    }


    saveTabObservable(createdFormStatusID: number, actionID: number): Observable<boolean> {
        if (this.skipSaveTab || this.isReadOnly) return of(true);
        //this.PopulateBasicItemDefinitionDTO();
        this.errors = [];
        console.log('Save Submitted!');

        //if createdFormStatusID is 0 (when changing tab) , send the currentstatus .
        createdFormStatusID = createdFormStatusID == undefined ? this.newItemFormService.formCurrentStatusID : createdFormStatusID;
        //this.shipperItemCompositionDto.formStatusID = createdFormStatusID;
        //this.shipperItemCompositionDto.formActionID = actionID;
        //this.shipperItemCompositionDto.createdBy = this.userId
        this.shipperItemCompositionList.forEach(item => { item.formStatusID = createdFormStatusID; item.formActionID = actionID; item.createdBy = this.userId; item.itemFormID = this.itemFormID; item.formattedCompositionGtin = item.formattedCompositionGtin.replace(/-/g, "") });
     
        //Get the user dropdown selection data
        //this.getBasicItemDefDropdownSelectionData();

        return this.shipperItemCompositionService.saveShipperItemCompositions(this.shipperItemCompositionList).pipe(
            map(res => {

                if(res.validation)
                    this.newItemFormService.addItemValidation(res.validation);      

                if(res.status)          
                    this.newItemFormService.formCurrentStatusID = createdFormStatusID;

                console.log('Changes Saved Successfully');

                //if (actionID)
                //    this.getInitialShipperItemCompositionItems();

                return res.status;
            }),
            catchError((err) => {
                if (err.status === 400) {
                    // handle validation error
                    this.newItemFormService.addItemValidation(err.error);
                    //this.handleItemValidations();
                    //let validationErrorDictionary = err.error;
                    //let validationErrorDictionary = err.error.modelState;
                    //this.handleBasicItemDefValidations(validationErrorDictionary);

                } else {
                    this.errors.push("Unhandled expection occured.");
                }

                window.scrollTo(0, 0);
                return of(false);
            })
        );
    }


    deleteItemForm() {

        let dialog = this.dialog.open(ConfirmDialogComponent);
        dialog.afterClosed().subscribe(option => {
            if (option && option === true) {
                this.newItemFormService.deleteItemForm().subscribe(res => {
                    if (res != undefined) {
                        if (res == true)
                            console.log('Deleted Successfully');
                        else
                            console.log('Delete Failed');
                    }
                    this.skipSaveTab = true;
                    this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" });
                },
                    (err) => {
                        if (err.status === 400) {
                            // handle validation error
                            //  let validationErrorDictionary = err.error.modelState;
                            //this.handleBasicItemDefValidations(err.error);
                        } else {
                            this.errors.push("Unhandled expection occured.");
                        }
                        window.scrollTo(0, 0);
                    })
                // TO DO: re-direct to dashboard to start the flow of New or existing item form


            }
        });
    }

    

}


