export class IShipperItemCompositionDto {
    rowId: number;
    itemFormID: number;
    compositionItemCode: string;
    compositionItemDescription: string;
    compositionItemTypeCode: string;
    formattedCompositionGtin: string;
    compositionGTINCheckDigit: Number;
    quantity: Number;
    compositionUOM: string;
    compositionUOMDescription: string;
    subDepartment: string;
    subDepartmentID: string;
    formActionID: number;
    formStatusID: number;
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;    
}

export class ShipperItemCompositionDto implements IShipperItemCompositionDto {
    rowId: number;
    itemFormID: number;
    compositionItemCode: string;
    compositionItemDescription: string;
    compositionItemTypeCode: string;
    formattedCompositionGtin: string;
    compositionGTINCheckDigit: Number;
    quantity: Number;
    compositionUOM: string;
    compositionUOMDescription: string;
    subDepartment: string;
    subDepartmentID: string; 
    formActionID: number;
    formStatusID: number; 
    createdByUserTypeID: number;
    createdBy: string;
    createdDate: Date;
    lastUpdatedBy: string;
    lastUpdatedDate: Date;
     
}

     

