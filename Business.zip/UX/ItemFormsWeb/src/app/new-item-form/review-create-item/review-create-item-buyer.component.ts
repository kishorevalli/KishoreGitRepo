import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { BasicItemDefinitionService } from '../basic-item-definition/basic-item-definition.service';
import { NewItemFormService } from '../new-item-form.service';
import { IBasicItemDefnitionDto, BasicItemDefnitionDto, IAdditionalGtinDto } from '../basic-item-definition/basic-item-definition-interface';
import { GeneralProductAttributesService } from '../general-product-attributes/general-product-attributes.service';
import { IGeneralProductAttributes, GeneralProductAttributes, INutritionalAllergenInfo, NutritionalAllergenInfo, INutritionalInfo, NutritionalInfo, INutritionalPanel, IDrugScheduleCode, IVariableWeightIndicator } from '../general-product-attributes/general-product-attributes.interface';
import { ShipperItemCompositionService } from '../shipper-item-composition/shipper-item-composition.service';
import { IShipperItemCompositionDto, ShipperItemCompositionDto } from '../shipper-item-composition/shipper-item-composition.interface';
import { UserType } from '../new-item-form.interface';
import { PackagingHierarchyService } from '../packaging-hierarchy/packaging-hierarchy.service';
import { IRetailPackType, ICaseCodeType, IOrderablePackLevel, IPackagingHierarchy, PackagingHierarchy, IWarehouseGtin, WarehouseGtin } from '../packaging-hierarchy/packaging-hierarchy.interface';
import { DsdAuthorizationRequestService } from '../dsd-authorization-request/dsd-authorization-request.service';
import { IVendorAuthorizationDto, VendorAuthorizationDto } from '../dsd-authorization-request/dsd-authorization-request.interface';
import { ProductGroupingService } from '../product-grouping/product-grouping.service';
import { IProductGroupingDto, ProductGroupingDto } from '../product-grouping/product-grouping.interface';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IProductAttribute, ProductAttribute } from '../product-attributes/product-attributes.interface';
import { ProductAttributesService } from '../product-attributes/product-attributes.service';
import { IScaleInfoDto, ScaleInfoDto } from '../scale-item-details/scale-item-details.interface';
import { ScaleItemDetailsBuyerService } from '../scale-item-details/scale-item-details-buyer.service';
import { IMarketingInfo, MarketingInfo, IFormComment } from '../marketing-support/marketing-support.interface';
import { MarketingSupportService } from '../marketing-support/marketing-support.service';
import { ReviewCreateItemService } from './review-create-item.service';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';

@Component({
    selector: 'ifw-review-create-item-buyer',
    templateUrl: './review-create-item-buyer.component.html',
    styleUrls: ['./review-create-item-buyer.component.scss']
})
export class ReviewCreateItemBuyerComponent implements OnInit {

    userId: any;
    itemFormDisplayId: number;
    itemFormID: number;
    public basicItemDefinitionDto: BasicItemDefnitionDto;
    public generalProductAttributes: IGeneralProductAttributes;
    public additionalGtinRows: IAdditionalGtinDto[];
    public shipperItemComposition: IShipperItemCompositionDto[];
    public showShipperCompositionType: boolean;
    public packagingHierarchies: IPackagingHierarchy[];
    public vendorAuthorizationList: IVendorAuthorizationDto[];
    public productGroupingList: IProductGroupingDto[]=[];
    public productGroupingModelList: IProductGroupingDto[] = [];
    public productAttributes: IProductAttribute[] = [];
    modelProductItemCode: number;
    modelPackagingItemCode: number;
    public scaleInfoDto: IScaleInfoDto = new ScaleInfoDto();
    public marketingInfo: IMarketingInfo = new MarketingInfo();
    public VendorFormComments: IFormComment[] = [];
    public BuyerFormComments: IFormComment[] = [];
    showSpinner: boolean = false;

    constructor(private router: Router,
        private route: ActivatedRoute,
        private basicItemDefService: BasicItemDefinitionService,
        public newItemFormService: NewItemFormService,
        private generalProductAttributesService: GeneralProductAttributesService,
        private shipperItemCompositionService: ShipperItemCompositionService,
        private packagingHierarchyService: PackagingHierarchyService,
        private dsdAuthorizationRequestService: DsdAuthorizationRequestService,
        private productGroupingService: ProductGroupingService,
        private productAttributesService: ProductAttributesService,
        private scaleItemDetailsBuyerService: ScaleItemDetailsBuyerService,
        private marketingSupportService: MarketingSupportService,
        private reviewCreateItemService: ReviewCreateItemService,
        public snackBar: MatSnackBar) { }
        

    ngOnInit() {
        this.route.queryParams
            .filter(params => params.id)
            .subscribe(params => {
                //  console.log(params); //  {id: "PGVSA1", role: "VPMD_VENDORPORTAL_VENDORSUPERADMIN"}             
                this.userId = params.id;

                console.log(this.userId); // PGVSA1

                this.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
            });

        this.basicItemDefinitionDto = new BasicItemDefnitionDto();
        this.generalProductAttributes = new GeneralProductAttributes();
        this.additionalGtinRows = [];
        this.shipperItemComposition = [];
        this.vendorAuthorizationList = [];
        this.showShipperCompositionType = false;
        this.getBasicItemDefinitionData();
        this.getGeneralProductAttributes();
        this.getShipperItemComposition();
        this.getPackaginghierarchy();
        this.getDsdAuthorizationRequest();
        this.modelProductItemCode = this.newItemFormService.modelProductItemcode;
        this.modelPackagingItemCode = this.newItemFormService.modelPackagingItemCode;
        this.getProductGrouping();
        this.getProductAttributes();
        this.getScaleInfo();
        this.getMarketingSupport();
        this.GetFormComment();
    }


    private getBasicItemDefinitionData() {

        this.itemFormDisplayId = this.newItemFormService.itemFormDisplayID;
        this.itemFormID = this.newItemFormService.itemFormID;

        this.basicItemDefService.getBasicItemDefinitionData(this.itemFormID).subscribe(res => {
            if (res != undefined) {

                this.basicItemDefinitionDto = res;
                this.additionalGtinRows = res.addtionalGtinList;
            }
        });

    }

    private getGeneralProductAttributes() {
        this.itemFormID = this.newItemFormService.itemFormID;
        this.generalProductAttributesService.GetGeneralProductAttributes(this.itemFormID).subscribe(res => {
            if (res != undefined) {
                this.generalProductAttributes = res;
            }
        }, (err) => {
            var error = err;
        });

    }

    private getShipperItemComposition() {
        if (this.newItemFormService.currentUserType == UserType.Buyer) {
            this.showShipperCompositionType = true;
        }
        let itemFormId = this.newItemFormService.itemFormID;
        this.shipperItemCompositionService.getShipperCompositionItems(itemFormId).subscribe(res => {
            this.shipperItemComposition = res;
        }, (err)=>{var error = err });
    }

    private getPackaginghierarchy() {
        let itemFormId = this.newItemFormService.itemFormID;
        this.packagingHierarchyService.getPackagingHierarchies(itemFormId).subscribe(res => {
            if (res != undefined) {
                this.packagingHierarchies = res;
            }
        }, (err) => {
        });

    }

    private getDsdAuthorizationRequest() {
        let itemFormId = this.newItemFormService.itemFormID;
        this.dsdAuthorizationRequestService.getDsdVendorAuthorizations(itemFormId).subscribe(res => {
            if (res != undefined) {
                this.vendorAuthorizationList = res;
            }
        }, (err) => { });
    }

    private getProductGrouping() {
        let itemFormId = this.newItemFormService.itemFormID;
        
        this.productGroupingService.GetProductGrouping(itemFormId).subscribe(res => {
            if (res != undefined) {
                this.productGroupingList = res;
            }
        }, (err) => { });
            
    }
    hasChild = (_rowData: IProductGroupingDto) => { return (_rowData.parents && (_rowData.parents).length > 0); };

    private getProductAttributes() {
        let itemFormId = this.newItemFormService.itemFormID;
        this.productAttributesService.getProductAttributes(itemFormId).subscribe(res => {
            if (res != undefined) {
                this.productAttributes = res;
            }
        }, (err) => { });

    }

    private getScaleInfo() {
        let itemFormId = this.newItemFormService.itemFormID;
        this.scaleItemDetailsBuyerService.getScaleInfo(itemFormId).subscribe(res => {
            if (res != undefined) {
                this.scaleInfoDto = res;
            }
        }, (err) => { });
    }

    private getMarketingSupport() {
        let itemFormId = this.newItemFormService.itemFormID;
        this.marketingSupportService.GetMarketingInfo(itemFormId).subscribe(res => {
            if (res != undefined) {
                this.marketingInfo = res;
            }
        }, (err) => { });

    }

    GetFormComment() {
        this.marketingSupportService.GetFormComment(this.itemFormID).subscribe(res => {
          this.VendorFormComments = res.filter(item => item.createdByUserTypeID === 1);
          this.BuyerFormComments = res.filter(item => item.createdByUserTypeID !== 1);
        },
        (err) => {
        });
      }
    performAction(action: any) {
        switch (action.actionName) {           
            case "Create Item":
                this.CreateItem(action.createdFormStatusID, action.actionID);
                break;
        }
    }


    public CreateItem(createdFormStatusID: number, actionID: number): void {
        this.reviewCreateItemService.createItem(this.itemFormID).subscribe(res => {
            this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
               
            });
            if (res.status) {
                this.snackBar.open("Submitted successfully.", null, {
                    duration: 500,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
            else {
                this.snackBar.open("Submit failed.", null, {
                    duration: 3000,
                    horizontalPosition: this.horizontalPosition,
                    verticalPosition: 'bottom',
                });
            }
        });
    }

    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

        //this.saveTabObservable(createdFormStatusID, actionID).subscribe(res => {
        //    this.newItemFormService.GetItemFormErrors(this.itemFormID).subscribe(res => {
        //        this.GetGeneralProductAttributes(this.itemFormID, true);
        //    });
        //    if (res) {
        //        this.snackBar.open("Submitted successfully.", null, {
        //            duration: 500,
        //            horizontalPosition: this.horizontalPosition,
        //            verticalPosition: 'bottom',
        //        });
        //    }
        //    else {
        //        this.snackBar.open("Submit failed.", null, {
        //            duration: 3000,
        //            horizontalPosition: this.horizontalPosition,
        //            verticalPosition: 'bottom',
        //        });
        //    }
        //});
 //   }

}
