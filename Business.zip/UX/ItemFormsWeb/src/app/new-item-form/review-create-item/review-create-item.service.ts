import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ILookupDto, LookupDto, IItemSaveResponse } from '../../shared/common.interface';
import { APP_CONFIG, AppConfig } from '../../app.config';

@Injectable()
export class ReviewCreateItemService {

    private baseUrl;
    private serviceBase: string = 'api/ReviewCreateItem/';
    //public vendorDomainList: IVendorDomain[];

    constructor(@Inject(APP_CONFIG) config: AppConfig,
        private httpClient: HttpClient) {
        this.baseUrl = config.apiEndpoint;
    }

    createItem(itemFormId: number): Observable<IItemSaveResponse> {
        //let url = `CreateItem/${itemFormId}`;
        //if (formStatusID && formActionID) {
        //    url = url + `/${formStatusID}/${formActionID}`;

            return this.httpClient.get<IItemSaveResponse>(this.baseUrl + this.serviceBase + `CreateItem?itemFormId=${itemFormId}`);           
    }


    //SaveProductGrouping(productGroupingList: IProductGroupingDto[], itemFormID: number, formStatusID?: number, formActionID?: number): Observable<IItemSaveResponse> {
    //    let url = `SaveProductGrouping/${itemFormID}`;
    //    if (formStatusID && formActionID) {
    //        url = url + `/${formStatusID}/${formActionID}`;
    //    }
    //    return this.httpClient.post<IItemSaveResponse>(this.baseUrl + this.serviceBase + url, productGroupingList);
    //}
}
