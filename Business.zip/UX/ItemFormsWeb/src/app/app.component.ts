import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
    selector: 'ifw-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent {
    title = 'ifw';
       
    //let vsa : string = "PGVSA1,PGVSA2,LBVSA1,LBVSA2,TOLVSA1,ABCVSA1,KFVSA1,KFVSA2";
    //let VU = "PGVU1,PGVU2,PGVU3,PGVU4,PGVU5,PGVU6,LBVU1,LBVU2,LBVU3,LBVU4,LBVU5,LBVU6,TOLVU1,TOLVU2,TOLVU3,TOLVU4,TOLVU5,TOLVU6,ABCVU1,ABCVU2,ABCVU3,ABCVU4,ABCVU5,ABCVU6,BFBVU1,BFBVU2,BFBVU3,BFBVU4,BFBVU5,BFBVU6,BFBVU7,CMVU1,CMVU2,CMVU3,CMVU4,CMVU5,CMVU6,KFVU1,KFVU2,KFVU3,KFVU4,BP007RX,BP007S3,BP007RW,BP007S8,BP007S9";
    //let VUA = "BFBVUA1,CMVUA1,CMVUA2";
    //BDD = "XSLM,XTGS,XWGT,XDGB,XCPH,XRHM1,XJKP,XCPH,XDJM1,XDGB,XSLM,XWGT";
    //CM = "XHMF,XLAR1,XWAB,XBHL,XSJO,XLJK1,XMLF2,XLJK1,XLAR1,XSJO,XBXS,XTKC,XHMF,XGAP,XJHG,XMJO,XMAP,XGAB1,XJTL1,XJDR2,XCHF";
    //Buyer = "XALP1,XCDK,XCHS,XCMT,XCTG,XDLL1,XAEB2,XALP1,XJDO,XRAB4,XJRM,XRAB4,XSLL2,XTBE,XJSK,XMPD,XRRC,XRRC2,XRSQ,XSSG,XJRG4,XKWR,XJGO,XDLM,XKLM,XRCS,XCMS2,XWCM,XLJS,XMEP,XPBW,XJST,XKXB1,XTJM,XSKH1,XKLR3,XADH,XKAV1,XEEE,XJHK,XMLB1";
    //Support = "PMNR,PCDT";
    //Clerical = "XAAH1,XADK2,XADO,XALC1,XAMH5,XAMR1,XARL,XARW1";
    //VSA_KFC = "BP00VVW,BP00UVX";
    //VU_KFC = "BP00UVC,BP00UVD,BP00UVE,BP00UVF";
    //VUA_KFC = "BP00UVY,BP00UVZ";
    //IU_KFC = "P9435484,P9435485";
    //CORW_KFC = "P9435494,P9435495";
    //CORO_KFC = "P9435496,P9435497";
    //Support_KFC = "P9435490,P9435491";
    //Clerical_KFC = "P9435492,P9435493";


    // roles: any = [
    //     { name: "VPMD_VENDORPORTAL_VENDORSUPERADMIN", users: GetUserList("VSA - ", VSA).concat(GetUserList("VSA_KFC - ", VSA_KFC)) },
    //    { name: "VPMD_VENDORPORTAL_VENDORUSER", users: GetUserList("VU - ", VU).concat(GetUserList("VU_KFC - ", VU_KFC)) },
    //    { name: "VPMD_VENDORPORTAL_VENDORUSERADMIN", users: GetUserList("VUA - ", VUA).concat(GetUserList("VUA_KFC - ", VUA_KFC)) },
    //    { name: "VPMD_VENDORPORTAL_MFRCOUPON_RW", users: GetUserList("BDD - ", BDD).concat(GetUserList("CM - ", CM)).concat(GetUserList("Buyer - ", Buyer)).concat(GetUserList("CORW_KFC - ", CORW_KFC)) },
    //    { name: "VPMD_VENDORPORTAL_MFRCOUPON_RO", users: GetUserList("CORO_KFC - ", CORO_KFC) },
    //    { name: "VPMD_VENDORPORTAL_SYSTEMSUPPORT", users: GetUserList("Support - ", Support).concat(GetUserList("Support_KFC - ", Support_KFC)) },
    //    { name: "VPMD_VENDORPORTAL_CLERICAL", users: GetUserList("Clerical - ", Clerical).concat(GetUserList("Clerical_KFC - ", Clerical_KFC)) }
    //    ]

    //    function GetUserList(prefix, users) : any{
    //        let userArr = users.split(",");
    //        let returnArr = [];
    //        for (let user of userArr) { returnArr.push({ user: user, displayName: prefix + user }); }

    //        return returnArr;
    //    }

     roles : any = [
        { value: 'steak-0', viewValue: 'Steak' },
        { value: 'pizza-1', viewValue: 'Pizza' },
        { value: 'tacos-2', viewValue: 'Tacos' }
    ];

}
