import { BrowserModule } from '@angular/platform-browser';
import { NgModule  } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { CoreModule } from './core/core.module';

import { AppComponent } from './app.component';


import { LoginComponent } from './login/login.component';
import { SharedModule } from './shared/shared.module';
import { FormsModule } from '@angular/forms';
import { DashboardModule } from './Dashboard/dashboard.module';
import { APP_CONFIG, IFW_DI_CONFIG }    from './app.config';
import { DialogContentComponent } from './new-item-form/basic-item-definition/dialog-content.component';

import { DialogVendorOrgSearchComponent } from './new-item-form/common/dialogs/dialog-vendor-org-search.component';



@NgModule({
  declarations: [
    AppComponent,
   LoginComponent,
   DialogContentComponent,
   DialogVendorOrgSearchComponent   
  ],
  imports: [
      BrowserModule,
    AppRoutingModule,
      CoreModule,
      SharedModule,
    FormsModule,
    DashboardModule

  ],
  entryComponents: [ 
    DialogContentComponent,
    DialogVendorOrgSearchComponent
  ],
  providers: [{ provide: APP_CONFIG, useValue: IFW_DI_CONFIG }],
    bootstrap: [AppComponent]
})
export class AppModule { }

