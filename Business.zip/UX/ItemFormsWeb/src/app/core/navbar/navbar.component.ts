import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { NewItemFormService } from '../../new-item-form/new-item-form.service';
    

@Component({
  selector: 'ifw-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
}) 
export class NavbarComponent implements OnInit {
  public userName: string;
  public logoutUri: string;
  public isAuthenticated : boolean = false;
  public isExternal: boolean = false;
  constructor(private auth: AuthService,
      private router: Router,
      private newItemFormService: NewItemFormService,) { }

  ngOnInit() {
    this.auth.userName$.subscribe(currentUser => {
        this.userName = currentUser;
        this.newItemFormService.loggedInUser = currentUser;
        this.isAuthenticated = true;
        this.isExternal = this.auth.isExternal;
    });
    this.auth.getNavigationUri().subscribe(res => {
      this.logoutUri = res;
    });
  }

  logout() {
    if(this.logoutUri && this.logoutUri.length > 0){
      window.location.href = this.logoutUri;
    }
  }
  navigateTodashboard() {
    this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" } );
  }
  navigateTocategoryReviewReport() {
    this.router.navigate(['/category-review-report'], { queryParamsHandling: "merge" } );
  }

}
