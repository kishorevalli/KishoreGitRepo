import { Injectable, Inject } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { APP_CONFIG, AppConfig } from '../../app.config';


@Injectable()
export class AuthService {
    private baseUrl: string; 
    private serviceBase: string = 'api/Common/';
    public currentUser: string = "";
    public isExternal: boolean = false;
    public userType: number = 0;
    public logoutUri: string;
    userName$: Subject<string> = new Subject<string>();
    constructor(@Inject(APP_CONFIG) config: AppConfig,
                private httpClient: HttpClient,
                private router: Router) { 
           this.baseUrl = config.apiEndpoint;
    }
    getAuthData(): Observable<boolean> {     
        return this.httpClient.get<any>(this.baseUrl + this.serviceBase + 'GetAuthData').pipe(
            map(res => {
                if(res){
                    this.currentUser = res.currentUser;
                    this.isExternal = res.isExternal; 
                    this.userType = res.userType; 
                    this.userName$.next(res.currentUser);
                    return true;
                }
                return false;
            }),
            catchError((err) => {
                if (this.logoutUri && this.logoutUri.length > 0) {
                    window.location.href = this.logoutUri;
                    return of(false);
                }
                else if(err.error && err.error.redirectUri && err.error.redirectUri.length > 0){
                    window.location.href = err.error.redirectUri;
                    return of(false);
                }
                else {
                    this.router.navigate(['/login'], { queryParamsHandling: "merge" });
                    return of(false);
                }
            })
        );
    }
    getNavigationUri(): Observable<string> {
        return this.httpClient.get<string>(this.baseUrl + this.serviceBase + 'getNavigationUri').pipe(
            map(res => {
                this.logoutUri = res;
                return res;
            }),
            catchError((err) => {               
                return of('');
            })
        );
    }
}