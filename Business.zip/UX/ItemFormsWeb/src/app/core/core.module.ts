import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { SharedModule } from '../shared/shared.module';

//Components
import { NavbarComponent } from './navbar/navbar.component';
import { AuthService } from '../core/services/auth.service';

@NgModule({
  imports: [
      RouterModule,
      HttpClientModule,
      NoopAnimationsModule,
      SharedModule
    ],
    exports: [
        HttpClientModule,
        NoopAnimationsModule,
        NavbarComponent
    ],
  declarations: [NavbarComponent],
   providers: [
    AuthService
    ]
})
export class CoreModule { }
