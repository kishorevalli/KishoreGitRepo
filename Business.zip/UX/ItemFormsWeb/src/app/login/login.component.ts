﻿import { Component, EventEmitter, OnInit, Output, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
    selector: 'ifw-login',
    templateUrl: './login.html',
     
})

export class LoginComponent {
    selectedRole: any;
    usersForRole: any[];
    selectedUser;
    test;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
      
      ) {}

        VSA : string = "PGVSA1,PGVSA2,LBVSA1,LBVSA2,TOLVSA1,ABCVSA1,KFVSA1,KFVSA2";
        VU = "PGVU1,PGVU2,PGVU3,PGVU4,PGVU5,PGVU6,LBVU1,LBVU2,LBVU3,LBVU4,LBVU5,LBVU6,TOLVU1,TOLVU2,TOLVU3,TOLVU4,TOLVU5,TOLVU6,ABCVU1,ABCVU2,ABCVU3,ABCVU4,ABCVU5,ABCVU6,BFBVU1,BFBVU2,BFBVU3,BFBVU4,BFBVU5,BFBVU6,BFBVU7,CMVU1,CMVU2,CMVU3,CMVU4,CMVU5,CMVU6,KFVU1,KFVU2,KFVU3,KFVU4,BP007RX,BP007S3,BP007RW,BP007S8,BP007S9";
        VUA = "BFBVUA1,CMVUA1,CMVUA2";
        BDD = "XSLM,XTGS,XWGT,XDGB,XCPH,XRHM1,XJKP,XCPH,XDJM1,XDGB,XSLM,XWGT";
        CM = "XHMF,XLAR1,XWAB,XBHL,XSJO,XLJK1,XMLF2,XLJK1,XLAR1,XSJO,XBXS,XTKC,XHMF,XGAP,XJHG,XMJO,XMAP,XGAB1,XJTL1,XJDR2,XCHF";
        Buyer = "XALP1,XCDK,XCHS,XCMT,XCTG,XDLL1,XAEB2,XALP1,XJDO,XRAB4,XJRM,XRAB4,XSLL2,XTBE,XJSK,XMPD,XRRC,XRRC2,XRSQ,XSSG,XJRG4,XKWR,XJGO,XDLM,XKLM,XRCS,XCMS2,XWCM,XLJS,XMEP,XPBW,XJST,XKXB1,XTJM,XSKH1,XKLR3,XADH,XKAV1,XEEE,XJHK,XMLB1";
        Support = "PMNR,PCDT";
        Clerical = "XAAH1,XADK2,XADO,XALC1,XAMH5,XAMR1,XARL,XARW1";
        VSA_KFC = "BP00VVW,BP00UVX";
        VU_KFC = "BP00UVC,BP00UVD,BP00UVE,BP00UVF";
        VUA_KFC = "BP00UVY,BP00UVZ";
        IU_KFC = "P9435484,P9435485";
        CORW_KFC = "P9435494,P9435495";
        CORO_KFC = "P9435496,P9435497";
        Support_KFC = "P9435490,P9435491";
    Clerical_KFC = "P9435492,P9435493";



    

    roles: any = [
        { name: 'VPMD_VENDORPORTAL_VENDORSUPERADMIN' },
        { name: 'VPMD_VENDORPORTAL_VENDORUSER' },
        { name: 'VPMD_VENDORPORTAL_ITEMFORM_RW' },
        { name: 'VPMD_VENDORPORTAL_ITEMFORM_MFGBDD'}
    ]


    users = [       
        { name: 'YBPVUA01', role: 'VPMD_VENDORPORTAL_VENDORUSERADMIN' },
        { name: 'YBPVUA02', role: 'VPMD_VENDORPORTAL_VENDORUSERADMIN' },
        { name: 'PGVU1', role: 'VPMD_VENDORPORTAL_VENDORUSER' },
        { name: 'YBPVU01', role: 'VPMD_VENDORPORTAL_VENDORUSER' },
        { name: 'YBPVU02', role: 'VPMD_VENDORPORTAL_VENDORUSER' },
        { name: 'YBPVU03', role: 'VPMD_VENDORPORTAL_VENDORUSER' },
        { name: 'PGVSA1', role: 'VPMD_VENDORPORTAL_VENDORSUPERADMIN' },
        { name: 'YBPVSA02', role: 'VPMD_VENDORPORTAL_VENDORSUPERADMIN' },
        { name: 'YBPVSA03', role: 'VPMD_VENDORPORTAL_VENDORSUPERADMIN' },
        { name: 'YBPVSA01', role: 'VPMD_VENDORPORTAL_VENDORSUPERADMIN' },
        { name: 'XALP1', role: 'VPMD_VENDORPORTAL_ITEMFORM_RW' },
        { name: 'YVPBUY15', role: 'VPMD_VENDORPORTAL_ITEMFORM_RW' },
        { name: 'YVPBUY01', role: 'VPMD_VENDORPORTAL_ITEMFORM_RW' },
        { name: 'YVPBUY02', role: 'VPMD_VENDORPORTAL_ITEMFORM_RW' },
        { name: 'PGMFG1', role: 'VPMD_VENDORPORTAL_ITEMFORM_MFGBDD' }
       
    ];

            // roles: any = [
            //     { name: "VPMD_VENDORPORTAL_VENDORSUPERADMIN", users: this.GetUserList("VSA - ", this.VSA).concat(this.GetUserList("VSA_KFC - ", this.VSA_KFC)) },
            //     { name: "VPMD_VENDORPORTAL_VENDORUSER", users: this.GetUserList("VU - ", this.VU).concat(this.GetUserList("VU_KFC - ", this.VU_KFC)) },
            //     { name: "VPMD_VENDORPORTAL_VENDORUSERADMIN", users: this.GetUserList("VUA - ", this.VUA).concat(this.GetUserList("VUA_KFC - ", this.VUA_KFC)) },
            //     { name: "VPMD_VENDORPORTAL_MFRCOUPON_RW", users: this.GetUserList("BDD - ", this.BDD).concat(this.GetUserList("CM - ", this.CM)).concat(this.GetUserList("Buyer - ", this.Buyer)).concat(this.GetUserList("CORW_KFC - ", this.CORW_KFC)) },
            //     { name: "VPMD_VENDORPORTAL_MFRCOUPON_RO", users: this.GetUserList("CORO_KFC - ", this.CORO_KFC) },
            //     { name: "VPMD_VENDORPORTAL_SYSTEMSUPPORT", users: this.GetUserList("Support - ", this.Support).concat(this.GetUserList("Support_KFC - ", this.Support_KFC)) },
            //     { name: "VPMD_VENDORPORTAL_CLERICAL", users: this.GetUserList("Clerical - ", this.Clerical).concat(this.GetUserList("Clerical_KFC - ", this.Clerical_KFC)) }
            //]
            ngOnInit() {
                this.route.queryParams
                    .filter(params => params.id, params => params.role)
                    .subscribe(params => {
                        //   console.log(params); //  {id: "PGVSA1", role: "VPMD_VENDORPORTAL_VENDORSUPERADMIN"}
                        this.router.navigate(['/dashboard'], { queryParamsHandling: "merge" } );
                    });
               
            }
            loginUser() {
                //alert(this.selectedRole);
                //alert(this.selectedUser);
                //this.router.navigate(['/dashboard']);
                //this.router.navigate(['/dashboard', { id: this.selectedUser}]);
              //  this.router.navigate(['/dashboard', { id: this.selectedUser, role: this.selectedRole}]);
                this.router.navigate(['/login'], { queryParams: { id: this.selectedUser, role: this.selectedRole}, queryParamsHandling: "merge" } );
               // this.router.navigate(['/dashboard'], { queryParams: { id: this.selectedUser, role: this.selectedRole}, queryParamsHandling: "merge" } );

                //{ id: this.selectedUser}]

               // $window.location.href = "Index.html?id=" + this.selectedUser + "&role=" + this.selectedRole;
                    }
                
                    roleChanged(role) {    
                        this.usersForRole = this.users.filter(u => u.role == role);
                        //alert(role);
                        }

             GetUserList(prefix:string, users:string) : any{
                let userArr = users.split(',');
                let returnArr = [];
                for (let user of userArr) { returnArr.push({ user: user, displayName: prefix + user }); }

                return returnArr;
    }
    
}