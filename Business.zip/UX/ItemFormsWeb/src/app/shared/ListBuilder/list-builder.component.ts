import { Component, Inject, Input, ElementRef, OnInit, EventEmitter, Output } from '@angular/core';
import { MatDialog, MatSnackBar, MatSnackBarRef, SimpleSnackBar } from '@angular/material';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';


@Component({
    moduleId: module.id,
    selector: 'list-builder',
    templateUrl: './list-builder.component.html',
    styleUrls: ['list-builder.component.scss'],
    providers: [      
    ]
})

export class ListBuilderComponent implements OnInit {
    public fullList: any[] = [];

    @Input() fromListHeader: string = '';
    @Input() toListHeader: string = '';
    @Input() fromList: any[] = [];
    @Input() toList: any[] = [];
    @Output() toListChange = new EventEmitter<any[]>();
    @Output() fromListChange = new EventEmitter<any[]>();

  
    constructor(private fb: FormBuilder, private snackBar: MatSnackBar
    ) {
       
    }

    /**  INITIALIZATION  **/
    /**
    */
    ngOnInit() {
        this.fullList = this.fromList;
    }
        
    showSelected: boolean;
    setRowEdit: boolean;

    rowsL: Array<any> = [];
    rowsR: Array<any> = [];
   

    emitToListChanged() {
        this.toListChange.emit(this.toList);
    }

    emitFromListChanged() {
        this.fromListChange.emit(this.fromList);
    }


    includeAll() {      
        if (this.fromList.length !== 0) {
            if (this.toList.length === 0) {
                this.toList = this.fromList;
            }
            else {
                for (var i = this.fromList.length; i--;) {
                    this.toList.push(this.fromList[i]);
                }
            }
            this.fromList = [];
            this.rowsL = [];
            this.emitToListChanged();
            this.emitFromListChanged();
        }
    }


    excludeAll() {
        if (this.toList.length !== 0) {
            if (this.fromList.length === 0) {
                this.fromList = this.toList;
            }
            else {
                for (var i = this.toList.length; i--;) {
                    this.fromList.push(this.toList[i]);
                }
            }            
            this.toList = [];
            this.rowsR = [];
            this.emitToListChanged();
            this.emitFromListChanged();
        }
    }

    include(rowsL) {
        
        for (var j = rowsL.length; j--;) {
            for (var i = this.fromList.length; i--;) {
                if (this.fromList[i] === rowsL[j]) {
                    this.toList.push(rowsL[j]);
                    this.fromList.splice(i, 1);
                }
            }
        }
        this.rowsL = [];
        this.emitToListChanged();
        this.emitFromListChanged();
    }

    exclude(rowsR) {
        
        for (var j = rowsR.length; j--;) {
            for (var i = this.toList.length; i--;) {
                if (this.toList[i] === rowsR[j]) {
                    this.fromList.push(rowsR[j]);
                    this.toList.splice(i, 1);
                }
            }
        }
        this.rowsR = [];
        this.emitToListChanged();
        this.emitFromListChanged();
    }

    createLRow(value: string, checked:boolean) {
        if (this.rowsL.indexOf(value) !== -1) {
            this.rowsL.splice(this.rowsL.indexOf(value), 1);
        }
        if(checked) {
            this.rowsL.push(value);
        }
    }

    createRRow(value: string, checked:boolean) {
        if (this.rowsR.indexOf(value) !== -1) {
            this.rowsR.splice(this.rowsR.indexOf(value), 1);
        }  
        if(checked)  {
            this.rowsR.push(value);
        }
    }
        
    openSnackBar(message: string, action: string): MatSnackBarRef<SimpleSnackBar> {
        return this.snackBar.open(message, action, {
            duration: 5000,
        });
    }
}

