import { Component } from '@angular/core';

@Component({
    template: `
    <h1 style="color:red">401 Unauthorized!</h1>
    `
})
export class PageNotAuthorizedComponent { }
