import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from './app-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { GridModule } from './grid/grid.module';
import { InputMaskModule } from './mask/input-mask.module';
import { DialogModule } from './dialog/dialog.module';
import { PageNotFoundComponent } from './page-not-found.component';
import { PageNotAuthorizedComponent } from './page-not-authorized.component';
import { DualListboxModule } from './dual-listbox/dual-listbox.module';



@NgModule({
  imports: [
    CommonModule,   
  ],
  declarations: [
    PageNotFoundComponent,
    PageNotAuthorizedComponent
  ],
  exports: [ 
    CommonModule,
    AppMaterialModule,
    ReactiveFormsModule,
    FormsModule,
      FlexLayoutModule,
      GridModule,
      InputMaskModule,
      DialogModule,
      DualListboxModule
  ]
})
export class SharedModule { }
