import { Component } from '@angular/core';

@Component({
    template: `
    <h1>This is still under construction!</h1>
    `
})
export class PageNotFoundComponent { }
