//import { Component, OnInit, Output, Input, EventEmitter, ViewEncapsulation } from '@angular/core';
//import * as _ from 'lodash';

import { Component, Inject, Input, ElementRef, OnInit, EventEmitter, Output } from '@angular/core';
import { MatDialog, MatSnackBar, MatSnackBarRef, SimpleSnackBar } from '@angular/material';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';

@Component({
    selector: 'ifw-dual-listbox',
    templateUrl: './dual-listbox.component.html',
    styleUrls: ['./dual-listbox.component.scss']
})
export class DualListboxComponent implements OnInit{

    public fullList: any[] = [];

    @Input() fromListHeader: string = '';
    @Input() toListHeader: string = '';
    @Input() fromList: any[] = [];
    @Input() toList: any[] = [];  
    @Input() descProperty: string = 'description';
    @Input() idProperty: string = 'id';
    @Input() showIdInDescription: boolean = false;
    @Output() toListChange = new EventEmitter<any[]>();
    @Output() fromListChange = new EventEmitter<any[]>();


    constructor(private fb: FormBuilder, private snackBar: MatSnackBar
    ) {

    }

    /**  INITIALIZATION  **/
    /**
    */
    ngOnInit() {
        this.fullList = this.fromList;
    }

    showSelected: boolean;
    setRowEdit: boolean;

    rowsL: Array<any> = [];
    rowsR: Array<any> = [];


    emitToListChanged() {
        
        this.toListChange.emit(this.toList);
    }

    emitFromListChanged() {        
        this.fromListChange.emit(this.fromList);
    }


    includeAll() {
        if (this.fromList.length !== 0) {
            if (this.toList.length === 0) {
                this.toList = this.fromList;
            }
            else {
                for (var i = this.fromList.length; i--;) {
                    this.toList.push(this.fromList[i]);
                }
            }
          
            this.fromList = [];
            this.rowsL = [];
            this.emitToListChanged();
            this.emitFromListChanged();
        }
    }


    excludeAll() {
        if (this.toList.length !== 0) {
            if (this.fromList.length === 0) {
                this.fromList = this.toList;
            }
            else {
                for (var i = this.toList.length; i--;) {
                    this.fromList.push(this.toList[i]);
                }
            }
                        
            this.toList = [];
            this.rowsR = [];
            this.emitToListChanged();
            this.emitFromListChanged();
        }
    }

    include(rowsL) {

        for (var j = rowsL.length; j--;) {
            for (var i = this.fromList.length; i--;) {
                if (this.fromList[i] === rowsL[j]) {
                    this.toList.push(rowsL[j]);
                    this.fromList.splice(i, 1);
                }
            }
        }
      
        this.rowsL = [];
        this.emitToListChanged();
        this.emitFromListChanged();
       
    }

    exclude(rowsR) {

        for (var j = rowsR.length; j--;) {
            for (var i = this.toList.length; i--;) {
                if (this.toList[i] === rowsR[j]) {
                    this.fromList.push(rowsR[j]);
                    this.toList.splice(i, 1);
                }
            }
        }
       
        this.rowsR = [];
        this.emitToListChanged();
        this.emitFromListChanged();        
    }

    createLRow(value: string) {
        if (this.rowsL.indexOf(value) !== -1) {
            this.rowsL.splice(this.rowsL.indexOf(value), 1);
        } else {
            this.rowsL.push(value);
        }
    }

    createRRow(value: string) {
        if (this.rowsR.indexOf(value) !== -1) {
            this.rowsR.splice(this.rowsR.indexOf(value), 1);
        } else {
            this.rowsR.push(value);
        }
    }

    openSnackBar(message: string, action: string): MatSnackBarRef<SimpleSnackBar> {
        return this.snackBar.open(message, action, {
            duration: 5000,
        });
    }

  //@Output() itemAdded: EventEmitter<any> = new EventEmitter();
  //@Output() itemRemoved: EventEmitter<any> = new EventEmitter();

  //public fullList: any [] = [];
  //public itemsFiltered: any [] = [];
  //public selectedItemsFiltered: any [] = [];
  //public filterText: string;
  //public filterSelectedText: string;

  //@Input() items: any [] = [];
  //@Input() selectedItems: any [] = [];
  //@Output() selectedItemsChange = new EventEmitter<any>();

  //@Input() descProperty: string = 'description';
  //@Input() idProperty: string = 'id';
  //@Input() showFilter: boolean = true;
  //@Input() height: string = '200px';
  //@Input() filterPlaceholder: string = 'Filter';
  //@Input() addIcon: string = 'add';
  //@Input() addIconColor: string = 'black';
  //@Input() removeIcon: string = 'delete';
  //@Input() removeIconColor: string = 'black';
  //@Input() textColor: string = 'black';
  //@Input() showIcons: boolean = true;

  //  constructor() {

  //  }
    

  //ngOnInit() {
  //  this.fullList = this.items;
  //  this.update();
  //  }

    

  //update(){
  //  this.updateItems();
  //  this.updateSelectedItems();
  //}

  //updateItems() {
  //    this.items = _.differenceBy(this.items, this.selectedItems, this.idProperty);
  //  this.filterItems(this.filterText);
  //}

  //updateSelectedItems() {
  //  this.selectedItemsFiltered = this.selectedItems;
  //  this.filterSelectedItems(this.filterSelectedText);
  //}

  //addItem(item) {
  //  this.itemAdded.emit(item);
  //  this.selectedItems.push(item);
  //  this.update();
  //}

  //removeItem(item) {
  //  this.itemRemoved.emit(item);
  //  this.selectedItems = this.selectedItems.filter(i => item.id != i.id);
  //  this.selectedItemsChange.emit(this.selectedItems);
  //  this.update();
  //}

  //filterItems(text: string){
  //  this.filterText = text;
  //  if(!text || !text.replace(" ", "")){
  //    this.itemsFiltered = this.items;
  //    return;
  //  }
  //  this.itemsFiltered = this.items
  //    .filter(item => item[this.descProperty].toLowerCase().includes(text.toLowerCase()));
  //}

  //filterSelectedItems(text: string){
  //  this.filterSelectedText = text;
  //  if(!text || !text.replace(" ", "")){
  //    this.selectedItemsFiltered = this.selectedItems;
  //    return;
  //  }
  //  this.selectedItemsFiltered = this.selectedItems
  //    .filter(item => item[this.descProperty].toLowerCase().includes(text.toLowerCase()));
  //}


}



