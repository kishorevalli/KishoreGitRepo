import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import {
  MatIconModule,
  MatCardModule,
  MatButtonModule,
  MatListModule,  
  MatMenuModule,
  MatSelectModule,
  MatInputModule,
  MatTooltipModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatTableModule,
  MatSortModule,
  MatPaginatorModule,  
  MatCheckboxModule,
  MatToolbarModule,
  MatTabsModule,
  MatSlideToggleModule,
  MatStepperModule,
  MatRadioModule,
  MatDialogModule,
  MatProgressSpinnerModule,
  MatSnackBarModule,
  MatGridListModule
 } from '@angular/material';

@NgModule({
  exports: [ 
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,    
    MatMenuModule,
    MatSelectModule,
    MatInputModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,    
    MatCheckboxModule,
    MatToolbarModule,
    MatTabsModule,
    MatSlideToggleModule,
    MatStepperModule,
    MatRadioModule,
    MatDialogModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatGridListModule
   ]
})
export class AppMaterialModule { }
