import { Directive, TemplateRef, Input } from '@angular/core'

@Directive({
  selector : '[ifwDetail]'
})
export class IfwDetail {
    @Input("ifwDetailWhen")  when: (detailData: any) => boolean;
    @Input("ifwDetailShowDetails") showDetailsDefault: boolean = false;
    constructor(public template: TemplateRef<any>) {}
}