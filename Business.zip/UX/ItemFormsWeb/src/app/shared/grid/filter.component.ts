import { Component, ViewEncapsulation,Inject,forwardRef,Output,EventEmitter,ChangeDetectionStrategy} from '@angular/core'
import { IfwGrid } from './grid.component';
import { IfwColumn } from './column.directive';

@Component({
    selector: 'ifw-filter',
    templateUrl: './filter.component.html',
    styleUrls: ['./filter.component.scss'],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
  })
  export class IfwFilter {
    constructor(@Inject(forwardRef(() => IfwGrid)) public dataGrid: IfwGrid) {}
    @Output() filter = new EventEmitter();
     filterBy: string = "";
     filterValue: string = "";
    ngOnInit() {
        this.filterBy = this._getfirstColumn();
    }
    _changelistFilterBy(filterBy: string) {
        this.filterBy = filterBy||'';
    }
    _searchClicked(){
        this._emitFilterEvent(); 
    }    

    clearSearchFilter() {
        this.filterValue = "";
        this._searchClicked();
    }

    _getfirstColumn(){
        let column: IfwColumn = (this.dataGrid.columns && this.dataGrid.columns.length >0) ? this.dataGrid.columns.first : null;
        if(column) return column.name;
        return "";        
    }
    private _emitFilterEvent() {
        this.filter.emit({
          filterBy: this.filterBy,
          filterValue: this.filterValue     
        });
    }
  }