import { Component, Input, Inject, forwardRef, ViewEncapsulation,ChangeDetectionStrategy } from '@angular/core'
import { IfwGrid } from './grid.component';
@Component({
    selector: '[ifwRow]',
    templateUrl: './row.component.html',
    styleUrls: ['./grid.component.scss'],
    encapsulation: ViewEncapsulation.None
  })
  export class IfwRow {
    @Input() row: any;
    @Input() index: number;
    constructor(@Inject(forwardRef(() => IfwGrid)) public dataGrid: IfwGrid) {}
    private _showDetails:boolean = false;
    private _showDetailsDefaultPrevious:boolean = false;
    get showDetails() {
      if(this.dataGrid.detailTemplate.showDetailsDefault && !this.detailTemplateShowIf()) return false;
      if (this._showDetailsDefaultPrevious != this.dataGrid.detailTemplate.showDetailsDefault) {       
        this._showDetailsDefaultPrevious = this.dataGrid.detailTemplate.showDetailsDefault;
        this._showDetails = this.dataGrid.detailTemplate.showDetailsDefault;
        if(this.row && this.row.showDetails) {          
          this.row.showDetails = false;
        } 
      }
      if(this.row && this.row.showDetails) return true;      
      return this._showDetails;
    }
    set showDetails(value:boolean){
      this._showDetails = value;
    }
    public detailTemplateShowIf(){
      return this.dataGrid.detailTemplate.when(this.row);
    }
    // Need this if we need to display nested data
    public getData(row:any, propertyName:string):string {
      return propertyName.split('.').reduce((prev:any, curr:string) => prev?prev[curr]:'', row);
    }
    public showDetailsClick(){     
      if(this.row && this.row.showDetails) {
        this.row.showDetails = false;
        this.showDetails = false;
      }
      else {
        this.showDetails = !this.showDetails;
      }
    }
  }