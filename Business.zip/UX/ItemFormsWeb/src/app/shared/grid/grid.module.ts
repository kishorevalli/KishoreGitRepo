import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IfwGrid } from './grid.component';
import { IfwRow } from './row.component';
import { IfwColumn } from './column.directive';
import { IfwDetail } from './detail.directive';
import { IfwFilter } from './filter.component';
import { AppMaterialModule } from '../app-material.module';

@NgModule({
    imports: [
      CommonModule,
      FormsModule,
       AppMaterialModule
    ],
    declarations: [
      IfwGrid,
      IfwRow,
      IfwColumn,
      IfwDetail,
      IfwFilter
    ],
    exports: [
      IfwGrid,
      IfwColumn,
      IfwDetail
    ]
  })
  export class GridModule { }
  