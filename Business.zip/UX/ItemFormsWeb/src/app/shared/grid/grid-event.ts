export class GridEvent {
    pageIndex: number;
    pageSize: number;
    length: number;
    active: string;
    direction: string;
    filterBy: string;
    filterValue: string;
    action?: GridAction;
}
export type GridAction = "filter" | "sort" | "page";