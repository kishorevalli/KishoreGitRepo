import { Component, Input, ContentChildren, ContentChild, QueryList, Output, EventEmitter, ViewChild, ViewEncapsulation, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core'
import { IfwColumn } from './column.directive';
import { IfwDetail } from './detail.directive';
import { PageEvent, MatPaginator, MatSort, Sort } from '@angular/material';
import { GridEvent, GridAction } from './grid-event'


@Component({
  selector: 'ifw-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class IfwGrid {
  @Input() data: any[];
  @Input() pageSize: number;
  @Input() length: number;
  @Input() pagination: boolean = true;
  @Input() sortable: boolean = true;
  @Input() filterable: boolean = true;
  @Input() header: boolean = true;
  _filterValue: string = "";
  _filterBy: string = "";
  @ContentChildren(IfwColumn) columns: QueryList<IfwColumn>;
  @ViewChild(MatSort) sorting: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ContentChild(IfwDetail) detailTemplate: IfwDetail;
  pageSizeOptions = [5, 10, 25, 100];

  @Output() gridChange = new EventEmitter<GridEvent>();
  constructor(private cdr: ChangeDetectorRef) { }
  emitPageEvent(pageEvent: PageEvent) {
    this._emitUpdateEvent("page");
  }

  emitSortEvent(sortEvent: Sort) {
    this._setFirstPage();
    this._emitUpdateEvent("sort");
  }
  updateChanges(){
    this.cdr.markForCheck();
  }
  emitFilterEvent(filterEvent: any) {
    this._setFirstPage();
    this._filterBy = filterEvent.filterBy;
    this._filterValue = filterEvent.filterValue;
    this._emitUpdateEvent("filter");
  }
  _setFirstPage(){
    if(this.paginator){
      this.paginator.pageIndex = 0;
    }
  }
  get _pageIndex(){
    return this.paginator? this.paginator.pageIndex : 0;
  }
  get _pageSize(){
    return this.paginator? this.paginator.pageSize : 0;
  }
  get _length(){
    return this.paginator? this.paginator.length : 0;
  }
  get _active(){
    return this.sorting? this.sorting.active : "";
  }
  get _direction(){
    return this.sorting? this.sorting.direction : "";
  }
  private _emitUpdateEvent(action?:GridAction) {
    this.gridChange.emit({
      pageIndex: this._pageIndex,
      pageSize: this._pageSize,
      length: this._length,
      active: this._active,
      direction: this._direction,
      filterBy: this._filterBy,
      filterValue: this._filterValue,
      action: action
    });
  }
}