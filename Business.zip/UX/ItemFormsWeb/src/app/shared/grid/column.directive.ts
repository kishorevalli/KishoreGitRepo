import { Directive, Input, ContentChild } from '@angular/core'

@Directive({
    selector : 'ifw-column'
})
export class IfwColumn {
    @Input() title: string;
    @Input() name: string;
    @Input() className: string;
    @Input() visible: boolean = true;
    @Input() sortable: boolean = true;
    @Input() filterable: boolean = true;
    @ContentChild('columnTemplate') columnTemplate;
    @ContentChild('headerTemplate') headerTemplate;
}