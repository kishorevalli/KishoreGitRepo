import { Directive, HostListener, Input, ElementRef, OnInit, Optional, Output,EventEmitter } from '@angular/core';
import { NgControl } from '@angular/forms';
// Usage: 
// <mat-form-field floatPlaceholder="always">
//    <input matInput numeric [decimals]="2" [max]="999" placeholder="Label Amount" formControlName="labelAmount">
//    <mat-hint align="end">Format 999.99</mat-hint>
// </mat-form-field>
interface IState {
  value: string;
  oldValue: string;
}
@Directive({
  selector: '[numeric]'
})
export class InputNumericDirective {
  @Input() max: number;
  @Input() decimals: number;
  private state: IState;
  //@Output() ngModelChange = new EventEmitter();
  @Output() maskChange = new EventEmitter();
  /**
     *
     * @param element
     * @param control
  */
  constructor(private element: ElementRef,
    @Optional() private control: NgControl) {
      this.state = {
        value: this.getValue(),
        oldValue: this.getValue()
      };
     }
       /**
   *
   * @param event
   */
  @HostListener('focus')
  public onFocus(): void {
    this.state.oldValue = this.getValue();
    this.state.value = this.getValue();
  }
 /**
   *
   * @param event
   */
  @HostListener('blur')
  public onBlur(): void {
    //console.log("oldValue" + this.state.oldValue);
    //console.log("newValue" + this.state.value);

    if(this.state.oldValue != this.state.value){
      this.maskChange.emit({
        target: {
          value: this.state.value
        }
      });
    }
  }
  /**
     *
     * @param event
  */
  @HostListener('input')
  public onChange(): void {
    this.applyMask(this.getValue());
  }
  /**
     *
     * @param value
     */
  private applyMask(value): void {
    let newValue: string = '';
    const splitStr: string[] = value.toString().split(".");
    let natural: string = splitStr[0];
    let naturalNew: string = '';
    let naturalLength = natural.length;
    if (this.max) {
      const maxlength = this.max.toString().length;
      naturalLength = (natural.length > maxlength) ? maxlength : natural.length;
    }
    for (let i = 0; i < naturalLength; i++) {
      let current = natural[i];
      let regexp = new RegExp('\\d', 'gi');
      if (!regexp.test(current)) {
        break;
      }
      naturalNew += current;
      // Below code is used if we need to consider @input max value not just the length of characters in max. 
      // Right now @input max ="999" is same as max="200"
      // if (parseFloat(naturalNew) > this.max) {
      //   naturalNew = naturalNew.slice(0, -1);
      //   break;
      // }
    }
    if (this.decimals && splitStr.length >= 2) {
      let decimal: string = splitStr[1];
      let decimalNew: string = '';
      const decimalLength = (decimal.length > this.decimals) ? this.decimals : decimal.length;
      for (let i = 0; i < decimalLength; i++) {
        let current = decimal[i];
        let regexp = new RegExp('\\d', 'gi');
        if (!regexp.test(current)) {
          break;
        }
        decimalNew += current;
      }
      newValue = naturalNew + "." + decimalNew;
    }
    else {
      newValue = naturalNew;
    }
    this.setValue(newValue);
    this.state.value = newValue;
  }
  /**
   *
   * @returns {any}
   */
  private getValue(): string {
    return this.element.nativeElement.value;
  }
  /**
   *
   * @param value
   */
  private setValue(value: string): void {
    this.element.nativeElement.value = value;
    if(this.control)this.control.control.setValue(value);
  }
}