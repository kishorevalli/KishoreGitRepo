import { Directive, HostListener, Input, ElementRef, OnInit, EventEmitter, Output, Optional } from '@angular/core';
import { NgControl } from '@angular/forms';


const placeholders = {
  'A': '^[a-zA-ZA-zА-яЁё]',
  '0': '\\d'
};

const keys = {
  'BACKSPACE': 8,
  'LEFT': 37,
  'RIGHT': 39,
  'DEL': 46,
};


interface IState {
  value: string;
  oldValue: string;
}

@Directive({
  selector: '[mask]'
})
export class InputMaskDirective  {

  private state: IState;

  @Input() mask: any;
  //@Output() ngModelChange = new EventEmitter();
  @Output() maskChange = new EventEmitter();

  /**
   *
   * @param element
   * @param control
   */
  constructor(private element: ElementRef, 
    @Optional() private control : NgControl) {
    this.state = {
      value: this.getValue(),
      oldValue: this.getValue()
    };
  }
   /**
   *
   * @param event
   */
  @HostListener('focus')
  public onFocus(): void {
    this.state.oldValue = this.getValue();
    this.state.value = this.getValue();
  }
 /**
   *
   * @param event
   */
  @HostListener('blur')
  public onBlur(): void {
    //console.log("oldValue" + this.state.oldValue);
    //console.log("newValue" + this.state.value);

    if(this.state.oldValue != this.state.value){
      this.maskChange.emit({
        target: {
          value: this.state.value
        }
      });
    }
  }
  
   /**
   *
   * @param event
   */ 
  @HostListener('input')
  public onChange(): void {
    this.applyMask(this.getClearValue(this.getValue()));
  }

  /**
   *
   * @param event
   */
  /*@HostListener('keypress', ['$event'])
  public onKeyPress(event): void {
    if(!this.mask) return;
    const key = this.getKey(event);
    if(key === keys.BACKSPACE ||key === keys.LEFT || key === keys.RIGHT) return;

    const cursorPosition = this.getCursorPosition();
    let regexp = this.createRegExp(cursorPosition);
    if(regexp != null && !regexp.test(event.key) || this.getValue().length >= this.mask.length) {
      event.preventDefault();
    }
    else {
      this.applyMask(this.getClearValue(this.getValue()));
    }
  }*/

  /**
   *
   * @param event
   */
 /* @HostListener('keydown', ['$event'])
  public onKeyDown(event): void {
    const key = this.getKey(event);
    if((key === keys.BACKSPACE || key === keys.DEL) && this.getClearValue(this.getValue()).length === 1) {
      this.setValue('');
      this.state.value = '';
      this.ngModelChange.emit('');
    }
  }*/

  /**
   *
   * @param event
   */
  /*
  public ngOnInit(): void {
    this.applyMask(this.getClearValue(this.getValue()));
  } */

  /**
   *
   * @param event
   * @returns {number}
   */
  private getKey(event) {
    return event.keyCode || event.charCode;
  }

  /**
   *
   * @param value
   */
  private applyMask(value): void {
    if(!this.mask) return;
    let newValue = '';
    let maskPosition = 0;

   /* if (this.getClearValue(value).length > this.getClearValue(this.mask).length) {
      this.setValue(this.state.value);
      return;
    }*/
    let length = (value.length > this.getClearValue(this.mask).length)? this.getClearValue(this.mask).length : value.length;
    for (let i = 0; i < length; i++) {
      let current = value[i];

      let regexp = this.createRegExp(maskPosition);
      if (regexp != null) {
        if (!regexp.test(current)) {
          this.setValue(this.state.value);
          break;
        }
        newValue += current;
      } else if (this.mask[maskPosition] === current) {
        newValue += current;
      } else {
        newValue += this.mask[maskPosition];
        i--;
      }

      maskPosition++;
    }

    const nextMaskElement = this.mask[maskPosition];
    if (value.length && nextMaskElement != null && /^[-\/\\^$#&@№:<>_\^!*+?.()|\[\]{}]/.test(nextMaskElement)) {
      newValue += nextMaskElement;
    }

    const oldValue = this.state.value;
    const cursorPosition = this.getCursorPosition();
    /*
    'change' event is not firing when the text field value is changed programatically
    https://bugs.chromium.org/p/chromium/issues/detail?id=92492
    This is fixed in chrome, but not in IE. So, need to use blur and write your own code to detect the change and emit change event.
    */
    this.setValue(newValue);
    this.state.value = newValue;

    if (oldValue.length >= cursorPosition) {
      this.setCursorPosition(cursorPosition);
    }

  }

  /**
   *
   * @param position
   * @returns {any}
   */
  private createRegExp(position): RegExp | null {
    if(!this.mask) return;
    if (this.mask[position] == null) {
      return null;
    }

    const currentSymbol = this.mask[position].toUpperCase();
    const keys = Object.keys(placeholders);
    const searchPosition = keys.indexOf(currentSymbol);
    if (searchPosition >= 0) {
      return new RegExp(placeholders[keys[searchPosition]], 'gi');
    }
    return null;
  }


  /**
   *
   * @returns {any}
   */
  private getValue(): string {
    return this.element.nativeElement.value;
  }

  /**
   *
   * @param value
   * @returns {string}
   */
  private getClearValue(value): string {
    return value.trim().replace(/[-\/\\^$#&@№:<>_\^!*+?.()|\[\]{} ]/gi, '');
  }

  /**
   *
   * @param value
   */
  private setValue(value: string): void {
    this.element.nativeElement.value = value;
    if(this.control)this.control.control.setValue(value);
  }

  /**
   *
   * @returns {number}
   */
  private getCursorPosition(): number {
    return this.element.nativeElement.selectionStart;
  }

  /**
   *
   * @param start
   * @param end
   */
  private setCursorPosition(start: number, end: number = start): void {
    this.element.nativeElement.setSelectionRange(start, end);
  }

}

