/**
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/M-Ulyanov/ng2-inputmask/
 */
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {InputMaskDirective} from './input-mask.directive';
import {InputNumericDirective} from './input-numeric.directive';


@NgModule({
    imports: [
        FormsModule
    ],
    declarations: [
        InputMaskDirective,
        InputNumericDirective
    ],
    exports: [
        InputMaskDirective,
        InputNumericDirective
    ]
})
export class InputMaskModule {
}