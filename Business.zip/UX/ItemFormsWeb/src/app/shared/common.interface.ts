﻿export interface ILookupDto {
    code: string;
    description: string;
}
export interface ILookupIntDto {
    code: number;
    description: string;
}
export interface ILookupIntFlagDto {
    code: number;
    description: string;
    receiptDescFlag: string;
}


export class LookupIntDto implements ILookupIntDto {
    code: number;
    description: string;
}

export class LookupIntFlagDto implements ILookupIntFlagDto {
    code: number;
    description: string;
    receiptDescFlag: string;
}


export class LookupDto implements ILookupDto {
    code: string;
    description: string;
}
// Validation DTO that returns after server side validation
export interface IItemSaveResponse {
    status: boolean;
    validation: IItemValidationDTO;
}
export interface IItemValidationDTO {
    tabName: string;
    errors: IErrorDTO[];
    warnings: IWarningDTO[];
    subTabValidations: ISubTabValidationDTO[]
}
export interface ISubTabValidationDTO {
    subTabType: string;
    subTabName: string;
    errors: IErrorDTO[];
    warnings: IWarningDTO[];
}
export interface IErrorDTO {
    errorCode: string;
    severityLevel: string;
    tabName: string;
    controlName: string;
    errorDescription: string;
}

export interface IListItem {
    id: number;
    name: string;    
    itemType: string;
}

export interface IWarningDTO {
    errorCode: string;
    severityLevel: string;
    controlName: string;
    errorDescription: string;
}
export class ItemValidationDTO implements IItemValidationDTO {
    tabName: string;
    errors: IErrorDTO[];
    warnings: IWarningDTO[];
    subTabValidations: ISubTabValidationDTO[]
}
export class SubTabValidationDTO implements ISubTabValidationDTO {
    subTabType: string;
    subTabName: string;
    errors: IErrorDTO[];
    warnings: IWarningDTO[];
}
export class ErrorDTO implements IErrorDTO {
    errorCode: string;
    severityLevel: string;
    tabName: string;
    controlName: string;
    errorDescription: string;
}
export class WarningDTO implements IWarningDTO {
    errorCode: string;
    severityLevel: string;  
    controlName: string;
    errorDescription: string;
}

export class ListItem implements IListItem {
    id: number;
    name: string;
    itemType: string;
}

export interface IScaleItemFacilityLookupDto {
    code: number;
    description: string;
    facilityGroup: string;
    facilityGroupDescription: string;
    facilityCodeDescription: string;
}

export class ScaleItemFacilityLookupDto implements IScaleItemFacilityLookupDto {
    code: number;
    description: string;
    facilityGroup: string;
    facilityGroupDescription: string;
    facilityCodeDescription: string;
}