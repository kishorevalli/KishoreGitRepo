﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Dependencies;
using Microsoft.Practices.Unity;

using Publix.S0VPITEM.ItemFormsBO;
using Publix.S0VPITEM.ItemFormsBO.Contracts;
using Publix.S0VPITEM.ItemFormsDac;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsWeb.Controllers.Security;
using System.Net.Http.Formatting;
using Newtonsoft.Json.Serialization;
using log4net;
using System.Web.Http.Cors;
using System.Net.Http.Headers;

namespace Publix.S0VPITEM.ItemFormsWeb
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            var cors = new EnableCorsAttribute("*", "*", "*");
            config.EnableCors(cors);

            // Web API configuration and services
            var container = new UnityContainer();
            container.RegisterInstance<ILog>(WebApiApplication.log);
            container.RegisterType<IIdentityService, IdentityService>(new HierarchicalLifetimeManager());
            config.DependencyResolver = new UnityResolver(container);

            // register business objects
            container.RegisterType<ICommonBO, CommonBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IBasicItemDefinitionBO, BasicItemDefinitionBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IGeneralProductAttributesBO, GeneralProductAttributesBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IWorkFlowBO, WorkFlowBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IPackagingHierarchyBO, PackagingHierarchyBO>(new HierarchicalLifetimeManager());
            
            container.RegisterType<IDsdAuthorizationRequestBO, DsdAuthorizationRequestBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IShipperItemCompositionBO, ShipperItemCompositionBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IDashboardBO, DashboardBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IMarketingSupportBO, MarketingSupportBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IProductGroupingBO, ProductGroupingBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IScaleItemDetailsBO, ScaleItemDetailsBO>(new HierarchicalLifetimeManager());
            container.RegisterType<IProductAttributesBO, ProductAttributesBO>(new HierarchicalLifetimeManager());
            container.RegisterType<ISubmitBO, SubmitBO>(new HierarchicalLifetimeManager());
            container.RegisterType<ICategoryReviewBO, CategoryReviewBO>(new HierarchicalLifetimeManager());


            //register data objects
            container.RegisterType<ICommonDac, CommonDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IBasicItemDefinitionDac, BasicItemDefinitionDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IGeneralProductAttributesDac, GeneralProductAttributesDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IWorkFlowDac, WorkFlowDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IDsdAuthorizationRequestDac, DsdAuthorizationRequestDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IPackagingHierarchyDac, PackagingHierarchyDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IShipperItemCompositionDac, ShipperItemCompositionDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IDashboardDac, DashboardDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IMarketingSupportDac, MarketingSupportDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IProductGroupingDac, ProductGroupingDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IScaleItemDetailsDac, ScaleItemDetailsDac>(new HierarchicalLifetimeManager());
            container.RegisterType<IProductAttributesDac, ProductAttributesDac>(new HierarchicalLifetimeManager());
            container.RegisterType<ICategoryReviewDac, CategoryReviewDac>(new HierarchicalLifetimeManager());


            config.Filters.Add(new SiteMinderAuthenticationAttribute());
            config.DependencyResolver = new UnityResolver(container);

            //TODO Research & Remove CORS
//#if DEBUG
            var corsOrgin = new EnableCorsAttribute("*", "*", "*");
            config.EnableCors(corsOrgin);
//#endif
            // Web API routes
            config.MapHttpAttributeRoutes();

            //config.Routes.MapHttpRoute(
            //    name: "DefaultApi",
            //    routeTemplate: "api/{controller}/{id}",
            //    defaults: new { id = RouteParameter.Optional }
            //);

            var jsonFormatter = config.Formatters.OfType<JsonMediaTypeFormatter>().FirstOrDefault();
            jsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            config.Formatters.JsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/html"));

            GlobalConfiguration.Configuration.IncludeErrorDetailPolicy = IncludeErrorDetailPolicy.Always;
        }
    }
}
