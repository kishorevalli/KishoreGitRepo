﻿using AutoMapper;
using Publix.S0VPITEM.ItemFormsBO.Mapping;

namespace Publix.S0VPITEM.ItemFormsWeb
{
    public static class AutoMapperConfig
    {
        public static void Configure()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile(new GeneralProductAttributesProfile());
                cfg.AddProfile(new PackagingHierarchyProfile());
                cfg.AddProfile(new DsdAuthorizationRequestProfile());
                cfg.AddProfile(new ErrorProfile());
                cfg.AddProfile(new BasicItemDefinitionProfile());
                cfg.AddProfile(new ProductGroupingProfile());
                cfg.AddProfile(new ScaleItemDetailsProfile());
                cfg.AddProfile(new ProductAttributesProfile());
            });
           
        }
    }
}