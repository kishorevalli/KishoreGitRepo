﻿using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class MarketingSupportDac : BaseDac, IMarketingSupportDac
    {
        public async Task<MarketingInfoDto> GetMarketingInfo(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {

                await conn.OpenAsync();
                MarketingInfoDto marketingInfo = await conn.QueryFirstOrDefaultAsync<MarketingInfoDto>(GetMarketingInfoSQL, new { @ItemFormID = ItemFormID });
                if (marketingInfo != null)
                {
                    var similarItemGTINList = await conn.QueryAsync<SimilarItemGTINDto>(GetSimilarItemGTINSQL, new { @ItemFormID = ItemFormID });
                    marketingInfo.SimilarItemGTINList = similarItemGTINList.ToList();
                }
                return marketingInfo;
            }
        }

        public async Task<IEnumerable<LookupDto>> GetPromoSupportFrequency()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<LookupDto>(GetPromoSupportFrequencySQL, new { IsActive = 1 }));
            }
        }

        public async Task<IEnumerable<LookupDto>> GetUnitCostUOM()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<LookupDto>(GetUnitCostUOMSQL, new { IsActive = 1 }));
            }
        }

        public async Task<bool> SaveMarketingInfo(MarketingInfoDto marketingInfo)
        {
            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    await conn.ExecuteAsync(InsertMarketingInfoAuditSQL, marketingInfo);
                    await conn.ExecuteAsync(MergeMarketingInfoSQL, marketingInfo);
                    // Audit and Delete SimilarGTIN list
                    await conn.ExecuteAsync(InsertSimilarItemGTINAuditSQL, new { ItemFormID = marketingInfo.ItemFormID });
                    await conn.ExecuteAsync(DeleteSimilarItemGTINSQL, new { ItemFormID = marketingInfo.ItemFormID });
                    if (marketingInfo.SimilarItemGTINList != null && marketingInfo.SimilarItemGTINList.Count > 0)
                    {
                        await conn.ExecuteAsync(InsertSimilarItemGTINSQL, marketingInfo.SimilarItemGTINList);
                    }
                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }

        public async Task<IEnumerable<FormCommentDto>> GetFormComment(int ItemFormID, int UserType)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                var sql = (UserType == 1) ? GetFormCommentVendorSQL : GetFormCommentSQL;
                await conn.OpenAsync();
                return await conn.QueryAsync<FormCommentDto>(sql, new { @ItemFormID = ItemFormID });
            }
        }
        public async Task<bool> SaveFormComment(FormCommentDto formComment)
        {
            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    await conn.ExecuteAsync(InsertFormCommentSQL, formComment);
                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }
        public async Task<List<SimilarItemGTINDto>> CreateSimilarItemForms(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                var similarItemGTINList = await conn.QueryAsync<SimilarItemGTINDto>(GetCloneSimilarItemGTINSQL, new { @ItemFormID = ItemFormID });
                foreach(var similarItem in similarItemGTINList)
                {
                    int NewItemFormID = await conn.QueryFirstOrDefaultAsync<int>(InsertSimilarItemFormSQL, new { @ItemFormID = ItemFormID });
                    similarItem.SimilarGTINNewItemFormID = NewItemFormID;
                }               
                return similarItemGTINList.ToList();
            }
        }
        public async Task<bool> CloneSimilarItemFormData(SimilarItemGTINDto SimilarItemForm)
        {
            bool retValue = false;
            if(SimilarItemForm.ItemFormID > 0 && SimilarItemForm.SimilarGTINNewItemFormID >0 && SimilarItemForm.SimilarGTIN > 0)
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    await conn.ExecuteAsync(InsertSimilarItemFormDataSQL, new
                    {
                        @ItemFormID = SimilarItemForm.ItemFormID,
                        @GTIN = SimilarItemForm.SimilarGTIN,
                        @GTINCheckDigit = SimilarItemForm.SimilarGTINCheckDigit,
                        @NewItemFormID = SimilarItemForm.SimilarGTINNewItemFormID
                    });
                    retValue = true;
                }
            }            
            return retValue;
        }
        public async Task UpdateItemFormVendorEmail(ItemFormDto itemForm)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(UpdateItemFormVendorEmailSQL, itemForm);
            }
        }
        #region "SQL Queries"
        private const string GetPromoSupportFrequencySQL = @" SELECT Code, Description
                                    FROM [dbo].[PromoSupportFrequency]   WHERE IsActive = @IsActive
                                    ORDER BY ID ";
        private const string GetUnitCostUOMSQL = @" SELECT Code, Description
                                    FROM [dbo].[UnitCostUOM]   WHERE IsActive = @IsActive
                                    ORDER BY ID ";
       
        private const string MergeMarketingInfoSQL = @" MERGE INTO [dbo].[MarketingInfo] AS Target
                 USING ( SELECT 
                             @ItemFormID AS ItemFormID
                            ,@ProjectedSales52Weeks AS ProjectedSales52Weeks
                            ,@UnitCost AS UnitCost
                            ,@UnitCostUOM AS UnitCostUOM
                            ,@SuggestedRetail AS SuggestedRetail
                            ,@SuggestedMargin AS SuggestedMargin
                            ,@ItemPreviouslyPresented AS ItemPreviouslyPresented
                            ,@AvailableShipDate AS AvailableShipDate
                            ,@NewItemFundsAvailable AS NewItemFundsAvailable
                            ,@NewItemFundsAmount AS NewItemFundsAmount
                            ,@PromoSupportFrequency AS PromoSupportFrequency
                            ,@MediaSupport AS MediaSupport
                            ,@LocalChainPresentlyStocking AS LocalChainPresentlyStocking
                            ,@CreatedBy AS CreatedBy
                            ,@LastUpdatedBy AS LastUpdatedBy)      
                AS Source   
                ON Target.[ItemFormID] = Source.[ItemFormID]
                WHEN MATCHED THEN
                    UPDATE SET
                        [ProjectedSales52Weeks] = Source.ProjectedSales52Weeks,
                        [UnitCost] = Source.UnitCost,
                        [UnitCostUOM] = Source.UnitCostUOM,
                        [SuggestedRetail] = Source.SuggestedRetail,                        
                        [SuggestedMargin] = Source.SuggestedMargin,
                        [ItemPreviouslyPresented] = Source.ItemPreviouslyPresented,
                        [AvailableShipDate] = Source.AvailableShipDate,
                        [NewItemFundsAvailable] = Source.NewItemFundsAvailable,
                        [NewItemFundsAmount] = Source.NewItemFundsAmount,
                        [PromoSupportFrequency] = Source.PromoSupportFrequency,
                        [MediaSupport] = Source.MediaSupport,
                        [LocalChainPresentlyStocking] = Source.LocalChainPresentlyStocking,
                        [LastUpdatedBy] = Source.LastUpdatedBy,
                        [LastUpdatedDate] = GetDate()
              WHEN NOT MATCHED BY TARGET THEN
                    INSERT 
                        ([ItemFormID]
                        ,[ProjectedSales52Weeks]
                        ,[UnitCost]
                        ,[UnitCostUOM]
                        ,[SuggestedRetail]
                        ,[SuggestedMargin]   
                        ,[ItemPreviouslyPresented]
                        ,[AvailableShipDate]
                        ,[NewItemFundsAvailable]
                        ,[NewItemFundsAmount]
                        ,[PromoSupportFrequency]
                        ,[MediaSupport]
                        ,[LocalChainPresentlyStocking]
                        ,[CreatedBy]
                        ,[CreatedDate])
                     VALUES
                         (Source.ItemFormID
                         ,Source.ProjectedSales52Weeks
                         ,Source.UnitCost
                         ,Source.UnitCostUOM
                         ,Source.SuggestedRetail
                         ,Source.SuggestedMargin      
                         ,Source.ItemPreviouslyPresented
                         ,Source.AvailableShipDate 
                         ,Source.NewItemFundsAvailable
                         ,Source.NewItemFundsAmount
                         ,Source.PromoSupportFrequency
                         ,Source.MediaSupport
                         ,Source.LocalChainPresentlyStocking
                         ,Source.CreatedBy
                         ,GetDate());";
        private const string InsertMarketingInfoAuditSQL = @" INSERT INTO [dbo].[MarketingInfoAudit]
                                      ([Version]
                                      ,[ItemFormID]
                                      ,[ProjectedSales52Weeks]
                                      ,[UnitCost]
                                      ,[UnitCostUOM]
                                      ,[SuggestedRetail]
                                      ,[SuggestedMargin]   
                                      ,[ItemPreviouslyPresented]
                                      ,[AvailableShipDate]
                                      ,[NewItemFundsAvailable]
                                      ,[NewItemFundsAmount]
                                      ,[PromoSupportFrequency]
                                      ,[MediaSupport]
                                      ,[LocalChainPresentlyStocking]
                                      ,[CreatedBy]
                                      ,[CreatedDate]
                                      ,[LastUpdatedBy]
                                      ,[LastUpdatedDate])
                                SELECT 
                                       getDate()
                                      ,ItemFormID
                                      ,ProjectedSales52Weeks
                                      ,UnitCost
                                      ,UnitCostUOM
                                      ,SuggestedRetail
                                      ,SuggestedMargin      
                                      ,ItemPreviouslyPresented
                                      ,AvailableShipDate
                                      ,NewItemFundsAvailable
                                      ,NewItemFundsAmount
                                      ,PromoSupportFrequency
                                      ,MediaSupport
                                      ,LocalChainPresentlyStocking
                                      ,CreatedBy
                                      ,GetDate()
                                      ,LastUpdatedBy
                                      ,GetDate() 
                               FROM [dbo].[MarketingInfo] where ItemFormID = @ItemFormID";
        private const string GetMarketingInfoSQL = @"SELECT 
                                         [ItemFormID]
                                        ,[ProjectedSales52Weeks]
                                        ,[UnitCost]
                                        ,[UnitCostUOM]
                                        ,[SuggestedRetail]
                                        ,[SuggestedMargin]   
                                        ,[ItemPreviouslyPresented]
                                        ,[AvailableShipDate]
                                        ,[NewItemFundsAvailable]
                                        ,[NewItemFundsAmount]
                                        ,[PromoSupportFrequency]
                                        ,[MediaSupport]
                                        ,[LocalChainPresentlyStocking]
                                        ,IFM.FormStatusID
                                        ,IFM.FormActionID
                                        ,IFM.VendorContactEmail
                                        FROM [dbo].[MarketingInfo] MKI
                                        INNER JOIN ItemForm IFM ON IFM.ID = MKI.ItemFormID
                                        WHERE MKI.ItemFormID = @ItemFormID";

        private const string InsertSimilarItemGTINSQL = @"INSERT INTO [dbo].[SimilarItemGTIN]
                                       ([ItemFormID]
                                       ,[SimilarGTIN]
                                       ,[SimilarGTINCheckDigit]
                                       ,[SimilarGTINNewItemFormID] 
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                                 VALUES
                                       (@ItemFormID
                                       ,@SimilarGTIN
                                       ,@SimilarGTINCheckDigit
                                       ,@SimilarGTINNewItemFormID
                                       ,@CreatedBy
                                       ,GetDate()
                                       ,@LastUpdatedBy
                                       ,GetDate())";
        private const string DeleteSimilarItemGTINSQL = @"DELETE FROM [dbo].[SimilarItemGTIN] WHERE 
                                        ItemFormID = @ItemFormID";
        private const string InsertSimilarItemGTINAuditSQL = @"INSERT INTO [dbo].[SimilarItemGTINAudit]
                                       ([Version]
                                       ,[ID] 
                                       ,[ItemFormID]
                                       ,[SimilarGTIN]
                                       ,[SimilarGTINCheckDigit]
                                       ,[SimilarGTINNewItemFormID] 
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                               SELECT 
                                        GetDate()
                                       ,[ID]
                                       ,ItemFormID
                                       ,SimilarGTIN
                                       ,SimilarGTINCheckDigit
                                       ,SimilarGTINNewItemFormID
                                       ,CreatedBy
                                       ,GetDate()
                                       ,LastUpdatedBy
                                       ,GetDate() 
                               FROM [dbo].[SimilarItemGTIN] where ItemFormID = @ItemFormID";
        private const string GetSimilarItemGTINSQL = @"SELECT       
	                                    [ItemFormID]
                                       ,[SimilarGTIN]
                                       ,[SimilarGTINCheckDigit]
                                       ,[SimilarGTINNewItemFormID] 
                                       ,IFM.ItemFormDisplayID AS SimilarGTINNewItemFormDisplayID
                               FROM [dbo].[SimilarItemGTIN] SIG
                               LEFT OUTER JOIN ItemForm IFM ON IFM.ID = SIG.SimilarGTINNewItemFormID
                               WHERE SIG.ItemFormID = @ItemFormID";

        private const string GetCloneSimilarItemGTINSQL = @"SELECT       
	                                    [ItemFormID]
                                       ,[SimilarGTIN]
                                       ,[SimilarGTINCheckDigit]
                                       ,[SimilarGTINNewItemFormID] 
                               FROM [dbo].[SimilarItemGTIN] 
                               WHERE ItemFormID = @ItemFormID AND SimilarGTINNewItemFormID IS NULL";

        private const string GetFormCommentSQL = @"SELECT  
                                        [ID]         
	                                   ,[ItemFormID]
                                       ,[Comment]
                                       ,[CreatedByUserTypeID]
                                       ,[ShowVendor] 
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                               FROM [dbo].[FormComment]
                               WHERE ItemFormID = @ItemFormID 
                               ORDER BY ID DESC ";

        private const string GetFormCommentVendorSQL = @"SELECT  
                                        [ID]         
	                                   ,[ItemFormID]
                                       ,[Comment]
                                       ,[CreatedByUserTypeID]
                                       ,[ShowVendor] 
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                               FROM [dbo].[FormComment]
                               WHERE ItemFormID = @ItemFormID AND (CreatedByUserTypeID = 1 OR ShowVendor = 1) 
                               ORDER BY ID DESC ";
        private const string InsertFormCommentSQL = @"INSERT INTO [dbo].[FormComment]
                                       ([ItemFormID]
                                       ,[Comment]
                                       ,[CreatedByUserTypeID]
                                       ,[ShowVendor] 
                                       ,[CreatedBy]
                                       ,[CreatedDate])
                                 VALUES
                                       (@ItemFormID
                                       ,@Comment
                                       ,@CreatedByUserTypeID
                                       ,@ShowVendor
                                       ,@CreatedBy
                                       ,GetDate())";
        private const string UpdateItemFormVendorEmailSQL = @"UPDATE [dbo].[ItemForm]
                        SET
                        [VendorContactEmail] = @VendorContactEmail
                        WHERE ID = @ID";

        private const string InsertSimilarItemFormSQL = @"DECLARE @ItemFormDisplayFormID as bigint
                        SELECT  @ItemFormDisplayFormID = CAST( CONCAT(CONVERT(VARCHAR(8), GETDATE(), 112) , FORMAT(COUNT(ID)+1,'0000'))AS bigint)  FROM [dbo].[ItemForm] WHERE CAST(CreatedDate AS DATE) = CAST(GETDATE() AS DATE)
                        INSERT INTO [dbo].[ItemForm]
	                        ([ItemFormDisplayID]
	                        ,[FormTypeID]
	                        ,[SubmissionDate]
	                        ,[SubmittedBy]
	                        ,[SubmittedUserTypeID]
                            ,[CreatedByUserTypeID]
	                        ,[FormStatusID]
	                        ,[FormActionID]
	                        ,[PendingRoleUserTypeID]
	                        ,[DSDAuthRequestSelectStoreOption]
	                        ,[VendorContactID]  
	                        ,[BuyerID]
	                        ,[BuyerName]                
	                        ,[CreatedBy]
	                        ,[CreatedDate]
                            ,[LastUpdatedBy]
                            ,[LastUpdatedDate]
	                        )
                          SELECT 
	                         @ItemFormDisplayFormID
	                        ,[FormTypeID]
	                        ,[SubmissionDate]
	                        ,[SubmittedBy]
	                        ,[SubmittedUserTypeID]
                            ,[CreatedByUserTypeID]
	                        ,[FormStatusID]
	                        ,[FormActionID]
	                        ,[PendingRoleUserTypeID]
	                        ,[DSDAuthRequestSelectStoreOption]
	                        ,[VendorContactID]     
	                        ,[BuyerID]
	                        ,[BuyerName]             
	                        ,'SYSTEM'
                            ,GetDate()         
	                        ,'SYSTEM'
                            ,GetDate()
                            FROM [dbo].[ItemForm] WHERE ID = @ItemFormID;
                        SELECT SCOPE_IDENTITY() AS ID;";

        private const string InsertSimilarItemFormDataSQL = @"
                            -- INSERT Basic Item Definition
                            INSERT INTO [dbo].[BasicItemDefinition]
	                            ( [ItemFormID]
	                            , [ItemTypeCode]
	                            , [ItemTypeDescription]
	                            , [AutoGenerateType4GTIN]
	                            , [GTIN]
	                            , [GTINCheckDigit]
	                            , [ExistingGTINIndicator]
	                            , [CompressedUPC]
	                            , [PriceLookupCode]
	                            , [ReUseItemCode]
	                            , [ReUseItemDescription]
	                            , [SubmissionReasonID]
	                            , [ItemCaseTypeID]
	                            , [RecipeRequired]
	                            , [IngredientItemRequired]
	                            , [ModelProductItemCode]
	                            , [ModelProductItemDescription]
	                            , [ModelProductItemTypeCode]
	                            , [ModelPackagingItemCode]
	                            , [ModelPackagingItemDescription]
	                            , [ModelPackagingItemTypeCode]
	                            , [VendorItemCode]
	                            , [VendorItemDescription]
	                            , [ItemDescription]
	                            , [Brand]
	                            , [Manufacturer]
	                            , [RetailPackagedItem]
	                            , [RetailPackType]
	                            , [RetailPackTypeDescription]
	                            , [RetailPackSize]
	                            , [Size]
	                            , [SizeUOM]
	                            , [SizeUOMDescription]
	                            , [MinorityManufacturer]
	                            , [PackageDescription]
	                            , [ContainerType]
	                            , [LabelAmount]
	                            , [PerpetualInventoryFlag]
	                            , [ReceiptDescription]
	                            , [AdDescription]
	                            , [ProductCatalogShortDescription1]
	                            , [ProductCatalogShortDescription2]
	                            , [NonDiscountable]
	                            , [AdditionalGTINPresent]
	                            , [CreatedBy]
	                            , [CreatedDate]
	                            ,[LastUpdatedBy]
	                            ,[LastUpdatedDate]
	                            , LastScanDate)
                            SELECT 
	                              @NewItemFormID
	                            , [ItemTypeCode]
	                            , [ItemTypeDescription]
	                            , [AutoGenerateType4GTIN]
	                            , @GTIN
	                            , @GTINCheckDigit
	                            , [ExistingGTINIndicator]
	                            , [CompressedUPC]
	                            , [PriceLookupCode]
	                            , [ReUseItemCode]
	                            , [ReUseItemDescription]
	                            , [SubmissionReasonID]
	                            , [ItemCaseTypeID]
	                            , [RecipeRequired]
	                            , [IngredientItemRequired]
	                            , [ModelProductItemCode]
	                            , [ModelProductItemDescription]
	                            , [ModelProductItemTypeCode]
	                            , [ModelPackagingItemCode]
	                            , [ModelPackagingItemDescription]
	                            , [ModelPackagingItemTypeCode]
	                            , [VendorItemCode]
	                            , [VendorItemDescription]
	                            , [ItemDescription]
	                            , [Brand]
	                            , [Manufacturer]
	                            , [RetailPackagedItem]
	                            , [RetailPackType]
	                            , [RetailPackTypeDescription]
	                            , [RetailPackSize]
	                            , [Size]
	                            , [SizeUOM]
	                            , [SizeUOMDescription]
	                            , [MinorityManufacturer]
	                            , [PackageDescription]
	                            , [ContainerType]
	                            , [LabelAmount]
	                            , [PerpetualInventoryFlag]
	                            , [ReceiptDescription]
	                            , [AdDescription]
	                            , [ProductCatalogShortDescription1]
	                            , [ProductCatalogShortDescription2]
	                            , [NonDiscountable]
	                            , [AdditionalGTINPresent]
	                            ,'SYSTEM'
	                            ,GetDate()
	                            ,'SYSTEM'
	                            ,GetDate()
	                            ,[LastScanDate]
                             FROM [dbo].[BasicItemDefinition] WHERE ItemFormID = @ItemFormID;


                             -- INSERT General Product Attributes
                            INSERT INTO [dbo].[GeneralProductAttribute]
	                            ([ItemFormID]
	                            ,[NutritionalPanelTypeID]
	                            ,[PerishableItem]
	                            ,[ProductDate]
	                            ,[BornOnDays]
	                            ,[CountryOfOrigin]           
	                            ,[Ignitable]
	                            ,[Corrosive]
	                            ,[Reactive]
	                            ,[Toxic]
	                            ,[EPAListedWaste]
	                            ,[ContainsBattery]
	                            ,[EMailForBatterySurvey]
	                            ,[DEARegulated]
	                            ,[Narcotic]
	                            ,[DrugScheduleCode]
	                            ,[NDCNumber]
	                            ,[NDCFormat]
	                            ,[NDCFormatDescription]
	                            ,[Disinfectant]
	                            ,[Allergic]
	                            ,[GlutenFree]
	                            ,[OrganicTypesID]
	                            ,[GreenLeaf]
	                            ,[Pesticide]
	                            ,[Liquor]
	                            ,[LiquorDescription]
	                            ,[Tobacco]
	                            ,[VariableWeightIndicator]
	                            ,[RandomWeight]
	                            ,[FoodStamp]
	                            ,[UnitPricingCount]
	                            ,[UnitPricingUOM]
	                            ,[TagCount]
	                            ,[TagSize]
	                            ,[SeasonalItem]
	                            ,[SeasonBeginDate]
	                            ,[SeasonEndDate]
	                            ,[MinDaysRequired]
	                            ,[MaxDaysRequired]
	                            ,[WhseShelfLife]
	                            ,[IgnoreQuantityCheck]
	                            ,[BioFlag]
	                            ,[ActivationProtectionEndDate]
	                            ,[ManuallyOrderedItem]
	                            ,[NutritionalInfoNotAvailableUntil]
	                            ,[CreatedBy]
	                            ,[CreatedDate]
	                            ,[LastUpdatedBy]
	                            ,[LastUpdatedDate])
                            SELECT
	                             @NewItemFormID     
	                            ,[NutritionalPanelTypeID]
	                            ,[PerishableItem]
	                            ,[ProductDate]
	                            ,[BornOnDays]
	                            ,[CountryOfOrigin]           
	                            ,[Ignitable]
	                            ,[Corrosive]
	                            ,[Reactive]
	                            ,[Toxic]
	                            ,[EPAListedWaste]
	                            ,[ContainsBattery]
	                            ,[EMailForBatterySurvey]
	                            ,[DEARegulated]
	                            ,[Narcotic]
	                            ,[DrugScheduleCode]
	                            ,[NDCNumber]
	                            ,[NDCFormat]
	                            ,[NDCFormatDescription]
	                            ,[Disinfectant]
	                            ,[Allergic]
	                            ,[GlutenFree]
	                            ,[OrganicTypesID]
	                            ,[GreenLeaf]
	                            ,[Pesticide]
	                            ,[Liquor]
	                            ,[LiquorDescription]
	                            ,[Tobacco]
	                            ,[VariableWeightIndicator]
	                            ,[RandomWeight]
	                            ,[FoodStamp]
	                            ,[UnitPricingCount]
	                            ,[UnitPricingUOM]
	                            ,[TagCount]
	                            ,[TagSize]
	                            ,[SeasonalItem]
	                            ,[SeasonBeginDate]
	                            ,[SeasonEndDate]
	                            ,[MinDaysRequired]
	                            ,[MaxDaysRequired]
	                            ,[WhseShelfLife]
	                            ,[IgnoreQuantityCheck]
	                            ,[BioFlag]
	                            ,[ActivationProtectionEndDate]
	                            ,[ManuallyOrderedItem]
	                            ,[NutritionalInfoNotAvailableUntil]
	                            ,'SYSTEM'
	                            ,GetDate()  
	                            ,'SYSTEM'
	                            ,GetDate()
                            FROM [dbo].[GeneralProductAttribute] WHERE ItemFormID = @ItemFormID; 
                             -- INSERT Nutritional Panel
                            DECLARE @NutritionalPanelIDs TABLE ( NutritionalPanelID INT PRIMARY KEY, [NutritionalPanelName] VARCHAR(250), [SortOrder] INT ) 
                            INSERT INTO [dbo].[NutritionalPanel]
                                 ([ItemFormID]        
                                 ,[NutritionalPanelName]
                                 ,[GTIN]
                                 ,[GTINCheckDigit] 
                                 ,[ContainsAllergen]
                                 ,[ServingSize]
                                 ,[ServingsPerContainer]
                                 ,[SortOrder]
                                 ,[CreatedBy]
                                 ,[CreatedDate]
                                 ,[LastUpdatedBy]
                                 ,[LastUpdatedDate])
                               OUTPUT inserted.ID, inserted.NutritionalPanelName, inserted.SortOrder INTO @NutritionalPanelIDs
                            SELECT 
                                  @NewItemFormID       
                                 ,[NutritionalPanelName]
                                 ,NULL
                                 ,NULL
                                 ,[ContainsAllergen]
                                 ,[ServingSize]
                                 ,[ServingsPerContainer]
                                 ,[SortOrder]
                                 ,'SYSTEM'
                                 ,GetDate()
                                 ,'SYSTEM'
                                 ,GetDate()
                                  FROM [dbo].[NutritionalPanel] WHERE ItemFormID = @ItemFormID;

                            INSERT INTO [dbo].[NutritionalInfo]
                                 ([NutritionalPanelID]
                                 ,[NutrDictionaryID]
                                 ,[NutrientName]
                                 ,[Quantity]
                                 ,[UOM]
                                 ,[DailyValuePercentage]
                                 ,[IsRequired]
                                 ,[SortOrder]
                                 ,[CreatedBy]
                                 ,[CreatedDate]
                                 ,[LastUpdatedBy]
                                 ,[LastUpdatedDate])
                            SELECT 
                                  NPID.[NutritionalPanelID]  
                                 ,NI.[NutrDictionaryID]
                                 ,NI.[NutrientName]
                                 ,NI.[Quantity]
                                 ,NI.[UOM]
                                 ,NI.[DailyValuePercentage]
                                 ,NI.[IsRequired]
                                 ,NI.[SortOrder]
                                 ,'SYSTEM'
                                 ,GetDate()
                                 ,'SYSTEM'
                                 ,GetDate()
                            FROM [dbo].[NutritionalInfo] NI
                                  INNER JOIN [dbo].[NutritionalPanel] NP ON NI.NutritionalPanelID = NP.ID
                                  INNER JOIN @NutritionalPanelIDs NPID ON NP.[NutritionalPanelName] = NPID.[NutritionalPanelName] AND NP.[SortOrder] = NPID.[SortOrder]
                                  WHERE NP.ItemFormID = @ItemFormID;

                            INSERT INTO [dbo].[NutritionalAllergenInfo]
                                 ([NutritionalPanelID]
                                 ,[NutrDictionaryID]
                                 ,[AllergenName]
                                 ,[Value]
                                 ,[SortOrder]
                                 ,[CreatedBy]
                                 ,[CreatedDate]
                                 ,[LastUpdatedBy]
                                 ,[LastUpdatedDate])
                            SELECT 
                                  NPID.[NutritionalPanelID]  
                                 ,NA.[NutrDictionaryID]
                                 ,NA.[AllergenName]
                                 ,NA.[Value]
                                 ,NA.[SortOrder]
                                 ,'SYSTEM'
                                 ,GetDate()
                                 ,'SYSTEM'
                                 ,GetDate()
                                  FROM [dbo].[NutritionalAllergenInfo] NA
                            INNER JOIN [dbo].[NutritionalPanel] NP ON NA.NutritionalPanelID = NP.ID
                            INNER JOIN @NutritionalPanelIDs NPID ON NP.[NutritionalPanelName] = NPID.[NutritionalPanelName] AND NP.[SortOrder] = NPID.[SortOrder]
                            WHERE NP.ItemFormID = @ItemFormID;

                            -- INSERT Shipper Item Composition
                            INSERT INTO [dbo].[ShipperItemComposition]
	                            ([ItemFormID]
	                            ,[CompositionItemCode]
	                            ,[CompositionItemDescription]
	                            ,[CompositionItemTypeCode]
	                            ,[CompositionGTIN]
	                            ,[CompositionGTINCheckDigit]
	                            ,[Quantity]
	                            ,[CompositionUOM]
	                            ,[CompositionUOMDescription]
	                            ,[SubDepartmentID]
	                            ,[SubDepartment]
	                            ,[CreatedBy]
	                            ,[CreatedDate]
	                            ,[LastUpdatedBy]
	                            ,[LastUpdatedDate])
                            SELECT 
	                              @NewItemFormID
	                            ,[CompositionItemCode]
	                            ,[CompositionItemDescription]
	                            ,[CompositionItemTypeCode]
	                            ,[CompositionGTIN]
	                            ,[CompositionGTINCheckDigit]
	                            ,[Quantity]
	                            ,[CompositionUOM]
	                            ,[CompositionUOMDescription]
	                            ,[SubDepartmentID]
	                            ,[SubDepartment]
	                            ,'SYSTEM'
	                            ,GetDate()  
	                            ,'SYSTEM'
	                            ,GetDate()
                            FROM [dbo].[ShipperItemComposition] WHERE ItemFormID = @ItemFormID; 

                            -- INSERT Packaging Hierarchy
                            DECLARE @PackagingHierarchyIDs TABLE (PackagingHierarchyID INT PRIMARY KEY, RetailPackType VARCHAR(15), RetailPackSize INT, Size DECIMAL(11,4), SizeUOM VARCHAR(2), LabelAmount DECIMAL(5,2)) 
                            INSERT INTO [dbo].[PackagingHierarchy]
	                            ([ItemFormID]
	                            ,[RetailPackType]
	                            ,[RetailPackTypeDescription]
	                            ,[RetailPackSize]
	                            ,[Size]
	                            ,[SizeUOM]
	                            ,[SizeUOMDescription]
	                            ,[LabelAmount]
	                            ,[MasterCaseCodeType]
	                            ,[MasterCaseGTIN]
	                            ,[MasterCaseGTINCheckDigit]
	                            ,[MasterCaseVendorItemGTIN]
	                            ,[MasterCaseSellingUnit]
	                            ,[MasterCaseWeight]
	                            ,[MasterCaseNetWeight]
	                            ,[MasterCaseHeight]
	                            ,[MasterCaseLength]
	                            ,[MasterCaseDepth]
	                            ,[MasterCaseCubicFootage]
	                            ,[InnerPackExist]
	                            ,[InnerCaseCodeType]
	                            ,[InnerCaseGTIN]
	                            ,[InnerCaseGTINCheckDigit]
	                            ,[InnerCaseSellingUnits]
	                            ,[InnerCaseWeight]
	                            ,[InnerCaseNetWeight]
	                            ,[InnerCaseHeight]
	                            ,[InnerCaseLength]
	                            ,[InnerCaseDepth]
	                            ,[InnerCaseCubicFootage]
	                            ,[MasterCasesInSinglePalletLayer]
	                            ,[LayersOnPallet]
	                            ,[PalletGTIN]
	                            ,[PalletQuantity]
	                            ,[PalletCubicFootage]
	                            ,[CreatedBy]
	                            ,[CreatedDate]
	                            ,[LastUpdatedBy]
	                            ,[LastUpdatedDate])
	                            OUTPUT inserted.ID, inserted.[RetailPackType], inserted.[RetailPackSize], inserted.[Size], inserted.[SizeUOM], inserted.[LabelAmount]  INTO @PackagingHierarchyIDs
                            SELECT 
	                             @NewItemFormID 
	                            ,PH.[RetailPackType]
	                            ,PH.[RetailPackTypeDescription]
	                            ,PH.[RetailPackSize]
	                            ,PH.[Size]
	                            ,PH.[SizeUOM]
	                            ,PH.[SizeUOMDescription]
	                            ,PH.[LabelAmount]
	                            ,PH.[MasterCaseCodeType]
	                            ,PH.[MasterCaseGTIN]
	                            ,PH.[MasterCaseGTINCheckDigit]
	                            ,PH.[MasterCaseVendorItemGTIN]
	                            ,PH.[MasterCaseSellingUnit]
	                            ,PH.[MasterCaseWeight]
	                            ,PH.[MasterCaseNetWeight]
	                            ,PH.[MasterCaseHeight]
	                            ,PH.[MasterCaseLength]
	                            ,PH.[MasterCaseDepth]
	                            ,PH.[MasterCaseCubicFootage]
	                            ,PH.[InnerPackExist]
	                            ,PH.[InnerCaseCodeType]
	                            ,PH.[InnerCaseGTIN]
	                            ,PH.[InnerCaseGTINCheckDigit]
	                            ,PH.[InnerCaseSellingUnits]
	                            ,PH.[InnerCaseWeight]
	                            ,PH.[InnerCaseNetWeight]
	                            ,PH.[InnerCaseHeight]
	                            ,PH.[InnerCaseLength]
	                            ,PH.[InnerCaseDepth]
	                            ,PH.[InnerCaseCubicFootage]
	                            ,PH.[MasterCasesInSinglePalletLayer]
	                            ,PH.[LayersOnPallet]
	                            ,PH.[PalletGTIN]
	                            ,PH.[PalletQuantity]
	                            ,PH.[PalletCubicFootage]
	                            ,'SYSTEM'
	                            ,GetDate()
	                            ,'SYSTEM'
	                            ,GetDate()
                            FROM [dbo].[PackagingHierarchy] PH
                            INNER JOIN [dbo].[BasicItemDefinition] BID ON PH.ItemFormID = BID.ItemFormID
                            WHERE PH.ItemFormID = @ItemFormID AND EXISTS (SELECT PH.RetailPackType,PH.RetailPackSize,PH.Size,PH.SizeUOM,PH.LabelAmount INTERSECT 
											  SELECT BID.RetailPackType,BID.RetailPackSize,BID.Size,BID.SizeUOM,BID.LabelAmount);

                            INSERT INTO [dbo].[OrderablePackLevel]
	                            ([PackagingHierarchyID]
	                            ,[InsertedByUserTypeID]
	                            ,[VendorNumber]
	                            ,[VendorDescription]
	                            ,[VendorType]
	                            ,[Warehouse]
	                            ,[WarehouseDescription]
	                            ,[OrderingPackagingLevelID]
	                            ,[OrderingPackagingLevelDescription]
	                            ,[OrderPackQuantity]
	                            ,[ShippingPackagingLevelID]
	                            ,[ShippingPackagingLevelDescription]
	                            ,[ShippingPackQty]
	                            ,[ShipMax]
	                            ,[ShipPallet]
	                            ,[EffectiveDate]
	                            ,[TerminationDate]
	                            ,[PrimaryVendor]
	                            ,[CreatedBy]
	                            ,[CreatedDate]
	                            ,[LastUpdatedBy]
	                            ,[LastUpdatedDate])
                            SELECT 
	                             PHID.PackagingHierarchyID
	                            ,OL.[InsertedByUserTypeID]
	                            ,OL.[VendorNumber]
	                            ,OL.[VendorDescription]
	                            ,OL.[VendorType]
	                            ,OL.[Warehouse]
	                            ,OL.[WarehouseDescription]
	                            ,OL.[OrderingPackagingLevelID]
	                            ,OL.[OrderingPackagingLevelDescription]
	                            ,OL.[OrderPackQuantity]
	                            ,OL.[ShippingPackagingLevelID]
	                            ,OL.[ShippingPackagingLevelDescription]
	                            ,OL.[ShippingPackQty]
	                            ,OL.[ShipMax]
	                            ,OL.[ShipPallet]
	                            ,OL.[EffectiveDate]
	                            ,OL.[TerminationDate]
	                            ,OL.[PrimaryVendor]
	                            ,'SYSTEM'
	                            ,GetDate()
	                            ,'SYSTEM'
	                            ,GetDate()	
                            FROM [dbo].[OrderablePackLevel] OL
                            INNER JOIN [dbo].[PackagingHierarchy] PH ON OL.PackagingHierarchyID = PH.ID 
                            INNER JOIN @PackagingHierarchyIDs PHID ON EXISTS (SELECT PH.RetailPackType,PH.RetailPackSize,PH.Size,PH.SizeUOM,PH.LabelAmount INTERSECT 
											                                  SELECT PHID.RetailPackType,PHID.RetailPackSize,PHID.Size,PHID.SizeUOM,PHID.LabelAmount)
                            WHERE PH.ItemFormID = @ItemFormID;

                            -- INSERT DSDAuthRequestStore
                            INSERT INTO [dbo].[DSDAuthRequestStore]
	                            ([ItemFormID]
	                            ,[VendorNumber]
	                            ,[VendorName]
	                            ,[StoreNumber]
	                            ,[StateCode]
	                            ,[StateName]
	                            ,[CountyCode]
	                            ,[CountyName]
	                            ,[IsActive]
	                            ,[CreatedBy]
	                            ,[CreatedDate]
	                            ,[LastUpdatedBy]
	                            ,[LastUpdatedDate])
                            SELECT
	                             @NewItemFormID
	                            ,[VendorNumber]
	                            ,[VendorName]
	                            ,[StoreNumber]
	                            ,[StateCode]
	                            ,[StateName]
	                            ,[CountyCode]
	                            ,[CountyName]
	                            ,[IsActive]
	                            ,'SYSTEM'
	                            ,GetDate()
	                            ,'SYSTEM'
	                            ,GetDate()
	                            FROM [dbo].[DSDAuthRequestStore]
	                            WHERE ItemFormID = @ItemFormID AND VendorNumber 
	                            IN (SELECT VendorNumber FROM [dbo].[PackagingHierarchy] PH	
                                INNER JOIN @PackagingHierarchyIDs PHID ON EXISTS (SELECT PH.RetailPackType,PH.RetailPackSize,PH.Size,PH.SizeUOM,PH.LabelAmount INTERSECT 
											                                      SELECT PHID.RetailPackType,PHID.RetailPackSize,PHID.Size,PHID.SizeUOM,PHID.LabelAmount)
	                            INNER JOIN [dbo].[OrderablePackLevel] ON OrderablePackLevel.PackagingHierarchyID = PH.ID
	                            WHERE PH.ItemFormID = @ItemFormID AND OrderablePackLevel.VendorType = 'DSD');

                            -- INSERT Product Grouping
                            INSERT INTO [dbo].[ProductGrouping]
	                            ([ItemFormID]
	                            ,[ChildProductGroupType]
	                            ,[ChildProductGroupCode]
	                            ,[ChildProductGroupDescription]
	                            ,[ItemTag] 
	                            ,[ParentProductGroupType]
	                            ,[ParentProductGroupCode]
	                            ,[ParentProductGroupDescription]
	                            ,[GrandParentProductGroupType]
	                            ,[GrandParentProductGroupCode]
	                            ,[GrandParentProductGroupDescription]
	                            ,[CreatedBy]
	                            ,[CreatedDate]
	                            ,[LastUpdatedBy]
	                            ,[LastUpdatedDate])
                            SELECT 
	                             @NewItemFormID
	                            ,[ChildProductGroupType]
	                            ,[ChildProductGroupCode]
	                            ,[ChildProductGroupDescription]
	                            ,[ItemTag] 
	                            ,[ParentProductGroupType]
	                            ,[ParentProductGroupCode]
	                            ,[ParentProductGroupDescription]
	                            ,[GrandParentProductGroupType]
	                            ,[GrandParentProductGroupCode]
	                            ,[GrandParentProductGroupDescription]
	                            ,'SYSTEM'
	                            ,GetDate()
	                            ,'SYSTEM'
	                            ,GetDate()
                            FROM [dbo].[ProductGrouping] WHERE ItemFormID = @ItemFormID;

                            -- INSERT Product Attributes
                            INSERT INTO [dbo].[ProductAttribute]
	                            ([ItemFormID]
	                            ,[ProductAttributeGroupCode]
	                            ,[ProductAttributeGroupDescription]
	                            ,[ProductAttributeType]
	                            ,[AttributeType]
	                            ,[AttributeCode]
	                            ,[AttributeDescription]
	                            ,[AttributeValueSequenceNumber]
	                            ,[AttributeValueDisplayText]
	                            ,[NewAttributeValue]
	                            ,[NewAttributeApprovalIndicator]
	                            ,[NewAttributeApprovedBy]
	                            ,[NewAttributeApprovedDate]
	                            ,[EffectiveDate]
	                            ,[TerminationDate]
	                            ,[ItemGroupType]
	                            ,[ItemGroupCode]
	                            ,[CreatedBy]
	                            ,[CreatedDate]
	                            ,[LastUpdatedBy]
	                            ,[LastUpdatedDate])
                            SELECT 
	                              @NewItemFormID
	                             ,[ProductAttributeGroupCode]
	                             ,[ProductAttributeGroupDescription]
	                             ,[ProductAttributeType]
	                             ,[AttributeType]
	                             ,[AttributeCode]
	                             ,[AttributeDescription]
	                             ,[AttributeValueSequenceNumber]
	                             ,[AttributeValueDisplayText]
	                             ,[NewAttributeValue]
	                             ,[NewAttributeApprovalIndicator]
	                             ,[NewAttributeApprovedBy]
	                             ,[NewAttributeApprovedDate]
	                             ,[EffectiveDate]
	                             ,[TerminationDate]
	                             ,[ItemGroupType]
	                             ,[ItemGroupCode]
	                             ,'SYSTEM'
	                             ,GetDate()
	                             ,'SYSTEM'
	                             ,GetDate()
                            FROM [dbo].[ProductAttribute] WHERE ItemFormID = @ItemFormID;
                            -- INSERT Scale Item tables
                            -- INSERT Scale Info
                            INSERT INTO [dbo].[ScaleInfo]
                                       ([ItemFormID]
                                       ,[BackroomScaleIndicator]
                                       ,[ScaleDescription1]
                                       ,[ScaleDescription2]
                                       ,[CalorieInformation]
                                       ,[Tare]
                                       ,[ScaleExtraTextRequired]
                                       ,[PriceModifier]
                                       ,[NutritionCodeRequired]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                            SELECT @NewItemFormID
                                  ,[BackroomScaleIndicator]
                                  ,[ScaleDescription1]
                                  ,[ScaleDescription2]
                                  ,[CalorieInformation]
                                  ,[Tare]
                                  ,[ScaleExtraTextRequired]
                                  ,[PriceModifier]
                                  ,[NutritionCodeRequired]
	                              ,'SYSTEM'
	                              ,GetDate()
	                              ,'SYSTEM'
	                              ,GetDate()
                              FROM [dbo].[ScaleInfo] WHERE ItemFormID = @ItemFormID;
                            -- INSERT Scale Override Description
                            INSERT INTO [dbo].[ScaleOverrideDescription]
                                       ([ItemFormID]
                                       ,[FacilityGroupType]
                                       ,[FacilityGroupTypeDescription]
                                       ,[FacilityGroupCode]
                                       ,[FacilityGroupDescription]
                                       ,[OverrideDescriptionLine1]
                                       ,[OverrideDescriptionLine2]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                            SELECT @NewItemFormID
                                  ,[FacilityGroupType]
                                  ,[FacilityGroupTypeDescription]
                                  ,[FacilityGroupCode]
                                  ,[FacilityGroupDescription]
                                  ,[OverrideDescriptionLine1]
                                  ,[OverrideDescriptionLine2]
	                              ,'SYSTEM'
	                              ,GetDate()
	                              ,'SYSTEM'
	                              ,GetDate()
                              FROM [dbo].[ScaleOverrideDescription] WHERE ItemFormID = @ItemFormID;
                            -- INSERT Scale Location
                            INSERT INTO [dbo].[ScaleLocation]
                                       ([ItemFormID]
                                       ,[ScaleLocation]
                                       ,[ScaleLocationDescription]
                                       ,[Action]
                                       ,[ActionDescription]
                                       ,[PLUNumber]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                            SELECT @NewItemFormID
                                  ,[ScaleLocation]
                                  ,[ScaleLocationDescription]
                                  ,[Action]
                                  ,[ActionDescription]
                                  ,[PLUNumber]
	                              ,'SYSTEM'
	                              ,GetDate()
	                              ,'SYSTEM'
	                              ,GetDate()
                            FROM [dbo].[ScaleLocation] WHERE ItemFormID = @ItemFormID;
                            -- INSERT Scale Shelf Life
                            INSERT INTO [dbo].[ScaleShelfLife]
                                       ([ItemFormID]
                                       ,[FacilityGroupType]
                                       ,[FacilityGroupTypeDescription]
                                       ,[FacilityGroupCode]
                                       ,[FacilityGroupDescription]
                                       ,[ShelfLifeDay]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                            SELECT @NewItemFormID
                                  ,[FacilityGroupType]
                                  ,[FacilityGroupTypeDescription]
                                  ,[FacilityGroupCode]
                                  ,[FacilityGroupDescription]
                                  ,[ShelfLifeDay]
	                              ,'SYSTEM'
	                              ,GetDate()
	                              ,'SYSTEM'
	                              ,GetDate()
                            FROM [dbo].[ScaleShelfLife] WHERE ItemFormID = @ItemFormID; 
                            -- INSERT Scale Grade
                            INSERT INTO [dbo].[ScaleGrade]
                                       ([ItemFormID]
                                       ,[FacilityGroupType]
                                       ,[FacilityGroupTypeDescription]
                                       ,[FacilityGroupCode]
                                       ,[FacilityGroupDescription]
                                       ,[Grade]
                                       ,[GradeDescription]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                            SELECT @NewItemFormID
                                  ,[FacilityGroupType]
                                  ,[FacilityGroupTypeDescription]
                                  ,[FacilityGroupCode]
                                  ,[FacilityGroupDescription]
                                  ,[Grade]
                                  ,[GradeDescription]
	                              ,'SYSTEM'
	                              ,GetDate()
	                              ,'SYSTEM'
	                              ,GetDate()
                              FROM [dbo].[ScaleGrade] WHERE ItemFormID = @ItemFormID; 

                              -- INSERT Marketing Info
                            INSERT INTO [dbo].[MarketingInfo]
                                       ([ItemFormID]
                                       ,[ProjectedSales52Weeks]
                                       ,[UnitCost]
                                       ,[UnitCostUOM]
                                       ,[SuggestedRetail]
                                       ,[SuggestedMargin]
                                       ,[ItemPreviouslyPresented]
                                       ,[AvailableShipDate]
                                       ,[NewItemFundsAvailable]
                                       ,[NewItemFundsAmount]
                                       ,[PromoSupportFrequency]
                                       ,[MediaSupport]
                                       ,[LocalChainPresentlyStocking]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                            SELECT @NewItemFormID
                                  ,[ProjectedSales52Weeks]
                                  ,[UnitCost]
                                  ,[UnitCostUOM]
                                  ,[SuggestedRetail]
                                  ,[SuggestedMargin]
                                  ,[ItemPreviouslyPresented]
                                  ,[AvailableShipDate]
                                  ,[NewItemFundsAvailable]
                                  ,[NewItemFundsAmount]
                                  ,[PromoSupportFrequency]
                                  ,[MediaSupport]
                                  ,[LocalChainPresentlyStocking]
	                              ,'SYSTEM'
	                              ,GetDate()
	                              ,'SYSTEM'
	                              ,GetDate()
                              FROM [dbo].[MarketingInfo] WHERE ItemFormID = @ItemFormID; 

                              -- UPDATE Similar Item GTIN
                              UPDATE [dbo].[SimilarItemGTIN]
                               SET [SimilarGTINNewItemFormID] = @NewItemFormID
                                  ,[LastUpdatedBy] = 'SYSTEM'
                                  ,[LastUpdatedDate] = GetDate()
                             WHERE [ItemFormID] = @ItemFormID AND SimilarGTIN = @GTIN;";
        //private const string InsertMarketingInfoSQL = @" INSERT INTO [dbo].[MarketingInfo]
        //                              ([ItemFormID]
        //                              ,[ProjectedSales52Weeks]
        //                              ,[UnitCost]
        //                              ,[UnitCostUOM]
        //                              ,[SuggestedRetail]
        //                              ,[SuggestedMargin]   
        //                              ,[ItemPreviouslyPresented]
        //                              ,[AvailableShipDate]
        //                              ,[NewItemFundsAvailable]
        //                              ,[NewItemFundsAmount]
        //                              ,[PromoSupportFrequency]
        //                              ,[MediaSupport]
        //                              ,[LocalChainPresentlyStocking]
        //                              ,[CreatedBy]
        //                              ,[CreatedDate]
        //                              ,[LastUpdatedBy]
        //                              ,[LastUpdatedDate])
        //                         VALUES
        //                              (@ItemFormID
        //                              ,@ProjectedSales52Weeks
        //                              ,@UnitCost
        //                              ,@UnitCostUOM
        //                              ,@SuggestedRetail
        //                              ,@SuggestedMargin      
        //                              ,@ItemPreviouslyPresented
        //                              ,@AvailableShipDate
        //                              ,@NewItemFundsAvailable
        //                              ,@NewItemFundsAmount
        //                              ,@PromoSupportFrequency
        //                              ,@MediaSupport
        //                              ,@LocalChainPresentlyStocking
        //                              ,@CreatedBy
        //                              ,GetDate()
        //                              ,@LastUpdatedBy
        //                              ,GetDate())";

        //private const string UpdateMarketingInfoSQL = @"UPDATE [dbo].[MarketingInfo]
        //                           SET 
        //                               [ProjectedSales52Weeks] = @ProjectedSales52Weeks
        //                              ,[UnitCost] = @UnitCost
        //                              ,[UnitCostUOM] = @UnitCostUOM
        //                              ,[SuggestedRetail] = @SuggestedRetail
        //                              ,[SuggestedMargin] = @SuggestedMargin      
        //                              ,[ItemPreviouslyPresented] = @ItemPreviouslyPresented
        //                              ,[AvailableShipDate] = @AvailableShipDate
        //                              ,[NewItemFundsAvailable] = @NewItemFundsAvailable
        //                              ,[NewItemFundsAmount] = @NewItemFundsAmount
        //                              ,[PromoSupportFrequency] = @PromoSupportFrequency
        //                              ,[MediaSupport] = @MediaSupport
        //                              ,[LocalChainPresentlyStocking] = @LocalChainPresentlyStocking
        //                              ,[LastUpdatedBy] = @LastUpdatedBy
        //                              ,[LastUpdatedDate] = getDate()
        //                         WHERE ItemFormID = @ItemFormID";

        #endregion
    }
}
