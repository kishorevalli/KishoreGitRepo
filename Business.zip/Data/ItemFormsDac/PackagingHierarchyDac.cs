﻿using Dapper;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class PackagingHierarchyDac : BaseDac, IPackagingHierarchyDac
    {
        public async Task<IEnumerable<RetailPackTypeDto>> GetRetailPackTypesForItemForm(int itemFormID)
        {
          
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    return (await conn.QueryAsync<RetailPackTypeDto>(GetRetailPackTypesSQL, new { @itemFormID = itemFormID } ));
                }         
          
        }

        public async Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchies(int itemFormID)
        {
           List<PackagingHierarchyDto> packagingHierarchiesList = new List<PackagingHierarchyDto>();

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
              var  packagingHierarchies = await conn.QueryAsync<PackagingHierarchyDto>(GetPackagingHierarchyForItemFormSQL, new { @ItemFormID = itemFormID });
                foreach (var packagingHierarchy in packagingHierarchies)
                {
                    var orderablePackLevels = await GetOrderablePackLevels(packagingHierarchy.ID);
                    packagingHierarchy.orderablePackLevels = orderablePackLevels.ToList();
                    packagingHierarchiesList.Add(packagingHierarchy);
                }
            }

            return packagingHierarchiesList;
        }


        public async Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchiesByModelItemCode(int? itemFormId)
        {

           
                List<PackagingHierarchyDto> packagingHierarchiesList = new List<PackagingHierarchyDto>();
            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    var packagingHierarchies = await conn.QueryAsync<PackagingHierarchyDto>(GetPackagingHierarchyByItemCodeSQL, new { @ItemformId = itemFormId });
                    foreach (var packagingHierarchy in packagingHierarchies)
                    {
                        var orderablePackLevels = await GetOrderablePackLevels(packagingHierarchy.ID);
                        packagingHierarchy.orderablePackLevels = orderablePackLevels.ToList();
                        packagingHierarchiesList.Add(packagingHierarchy);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return packagingHierarchiesList;
        }


        public async Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchiesByModelGTIN(decimal gtin)
        {
            List<PackagingHierarchyDto> packagingHierarchiesList = new List<PackagingHierarchyDto>();

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                var packagingHierarchies = await conn.QueryAsync<PackagingHierarchyDto>(GetPackagingHierarchyByGtinSQL, new { @Gtin = gtin });
                foreach (var packagingHierarchy in packagingHierarchies)
                {
                    var orderablePackLevels = await GetOrderablePackLevels(packagingHierarchy.ID);
                    packagingHierarchy.orderablePackLevels = orderablePackLevels.ToList();
                    packagingHierarchiesList.Add(packagingHierarchy);
                }
            }

            return packagingHierarchiesList;
        }
        

        public async Task<IEnumerable<OrderablePackLevelDto>> GetOrderablePackLevels(int packagingHierarchyID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<OrderablePackLevelDto>(GetOrderablePackLevelsForPHSQL, new { @PackagingHierarchyID = packagingHierarchyID });
            }

        }

        public async Task<IEnumerable<CaseCodeTypeDto>> GetCaseCodeTypes()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                 await conn.OpenAsync();
                return (await conn.QueryAsync<CaseCodeTypeDto>(GetCaseCodeTypesSQL));
            }
        }


        public async Task<IEnumerable<OrderingLevelsDto>> GetOrderingLevels()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<OrderingLevelsDto>(GetOrderingLevelsSQL));
            }            
        }

        public async Task<int> InsertPackagingHierarchy(PackagingHierarchyDto packagingHierarchy)
        {
            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    return await conn.ExecuteScalarAsync<int>(InsertPackagingHierarchySQL, packagingHierarchy);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public async Task InsertOrderabePackLevels(OrderablePackLevelDto orderablePackLevel)
        {
            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    await conn.ExecuteAsync(InsertIntoOrderablePackLevels, orderablePackLevel);

                }
            }
            catch 
            {
                throw;
            }
        }

        public async Task UpdatePackagingHierarchy(PackagingHierarchyDto packagingHierarchy)
        {
            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    await conn.ExecuteAsync(InsertIntoPackagingHierarchyAuditSQL, new { ID = packagingHierarchy.ID });
                    await conn.ExecuteAsync(UpdatePackagingHierarchySQL, packagingHierarchy);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public async Task UpdateOrderabePackLevels(OrderablePackLevelDto orderablePackLevel)
        //{
           
        //        using (var conn = (SqlConnection)base.S0VPITEM_Connection)
        //        {
        //            await conn.OpenAsync();
        //       // await conn.ExecuteAsync(InsertOrderablePackLevelsAuditSQL, new { @PackagingHierarchyID = orderablePackLevel.PackagingHierarchyID });
        //        await conn.ExecuteAsync(UpdateOrderabePackLevelsSQL, orderablePackLevel);
        //        }
          
        //}

        public async Task UpdatePrimaryVendorForWarehouse(WarehouseGtinDto warehouseDetails)
        {
            
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();                    
                    await conn.ExecuteAsync(UpdatePrimaryVendorSQL, warehouseDetails);
                }
           
        }

        public async Task<int> IsPackagingHierarchyExistsForItemForm(PackagingHierarchyDto packagingHierarchy)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    var phID = await conn.ExecuteScalarAsync<int>(GetPHCountByItemFormIDSQL, packagingHierarchy);
                    return phID;
                   // return count > 0 ? true : false;
                }
                catch
                {
                    throw;
                }

            }
        }

        public async Task<int> IsPrimaryVendorExistsForWHByGtin(WarehouseGtinDto warehouseDetails)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    var count = await conn.ExecuteScalarAsync<int>(IsPrimaryVendorExistsForWHByGtinSQL, warehouseDetails);
                    return count ;
                }
                catch
                {
                    throw;
                }

            }
        }
        public async Task<IEnumerable<int>> GetValidItemFormIDForModellingByModelPHItemCode(int? modelItemCode , int? itemformId, List<int> userVendors , UserType userType)
        {
            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    if (userType == UserType.Vendor)
                    {
                        //int[] vendors = userVendors.ToArray();
                        string vendors = string.Join(",", userVendors);
                        return (await conn.QueryAsync<int>(GetItemFormIDForModellingByModelPHItemCodeSQL, new { @modelItemCode = modelItemCode, @itemformId = itemformId, @userVendors = vendors }));
                    }
                    else
                    {
                        return (await conn.QueryAsync<int>(GetItemFormIDForModellingByModelPHItemCodeBuyerSQL, new { @modelItemCode = modelItemCode, @itemformId = itemformId}));
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            
       }


        public async Task<IEnumerable<int>> GetValidItemFormIDForModellingByGtin(decimal gtin, int? itemformId, List<int> userVendors, UserType userType)
        {
            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    if (userType == UserType.Vendor)
                    {
                        //int[] vendors = userVendors.ToArray();
                        string vendors = string.Join(",", userVendors);
                        return (await conn.QueryAsync<int>(GetItemFormIDForModellingByGtinSQL, new { @Gtin = gtin, @itemformId = itemformId, @userVendors = vendors }));
                    }
                    else
                    {
                        return (await conn.QueryAsync<int>(GetItemFormIDForModellingByGtinBuyerSQL, new { @Gtin = gtin, @itemformId = itemformId }));
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }


        }


        public async Task<bool> DeleteOrderingLevels(int packagingHierarchyID , bool isModelling)
        {

            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    await conn.ExecuteAsync(InsertOrderablePackLevelsAuditSQL, new { @PackagingHierarchyID = packagingHierarchyID });
                    await conn.ExecuteAsync(DeleteOrderablePackLevelsSql, new { @PackagingHierarchyID = packagingHierarchyID });                    
                    retValue = true;
                }
                catch
                {
                    throw;
                }


            }
            return retValue;
        }

        public async Task<bool> DeletePackagingHierarchies(GTINRetailPackInfoDto gtinRetailPackInfo)
        {

            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    await conn.ExecuteAsync(InsertIntoPackagingHierarchyAuditSQL, new { @ID = gtinRetailPackInfo.PackagingHierarchiesList });
                    await conn.ExecuteAsync(DeletePackagingHierarchiesSql, new {@IDs = gtinRetailPackInfo.PackagingHierarchiesList });
                    retValue = true;
                }
                catch (Exception ex)
                {
                    throw;
                }


            }
            return retValue;
        }
        public async Task<IEnumerable<VendorDomainDto>> GetDsdVendorsExistInDsdForItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<VendorDomainDto>(GetDsdVendorsExistInDsdForItemFormSQL, new { ItemFormID = itemFormID });
            }
        }
        private const string GetPHCountByItemFormIDSQL = @" Select ID from PackagingHierarchy where ItemFormID = @ItemFormID and RetailPackType = @RetailPackType and
                                                                ((RetailPackSize = @RetailPackSize) or (RetailPackSize is null and @RetailPackSize is null)) 
															 and ((Size = @Size) or (Size is null and @Size is null)) 
															 and  SizeUOM = @SizeUOM 
															 and ((LabelAmount = @LabelAmount) or (LabelAmount is null and @LabelAmount is null))";

       private const string UpdateOrderabePackLevelsSQL = @"UPDATE [dbo].[OrderablePackLevel]
      SET 
       [InsertedByUserTypeID] = @InsertedByUserTypeID
      ,[VendorNumber] = @VendorNumber
      ,[VendorDescription] = @VendorDescription
      ,[VendorType] = @VendorType
      ,[Warehouse] = @Warehouse
      ,[WarehouseDescription] = @WarehouseDescription
      ,[OrderingPackagingLevelID] = @OrderingPackagingLevelID
      ,[OrderingPackagingLevelDescription] = @OrderingPackagingLevelDescription
      ,[OrderPackQuantity] = @OrderPackQuantity
      ,[ShippingPackagingLevelID] = @ShippingPackagingLevelID
      ,[ShippingPackagingLevelDescription] = @[ShippingPackagingLevelDescription]
      ,[ShippingPackQty] = @ShippingPackQty
      ,[ShipMax] = @ShipMax
      ,[ShipPallet] = @ShipPallet
      ,[EffectiveDate] = @EffectiveDate
      ,[TerminationDate] = @TerminationDate
      ,[PrimaryVendor] = @PrimaryVendor
      ,[CreatedBy] = @CreatedBy
      ,[CreatedDate] = @CreatedDate
      ,[LastUpdatedBy] = @LastUpdatedBy
      ,[LastUpdatedDate] = @LastUpdatedDate
     WHERE  [PackagingHierarchyID] = @PackagingHierarchyID AND [VendorNumber] = @VendorNumber"; 

        private const string GetRetailPackTypesSQL = @"Select  [RetailPackType], bid.[RetailPackTypeDescription] ,[RetailPackSize],[Size],[SizeUOM],[SizeUOMDescription],[LabelAmount] from [dbo].[BasicItemDefinition] bid 
  where bid.ItemFormID = @itemFormID and bid.[RetailPackType] != ''
  UNION 
    Select  [RetailPackType],agtin.[RetailPackTypeDescription],[RetailPackSize],[Size],[SizeUOM],[SizeUOMDescription],[LabelAmount] from [dbo].[AdditionalGTIN] agtin 
  where agtin.ItemFormID = @itemFormID and agtin.[RetailPackType] != '' ";

        private const string GetCaseCodeTypesSQL = @"SELECT [CaseCodeType]
      ,[CaseTypeDesc]
      ,[SortOrder]
  FROM [dbo].[CaseCodeType] order by SortOrder";

        private const string GetOrderingLevelsSQL = @"SELECT [ID]
      ,[Name]      
      ,[SortOrder]
  FROM [dbo].[OrderingLevels] where IsActive = 1 order by sortorder";


        private const string GetPackagingHierarchyForItemFormSQL = @"SELECT PH.[ID]
      ,[ItemFormID]
      ,[RetailPackType]
      ,[RetailPackTypeDescription]
      ,[RetailPackSize]
      ,[Size]
      ,[SizeUOM]
      ,[SizeUOMDescription]
      ,[LabelAmount]
      ,[MasterCaseCodeType]
      ,[MasterCaseGTIN]
      ,[MasterCaseGTINCheckDigit]
      ,[MasterCaseVendorItemGTIN]
      ,[MasterCaseSellingUnit]
      ,[MasterCaseWeight]
      ,[MasterCaseNetWeight]
      ,[MasterCaseHeight]
      ,[MasterCaseLength]
      ,[MasterCaseDepth]
      ,[MasterCaseCubicFootage]
      ,[InnerPackExist]
      ,[InnerCaseCodeType]
      ,[InnerCaseGTIN]
      ,[InnerCaseGTINCheckDigit]
      ,[InnerCaseSellingUnits]
      ,[InnerCaseWeight]
      ,[InnerCaseNetWeight]
      ,[InnerCaseHeight]
      ,[InnerCaseLength]
      ,[InnerCaseDepth]
      ,[InnerCaseCubicFootage]
      ,[MasterCasesInSinglePalletLayer]
      ,[LayersOnPallet]
      ,[PalletGTIN]
      ,[PalletQuantity]
      ,[PalletCubicFootage]      
      ,IFM.FormStatusID
    FROM [dbo].[PackagingHierarchy] PH
  INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID
  WHERE PH.ItemFormID = @ItemFormID";


        //      private const string GetPackagingHierarchyByItemCodeSQL = @"SELECT PH.[ID]
        //    ,[ItemFormID]
        //    ,[RetailPackType]
        //    ,[RetailPackTypeDescription]
        //    ,[RetailPackSize]
        //    ,[Size]
        //    ,[SizeUOM]
        //    ,[SizeUOMDescription]
        //    ,[LabelAmount]
        //    ,[MasterCaseCodeType]
        //    ,[MasterCaseGTIN]
        //    ,[MasterCaseGTINCheckDigit]
        //    ,[MasterCaseVendorItemGTIN]
        //    ,[MasterCaseSellingUnit]
        //    ,[MasterCaseWeight]
        //    ,[MasterCaseNetWeight]
        //    ,[MasterCaseHeight]
        //    ,[MasterCaseLength]
        //    ,[MasterCaseDepth]
        //    ,[MasterCaseCubicFootage]
        //    ,[InnerPackExist]
        //    ,[InnerCaseCodeType]
        //    ,[InnerCaseGTIN]
        //    ,[InnerCaseGTINCheckDigit]
        //    ,[InnerCaseSellingUnits]
        //    ,[InnerCaseWeight]
        //    ,[InnerCaseNetWeight]
        //    ,[InnerCaseHeight]
        //    ,[InnerCaseLength]
        //    ,[InnerCaseDepth]
        //    ,[InnerCaseCubicFootage]
        //    ,[MasterCasesInSinglePalletLayer]
        //    ,[LayersOnPallet]
        //    ,[PalletGTIN]
        //    ,[PalletQuantity]
        //    ,[PalletCubicFootage]      
        //    ,IFM.FormStatusID
        //  FROM [dbo].[PackagingHierarchy] PH
        //INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID
        //WHERE IFM.ItemCode = @ItemCode AND (PH.RetailPackType = 'R' OR PH.RetailPackType = '' )";


        private const string GetPackagingHierarchyByItemCodeSQL = @"
           SELECT PH.[ID]
          , PH.[ItemFormID]    
          , PH.[RetailPackType]    
          , PH.[RetailPackTypeDescription]    
          , PH.[RetailPackSize]    
          , PH.[Size]    
          , PH.[SizeUOM]    
          , PH.[SizeUOMDescription]    
          , PH.[LabelAmount]    
          , [MasterCaseCodeType]
          , [MasterCaseGTIN]
          , [MasterCaseGTINCheckDigit]
          , [MasterCaseVendorItemGTIN]
          , [MasterCaseSellingUnit]
          , [MasterCaseWeight]
          , [MasterCaseNetWeight]
          , [MasterCaseHeight]
          , [MasterCaseLength]
          , [MasterCaseDepth]
          , [MasterCaseCubicFootage]
          , [InnerPackExist]
          , [InnerCaseCodeType]
          , [InnerCaseGTIN]
          , [InnerCaseGTINCheckDigit]
          , [InnerCaseSellingUnits]
          , [InnerCaseWeight]
          , [InnerCaseNetWeight]
          , [InnerCaseHeight]
          , [InnerCaseLength]
          , [InnerCaseDepth]
          , [InnerCaseCubicFootage]
          , [MasterCasesInSinglePalletLayer]
          , [LayersOnPallet]
          , [PalletGTIN]
          , [PalletQuantity]
          , [PalletCubicFootage]
          , IFM.FormStatusID
        FROM [dbo].[PackagingHierarchy] PH
        INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID    
        WHERE IFM.ItemCode = (Select ModelPackagingItemCode from BasicItemDefinition where ItemFormID = @ItemformId)
        AND(PH.RetailPackType = 'R' OR PH.RetailPackType = '')";

        private const string GetPackagingHierarchyByGtinSQL = @"SELECT PH.[ID]
      ,[ItemFormID]
      ,[RetailPackType]
      ,[RetailPackTypeDescription]
      ,[RetailPackSize]
      ,[Size]
      ,[SizeUOM]
      ,[SizeUOMDescription]
      ,[LabelAmount]
      ,[MasterCaseCodeType]
      ,[MasterCaseGTIN]
      ,[MasterCaseGTINCheckDigit]
      ,[MasterCaseVendorItemGTIN]
      ,[MasterCaseSellingUnit]
      ,[MasterCaseWeight]
      ,[MasterCaseNetWeight]
      ,[MasterCaseHeight]
      ,[MasterCaseLength]
      ,[MasterCaseDepth]
      ,[MasterCaseCubicFootage]
      ,[InnerPackExist]
      ,[InnerCaseCodeType]
      ,[InnerCaseGTIN]
      ,[InnerCaseGTINCheckDigit]
      ,[InnerCaseSellingUnits]
      ,[InnerCaseWeight]
      ,[InnerCaseNetWeight]
      ,[InnerCaseHeight]
      ,[InnerCaseLength]
      ,[InnerCaseDepth]
      ,[InnerCaseCubicFootage]
      ,[MasterCasesInSinglePalletLayer]
      ,[LayersOnPallet]
      ,[PalletGTIN]
      ,[PalletQuantity]
      ,[PalletCubicFootage]      
      ,IFM.FormStatusID
    FROM [dbo].[PackagingHierarchy] PH
  INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID
  INNER JOIN BasicItemDefinition BID ON IFM.ID = BID.ItemFormID
  WHERE IFM.ItemCode = @ItemCode AND BID.GTIN = @Gtin AND (PH.RetailPackType = 'R' || PH.RetailPackType = '' )";

        private const string GetOrderablePackLevelsForPHSQL = @"SELECT [ID]
      ,[PackagingHierarchyID]
      ,[InsertedByUserTypeID]
      ,[VendorNumber]
      ,[VendorDescription]
      ,[VendorType]
      ,[Warehouse]
      ,[WarehouseDescription]
      ,[OrderingPackagingLevelID]
      ,[OrderingPackagingLevelDescription]
      ,[OrderPackQuantity]
      ,[ShippingPackagingLevelID]
      ,[ShippingPackagingLevelDescription]
      ,[ShippingPackQty]
      ,[ShipMax]
      ,[ShipPallet]
      ,[EffectiveDate]
      ,[TerminationDate]
      ,[PrimaryVendor]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[LastUpdatedBy]
      ,[LastUpdatedDate]
  FROM [dbo].[OrderablePackLevel] Where PackagingHierarchyID = @PackagingHierarchyID order by VendorNumber";

        private const string InsertPackagingHierarchySQL = @"INSERT INTO [dbo].[PackagingHierarchy]
           ([ItemFormID]
           ,[RetailPackType]
           ,[RetailPackTypeDescription]
           ,[RetailPackSize]
           ,[Size]
           ,[SizeUOM]
           ,[SizeUOMDescription]
           ,[LabelAmount]
           ,[MasterCaseCodeType]
           ,[MasterCaseGTIN]
           ,[MasterCaseGTINCheckDigit]
           ,[MasterCaseVendorItemGTIN]
           ,[MasterCaseSellingUnit]
           ,[MasterCaseWeight]
           ,[MasterCaseNetWeight]
           ,[MasterCaseHeight]
           ,[MasterCaseLength]
           ,[MasterCaseDepth]
           ,[MasterCaseCubicFootage]
           ,[InnerPackExist]
           ,[InnerCaseCodeType]
           ,[InnerCaseGTIN]
           ,[InnerCaseGTINCheckDigit]
           ,[InnerCaseSellingUnits]
           ,[InnerCaseWeight]
           ,[InnerCaseNetWeight]
           ,[InnerCaseHeight]
           ,[InnerCaseLength]
           ,[InnerCaseDepth]
           ,[InnerCaseCubicFootage]
           ,[MasterCasesInSinglePalletLayer]
           ,[LayersOnPallet]
           ,[PalletGTIN]
           ,[PalletQuantity]
           ,[PalletCubicFootage]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     VALUES
           ( @ItemFormID
           ,@RetailPackType
           ,@RetailPackTypeDescription
           ,@RetailPackSize
           ,@Size
           ,@SizeUOM
           ,@SizeUOMDescription
           ,@LabelAmount
           ,@MasterCaseCodeType
           ,@MasterCaseGTIN
           ,@MasterCaseGTINCheckDigit
           ,@MasterCaseVendorItemGTIN
           ,@MasterCaseSellingUnit 
           ,@MasterCaseWeight
           ,@MasterCaseNetWeight
           ,@MasterCaseHeight
           ,@MasterCaseLength
           ,@MasterCaseDepth 
           ,@MasterCaseCubicFootage
           ,@InnerPackExist
           ,@InnerCaseCodeType
           ,@InnerCaseGTIN
           ,@InnerCaseGTINCheckDigit
           ,@InnerCaseSellingUnits
           ,@InnerCaseWeight
           ,@InnerCaseNetWeight
           ,@InnerCaseHeight
           ,@InnerCaseLength
           ,@InnerCaseDepth 
           ,@InnerCaseCubicFootage 
           ,@MasterCasesInSinglePalletLayer
           ,@LayersOnPallet 
           ,@PalletGTIN 
           ,@PalletQuantity 
           ,@PalletCubicFootage
           ,@CreatedBy 
           ,getDate() 
           ,@LastUpdatedBy
           ,null );
             SELECT SCOPE_IDENTITY();";

        private const string UpdatePackagingHierarchySQL = @"UPDATE [dbo].[PackagingHierarchy]
        SET      
       [MasterCaseCodeType] = @MasterCaseCodeType
      ,[MasterCaseGTIN] = @MasterCaseGTIN
      ,[MasterCaseGTINCheckDigit] = @MasterCaseGTINCheckDigit
      ,[MasterCaseVendorItemGTIN] = @MasterCaseVendorItemGTIN
      ,[MasterCaseSellingUnit] = @MasterCaseSellingUnit
      ,[MasterCaseWeight] = @MasterCaseWeight
      ,[MasterCaseNetWeight] = @MasterCaseNetWeight
      ,[MasterCaseHeight] = @MasterCaseHeight
      ,[MasterCaseLength] = @MasterCaseLength
      ,[MasterCaseDepth] = @MasterCaseDepth 
      ,[MasterCaseCubicFootage] = @MasterCaseCubicFootage
      ,[InnerPackExist] = @InnerPackExist
      ,[InnerCaseCodeType] = @InnerCaseCodeType
      ,[InnerCaseGTIN] = @InnerCaseGTIN
      ,[InnerCaseGTINCheckDigit] = @InnerCaseGTINCheckDigit
      ,[InnerCaseSellingUnits] = @InnerCaseSellingUnits
      ,[InnerCaseWeight] = @InnerCaseWeight
      ,[InnerCaseNetWeight] = @InnerCaseNetWeight
      ,[InnerCaseHeight] = @InnerCaseHeight
      ,[InnerCaseLength] = @InnerCaseLength 
      ,[InnerCaseDepth] = @InnerCaseDepth
      ,[InnerCaseCubicFootage] = @InnerCaseCubicFootage
      ,[MasterCasesInSinglePalletLayer] = @MasterCasesInSinglePalletLayer
      ,[LayersOnPallet] = @LayersOnPallet
      ,[PalletGTIN] = @PalletGTIN
      ,[PalletQuantity] = @PalletQuantity
      ,[PalletCubicFootage] = @PalletCubicFootage
      ,[LastUpdatedBy] = @LastUpdatedBy
      ,[LastUpdatedDate] = getDate()
 WHERE  ItemFormID = @ItemFormID 
    AND RetailPackType = @RetailPackType 
    AND ((RetailPackSize = @RetailPackSize) or (RetailPackSize is null and @RetailPackSize is null)) 
    AND ((Size = @Size) or (Size is null and @Size is null)) 
    AND  SizeUOM = @SizeUOM 
    AND ((LabelAmount = @LabelAmount) or (LabelAmount is null and @LabelAmount is null))";

        private const string InsertOrderablePackLevelsAuditSQL = @"INSERT INTO [dbo].[OrderablePackLevelAudit]
           ([Version]
           ,[ID]
           ,[PackagingHierarchyID]
           ,[InsertedByUserTypeID]
           ,[VendorNumber]
           ,[VendorDescription]
           ,[VendorType]
           ,[Warehouse]
           ,[WarehouseDescription]
           ,[OrderingPackagingLevelID]
           ,[OrderingPackagingLevelDescription]
           ,[OrderPackQuantity]
           ,[ShippingPackagingLevelID]
           ,[ShippingPackagingLevelDescription]
           ,[ShippingPackQty]
           ,[ShipMax]
           ,[ShipPallet]
           ,[EffectiveDate]
           ,[TerminationDate]
           ,[PrimaryVendor]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
		SELECT getDate()
           ,ID
           ,PackagingHierarchyID
           ,InsertedByUserTypeID
           ,VendorNumber
           ,VendorDescription
           ,VendorType
           ,Warehouse
           ,WarehouseDescription
           ,OrderingPackagingLevelID
           ,OrderingPackagingLevelDescription
           ,OrderPackQuantity
           ,ShippingPackagingLevelID
           ,ShippingPackagingLevelDescription
           ,ShippingPackQty
           ,ShipMax
           ,ShipPallet
           ,EffectiveDate
           ,TerminationDate
           ,PrimaryVendor
           ,CreatedBy
           ,getDate()
           ,LastUpdatedBy
           ,getDate() FROM OrderablePackLevel where PackagingHierarchyID = @PackagingHierarchyID";



        private const string IsPrimaryVendorExistsForWHByGtinSQL = @"
                SELECT COUNT(*) FROM [dbo].[ItemForm] IFM
                INNER JOIN [dbo].[BasicItemDefinition] BID ON IFM.ID = BID.ItemFormID
                INNER JOIN [dbo].[PackagingHierarchy] PKGH ON IFM.ID = PKGH.ItemFormID
                INNER JOIN [dbo].[OrderablePackLevel] OPL ON PKGH.ID = OPL.PackagingHierarchyID
                WHERE BID.GTIN = @GTIN AND BID.ItemFormID != @ItemFormID AND OPL.Warehouse = @WarehouseNumber AND OPL.PrimaryVendor = 'Y' 
                AND IFM.FormStatusID IN (5)";

        private const string UpdatePrimaryVendorSQL = @"
          Update [dbo].[OrderablePackLevel] OPL set PrimaryVendor = 'N'
                INNER JOIN [dbo].[PackagingHierarchy] PKGH ON OPL.PackagingHierarchyID = PKGH.ID
                INNER JOIN [dbo].[ItemForm] IFM ON PKGH.ItemFormID = IFM.ID
                INNER JOIN [dbo].[BasicItemDefinition] BID ON IFM.ID = BID.ItemFormID                
            where BID.GTIN = @GTIN  AND OPL.Warehouse = @WarehouseNumber  AND IFM.FormStatusID IN (5)";

        private const string DeletePackagingHierarchiesSql = @"Delete [dbo].[PackagingHierarchy] where ID IN (@IDs)";
        //   private const string InsertIntoPackagingHierarchyAudit = @"INSERT INTO [dbo].[PackagingHierarchy]
        //      ( [Version]
        //      ,[ItemFormID]
        //      ,[RetailPackType]
        //      ,[RetailPackTypeDescription]
        //      ,[RetailPackSize]
        //      ,[Size]
        //      ,[SizeUOM]
        //      ,[SizeUOMDescription]
        //      ,[LabelAmount]
        //      ,[MasterCaseCodeType]
        //      ,[MasterCaseGTIN]
        //      ,[MasterCaseGTINCheckDigit]
        //      ,[MasterCaseVendorItemGTIN]
        //      ,[MasterCaseSellingUnit]
        //      ,[MasterCaseWeight]
        //      ,[MasterCaseNetWeight]
        //      ,[MasterCaseHeight]
        //      ,[MasterCaseLength]
        //      ,[MasterCaseDepth]
        //      ,[MasterCaseCubicFootage]
        //      ,[InnerPackExist]
        //      ,[InnerCaseCodeType]
        //      ,[InnerCaseGTIN]
        //      ,[InnerCaseGTINCheckDigit]
        //      ,[InnerCaseSellingUnits]
        //      ,[InnerCaseWeight]
        //      ,[InnerCaseNetWeight]
        //      ,[InnerCaseHeight]
        //      ,[InnerCaseLength]
        //      ,[InnerCaseDepth]
        //      ,[InnerCaseCubicFootage]
        //      ,[MasterCasesInSinglePalletLayer]
        //      ,[LayersOnPallet]
        //      ,[PalletGTIN]
        //      ,[PalletQuantity]
        //      ,[PalletCubicFootage]
        //      ,[CreatedBy]
        //      ,[CreatedDate]
        //      ,[LastUpdatedBy]
        //      ,[LastUpdatedDate])
        //VALUES (@getDate()           
        //      , @ItemFormID
        //      , @RetailPackType
        //      , @RetailPackTypeDescription
        //      , @RetailPackSize
        //      , @Size
        //      , @SizeUOM
        //      , @SizeUOMDescription
        //      , @LabelAmount
        //      , @MasterCaseCodeType
        //      , @MasterCaseGTIN
        //      , @MasterCaseGTINCheckDigit
        //      , @MasterCaseVendorItemGTIN
        //      , @MasterCaseSellingUnit
        //      , @MasterCaseWeight
        //      , @MasterCaseNetWeight
        //      , @MasterCaseHeight
        //      , @MasterCaseLength
        //      , @MasterCaseDepth
        //      , @MasterCaseCubicFootage
        //      , @InnerPackExist
        //      , @InnerCaseCodeType
        //      , @InnerCaseGTIN
        //      , @InnerCaseGTINCheckDigit
        //      , @InnerCaseSellingUnits
        //      , @InnerCaseWeight
        //      , @InnerCaseNetWeight
        //      , @InnerCaseHeight
        //      , @InnerCaseLength
        //      , @InnerCaseDepth
        //      , @InnerCaseCubicFootage
        //      , @MasterCasesInSinglePalletLayer
        //      , @LayersOnPallet
        //      , @PalletGTIN
        //      , @PalletQuantity
        //      , @PalletCubicFootage
        //      , @CreatedBy
        //      , @CreatedDate
        //      , @LastUpdatedBy
        //      , @LastUpdatedDate) ";

        private const string InsertIntoPackagingHierarchyAuditSQL = @"INSERT INTO [dbo].[PackagingHierarchyAudit]
           ([Version]
           ,[ID]
           ,[ItemFormID]
           ,[RetailPackType]
           ,[RetailPackTypeDescription]
           ,[RetailPackSize]
           ,[Size]
           ,[SizeUOM]
           ,[SizeUOMDescription]
           ,[LabelAmount]
           ,[MasterCaseCodeType]
           ,[MasterCaseGTIN]
           ,[MasterCaseGTINCheckDigit]
           ,[MasterCaseVendorItemGTIN]
           ,[MasterCaseSellingUnit]
           ,[MasterCaseWeight]
           ,[MasterCaseNetWeight]
           ,[MasterCaseHeight]
           ,[MasterCaseLength]
           ,[MasterCaseDepth]
           ,[MasterCaseCubicFootage]
           ,[InnerPackExist]
           ,[InnerCaseCodeType]
           ,[InnerCaseGTIN]
           ,[InnerCaseGTINCheckDigit]
           ,[InnerCaseVendorItemGTIN]
           ,[InnerCaseSellingUnits]
           ,[InnerCaseWeight]
           ,[InnerCaseNetWeight]
           ,[InnerCaseHeight]
           ,[InnerCaseLength]
           ,[InnerCaseDepth]
           ,[InnerCaseCubicFootage]
           ,[MasterCasesInSinglePalletLayer]
           ,[LayersOnPallet]
           ,[PalletGTIN]
           ,[PalletQuantity]
           ,[PalletCubicFootage]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     SELECT 
           getDate()
           ,ID
           ,ItemFormID
           ,RetailPackType
           ,RetailPackTypeDescription
           ,RetailPackSize
           ,Size
           ,SizeUOM
           ,SizeUOMDescription
           ,LabelAmount
           ,MasterCaseCodeType
           ,MasterCaseGTIN
           ,MasterCaseGTINCheckDigit
           ,MasterCaseVendorItemGTIN
           ,MasterCaseSellingUnit
           ,MasterCaseWeight
           ,MasterCaseNetWeight
           ,MasterCaseHeight
           ,MasterCaseLength
           ,MasterCaseDepth
           ,MasterCaseCubicFootage
           ,InnerPackExist
           ,InnerCaseCodeType
           ,InnerCaseGTIN
           ,InnerCaseGTINCheckDigit
           ,InnerCaseVendorItemGTIN
           ,InnerCaseSellingUnits
           ,InnerCaseWeight
           ,InnerCaseNetWeight
           ,InnerCaseHeight
           ,InnerCaseLength
           ,InnerCaseDepth
           ,InnerCaseCubicFootage
           ,MasterCasesInSinglePalletLayer
           ,LayersOnPallet
           ,PalletGTIN
           ,PalletQuantity
           ,PalletCubicFootage
           ,CreatedBy
           ,getDate()
           ,LastUpdatedBy
           ,getDate() From [dbo].[PackagingHierarchy] Where ID IN (@ID)";

        private const string InsertIntoOrderablePackLevels = @"INSERT INTO [dbo].[OrderablePackLevel]
           ([PackagingHierarchyID]
           ,[InsertedByUserTypeID]
           ,[VendorNumber]
           ,[VendorDescription]
           ,[VendorType]
           ,[Warehouse]
           ,[WarehouseDescription]
           ,[OrderingPackagingLevelID]
           ,[OrderingPackagingLevelDescription]
           ,[OrderPackQuantity]
           ,[ShippingPackagingLevelID]
           ,[ShippingPackagingLevelDescription]
           ,[ShippingPackQty]
           ,[ShipMax]
           ,[ShipPallet]
           ,[EffectiveDate]
           ,[TerminationDate]
           ,[PrimaryVendor]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     VALUES
           (@PackagingHierarchyID
           ,@InsertedByUserTypeID
           ,@VendorNumber
           ,@VendorDescription
           ,@VendorType
           ,@Warehouse
           ,@WarehouseDescription
           ,@OrderingPackagingLevelID
           ,@OrderingPackagingLevelDescription
           ,@OrderPackQuantity
           ,@ShippingPackagingLevelID
           ,@ShippingPackagingLevelDescription
           ,@ShippingPackQty
           ,@ShipMax
           ,@ShipPallet
           ,@EffectiveDate
          , @TerminationDate
           ,@PrimaryVendor
           ,@CreatedBy
           ,getDate()
           ,@LastUpdatedBy
           ,getDate())";

         //,CONVERT(datetime, IIF ( @EffectiveDate = '', null, @EffectiveDate ) , 101)
         // ,CONVERT(datetime, IIF ( @TerminationDate = '', null, @TerminationDate ) , 101)
        private const string DeleteOrderablePackLevelsSql = @"Delete [S0VPITEM].[dbo].[OrderablePackLevel] where PackagingHierarchyID = @PackagingHierarchyID";
        //Select ModelPackagingItemCode from BasicItemDefinition where itemformid = @itemformId
        //GetValidItemFormIDForModellingByModelPHItemCode(int? itemformId, int[] userVendors);
        // IFM.ItemCode = (@modelItemCode) AND ifm.FormStatusID IN (4,5,8,9,10,11,12)  AND
        private const string GetItemFormIDForModellingByModelPHItemCodeSQL = @"
        SELECT TOP 1 ItemFormID, IFM.ItemCode, ifm.CreatedDate ,ifm.SubmissionDate FROM PackagingHierarchy PH INNER JOIN OrderablePackLevel OL ON ol.PackagingHierarchyID = PH.ID
        INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID
         WHERE
         IFM.ItemCode = (@modelItemCode) AND ifm.FormStatusID IN (12)  AND
        (PH.RetailPackType = 'R' OR PH.RetailPackType = '') AND
        PH.ID NOT IN (
        SELECT PackagingHierarchyID from OrderablePackLevel WHERE VendorNumber NOT IN (SELECT ID FROM CSVToTable(@userVendors))
         ) 
         order by ifm.SubmissionDate desc";


        private const string GetItemFormIDForModellingByModelPHItemCodeBuyerSQL = @"
        SELECT TOP 1 ItemFormID, IFM.ItemCode, ifm.CreatedDate ,ifm.SubmissionDate FROM PackagingHierarchy PH 
        INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID
         WHERE
         IFM.ItemCode = (@modelItemCode) AND ifm.FormStatusID IN (12)  AND
        (PH.RetailPackType = 'R' OR PH.RetailPackType = '') 
         order by ifm.SubmissionDate desc";

        private const string GetItemFormIDForModellingByGtinBuyerSQL = @"
        SELECT TOP 1 PH.ItemFormID, IFM.ItemCode, ifm.CreatedDate ,ifm.SubmissionDate FROM PackagingHierarchy PH 
        INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID
        INNER JOIN BasicItemDefinition BID on IFM.ID = BID.ItemFormID
         WHERE
         BID.GTIN = (@Gtin) AND ifm.FormStatusID IN (12)  AND
        (PH.RetailPackType = 'R' OR PH.RetailPackType = '') 
         order by ifm.SubmissionDate desc";

        private const string GetItemFormIDForModellingByGtinSQL = @"
        SELECT TOP 1 PH.ItemFormID, IFM.ItemCode, ifm.CreatedDate ,ifm.SubmissionDate FROM PackagingHierarchy PH INNER JOIN OrderablePackLevel OL ON ol.PackagingHierarchyID = PH.ID
        INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID
        INNER JOIN BasicItemDefinition BID on IFM.ID = BID.ItemFormID
         WHERE
         BID.GTIN = (@Gtin)
         AND ifm.FormStatusID IN (12)  AND
        (PH.RetailPackType = 'R' OR PH.RetailPackType = '') AND
        PH.ID NOT IN (
        SELECT PackagingHierarchyID from OrderablePackLevel WHERE VendorNumber NOT IN (SELECT ID FROM CSVToTable(@userVendors))
         ) 
         order by ifm.SubmissionDate desc";
        //private const string GetValidItemFormIDForModellingByModelPHItemCodeBuyerSQL = @"
        //SELECT TOP 1 ItemFormID, IFM.ItemCode, ifm.CreatedDate ,ifm.SubmissionDate FROM PackagingHierarchy PH 
        //INNER JOIN ItemForm IFM ON IFM.ID = PH.ItemFormID
        // WHERE
        // IFM.ItemCode = (Select ModelPackagingItemCode from BasicItemDefinition where itemformid = @itemformId) AND ifm.FormStatusID IN (12)  AND
        //(PH.RetailPackType = 'R' OR PH.RetailPackType = '')
        // order by ifm.SubmissionDate desc";

        private const string GetDsdVendorsExistInDsdForItemFormSQL = @"SELECT DISTINCT VendorNumber, VendorName FROM [dbo].[DSDAuthRequestStore] 
                                                WHERE ItemFormID = @ItemFormID";
    }
}

//IFM.ItemCode = (Select ModelPackagingItemCode from BasicItemDefinition where itemformid = 12441) AND ifm.FormStatusID IN (4,5,8,9,10,11,12)  AND