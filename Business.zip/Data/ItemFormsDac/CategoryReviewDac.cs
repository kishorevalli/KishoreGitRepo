﻿using Dapper;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class CategoryReviewDac : BaseDac, ICategoryReviewDac
    {
        public async Task<IEnumerable<CategoryReviewDto>> GetCategoryReviewReport(int BuyerID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<CategoryReviewDto>(GetCategoryReviewReportSQL, new { BuyerID = BuyerID }));
            }
        }

        //public async Task<IEnumerable<LookupDto>> GetRSSListByBuyerID(int BuyerID)
        //{
        //    throw new NotImplementedException();

        //}
        #region "SQL Queries"
        private const string GetCategoryReviewReportSQL = @"SELECT 
                                         IFM.[ID] AS ItemFormID
                                        ,IFM.[ItemFormDisplayID]
                                        ,BID.[GTIN]
                                        ,BID.[GTINCheckDigit]
                                        ,BID.[ItemDescription]
                                        ,MKI.[ProjectedSales52Weeks]
                                        ,MKI.[UnitCost]
                                        ,MKI.[UnitCostUOM]
                                        ,MKI.[SuggestedRetail]
                                        ,MKI.[SuggestedMargin]   
                                        ,MKI.[ItemPreviouslyPresented]
                                        ,MKI.[AvailableShipDate]
                                        ,MKI.[NewItemFundsAvailable]
                                        ,MKI.[NewItemFundsAmount] 
										,STUFF((SELECT DISTINCT ', '+CONVERT(VARCHAR, ChildProductGroupCode)  + ' - ' + ChildProductGroupDescription 
											 FROM ProductGrouping WHERE ItemFormID = IFM.ID AND ChildProductGroupType = 'RSS'
											  FOR XML PATH('')
											),1,2,'') RSS
										,REPLACE(STUFF((SELECT DISTINCT '[crlf]' + CONVERT(VARCHAR, VendorNumber)  + ' - ' + LTRIM(RTRIM([VendorDescription]))
										  FROM [dbo].[PackagingHierarchy] 
                                          INNER JOIN [dbo].[OrderablePackLevel] ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
                                          WHERE PackagingHierarchy.ItemFormID=IFM.ID
										  FOR XML PATH('')),1,6,''),'[crlf]',CHAR(13)+CHAR(10)) Vendor
										,STUFF((SELECT ', '+comment + ' - ' + CreatedBy + '@'+ CONVERT(VARCHAR(10), CreatedDate, 101) + ' ' + CONVERT(VARCHAR(8), CreatedDate, 108)
											  FROM      FormComment WHERE ItemFormID = IFM.ID AND CreatedByUserTypeID = 1
											  FOR XML PATH('')
											),1,2,'') VendorComments
										,STUFF((SELECT ', '+comment + ' - ' + CreatedBy + '@'+ CONVERT(VARCHAR(10), CreatedDate, 101) + ' ' + CONVERT(VARCHAR(8), CreatedDate, 108)
											  FROM      FormComment WHERE ItemFormID = IFM.ID AND CreatedByUserTypeID <> 1
											  FOR XML PATH('')
											),1,2,'') BuyerComments                                                      
                                        FROM ItemForm IFM 
                                        INNER JOIN [dbo].[BasicItemDefinition] BID ON IFM.ID = BID.ItemFormID
                                        LEFT JOIN [dbo].[MarketingInfo] MKI ON IFM.ID = MKI.ItemFormID
                                        WHERE IFM.BuyerID = @BuyerID AND IFM.FormStatusID = 8";

        #endregion
    }
}
