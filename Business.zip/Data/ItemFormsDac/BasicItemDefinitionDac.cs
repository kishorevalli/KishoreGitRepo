﻿using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using System.Transactions;
using System.Globalization;
using System.Collections;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class BasicItemDefinitionDac: BaseDac, IBasicItemDefinitionDac
    {

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<LookupDto>> GetSubmissionReasons()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                LookupDto lookupDto = new LookupDto();
                lookupDto.IsActive = 1;
                return (await conn.QueryAsync<LookupDto>(GetSubmissionReasonsSQL, lookupDto));
                //return (await conn.QueryAsync<LookupDto>(GetSubmissionReasonsSQL, new { IsActive = lookupDto.IsActive }));
            }
        }



        public async Task<bool> SaveBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            bool retValue = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    //TODO implement Transaction scope                    
               

                  
                  //  await conn.ExecuteAsync(UpdateItemFormSQL, basicItemDefinitionDto);
                    await conn.ExecuteAsync(AuditBasicItemFormDefnitionSQL, basicItemDefinitionDto); 
                    await conn.ExecuteAsync(MergeBasicItemFormDefnitionSQL, basicItemDefinitionDto);
                    await conn.ExecuteAsync(AuditAdditionalGTINSQL, basicItemDefinitionDto); 
                    await conn.ExecuteAsync(DeleteAdditionalGTINSQL, new { ItemFormID = basicItemDefinitionDto.ItemFormID});
                    await conn.ExecuteAsync(AssignCurrentReuseItemCodeToFormSQL, new { ItemFormID = basicItemDefinitionDto.ItemFormID,ItemCode = basicItemDefinitionDto.ReuseItemCode });
                                        
                    if (basicItemDefinitionDto.AddtionalGtinList != null && basicItemDefinitionDto.AddtionalGtinList.Count >0)
                    {
                        basicItemDefinitionDto.AddtionalGtinList = basicItemDefinitionDto.AddtionalGtinList.Select(c => { c.ItemFormID = basicItemDefinitionDto.ItemFormID; return c; }).ToList();
                        await conn.ExecuteAsync(InsertBasicItemDefinitionAdditionalGTINSQL, basicItemDefinitionDto.AddtionalGtinList);
                    }
                    //TODO Use seperate method and call based on user type.
                    if(basicItemDefinitionDto.SubmittedUserTypeID != UserType.Vendor)
                    {                        
                        await conn.ExecuteAsync(AuditScaleInfoSQL, basicItemDefinitionDto);
                        await conn.ExecuteAsync(SaveScaleInfoSQL, basicItemDefinitionDto);
                    }                       


                    retValue = true;
                }
                catch(Exception e)
                {
                    throw e;
                }              
            }
            return retValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<LookupDto>> GetItemCaseTypes()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<LookupDto>(GetItemCaseTypesSQL));
            }
        }

        public async Task<IEnumerable<LookupDto>> GetReuseItemSubDepartments()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<LookupDto>(GetReuseItemSubDepartmentsSQL));
            }
        }

        
        public async Task<BasicItemDefinitionDto> GetBasicItemDefinitionData(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                               
                await conn.OpenAsync();              
                BasicItemDefinitionDto basicItemDefinitionDto = await conn.QueryFirstOrDefaultAsync<BasicItemDefinitionDto>(GetBasicItemDefinitionDataSQL, new { @ItemFormID = itemFormId });
                if (basicItemDefinitionDto != null)
                {
                    var additionalGTInList = await conn.QueryAsync<AdditionalGTINDto>(GetAdditionalGTINSQL, new { @ItemFormID = itemFormId });
                    basicItemDefinitionDto.AddtionalGtinList = additionalGTInList.ToList();
                }
                return basicItemDefinitionDto;                
            }
        }

        public async Task<IEnumerable<long>> GetItemFormsDisplayIDs(string  userId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {

                await conn.OpenAsync();
                IEnumerable<long> itemFormDisplayIds = await conn.QueryAsync<long>(GetItemFormDisplayIDSQL, new { @userId = userId });
                
                return await Task.FromResult(itemFormDisplayIds);

            }
        }

        public async Task<bool> IsGTINExistsInPackagingHierarchy(decimal Gtin)
        {
            // throw new NotImplementedException();

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var recordCnt = await conn.QueryFirstAsync<int>(IsGTINExistsInItemFormsSQL, new { @Gtin = Gtin });
                return (recordCnt > 0 ? true : false);
            }
        }

        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="reuseItemCodeDto"></param>
        /// <returns></returns>
        public async Task<ReuseItemCodeDto> IsSelectedReuseItemCodeAlreadyUsed(ReuseItemCodeDto reuseItemCodeDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var result = conn.QueryFirstAsync<string>(IsSelectedReuseItemCodeAlreadyUsedSQL, reuseItemCodeDto).Result;
                ItemValidationDTO validationError = new ItemValidationDTO();
                List<ErrorDTO> errors = new List<ErrorDTO>();
                validationError.Errors = errors;
                switch (result)
                {
                    case "Invalid":
                        reuseItemCodeDto.IsAvailable = false;
                        validationError.Errors.Add(new ErrorDTO { ErrorDescription = "Invalid Reuse Item Code" } ) ;
                        reuseItemCodeDto.ValidationErrors = validationError;
                        break;
                    case "NotAvailable":
                        reuseItemCodeDto.IsAvailable = false;
                        validationError.Errors.Add(new ErrorDTO { ErrorDescription = "Reuse Item Code is consumed by other form" });                        
                        reuseItemCodeDto.ValidationErrors = validationError;                        
                        break;
                    case "Available":
                        reuseItemCodeDto.IsAvailable = true;                        
                        break;
                    default:
                        break;
                }

                return reuseItemCodeDto;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="reuseItemCodeDto"></param>
        /// <returns></returns>
        public async Task<IEnumerable<ReuseItemCodeDto>> GetItemFormReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<ReuseItemCodeDto>(GetItemFormReuseItemCodesBySubDeptSQL, reuseItemCodeDto));
            }
        }

        public async Task<IEnumerable<ReuseItemCodeDto>> GetAvailableItemFormReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<ReuseItemCodeDto>(GetAvailableItemFormReuseItemCodesBySubDeptSQL, reuseItemCodeDto));
            }
        }

        


        /// <summary>
        /// 
        /// </summary>
        /// <param name="reuseItemCodeDto"></param>
        /// <returns></returns>
        public async Task<bool> SaveReuseItemCode(ReuseItemCodeDto reuseItemCodeDto)
        {
            bool bSuccess = false;
            using (TransactionScope scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    if (reuseItemCodeDto.SubDeptCode == 0)
                        reuseItemCodeDto.SubDeptCode = conn.QueryFirstAsync<int>(GetSubDeptForReuseItemCodeSQL, reuseItemCodeDto).Result;
                    // it is not needed
                    //await conn.ExecuteAsync(UnbindPreviousReuseItemCodeFromFormSQL, reuseItemCodeDto);
                    await conn.ExecuteAsync(LockCurrentReuseItemCodeToFormSQL, reuseItemCodeDto);                                  
                    
                }
                scope.Complete();
                bSuccess = true;
            }
            return bSuccess;
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="reuseItemCodeDtoList"></param>
       /// <returns></returns>
        public async Task<bool> DeleteUnAvailableReuseItemCodes(IEnumerable<ReuseItemCodeDto> reuseItemCodeDtoList)
        {
            bool bSuccess = false;
           
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                await conn.ExecuteAsync(DeleteUnAvailableReuseItemCodesSQL, reuseItemCodeDtoList);

            }
                
            bSuccess = true;
            
            return bSuccess;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reuseItemCodeDtoList"></param>
        /// <returns></returns>
        public async Task<bool> InsertAvailableReuseItemCodes(IEnumerable<ReuseItemCodeDto> reuseItemCodeDtoList)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                await conn.ExecuteAsync(InsertReuseItemCodeSQL, reuseItemCodeDtoList);

            }

            bSuccess = true;

            return bSuccess;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="modelProductItemValueDto"></param>
        /// <returns></returns>
        public async Task<bool> SaveModelProductItemValues(ModelProductItemValueDto modelProductItemValueDto)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                
                await conn.ExecuteAsync(AuditModelProductItemValueSQL, modelProductItemValueDto);
                await conn.ExecuteAsync(SaveModelProductItemValuesSQL, modelProductItemValueDto);
            }

            bSuccess = true;

            return bSuccess;
        }

        
        public async Task<ModelProductItemValueDto> GetModelProductItemValues(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryFirstOrDefaultAsync<ModelProductItemValueDto>(GetModelProductItemValuesSQL, new { ItemFormID = itemFormID }));
            }
        }


        
        public async Task<bool> DeleteModelProductItemValues(int itemFormID)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                await conn.ExecuteAsync(AuditModelProductItemValueSQL, new { ItemFormID = itemFormID });
                await conn.ExecuteAsync(DeleteModelProductItemValuesSQL,new { ItemFormID = itemFormID });
            }

            bSuccess = true;

            return bSuccess;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="scaleInfoDto"></param>
        /// <returns></returns>
        public async Task<bool> SaveScaleInfo(ScaleInfoDto scaleInfoDto)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                await conn.ExecuteAsync(SaveScaleInfoSQL, scaleInfoDto);
            }

            bSuccess = true;

            return bSuccess;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reuseItemCodeDtoList"></param>
        /// <returns></returns>
        public async Task<bool> DetachReuseItemCode(IEnumerable<ReuseItemCodeDto> reuseItemCodeDtoList)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                await conn.ExecuteAsync(DeleteUnAvailableReuseItemCodesSQL, reuseItemCodeDtoList);

            }

            bSuccess = true;

            return bSuccess;
        }

        public async Task<bool> CheckIfItemCreatedByItemForms(int? itemCode)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {                    
                    var count = await conn.ExecuteScalarAsync<int>(CheckIfItemCreatedByItemFormsSQL, new { ItemCode = itemCode });
                    return count > 0 ? true : false;
                }
                catch
                {
                    throw;
                }

            }
        }
        //public async Task<IEnumerable<GTINWithCheckdigitDto>> GetBasicItemDefinitionGTIN(int itemFormID)
        //{
        //    using (var conn = (SqlConnection)base.S0VPITEM_Connection)
        //    {
        //        await conn.OpenAsync();
        //        return (await conn.QueryAsync<GTINWithCheckdigitDto>(GetBasicItemDefinitionGTINSQL, new { ItemFormID = itemFormID }));
        //    }
        //}
        public async Task<IEnumerable<GTINWithCheckdigitDto>> GetNutritionalPanelGTIN(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<GTINWithCheckdigitDto>(GetNutritionalPanelGTINSQL, new { @ItemFormID = itemFormID });
            }
        }

        public async Task<bool> RemoveGTINRetailPackRelatedInfo(GTINRetailPackInfoDto gtinRetailPackInfo)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                if(gtinRetailPackInfo.NutritionalPanelGTINList !=null && gtinRetailPackInfo.NutritionalPanelGTINList.Length > 0)
                {
                    await conn.ExecuteAsync(RemoveNutritionalPanelGTINSQL, new { @ItemFormID = gtinRetailPackInfo.ItemFormID, @Gtins = gtinRetailPackInfo.NutritionalPanelGTINList });
                }
            }
            return true;
        }

        #region Queries
        private const string SaveBasicItemDefinitionSQL = "";
      
        private const string CheckIfItemCreatedByItemFormsSQL = @"SELECT count(*) FROM ItemForm where ItemCode = @ItemCode";

        private const string IsGTINExistsInItemFormsSQL = @"SELECT count(*) FROM PackagingHierarchy
                                                         WHERE (MasterCaseGTIN = @Gtin OR InnerCaseGTIN = @Gtin )";

        private const string InsertBasicItemDefinitionAdditionalGTINSQL = @"INSERT INTO [S0VPITEM].[dbo].[AdditionalGTIN]
           ([ItemFormID]
           ,[GTIN]
           ,[GTINCheckDigit]
           ,[ExistingGTINIndicator]
           ,[CompressedUPC]
           ,[PriceLookupCode]
           ,[OverrideReceiptDescription]
           ,[RetailPackType]
           ,[RetailPackTypeDescription]
           ,[RetailPackSize]
           ,[Size]
           ,[SizeUOM]
           ,[SizeUOMDescription]
           ,[LabelAmount]
           ,[NonDiscountable]
           ,[CreatedBy]
           ,[CreatedDate]
           )
     VALUES
           (@ItemFormID
           , @GTIN
           , @GTINCheckDigit
           , @ExistingGTINIndicator
           , @CompressedUPC
           , @PriceLookupCode
           , @OverrideReceiptDescription
           , @RetailPackType
           , @RetailPackTypeDescription
           , @RetailPackSize
           , @Size
           , @SizeUOM
           , @SizeUOMDescription
           , @LabelAmount
           , @NonDiscountable
           , @CreatedBy
           , getDate()
           );";


        private const string InsertBasicItemDefinitionSQL = @"INSERT INTO [S0VPITEM].[dbo].[BasicItemDefinition]
           (
            [ItemFormID]
           ,[ItemTypeCode]
           ,[ItemTypeDescription]
           ,[GTIN]
           ,[GTINCheckDigit]
           ,[ExistingGTINIndicator]
           ,[CompressedUPC]
           ,[PriceLookupCode]
           ,[ReUseItemCode]
           ,[ReUseItemDescription]
           ,[SubmissionReasonID]
           ,[ItemCaseTypeID]
           ,[RecipeRequired]
           ,[IngredientItemRequired]
           ,[ModelProductItemCode]
           ,[ModelProductItemDescription]
           ,[ModelPackagingItemCode]
           ,[ModelPackagingItemDescription]
           ,[VendorItemCode]
           ,[VendorItemDescription]
           ,[ItemDescription]
           ,[Brand]
           ,[Manufacturer]
           ,[RetailPackagedItem]
           ,[RetailPackType]
           ,[RetailPackTypeDescription]
           ,[RetailPackSize]
           ,[Size]
           ,[SizeUOM]
           ,[SizeUOMDescription]
           ,[MinorityManufacturer]
           ,[PackageDescription]
           ,[ContainerType]
           ,[LabelAmount]
           ,[PerpetualInventoryFlag]
           ,[ReceiptDescription]
           ,[AdDescription]
           ,[ProductCatalogShortDescription1]
           ,[ProductCatalogShortDescription2]
           ,[NonDiscountable]           
           ,[AdditionalGTINPresent]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate]
            ,LastScanDate)
     VALUES
           (
             @ItemFormID 
            , @ItemTypeCode
           , @ItemTypeDescription
           , @GTIN
           , @GTINCheckDigit
           , @ExistingGTINIndicator
           , @CompressedUPC
           , @PriceLookupCode
           , @ReUseItemCode
           , @ReUseItemDescription
           , @SubmissionReasonID
           , @ItemCaseTypeID
           , @RecipeRequired
           , @IngredientItemRequired
           , @ModelProductItemCode
           , @ModelProductItemDescription
           , @ModelPackagingItemCode
           , @ModelPackagingItemDescription
           , @VendorItemCode
           , @VendorItemDescription
           , @ItemDescription
           , @Brand
           , @Manufacturer
           , @RetailPackagedItem
           , @RetailPackType
           , @RetailPackTypeDescription
           , @RetailPackSize
           , @Size
           , @SizeUOM
           , @SizeUOMDescription
           , @MinorityManufacturer
           , @PackageDescription
           , @ContainerType
           , @LabelAmount
           , @PerpetualInventoryFlag
           , @ReceiptDescription
           , @AdDescription
           , @ProductCatalogShortDescription1
           , @ProductCatalogShortDescription2
           , @NonDiscountable
           , @AdditionalGTINPresent
           , @CreatedBy
           , getDate()
           , @LastUpdatedBy
           , getDate()
           ,@LastScanDate );";

        private const string GetSubmissionReasonsSQL = @" SELECT ID AS Code, Name AS Description
                                    FROM [dbo].[SubmissionReason]   WHERE IsActive = @IsActive
                                    ORDER BY ID ";

        private const string InsertItemFormSQL = @"DECLARE @ItemFormDisplayFormID as bigint,@FormId int
WITH ItemFormIDs (FormId)  
AS  
(  
   SELECT FormId from ItemForm where CAST(CreatedDate AS DATE) = CAST(GETDATE() AS DATE)
   UNION
   SELECT FormId from ItemFormAudit where CAST(CreatedDate AS DATE) = CAST(GETDATE() AS DATE)
   UNION 
   SELECT 0  
)  
SELECT @ItemFormDisplayFormID =CAST( CONCAT(CONVERT(VARCHAR(8), GETDATE(), 112) , FORMAT(MAX(FormId)+1,'0000'))AS bigint)
,@FormId = MAX(FormId)+1
FROM ItemFormIDs; 

INSERT INTO [S0VPITEM].[dbo].[ItemForm]
           (FormId
			,ItemFormDisplayID
            ,[FormTypeID]
           ,[SubmissionDate]
           ,[SubmittedBy]
           ,[SubmittedUserTypeID]
           ,[FormStatusID]
           ,[FormActionID]
           ,[PendingRoleUserTypeID]
           ,[DSDAuthRequestSelectStoreOption]
           , VendorContactID          
           ,[CreatedBy]
           ,[CreatedDate]
           )
     VALUES
           (@FormId
           ,@ItemFormDisplayFormID
           ,@FormTypeID
           , getDate()
           , @SubmittedBy
           , @SubmittedUserTypeID
           , @FormStatusID
           , @FormActionID
           , @PendingRoleUserTypeID
           , @VendorContactID
           , @DSDAuthRequestSelectStoreOption          
           , @CreatedBy
           , getDate()
           );SELECT @ItemFormDisplayFormID AS ItemFormDisplayID,SCOPE_IDENTITY() AS ID";

        private const string GetItemCaseTypesSQL = @" SELECT ID AS Code, Name AS Description
                                    FROM [dbo].[ItemCaseType]   WHERE IsActive = 1
                                    ORDER BY ID ";

        private const string GetReuseItemSubDepartmentsSQL = @"  select distinct subDeptCode as Code,SubDepartmentName as Description from ReUseItemCode  WHERE ItemFormID IS NULL ORDER BY SubDepartmentName ";




        private const string GetBasicItemDefinitionDataSQL = @"SELECT
                                                                    IFM.ItemFormDisplayID  
                                                                    ,BID.ItemFormID
		                                                            ,BID.[ItemTypeCode]
		                                                            ,BID.[ItemTypeDescription]
                                                                    ,BID.[AutoGenerateType4GTIN]
		                                                            ,BID.[GTIN]
		                                                            ,BID.[GTINCheckDigit]
		                                                            ,BID.[ExistingGTINIndicator]
		                                                            ,BID.[CompressedUPC]
		                                                            ,BID.[PriceLookupCode]
		                                                            ,BID.[ReUseItemCode]
		                                                            ,BID.[ReUseItemDescription]
		                                                            ,BID.[SubmissionReasonID]
		                                                            ,BID.[ItemCaseTypeID]
		                                                            ,BID.[RecipeRequired]
		                                                            ,BID.[IngredientItemRequired]
		                                                            ,BID.[ModelProductItemCode]
		                                                            ,BID.[ModelProductItemDescription]
                                                                    ,BID.[ModelProductItemTypeCode]
		                                                            ,BID.[ModelPackagingItemCode]
		                                                            ,BID.[ModelPackagingItemDescription]
                                                                    ,BID.[ModelPackagingItemTypeCode]
		                                                            ,BID.[VendorItemCode]
		                                                            ,BID.[VendorItemDescription]
		                                                            ,BID.[ItemDescription]
		                                                            ,BID.[Brand]
		                                                            ,BID.[Manufacturer]
		                                                            ,BID.[RetailPackagedItem]
		                                                            ,BID.[RetailPackType]
		                                                            ,BID.[RetailPackTypeDescription]
		                                                            ,BID.[RetailPackSize]
		                                                            ,BID.[Size]
		                                                            ,BID.[SizeUOM]
		                                                            ,BID.[SizeUOMDescription]
		                                                            ,BID.[MinorityManufacturer]
		                                                            ,BID.[PackageDescription]
		                                                            ,BID.[ContainerType]
		                                                            ,BID.[LabelAmount]
		                                                            ,BID.[PerpetualInventoryFlag]
		                                                            ,BID.[ReceiptDescription]
		                                                            ,BID.[AdDescription]
		                                                            ,BID.[ProductCatalogShortDescription1]
		                                                            ,BID.[ProductCatalogShortDescription2]
		                                                            ,BID.[NonDiscountable]
		                                                            ,BID.[AdditionalGTINPresent]
		                                                            ,BID.LastScanDate
		                                                            ,SI.BackroomScaleIndicator
		                                                            ,SI.ScaleDescription1
		                                                            ,SI.ScaleDescription2
		                                                            ,IIF((MI.Brand IS NOT NULL AND ISNULL(BID.Brand,'') != ISNULL(MI.Brand,'')),1, 0 ) AS IsBrandChanged
		                                                            ,IIF((MI.Manufacturer IS NOT NULL AND ISNULL(BID.Manufacturer,'') != ISNULL(MI.Manufacturer,'')),1, 0 ) AS IsManufacturerChanged
		                                                            ,IFM.SubmittedUserTypeID
		                                                            ,IFM.FormStatusID
		                                                            ,IFM.FormTypeID
		                                                            ,IFM.FormActionID
                                                                    ,IFM.ItemCode
                                                            FROM [dbo].[BasicItemDefinition] BID
                                                            INNER JOIN ItemForm IFM ON IFM.ID = BID.ItemFormID
                                                            LEFT OUTER JOIN [dbo].[ScaleInfo] SI ON BID.ItemFormID = SI.ItemFormID
                                                            LEFT OUTER JOIN [dbo].[ModelProductItemValue] MI ON BID.ItemFormID = MI.ItemFormID
                                                            WHERE IFM.ID = @ItemFormID AND IFM.FormStatusID != 2";

        
        private const string GetAdditionalGTINSQL = @"SELECT       
	   [ItemFormID]
      ,[GTIN]
      ,[GTINCheckDigit]
      ,[ExistingGTINIndicator]
      ,[CompressedUPC]
      ,[PriceLookupCode]
      ,[OverrideReceiptDescription]
      ,[RetailPackType]
      ,[RetailPackTypeDescription]
      ,[RetailPackSize]
      ,[Size]
      ,[SizeUOM]
      ,[SizeUOMDescription]
      ,[LabelAmount]
      ,[NonDiscountable]     
  FROM [dbo].[AdditionalGTIN]
  INNER JOIN ItemForm ON [AdditionalGTIN].ItemFormID = ItemForm.ID 
   WHERE ItemForm.ID = @ItemFormID AND ItemForm.FormStatusID != 2";







        //private const string GetItemFormDisplayIDSQL = @"SELECT TOP 30 ItemFormDisplayID FROM ItemForm
        //                                                 WHERE CreatedBy = @UserId AND [FormStatusID] != 2 
        //                                                 ORDER BY ID Desc";

        private const string GetItemFormDisplayIDSQL = @"SELECT TOP 30 ItemFormDisplayID FROM ItemForm
                                                         WHERE  [FormStatusID] != 2 AND FormTypeId NOT IN(3,4)
                                                         ORDER BY ID Desc";



        private const string UpdateItemFormSQL = @"
                        UPDATE [S0VPITEM].[dbo].[ItemForm]
                        SET 
                        [SubmittedUserTypeID] = @SubmittedUserTypeID,
                        [FormTypeID] = @FormTypeID,
                        [FormStatusID] = @FormStatusID,
                        [FormActionID] = @FormActionID,
                        [LastUpdatedBy] = @LastUpdatedBy,
                        [LastUpdatedDate] = getDate(),
                        [ItemCode] = @ItemCode
                        WHERE ID = @ItemFormID";

       

        private const string MergeBasicItemFormDefnitionSQL = @"
        MERGE [BasicItemDefinition] AS target
USING (SELECT @ItemFormID  AS ItemFormID ,	@ItemTypeCode  AS ItemTypeCode ,	@ItemTypeDescription  AS ItemTypeDescription ,	@AutoGenerateType4GTIN AS AutoGenerateType4GTIN, @GTIN  AS GTIN ,	@GTINCheckDigit AS GTINCheckDigit,
@ExistingGTINIndicator AS ExistingGTINIndicator,	@CompressedUPC  AS CompressedUPC ,	@PriceLookupCode AS PriceLookupCode,	@ReUseItemCode  AS ReUseItemCode ,	
@ReUseItemDescription AS ReUseItemDescription,	@SubmissionReasonID AS SubmissionReasonID,	@ItemCaseTypeID  AS ItemCaseTypeID ,	@RecipeRequired AS RecipeRequired,	
@IngredientItemRequired AS IngredientItemRequired,	@ModelProductItemCode  AS ModelProductItemCode ,	@ModelProductItemDescription  AS ModelProductItemDescription ,@ModelProductItemTypeCode AS ModelProductItemTypeCode,	
@ModelPackagingItemCode AS ModelPackagingItemCode,	@ModelPackagingItemDescription AS ModelPackagingItemDescription, @ModelPackagingItemTypeCode AS ModelPackagingItemTypeCode,	@VendorItemCode  AS VendorItemCode ,	
@VendorItemDescription  AS VendorItemDescription ,	@ItemDescription  AS ItemDescription ,	@Brand  AS Brand ,	@Manufacturer  AS Manufacturer ,	
@RetailPackagedItem AS RetailPackagedItem,	@RetailPackType  AS RetailPackType ,	@RetailPackTypeDescription  AS RetailPackTypeDescription ,	
@RetailPackSize  AS RetailPackSize ,	@Size  AS Size ,	@SizeUOM  AS SizeUOM ,	@SizeUOMDescription  AS SizeUOMDescription ,	
@MinorityManufacturer AS MinorityManufacturer,	@PackageDescription AS PackageDescription,	@ContainerType  AS ContainerType ,	
@LabelAmount  AS LabelAmount ,	@PerpetualInventoryFlag  AS PerpetualInventoryFlag ,	@ReceiptDescription  AS ReceiptDescription ,	
@AdDescription  AS AdDescription ,	@ProductCatalogShortDescription1 AS ProductCatalogShortDescription1,	 @ProductCatalogShortDescription2   AS ProductCatalogShortDescription2 ,
@NonDiscountable  AS NonDiscountable ,	@AdditionalGTINPresent  AS AdditionalGTINPresent ,	@CreatedBy  AS CreatedBy ,	
@LastUpdatedBy  AS LastUpdatedBy ,	@LastScanDate AS LastScanDate
) AS source
ON		1=1 AND target.[ItemFormID] = source.[ItemFormID]
WHEN MATCHED THEN
    UPDATE 
   SET [ItemTypeCode] = source.ItemTypeCode
      , [ItemTypeDescription] = source.ItemTypeDescription
      , [AutoGenerateType4GTIN] = source.AutoGenerateType4GTIN
      , [GTIN] = source.GTIN
      , [GTINCheckDigit] = source.GTINCheckDigit
      , [ExistingGTINIndicator] = source.ExistingGTINIndicator
      , [CompressedUPC] = source.CompressedUPC
      , [PriceLookupCode] = source.PriceLookupCode
      , [ReUseItemCode] = source.ReUseItemCode
      , [ReUseItemDescription] = source.ReUseItemDescription
      , [SubmissionReasonID] = source.SubmissionReasonID
      , [ItemCaseTypeID] = source.ItemCaseTypeID
      , [RecipeRequired] = source.RecipeRequired
      , [IngredientItemRequired] = source.IngredientItemRequired
      , [ModelProductItemCode] = source.ModelProductItemCode
      , [ModelProductItemDescription] = source.ModelProductItemDescription
       , [ModelProductItemTypeCode]  = source.ModelProductItemTypeCode
      , [ModelPackagingItemCode] = source.ModelPackagingItemCode
      , [ModelPackagingItemDescription] = source.ModelPackagingItemDescription
        ,[ModelPackagingItemTypeCode] = source.ModelPackagingItemTypeCode
      , [VendorItemCode] = source.VendorItemCode
      , [VendorItemDescription] = source.VendorItemDescription
      , [ItemDescription] = source.ItemDescription
      , [Brand] = source.Brand
      , [Manufacturer] = source.Manufacturer
      , [RetailPackagedItem] = source.RetailPackagedItem
      , [RetailPackType] = source.RetailPackType
      , [RetailPackTypeDescription] = source.RetailPackTypeDescription
      , [RetailPackSize] = source.RetailPackSize
      , [Size] = source.Size
      , [SizeUOM] = source.SizeUOM
      , [SizeUOMDescription] = source.SizeUOMDescription
      , [MinorityManufacturer] = source.MinorityManufacturer
      , [PackageDescription] = source.PackageDescription
      , [ContainerType] = source.ContainerType
      , [LabelAmount] = source.LabelAmount
      , [PerpetualInventoryFlag] = source.PerpetualInventoryFlag
      , [ReceiptDescription] = source.ReceiptDescription
      , [AdDescription] = source.AdDescription
      , [ProductCatalogShortDescription1] = source.ProductCatalogShortDescription1
      , [ProductCatalogShortDescription2] = source.ProductCatalogShortDescription2
      , [NonDiscountable] = source.NonDiscountable
      , [AdditionalGTINPresent] = source.AdditionalGTINPresent
      , [LastUpdatedBy] = source.LastUpdatedBy
      , [LastUpdatedDate] = getdate()
      , [LastScanDate] = source.LastScanDate
WHEN NOT MATCHED BY TARGET THEN
    INSERT 
           (
            [ItemFormID]
           , [ItemTypeCode]
           , [ItemTypeDescription]
           , [AutoGenerateType4GTIN]
           , [GTIN]
           , [GTINCheckDigit]
           , [ExistingGTINIndicator]
           , [CompressedUPC]
           , [PriceLookupCode]
           , [ReUseItemCode]
           , [ReUseItemDescription]
           , [SubmissionReasonID]
           , [ItemCaseTypeID]
           , [RecipeRequired]
           , [IngredientItemRequired]
           , [ModelProductItemCode]
           , [ModelProductItemDescription]
           , [ModelProductItemTypeCode]
           , [ModelPackagingItemCode]
           , [ModelPackagingItemDescription]
           , [ModelPackagingItemTypeCode]
           , [VendorItemCode]
           , [VendorItemDescription]
           , [ItemDescription]
           , [Brand]
           , [Manufacturer]
           , [RetailPackagedItem]
           , [RetailPackType]
           , [RetailPackTypeDescription]
           , [RetailPackSize]
           , [Size]
           , [SizeUOM]
           , [SizeUOMDescription]
           , [MinorityManufacturer]
           , [PackageDescription]
           , [ContainerType]
           , [LabelAmount]
           , [PerpetualInventoryFlag]
           , [ReceiptDescription]
           , [AdDescription]
           , [ProductCatalogShortDescription1]
           , [ProductCatalogShortDescription2]
           , [NonDiscountable]
           , [AdditionalGTINPresent]
           , [CreatedBy]
           , [CreatedDate]
            , LastScanDate)
     VALUES
           (
             source.ItemFormID
            , source.ItemTypeCode
           , source.ItemTypeDescription
           , source.AutoGenerateType4GTIN
           , source.GTIN
           , source.GTINCheckDigit
           , source.ExistingGTINIndicator
           , source.CompressedUPC
           , source.PriceLookupCode
           , source.ReUseItemCode
           , source.ReUseItemDescription
           , source.SubmissionReasonID
           , source.ItemCaseTypeID
           , source.RecipeRequired
           , source.IngredientItemRequired
           , source.ModelProductItemCode
           , source.ModelProductItemDescription
           , source.ModelProductItemTypeCode
           , source.ModelPackagingItemCode
           , source.ModelPackagingItemDescription
           , source.ModelPackagingItemTypeCode
           , source.VendorItemCode
           , source.VendorItemDescription
           , source.ItemDescription
           , source.Brand
           , source.Manufacturer
           , source.RetailPackagedItem
           , source.RetailPackType
           , source.RetailPackTypeDescription
           , source.RetailPackSize
           , source.Size
           , source.SizeUOM
           , source.SizeUOMDescription
           , source.MinorityManufacturer
           , source.PackageDescription
           , source.ContainerType
           , source.LabelAmount
           , source.PerpetualInventoryFlag
           , source.ReceiptDescription
           , source.AdDescription
           , source.ProductCatalogShortDescription1
           , source.ProductCatalogShortDescription2
           , source.NonDiscountable
           , source.AdditionalGTINPresent
           , source.CreatedBy
           , getDate()
           ,source.LastScanDate );";

        private const string DeleteAdditionalGTINSQL = @"DELETE FROM [dbo].[AdditionalGTIN] WHERE 
ItemFormID = @ItemFormID";

        private const string GetItemFormIdByDisplayIDSQL = @"SELECT ID FROM [dbo].[ItemForm] WHERE ItemFormDisplayID = @ItemFormDisplayID";

        private const string GetAvailableItemFormReuseItemCodesBySubDeptSQL = @"SELECT[ItemCode]
                                                                                ,[ItemDescription]
                                                                                ,[SubDeptCode]
                                                                                ,[ItemFormID]
                                                                                FROM[S0VPITEM].[dbo].[ReUseItemCode]
                                                                                WHERE SubDeptCode = @SubDeptCode  AND ((ItemFormID IS NULL) OR (ItemFormID=@ItemFormID and Status = 'L')) order by ItemDescription";

        private const string UnbindPreviousReuseItemCodeFromFormSQL = @"Update[ReUseItemCode] set ItemFormID = null where ItemFormID = @ItemFormID and [SubDeptCode] = @SubDeptCode;";
        private const string LockCurrentReuseItemCodeToFormSQL = @"Update [ReUseItemCode]  set ItemFormID = @ItemFormID,Status = 'L'  where ItemCode = @ItemCode and [SubDeptCode] = @SubDeptCode";
        private const string AssignCurrentReuseItemCodeToFormSQL = @"Update [ReUseItemCode]  set ItemFormID = null,Status = null WHERE ItemFormID = @ItemFormID; Update [ReUseItemCode]  set ItemFormID = @ItemFormID,Status = 'A'  where ItemCode = @ItemCode ";

        private const string GetSubDeptForReuseItemCodeSQL = @"SELECT SubDeptCode FROM ReUseItemCode WHERE itemcode = @ItemCode";

        private const string GetItemFormReuseItemCodesBySubDeptSQL = @"SELECT  [ItemCode], [ItemDescription], [SubDeptCode], [ItemFormID]
                                                    FROM [dbo].[ReUseItemCode] WHERE [SubDeptCode] = @SubDeptCode";

        private const string IsSelectedReuseItemCodeAlreadyUsedSQL = @"Declare @ResultMessage varchar(25)
                                                                    IF NOT EXISTS (SELECT * FROM [dbo].[ReUseItemCode]  WHERE [ItemCode] = @ItemCode)
                                                                    SET @ResultMessage = 'Invalid'
                                                                    ELSE IF EXISTS (SELECT * FROM [dbo].[ReUseItemCode]  WHERE [ItemCode] = @ItemCode AND [ItemFormID] IS NOT NULL AND [ItemFormID] != @ItemFormID)
                                                                    SET @ResultMessage = 'NotAvailable' 
                                                                    ELSE
                                                                    SET @ResultMessage = 'Available'
                                                                    SELECT @ResultMessage";
        
              

        private const string DeleteReuseItemCodeByItemFormIdSQL = @"DELETE FROM [dbo].[ReUseItemCode] WHERE ([ItemFormID] = @ItemFormID OR ItemCode = @ItemCode)";

        private const string InsertReuseItemCodeSQL = @"INSERT INTO [dbo].[ReUseItemCode] (ItemCode, ItemDescription, SubDeptCode, ItemFormID, CreatedBy, CreatedDate)
        VALUES(@ItemCode, @ItemDescription, @SubDeptCode, @ItemFormID, @CreatedBy, getDate())";

        private const string DeleteUnAvailableReuseItemCodesSQL = @"DELETE FROM [dbo].[ReUseItemCode] WHERE ItemCode = @ItemCode";



        private const string InsertGeneralProductAttributesSQL = @" INSERT INTO [dbo].[GeneralProductAttribute]
           ([ItemFormID]
           ,[PerishableItem]
           ,[ProductDate]
           ,[BornOnDays]
           ,[CountryOfOrigin]
           ,[Hazardous]
           ,[Ignitable]
           ,[Corrosive]
           ,[Reactive]
           ,[Toxic]
           ,[EPAListedWaste]
           ,[ContainsBattery]
           ,[EMailForBatterySurvey]
           ,[DEARegulated]
           ,[Narcotic]
           ,[DrugScheduleCode]
           ,[NDCNumber]
           ,[NDCFormat]
           ,[NDCFormatDescription]
           ,[Disinfectant]
           ,[Allergic]
           ,[GlutenFree]
           ,[OrganicTypesID]
           ,[GreenLeaf]
           ,[Pesticide]
           ,[Liquor]
           ,[LiquorDescription]
           ,[Tobacco]
           ,[VariableWeightIndicator]
           ,[RandomWeight]
           ,[FoodStamp]
           ,[UnitPricingCount]
           ,[UnitPricingUOM]
           ,[TagCount]
           ,[TagSize]
           ,[SeasonalItem]
           ,[SeasonBeginDate]
           ,[SeasonEndDate]
           ,[MinDaysRequired]
           ,[MaxDaysRequired]
           ,[WhseShelfLife]
           ,[IgnoreQuantityCheck]
           ,[BioFlag]
           ,[ActivationProtectionEndDate]
           ,[ManuallyOrderedItem]
           ,[NutritionalInfoNotAvailableUntil]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     VALUES
           (@ItemFormID
           ,@PerishableItem
           ,@ProductDate
           ,@BornOnDays
           ,@CountryOfOrigin
           ,@Hazardous
           ,@Ignitable
           ,@Corrosive
           ,@Reactive
           ,@Toxic
           ,@EPAListedWaste
           ,@ContainsBattery
           ,@EMailForBatterySurvey
           ,@DEARegulated
           ,@Narcotic
           ,@DrugScheduleCode
           ,@NDCNumber
           ,@NDCFormat
           ,@NDCFormatDescription
           ,@Disinfectant
           ,@Allergic
           ,@GlutenFree
           ,@OrganicTypesID
           ,@GreenLeaf
           ,@Pesticide
           ,@Liquor
           ,@LiquorDescription
           ,@Tobacco
           ,@VariableWeightIndicator
           ,@RandomWeight
           ,@FoodStamp
           ,@UnitPricingCount
           ,@UnitPricingUOM
           ,@TagCount
           ,@TagSize
           ,@SeasonalItem
           ,@SeasonBeginDate
           ,@SeasonEndDate
           ,@MinDaysRequired
           ,@MaxDaysRequired
           ,@WhseShelfLife
           ,@IgnoreQuantityCheck
           ,@BioFlag
           ,@ActivationProtectionEndDate
           ,@ManuallyOrderedItem
           ,null
           ,@CreatedBy
           ,GetDate()
           ,@LastUpdatedBy
           ,GetDate())";

        private const string SaveModelProductItemValuesSQL = @"MERGE[dbo].[ModelProductItemValue] AS target
                                                USING(
                                                SELECT
                                                @ItemFormID AS ItemFormID
                                                , @Brand AS Brand
                                                , @Manufacturer AS Manufacturer
                                                , @ItemDescription AS ItemDescription
                                                , @ReceiptDescription AS ReceiptDescription
                                                , @ScaleDescription1 AS ScaleDescription1
                                                , @ScaleDescription2 AS ScaleDescription2
                                                , @AdDescription AS AdDescription
                                                , @ProductCatalogShortDescription1 AS ProductCatalogShortDescription1
                                                , @ProductCatalogShortDescription2 AS ProductCatalogShortDescription2
                                                , @CreatedBy AS CreatedBy
                                                , getdate() AS CreatedDate
                                                 , @LastUpdatedBy AS LastUpdatedBy
                                                  , getdate() AS LastUpdatedDate
                                                  ) AS source
                                                ON		1=1 AND target.[ItemFormID] = source.[ItemFormID]
                                                WHEN MATCHED THEN
                                                    UPDATE
                                                   SET
                                                        Brand = source.Brand,
                                                        Manufacturer        = source.Manufacturer,
                                                        ItemDescription     = source.ItemDescription,
                                                        ReceiptDescription  = source.ReceiptDescription,
                                                        ScaleDescription1   = source.ScaleDescription1,
                                                        ScaleDescription2   = source.ScaleDescription2,
                                                        AdDescription       = source.AdDescription,
                                                        ProductCatalogShortDescription1 = source.ProductCatalogShortDescription1,
                                                        ProductCatalogShortDescription2 = source.ProductCatalogShortDescription2,
                                                        LastUpdatedBy   = source.LastUpdatedBy,
                                                        LastUpdatedDate = source.LastUpdatedDate
                                                WHEN NOT MATCHED BY TARGET THEN
                                                    INSERT
                                                           ([ItemFormID]
                                                           , [Brand]
                                                           , [Manufacturer]
                                                           , [ItemDescription]
                                                           , [ReceiptDescription]
                                                           , [ScaleDescription1]
                                                           , [ScaleDescription2]
                                                           , [AdDescription]
                                                           , [ProductCatalogShortDescription1]
                                                           , [ProductCatalogShortDescription2]
                                                           , [CreatedBy]
                                                           , [CreatedDate])
                                                     VALUES
                                                           (
                                                                source.ItemFormID,
                                                                source.Brand,
                                                                source.Manufacturer,
                                                                source.ItemDescription,
                                                                source.ReceiptDescription,
                                                                source.ScaleDescription1,
                                                                source.ScaleDescription2,
                                                                source.AdDescription,
                                                                source.ProductCatalogShortDescription1,
                                                                source.ProductCatalogShortDescription2,
                                                                source.CreatedBy,
                                                                source.CreatedDate

                                                            );";

        private const string GetModelProductItemValuesSQL = @"SELECT [ItemFormID]
                                                              ,[Brand]
                                                              ,[Manufacturer]
                                                              ,[ItemDescription]
                                                              ,[ReceiptDescription]
                                                              ,[ScaleDescription1]
                                                              ,[ScaleDescription2]
                                                              ,[AdDescription]
                                                              ,[ProductCatalogShortDescription1]
                                                              ,[ProductCatalogShortDescription2]
                                                                FROM [dbo].[ModelProductItemValue]
                                                            INNER JOIN ItemForm ON [dbo].[ModelProductItemValue].ItemFormID = ItemForm.ID
                                                            WHERE [dbo].[ModelProductItemValue].ItemFormID = @ItemFormID AND ItemForm.FormStatusID != 2";

        private const string DeleteModelProductItemValuesSQL = @"DELETE FROM [dbo].[ModelProductItemValue] WHERE ItemFormID = @ItemFormID";

        private const string SaveScaleInfoSQL = @"MERGE [dbo].[ScaleInfo] AS target
	                                            USING(
		                                            SELECT
		                                            @ItemFormID AS ItemFormID
		                                            , @BackroomScaleIndicator AS BackroomScaleIndicator
		                                            , @ScaleDescription1 AS ScaleDescription1
		                                            , @ScaleDescription2 AS ScaleDescription2
		                                            , @CreatedBy AS CreatedBy
		                                            , getdate() AS CreatedDate
		                                            , @LastUpdatedBy AS LastUpdatedBy
		                                            , getdate() AS LastUpdatedDate
		                                            ) AS source
	                                            ON		1=1 AND target.[ItemFormID] = source.[ItemFormID]
	                                            WHEN MATCHED THEN
		                                            UPDATE
		                                            SET 
		                                               [BackroomScaleIndicator] =	source.BackroomScaleIndicator
		                                              ,[ScaleDescription1]		=	source.ScaleDescription1
		                                              ,[ScaleDescription2]		=	source.ScaleDescription2
		                                              ,[LastUpdatedBy]			=	source.LastUpdatedBy
		                                              ,[LastUpdatedDate]		=	source.LastUpdatedDate
	                                            WHEN NOT MATCHED BY TARGET THEN
		                                            INSERT
		                                            ([ItemFormID]
		                                            ,[BackroomScaleIndicator]
		                                            ,[ScaleDescription1]
		                                            ,[ScaleDescription2]
		                                            ,[CreatedBy]
		                                            ,[CreatedDate])
		                                            VALUES
		                                            (
		                                            source.ItemFormID
		                                            ,source.BackroomScaleIndicator
		                                            ,source.ScaleDescription1
		                                            ,source.ScaleDescription2	
		                                            ,source.CreatedBy
		                                            ,source.CreatedDate
		                                            );";

        private const string AuditBasicItemFormDefnitionSQL = @"INSERT INTO [dbo].[BasicItemDefinitionAudit]
                                                                   ([Version]
                                                                   ,[ItemFormID]
                                                                   ,[ItemTypeCode]
                                                                   ,[ItemTypeDescription]
                                                                   ,[AutoGenerateType4GTIN]
                                                                   ,[GTIN]
                                                                   ,[GTINCheckDigit]
                                                                   ,[ExistingGTINIndicator]
                                                                   ,[CompressedUPC]
                                                                   ,[PriceLookupCode]
                                                                   ,[ReUseItemCode]
                                                                   ,[ReUseItemDescription]
                                                                   ,[SubmissionReasonID]
                                                                   ,[ItemCaseTypeID]
                                                                   ,[RecipeRequired]
                                                                   ,[IngredientItemRequired]
                                                                   ,[ModelProductItemCode]
                                                                   ,[ModelProductItemDescription]
                                                                   ,[ModelPackagingItemCode]
                                                                   ,[ModelPackagingItemDescription]
                                                                   ,[VendorItemCode]
                                                                   ,[VendorItemDescription]
                                                                   ,[ItemDescription]
                                                                   ,[Brand]
                                                                   ,[Manufacturer]
                                                                   ,[RetailPackagedItem]
                                                                   ,[RetailPackType]
                                                                   ,[RetailPackTypeDescription]
                                                                   ,[RetailPackSize]
                                                                   ,[Size]
                                                                   ,[SizeUOM]
                                                                   ,[SizeUOMDescription]
                                                                   ,[MinorityManufacturer]
                                                                   ,[PackageDescription]
                                                                   ,[ContainerType]
                                                                   ,[LabelAmount]
                                                                   ,[PerpetualInventoryFlag]
                                                                   ,[ReceiptDescription]
                                                                   ,[AdDescription]
                                                                   ,[ProductCatalogShortDescription1]
                                                                   ,[ProductCatalogShortDescription2]
                                                                   ,[NonDiscountable]
                                                                   ,[AdditionalGTINPresent]
                                                                   ,[CreatedBy]
                                                                   ,[CreatedDate]
                                                                   ,[LastUpdatedBy]
                                                                   ,[LastUpdatedDate]
                                                                   ,[LastScanDate])
                                                            SELECT  getDate(),
	                                                               [ItemFormID]
                                                                  ,[ItemTypeCode]
                                                                  ,[ItemTypeDescription]
                                                                  ,[AutoGenerateType4GTIN]
                                                                  ,[GTIN]
                                                                  ,[GTINCheckDigit]
                                                                  ,[ExistingGTINIndicator]
                                                                  ,[CompressedUPC]
                                                                  ,[PriceLookupCode]
                                                                  ,[ReUseItemCode]
                                                                  ,[ReUseItemDescription]
                                                                  ,[SubmissionReasonID]
                                                                  ,[ItemCaseTypeID]
                                                                  ,[RecipeRequired]
                                                                  ,[IngredientItemRequired]
                                                                  ,[ModelProductItemCode]
                                                                  ,[ModelProductItemDescription]
                                                                  ,[ModelPackagingItemCode]
                                                                  ,[ModelPackagingItemDescription]
                                                                  ,[VendorItemCode]
                                                                  ,[VendorItemDescription]
                                                                  ,[ItemDescription]
                                                                  ,[Brand]
                                                                  ,[Manufacturer]
                                                                  ,[RetailPackagedItem]
                                                                  ,[RetailPackType]
                                                                  ,[RetailPackTypeDescription]
                                                                  ,[RetailPackSize]
                                                                  ,[Size]
                                                                  ,[SizeUOM]
                                                                  ,[SizeUOMDescription]
                                                                  ,[MinorityManufacturer]
                                                                  ,[PackageDescription]
                                                                  ,[ContainerType]
                                                                  ,[LabelAmount]
                                                                  ,[PerpetualInventoryFlag]
                                                                  ,[ReceiptDescription]
                                                                  ,[AdDescription]
                                                                  ,[ProductCatalogShortDescription1]
                                                                  ,[ProductCatalogShortDescription2]
                                                                  ,[NonDiscountable]
                                                                  ,[AdditionalGTINPresent]
                                                                  ,[CreatedBy]
                                                                  ,[CreatedDate]
                                                                  ,[LastUpdatedBy]
                                                                  ,[LastUpdatedDate]
                                                                  ,[LastScanDate]
                                                          FROM [dbo].[BasicItemDefinition] WHERE [ItemFormID] = @ItemFormID";

        private const string AuditAdditionalGTINSQL = @"INSERT INTO [dbo].[AdditionalGTINAudit]
                                                   ([Version]
                                                   ,[ItemFormID]
                                                   ,[GTIN]
                                                   ,[GTINCheckDigit]
                                                   ,[ExistingGTINIndicator]
                                                   ,[CompressedUPC]
                                                   ,[PriceLookupCode]
                                                   ,[OverrideReceiptDescription]
                                                   ,[RetailPackType]
                                                   ,[RetailPackTypeDescription]
                                                   ,[RetailPackSize]
                                                   ,[Size]
                                                   ,[SizeUOM]
                                                   ,[SizeUOMDescription]
                                                   ,[LabelAmount]
                                                   ,[NonDiscountable]
                                                   ,[CreatedBy]
                                                   ,[CreatedDate]
                                                   ,[LastUpdatedBy]
                                                   ,[LastUpdatedDate])
                                         SELECT getdate()
                                              ,[ItemFormID]
                                              ,[GTIN]
                                              ,[GTINCheckDigit]
                                              ,[ExistingGTINIndicator]
                                              ,[CompressedUPC]
                                              ,[PriceLookupCode]
                                              ,[OverrideReceiptDescription]
                                              ,[RetailPackType]
                                              ,[RetailPackTypeDescription]
                                              ,[RetailPackSize]
                                              ,[Size]
                                              ,[SizeUOM]
                                              ,[SizeUOMDescription]
                                              ,[LabelAmount]
                                              ,[NonDiscountable]
                                              ,[CreatedBy]
                                              ,[CreatedDate]
                                              ,[LastUpdatedBy]
                                              ,[LastUpdatedDate]
                                                FROM[dbo].[AdditionalGTIN]
                                        WHERE [ItemFormID] = @ItemFormID";

        private const string AuditScaleInfoSQL = @"INSERT INTO [dbo].[ScaleInfoAudit]
                                                    ([Version]
                                                    ,[ItemFormID]
                                                    ,[BackroomScaleIndicator]
                                                    ,[ScaleDescription1]
                                                    ,[ScaleDescription2]
                                                    ,[CalorieInformation]
                                                    ,[Tare]
                                                    ,[ScaleExtraTextRequired]
                                                    ,[PriceModifier]
                                                    ,[NutritionCodeRequired]
                                                    ,[CreatedBy]
                                                    ,[CreatedDate]
                                                    ,[LastUpdatedBy]
                                                    ,[LastUpdatedDate])
                                                SELECT getdate()
                                                    ,[ItemFormID]
                                                    ,[BackroomScaleIndicator]
                                                    ,[ScaleDescription1]
                                                    ,[ScaleDescription2]
                                                    ,[CalorieInformation]
                                                    ,[Tare]
                                                    ,[ScaleExtraTextRequired]
                                                    ,[PriceModifier]
                                                    ,[NutritionCodeRequired]
                                                    ,[CreatedBy]
                                                    ,[CreatedDate]
                                                    ,[LastUpdatedBy]
                                                    ,[LastUpdatedDate]
                                                FROM [dbo].[ScaleInfo] WHERE [ItemFormID] = @ItemFormID";

        private const string AuditModelProductItemValueSQL = @" INSERT INTO [dbo].[ModelProductItemValueAudit]
                                                           ([Version]
                                                           ,[ItemFormID]
                                                           ,[Brand]
                                                           ,[Manufacturer]
                                                           ,[ItemDescription]
                                                           ,[ReceiptDescription]
                                                           ,[ScaleDescription1]
                                                           ,[ScaleDescription2]
                                                           ,[AdDescription]
                                                           ,[ProductCatalogShortDescription1]
                                                           ,[ProductCatalogShortDescription2]
                                                           ,[CreatedBy]
                                                           ,[CreatedDate]
                                                           ,[LastUpdatedBy]
                                                           ,[LastUpdatedDate])
                                                   SELECT getdate()
                                                      ,[ItemFormID]
                                                      ,[Brand]
                                                      ,[Manufacturer]
                                                      ,[ItemDescription]
                                                      ,[ReceiptDescription]
                                                      ,[ScaleDescription1]
                                                      ,[ScaleDescription2]
                                                      ,[AdDescription]
                                                      ,[ProductCatalogShortDescription1]
                                                      ,[ProductCatalogShortDescription2]
                                                      ,[CreatedBy]
                                                      ,[CreatedDate]
                                                      ,[LastUpdatedBy]
                                                      ,[LastUpdatedDate]
                                                        FROM [dbo].[ModelProductItemValue]
                                                        WHERE [ItemFormID] = @ItemFormID";

        //private const string GetBasicItemDefinitionGTINSQL = @"SELECT [GTIN],[GTINCheckDigit] FROM[S0VPITEM].[dbo].[BasicItemDefinition]  WHERE [ItemFormID] = @ItemFormID
        //                                       UNION
        //                                       SELECT [GTIN],[GTINCheckDigit] FROM[S0VPITEM].[dbo].[AdditionalGTIN]  WHERE [ItemFormID] = @ItemFormID";

        private const string GetNutritionalPanelGTINSQL = @"SELECT DISTINCT [GTIN],[GTINCheckDigit] FROM NutritionalPanel WHERE [ItemFormID] = @ItemFormID AND [GTIN] IS NOT NULL";

        private const string RemoveNutritionalPanelGTINSQL = @"UPDATE NutritionalPanel SET [GTIN]= NULL, [GTINCheckDigit] = NULL WHERE [ItemFormID] = @ItemFormID AND [GTIN] IN @Gtins";

        #endregion
    }
}
