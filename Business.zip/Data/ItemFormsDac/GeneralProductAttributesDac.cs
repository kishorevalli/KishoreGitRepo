﻿using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;
using System.Linq;
using System.Drawing;
using System.Runtime.Caching;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class GeneralProductAttributesDac : BaseDac, IGeneralProductAttributesDac
    {
        public async Task<IEnumerable<LookupDto>> GetNutritionalPanelTypes()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<LookupDto>(GetNutritionalPanelTypesSQL, new { IsActive = 1 }));
            }
        }

        public async Task<IEnumerable<OrganicType>> GetOrganicTypes()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();             
                return (await conn.QueryAsync<OrganicType>(GetOrganicTypesSQL, new { IsActive = 1 }));
            }
        }


        public async Task<IEnumerable<DrugScheduleCodeDto>> GetDrugScheduleCodes()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();                
                return (await conn.QueryAsync<DrugScheduleCodeDto>(GetDrugScheduleCodesSQL, new { IsActive = 1 }));
            }
        }

        public async Task<IEnumerable<VariableWeightIndicatorDto>> GetVariableWeightIndicators()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<VariableWeightIndicatorDto>(GetVariableWeightIndicatorsSQL, new { IsActive = 1 }));
            }
        }

        public async Task<IEnumerable<UnacceptableIngredientDto>> GetUnacceptableIngredientList()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<UnacceptableIngredientDto>(GetUnacceptableIngredientListSQL));
            }
        }
        public async Task InsertGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertGeneralProductAttributesSQL, generalProductAttributes);
            }
        }

        public async Task UpdateGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertGeneralProductAttributesAuditSQL, new { ItemFormID = generalProductAttributes.ItemFormID });
                await conn.ExecuteAsync(UpdateGeneralProductAttributesSQL, generalProductAttributes);
            }
        }

        public async Task DeleteNutritionalPanel(NutritionalPanelDto nutritionalPanel)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertNutritionalPanelAuditSQL, new { ID = nutritionalPanel.ID });
                await conn.ExecuteAsync(DeleteNutritionalPanelsSQL, new { IDList = nutritionalPanel.ID });

                await conn.ExecuteAsync(InsertNutritionalInfoAuditSQL, new { NutritionalPanelID = nutritionalPanel.ID });
                await conn.ExecuteAsync(DeleteNutritionalInfoSQL, new { NutritionalPanelID = nutritionalPanel.ID });


                await conn.ExecuteAsync(InsertNutritionalAllergenInfoAuditSQL, new { NutritionalPanelID = nutritionalPanel.ID });
                await conn.ExecuteAsync(DeleteNutritionalAllergensInfoSQL, new { NutritionalPanelID = nutritionalPanel.ID });
            }
        }

        public async Task UpdateNutritionalPanels(NutritionalPanelDto np)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

               
                 await   conn.ExecuteAsync(InsertNutritionalPanelAuditSQL, new { ID = np.ID });
               
                await conn.ExecuteAsync(UpdateNutritionalPanelSQL, np);

                if (np.NutritionalInfoList != null)
                {
                    await conn.ExecuteAsync(InsertNutritionalInfoAuditSQL, new { NutritionalPanelID = np.ID });
                    await conn.ExecuteAsync(DeleteNutritionalInfoSQL, new { NutritionalPanelID = np.ID });

                  
                    np.NutritionalInfoList.ForEach(n => { n.NutritionalPanelID = np.ID; });
                    await conn.ExecuteAsync(InsertNutritionalInfoSQL, np.NutritionalInfoList);
                   
                }

                if (np.NutritionalAllergenInfoList != null)
                {
                    await conn.ExecuteAsync(InsertNutritionalAllergenInfoAuditSQL, new { NutritionalPanelID = np.ID });
                    await conn.ExecuteAsync(DeleteNutritionalAllergensInfoSQL, new { NutritionalPanelID = np.ID });

                   
                    np.NutritionalAllergenInfoList.ForEach(na => { na.NutritionalPanelID = np.ID; });                   
                    await conn.ExecuteAsync(InsertAllergensInfoSQL, np.NutritionalAllergenInfoList);
                   

                }
                
            }

        }

        //public async Task<IEnumerable<ErrorDTO>> GetErrorMessagesCollection()
        //{
        //    //    var CacheKey = "ItemForm_ErrorMessages";

        //    //    var itemFormErrorMessages = (List<ErrorDTO>)MemoryCache.Default[CacheKey];

        //    List<ErrorDTO> itemFormErrorMessages = new List<ErrorDTO>();

        //    if (itemFormErrorMessages == null)
        //    {


        //        using (var conn = (SqlConnection)base.S0VPITEM_Connection)
        //        {
        //            await conn.OpenAsync();
        //            try
        //            {
        //                itemFormErrorMessages = (List<ErrorDTO>)conn.QueryAsync<ErrorDTO>(GetErrorMessagesSQL).Result;
        //                //   MemoryCache.Default.Add(CacheKey, itemFormErrorMessages, DateTime.Now.AddDays(1));
        //            }

        //            catch (Exception ex)
        //            {

        //            }
        //        }
        //    }

        //    return itemFormErrorMessages;
        //}

        public async Task InsertNutritionalPanel(NutritionalPanelDto nutritionalPanel)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var nutritionalPanelID = conn.QueryAsync<int>(InsertNutritionalPanelsSQL, nutritionalPanel).Result.FirstOrDefault();

                if (nutritionalPanel.NutritionalInfoList != null)
                {
                    nutritionalPanel.NutritionalInfoList.ForEach(n => { n.NutritionalPanelID = nutritionalPanelID; });
                    await conn.ExecuteAsync(InsertNutritionalInfoSQL, nutritionalPanel.NutritionalInfoList);                 
                }

                if (nutritionalPanel.NutritionalAllergenInfoList != null)
                {                   
                    nutritionalPanel.NutritionalAllergenInfoList.ForEach(na => { na.NutritionalPanelID = nutritionalPanelID; });                 
                    await conn.ExecuteAsync(InsertAllergensInfoSQL, nutritionalPanel.NutritionalAllergenInfoList);     
                }

               
            }
        }


        public async Task<GeneralProductAttributesDto> GetGeneralProductAttributes(int itemFormID)
        {
            GeneralProductAttributesDto generalProductAttributes = new GeneralProductAttributesDto();
            // throw new NotImplementedException();
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                generalProductAttributes = conn.QueryAsync<GeneralProductAttributesDto>(GetGeneralProductAttributesSQL, new { ItemFormID = itemFormID }).Result.FirstOrDefault();
                if (generalProductAttributes == null)
                    return generalProductAttributes;
                var nutritionalPanels = await conn.QueryAsync<NutritionalPanelDto>(GetNutritionalPanelsSQL, new { ItemFormID = itemFormID });

                List<NutritionalPanelDto> nutritionalPanelList = new List<NutritionalPanelDto>();
                foreach (var nutritionalPanel in nutritionalPanels)
                {
                    //Retreive nutritional Info for each nutritional Panel.
                    var nutritionalInfo = await conn.QueryAsync<NutritionalInfoDto>(GetNutritionalInfoSQL, new { NutritionalPanelID = nutritionalPanel.ID });
                    nutritionalPanel.NutritionalInfoList = nutritionalInfo.ToList();

                    //Retreive Allergens Info for each nutritional Panel.
                    var nutritionalAllergens = await conn.QueryAsync<NutritionalAllergenInfoDto>(GetNutritionalAllergenInfoSQL, new { NutritionalPanelID = nutritionalPanel.ID });
                    nutritionalPanel.NutritionalAllergenInfoList = nutritionalAllergens.ToList();

                    nutritionalPanelList.Add(nutritionalPanel);

                }
                generalProductAttributes.NutritionalPanelList = nutritionalPanelList;
            }
            return generalProductAttributes;
        }

        public async Task<bool> IsGPADetailsExistsForItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    var count = await conn.ExecuteScalarAsync<int>(GetGPACountByItemFormIDSQL, new { ItemFormID = itemFormID });
                    return count > 0 ? true : false;
                }
                catch
                {
                    throw;
                }

            }
        }

        public async Task<GeneralProductAttributesDto> GetGPAWeightDetails(int itemFormID)
        {

            GeneralProductAttributesDto generalProductAttributes = new GeneralProductAttributesDto();
            // throw new NotImplementedException();
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                generalProductAttributes = await conn.QueryFirstOrDefaultAsync<GeneralProductAttributesDto>(GetGPAWeightDetailsSQL, new { ItemFormID = itemFormID });
            }
            return generalProductAttributes;
        }

        #region "SQL Queries"
        private const string GetNutritionalPanelTypesSQL = @" SELECT ID AS Code, Name AS Description
                                    FROM [dbo].[NutritionalPanelType]   WHERE IsActive = @IsActive
                                    ORDER BY SortOrder ";

        private const string GetDrugScheduleCodesSQL =  @"Select DrugScheduleCode , Narcotic from [dbo].[DrugScheduleCode] where IsActive = @IsActive";
        private const string GetVariableWeightIndicatorsSQL = @"Select ID, Code, ShortDescription, Description, ValidForShipper 
                                                                FROM [dbo].[VariableWeightIndicator] 
                                                                WHERE IsActive = @IsActive 
                                                                ORDER BY SortOrder ";
        private const string GetUnacceptableIngredientListSQL = @"Select ID, Ingredient, Description
                                                                FROM [dbo].[UnacceptableIngredient]";

        private const string GetOrganicTypesSQL = @" SELECT ID AS Code, Name AS Description, PMDSName AS PMDSName
                                    FROM [dbo].[OrganicType]   WHERE IsActive = @IsActive
                                    ORDER BY SortOrder ";

        private const string InsertGeneralProductAttributesSQL = @" INSERT INTO [dbo].[GeneralProductAttribute]
           ([ItemFormID]
           ,[NutritionalPanelTypeID]
           ,[PerishableItem]
           ,[ProductDate]
           ,[BornOnDays]
           ,[CountryOfOrigin]           
           ,[Ignitable]
           ,[Corrosive]
           ,[Reactive]
           ,[Toxic]
           ,[EPAListedWaste]
           ,[ContainsBattery]
           ,[EMailForBatterySurvey]
           ,[DEARegulated]
           ,[Narcotic]
           ,[DrugScheduleCode]
           ,[NDCNumber]
           ,[NDCFormat]
           ,[NDCFormatDescription]
           ,[Disinfectant]
           ,[Allergic]
           ,[GlutenFree]
           ,[OrganicTypesID]
           ,[GreenLeaf]
           ,[Pesticide]
           ,[Liquor]
           ,[LiquorDescription]
           ,[Tobacco]
           ,[VariableWeightIndicator]
           ,[RandomWeight]
           ,[FoodStamp]
           ,[UnitPricingCount]
           ,[UnitPricingUOM]
           ,[TagCount]
           ,[TagSize]
           ,[SeasonalItem]
           ,[SeasonBeginDate]
           ,[SeasonEndDate]
           ,[MinDaysRequired]
           ,[MaxDaysRequired]
           ,[WhseShelfLife]
           ,[IgnoreQuantityCheck]
           ,[BioFlag]
           ,[ActivationProtectionEndDate]
           ,[ManuallyOrderedItem]
           ,[NutritionalInfoNotAvailableUntil]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     VALUES
           (@ItemFormID
           ,@NutritionalPanelTypeID
           ,@PerishableItem
           ,@ProductDate
           ,@BornOnDays
           ,@CountryOfOrigin           
           ,@Ignitable
           ,@Corrosive
           ,@Reactive
           ,@Toxic
           ,@EPAListedWaste
           ,@ContainsBattery
           ,@EMailForBatterySurvey
           ,@DEARegulated
           ,@Narcotic
           ,@DrugScheduleCode
           ,@NDCNumber
           ,@NDCFormat
           ,@NDCFormatDescription
           ,@Disinfectant
           ,@Allergic
           ,@GlutenFree
           ,@OrganicTypesID
           ,@GreenLeaf
           ,@Pesticide
           ,@Liquor
           ,@LiquorDescription
           ,@Tobacco
           ,@VariableWeightIndicator
           ,@RandomWeight
           ,@FoodStamp
           ,@UnitPricingCount
           ,@UnitPricingUOM
           ,@TagCount
           ,@TagSize
           ,@SeasonalItem
           ,@SeasonBeginDate
           ,@SeasonEndDate
           ,@MinDaysRequired
           ,@MaxDaysRequired
           ,@WhseShelfLife
           ,@IgnoreQuantityCheck
           ,@BioFlag
           ,@ActivationProtectionEndDate
           ,@ManuallyOrderedItem
           ,@NutritionalInfoNotAvailableUntil
           ,@CreatedBy
           ,GetDate()
           ,@LastUpdatedBy
           ,GetDate())";


        private const string InsertGeneralProductAttributesAuditSQL = @"
INSERT INTO [dbo].[GeneralProductAttributeAudit]
           ([Version]
           ,[ItemFormID]
           ,[NutritionalPanelTypeID]
           ,[PerishableItem]
           ,[ProductDate]
           ,[BornOnDays]
           ,[CountryOfOrigin]           
           ,[Ignitable]
           ,[Corrosive]
           ,[Reactive]
           ,[Toxic]
           ,[EPAListedWaste]
           ,[ContainsBattery]
           ,[EMailForBatterySurvey]
           ,[DEARegulated]
           ,[Narcotic]
           ,[DrugScheduleCode]
           ,[NDCNumber]
           ,[NDCFormat]
           ,[NDCFormatDescription]
           ,[Disinfectant]
           ,[Allergic]
           ,[GlutenFree]
           ,[OrganicTypesID]
           ,[GreenLeaf]
           ,[Pesticide]
           ,[Liquor]
           ,[LiquorDescription]
           ,[Tobacco]
           ,[VariableWeightIndicator]
           ,[RandomWeight]
           ,[FoodStamp]
           ,[UnitPricingCount]
           ,[UnitPricingUOM]
           ,[TagCount]
           ,[TagSize]
           ,[SeasonalItem]
           ,[SeasonBeginDate]
           ,[SeasonEndDate]
           ,[MinDaysRequired]
           ,[MaxDaysRequired]
           ,[WhseShelfLife]
           ,[IgnoreQuantityCheck]
           ,[BioFlag]
           ,[ActivationProtectionEndDate]
           ,[ManuallyOrderedItem]
           ,[NutritionalInfoNotAvailableUntil]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     SELECT 
            getDate()
            ,ItemFormID
           ,NutritionalPanelTypeID
           ,PerishableItem
           ,ProductDate
           ,BornOnDays
           ,CountryOfOrigin           
           ,Ignitable
           ,Corrosive
           ,Reactive
           ,Toxic
           ,EPAListedWaste
           ,ContainsBattery
           ,EMailForBatterySurvey
           ,DEARegulated
           ,Narcotic
           ,DrugScheduleCode
           ,NDCNumber
           ,NDCFormat
           ,NDCFormatDescription
           ,Disinfectant
           ,Allergic
           ,GlutenFree
           ,OrganicTypesID
           ,GreenLeaf
           ,Pesticide
           ,Liquor
           ,LiquorDescription
           ,Tobacco
           ,VariableWeightIndicator
           ,RandomWeight
           ,FoodStamp
           ,UnitPricingCount
           ,UnitPricingUOM
           ,TagCount
           ,TagSize
           ,SeasonalItem
           ,SeasonBeginDate
           ,SeasonEndDate
           ,MinDaysRequired
           ,MaxDaysRequired
           ,WhseShelfLife
           ,IgnoreQuantityCheck
           ,BioFlag
           ,ActivationProtectionEndDate
           ,ManuallyOrderedItem
           ,NutritionalInfoNotAvailableUntil
           ,CreatedBy
           ,GetDate()
           ,LastUpdatedBy
           ,GetDate() FROM GeneralProductAttribute where ItemFormID = @ItemFormID";

        private const string InsertNutritionalPanelAuditSQL = @"INSERT INTO [dbo].[NutritionalPanelAudit]
           ([Version]
           ,[ID]
           ,[ItemFormID]
           ,[NutritionalPanelName]
           ,[GTIN]         
           ,[GTINCheckDigit]
           ,[ContainsAllergen]         
           ,[ServingSize]
           ,[ServingsPerContainer]
           ,[SortOrder]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     SELECT 
           getDate()
           ,ID
           ,ItemFormID
           ,NutritionalPanelName
           ,GTIN    
           ,GTINCheckDigit
           ,ContainsAllergen    
           ,ServingSize
           ,ServingsPerContainer
           ,SortOrder
           ,CreatedBy
           ,getDate()
           ,LastUpdatedBy
           ,getDate() FROM NutritionalPanel where ID = @ID";

        private const string InsertNutritionalInfoAuditSQL = @"INSERT INTO [dbo].[NutritionalInfoAudit]
           ([Version]
           ,[ID]
           ,[NutritionalPanelID]
           ,[NutrDictionaryID]
           ,[NutrientName]
           ,[Quantity]
           ,[UOM]
           ,[DailyValuePercentage]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     SELECT 
            getDate()
           ,ID
           ,NutritionalPanelID
           ,NutrDictionaryID
           ,NutrientName
           ,Quantity
           ,UOM
           ,DailyValuePercentage
           ,CreatedBy
           ,getDate()
           ,LastUpdatedBy
           ,getDate() from NutritionalInfo where NutritionalPanelID = @NutritionalPanelID";

        private const string InsertNutritionalAllergenInfoAuditSQL = @"INSERT INTO [dbo].[NutritionalAllergenInfoAudit]
           ([Version]
           ,[ID]
           ,[NutritionalPanelID]
           ,[NutrDictionaryID]
           ,[AllergenName]
           ,[Value]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     SELECT
            getDate()
           ,ID
           ,NutritionalPanelID
           ,NutrDictionaryID
           ,AllergenName
           ,[Value]
           ,CreatedBy
           ,getDate()
           ,LastUpdatedBy
           ,getDate() From NutritionalAllergenInfo WHERE NutritionalPanelID = @NutritionalPanelID";

        private const string UpdateNutritionalPanelSQL = @"UPDATE [dbo].[NutritionalPanel]
   SET 
       [ItemFormID] = @ItemFormID
      ,[NutritionalPanelName] = @NutritionalPanelName
      ,[GTIN] = @GTIN
      ,[GTINCheckDigit] = @GTINCheckDigit
      ,[ContainsAllergen] = @ContainsAllergen
      ,[ServingSize] = @ServingSize
      ,[ServingsPerContainer] = @ServingsPerContainer
      ,[SortOrder] = @SortOrder      
      ,[LastUpdatedBy] = @LastUpdatedBy
      ,[LastUpdatedDate] = getDate()
 WHERE ID = @ID";


        private const string GetGPACountByItemFormIDSQL = @"Select count(*) from GeneralProductAttribute where ItemFormID = @ItemFormID";

        private const string InsertNutritionalPanelsSQL = @"INSERT INTO [dbo].[NutritionalPanel]
           ([ItemFormID]        
           ,[NutritionalPanelName]
           ,[GTIN]
           ,[GTINCheckDigit] 
           ,[ContainsAllergen]
           ,[ServingSize]
           ,[ServingsPerContainer]
           ,[SortOrder]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     VALUES
           (@ItemFormID           
           ,@NutritionalPanelName
           ,@GTIN
           ,@GTINCheckDigit
           ,@ContainsAllergen
           ,@ServingSize
           ,@ServingsPerContainer
           ,@SortOrder
           ,@CreatedBy
           ,GetDate()
           ,@LastUpdatedBy
           ,GetDate()); SELECT SCOPE_IDENTITY() AS ID";


        private const string InsertNutritionalInfoSQL = @"INSERT INTO [dbo].[NutritionalInfo]
           ([NutritionalPanelID]
           ,[NutrDictionaryID]
           ,[NutrientName]
           ,[Quantity]
           ,[UOM]
           ,[DailyValuePercentage]
           ,[IsRequired]
           ,[SortOrder]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     VALUES
           (@NutritionalPanelID
           ,@NutrDictionaryID
           ,@NutrientName
           ,@Quantity
           ,@UOM
           ,@DailyValuePercentage
           ,@IsRequired
           ,@SortOrder
           ,@CreatedBy
           ,GetDate()
           ,@LastUpdatedBy
           ,GetDate())";

     //   private const string InsertNutritionalPanelSQL = @"INSERT INTO [dbo].[NutritionalPanel]
     //      ([ItemFormID]
     //      ,[NutritionalPanelName]
     //      ,[GTIN]
     //      ,[GTINCheckDigit] 
     //      ,[ContainsAllergen]
     //      ,[ServingSize]
     //      ,[ServingsPerContainer]
     //      ,[CreatedBy]
     //      ,[CreatedDate]
     //      ,[LastUpdatedBy]
     //      ,[LastUpdatedDate])
     //VALUES
     //      ( @ItemFormID
     //      ,@NutritionalPanelName
     //      ,@GTIN
     //      ,@GTINCheckDigit
     //      ,@ContainsAllergen
     //      ,@ServingSize
     //      ,@ServingsPerContainer
     //      ,@CreatedBy
     //      ,getDate()
     //      ,@LastUpdatedBy
     //      ,getDate())";

        private const string InsertAllergensInfoSQL = @"INSERT INTO [dbo].[NutritionalAllergenInfo]
           ([NutritionalPanelID]
           ,[NutrDictionaryID]
           ,[AllergenName]
           ,[Value]
           ,[SortOrder]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     VALUES
           (@NutritionalPanelID
           ,@NutrDictionaryID
           ,@AllergenName
           ,@Value
           ,@SortOrder
           ,@CreatedBy
           ,GetDate()
           ,@LastUpdatedBy
           ,GetDate())";

        private const string GetGeneralProductAttributesSQL = @"SELECT [ItemFormID]
      ,[PerishableItem]
      ,[NutritionalPanelTypeID]
      ,[ProductDate]
      ,[BornOnDays]
      ,[CountryOfOrigin]      
      ,[Ignitable]
      ,[Corrosive]
      ,[Reactive]
      ,[Toxic]
      ,[EPAListedWaste]
      ,[ContainsBattery]
      ,[EMailForBatterySurvey]
      ,[DEARegulated]
      ,[Narcotic]
      ,[DrugScheduleCode]
      ,[NDCNumber]
      ,[NDCFormat]
      ,[NDCFormatDescription]
      ,[Disinfectant]
      ,[Allergic]
      ,[GlutenFree]
      ,[OrganicTypesID]
      ,[GreenLeaf]
      ,[Pesticide]
      ,[Liquor]
      ,[LiquorDescription]
      ,[Tobacco]
      ,[VariableWeightIndicator]
      ,[RandomWeight]
      ,[FoodStamp]
      ,[UnitPricingCount]
      ,[UnitPricingUOM]
      ,[TagCount]
      ,[TagSize]
      ,[SeasonalItem]
      ,[SeasonBeginDate]
      ,[SeasonEndDate]
      ,[MinDaysRequired]
      ,[MaxDaysRequired]
      ,[WhseShelfLife]
      ,[IgnoreQuantityCheck]
      ,[BioFlag]
      ,[ActivationProtectionEndDate]
      ,[ManuallyOrderedItem]
      ,[NutritionalInfoNotAvailableUntil]
      ,IFM.FormStatusID
  FROM [dbo].[GeneralProductAttribute] GPA
  INNER JOIN ItemForm IFM ON IFM.ID = GPA.ItemFormID
  WHERE GPA.ItemFormID = @ItemFormID";

        private const string GetNutritionalPanelsSQL = @"SELECT [ID]
      ,[ItemFormID]      
      ,[NutritionalPanelName]
      ,[GTIN]
      ,[GTINCheckDigit]
      ,[ContainsAllergen]
      ,[ServingSize]
      ,[ServingsPerContainer]
      ,[SortOrder]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[LastUpdatedBy]
      ,[LastUpdatedDate]
  FROM [dbo].[NutritionalPanel]
  WHERE ItemFormID = @ItemFormID
  ORDER BY SortOrder";

        private const string GetNutritionalInfoSQL = @"SELECT [ID]
      ,[NutritionalPanelID]
      ,[NutrDictionaryID]
      ,[NutrientName]
      ,[Quantity]
      ,[UOM]
      ,[DailyValuePercentage]
      ,[IsRequired]
      ,[SortOrder]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[LastUpdatedBy]
      ,[LastUpdatedDate]
  FROM [dbo].[NutritionalInfo]
  WHERE NutritionalPanelID = @NutritionalPanelID
  ORDER BY SortOrder";

        private const string GetNutritionalAllergenInfoSQL = @"SELECT [ID]
      ,[NutritionalPanelID]
      ,[NutrDictionaryID]
      ,[AllergenName]
      ,[Value]
      ,[SortOrder]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[LastUpdatedBy]
      ,[LastUpdatedDate]
   FROM [dbo].[NutritionalAllergenInfo]
   WHERE NutritionalPanelID = @NutritionalPanelID
   ORDER BY SortOrder";

        private const string GetGPAWeightDetailsSQL = @"Select [ItemFormID] , [RandomWeight], [VariableWeightIndicator] from [dbo].[GeneralProductAttribute]
where ItemFormID = @ItemFormID";

        private const string UpdateGeneralProductAttributesSQL = @"
UPDATE [dbo].[GeneralProductAttribute]
   SET 
       [NutritionalPanelTypeID] = @NutritionalPanelTypeID
      ,[PerishableItem] = @PerishableItem
      ,[ProductDate] = @ProductDate
      ,[BornOnDays] = @BornOnDays
      ,[CountryOfOrigin] = @CountryOfOrigin      
      ,[Ignitable] = @Ignitable
      ,[Corrosive] = @Corrosive
      ,[Reactive] = @Reactive
      ,[Toxic] = @Toxic
      ,[EPAListedWaste] = @EPAListedWaste
      ,[ContainsBattery] = @ContainsBattery
      ,[EMailForBatterySurvey] = @EMailForBatterySurvey
      ,[DEARegulated] = @DEARegulated
      ,[Narcotic] = @Narcotic
      ,[DrugScheduleCode] = @DrugScheduleCode
      ,[NDCNumber] = @NDCNumber
      ,[NDCFormat] = @NDCFormat
      ,[NDCFormatDescription] = @NDCFormatDescription
      ,[Disinfectant] = @Disinfectant
      ,[Allergic] = @Allergic
      ,[GlutenFree] = @GlutenFree
      ,[OrganicTypesID] = @OrganicTypesID
      ,[GreenLeaf] = @GreenLeaf
      ,[Pesticide] = @Pesticide
      ,[Liquor] = @Liquor
      ,[LiquorDescription] = @LiquorDescription
      ,[Tobacco] = @Tobacco
      ,[VariableWeightIndicator] = @VariableWeightIndicator
      ,[RandomWeight] = @RandomWeight
      ,[FoodStamp] = @FoodStamp
      ,[UnitPricingCount] = @UnitPricingCount
      ,[UnitPricingUOM] = @UnitPricingUOM
      ,[TagCount] = @TagCount
      ,[TagSize] = @TagSize
      ,[SeasonalItem] = @SeasonalItem
      ,[SeasonBeginDate] = @SeasonBeginDate
      ,[SeasonEndDate] = @SeasonEndDate
      ,[MinDaysRequired] = @MinDaysRequired
      ,[MaxDaysRequired] = @MaxDaysRequired
      ,[WhseShelfLife] = @WhseShelfLife
      ,[IgnoreQuantityCheck] = @IgnoreQuantityCheck
      ,[BioFlag] = @BioFlag
      ,[ActivationProtectionEndDate] = @ActivationProtectionEndDate
      ,[ManuallyOrderedItem] = @ManuallyOrderedItem
      ,[NutritionalInfoNotAvailableUntil] = @NutritionalInfoNotAvailableUntil     
      ,[LastUpdatedBy] = @LastUpdatedBy
      ,[LastUpdatedDate] = getDate()
 WHERE ItemFormID = @ItemFormID";

        private const string DeleteNutritionalInfoSQL = @"Delete NutritionalInfo where NutritionalPanelID = @NutritionalPanelID";
        private const string DeleteNutritionalAllergensInfoSQL = @"Delete NutritionalAllergenInfo where NutritionalPanelID = @NutritionalPanelID";
        private const string DeleteNutritionalPanelsSQL = @"Delete NutritionalPanel where ID IN (@IDList)";

        //      private const string GetErrorMessagesSQL = @"SELECT ErrorCode,ErrorDescription,TabName,ControlName,SeverityLevel FROM ErrorMessage";

        #endregion

        #region "Commented Code - to delete"
        //public async Task<bool> SaveGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes)
        //{
        //    bool successFlag;
        //    //using (var conn = (SqlConnection)base.S0VPITEM_Connection)
        //    //{
        //    //    await conn.OpenAsync();
        //    try
        //    {
        //        var gpaDetailsExists = await IsGPADetailsExistsForItemForm(generalProductAttributes.ItemFormID);
        //        if (gpaDetailsExists)
        //        {
        //            if (generalProductAttributes.IsDirty)
        //            {
        //                await UpdateGeneralProductAttributes(generalProductAttributes);

        //                if (generalProductAttributes.NutritionalPanelList.Count > 0)
        //                {
        //                    //TODO: Get the max degree of parallelism from db system values. 
        //                   Parallel.ForEach(generalProductAttributes.NutritionalPanelList, new ParallelOptions() { MaxDegreeOfParallelism = 4 },  (nutritionalPanel) =>
        //                    {

        //                        if (nutritionalPanel.IsDeleted)
        //                        {
        //                            Task.Run(async () => { await DeleteNutritionalPanel(nutritionalPanel); }).Wait();
        //                        }
        //                        else if (nutritionalPanel.ID == 0)
        //                        {
        //                            Task.Run(async () => { await InsertNutritionalPanel(nutritionalPanel); }).Wait();

        //                        }
        //                        else if (nutritionalPanel.IsDirty)
        //                        {
        //                            Task.Run(async () => { await UpdateNutritionalPanels(nutritionalPanel);}).Wait();                              

        //                        }
        //                        // }

        //                    });
        //                    await Task.WhenAll();                      
        //                }
        //            }
        //        }
        //        else
        //        {
        //            await InsertGeneralProductAttributes(generalProductAttributes);
        //            if (generalProductAttributes.NutritionalPanelList != null)
        //            {
        //                Parallel.ForEach(generalProductAttributes.NutritionalPanelList, new ParallelOptions() { MaxDegreeOfParallelism = 4 },  (nutritionalPanel) =>
        //                {
        //                    Task.Run(async () => { await InsertNutritionalPanel(nutritionalPanel); }).Wait();
        //                });
        //            }
        //        }

        //        successFlag = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }

        //    return successFlag;
        //    // }
        //}
        #endregion
    }
}
