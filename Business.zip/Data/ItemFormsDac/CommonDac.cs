﻿using Dapper;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class CommonDac : BaseDac , ICommonDac
    {
        public  async Task<bool> IsGTINExists(long Gtin)
        {
             throw new NotImplementedException();

            //using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            //{
            //    await conn.OpenAsync();
            //    var recordCnt = await conn.QueryFirstAsync<int>(IsGTINExistsInItemFormsSQL);
            //    return (recordCnt > 0 ? true : false);                
            //}
        }


        public async Task<bool> DeleteItemForm(ItemFormDto itemFormDto)
        {

            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    await conn.ExecuteAsync(DeleteItemFormSQL, itemFormDto);
                    await conn.ExecuteAsync(DeleteReuseItemCodeByItemFormIdSQL, itemFormDto);
                    retValue = true;
                }
                catch
                {
                    throw;
                }


            }
            return retValue;
        }

        public async Task<ItemFormDto> SaveItemForm(ItemFormDto itemFormDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryFirstOrDefaultAsync<ItemFormDto>(SaveItemFormSQL, itemFormDto));
            }
           
        }

        public async Task<ItemFormDto> GetItemFormData(long itemFormDisplayId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {

                await conn.OpenAsync();
                ItemFormDto itemFormDto = await conn.QueryFirstOrDefaultAsync<ItemFormDto>(GetItemFormDataSQL, new { @ItemFormDisplayID = itemFormDisplayId });
               
                return itemFormDto;
            }
        }

        public async Task<ItemFormDto> GetItemFormDataById(long itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {

                await conn.OpenAsync();
                ItemFormDto itemFormDto = await conn.QueryFirstOrDefaultAsync<ItemFormDto>(GetItemFormDataSQLById, new { @ItemFormID = itemFormId });

                return itemFormDto;
            }
        }

        public async Task<IEnumerable<int>> GetVendorsForItemForm(int itemFormId)
        {

            //try
            //{
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    return (await conn.QueryAsync<int>(GetVendorsForItemFormSQL, new { @ItemFormID = itemFormId }));
                 //   return vendors;

                 
                }
            //}
            //catch (Exception ex)
            //{
            //    throw;
            //}

            //return null;
        }
        

        public async Task<IEnumerable<ErrorDTO>> GetErrorMessagesByType(ErrorDTO errors)
        {
            IEnumerable <ErrorDTO> errorMessages = await GetErrorMessages();
            if (errors.SeverityLevel != "ALL")            
            errorMessages =   errorMessages.ToList().FindAll(error => error.TabName == errors.TabName && error.SeverityLevel == errors.SeverityLevel);
            return await Task.FromResult(errorMessages);
        }

        public async Task UpdateItemForm(ItemFormDto itemForm)
        {  using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                var sql = (itemForm.FormActionID != 0 && itemForm.FormStatusID != 0) ? UpdateItemFormSQL : UpdateItemFormTimestampSQL;
                await conn.OpenAsync();
                await conn.ExecuteAsync(sql, itemForm);
            }            
        }

        public async Task UpdateItemCodeForItemForm(ItemFormDto itemForm)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(UpdateItemCodeForItemFormSQL, itemForm);
            }
        }

        public async Task SubmitItemFormsForCreation(IEnumerable<CreateItemFormDto> itemFormsForCreation)
        {

            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    await conn.ExecuteAsync(InsertIntoItemForCreationSQL, itemFormsForCreation);
                }
            }
            catch (Exception ex)
            {


            }
        }

        public async Task<string> GetVendorItemCode(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryFirstOrDefaultAsync<string>(GetVendorItemCodeSQL, new { @ItemFormID = itemFormID });
            }
        }       


        public async Task<IEnumerable<GTINWithCheckdigitDto>> GetBasicItemDefinitionGTIN(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<GTINWithCheckdigitDto>(GetBasicItemDefinitionGTINSQL, new { ItemFormID = itemFormID }));
            }
        }
        public async Task<bool> IsDsdVendorsExistForItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                int count = await conn.QueryFirstAsync<int>(IsDsdVendorsExistForItemFormSQL, new { ItemFormID = itemFormID });
                return (count > 0);
            }
        }

        public async Task<bool> SaveItemFormErrors(List<ItemFormErrorDto> ItemFormErroList,string TabName, int ItemFormID)
        {
            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    await conn.ExecuteAsync(DeleteItemFormErrorSQL, new { TabName = TabName, ItemFormID = ItemFormID });
                    await conn.ExecuteAsync(InsertItemFormErrorSQL, ItemFormErroList);
                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }
        public async Task<IEnumerable<ItemFormErrorDto>> GetItemFormErrors(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<ItemFormErrorDto>(GetItemFormErrorSQL, new { ItemFormID = ItemFormID }));
            }
        }

        public async Task<bool> IsFAMCodeExistsInProductGrouping(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                int count = await conn.QueryFirstAsync<int>(IsFAMCodeExistsInProductGroupingSQL, new { @ItemFormID = itemFormID });
                return (count > 0);
            }
        }
        public async Task<IEnumerable<ItemFormDto>> GetItemFormGroup(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<ItemFormDto>(GetItemFormGroupSQL, new { ItemFormID = ItemFormID }));
            }
        }
        public async Task<IEnumerable<KeyValuePair<string, string>>> GetSystemValues()
        {
            //TODO: Disable the cache during development..Need to comment the below 2 line after DEVELOPMENT
            using (var conn = (SqlConnection)S0VPITEM_Connection)
            { return await conn.QueryAsync<KeyValuePair<string, string>>(GetSystemValuesSQL); }

            var CacheKey = "ItemForm_SystemValues";

            var itemFormSystemValues = (List<KeyValuePair<string, string>>)MemoryCache.Default[CacheKey];

            if (itemFormSystemValues == null)
            {
                using (var conn = (SqlConnection)S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    itemFormSystemValues = (List<KeyValuePair<string, string>>)await conn.QueryAsync<KeyValuePair<string, string>>(GetSystemValuesSQL);
                    MemoryCache.Default.Add(CacheKey, itemFormSystemValues, DateTime.Now.AddDays(1));
                }
            }
            return itemFormSystemValues;
        }

        public async Task<IEnumerable<int>> GetChildForms(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<int>(GetChildFormsSQL, new { @ItemFormID = itemFormId }));
            }
        }

        #region "Query"

        private const string IsFAMCodeExistsInProductGroupingSQL = @" Select count(*) from [S0VPITEM].[dbo].[ProductGrouping] where 
            ItemFormID = @ItemFormID AND [ChildProductGroupType] = 'FAM' AND [ChildProductGroupCode] IS NOT NULL";

        private const string UpdateItemFormSQL = @"
                        UPDATE [S0VPITEM].[dbo].[ItemForm]
                        SET 
                        [SubmittedUserTypeID] = @SubmittedUserTypeID,
                        [FormStatusID] = @FormStatusID,
                        [FormActionID] = @FormActionID,
                        [LastUpdatedBy] = @LastUpdatedBy,
                        [LastUpdatedDate] = getDate()
                        WHERE ID = @ID";
        private const string UpdateItemFormTimestampSQL = @"
                        UPDATE [S0VPITEM].[dbo].[ItemForm]
                        SET                         
                        [LastUpdatedBy] = @LastUpdatedBy,
                        [LastUpdatedDate] = getDate()
                        WHERE ID = @ID";
      
        private const string UpdateItemCodeForItemFormSQL = @"
                        UPDATE [S0VPITEM].[dbo].[ItemForm]
                        SET 
                        [SubmittedUserTypeID] = @SubmittedUserTypeID,
                        [ItemCode] = @ItemCode,
                        [FormStatusID] = @FormStatusID,
                        [FormActionID] = @FormActionID,
                        [LastUpdatedBy] = @LastUpdatedBy,
                        [LastUpdatedDate] = getDate()
                        WHERE ID = @ID";

        private const string IsGTINExistsInItemFormsSQL = @"SELECT count(*) FROM PackagingHierarchy
                                                         WHERE (MasterCaseGTIN = @Gtin OR InnerCaseGTIN = @Gtin OR PalletGTIN = @Gtin  )
                                                         ORDER BY ID Desc";


        private const string GetVendorListForItemFormSQL = @"SELECT VendorNumber from [dbo].[PackagingHierarchy]
	                                                            INNER JOIN [OrderablePackLevel] ON PackagingHierarchy.ID = OrderablePackLevel.PackagingHierarchyID WHERE PackagingHierarchy.ItemFormID = @ItemFormID
	                                                            UNION
	                                                            SELECT VendorNumber FROM DSDAuthRequestStore WHERE DSDAuthRequestStore.ItemFormID = @ItemFormID";

        private const string DeleteItemFormSQL = @"
                        UPDATE [S0VPITEM].[dbo].[ItemForm]
                        SET 
                        [FormStatusID] = 2,
                        [LastUpdatedBy] = @LastUpdatedBy,
                        [LastUpdatedDate] = getDate()
                        WHERE ItemFormDisplayID = @ItemFormDisplayID";

        private const string SaveItemFormSQL = @"DECLARE @ItemFormDisplayFormID as bigint
                        SELECT  @ItemFormDisplayFormID = CAST( CONCAT(CONVERT(VARCHAR(8), GETDATE(), 112) , FORMAT(COUNT(ID)+1,'0000'))AS bigint)  FROM [dbo].[ItemForm] WHERE CAST(CreatedDate AS DATE) = CAST(GETDATE() AS DATE)
                        INSERT INTO [dbo].[ItemForm]
	                        (ItemFormDisplayID
	                        ,[FormTypeID]
	                        ,[SubmissionDate]
	                        ,[SubmittedBy]
	                        ,[SubmittedUserTypeID]
                            ,CreatedByUserTypeID
	                        ,[FormStatusID]
	                        ,[FormActionID]
	                        ,[PendingRoleUserTypeID]
	                        ,[DSDAuthRequestSelectStoreOption]
	                        , VendorContactID 
                             ,VendorContactName 
                             ,VendorContactEmail
                            ,BuyerID
                            ,BuyerName          
	                        ,[CreatedBy]
	                        ,[CreatedDate]
	                        )
                        VALUES
	                        (@ItemFormDisplayFormID
	                        ,@FormTypeID
	                        , getDate()
	                        , @SubmittedBy
	                        , @SubmittedUserTypeID
                            , @CreatedByUserTypeID
	                        , @FormStatusID
	                        , @FormActionID
	                        , @PendingRoleUserTypeID
                            , @DSDAuthRequestSelectStoreOption                              
	                        , @VendorContactID 
                             ,@VendorContactName 
                             ,@VendorContactEmail
                            ,@BuyerID
                            ,@BuyerName                                
                            , @CreatedBy
                            , getDate()
                        );
                        SELECT [ID]
                              ,[ItemFormDisplayID]
                              ,[FormTypeID]
                              ,[SubmissionDate]
                              ,[SubmittedBy]
                              ,[SubmittedUserTypeID]
                               ,CreatedByUserTypeID 
                              ,[FormStatusID]
                              ,[FormActionID]
                              ,[PendingRoleUserTypeID]
                              ,[DSDAuthRequestSelectStoreOption]
                              ,[ItemCreatedDateTime]
                              ,[CreatedBy]
                              ,[CreatedDate]
                              ,[LastUpdatedBy]
                              ,[LastUpdatedDate]
                              ,[VendorContactID]
                              ,VendorContactName 
                              ,VendorContactEmail
                              ,BuyerID
                              ,BuyerName     
                          FROM [dbo].[ItemForm] WHERE [ID] = SCOPE_IDENTITY();";

        private const string GetItemFormDataSQL = @"  SELECT ID, [ItemFormDisplayID]
                              ,[FormTypeID]
                              ,[SubmissionDate]
                              ,[SubmittedBy]
                              ,[SubmittedUserTypeID]
                              ,[CreatedByUserTypeID]
                              ,[FormStatusID]
                              ,[FormActionID]
                              ,[PendingRoleUserTypeID]
                              ,[DSDAuthRequestSelectStoreOption]
                              ,[ItemCreatedDateTime]
                              ,[VendorContactID]
                              ,[VendorContactName]
                              ,[VendorContactEmail]
                              ,[BuyerID]
                              ,[BuyerName]
                              ,[ParentFlag]
                              ,[IsInGroup]
                              ,[GroupID]
                              ,[CreatedBy]
                              ,[CreatedDate]
                              ,[LastUpdatedBy]
                              ,[LastUpdatedDate]
                          FROM [S0VPITEM].[dbo].[ItemForm]
  WHERE ItemFormDisplayID = @ItemFormDisplayID";

        private const string GetItemFormDataSQLById = @"  SELECT ID, [ItemFormDisplayID]
                              ,[FormTypeID]
                              ,[SubmissionDate]
                              ,[SubmittedBy]
                              ,[SubmittedUserTypeID]
                              ,[CreatedByUserTypeID]
                              ,[FormStatusID]
                              ,[FormActionID]
                              ,[PendingRoleUserTypeID]
                              ,[DSDAuthRequestSelectStoreOption]
                              ,[ItemCreatedDateTime]
                              ,[VendorContactID]
                              ,[VendorContactName]
                              ,[VendorContactEmail]
                              ,[BuyerID]
                              ,[BuyerName]
                              ,[ParentFlag]
                              ,[IsInGroup]
                              ,[GroupID]
                              ,[CreatedBy]
                              ,[CreatedDate]
                              ,[LastUpdatedBy]
                              ,[LastUpdatedDate]
                          FROM [S0VPITEM].[dbo].[ItemForm]
  WHERE ID = @ItemFormID";

        private const string DeleteReuseItemCodeByItemFormIdSQL = @"DELETE FROM [dbo].[ReUseItemCode] WHERE [ItemFormID] = (SELECT ID from [dbo].[ItemForm]  WHERE ItemFormDisplayID = @ItemFormDisplayID)";

        private const string GetVendorItemCodeSQL = @"SELECT VendorItemCode from  [dbo].[BasicItemDefinition] WHERE [ItemFormID] = @ItemFormID";

        private const string GetBasicItemDefinitionGTINSQL = @"SELECT [GTIN],[GTINCheckDigit] FROM[S0VPITEM].[dbo].[BasicItemDefinition]  WHERE [ItemFormID] = @ItemFormID
                                               UNION
                                               SELECT [GTIN],[GTINCheckDigit] FROM[S0VPITEM].[dbo].[AdditionalGTIN]  WHERE [ItemFormID] = @ItemFormID";

        private const string IsDsdVendorsExistForItemFormSQL = @"SELECT COUNT(*) FROM [dbo].[PackagingHierarchy] 
                                                INNER JOIN [dbo].[OrderablePackLevel] ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
                                                WHERE PackagingHierarchy.ItemFormID = @ItemFormID AND OrderablePackLevel.VendorType = 'DSD'";
        private const string DeleteItemFormErrorSQL = @"DELETE FROM [dbo].[ItemFormError] WHERE [ItemFormID] = @ItemFormID AND TabName = @TabName";
        private const string InsertItemFormErrorSQL = @"INSERT INTO [dbo].[ItemFormError]
                                       ([ItemFormID]
                                       ,[ErrorCode]
                                       ,[ErrorDescription]
                                       ,[TabName]
                                       ,[SubTabName]
                                       ,[CreatedBy]
                                       ,[CreatedDate])
                                 VALUES
                                       (@ItemFormID
                                       ,@ErrorCode
                                       ,@ErrorDescription
                                       ,@TabName
                                       ,@SubTabName
                                       ,@CreatedBy
                                       ,GetDate())";
        private const string GetItemFormErrorSQL = @"SELECT IFE.[ID]
                                          ,IFE.[ItemFormID]
                                          ,IFE.[ErrorCode]
                                          ,IFE.[ErrorDescription]
                                          ,IFE.[TabName]
                                          ,IFE.[SubTabName]
                                          ,EM.[ControlName]
                                          ,EM.[SeverityLevel]
                                          ,IFE.[CreatedBy]
                                          ,IFE.[CreatedDate]
                                      FROM [dbo].[ItemFormError] IFE
                                      INNER JOIN ErrorMessage EM ON EM.ErrorCode = IFE.ErrorCode
                                      WHERE [ItemFormID] = @ItemFormID";
        private const string GetItemFormGroupSQL = @"SELECT IFW.ID,IFW.ItemFormDisplayID, IFW.ParentFlag, IFW.IsInGroup, IFW.FormStatusID,
                                        (SELECT Count(*) from ItemFormError WHERE ItemFormID=IFW.ID) AS ItemFormErrorCount FROM ItemForm IFW 
                                        INNER JOIN BasicItemDefinition BID ON BID.ItemFormID = IFW.ID 
                                        INNER JOIN (SELECT ID, IsInGroup, ParentFlag, GroupID, BID2.GTIN FROM ItemForm  
                                                    INNER JOIN BasicItemDefinition BID2 ON BID2.ItemFormID = ID) AS ParentIFW 
                                        ON ParentIFW.GTIN = BID.GTIN AND ISNULL(ParentIFW.GroupID,'01/01/1900') = ISNULL(IFW.GroupID,'01/01/1900')
                                        WHERE ParentIFW.ID = @ItemFormID";

        private const string GetSystemValuesSQL = @"SELECT [KeyName] AS [Key],[Value] FROM [dbo].[SystemValue]";

        private const string InsertIntoItemForCreationSQL = @"INSERT INTO [dbo].[ItemFormsForCreation]
           ([ItemFormID]
           ,[Status]
           ,[ParentFlag]
           ,[ErrorMessage]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
                                 VALUES
                                       (@ItemFormID
                                       ,@Status
                                       ,@ParentFlag
                                       ,''
                                       ,@LastUpdatedBy
                                       ,getDate())";

        private const string GetVendorsForItemFormSQL = @"  Select VendorNumber from OrderablePackLevel opl inner join
  PackagingHierarchy ph on opl.packagingHierarchyID = ph.ID 
  where ph.ItemFormID = @ItemFormID";

        private const string GetChildFormsSQL = @"Select ID from ItemForm ifm 
inner join [dbo].[BasicItemDefinition] bid 
on ifm.id = bid.ItemFormID 
where bid.GTIN = (select GTIN from BasicItemDefinition where ItemFormID = @ItemFormID) 
and ifm.IsInGroup = 'Y' and ifm.GroupID is NULL";

        #endregion

    }
}
