﻿using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class ProductGroupingDac : BaseDac, IProductGroupingDac
    {
        public async Task<IEnumerable<ProductGroupingLinearDto>> GetProductGrouping(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<ProductGroupingLinearDto>(GetproductGroupingSQL, new { @ItemFormID = ItemFormID });
            }
        }
        public async Task<bool> SaveProductGrouping(List<ProductGroupingLinearDto> productGroupingList, int ItemFormID)
        {
            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    // Audit and delete "Product Grouping" list
                    await conn.ExecuteAsync(InsertProductGroupingAuditSQL, new { ItemFormID = ItemFormID });
                    await conn.ExecuteAsync(DeleteProductGroupingSQL, new { ItemFormID = ItemFormID });
                    if (productGroupingList != null && productGroupingList.Count > 0)
                    {
                        await conn.ExecuteAsync(InsertProductGroupingSQL, productGroupingList);
                    }
                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }
        public async Task<bool> SaveFAMProductGrouping(List<ProductGroupingLinearDto> productGroupingList, int ItemFormID)
        {
            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    // Audit and delete "FAM Product Grouping" list
                    if (productGroupingList != null && productGroupingList.Count > 0)
                    {
                        await conn.ExecuteAsync(InsertFAMProductGroupingAuditSQL, new { ItemFormIDs = ItemFormID });
                        await conn.ExecuteAsync(DeleteFAMProductGroupingSQL, new { ItemFormIDs = ItemFormID });
                        await conn.ExecuteAsync(InsertProductGroupingSQL, productGroupingList);
                    }
                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }
        public async Task<bool> CopyProductGrouping(int ItemFormID, int SimilarItemFormID)
        {
            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    // Audit and delete "Product Grouping" list
                    await conn.ExecuteAsync(InsertProductGroupingAuditSQL, new { ItemFormID = ItemFormID });
                    await conn.ExecuteAsync(DeleteProductGroupingSQL, new { ItemFormID = ItemFormID });
                    await conn.ExecuteAsync(CopyProductGroupingSQL, new { ItemFormID = ItemFormID, SimilarItemFormID = SimilarItemFormID });
                    await conn.ExecuteAsync(CopyBuyerItemFormSQL, new { ItemFormIDs = ItemFormID, ParentItemFormID = SimilarItemFormID });
                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }
        public async Task<bool> CopyFAMProductGrouping(List<ProductGroupingLinearDto> productGroupingFAMList, int ItemFormID, List<int> SimilarItemFormIDs)
        {
            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    List<ProductGroupingLinearDto> productGroupingList = new List<ProductGroupingLinearDto>();
                    foreach(int similarItemFormID in SimilarItemFormIDs)
                    {
                        foreach(var productGroupingFAM in productGroupingFAMList)
                        {
                            productGroupingList.Add(new ProductGroupingLinearDto
                            {
                                ItemFormID = similarItemFormID,
                                ChildProductGroupType = productGroupingFAM.ChildProductGroupType,
                                ChildProductGroupCode = productGroupingFAM.ChildProductGroupCode,
                                ChildProductGroupDescription = productGroupingFAM.ChildProductGroupDescription,
                                ItemTag = productGroupingFAM.ItemTag,
                                ParentProductGroupType = productGroupingFAM.ParentProductGroupType,
                                ParentProductGroupCode = productGroupingFAM.ParentProductGroupCode,
                                ParentProductGroupDescription = productGroupingFAM.ParentProductGroupDescription,
                                GrandParentProductGroupType = productGroupingFAM.GrandParentProductGroupType,
                                GrandParentProductGroupCode = productGroupingFAM.GrandParentProductGroupCode,
                                GrandParentProductGroupDescription = productGroupingFAM.GrandParentProductGroupDescription,
                                CreatedBy = "SYSTEM",
                                LastUpdatedBy = productGroupingFAM.LastUpdatedBy
                            });
                        }
                    }
                    // Audit and delete "Product Grouping" list
                    await conn.ExecuteAsync(InsertFAMProductGroupingAuditSQL, new { ItemFormIDs = string.Join(",", SimilarItemFormIDs) });
                    await conn.ExecuteAsync(DeleteFAMProductGroupingSQL, new { ItemFormIDs = string.Join(",", SimilarItemFormIDs) });
                    await conn.ExecuteAsync(InsertProductGroupingSQL, productGroupingList);
                    await conn.ExecuteAsync(CopyBuyerItemFormSQL, new { ItemFormIDs = string.Join(",", SimilarItemFormIDs), ParentItemFormID = ItemFormID });
                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }
        public async Task UpdateItemFormBuyer(ItemFormDto itemForm)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(UpdateItemFormBuyerSQL, itemForm);
            }
        }

        public async Task<IEnumerable<ProductPriceGroupDto>> GetProductPriceGroup(string SearchBy, string SearchValue)
        {
            int SearchIntValue;
            if (!Int32.TryParse(SearchValue, out SearchIntValue))
            {
                SearchIntValue = -1;
            }
            string SearchLikeValue = SearchValue + "%";
            using (var conn = (SqlConnection)base.FLEX_Connection)
            {
                await conn.OpenAsync();
                string PriceGroupSQL = @"SELECT PG.[PriceGroupID],PG.[PriceGroupName],PG.[LeadItemCode],PG.[ItemCode],PG.[ItemDescription]
                                      ,PG.[SupplierNumber] AS VendorNumber,PG.[SupplierName] AS VendorName
                                       FROM [dbo].[vw_PriceGroup] PG ";
                if (SearchBy == "ItemCode")
                {
                    PriceGroupSQL += @"WHERE LeadItemCode = @SearchIntValue";
                }
                else if (SearchBy == "ItemDescription")
                {
                    PriceGroupSQL += @"INNER JOIN (SELECT [PriceGroupID], ItemCode, MIN(LeadItemCode) As LeadItemCode from [dbo].[vw_PriceGroup] GROUP BY PriceGroupID,ItemCode) AS PG2
                                         ON PG2.PriceGroupID = PG.PriceGroupID AND PG2.LeadItemCode = PG.LeadItemCode AND PG2.ItemCode = PG.ItemCode ";
                    PriceGroupSQL += @"WHERE PG.ItemDescription LIKE @SearchLikeValue";
                }
                else if (SearchBy == "PriceGroupID")
                {
                    PriceGroupSQL += @"INNER JOIN (SELECT [PriceGroupID], ItemCode, MIN(LeadItemCode) As LeadItemCode from [dbo].[vw_PriceGroup] GROUP BY PriceGroupID,ItemCode) AS PG2
                                         ON PG2.PriceGroupID = PG.PriceGroupID AND PG2.LeadItemCode = PG.LeadItemCode AND PG2.ItemCode = PG.ItemCode ";
                    PriceGroupSQL += @"WHERE PG.[PriceGroupID] = @SearchIntValue";
                }
                else if (SearchBy == "PriceGroupName")
                {
                    PriceGroupSQL += @"INNER JOIN (SELECT [PriceGroupID], ItemCode, MIN(LeadItemCode) As LeadItemCode from [dbo].[vw_PriceGroup] GROUP BY PriceGroupID,ItemCode) AS PG2
                                         ON PG2.PriceGroupID = PG.PriceGroupID AND PG2.LeadItemCode = PG.LeadItemCode AND PG2.ItemCode = PG.ItemCode ";
                    PriceGroupSQL += @"AND PG.[PriceGroupName] LIKE @SearchLikeValue";
                }
                else
                {
                    return new List<ProductPriceGroupDto>();
                }
                return await conn.QueryAsync<ProductPriceGroupDto>(PriceGroupSQL, new { @SearchIntValue = SearchIntValue, @SearchLikeValue = SearchLikeValue });
            }
        }
        public async Task<IEnumerable<ProductAdGroupDto>> GetProductAdGroup(string SearchBy, string SearchValue)
        {
            int SearchIntValue;
            if(!Int32.TryParse(SearchValue, out SearchIntValue))
            {
                SearchIntValue = -1;
            }
            string SearchLikeValue = SearchValue.Trim() + "%";
            using (var conn = (SqlConnection)base.PPMS_Connection)
            {
                await conn.OpenAsync();
                string AdGroupSQL = @" SELECT [AdGroupID],[AdGroupDesc] AS AdGroupName,[ItemCode],[ItemDesc] AS ItemDescription,[LeadCode]
                                       FROM [dbo].[AdGroupItems] WHERE ";
                if(SearchBy == "ItemCode")
                {
                    AdGroupSQL += @"AdGroupID IN (SELECT DISTINCT AdGroupID FROM [dbo].[AdGroupItems] WHERE ItemCode = @SearchIntValue)";
                }
                else if (SearchBy == "ItemDescription")
                {
                    AdGroupSQL += @"AdGroupID IN (SELECT DISTINCT AdGroupID FROM [dbo].[AdGroupItems] WHERE ItemDesc LIKE @SearchLikeValue)";
                }
                else if(SearchBy == "AdGroupID")
                {
                    AdGroupSQL += @"AdGroupID = @SearchIntValue";
                }
                else if (SearchBy == "AdGroupName")
                {
                    AdGroupSQL += @"[AdGroupDesc] LIKE @SearchLikeValue";
                }
                else
                {
                    return new List<ProductAdGroupDto>();
                }
                return await conn.QueryAsync<ProductAdGroupDto>(AdGroupSQL, new { @SearchIntValue = SearchIntValue, @SearchLikeValue = SearchLikeValue });
            }
        }

        public async Task<IEnumerable<ProductGroupingDto>> GetFLEXProductGroup(int ItemCode, int ModelGroupCodeType)
        {
            using (var conn = (SqlConnection)base.FLEX_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<ProductGroupingDto>(GetFLEXProductGroupSQL, new { @ItemCode = ItemCode, @ModelGroupCodeType = ModelGroupCodeType });
            }
        }
        public async Task<IEnumerable<ProductGroupingDto>> GetPPMSProductGroup(int ItemCode, int ModelGroupCodeType)
        {
            using (var conn = (SqlConnection)base.PPMS_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<ProductGroupingDto>(GetPPMSProductGroupSQL, new { @ItemCode = ItemCode, @ModelGroupCodeType = ModelGroupCodeType });
            }
        }
        public async Task<IEnumerable<ProductGroupingVendorDto>> GetVBGVendors(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<ProductGroupingVendorDto>(GetVBGVendorsSQL, new { @ItemFormID = ItemFormID });
            }
        }

        public async Task<int> GetSubmittedItemFormIDWithSameGTIN(int ItemFormID, string ItemFormStatusIDs)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.ExecuteScalarAsync<int>(GetSubmittedItemFormIDWithSameGTINSQL, new { @ItemFormID = ItemFormID, @ItemFormStatusIDs = ItemFormStatusIDs});
            }
        }

        #region "SQL Queries"
        private const string InsertProductGroupingAuditSQL = @"INSERT INTO [dbo].[ProductGroupingAudit]
                                       ([Version]
                                       ,[ID]
                                       ,[ItemFormID]
                                       ,[ChildProductGroupType]
                                       ,[ChildProductGroupCode]
                                       ,[ChildProductGroupDescription]
                                       ,[ItemTag] 
                                       ,[ParentProductGroupType]
                                       ,[ParentProductGroupCode]
                                       ,[ParentProductGroupDescription]
                                       ,[GrandParentProductGroupType]
                                       ,[GrandParentProductGroupCode]
                                       ,[GrandParentProductGroupDescription]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                               SELECT 
                                        GetDate()
                                       ,[ID]
                                       ,[ItemFormID]
                                       ,[ChildProductGroupType]
                                       ,[ChildProductGroupCode]
                                       ,[ChildProductGroupDescription]
                                       ,[ItemTag] 
                                       ,[ParentProductGroupType]
                                       ,[ParentProductGroupCode]
                                       ,[ParentProductGroupDescription]
                                       ,[GrandParentProductGroupType]
                                       ,[GrandParentProductGroupCode]
                                       ,[GrandParentProductGroupDescription]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate]
                               FROM [dbo].[ProductGrouping] where ItemFormID = @ItemFormID";
        private const string DeleteProductGroupingSQL = @"DELETE FROM [dbo].[ProductGrouping] WHERE 
                                        ItemFormID = @ItemFormID";
        private const string InsertProductGroupingSQL = @"INSERT INTO [dbo].[ProductGrouping]
                                       ([ItemFormID]
                                       ,[ChildProductGroupType]
                                       ,[ChildProductGroupCode]
                                       ,[ChildProductGroupDescription]
                                       ,[ItemTag] 
                                       ,[ParentProductGroupType]
                                       ,[ParentProductGroupCode]
                                       ,[ParentProductGroupDescription]
                                       ,[GrandParentProductGroupType]
                                       ,[GrandParentProductGroupCode]
                                       ,[GrandParentProductGroupDescription]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                                 VALUES
                                       (@ItemFormID
                                       ,@ChildProductGroupType
                                       ,@ChildProductGroupCode
                                       ,@ChildProductGroupDescription
                                       ,@ItemTag
                                       ,@ParentProductGroupType
                                       ,@ParentProductGroupCode
                                       ,@ParentProductGroupDescription
                                       ,@GrandParentProductGroupType
                                       ,@GrandParentProductGroupCode
                                       ,@GrandParentProductGroupDescription
                                       ,@CreatedBy
                                       ,GetDate()
                                       ,@LastUpdatedBy
                                       ,GetDate())";
        private const string InsertFAMProductGroupingAuditSQL = @"INSERT INTO [dbo].[ProductGroupingAudit]
                                       ([Version]
                                       ,[ID]
                                       ,[ItemFormID]
                                       ,[ChildProductGroupType]
                                       ,[ChildProductGroupCode]
                                       ,[ChildProductGroupDescription]
                                       ,[ItemTag] 
                                       ,[ParentProductGroupType]
                                       ,[ParentProductGroupCode]
                                       ,[ParentProductGroupDescription]
                                       ,[GrandParentProductGroupType]
                                       ,[GrandParentProductGroupCode]
                                       ,[GrandParentProductGroupDescription]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                               SELECT 
                                        GetDate()
                                       ,[ID]
                                       ,[ItemFormID]
                                       ,[ChildProductGroupType]
                                       ,[ChildProductGroupCode]
                                       ,[ChildProductGroupDescription]
                                       ,[ItemTag] 
                                       ,[ParentProductGroupType]
                                       ,[ParentProductGroupCode]
                                       ,[ParentProductGroupDescription]
                                       ,[GrandParentProductGroupType]
                                       ,[GrandParentProductGroupCode]
                                       ,[GrandParentProductGroupDescription]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate]
                               FROM [dbo].[ProductGrouping] where ItemFormID IN (SELECT * FROM dbo.CSVToTable(@ItemFormIDs)) AND ChildProductGroupType = 'FAM'";
        private const string DeleteFAMProductGroupingSQL = @"DELETE FROM [dbo].[ProductGrouping] WHERE 
                                        ItemFormID IN (SELECT * FROM dbo.CSVToTable(@ItemFormIDs)) AND ChildProductGroupType = 'FAM'";
        private const string CopyProductGroupingSQL = @"INSERT INTO [dbo].[ProductGrouping]
                                       ([ItemFormID]
                                       ,[ChildProductGroupType]
                                       ,[ChildProductGroupCode]
                                       ,[ChildProductGroupDescription]
                                       ,[ItemTag] 
                                       ,[ParentProductGroupType]
                                       ,[ParentProductGroupCode]
                                       ,[ParentProductGroupDescription]
                                       ,[GrandParentProductGroupType]
                                       ,[GrandParentProductGroupCode]
                                       ,[GrandParentProductGroupDescription]
                                       ,[CreatedBy]
                                       ,[CreatedDate]
                                       ,[LastUpdatedBy]
                                       ,[LastUpdatedDate])
                               SELECT 
                                        @ItemFormID
                                       ,[ChildProductGroupType]
                                       ,[ChildProductGroupCode]
                                       ,[ChildProductGroupDescription]
                                       ,[ItemTag] 
                                       ,[ParentProductGroupType]
                                       ,[ParentProductGroupCode]
                                       ,[ParentProductGroupDescription]
                                       ,[GrandParentProductGroupType]
                                       ,[GrandParentProductGroupCode]
                                       ,[GrandParentProductGroupDescription]
                                       ,[CreatedBy]
                                       ,GetDate()
                                       ,[LastUpdatedBy]
                                       ,GetDate()
                               FROM [dbo].[ProductGrouping] where ItemFormID = @SimilarItemFormID";
        private const string CopyBuyerItemFormSQL = @"UPDATE ItemForm
                                            SET BuyerID = i.BuyerID,
                                            BuyerName = i.BuyerName
                                            FROM  (SELECT ID, BuyerID,BuyerName FROM  ItemForm WHERE ID = @ParentItemFormID ) i
                                            WHERE ItemForm.ID IN (SELECT * FROM dbo.CSVToTable(@ItemFormIDs))";
        private const string GetproductGroupingSQL = @"SELECT       
	                                    [ItemFormID]
                                       ,[ChildProductGroupType]
                                       ,[ChildProductGroupCode]
                                       ,[ChildProductGroupDescription]
                                       ,[ItemTag] 
                                       ,[ParentProductGroupType]
                                       ,[ParentProductGroupCode]
                                       ,[ParentProductGroupDescription]
                                       ,[GrandParentProductGroupType]
                                       ,[GrandParentProductGroupCode]
                                       ,[GrandParentProductGroupDescription]
                               FROM [dbo].[ProductGrouping] PG
                                        WHERE PG.ItemFormID = @ItemFormID";

        private const string GetProductPriceGroupSQL = @"SELECT [PriceGroupID]
                                      ,[PriceGroupName]
                                      ,[LeadItemCode]
                                      ,[ItemCode]
                                      ,[ItemDescription]
                                      ,[SupplierNumber] AS VendorNumber
                                      ,[SupplierName] AS VendorName
                                  FROM [dbo].[vw_PriceGroup]
                                        WHERE LeadItemCode = @ItemCode";
        private const string GetFLEXProductGroupSQL = @" SELECT 'FLEX' AS ProductGroupType
                                      ,[PriceGroupID] AS ProductGroupCode
                                      ,[PriceGroupName] AS ProductGroupDescription
                                      ,@ModelGroupCodeType  AS ModelGroupCodeType
                                 FROM [dbo].[vw_PriceGroup]
                                        WHERE LeadItemCode = @ItemCode AND ItemCode = @ItemCode";
        private const string GetProductAdGroupSQL = @" SELECT [AdGroupID]
                                      ,[AdGroupDesc] AS AdGroupName
                                      ,[ItemCode]
                                      ,[ItemDesc] AS ItemDescription
                                      ,[LeadCode]
                                  FROM [dbo].[AdGroupItems]
                                        WHERE  AdGroupID IN (SELECT AdGroupID FROM [dbo].[AdGroupItems] 
                                                            WHERE ItemCode = @ItemCode)";
        private const string GetPPMSProductGroupSQL = @" SELECT 'PPMS' AS ProductGroupType
                                      ,[AdGroupID] AS ProductGroupCode
                                      ,[AdGroupDesc] AS ProductGroupDescription
                                      ,@ModelGroupCodeType  AS ModelGroupCodeType
                                  FROM [dbo].[AdGroupItems]
                                                    WHERE ItemCode = @ItemCode";

        private const string GetVBGVendorsSQL = @" SELECT DISTINCT VendorNumber, [VendorDescription] FROM [dbo].[PackagingHierarchy] 
                                                INNER JOIN [dbo].[OrderablePackLevel] ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
                                                WHERE OrderablePackLevel.VendorType = 'DSD' AND PackagingHierarchy.ItemFormID 
                                                IN 
												(SELECT ID FROM ItemForm IFW WHERE ID = @ItemFormID AND IFW.ParentFlag != 'Y'
                                                    UNION
                                                 SELECT IFW.ID FROM ItemForm IFW 
                                                    INNER JOIN BasicItemDefinition BID 
                                                    ON BID.ItemFormID = IFW.ID 
                                                    INNER JOIN (SELECT ID, IsInGroup, ParentFlag, BID2.GTIN FROM ItemForm  
                                                                INNER JOIN BasicItemDefinition BID2 ON BID2.ItemFormID = ID) AS ParentIFW 
                                                    ON ParentIFW.GTIN = BID.GTIN AND ParentIFW.ParentFlag = 'Y'
                                                 WHERE ParentIFW.ID = @ItemFormID)";

        private const string GetSubmittedItemFormIDWithSameGTINSQL = @"SELECT TOP 1 IFW.ID FROM ItemForm IFW 
                                                    INNER JOIN BasicItemDefinition BID ON BID.ItemFormID = IFW.ID 
                                                    INNER JOIN ProductGrouping PG ON PG.ItemFormID = IFW.ID
                                                    WHERE BID.GTIN = (SELECT GTIN FROM BasicItemDefinition BID2 WHERE BID2.ItemFormID = @ItemFormID) 
	                                                AND IFW.ID != @ItemFormID AND IFW.FormStatusID IN (SELECT * FROM dbo.CSVToTable(@ItemFormStatusIDs)) 
                                                    AND PG.ParentProductGroupType = 'BUY'         
                                                    ORDER BY IFW.ID DESC";
        private const string UpdateItemFormBuyerSQL = @"UPDATE [dbo].[ItemForm]
                        SET
                        [BuyerID] = @BuyerID,
                        [BuyerName] = @BuyerName
                        WHERE ID = @ID";
        #endregion
    }
}
