﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IPackagingHierarchyDac
    {
        Task<IEnumerable<RetailPackTypeDto>> GetRetailPackTypesForItemForm(int itemFormID);

        Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchies(int itemFormID);
        Task<IEnumerable<CaseCodeTypeDto>> GetCaseCodeTypes();
        Task<int> InsertPackagingHierarchy(PackagingHierarchyDto packagingHierarchy);
        Task<int> IsPackagingHierarchyExistsForItemForm(PackagingHierarchyDto packagingHierarchy);
        Task UpdatePackagingHierarchy(PackagingHierarchyDto packagingHierarchy);
        Task<IEnumerable<OrderingLevelsDto>> GetOrderingLevels();
        Task InsertOrderabePackLevels(OrderablePackLevelDto orderablePackLevel);
        Task<bool> DeleteOrderingLevels(int packagingHierarchyID , bool isModelling = false);
        Task<int> IsPrimaryVendorExistsForWHByGtin(WarehouseGtinDto warehouseDetails);
        Task UpdatePrimaryVendorForWarehouse(WarehouseGtinDto warehouseDetails);
        Task<bool> DeletePackagingHierarchies(GTINRetailPackInfoDto gtinRetailPackInfo);
        Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchiesByModelItemCode(int? itemFormId);

        Task<IEnumerable<PackagingHierarchyDto>> GetPackagingHierarchiesByModelGTIN(decimal gtin);

        Task<IEnumerable<OrderablePackLevelDto>> GetOrderablePackLevels(int packagingHierarchyID);

        Task<IEnumerable<int>> GetValidItemFormIDForModellingByModelPHItemCode(int? modelItemCode , int? itemformId, List<int> userVendors , UserType userType);

        Task<IEnumerable<int>> GetValidItemFormIDForModellingByGtin(decimal gtin, int? itemformId, List<int> userVendors, UserType userType);
        Task<IEnumerable<VendorDomainDto>> GetDsdVendorsExistInDsdForItemForm(int itemFormID);
    }
}
