﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IProductAttributesDac
    {
        Task<bool> SaveProductAttributes(List<ProductAttributeDto> productAttributes, int ItemFormID);
        Task<int> InsertProductAttributes(List<ProductAttributeDto> productAttributes);
        Task<IEnumerable<ProductAttributeDto>> GetProductAttributes(int ItemFormID);
        Task<IEnumerable<ProductGroupingLinearDto>> GetFamAndRssDetails(int ItemFormID);
        Task<IEnumerable<ErrorDTO>> GetErrorMessages();
        Task<IEnumerable<ProductAttributeScopingDto>> GetProductAttributesScopingDetails();

        Task<string> GetPAScopingColumnValue(string tableName, string columnName, int itemFormID);

    }
}
