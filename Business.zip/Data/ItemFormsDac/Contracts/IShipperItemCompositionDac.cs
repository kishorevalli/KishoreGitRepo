﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{   
        public interface IShipperItemCompositionDac
        {
          Task<bool> SaveShipperCompositionItems(ShipperItemCompositionDto ShipperItemComposition);
          Task<bool> DeleteShipperCompositionItem(ShipperItemCompositionDto ShipperItemComposition);
          Task<IEnumerable<ShipperItemCompositionDto>> GetShipperCompositionItems(int ItemFormID);
        Task<bool> InsertShipperCompositionItem(ShipperItemCompositionDto ShipperItemComposition);
        Task<bool> DeleteAllShipperCompositionItems(int ItemFormID);

        Task<IEnumerable<ShipperItemCompositionDto>> CheckShipperItemCompositionGTINExistInItemForm(decimal CompositionGTIN);

          Task<int> GetCaseType(int ItemFormID);

          Task<int> GetShipperSubDepartmentCode(int ItemFormID);

          Task<int> GetProductGroupingSubDepartmentCode(int ItemFormID);

        Task<int> DeleteShipperItemCompositionList(int ItemFormID);
    }         
}
