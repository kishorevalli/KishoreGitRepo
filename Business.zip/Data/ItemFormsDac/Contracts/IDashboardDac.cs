﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
   public interface IDashboardDac
    {
        string AttachSearchFiterList(DashboardSearchCriteriaDto dashboardSearchCriteriaDto, UserType user);
        Task<IEnumerable<DashboardItemFormDto>> GetItemFormListBySearchCriteria(DashboardSearchCriteriaDto dashboardSearchCriteriaDto);
        Task<IEnumerable<DashboardItemFormDto>> GetItemFormListBySearchCriteriaInternalUser(DashboardSearchCriteriaDto dashboardSearchCriteriaDto);        
      
        Task<IEnumerable<DashboardStatusDto>> GetDashboardStatus(LoggedInUserDto loggedInUser);
        Task<int> GetDashboardStatusCount(DashboardStatusDto dashboardStatusDto);
        Task<int> GetDashboardStatusCountInternal(DashboardStatusDto dashboardStatusDto);
        Task<IEnumerable<DashboardItemFormDto>> GetDashboardStatusDetail(DashboardStatusDto dashboardStatusDto);
        Task<IEnumerable<DashboardItemFormDto>> GetDashboardStatusDetailInternal(DashboardStatusDto dashboardStatusDto);
        
        Task<bool> UpdateItemFormActionAndCurrentStatus(FormUserPermittedActionDto formUserPermittedAction);
        Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForVendor();
        Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForBuyer(int LoggedInUserTypeID);
        

        bool UpdateVSARelatedForm(string VSALoginUserID, string VendorList);
        Task<bool> InsertDashboardUserSelection(DashboardUserSelectionDto dashboardUserSelectionDto);
        Task<DashboardUserSelectionDto> GetDashboardUserSelection(string LoggedInUserID);
        int ValidateItemFormByVendors(int ItemFormID, string LoggedInVendorList);

        //TODO Remove
        Task<IEnumerable<ItemFormDto>> GetItemForms(string userId);
        Task<bool> UpdateReassignVendorContact(ViewForUserListDto vendorContact);

        Task<IEnumerable<DashboardItemFormDto>> AddItemFormToGroup(int ItemFormID);

        Task<IEnumerable<DashboardItemFormDto>> RemoveItemFormFromGroup(int ItemFormID);

        Task<IEnumerable<DashboardItemFormDto>> ParentingItemForm(int ItemFormID);
        Task<IEnumerable<DashboardItemFormDto>> UnParentingItemForm(int ItemFormID);

        Task<IEnumerable<ErrorDTO>> GetDashboardErrorMessageList(int ItemFormID);

        Task<bool> ChangeVendorSubmittedFormToReview(int ItemFormID);

        Task<bool> UpdateItemFormStatusForInternalUser(FormUserPermittedActionDto formUserPermittedAction);
        Task<DashboardStatusDto> GetDefaultFavouriteForUserType(int UserTypeID);
        Task<string> GetParentStatusForGTIN(decimal GTIN);

        Task<IEnumerable<FormUserPermittedActionDto>> GetFormActionsForItemForm(int currentUserTypeID, int CurrentFormStatusID);

    }
}
