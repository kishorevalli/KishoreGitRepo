﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IScaleItemDetailsDac
    {
        Task<bool> IsScaleItemDetailsExist(int itemFormId);
        Task InsertScaleInfo(ScaleInfoDto scaleInfoDto);
        Task InsertScaleOverrideDescription(ScaleOverrideDescriptionDto scaleOverrideDto, int itemFormId);
        Task InsertScaleLocation(ScaleLocationDto scaleLocationDto, int itemFormId);
        Task InsertScaleShelfLife(ScaleShelfLifeDto scaleShelfLifeDto, int itemFormId);
        Task InsertScaleGrade(ScaleGradeDto scaleGradeDto, int itemFormId);
        Task<ScaleInfoDto> GetScaleInfo(int itemFormId);
        Task UpdateScaleInfo(ScaleInfoDto scaleInfoDto);
        Task<List<ScaleOverrideDescriptionDto>> GetScaleOverrideDescription(int itemFormId);
        Task<List<ScaleLocationDto>> GetScaleLocations(int itemFormId);
        Task<List<ScaleShelfLifeDto>> GetScaleShelfLife(int itemFormId);
        Task<List<ScaleGradeDto>> GetScaleGrade(int itemFormId);
        Task InsertScaleOverrideDescriptionAudit(int itemFormId);
        Task InsertScaleLocationAudit(int itemFormId);
        Task InsertScaleShelfLifeAudit(int itemFormId);
        Task InsertScaleGradeAudit(int itemFormId);
        Task<IEnumerable<ErrorDTO>> GetErrorMessages();
    }
}
