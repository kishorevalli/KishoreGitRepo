﻿using Publix.S0VPITEM.ItemFormsEntities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IGeneralProductAttributesDac
    {
        Task<IEnumerable<LookupDto>> GetNutritionalPanelTypes();
        Task<IEnumerable<OrganicType>> GetOrganicTypes();
        Task<IEnumerable<DrugScheduleCodeDto>> GetDrugScheduleCodes();
        Task<GeneralProductAttributesDto> GetGeneralProductAttributes(int itemFormID);
      //  Task<bool> SaveGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes);
        Task<bool> IsGPADetailsExistsForItemForm(int ItemFormID);
        Task<IEnumerable<ErrorDTO>> GetErrorMessages();
        Task InsertGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes);
        Task UpdateGeneralProductAttributes(GeneralProductAttributesDto generalProductAttributes);
        Task DeleteNutritionalPanel(NutritionalPanelDto nutritionalPanel);
        Task InsertNutritionalPanel(NutritionalPanelDto nutritionalPanel);
        Task UpdateNutritionalPanels(NutritionalPanelDto nutritionalPanel);
        Task<IEnumerable<VariableWeightIndicatorDto>> GetVariableWeightIndicators();
        Task<IEnumerable<UnacceptableIngredientDto>> GetUnacceptableIngredientList();

        Task<GeneralProductAttributesDto> GetGPAWeightDetails(int itemFormID);
        //Task<IEnumerable<ErrorDTO>> GetErrorMessagesCollection();

    }
}
