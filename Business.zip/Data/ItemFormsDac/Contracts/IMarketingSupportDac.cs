﻿using Publix.S0VPITEM.ItemFormsEntities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IMarketingSupportDac
    {
        Task<IEnumerable<LookupDto>> GetPromoSupportFrequency();
        Task<IEnumerable<LookupDto>> GetUnitCostUOM();
        Task<MarketingInfoDto> GetMarketingInfo(int ItemFormID);
        Task<bool> SaveMarketingInfo(MarketingInfoDto marketingInfo);
        Task<IEnumerable<FormCommentDto>> GetFormComment(int ItemFormID, int UserType);
        Task<bool> SaveFormComment(FormCommentDto formComment);
        Task<List<SimilarItemGTINDto>> CreateSimilarItemForms(int ItemFormID);
        Task<bool> CloneSimilarItemFormData(SimilarItemGTINDto SimilarItemForm);
        Task UpdateItemFormVendorEmail(ItemFormDto itemForm);
    }
}
