﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IProductGroupingDac
    {
        Task<IEnumerable<ProductGroupingLinearDto>> GetProductGrouping(int ItemFormID);
        Task<bool> SaveProductGrouping(List<ProductGroupingLinearDto> productGroupingList, int ItemFormID);
        Task<IEnumerable<ProductPriceGroupDto>> GetProductPriceGroup(string SearchBy, string SearchValue);
        Task<IEnumerable<ProductAdGroupDto>> GetProductAdGroup(string SearchBy, string SearchValue);
        Task<IEnumerable<ProductGroupingVendorDto>> GetVBGVendors(int ItemFormID);
        Task<IEnumerable<ProductGroupingDto>> GetFLEXProductGroup(int ItemCode, int ModelGroupCodeType);
        Task<IEnumerable<ProductGroupingDto>> GetPPMSProductGroup(int ItemCode, int ModelGroupCodeType);
        Task UpdateItemFormBuyer(ItemFormDto itemForm);
        Task<int> GetSubmittedItemFormIDWithSameGTIN(int ItemFormID, string ItemFormStatusIDs);
        Task<bool> CopyProductGrouping(int ItemFormID, int SimilarItemFormID);
        Task<bool> SaveFAMProductGrouping(List<ProductGroupingLinearDto> productGroupingList, int ItemFormID);
        Task<bool> CopyFAMProductGrouping(List<ProductGroupingLinearDto> productGroupingFAMList, int ItemFormID, List<int> SimilarItemFormIDs);
    }
}
