﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface ICommonDac
    {
        Task<Boolean> IsGTINExists(long Gtin);

        Task<bool> DeleteItemForm(ItemFormDto itemFormDto);

        Task<ItemFormDto> SaveItemForm(ItemFormDto itemFormDto);

        Task<ItemFormDto> GetItemFormData(long itemFormDisplayId);

        Task UpdateItemForm(ItemFormDto itemForm);

        Task<IEnumerable<ErrorDTO>> GetErrorMessagesByType(ErrorDTO errors);

        Task UpdateItemCodeForItemForm(ItemFormDto itemForm);
        Task<string> GetVendorItemCode(int itemFormID);

        Task<IEnumerable<ErrorDTO>> GetErrorMessages();
        Task<IEnumerable<GTINWithCheckdigitDto>> GetBasicItemDefinitionGTIN(int itemFormID);
        Task<bool> IsDsdVendorsExistForItemForm(int itemFormID);
        Task<bool> IsFAMCodeExistsInProductGrouping(int itemFormID);
        Task<bool> SaveItemFormErrors(List<ItemFormErrorDto> ItemFormErroList, string TabName, int ItemFormID);
        Task<IEnumerable<ItemFormErrorDto>> GetItemFormErrors(int ItemFormID);
        Task<IEnumerable<ItemFormDto>> GetItemFormGroup(int ItemFormID);
        Task<IEnumerable<KeyValuePair<string, string>>> GetSystemValues();
        Task SubmitItemFormsForCreation(IEnumerable<CreateItemFormDto> itemFormsForCreation);
        Task<IEnumerable<int>> GetVendorsForItemForm(int itemFormId);
        Task<IEnumerable<int>> GetChildForms(int itemFormId);
        Task<ItemFormDto> GetItemFormDataById(long itemFormId);
    }
}
