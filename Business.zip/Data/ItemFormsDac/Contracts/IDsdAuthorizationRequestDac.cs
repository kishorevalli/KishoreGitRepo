﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IDsdAuthorizationRequestDac
    {
        Task<bool> SaveDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList);

        Task<IEnumerable<DsdVendorAuthorizationDto>> GetDsdVendorAuthorizations(int itemFormID);

        Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdVendorsByItemForm(int itemFormID);

        Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdStatesByItemForm(int itemFormID);

        Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdCountiesByItemForm(int itemFormID);

        Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdVendorStoreAuthorizationsByItemForm(int itemFormID);

        Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdVendorStoreAuthorizationsBySearchCriteria(VendorServiceDto vendorServiceDto);

        Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdOverlappedVendorStoreAuthorizationsByItemForm(int itemFormID);

        Task<bool> IsOverlappedVendorStoreAuthExistsByItemForm(int itemFormID);

        Task<bool> IsMultipleDsdVendorsSubmittingSameGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto);

        Task SaveDsdVendorStoreAuthorization(DsdAuthRequestStoreDto dsdAuthRequestStoreDto);

        Task<bool> IsOverlappedVendorStoreAuthExistsByGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto);

        Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdOverlappedVendorStoreAuthorizationsByGtin(decimal gtin);


        Task<bool> SaveBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto);

        Task<BasicItemDefinitionDto> GetBasicItemDefinitionData(long itemFormDisplayID);

        Task<bool> DeleteDsdVendorAuthorizationsByItemForm(int itemFormID);

        Task<bool> DeleteDsdVendorAuthorizationsByItemFormAndVendors(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto);

        Task<bool> BulkInsertDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList);
        Task<IEnumerable<VendorDomainDto>> GetDsdVendorsExistForItemForm(int itemFormID);
        Task<bool> DeleteDsdVendorsNotInPackagingHierarchy(int itemFormID);
    }
}
