﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IBasicItemDefinitionDac
    {
        Task<IEnumerable<LookupDto>> GetSubmissionReasons();

        Task<IEnumerable<LookupDto>> GetItemCaseTypes();
      

        Task<bool> SaveBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto);

        Task<BasicItemDefinitionDto> GetBasicItemDefinitionData(int itemFormId);

        Task<IEnumerable<long>> GetItemFormsDisplayIDs(string userId);

        Task<Boolean> IsGTINExistsInPackagingHierarchy(decimal Gtin);

     //   Task<bool> DeleteItemForm(ItemFormDto itemFormDto);

        Task<IEnumerable<ErrorDTO>> GetErrorMessages();

        Boolean RemoveItemFormCache(String CacheKey);

        Task<IEnumerable<ReuseItemCodeDto>> GetItemFormReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto);

        Task<IEnumerable<ReuseItemCodeDto>> GetAvailableItemFormReuseItemCodesBySubDept(ReuseItemCodeDto reuseItemCodeDto);
        

        Task<ReuseItemCodeDto> IsSelectedReuseItemCodeAlreadyUsed(ReuseItemCodeDto reuseItemCodeDto);

        Task<bool> SaveReuseItemCode(ReuseItemCodeDto reuseItemCodeDto);

        Task<bool> DeleteUnAvailableReuseItemCodes(IEnumerable<ReuseItemCodeDto> reuseItemCodeDtoList);

        Task<bool> InsertAvailableReuseItemCodes(IEnumerable<ReuseItemCodeDto> reuseItemCodeDtoList);

        Task<bool> SaveModelProductItemValues(ModelProductItemValueDto modelProductItemValueDto);

        Task<ModelProductItemValueDto> GetModelProductItemValues(int itemFormID);

        Task<bool> DeleteModelProductItemValues(int itemFormID);

        Task<bool> SaveScaleInfo(ScaleInfoDto scaleInfoDto);

        Task<IEnumerable<LookupDto>> GetReuseItemSubDepartments();

        Task<bool> CheckIfItemCreatedByItemForms(int? itemCode);

     //   Task<IEnumerable<GTINWithCheckdigitDto>> GetBasicItemDefinitionGTIN(int itemFormID);
        Task<IEnumerable<GTINWithCheckdigitDto>> GetNutritionalPanelGTIN(int itemFormID);
        Task<bool> RemoveGTINRetailPackRelatedInfo(GTINRetailPackInfoDto gtinRetailPackInfo);
 
    }
}
