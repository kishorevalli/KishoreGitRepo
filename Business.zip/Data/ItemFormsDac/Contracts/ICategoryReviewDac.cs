﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface ICategoryReviewDac
    {
        //Task<IEnumerable<LookupDto>> GetRSSListByBuyerID(int BuyerID);
        Task<IEnumerable<CategoryReviewDto>> GetCategoryReviewReport(int BuyerID);

    }
}
