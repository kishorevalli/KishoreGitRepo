﻿using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac.Contracts
{
    public interface IWorkFlowDac
    {
        Task<IEnumerable<FormUserPermittedActionDto>> GetFormUserPermittedAction(UserType currentUserType, int FormCurrentStatusID , int formTypeID);

        int ValidateItemFormByVendors(int ItemFormID, string LoggedInVendorList);
    }
}
