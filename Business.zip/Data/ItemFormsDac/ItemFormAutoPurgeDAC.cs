﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Dapper;
using System.Data.SqlClient;
using System.Transactions;
using System.Globalization;
using System.Collections;


namespace Publix.S0VPITEM.ItemFormsDac
{

    public class ItemFormAutoPurgeDAC : BaseDac
    {
        public async Task<IEnumerable<ItemFormPurgeCriteriaDTO>> GetPurgeCriteria(string str)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                ItemFormPurgeCriteriaDTO purge = new ItemFormPurgeCriteriaDTO();
                return (await conn.QueryAsync<ItemFormPurgeCriteriaDTO>(str));
            }
        }
        //public IEnumerable<ItemFormPurgeCriteriaDTO> GetPurgeCriteria(string str)
        //{
        //    using (var conn = (SqlConnection)base.S0VPITEM_Connection)
        //    {
        //        conn.Open();
        //        ItemFormPurgeCriteriaDTO purge = new ItemFormPurgeCriteriaDTO();
        //        IEnumerable<ItemFormPurgeCriteriaDTO> retVals = conn.Query<ItemFormPurgeCriteriaDTO>(str);
        //        return retVals;
        //    }
        //}
        public async Task<IEnumerable<ItemFormPurgeTableListDTO>> GetPurgeTableList(string str)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<ItemFormPurgeTableListDTO>(str));              
            }
        }
        //public IEnumerable<ItemFormPurgeTableListDTO> GetPurgeTableList(string str)
        //{
        //    using (var conn = (SqlConnection)base.S0VPITEM_Connection)
        //    {
        //        conn.Open();
        //        IEnumerable<ItemFormPurgeTableListDTO> _listTable = conn.Query<ItemFormPurgeTableListDTO>(str);
        //        return _listTable;
        //    }
        //}
        public async Task<IEnumerable<int>> GetAutoPurgeCandidates(string str, string dbName)
        {
            List<int> Offers = new List<int>();
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<int>(str));
                               
            }
        }

        //public List<int> GetAutoPurgeCandidates(string str, string dbName)
        //{
        //    List<int> Offers = new List<int>();
        //    using (var conn = (SqlConnection)base.S0VPITEM_Connection)
        //    {
        //        conn.Open();
        //        Offers = conn.Query<int>(str).ToList();
        //        return Offers;
        //    }
        //}

        public bool PurgeCostOffer(string str, string dbName)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
               conn.Open();
               conn.Execute(str);
               return true;
            }
        }
    }
}







