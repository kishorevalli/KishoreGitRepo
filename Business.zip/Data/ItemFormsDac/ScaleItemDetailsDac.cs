﻿using Dapper;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class ScaleItemDetailsDac : BaseDac, IScaleItemDetailsDac
    {
        public async Task<bool> IsScaleItemDetailsExist(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var count = await conn.ExecuteScalarAsync<int>(GetScaleInfoCountSql, new { ItemFormID = itemFormId });
                return count > 0 ? true : false;
            }
        }

        public async Task InsertScaleInfo(ScaleInfoDto scaleInfoDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleInfoSql, scaleInfoDto); 
            }
        }

        public async Task InsertScaleOverrideDescription(ScaleOverrideDescriptionDto scaleOverrideDto, int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleOverrideDescriptionSql, scaleOverrideDto);
            }
        }

        public async Task InsertScaleOverrideDescriptionAudit(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleOverrideDescriptionAuditSql, new { @ItemFormId = itemFormId });
            }
        }

        public async Task<List<ScaleOverrideDescriptionDto>> GetScaleOverrideDescription(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var ScaleOverrideInfo = await conn.QueryAsync<ScaleOverrideDescriptionDto>(GetScaleOverrideDescriptionSql, new { @ItemFormId = itemFormId });
                return ScaleOverrideInfo.ToList();
            }
        }

        public async Task InsertScaleLocation(ScaleLocationDto scaleLocationDto, int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleLocationSql, scaleLocationDto);
            }
        }
        public async Task InsertScaleLocationAudit(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleLocationAuditSql, new { @ItemFormId = itemFormId });
            }
        }

        public async Task<List<ScaleLocationDto>> GetScaleLocations(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var ScaleLocationList = await conn.QueryAsync<ScaleLocationDto>(GetScaleLocationSql, new { @ItemFormId = itemFormId });
                return ScaleLocationList.ToList();
            }
        }
        
        public async Task InsertScaleShelfLife(ScaleShelfLifeDto scaleShelfLifeDto, int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleShelfLifeSql, scaleShelfLifeDto);
            }
        }
        public async Task InsertScaleShelfLifeAudit(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleShelfLifeAuditSql, new { @ItemFormId = itemFormId });
            }
        }
        public async Task<List<ScaleShelfLifeDto>> GetScaleShelfLife(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var ScaleShelfLifeList = await conn.QueryAsync<ScaleShelfLifeDto>(GetScaleShelfLifeSql, new { @ItemFormId = itemFormId });
                return ScaleShelfLifeList.ToList();
            }
        }
        
        public async Task InsertScaleGrade(ScaleGradeDto scaleGradeDto, int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleGradeSql, scaleGradeDto);
            }
        }
        public async Task InsertScaleGradeAudit(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleGradeAuditSql, new { @ItemFormId = itemFormId });
            }
        }
        public async Task<List<ScaleGradeDto>> GetScaleGrade(int itemFormId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var ScaleGradeList = await conn.QueryAsync<ScaleGradeDto>(GetScaleGradeSql, new { @ItemFormId = itemFormId });
                return ScaleGradeList.ToList();
            }
        }

        public async Task<ScaleInfoDto> GetScaleInfo(int itemFormId)
        {
            ScaleInfoDto dto = new ScaleInfoDto();
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                var ScaleInfo = await conn.QueryAsync<ScaleInfoDto>(GetScaleInfoSql, new { @ItemFormID = itemFormId });
                dto = ScaleInfo.ToList().FirstOrDefault();
                if(dto != null)
                {
                    dto.ScaleOverrideDescriptionList = await GetScaleOverrideDescription(itemFormId);
                    dto.ScaleLocationList = await GetScaleLocations(itemFormId);
                    dto.ScaleShelfLifeList = await GetScaleShelfLife(itemFormId);
                    dto.ScaleGradeList = await GetScaleGrade(itemFormId);
                }
                return dto;
            }
        }

        public async Task UpdateScaleInfo(ScaleInfoDto scaleInfoDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertScaleInfoAuditSql, scaleInfoDto);
                await conn.ExecuteAsync(UpdateScaleInfoSql, scaleInfoDto);
            }
        }

        

        private const string GetScaleInfoCountSql = @"Select count(*) from ScaleInfo where ItemFormID = @ItemFormID";
        private const string GetScaleInfoSql = @"SELECT
                                                   si.ItemFormID
                                                   ,si.BackroomScaleIndicator
                                                   ,LTRIM(RTRIM(si.ScaleDescription1)) AS ScaleDescription1
                                                   ,LTRIM(RTRIM(si.ScaleDescription2)) AS ScaleDescription2
                                                   ,si.CalorieInformation
                                                   ,si.Tare
                                                   ,si.ScaleExtraTextRequired
                                                   ,si.PriceModifier
                                                   ,si.NutritionCodeRequired
                                                   ,si.CreatedBy
                                                   ,si.CreatedDate
                                                   ,si.LastUpdatedBy
                                                   ,si.LastUpdatedDate
                                                   FROM ScaleInfo si
                                                   inner join ItemForm ifm ON si.ItemFormID = ifm.id
                                                   WHERE si.ItemFormID = @ItemFormID";
        private const string InsertScaleInfoAuditSql = @"Insert into ScaleInfoAudit([Version]
                                                         ,ItemFormID
                                                         ,BackroomScaleIndicator
                                                         ,ScaleDescription1
                                                         ,ScaleDescription2
                                                         ,CalorieInformation
                                                         ,Tare
                                                         ,ScaleExtraTextRequired
                                                         ,PriceModifier
                                                         ,NutritionCodeRequired
                                                         ,CreatedBy
                                                         ,CreatedDate
                                                         ,LastUpdatedBy
                                                         ,LastUpdatedDate)
                                                         SELECT
                                                         GETDATE()
                                                         ,ItemFormID
                                                         ,BackroomScaleIndicator
                                                         ,ScaleDescription1
                                                         ,ScaleDescription2
                                                         ,CalorieInformation
                                                         ,Tare
                                                         ,ScaleExtraTextRequired
                                                         ,PriceModifier
                                                         ,NutritionCodeRequired
                                                         ,CreatedBy
                                                         ,CreatedDate
                                                         ,LastUpdatedBy
                                                         ,LastUpdatedDate
                                                         FROM ScaleInfo 
                                                         WHERE ItemFormID = @ItemFormID
                                                         ";
        private const string UpdateScaleInfoSql = @"Update ScaleInfo Set
                                                         BackroomScaleIndicator = @BackroomScaleIndicator
                                                         ,ScaleDescription1=@ScaleDescription1
                                                         ,ScaleDescription2=@ScaleDescription2
                                                         ,CalorieInformation=@CalorieInformation
                                                         ,Tare=@Tare
                                                         ,ScaleExtraTextRequired=@ScaleExtraTextRequired
                                                         ,PriceModifier=@PriceModifier
                                                         ,NutritionCodeRequired=@NutritionCodeRequired
                                                         ,LastUpdatedBy=@LastUpdatedBy
                                                         ,LastUpdatedDate=GETDATE()
                                                         WHERE ItemFormID = @ItemFormID
                                                         ";
        private const string InsertScaleInfoSql = @"INSERT INTO dbo.ScaleInfo(
                                                    [ItemFormID]
                                                   ,[BackroomScaleIndicator]
                                                   ,[ScaleDescription1]
                                                   ,[ScaleDescription2]
                                                   ,[CalorieInformation]
                                                   ,[Tare]
                                                   ,[ScaleExtraTextRequired]
                                                   ,[PriceModifier]
                                                   ,[NutritionCodeRequired]
                                                   ,[CreatedBy]
                                                   ,[CreatedDate]
                                                   ,[LastUpdatedBy]
                                                   ,[LastUpdatedDate])
                                                   Values(
                                                    @ItemFormID
                                                   ,@BackroomScaleIndicator
                                                   ,@ScaleDescription1
                                                   ,@ScaleDescription2
                                                   ,@CalorieInformation
                                                   ,@Tare
                                                   ,@ScaleExtraTextRequired
                                                   ,@PriceModifier
                                                   ,@NutritionCodeRequired
                                                   ,@CreatedBy
                                                   ,GETDATE()
                                                   ,@LastUpdatedBy
                                                   ,GETDATE())";

        private const string InsertScaleOverrideDescriptionSql = @"INSERT INTO dbo.ScaleOverrideDescription(
                                                    ItemFormID
                                                    ,FacilityGroupType
                                                    ,FacilityGroupTypeDescription
                                                    ,FacilityGroupCode
                                                    ,FacilityGroupDescription
                                                    ,OverrideDescriptionLine1
                                                    ,OverrideDescriptionLine2
                                                    ,CreatedBy
                                                    ,CreatedDate
                                                    ,LastUpdatedBy
                                                    ,LastUpdatedDate)
                                                    Values(
                                                    @ItemFormID
                                                    ,@FacilityGroupType
                                                    ,@FacilityGroupTypeDescription
                                                    ,@FacilityGroupCode
                                                    ,@FacilityGroupDescription
                                                    ,@OverrideDescriptionLine1
                                                    ,@OverrideDescriptionLine2
                                                    ,@CreatedBy
                                                    ,GETDATE()
                                                    ,@LastUpdatedBy
                                                    ,GETDATE())
                                                    ";
        private const string InsertScaleOverrideDescriptionAuditSql = @"Insert Into dbo.ScaleOverrideDescriptionAudit(
                                                                      [Version]
                                                                      ,ItemFormID
                                                                      ,FacilityGroupType
                                                                      ,FacilityGroupTypeDescription
                                                                      ,FacilityGroupCode
                                                                      ,FacilityGroupDescription
                                                                      ,OverrideDescriptionLine1
                                                                      ,OverrideDescriptionLine2
                                                                      ,CreatedBy
                                                                      ,CreatedDate
                                                                      ,LastUpdatedBy
                                                                      ,LastUpdatedDate)
                                                                      Select GETDATE()
                                                                      ,ItemFormID
                                                                      ,FacilityGroupType
                                                                      ,FacilityGroupTypeDescription
                                                                      ,FacilityGroupCode
                                                                      ,FacilityGroupDescription
                                                                      ,OverrideDescriptionLine1
                                                                      ,OverrideDescriptionLine2
                                                                      ,CreatedBy
                                                                      ,CreatedDate
                                                                      ,LastUpdatedBy
                                                                      ,LastUpdatedDate FROM dbo.ScaleOverrideDescription where ItemFormID = @ItemFormId
                                                                      
                                                                      Delete From dbo.ScaleOverrideDescription where ItemFormID = @ItemFormId";
        private const string InsertScaleLocationSql = @"INSERT INTO dbo.ScaleLocation(
                                                    ItemFormID
                                                    ,ScaleLocation
                                                    ,ScaleLocationDescription
                                                    ,Action
                                                    ,ActionDescription
                                                    ,PLUNumber
                                                    ,CreatedBy
                                                    ,CreatedDate
                                                    ,LastUpdatedBy
                                                    ,LastUpdatedDate)
                                                    Values(
                                                    @ItemFormID
                                                    ,@ScaleLocation
                                                    ,@ScaleLocationDescription
                                                    ,@Action
                                                    ,@ActionDescription
                                                    ,@PLUNumber
                                                    ,@CreatedBy
                                                    ,GETDATE()
                                                    ,@LastUpdatedBy
                                                    ,GETDATE())";

        private const string InsertScaleLocationAuditSql = @"Insert Into dbo.ScaleLocationAudit(
                                                           [Version]
                                                           ,ItemFormID
                                                           ,ScaleLocation
                                                           ,ScaleLocationDescription
                                                           ,[Action]
                                                           ,ActionDescription
                                                           ,PLUNumber
                                                           ,CreatedBy
                                                           ,CreatedDate
                                                           ,LastUpdatedBy
                                                           ,LastUpdatedDate)
                                                           Select GETDATE()
                                                           ,ItemFormID
                                                           ,ScaleLocation
                                                           ,ScaleLocationDescription
                                                           ,[Action]
                                                           ,ActionDescription
                                                           ,PLUNumber
                                                           ,CreatedBy
                                                           ,CreatedDate
                                                           ,LastUpdatedBy
                                                           ,LastUpdatedDate FROM dbo.ScaleLocation where ItemFormID = @ItemFormId
                                                           
                                                           Delete From dbo.ScaleLocation where ItemFormID = @ItemFormId";

        private const string InsertScaleShelfLifeSql = @"INSERT INTO dbo.ScaleShelfLife(
                                                    ItemFormID
                                                    ,FacilityGroupType
                                                    ,FacilityGroupTypeDescription
                                                    ,FacilityGroupCode
                                                    ,FacilityGroupDescription
                                                    ,ShelfLifeDay
                                                    ,CreatedBy
                                                    ,CreatedDate
                                                    ,LastUpdatedBy
                                                    ,LastUpdatedDate)
                                                    Values(
                                                    @ItemFormID
                                                    ,@FacilityGroupType
                                                    ,@FacilityGroupTypeDescription
                                                    ,@FacilityGroupCode
                                                    ,@FacilityGroupDescription
                                                    ,@ShelfLifeDay
                                                    ,@CreatedBy
                                                    ,GETDATE()
                                                    ,@LastUpdatedBy
                                                    ,GETDATE())";

        private const string InsertScaleShelfLifeAuditSql = @"Insert Into dbo.ScaleShelfLifeAudit(
                                                            [Version]
                                                            ,ItemFormID
                                                            ,FacilityGroupType
                                                            ,FacilityGroupTypeDescription
                                                            ,FacilityGroupCode
                                                            ,FacilityGroupDescription
                                                            ,ShelfLifeDay
                                                            ,CreatedBy
                                                            ,CreatedDate
                                                            ,LastUpdatedBy
                                                            ,LastUpdatedDate)
                                                            Select GETDATE()
                                                            ,ItemFormID
                                                            ,FacilityGroupType
                                                            ,FacilityGroupTypeDescription
                                                            ,FacilityGroupCode
                                                            ,FacilityGroupDescription
                                                            ,ShelfLifeDay
                                                            ,CreatedBy
                                                            ,CreatedDate
                                                            ,LastUpdatedBy
                                                            ,LastUpdatedDate FROM dbo.ScaleShelfLife where ItemFormID = @ItemFormId

                                                            Delete From dbo.ScaleShelfLife where ItemFormID = @ItemFormId";

        private const string InsertScaleGradeSql = @"INSERT INTO dbo.ScaleGrade(
                                                    ItemFormID
                                                    ,FacilityGroupType
                                                    ,FacilityGroupTypeDescription
                                                    ,FacilityGroupCode
                                                    ,FacilityGroupDescription
                                                    ,Grade
                                                    ,GradeDescription
                                                    ,CreatedBy
                                                    ,CreatedDate
                                                    ,LastUpdatedBy
                                                    ,LastUpdatedDate)
                                                    Values(
                                                    @ItemFormID
                                                    ,@FacilityGroupType
                                                    ,@FacilityGroupTypeDescription
                                                    ,@FacilityGroupCode
                                                    ,@FacilityGroupDescription
                                                    ,@Grade
                                                    ,@GradeDescription
                                                    ,@CreatedBy
                                                    ,GETDATE()
                                                    ,@LastUpdatedBy
                                                    ,GETDATE())";

        private const string InsertScaleGradeAuditSql = @"Insert Into dbo.ScaleGradeAudit(
                                                        [Version]
                                                        ,ItemFormID
                                                        ,FacilityGroupType
                                                        ,FacilityGroupTypeDescription
                                                        ,FacilityGroupCode
                                                        ,FacilityGroupDescription
                                                        ,Grade
                                                        ,GradeDescription
                                                        ,CreatedBy
                                                        ,CreatedDate
                                                        ,LastUpdatedBy
                                                        ,LastUpdatedDate)
                                                        Select GETDATE()
                                                        ,ItemFormID
                                                        ,FacilityGroupType
                                                        ,FacilityGroupTypeDescription
                                                        ,FacilityGroupCode
                                                        ,FacilityGroupDescription
                                                        ,Grade
                                                        ,GradeDescription
                                                        ,CreatedBy
                                                        ,CreatedDate
                                                        ,LastUpdatedBy
                                                        ,LastUpdatedDate FROM dbo.ScaleGrade where ItemFormID = @ItemFormId
                                                        
                                                        Delete From dbo.ScaleGrade where ItemFormID = @ItemFormId";

        private const string GetScaleOverrideDescriptionSql = @" SELECT ID
                                                                 ,ItemFormID
                                                                 ,FacilityGroupType
                                                                 ,FacilityGroupTypeDescription
                                                                 ,FacilityGroupCode
                                                                 ,FacilityGroupDescription
                                                                 ,OverrideDescriptionLine1
                                                                 ,OverrideDescriptionLine2
                                                                 ,CreatedBy
                                                                 ,CreatedDate
                                                                 ,LastUpdatedBy
                                                                 ,LastUpdatedDate 
                                                                 FROM ScaleOverrideDescription WHERE ItemFormID = @itemFormId";

        private const string GetScaleLocationSql = @"SELECT ID
                                                     ,ItemFormID
                                                     ,ScaleLocation
                                                     ,ScaleLocationDescription
                                                     ,Action
                                                     ,ActionDescription
                                                     ,PLUNumber
                                                     ,CreatedBy
                                                     ,CreatedDate
                                                     ,LastUpdatedBy
                                                     ,LastUpdatedDate 
                                                     FROM ScaleLocation WHERE ItemFormID = @itemFormId";
        private const string GetScaleShelfLifeSql = @"SELECT ID
                                                     ,ItemFormID
                                                     ,FacilityGroupType
                                                     ,FacilityGroupTypeDescription
                                                     ,FacilityGroupCode
                                                     ,FacilityGroupDescription
                                                     ,ShelfLifeDay
                                                     ,CreatedBy
                                                     ,CreatedDate
                                                     ,LastUpdatedBy
                                                     ,LastUpdatedDate
                                                     FROM ScaleShelfLife WHERE ItemFormID = @itemFormId";
        private const string GetScaleGradeSql = @"SELECT ID
                                                  ,ItemFormID
                                                  ,FacilityGroupType
                                                  ,FacilityGroupTypeDescription
                                                  ,FacilityGroupCode
                                                  ,FacilityGroupDescription
                                                  ,Grade
                                                  ,GradeDescription
                                                  ,CreatedBy
                                                  ,CreatedDate
                                                  ,LastUpdatedBy
                                                  ,LastUpdatedDate
                                                  FROM ScaleGrade WHERE ItemFormID = @itemFormId";
    }
}
