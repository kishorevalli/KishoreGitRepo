﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Publix.S0VPITEM.ItemFormsEntities;
using Publix.S0VPITEM.ItemFormsDac.Contracts;

namespace Publix.S0VPITEM.ItemFormsDac
{
   
    public class WorkFlowDac : BaseDac,IWorkFlowDac
    {
        
        public async Task<IEnumerable<FormUserPermittedActionDto>> GetFormUserPermittedAction(UserType currentUserType, int FormCurrentStatusID , int formTypeID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                 conn.Open();
                IEnumerable<FormUserPermittedActionDto> actions = conn.Query<FormUserPermittedActionDto>(GetFormUserPermittedActionsQuery(currentUserType, FormCurrentStatusID, formTypeID));
                return await Task.FromResult(actions);        
            }
        }


        private string GetFormUserPermittedActionsQuery(UserType currentUserType, int FormCurrentStatusID , int formTypeID,bool IsDashboard = false)
        {
            string baseFUPAQuery = baseGetFormUserPermittedActionsSQL;

            switch (currentUserType)
            {
                case UserType.Vendor:
                    baseFUPAQuery = baseFUPAQuery + "FUPA.UserTypeId = 1 AND FUPA.IsActive = 1";
                    break;                  
                case UserType.Buyer:
                    baseFUPAQuery = baseFUPAQuery + "FUPA.UserTypeId = 2 AND FUPA.IsActive = 1";
                    break;
                case UserType.Clerical:
                    baseFUPAQuery = baseFUPAQuery + "FUPA.UserTypeId = 3 AND FUPA.IsActive = 1";
                    break;
                case UserType.MfgClerical:
                    baseFUPAQuery = baseFUPAQuery + "FUPA.UserTypeId = 4 AND FUPA.IsActive = 1";
                    break;
                case UserType.MfgBDD:
                    baseFUPAQuery = baseFUPAQuery + "FUPA.UserTypeId = 5 AND FUPA.IsActive = 1";
                    break;
                case UserType.ALL:
                    baseFUPAQuery = baseFUPAQuery + "FUPA.UserTypeId = 0 AND FUPA.IsActive = 0";
                    break;
            }
            if (IsDashboard)
                baseFUPAQuery = baseFUPAQuery + "AND FormAction.ID <> 2";
            else
                baseFUPAQuery = baseFUPAQuery + "AND FormAction.ID <> 1";

            if (FormCurrentStatusID == 0)
                baseFUPAQuery = baseFUPAQuery + " AND CurrentFormStatusID = CurrentFormStatusID";
            else
                baseFUPAQuery = baseFUPAQuery + " AND CurrentFormStatusID = " + FormCurrentStatusID;

            if (formTypeID != 0)
                baseFUPAQuery = baseFUPAQuery + " AND FormTypeId =" +  formTypeID + ";";

            return baseFUPAQuery;
        }

        public int ValidateItemFormByVendors(int ItemFormID, string LoggedInVendorList)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                try
                {
                    conn.Open();
                    return (conn.Query<int>(ValidateItemFormByVendorsSQL, new { @ItemFormID = ItemFormID, @LoggedInVendorList = LoggedInVendorList })).FirstOrDefault();
                }
                catch (Exception e)
                {

                    throw;
                }

            }
        }

        #region "Query"

        private const string baseGetFormUserPermittedActionsSQL = @" SELECT 
                                                                    FUPA.FormTypeId,
                                                                    CurrentFormStatusID,
                                                                    CurrentFormStatus.Name as CurrentFormStatus ,
                                                                    FormActionID,
                                                                    FormAction.Name as ActionName,
                                                                    BuyerActionName,
                                                                    VendorActionName,
                                                                    ISNULL(CreatedFormStatusID, CurrentFormStatusID) as CreatedFormStatusID,
                                                                    CreatedFormStatus.Name as CreatedFormStatus,
                                                                    FormAction.Comment as ActionComment,
                                                                    CurrentFormStatus.Comment as CurrentFormStatusComment,
                                                                    CreatedFormStatus.Comment as CreatedFormStatusComment
                                                                    FROM FormUserPermittedAction FUPA 
                                                                    INNER JOIN FormAction 
                                                                    ON FormAction.ID = FUPA.FormActionID
                                                                    INNER JOIN FormStatus as CurrentFormStatus ON CurrentFormStatus.ID = FUPA.CurrentFormStatusID
                                                                    LEFT JOIN FormStatus as CreatedFormStatus ON CreatedFormStatus.ID = FormAction.CreatedFormStatusID
                                                                    WHERE  ";

        private const string ValidateItemFormByVendorsSQL = @";WITH ItemFormVendorsCTE
	                                                            AS
	                                                            (
	                                                            SELECT VendorNumber from [dbo].[PackagingHierarchy]
	                                                            INNER JOIN [OrderablePackLevel] ON PackagingHierarchy.ID = OrderablePackLevel.PackagingHierarchyID WHERE PackagingHierarchy.ItemFormID = @ItemFormID
	                                                            UNION
	                                                            SELECT VendorNumber FROM DSDAuthRequestStore WHERE DSDAuthRequestStore.ItemFormID = @ItemFormID	                                                           
	                                                            ) 
	                                                            SELECT TOP 1 VendorNumber FROM ItemFormVendorsCTE WHERE VendorNumber NOT IN (SELECT id FROM CSVToTable(@LoggedInVendorList)) AND EXISTS(SELECT * FROM ItemFormVendorsCTE);";

        #endregion

    }
}
