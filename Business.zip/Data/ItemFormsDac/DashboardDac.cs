﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System.Data.SqlClient;
using Publix.S0VPITEM.ItemFormsEntities;
using Dapper;

namespace Publix.S0VPITEM.ItemFormsDac
{
   public class DashboardDac : BaseDac, IDashboardDac
    {

        public string AttachSearchFiterList(DashboardSearchCriteriaDto dashboardSearchCriteriaDto,UserType user)
        {          
                string filterSQL = string.Empty;

        

            if (dashboardSearchCriteriaDto.SearchItemCode != 0)            
                filterSQL += VendorItemCodeFilterSQL;
            
                if (!string.IsNullOrEmpty(dashboardSearchCriteriaDto.FormattedGtin))                
                filterSQL += GTINFilterSQL;
                
                if (!string.IsNullOrEmpty(dashboardSearchCriteriaDto.SearchItemDescription))                
                filterSQL += VendorItemDescriptionFilterSQL;
                
                if (dashboardSearchCriteriaDto.SearchSubmittedFromDate != DateTime.MinValue && dashboardSearchCriteriaDto.SearchSubmittedToDate != DateTime.MinValue)                
                filterSQL += SubmissionDateFilterSQL;
                
                if (dashboardSearchCriteriaDto.CompressedUPC != 0)                
                filterSQL += CompressedUPCFilterSQL;
                
                if (dashboardSearchCriteriaDto.PriceLookupCode != 0)                
                filterSQL += PriceLookupCodeFilterSQL;
            

                if (dashboardSearchCriteriaDto.SearchFormId != 0) {
                string strSearchFormId = dashboardSearchCriteriaDto.SearchFormId.ToString();
                if (strSearchFormId.Length == 12)                    
                   filterSQL += ExactItemFormDisplayIDFilterSQL;
                else
                    filterSQL += ItemFormDisplayIDFilterSQL;
            }  

            if (!string.IsNullOrEmpty(dashboardSearchCriteriaDto.SearchFormStatusId))                      
                filterSQL += FormStatusIDFilterSQL;

            //if (!string.IsNullOrEmpty(dashboardSearchCriteriaDto.viewItemFormsForUserID))
            //    filterSQL += SpecificViewItemFormsForUserIDFilterSQL;
            if (user == UserType.Vendor)
            {
                if (!string.IsNullOrEmpty(dashboardSearchCriteriaDto.VendorContactID))
                    filterSQL += SpecificViewItemFormsForUserIDFilterSQL;

                if (dashboardSearchCriteriaDto.IncludeVSARelatedForm)
                    filterSQL += VSAAndRelatedFormsFilter;
                else
                    filterSQL += AnyUserWithoutVSARelatedFormsFilter;
            }
            else {
                if (dashboardSearchCriteriaDto.BuyerID !=0)
                    filterSQL += SpecificViewItemFormsForUserIDFilterInternalSQL;
            }

            if (!string.IsNullOrEmpty(dashboardSearchCriteriaDto.finalVendorList))
            {
                if (dashboardSearchCriteriaDto.finalVendorList.Trim().Length != 0)
                    filterSQL += VendorListFilterSQL;
            }



            return filterSQL;
        }


        public async Task<IEnumerable<DashboardItemFormDto>> GetItemFormListBySearchCriteria(DashboardSearchCriteriaDto dashboardSearchCriteriaDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                string searchCriteriaSQL = GetItemFormListBySearchCriteriaBaseSQL + AttachSearchFiterList(dashboardSearchCriteriaDto,UserType.Vendor) + " ORDER BY BID.ItemFormID DESC ";
                return (await conn.QueryAsync<DashboardItemFormDto>(searchCriteriaSQL, dashboardSearchCriteriaDto));
            }
        }


        public async Task<IEnumerable<DashboardItemFormDto>> GetItemFormListBySearchCriteriaInternalUser(DashboardSearchCriteriaDto dashboardSearchCriteriaDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                 conn.Open();

                //await conn.ExecuteAsync(UpdateItemFormActionAndCurrentStatusAuditSQL, new { ItemFormID = formActionStatusDto.ItemFormID });
                 conn.Execute(CreateBuyerDashboardTableTempSQL);
                string searchCriteriaSQL = InsertItemFormForSearchCriteriaBuyerBaseSQL + AttachSearchFiterList(dashboardSearchCriteriaDto,UserType.Buyer) + " ORDER BY ItemForm.GROUPID,BID.GTIN ";
                 conn.Execute(searchCriteriaSQL, dashboardSearchCriteriaDto);
                if (dashboardSearchCriteriaDto.SearchFormStatusId == null)
                    dashboardSearchCriteriaDto.SearchFormStatusId = "0";


                return conn.QueryAsync<DashboardItemFormDto>(GetBuyerItemFormForSearchCriteriaSQL, new { IncludeGroupedItemForm = 1, FormStatusID = dashboardSearchCriteriaDto.SearchFormStatusId, BuyerID = dashboardSearchCriteriaDto.BuyerID }).Result.ToList();
               
            }
        }
       

        public async Task<IEnumerable<DashboardStatusDto>> GetDashboardStatus(LoggedInUserDto loggedInUser)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {                
                await conn.OpenAsync();
                int Usertype = Convert.ToInt32(loggedInUser.LoggedInUserTypeID);               
                
                return await conn.QueryAsync<DashboardStatusDto>(GetDashboardStatusSQL, new { LoggedInUserID = loggedInUser.LoggedInUserID, LoggedInUserTypeID = Usertype });
            }
        }



        public async Task<int> GetDashboardStatusCount(DashboardStatusDto dashboardStatusDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                //int r = 0;
                //try
                //{
                //    conn.Open();
                //    r = conn.QueryFirstOrDefault<int>(GetDashboardStatusCountSQL, new { DashboardStatusNameId = dashboardStatusDto.DashboardStatusNameId, ViewForUserId = dashboardStatusDto.VendorContactID, IncludeVSARelatedFormsInput = 1 });
                //}
                //catch (Exception e )
                //{
                //    string s = "sd";
                //    //throw;
                //}
                //return r;
                return (await conn.QueryAsync<int>(GetDashboardStatusCountSQL, new { DashboardStatusNameId = dashboardStatusDto.DashboardStatusNameId, ViewForUserId  = dashboardStatusDto.VendorContactID, IncludeVSARelatedFormsInput = dashboardStatusDto.IsIncludeRelatedFromChecked })).FirstOrDefault();
            }
        }

        public async Task<int> GetDashboardStatusCountInternal(DashboardStatusDto dashboardStatusDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<int>(GetDashboardStatusCountInternalSQL, new { DashboardStatusNameId = dashboardStatusDto.DashboardStatusNameId, viewItemFormsForUserID = dashboardStatusDto.BuyerID })).FirstOrDefault();
            }
        }

        //

        public int ValidateItemFormByVendors(int ItemFormID,string LoggedInVendorList)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                try
                {
                     conn.Open();
                    return (conn.Query<int>(ValidateItemFormByVendorsSQL, new { @ItemFormID = ItemFormID, @LoggedInVendorList = LoggedInVendorList })).FirstOrDefault();
                }
                catch (Exception e)
                {

                    throw;
                }
               
            }
        }

        //ValidateItemFormByVendorsSQL

        public async Task<IEnumerable<DashboardItemFormDto>> GetDashboardStatusDetail(DashboardStatusDto dashboardStatusDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {                
                    conn.Open();
                    IEnumerable<DashboardItemFormDto> statusDetailList = conn.Query<DashboardItemFormDto>(GetDashboardStatusDetailSQL, new { DashboardStatusNameId = dashboardStatusDto.DashboardStatusNameId, @ViewForUserId = dashboardStatusDto.VendorContactID, @IncludeVSARelatedFormsInput = dashboardStatusDto.IncludeVSARelatedForm });
                    return statusDetailList;
                    //await conn.OpenAsync();
                    //return (await conn.QueryAsync<DashboardItemFormDto>(GetDashboardStatusDetailSQL, new { DashboardStatusNameId = dashboardStatusDto.DashboardStatusNameId, @ViewForUserId = dashboardStatusDto.UserID }));                
            }
        }

        public async Task<IEnumerable<DashboardItemFormDto>> GetDashboardStatusDetailInternal(DashboardStatusDto dashboardStatusDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                 conn.Open();
                 conn.Execute(CreateBuyerDashboardTableTempSQL);
                
                 conn.Execute(GetDashboardStatusDetailInternalSQL, new { DashboardStatusNameId = dashboardStatusDto.DashboardStatusNameId, viewItemFormsForUserID = dashboardStatusDto.BuyerID });
                return conn.Query<DashboardItemFormDto>(GetBuyerStatusDetailSQL, new { FormStatusID = dashboardStatusDto.StatusID, viewItemFormsForUserID = dashboardStatusDto.BuyerID }).ToList();                
               
            }
        }

        //GetDashboardFormStatusForVendorSQL

        public async Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForVendor()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<DashboardFormStatusDto>(GetDashboardFormStatusForVendorSQL));
            }
        }

        public async Task<IEnumerable<DashboardFormStatusDto>> GetDashboardFormStatusForBuyer(int LoggedInUserTypeID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<DashboardFormStatusDto>(GetDashboardFormStatusForBuyerSQL, new { UserTypeID = LoggedInUserTypeID }));
            }
        }



        public async Task<bool> UpdateItemFormActionAndCurrentStatus(FormUserPermittedActionDto formUserPermittedAction)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
               
                await conn.ExecuteAsync(UpdateItemFormActionAndCurrentStatusAuditSQL, new { ItemFormID = formUserPermittedAction.ItemFormID });
                await conn.ExecuteAsync(UpdateItemFormActionAndCurrentStatusSQL, new {FormActionID = formUserPermittedAction.FormActionID, ItemFormID = formUserPermittedAction.ItemFormID,LastUpdatedBy = formUserPermittedAction.LastUpdatedBy
                });
                return true;
            }
        }

        public async Task<bool> UpdateItemFormStatusForInternalUser(FormUserPermittedActionDto formUserPermittedAction)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                await conn.ExecuteAsync(UpdateItemFormStatusForInternalUserAuditSQL, new { ItemFormID = formUserPermittedAction.ItemFormID });
                await conn.ExecuteAsync(UpdateItemFormStatusForInternalUserSQL, new
                {
                    FormActionID = formUserPermittedAction.FormActionID,
                    ItemFormID = formUserPermittedAction.ItemFormID,
                    LastUpdatedBy = formUserPermittedAction.LastUpdatedBy
                });
                return true;
            }
        }

        public bool UpdateVSARelatedForm(string VSALoginUserID, string VendorList)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                conn.Open();
                conn.Execute(UpdateVSARelatedFormSQL, new { @VSALoginUserID = VSALoginUserID, @VendorList = VendorList });                
                return true;
            }
        }

        public async Task<bool> InsertDashboardUserSelection(DashboardUserSelectionDto dashboardUserSelectionDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(InsertDashboardUserSelectionSQL, dashboardUserSelectionDto);               
                return true;
            }
        }

        public async Task<bool> UpdateReassignVendorContact(ViewForUserListDto vendorContact)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(UpdateReassignVendorContactSQL, vendorContact);
                return true;
            }
        }

        //UpdateReaasignVendorContactSQL

        public async Task<DashboardUserSelectionDto> GetDashboardUserSelection(string LoggedInUserID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryFirstOrDefaultAsync<DashboardUserSelectionDto>(GetDashboardUserSelectionSQL, new { @LoggedInUserID = LoggedInUserID }));
            }
        }

        //UpdateVSARelatedFormSQL

        //TODO Remove
        public async Task<IEnumerable<ItemFormDto>> GetItemForms(string userId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {

                await conn.OpenAsync();
                IEnumerable<ItemFormDto> itemForms = await conn.QueryAsync<ItemFormDto>(GetItemFormsSQL, new { @userId = userId });

                return itemForms;
            }
        }

        public async Task<bool> IsParentFlagSetForGTINTree(string userId)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                // TO DO work the logic
                await conn.OpenAsync();
                IEnumerable<ItemFormDto> itemForms = await conn.QueryAsync<ItemFormDto>(GetItemFormsSQL, new { @userId = userId });

                return true;
            }
        }

        public async Task<string> GetParentStatusForGTIN(decimal GTIN)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {                
                await conn.OpenAsync();
                return await conn.QueryFirstOrDefaultAsync<string>(GetParentStatusForGTINSQL, new { @GTIN = GTIN });                
            }
        }

        public async Task<IEnumerable<ErrorDTO>> GetDashboardErrorMessageList(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {           
                await conn.OpenAsync();
                return await conn.QueryAsync<ErrorDTO>(GetDashboardErrorMessageListSQL, new { @ItemFormID = ItemFormID });             
            }
        }

        

        public async Task<IEnumerable<DashboardItemFormDto>> RemoveItemFormFromGroup(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                 conn.Open();
                conn.Execute(CreateBuyerItemFormForGTINTempTableSQL, new { @ItemFormID = ItemFormID });
                conn.Execute(LoadBuyerItemFormForGTINTempTableSQL, new { @ItemFormID = ItemFormID });
                 conn.Execute(UnGroupingItemFormSQL, new { @ItemFormID = ItemFormID });
                 conn.Execute(GetGroupedItemFormForGTINSQL);
                return await Task.FromResult(conn.Query<DashboardItemFormDto>(GetGroupedItemFormForGTINSQL));
            }
        }

        public async Task<IEnumerable<DashboardItemFormDto>> AddItemFormToGroup(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                 conn.Open();
                 conn.Execute(CreateBuyerItemFormForGTINTempTableSQL, new { @ItemFormID = ItemFormID });
                 conn.Execute(LoadBuyerItemFormForGTINTempTableSQL, new { @ItemFormID = ItemFormID });
                 conn.Execute(GroupingItemFormSQL, new { @ItemFormID = ItemFormID });
                 conn.Execute(GetGroupedItemFormForGTINSQL);
                return await Task.FromResult(conn.Query<DashboardItemFormDto>(GetGroupedItemFormForGTINSQL));                
            }
        }

        public async Task<IEnumerable<DashboardItemFormDto>> ParentingItemForm(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                conn.Open();
                conn.Execute(CreateBuyerItemFormForGTINTempTableSQL, new { @ItemFormID = ItemFormID });
                conn.Execute(LoadBuyerItemFormForGTINTempTableSQL, new { @ItemFormID = ItemFormID });
                conn.Execute(ParentingItemFormSQL, new { @ItemFormID = ItemFormID });
                conn.Execute(GetGroupedItemFormForGTINSQL);
                return await Task.FromResult(conn.Query<DashboardItemFormDto>(GetGroupedItemFormForGTINSQL));
               
            }
        }

        public async Task<IEnumerable<DashboardItemFormDto>> UnParentingItemForm(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                conn.Open();
                conn.Execute(CreateBuyerItemFormForGTINTempTableSQL, new { @ItemFormID = ItemFormID });
                conn.Execute(LoadBuyerItemFormForGTINTempTableSQL, new { @ItemFormID = ItemFormID });
                conn.Execute(UnParentingItemFormSQL, new { @ItemFormID = ItemFormID });
                conn.Execute(GetGroupedItemFormForGTINSQL);
                return await Task.FromResult(conn.Query<DashboardItemFormDto>(GetGroupedItemFormForGTINSQL));

            }
        }

        public async Task<bool> ChangeVendorSubmittedFormToReview(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await  conn.ExecuteAsync(ChangeVendorSubmittedFormToReviewSQL, new { @ItemFormID = ItemFormID });
                return true;
            }
        }

        public async Task<DashboardStatusDto> GetDefaultFavouriteForUserType(int UserTypeID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();               
                return await conn.QueryFirstAsync<DashboardStatusDto>(GetDefaultFavouriteForUserTypeSQL, new {UserTypeID = UserTypeID });
            }
        }

        public async Task<IEnumerable<FormUserPermittedActionDto>> GetFormActionsForItemForm(int currentUserTypeID, int CurrentFormStatusID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<FormUserPermittedActionDto>(GetFormActionsForItemFormSQL, new { UserTypeID = currentUserTypeID, CurrentFormStatusID = CurrentFormStatusID });                
            }
        }

        private const string UpdateVSARelatedFormSQL = @" DECLARE @delimiter NVARCHAR(5);
                                                            DECLARE @VendorListXML XML;

                                                            --SET @VSALoginUserID = 'PGVSA1'
                                                            --SELECT @VendorList = '110601,110101'
                                                            set @delimiter = ','

                                                            IF OBJECT_ID('tempdb..#VSAVendors') IS NOT NULL
                                                                DROP TABLE #VSAVendors
                                                            create table  #VSAVendors  (VSAVendorNumber int)

                                                            SELECT @VendorListXML = CAST('<d>' + REPLACE(@VendorList, @delimiter, '</d><d>') + '</d>' AS XML);

                                                            INSERT INTO #VSAVendors
                                                            SELECT T.split.value('.', 'nvarchar(max)') AS data
                                                            FROM @VendorListXML.nodes('/d') T (split)

                                                            DELETE SessionDashboardVSABrokerForm WHERE VSAUserID = @VSALoginUserID
                                                            -- Return Item forms Valid for VSA Log in 
                                                            INSERT INTO [dbo].SessionDashboardVSABrokerForm(VSAUserID,BrokerItemFormID,CreatedBy,CreatedDate)
                                                            SELECT @VSALoginUserID,ID,@VSALoginUserID,GETDATE() FROM ItemForm WHERE NOT EXISTS (
                                                            SELECT  DISTINCT VendorNumber from [dbo].[PackagingHierarchy]
                                                            INNER JOIN [OrderablePackLevel] ON PackagingHierarchy.ID = OrderablePackLevel.PackagingHierarchyID WHERE PackagingHierarchy.ItemFormID = ItemForm.ID
                                                            UNION
                                                            SELECT DISTINCT VendorNumber FROM DSDAuthRequestStore WHERE DSDAuthRequestStore.ItemFormID = ItemForm.ID
                                                            EXCEPT
                                                            SELECT VSAVendorNumber FROM  #VSAVendors VSAVendors)
                                                            AND EXISTS (SELECT  DISTINCT VendorNumber from [dbo].[PackagingHierarchy]
                                                            INNER JOIN [OrderablePackLevel] ON PackagingHierarchy.ID = OrderablePackLevel.PackagingHierarchyID WHERE PackagingHierarchy.ItemFormID = ItemForm.ID
                                                            UNION
                                                            SELECT DISTINCT VendorNumber FROM DSDAuthRequestStore WHERE DSDAuthRequestStore.ItemFormID = ItemForm.ID)";

        private const string GetItemFormsSQL = @"SELECT ID, [ItemFormDisplayID]
                                                              ,[FormTypeID]
                                                              ,[SubmissionDate]
                                                              ,[SubmittedBy]
                                                              ,[SubmittedUserTypeID]
                                                              ,CreatedByUserTypeID
                                                              ,[FormStatusID]
                                                              ,[FormActionID]
                                                              ,[PendingRoleUserTypeID]
                                                              ,[DSDAuthRequestSelectStoreOption]
                                                              ,[ItemCreatedDateTime]
                                                              ,VendorContactID
                                                              ,[CreatedBy]
                                                              ,[CreatedDate]
                                                              ,[LastUpdatedBy]
                                                              ,[LastUpdatedDate]
                                                          FROM [S0VPITEM].[dbo].[ItemForm]
                                                        WHERE  [FormStatusID] != 2
                                                        ORDER BY ID Desc";

        private const string CheckParentFlagForGTIN = @"DECLARE @TotalGTINCount int = 0 ;
                                                        SELECT @TotalGTINCount = COUNT(*) FROM BasicItemDefinition BID INNER JOIN ItemForm  ON BID.ItemFormID = ItemForm.ID
                                                        WHERE ItemForm.GroupID IS NULL AND GTIN = @GTIN                                                        

                                                        SELECT BID.ItemFormID, BID.GTIN,ItemForm.ParentFlag,ItemForm.IsInGroup FROM ItemForm INNER JOIN BasicItemDefinition BID ON BID.ItemFormID = ItemForm.ID
                                                        WHERE ItemForm.GroupID IS NULL AND (ItemForm.ParentFlag = 'Y' OR @TotalGTINCount = 1) AND GTIN = @GTIN ";


        private const string GetItemFormListBySearchCriteriaBaseSQL = @"SELECT DISTINCT BID.ItemFormID,
                ItemForm.ItemFormDisplayID,
                ItemForm.ParentFlag,
				ItemForm.IsInGroup,
				ItemForm.GroupID,
                BID.GTIN,
                BID.GTINCheckDigit,
                BID.VendorItemCode,
                BID.VendorItemDescription,
                BID.ItemDescription as BuyerItemDescription,
                FormStatus.ID as FormStatusID,
                FormStatus.Name as FormStatus,
                BuyerStatusNameForLinkedForm,
                BuyerStatusName,
                VendorStatusName,
                FormType.ID as FormTypeID,
                FormType.Name as FormType,
                ( SELECT  SUBSTRING((SELECT DISTINCT ',' + CONVERT(varchar(10), VendorNumber)
                            FROM ItemForm InnerItemForm
							INNER JOIN PackagingHierarchy ON PackagingHierarchy.ItemFormID = ItemForm.ID				
							INNER JOIN OrderablePackLevel ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
							WHERE InnerItemForm.ID = ItemForm.ID                           
                            FOR XML PATH('')
                        ), 2, 1000000)) as VendorList,
                (SELECT TOP 1 ChildProductGroupCode as BuyerProductGroupCode FROM[ProductGrouping] WHERE ChildProductGroupType = 'BUY' AND ItemFormID = BID.ItemFormID) as BuyerProductGroupCode,
                (SELECT TOP 1 ChildProductGroupDescription as BuyerProductGroupDescription FROM [ProductGrouping] WHERE ChildProductGroupType = 'BUY' AND ItemFormID = BID.ItemFormID) as BuyerProductGroupDescription,
                (SELECT TOP 1 ChildProductGroupCode as RSSProductGroupCode FROM[ProductGrouping] WHERE ChildProductGroupType = 'RSS' AND ItemFormID = BID.ItemFormID) as RSSProductGroupCode,
                (SELECT TOP 1 ChildProductGroupDescription as RSSProductGroupDescription FROM[ProductGrouping] WHERE ChildProductGroupType = 'RSS' AND ItemFormID = BID.ItemFormID) as RSSProductGroupDescription
                FROM ItemForm INNER JOIN BasicItemDefinition BID
                ON ItemForm.ID = BID.ItemFormID
                INNER JOIN [dbo].FormStatus ON FormStatus.ID = ItemForm.FormStatusID
                INNER JOIN [dbo].FormType ON FormType.ID = ItemForm.FormTypeID
                LEFT JOIN PackagingHierarchy ON PackagingHierarchy.ItemFormID = ItemForm.ID				
				LEFT JOIN OrderablePackLevel ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
                WHERE 1=1 ";

        private const string CreateBuyerDashboardTableTempSQL = @"IF OBJECT_ID('tempdb..#BuyerDashboardItemForm') IS NOT NULL
                                                                DROP TABLE #BuyerDashboardItemForm;                                                           
                                                            

                                                            CREATE TABLE #BuyerDashboardItemForm(
	                                                        ItemFormID [int]  NOT NULL,
	                                                        ItemFormDisplayID bigint NULL,
	                                                        ParentFlag char(1) NULL,
	                                                        IsInGroup char(1) NULL,
	                                                        GroupID char(1) NULL,
	                                                        GTIN decimal(13,0) NULL,
	                                                        GTINCheckDigit decimal(13,0) NULL,
	                                                        VendorItemCode [varchar](15) NULL,
	                                                        VendorItemDescription [varchar](30) NULL,
                                                            BuyerItemDescription varchar(30),
	                                                        FormStatusID int NULL,
	                                                        FormStatus varchar(50) NULL,
                                                            BuyerStatusNameForLinkedForm varchar(50) NULL,
                                                            BuyerStatusName varchar(50) NULL,
                                                            VendorStatusName varchar(50) NULL,
	                                                        FormTypeID int NULL,
	                                                        FormType varchar(50) NULL,
	                                                        VendorList VARCHAR(MAX),
	                                                        BuyerProductGroupCode VARCHAR(4) NULL,
	                                                        BuyerProductGroupDescription VARCHAR(32) NULL,
	                                                        RSSProductGroupCode VARCHAR(4) NULL,
	                                                        RSSProductGroupDescription VARCHAR(32) NULL,
	                                                        EligibleForGroupingParenting char(1) NULL DEFAULT('N'),
                                                            SingleGTINItemForm char(1) NULL DEFAULT('Y'),
                                                            WarningCount int NULL);
                                                            
                                                            IF OBJECT_ID('tempdb..#SearchFilterBuyerItemForm') IS NOT NULL  DROP TABLE #SearchFilterBuyerItemForm;
                                                            CREATE TABLE #SearchFilterBuyerItemForm(GTIN decimal(13,0) NOT NULL,ItemFormID [int]  NOT NULL,IsInGroup char(1) NULL,FilterResult char(1) NULL);
                                                            
                                                            IF OBJECT_ID('tempdb..#ItemForminGroup') IS NOT NULL
                                                            DROP TABLE #ItemForminGroup;
                                                            CREATE TABLE #ItemForminGroup(ItemFormID [int]  NOT NULL,MaxItemFormID int NULL)";

        private const string InsertItemFormForSearchCriteriaBuyerBaseSQL = @"
                                                            INSERT INTO #SearchFilterBuyerItemForm(GTIN, ItemFormID ,IsInGroup,FilterResult)              
                                                                    SELECT BID.GTIN,ItemForm.ID,ItemForm.IsInGroup,'Y'
	                                                                FROM ItemForm INNER JOIN BasicItemDefinition BID
	                                                                ON ItemForm.ID = BID.ItemFormID
	                                                                INNER JOIN [dbo].FormStatus ON FormStatus.ID = ItemForm.FormStatusID
	                                                                INNER JOIN [dbo].FormType ON FormType.ID = ItemForm.FormTypeID				
	                                                                LEFT JOIN PackagingHierarchy ON PackagingHierarchy.ItemFormID = ItemForm.ID				
	                                                                LEFT JOIN OrderablePackLevel ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
	                                                                WHERE 1=1 ";

        private const string GetBuyerItemFormForSearchCriteriaSQL = @" IF(@IncludeGroupedItemForm = 1)
	                         BEGIN
	                         INSERT INTO #BuyerDashboardItemForm(ItemFormID,
		                        ItemFormDisplayID,
		                        ParentFlag,
		                        IsInGroup,
		                        GroupID,
		                        GTIN,
		                        GTINCheckDigit,
		                        VendorItemCode,
		                        VendorItemDescription,
                                BuyerItemDescription,
		                        FormStatusID,
		                        FormStatus,
                                BuyerStatusNameForLinkedForm,
                                BuyerStatusName,
                                VendorStatusName,
		                        FormTypeID,
		                        FormType,
		                        VendorList,
		                        BuyerProductGroupCode,
		                        BuyerProductGroupDescription,
		                        RSSProductGroupCode,
		                        RSSProductGroupDescription
                                ,WarningCount)
	                                        SELECT DISTINCT BID.ItemFormID,
					                        ItemForm.ItemFormDisplayID,
					                        ItemForm.ParentFlag,
					                        ItemForm.IsInGroup,
					                        ItemForm.GroupID,
					                        BID.GTIN,
					                        BID.GTINCheckDigit,
					                        BID.VendorItemCode,
					                        BID.VendorItemDescription,
                                            ISNULL(NULLIF(BID.ItemDescription,''),BID.VendorItemDescription),
					                        FormStatus.ID as FormStatusID,
					                        FormStatus.Name as FormStatus,
                                            FormStatus.BuyerStatusNameForLinkedForm,
                                            FormStatus.BuyerStatusName,
                                            FormStatus.VendorStatusName,
					                        FormType.ID as FormTypeID,
					                        FormType.Name as FormType,
					                        ( SELECT  SUBSTRING((SELECT DISTINCT ', ' + CONVERT(varchar(10), VendorNumber)
								                        FROM ItemForm InnerItemForm
								                        INNER JOIN PackagingHierarchy ON PackagingHierarchy.ItemFormID = ItemForm.ID				
								                        INNER JOIN OrderablePackLevel ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
								                        WHERE InnerItemForm.ID = ItemForm.ID                           
								                        FOR XML PATH('')
							                        ), 2, 1000000)) as VendorList,
					                        (SELECT TOP 1 ChildProductGroupCode as BuyerProductGroupCode FROM[ProductGrouping] WHERE ChildProductGroupType = 'BUY' AND ItemFormID = BID.ItemFormID) as BuyerProductGroupCode,
					                        (SELECT TOP 1 ChildProductGroupDescription as BuyerProductGroupDescription FROM [ProductGrouping] WHERE ChildProductGroupType = 'BUY' AND ItemFormID = BID.ItemFormID) as BuyerProductGroupDescription,
					                        (SELECT TOP 1 ChildProductGroupCode as RSSProductGroupCode FROM[ProductGrouping] WHERE ChildProductGroupType = 'RSS' AND ItemFormID = BID.ItemFormID) as RSSProductGroupCode,
					                        (SELECT TOP 1 ChildProductGroupDescription as RSSProductGroupDescription FROM[ProductGrouping] WHERE ChildProductGroupType = 'RSS' AND ItemFormID = BID.ItemFormID) as RSSProductGroupDescription,
                                            (SELECT  COUNT(*)  FROM ItemForm INNER JOIN ItemFormError ON ItemForm.ID = ItemFormError.ItemFormID  WHERE ItemForm.ID = BID.ItemFormID) AS WarningCount                    
					                        FROM ItemForm INNER JOIN BasicItemDefinition BID
					                        ON ItemForm.ID = BID.ItemFormID
					                        INNER JOIN [dbo].FormStatus ON FormStatus.ID = ItemForm.FormStatusID
					                        INNER JOIN [dbo].FormType ON FormType.ID = ItemForm.FormTypeID
					                        INNER JOIN #SearchFilterBuyerItemForm SFItemForm ON (SFItemForm.GTIN = BID.GTIN AND SFItemForm.IsInGroup = 'Y' AND ItemForm.IsInGroup = 'Y') OR (SFItemForm.IsInGroup = 'N' AND SFItemForm.ItemFormID = ItemForm.ID)			
					                        LEFT JOIN PackagingHierarchy ON PackagingHierarchy.ItemFormID = ItemForm.ID				
					                        LEFT JOIN OrderablePackLevel ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID	
                                            WHERE ItemForm.BuyerID = @BuyerID 
	                         END
                         ELSE
                         BEGIN
 	                        INSERT INTO #BuyerDashboardItemForm(ItemFormID,
		                        ItemFormDisplayID,
		                        ParentFlag,
		                        IsInGroup,
		                        GroupID,
		                        GTIN,
		                        GTINCheckDigit,
		                        VendorItemCode,
		                        VendorItemDescription,
                                BuyerItemDescription,
		                        FormStatusID,
		                        FormStatus,
                                BuyerStatusNameForLinkedForm,
                                BuyerStatusName,
                                VendorStatusName,
		                        FormTypeID,
		                        FormType,
		                        VendorList,
		                        BuyerProductGroupCode,
		                        BuyerProductGroupDescription,
		                        RSSProductGroupCode,
		                        RSSProductGroupDescription
                                ,WarningCount)
	                        SELECT DISTINCT BID.ItemFormID,
					                        ItemForm.ItemFormDisplayID,
					                        ItemForm.ParentFlag,
					                        ItemForm.IsInGroup,
					                        ItemForm.GroupID,
					                        BID.GTIN,
					                        BID.GTINCheckDigit,
					                        BID.VendorItemCode,
					                        BID.VendorItemDescription,
                                            ISNULL(NULLIF(BID.ItemDescription,''),BID.VendorItemDescription),
					                        FormStatus.ID as FormStatusID,
					                        FormStatus.Name as FormStatus,
                                            FormStatus.BuyerStatusNameForLinkedForm,
                                            FormStatus.BuyerStatusName,
                                            FormStatus.VendorStatusName,
					                        FormType.ID as FormTypeID,
					                        FormType.Name as FormType,
					                        ( SELECT  SUBSTRING((SELECT DISTINCT ', ' + CONVERT(varchar(10), VendorNumber)
								                        FROM ItemForm InnerItemForm
								                        INNER JOIN PackagingHierarchy ON PackagingHierarchy.ItemFormID = ItemForm.ID				
								                        INNER JOIN OrderablePackLevel ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
								                        WHERE InnerItemForm.ID = ItemForm.ID                           
								                        FOR XML PATH('')
							                        ), 2, 1000000)) as VendorList,
					                        (SELECT TOP 1 ChildProductGroupCode as BuyerProductGroupCode FROM[ProductGrouping] WHERE ChildProductGroupType = 'BUY' AND ItemFormID = BID.ItemFormID) as BuyerProductGroupCode,
					                        (SELECT TOP 1 ChildProductGroupDescription as BuyerProductGroupDescription FROM [ProductGrouping] WHERE ChildProductGroupType = 'BUY' AND ItemFormID = BID.ItemFormID) as BuyerProductGroupDescription,
					                        (SELECT TOP 1 ChildProductGroupCode as RSSProductGroupCode FROM[ProductGrouping] WHERE ChildProductGroupType = 'RSS' AND ItemFormID = BID.ItemFormID) as RSSProductGroupCode,
					                        (SELECT TOP 1 ChildProductGroupDescription as RSSProductGroupDescription FROM[ProductGrouping] WHERE ChildProductGroupType = 'RSS' AND ItemFormID = BID.ItemFormID) as RSSProductGroupDescription,
                                            (SELECT  COUNT(*)  FROM ItemForm INNER JOIN ItemFormError ON ItemForm.ID = ItemFormError.ItemFormID  WHERE ItemForm.ID = BID.ItemFormID) AS WarningCount                    
					                        FROM ItemForm INNER JOIN BasicItemDefinition BID
					                        ON ItemForm.ID = BID.ItemFormID
					                        INNER JOIN [dbo].FormStatus ON FormStatus.ID = ItemForm.FormStatusID
					                        INNER JOIN [dbo].FormType ON FormType.ID = ItemForm.FormTypeID					                        		
					                        LEFT JOIN PackagingHierarchy ON PackagingHierarchy.ItemFormID = ItemForm.ID				
					                        LEFT JOIN OrderablePackLevel ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID	
                                            WHERE ItemForm.BuyerID = 90000015 AND ItemForm.FormStatusID = 5	
	                        END

	                        UPDATE DItemForm
				                        SET EligibleForGroupingParenting = 'Y',SingleGTINItemForm = 'N'
				                        FROM #BuyerDashboardItemForm AS DItemForm                                        
				                        WHERE EXISTS (SELECT DItemForm.GTIN FROM BasicItemDefinition BID
								                        INNER JOIN ItemForm ON ItemForm.ID = BID.ItemFormID                                                       
                                                        WHERE DItemForm.GTIN = BID.GTIN AND ItemForm.GroupID IS NULL 
                                                        GROUP BY BID.GTIN,ItemForm.GroupID 
                                                        HAVING  COUNT(ItemFormID) > 1)
                            UPDATE DItemForm
				                        SET SingleGTINItemForm = 'Y'
				                        FROM #BuyerDashboardItemForm AS DItemForm                                        
				                        WHERE EXISTS (SELECT DItemForm.GTIN FROM BasicItemDefinition BID
								                        INNER JOIN ItemForm ON ItemForm.ID = BID.ItemFormID                                                       
                                                        WHERE DItemForm.GTIN = BID.GTIN AND ItemForm.GroupID IS NULL 
                                                        GROUP BY BID.GTIN,ItemForm.GroupID 
                                                        HAVING  COUNT(ItemFormID) = 1); 
                            
                            INSERT INTO #ItemForminGroup (ItemFormID,MaxItemFormID)
                                SELECT ItemFormID,MIN(ItemFormID) OVER (PARTITION BY GTIN) as MaxItemFormID FROM  #BuyerDashboardItemForm DItemForm
                                WHERE SingleGTINItemForm  = 'N' AND FormStatusID = 4 AND 
                                NOT EXISTS (SELECT GTIN FROM BasicItemDefinition BID
			                    INNER JOIN ItemForm ON ItemForm.ID = BID.ItemFormID WHERE BID.GTIN  = DItemForm.GTIN and FormStatusID <> 4);

                                IF EXISTS(SELECT * FROM #ItemForminGroup )
                                BEGIN
                                    UPDATE DItemForm
                                    SET DItemForm.ParentFlag = 'Y'
                                    FROM #BuyerDashboardItemForm DItemForm INNER JOIN #ItemForminGroup ON DItemForm.ItemFormID = #ItemForminGroup.MaxItemFormID

                                    UPDATE DItemForm
                                    SET DItemForm.IsInGroup = 'Y'
                                    FROM #BuyerDashboardItemForm DItemForm INNER JOIN #ItemForminGroup ON DItemForm.ItemFormID = #ItemForminGroup.ItemFormID

                                    UPDATE MainItemForm
                                    SET MainItemForm.ParentFlag = 'Y'
                                    FROM ItemForm MainItemForm INNER JOIN #ItemForminGroup ON MainItemForm.ID = #ItemForminGroup.MaxItemFormID

                                    UPDATE MainItemForm
                                    SET MainItemForm.IsInGroup = 'Y'
                                    FROM ItemForm MainItemForm INNER JOIN #ItemForminGroup ON MainItemForm.ID = #ItemForminGroup.ItemFormID
                                END
                                
                            
                            if(@FormStatusID = 0)
                                SELECT * FROM #BuyerDashboardItemForm WHERE FormStatusID NOT IN (1,2,3)
                            else
	                        SELECT * FROM #BuyerDashboardItemForm WHERE FormStatusID = @FormStatusID AND FormStatusID NOT IN (1,2,3) ";


        private const string GetBuyerStatusDetailSQL = @"UPDATE DItemForm
				                        SET EligibleForGroupingParenting = 'Y',SingleGTINItemForm = 'N'
				                        FROM #BuyerDashboardItemForm AS DItemForm                                        
				                        WHERE EXISTS (SELECT DItemForm.GTIN FROM BasicItemDefinition BID
								                        INNER JOIN ItemForm ON ItemForm.ID = BID.ItemFormID                                                       
                                                        WHERE DItemForm.GTIN = BID.GTIN AND ItemForm.GroupID IS NULL 
                                                        GROUP BY BID.GTIN,ItemForm.GroupID 
                                                        HAVING  COUNT(ItemFormID) > 1)
                                        UPDATE DItemForm
				                                    SET SingleGTINItemForm = 'Y'
				                                    FROM #BuyerDashboardItemForm AS DItemForm                                        
				                                    WHERE EXISTS (SELECT DItemForm.GTIN FROM BasicItemDefinition BID
								                                    INNER JOIN ItemForm ON ItemForm.ID = BID.ItemFormID                                                       
                                                                    WHERE DItemForm.GTIN = BID.GTIN AND ItemForm.GroupID IS NULL 
                                                                    GROUP BY BID.GTIN,ItemForm.GroupID 
                                                                    HAVING  COUNT(ItemFormID) = 1); 
                        
	                        SELECT * FROM #BuyerDashboardItemForm WHERE FormStatusID = @FormStatusID AND FormStatusID NOT IN (1,2,3)";


        private const string AnyUserWithoutVSARelatedFormsFilter = " AND ItemForm.VendorContactID IN (@VendorContactID) ";
        private const string VSAAndRelatedFormsFilter = " AND (ItemForm.VendorContactID IN (@VendorContactID) OR ItemForm.ID IN (SELECT BrokerItemFormID FROM SessionDashboardVSABrokerForm WHERE VSAUserID = @VendorContactID)) ";
        private const string VendorItemCodeFilterSQL = " AND BID.VendorItemCode = @SearchItemCode";
        private const string GTINFilterSQL = " AND BID.GTIN = @GTIN";
        private const string VendorItemDescriptionFilterSQL = " AND BID.VendorItemDescription LIKE ''+@SearchItemDescription+'%'";
        private const string SubmissionDateFilterSQL = " AND SubmissionDate > @SearchSubmittedFromDate AND SubmissionDate <  @SearchSubmittedToDate";
        private const string CompressedUPCFilterSQL = " AND BID.CompressedUPC = @CompressedUPC";
        private const string PriceLookupCodeFilterSQL = " AND BID.PriceLookupCode = @PriceLookupCode";
        private const string ItemFormDisplayIDFilterSQL = " AND ItemForm.ItemFormDisplayID LIKE ''+CAST(@SearchFormId AS VARCHAR(18))+'%'";
        private const string ExactItemFormDisplayIDFilterSQL = " AND ItemForm.ItemFormDisplayID = @SearchFormId ";
        private const string FormStatusIDFilterSQL = "  AND ItemForm.FormStatusID IN (SELECT ID FROM CSVToTable(@SearchFormStatusId))"; 
        private const string SpecificViewItemFormsForUserIDFilterSQL = "  AND ItemForm.VendorContactID = @VendorContactID";
        private const string SpecificViewItemFormsForUserIDFilterInternalSQL = "  AND ItemForm.BuyerID = @BuyerID";
        private const string VendorListFilterSQL = "  AND OrderablePackLevel.VendorNumber IN (SELECT ID FROM CSVToTable(@finalVendorList)) ";


        private const string ChangeVendorSubmittedFormToReviewSQL = @"DECLARE @GTIN decimal(13,0),@IsInGroup char(1)
                                                                    SELECT @GTIN = BID.GTIN,@IsInGroup = IsInGroup FROM ItemForm INNER Join BasicItemDefinition BID ON BID.ItemFormID = ItemForm.ID WHERE ID = @ItemFormID

                                                                    IF(@IsInGroup = 'Y')
                                                                    UPDATE SubmittedItemForm
                                                                    SET SubmittedItemForm.FormStatusID = 5
                                                                    FROM ItemForm SubmittedItemForm
                                                                    INNER Join BasicItemDefinition BID ON BID.ItemFormID = SubmittedItemForm.ID WHERE BID.GTIN = @GTIN AND IsInGroup = 'Y' AND GroupID IS NULL
                                                                    ELSE
                                                                    UPDATE ItemForm
                                                                    SET FormStatusID = 5
                                                                    WHERE ID = @ItemFormID";

        private const string CreateBuyerItemFormForGTINTempTableSQL = @"IF OBJECT_ID('tempdb..#ItemFormForGTIN') IS NOT NULL
	                                                                DROP TABLE #ItemFormForGTIN;                             

	                                                                CREATE TABLE #ItemFormForGTIN(
	                                                                ItemFormID [int]  NOT NULL,
	                                                                GTIN decimal(13,0) NULL,	                                                  
	                                                                ParentFlag char(1) NULL,
	                                                                IsInGroup char(1) NULL,
	                                                                GroupID char(1) NULL,
	                                                                FormStatusID int NULL,
                                                                    EligibleForGroupingParenting char(1) DEFAULT('N') NULL,
                                                                    SingleGTINItemForm char(1) DEFAULT('Y') NULL,
                                                                    WarningCount int NULL 	                                                                                                         
	                                                                );

                                                                   ";

        private const string LoadBuyerItemFormForGTINTempTableSQL = @"INSERT INTO #ItemFormForGTIN(ItemFormID,GTIN,ParentFlag,IsInGroup,GroupID,FormStatusID,WarningCount)
	                                                                    SELECT BIDForGTIN.ItemFormID,BIDForGTIN.GTIN, ParentFlag,IsInGroup,GroupID,ItemForm.FormStatusID, 
                                                                        (SELECT COUNT(*)  FROM ItemForm INNER JOIN ItemFormError ON ItemForm.ID = ItemFormError.ItemFormID  WHERE ItemForm.ID = BIDForGTIN.ItemFormID) AS WarningCount                         
                                                                        FROM BasicItemDefinition BID 
	                                                                    INNER JOIN BasicItemDefinition BIDForGTIN ON BIDForGTIN.GTIN = BID.GTIN 
	                                                                    INNER JOIN ItemForm  ON BIDForGTIN.ItemFormID = ItemForm.ID
	                                                                    WHERE BID.ItemFormID = @ItemFormID AND ItemForm.GroupID IS NULL AND FormStatusID NOT IN (1,2,3);
                                                                        
                                                                        UPDATE DItemForm
				                                                        SET EligibleForGroupingParenting = 'Y',SingleGTINItemForm = 'N'
				                                                        FROM #ItemFormForGTIN AS DItemForm                                        
				                                                        WHERE EXISTS (SELECT DItemForm.GTIN FROM BasicItemDefinition BID
								                                                        INNER JOIN ItemForm ON ItemForm.ID = BID.ItemFormID                                                                                        
                                                                                        WHERE DItemForm.GTIN = BID.GTIN AND ItemForm.GroupID IS NULL  
                                                                                        GROUP BY BID.GTIN,ItemForm.GroupID 
                                                                                        HAVING  COUNT(ItemFormID) > 1);";

        private const string GroupingItemFormSQL = @"IF EXISTS(SELECT * FROM #ItemFormForGTIN WHERE ParentFlag = 'Y')
                                                        BEGIN
	                                                        IF EXISTS(SELECT * FROM #ItemFormForGTIN  WHERE IsInGroup = 'Y' ) --- AND FormStatusID  = 4 add later tree child status are in submitted
		                                                        UPDATE ItemForm 
		                                                        SET IsInGroup = 'Y',ParentFlag ='N',
                                                                FormStatusID = (SELECT FormStatusID FROM #ItemFormForGTIN WHERE ParentFlag = 'Y')
		                                                        WHERE ID = @ItemFormID	
	                                                        ELSE
		                                                        UPDATE ItemForm  -- tree child are move to higher state from submitted to in review or more
		                                                        SET IsInGroup = 'N',ParentFlag ='N'
		                                                        WHERE ID = @ItemFormID
                                                        END
                                                        ELSE
                                                        UPDATE ItemForm -- Setting grouped item form as parent after user validation when no parent exist for the gtin family
                                                        SET IsInGroup = 'Y',ParentFlag ='Y'
                                                        WHERE ID = @ItemFormID";

        private const string UnGroupingItemFormSQL = @"DECLARE @TotalGTINChildCount int =0,@IsParentFlagUnGroupped char(1) = 'N',@NextParentItemForm int =0	
	                                                    SELECT @IsParentFlagUnGroupped = 'Y' FROM #ItemFormForGTIN WHERE ParentFlag = 'Y' AND ItemFormID = @ItemFormID
	                                                    SELECT @TotalGTINChildCount = COUNT(*),@NextParentItemForm = MIN(ItemFormID) FROM #ItemFormForGTIN WHERE IsInGroup = 'Y' AND ParentFlag = 'N'

                                                            IF (@IsParentFlagUnGroupped = 'Y' AND @TotalGTINChildCount > 0) -- parent flag is ungrouped which has tree with child	
		                                                            BEGIN						
			                                                            UPDATE ItemForm
			                                                            SET ParentFlag ='Y'
			                                                            WHERE ID = @NextParentItemForm
			                                                            UPDATE ItemForm
			                                                            SET IsInGroup = 'N',ParentFlag = 'N'
			                                                            WHERE ID = @ItemFormID
		                                                            END	
                                                            ELSE IF (@IsParentFlagUnGroupped = 'Y'AND @TotalGTINChildCount = 0)
		                                                            UPDATE ItemForm
		                                                            SET IsInGroup = 'N',ParentFlag = 'N'
		                                                            WHERE ID = @ItemFormID
                                                            ELSE IF ( @IsParentFlagUnGroupped = 'N')
		                                                            UPDATE ItemForm
		                                                            SET IsInGroup = 'N'
		                                                            WHERE ID = @ItemFormID";


        private const string ParentingItemFormSQL = @" DECLARE @TotalGTINChildCount int =0,@HasParent char(1) = 'N',@PreviousParentItemForm int =0	
	                                                   SELECT @HasParent = 'Y',@PreviousParentItemForm = ItemFormID FROM #ItemFormForGTIN WHERE ParentFlag = 'Y' 
	                                                   SELECT @TotalGTINChildCount = COUNT(*) FROM #ItemFormForGTIN WHERE IsInGroup = 'Y' AND ParentFlag = 'N'

                                                            IF (@HasParent = 'Y' AND @TotalGTINChildCount > 0) -- parent flag is ungrouped which has tree with child	
		                                                            BEGIN						
			                                                            UPDATE ItemForm
			                                                            SET ParentFlag ='N'
			                                                            WHERE ID = @PreviousParentItemForm
			                                                            UPDATE ItemForm
			                                                            SET ParentFlag = 'Y',IsInGroup = 'Y'
			                                                            WHERE ID = @ItemFormID
		                                                            END	
                                                            ELSE IF (@HasParent = 'N')
		                                                            UPDATE ItemForm
		                                                            SET IsInGroup = 'Y',ParentFlag = 'Y'
		                                                            WHERE ID = @ItemFormID";

        private const string UnParentingItemFormSQL = @"DECLARE @TotalGTINChildCount int =0,@NextParentItemForm int =0		                                                  
	                                                    SELECT @TotalGTINChildCount = COUNT(*),@NextParentItemForm = MIN(ItemFormID) FROM #ItemFormForGTIN WHERE IsInGroup = 'Y' AND ParentFlag = 'N'

                                                            IF (@TotalGTINChildCount > 0) -- parent flag is ungrouped which has tree with child	
		                                                            BEGIN						
			                                                            UPDATE ItemForm
			                                                            SET ParentFlag ='Y'
			                                                            WHERE ID = @NextParentItemForm
			                                                            UPDATE ItemForm
			                                                            SET ParentFlag = 'N'
			                                                            WHERE ID = @ItemFormID
		                                                            END	
                                                            ELSE IF (@TotalGTINChildCount = 0)
		                                                            UPDATE ItemForm
		                                                            SET IsInGroup = 'N',ParentFlag = 'N'
		                                                            WHERE ID = @ItemFormID";

        private const string GetGroupedItemFormForGTINSQL = @"SELECT DISTINCT BID.ItemFormID,
					                                        ItemForm.ItemFormDisplayID,
					                                        ItemForm.ParentFlag,
					                                        ItemForm.IsInGroup,
					                                        ItemForm.GroupID,
					                                        BID.GTIN,
					                                        BID.GTINCheckDigit,
					                                        BID.VendorItemCode,
					                                        BID.VendorItemDescription,
                                                            ISNULL(NULLIF(BID.ItemDescription,''),BID.VendorItemDescription) as BuyerItemDescription,
					                                        FormStatus.ID as FormStatusID,
					                                        FormStatus.Name as FormStatus,
                                                            FormStatus.BuyerStatusNameForLinkedForm,
                                                            FormStatus.BuyerStatusName,
                                                            FormStatus.VendorStatusName,
					                                        FormType.ID as FormTypeID,
					                                        FormType.Name as FormType,
					                                        ( SELECT  SUBSTRING((SELECT DISTINCT ',' + CONVERT(varchar(10), VendorNumber)
								                                        FROM ItemForm InnerItemForm
								                                        INNER JOIN PackagingHierarchy ON PackagingHierarchy.ItemFormID = ItemForm.ID				
								                                        INNER JOIN OrderablePackLevel ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
								                                        WHERE InnerItemForm.ID = ItemForm.ID                           
								                                        FOR XML PATH('')
							                                        ), 2, 1000000)) as VendorList,
					                                        (SELECT TOP 1 ChildProductGroupCode as BuyerProductGroupCode FROM[ProductGrouping] WHERE ChildProductGroupType = 'BUY' AND ItemFormID = BID.ItemFormID) as BuyerProductGroupCode,
					                                        (SELECT TOP 1 ChildProductGroupDescription as BuyerProductGroupDescription FROM [ProductGrouping] WHERE ChildProductGroupType = 'BUY' AND ItemFormID = BID.ItemFormID) as BuyerProductGroupDescription,
					                                        (SELECT TOP 1 ChildProductGroupCode as RSSProductGroupCode FROM[ProductGrouping] WHERE ChildProductGroupType = 'RSS' AND ItemFormID = BID.ItemFormID) as RSSProductGroupCode,
					                                        (SELECT TOP 1 ChildProductGroupDescription as RSSProductGroupDescription FROM[ProductGrouping] WHERE ChildProductGroupType = 'RSS' AND ItemFormID = BID.ItemFormID) as RSSProductGroupDescription,
                                                            #ItemFormForGTIN.EligibleForGroupingParenting,
                                                            #ItemFormForGTIN.WarningCount                
					                                        FROM ItemForm INNER JOIN BasicItemDefinition BID
					                                        ON ItemForm.ID = BID.ItemFormID
					                                        INNER JOIN [dbo].FormStatus ON FormStatus.ID = ItemForm.FormStatusID
					                                        INNER JOIN [dbo].FormType ON FormType.ID = ItemForm.FormTypeID
					                                        INNER JOIN #ItemFormForGTIN ON #ItemFormForGTIN.ItemFormID = ItemForm.ID";


        private const string GetFormActionListBaseSQL = @"SELECT FUPA.FormTypeId , CurrentFormStatusID,
                                                            CurrentFormStatus.Name as CurrentFormStatus ,
                                                            FormActionID,
                                                            FormAction.Name as ActionName,
                                                            BuyerActionName,
                                                            VendorActionName,
                                                            CreatedFormStatusID,
                                                            CreatedFormStatus.Name as CreatedFormStatus,
                                                            FormAction.Comment as ActionComment,
                                                            CurrentFormStatus.Comment as CurrentFormStatusComment,
                                                            CreatedFormStatus.Comment as CreatedFormStatusComment
                                                            FROM FormUserPermittedAction FUPA 
                                                            INNER JOIN FormAction 
                                                            ON FormAction.ID = FUPA.FormActionID
                                                            INNER JOIN FormStatus as CurrentFormStatus ON CurrentFormStatus.ID = FUPA.CurrentFormStatusID
                                                            INNER JOIN FormStatus as CreatedFormStatus ON CreatedFormStatus.ID = FormAction.CreatedFormStatusID
                                                            WHERE ";

        private const string UpdateItemFormActionAndCurrentStatusSQL = @"UPDATE ItemForm
                                                                        SET ItemForm.FormActionID = @FormActionID,
                                                                        ItemForm.FormStatusID = (SELECT CreatedFormStatusID FROM FormAction WHERE ID = @FormActionID)
                                                                        ,LastUpdatedBy = @LastUpdatedBy
                                                                        ,LastUpdatedDate = GETDATE()
                                                                        WHERE ItemForm.ID = @ItemFormID";

        private const string UpdateItemFormStatusForInternalUserSQL = @"IF EXISTS (SELECT * FROM ItemForm WHERE ID = @ItemFormID AND ParentFlag = 'Y')
                                                                                BEGIN
                                                                                    DECLARE @GTIN Decimal(13,0)
                                                                                    select @GTIN = GTIN from ItemForm inner join BasicItemDefinition BID ON BID.ItemFormID = ItemForm.ID
                                                                                    where ID = @ItemFormID 

                                                                                    UPDATE GItemForm 
                                                                                    SET FormStatusID = (SELECT CreatedFormStatusID FROM FormAction WHERE ID = @FormActionID)
                                                                                    FROM ItemForm GItemForm
                                                                                    inner join BasicItemDefinition BID ON BID.ItemFormID = GItemForm.ID
                                                                                    WHERE GTIN = @GTIN and GroupID IS NULL AND IsInGroup ='Y'
                                                                                END
                                                                                ELSE
                                                                                    UPDATE ItemForm
                                                                                    SET ItemForm.FormActionID = @FormActionID,
                                                                                    ItemForm.FormStatusID = (SELECT CreatedFormStatusID FROM FormAction WHERE ID = @FormActionID)
	                                                                                ,LastUpdatedBy = @LastUpdatedBy
	                                                                                ,LastUpdatedDate = GETDATE()
                                                                                    WHERE ItemForm.ID = @ItemFormID";
        private const string UpdateReassignVendorContactSQL = @"UPDATE itemform
                                                            SET VendorContactID = @ViewForUserId
                                                            WHERE ID = @ItemFormId";

        private const string UpdateItemFormActionAndCurrentStatusAuditSQL = @"INSERT INTO [dbo].[ItemFormAudit]
           ([Version]
           ,[ID]
           ,[ItemFormDisplayID]
           ,[FormTypeID]
           ,[SubmissionDate]
           ,[SubmittedBy]
           ,[SubmittedUserTypeID]
           ,[FormStatusID]
           ,[FormActionID]
           ,[PendingRoleUserTypeID]
           ,[DSDAuthRequestSelectStoreOption]
           ,[ItemCreatedDateTime]
           ,[VendorContactID]
           ,[DeferredToDate]
           ,[ItemCode]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])     
            SELECT 
			GETDATE()
			,[ID]
           ,[ItemFormDisplayID]
           ,[FormTypeID]
           ,[SubmissionDate]
           ,[SubmittedBy]
           ,[SubmittedUserTypeID]
           ,[FormStatusID]
           ,[FormActionID]
           ,[PendingRoleUserTypeID]
           ,[DSDAuthRequestSelectStoreOption]
           ,[ItemCreatedDateTime]
           ,[VendorContactID]
           ,[DeferredToDate]
           ,[ItemCode]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate] FROM ItemForm WHERE ItemForm.ID = @ItemFormID";

        private const string UpdateItemFormStatusForInternalUserAuditSQL = @"IF EXISTS (SELECT * FROM ItemForm WHERE ID = @ItemFormID AND ParentFlag = 'Y')
                BEGIN
	                DECLARE @GTIN Decimal(13,0)
	                select @GTIN =GTIN from ItemForm inner join BasicItemDefinition BID ON BID.ItemFormID = ItemForm.ID
	                where ID = @ItemFormID
    
                    INSERT INTO [dbo].[ItemFormAudit]
                           ([Version]
                           ,[ID]
                           ,[ItemFormDisplayID]
                           ,[FormTypeID]
                           ,[SubmissionDate]
                           ,[SubmittedBy]
                           ,[SubmittedUserTypeID]
                           ,[FormStatusID]
                           ,[FormActionID]
                           ,[PendingRoleUserTypeID]
                           ,[DSDAuthRequestSelectStoreOption]
                           ,[ItemCreatedDateTime]
                           ,[VendorContactID]
                           ,[DeferredToDate]
                           ,[ItemCode]
                           ,[CreatedBy]
                           ,[CreatedDate]
                           ,[LastUpdatedBy]
                           ,[LastUpdatedDate]) 
	                 SELECT 
			                GETDATE()
			                ,[ID]
                           ,[ItemFormDisplayID]
                           ,[FormTypeID]
                           ,[SubmissionDate]
                           ,[SubmittedBy]
                           ,[SubmittedUserTypeID]
                           ,[FormStatusID]
                           ,[FormActionID]
                           ,[PendingRoleUserTypeID]
                           ,[DSDAuthRequestSelectStoreOption]
                           ,[ItemCreatedDateTime]
                           ,[VendorContactID]
                           ,[DeferredToDate]
                           ,[ItemCode]
                           ,[CreatedBy]
                           ,[CreatedDate]
                           ,[LastUpdatedBy]
                           ,[LastUpdatedDate] FROM ItemForm 
                            WHERE ItemForm.ID IN (SELECT ID FROM ItemForm 
								                  inner join BasicItemDefinition BID ON BID.ItemFormID = ItemForm.ID
                                                  WHERE GTIN = @GTIN and GroupID IS NULL AND IsInGroup ='Y')
                END

                INSERT INTO [dbo].[ItemFormAudit]
                           ([Version]
                           ,[ID]
                           ,[ItemFormDisplayID]
                           ,[FormTypeID]
                           ,[SubmissionDate]
                           ,[SubmittedBy]
                           ,[SubmittedUserTypeID]
                           ,[FormStatusID]
                           ,[FormActionID]
                           ,[PendingRoleUserTypeID]
                           ,[DSDAuthRequestSelectStoreOption]
                           ,[ItemCreatedDateTime]
                           ,[VendorContactID]
                           ,[DeferredToDate]
                           ,[ItemCode]
                           ,[CreatedBy]
                           ,[CreatedDate]
                           ,[LastUpdatedBy]
                           ,[LastUpdatedDate])     
                            SELECT 
			                GETDATE()
			                ,[ID]
                           ,[ItemFormDisplayID]
                           ,[FormTypeID]
                           ,[SubmissionDate]
                           ,[SubmittedBy]
                           ,[SubmittedUserTypeID]
                           ,[FormStatusID]
                           ,[FormActionID]
                           ,[PendingRoleUserTypeID]
                           ,[DSDAuthRequestSelectStoreOption]
                           ,[ItemCreatedDateTime]
                           ,[VendorContactID]
                           ,[DeferredToDate]
                           ,[ItemCode]
                           ,[CreatedBy]
                           ,[CreatedDate]
                           ,[LastUpdatedBy]
                           ,[LastUpdatedDate] FROM ItemForm WHERE ItemForm.ID = @ItemFormID";

        private const string GetDashboardStatusSQL = @"WITH DashBoardStatusCTE (DashboardStatusNameId,Status,StatusID,StatusComment,StatusImage,SortOrder) as
                                                    (
                                                    SELECT ID as DashboardStatusNameId,Status,StatusID, StatusComment,StatusImage,SortOrder FROM [DashboardStatusQueries] WHERE ISActive = 1 AND UserTypeID = @LoggedInUserTypeID and UserTypeID IS NOT NULL
                                                    UNION
                                                    SELECT ID as DashboardStatusNameId,Status,StatusID, StatusComment,StatusImage,SortOrder FROM [DashboardStatusQueries] WHERE ISActive = 1 AND UserID = @LoggedInUserID and UserTypeID IS NULL
                                                    )
                                                    SELECT* FROM DashBoardStatusCTE ORDER BY SortOrder";

        private const string GetDashboardStatusCountSQL = @"DECLARE @ExecStr NVARCHAR(MAX),@IncludeVSARelatedForms bit;
                                                                select @ExecStr = AggregateQuery from [dbo].[DashboardStatusQueries]
                                                                WHERE ID = @DashboardStatusNameId
                                                                EXEC sp_executesql @ExecStr, N'@VendorContactID CHAR(10),@IncludeVSARelatedForms bit', @VendorContactID = @ViewForUserId,@IncludeVSARelatedForms = @IncludeVSARelatedFormsInput";

        private const string GetDashboardStatusCountInternalSQL = @"DECLARE @ExecStr NVARCHAR(MAX);
                                                                select @ExecStr = AggregateQuery from [dbo].[DashboardStatusQueries]
                                                                WHERE ID = @DashboardStatusNameId
                                                                EXEC sp_executesql @ExecStr, N'@viewItemFormsForUserID CHAR(10)', @viewItemFormsForUserID = @viewItemFormsForUserID";


        private const string GetDashboardStatusDetailSQL = @"DECLARE @ExecStr NVARCHAR(MAX);
                                                                select @ExecStr = DetailsQuery from [dbo].[DashboardStatusQueries]
                                                                WHERE ID = @DashboardStatusNameId
                                                                EXEC sp_executesql @ExecStr, N'@VendorContactID CHAR(10),@IncludeVSARelatedForms bit', @VendorContactID = @ViewForUserId,@IncludeVSARelatedForms = @IncludeVSARelatedFormsInput";

        private const string GetDashboardStatusDetailInternalSQL = @"DECLARE @ExecStr NVARCHAR(MAX);
                                                                select @ExecStr = DetailsQuery from [dbo].[DashboardStatusQueries]
                                                                WHERE ID = @DashboardStatusNameId
                                                                EXEC sp_executesql @ExecStr, N'@viewItemFormsForUserID CHAR(10)', @viewItemFormsForUserID = @viewItemFormsForUserID";

        private const string GetDashboardFormStatusForVendorSQL = @";WITH VendorStatusCTE
                                                                        AS (
                                                                         SELECT CONVERT(varchar(10), ID) AS ID,VendorStatusName FROM FormStatus
                                                                         WHERE EXISTS (SELECT * FROM FormUserPermittedAction FUPA WHERE FUPA.UserTypeId = 1 AND FUPA.IsActive = 1 AND FormStatus.ID = FUPA.CurrentFormStatusID) AND IsActive = 1)

                                                                         SELECT OutTab.VendorStatusName as FormStatus ,
                                                                              FormStatusIDs = 
                                                                                      STUFF ( ( SELECT ','+InrTab.ID
                                                                                          FROM VendorStatusCTE InrTab
                                                                                          WHERE InrTab.VendorStatusName = OutTab.VendorStatusName                  
                                                                                          ORDER BY InrTab.ID
                                                                                          FOR XML PATH(''),TYPE 
                                                                                          ).value('.','VARCHAR(MAX)') 
                                                                                         , 1,1,SPACE(0))
                                                                        FROM VendorStatusCTE OutTab
                                                                        GROUP BY OutTab.VendorStatusName;";

        private const string GetDashboardFormStatusForBuyerSQL = @"SELECT DISTINCT FormStatus.ID as FormStatusIDs,BuyerStatusName as  FormStatus
                                                                    FROM FormUserPermittedAction FUPA
                                                                    INNER JOIN FormStatus ON FormStatus.ID = FUPA.CurrentFormStatusID
                                                                    WHERE UserTypeId = @UserTypeID";


        private const string InsertDashboardUserSelectionSQL = @"DELETE SessionDashboardUserSelection WHERE LoggedInUserID = @LoggedInUserID;
                                                                        INSERT INTO [dbo].[SessionDashboardUserSelection]
                                                                                   ([LoggedInUserID]
                                                                                    ,IsVSAUser
                                                                                    ,BuyerID
                                                                                    ,VendorContactID
                                                                                    ,IsFavouriteClicked
                                                                                    ,IsSearchClicked
                                                                                   ,[DashboardStatusQueriesID]
                                                                                   ,DashboardStatusName
                                                                                    ,StatusID
                                                                                   ,[SearchGTIN]
                                                                                   ,[SearchGTINCheckDigit]
                                                                                   ,[SearchItemCode]
                                                                                   ,SearchFormID
                                                                                   ,[SearchSubmittedFromDate]
                                                                                   ,[SearchSubmittedToDate]
                                                                                   ,[CompressedUPC]
                                                                                   ,[SearchItemDescription]
                                                                                   ,[PriceLookupCode]
                                                                                   ,[SearchFormStatusId]
                                                                                   ,[searchSelectedOrganization]
                                                                                   ,[searchSelectedVendors]
                                                                                   ,[CreatedBy]
                                                                                   ,[CreatedDate]
                                                                                   ,[LastUpdatedBy]
                                                                                   ,[LastUpdatedDate])
                                                                             VALUES
                                                                                   (@LoggedInUserID
                                                                                   ,@IsVSAUser
                                                                                   ,@BuyerID
                                                                                   ,@VendorContactID
                                                                                   ,@IsFavouriteClicked
                                                                                   ,@IsSearchClicked
                                                                                   ,@DashboardStatusQueriesID
                                                                                   ,@DashboardStatusName
                                                                                   ,@StatusID
                                                                                   ,@SearchGTIN
                                                                                   ,@SearchGTINCheckDigit
                                                                                   ,@SearchItemCode
                                                                                   ,@SearchFormID
                                                                                   ,@SearchSubmittedFromDate
                                                                                   ,@SearchSubmittedToDate
                                                                                   ,@CompressedUPC
                                                                                   ,@SearchItemDescription
                                                                                   ,@PriceLookupCode
                                                                                   ,@SearchFormStatusId
                                                                                   ,@searchSelectedOrganization
                                                                                   ,@searchSelectedVendors
                                                                                   ,@CreatedBy
                                                                                   ,GETDATE()
                                                                                   ,@LastUpdatedBy
                                                                                   ,GETDATE())";

        private const string GetDashboardUserSelectionSQL = @"SELECT [LoggedInUserID]
                                                                   ,IsVSAUser    
                                                                    ,BuyerID
                                                                   ,VendorContactID
                                                                    ,IsFavouriteClicked
                                                                    ,IsSearchClicked
                                                                   ,[DashboardStatusQueriesID]
                                                                    ,DashboardStatusName
                                                                    ,StatusID
                                                                   ,[SearchGTIN]
                                                                   ,[SearchGTINCheckDigit]
                                                                   ,[SearchItemCode]
                                                                    ,SearchFormID
                                                                   ,[SearchSubmittedFromDate]
                                                                   ,[SearchSubmittedToDate]
                                                                   ,[CompressedUPC]
                                                                   ,[SearchItemDescription]
                                                                   ,[PriceLookupCode]
                                                                   ,[SearchFormStatusId]
                                                                   ,[searchSelectedOrganization]
                                                                   ,[searchSelectedVendors]
                                                                   ,[CreatedBy]
                                                                   ,[CreatedDate]
                                                                   ,[LastUpdatedBy]
                                                                   ,[LastUpdatedDate]
		                                                           FROM [SessionDashboardUserSelection] WHERE [LoggedInUserID] = @LoggedInUserID";

        private const string AddItemFormToGroupSQL = @"UPDATE ItemForm
														SET IsInGroup = 'Y'
														WHERE ID = @ItemFormID";

        private const string RemoveItemFormFromGroupSQL = @"UPDATE ItemForm
														SET IsInGroup = 'N'
														WHERE ID = @ItemFormID";

        private const string ValidateItemFormByVendorsSQL = @";WITH ItemFormVendorsCTE
	                                                            AS
	                                                            (
	                                                            SELECT VendorNumber from [dbo].[PackagingHierarchy]
	                                                            INNER JOIN [OrderablePackLevel] ON PackagingHierarchy.ID = OrderablePackLevel.PackagingHierarchyID WHERE PackagingHierarchy.ItemFormID = @ItemFormID
	                                                            UNION
	                                                            SELECT VendorNumber FROM DSDAuthRequestStore WHERE DSDAuthRequestStore.ItemFormID = @ItemFormID	                                                           
	                                                            ) 
	                                                            SELECT TOP 1 VendorNumber FROM ItemFormVendorsCTE WHERE VendorNumber NOT IN (SELECT id FROM CSVToTable(@LoggedInVendorList)) AND EXISTS(SELECT * FROM ItemFormVendorsCTE);";

        private const string GetDashboardErrorMessageListSQL = @"SELECT ItemFormError.TabName,ErrorMessage.ErrorDescription 
                                                                 FROM ItemFormError INNER JOIN ErrorMessage ON ItemFormError.ErrorCode = ErrorMessage.ErrorCode
                                                                 WHERE ItemFormError.ItemFormID = @ItemFormID";

        private const string GetDefaultFavouriteForUserTypeSQL = "  SELECT ID AS DashboardStatusNameId,StatusID,Status FROM [DashboardStatusQueries] WHERE SortOrder = (SELECT MIN(SortOrder) FROM DashboardStatusQueries) AND UserTypeID = @UserTypeID";

        private const string GetParentStatusForGTINSQL = @"select FormStatus.BuyerStatusName  from BasicItemDefinition BID 
                                                        inner join ItemForm on ItemForm.ID = BID.ItemFormID
                                                        inner join FormStatus ON FormStatus.ID = ItemForm.FormStatusID
                                                        WHERE GTIN = @GTIN AND GroupID is null AND ParentFlag = 'Y'";


        private const string GetFormActionsForItemFormSQL = @"select FormAction.ID AS FormActionID,VendorActionName,BuyerActionName,CreatedFormStatusID,CurrentFormStatusID from FormAction inner join [FormUserPermittedAction] FUPA on FUPA.FormActionID =  FormAction.ID WHERE UserTypeId = @UserTypeID AND CurrentFormStatusID = @CurrentFormStatusID and FormTypeId =1 AND FUPA.FormActionID <> 2";


    }
}
