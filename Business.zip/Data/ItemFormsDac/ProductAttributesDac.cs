﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System.Data.SqlClient;
using Dapper;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class ProductAttributesDac : BaseDac, IProductAttributesDac
    {
        public async Task<bool> SaveProductAttributes(List<ProductAttributeDto> productAttributes, int ItemFormID)
        {
            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    // Audit , delete are re-insert the new product attributes list.
                    await conn.ExecuteAsync(InsertProductAttributesAuditSQL, new { ItemFormID = ItemFormID });
                    await conn.ExecuteAsync(DeleteProductAttributesSQL, new { ItemFormID = ItemFormID });
                    if (productAttributes != null && productAttributes.Count > 0)
                    {
                        await conn.ExecuteAsync(InsertProductAttributesSQL, productAttributes);
                    }
                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }


        public async Task<int> InsertProductAttributes(List<ProductAttributeDto> productAttributes)
        {
            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    return await conn.ExecuteScalarAsync<int>(InsertProductAttributesSQL, productAttributes);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<IEnumerable<ProductAttributeDto>> GetProductAttributes(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<ProductAttributeDto>(GetProductAttributesSQL, new { @ItemFormID = ItemFormID });
            }
        }

        public async Task<IEnumerable<ProductAttributeScopingDto>> GetProductAttributesScopingDetails()
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<ProductAttributeScopingDto>(GetProductAttributesScopingSQL);
            }
        }


        public async Task<IEnumerable<ProductGroupingLinearDto>> GetFamAndRssDetails(int ItemFormID)
        {
            try
            {
                using (var conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    return await conn.QueryAsync<ProductGroupingLinearDto>(GetFamAndRssDetailsSQL, new { @ItemFormID = ItemFormID });
                }
            }
            catch (Exception ex)
            {

            }

            return null;
        }

        public async Task<string> GetPAScopingColumnValue(string tableName , string columnName , int itemFormID)
        {
            SqlConnection conn = new SqlConnection();
            string columnValue;
            try
            {
                using (conn = (SqlConnection)base.S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    string GetPAScopingColumnValueSQL = "Select " + columnName + " from " + tableName + " where ItemFormID = " + itemFormID;
                    //var value = await conn.QueryAsync<string>(GetPAScopingColumnValueSQL, new { @TableName = tableName, @ColumnName = columnName, @ItemFormID = itemFormID });
                    var value = await conn.QueryAsync<string>(GetPAScopingColumnValueSQL);
                    columnValue =  value.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw;

            }
            finally
                {
                conn.Close();
            }

            return columnValue;

        }

        private const string GetFamAndRssDetailsSQL = @"  Select distinct ChildProductGroupType , ChildProductGroupCode from productgrouping where ItemFormID = @ItemFormID and (ChildProductGroupType = 'FAM' or  ChildProductGroupType = 'RSS')";

       // private const string GetPAScopingColumnValueSQL = @"Select @ColumnName from @TableName where ItemFormID = @ItemFormID";



        private const string InsertProductAttributesSQL = @"INSERT INTO [dbo].[ProductAttribute]
           ([ItemFormID]
           ,[ProductAttributeGroupCode]
           ,[ProductAttributeGroupDescription]
           ,[ProductAttributeType]
           ,[AttributeType]
           ,[AttributeCode]
           ,[AttributeDescription]
           ,[AttributeValueSequenceNumber]
           ,[AttributeValueDisplayText]
           ,[NewAttributeValue]
           ,[NewAttributeApprovalIndicator]
           ,[NewAttributeApprovedBy]
           ,[NewAttributeApprovedDate]
           ,[EffectiveDate]
           ,[TerminationDate]
           ,[ItemGroupType]
           ,[ItemGroupCode]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     VALUES
           (@ItemFormID
           ,@ProductAttributeGroupCode
           ,@ProductAttributeGroupDescription
           ,@ProductAttributeType 
           ,@ProductAttributeType 
           ,@AttributeCode
           ,@AttributeDescription 
           ,@AttributeValueSequenceNumber
           ,@AttributeValueDisplayText
           ,@NewAttributeValue 
           ,@NewAttributeApprovalIndicator 
           ,@NewAttributeApprovedBy
           ,@NewAttributeApprovedDate 
           ,@EffectiveDate
           ,@TerminationDate
           ,@ItemGroupType
           ,@ItemGroupCode
           ,@CreatedBy
           ,getDate()
           ,@LastUpdatedBy
           ,null)";

        private const string InsertProductAttributesAuditSQL = @"INSERT INTO [dbo].[ProductAttributeAudit]
           ([Version]
           ,[ID]
           ,[ItemFormID]
           ,[ProductAttributeGroupCode]
           ,[ProductAttributeGroupDescription]
           ,[ProductAttributeType]
           ,[AttributeType]
           ,[AttributeCode]
           ,[AttributeDescription]
           ,[AttributeValueSequenceNumber]
           ,[AttributeValueDisplayText]
           ,[NewAttributeValue]
           ,[NewAttributeApprovalIndicator]
           ,[NewAttributeApprovedBy]
           ,[NewAttributeApprovedDate]
           ,[EffectiveDate]
           ,[TerminationDate]
           ,[ItemGroupType]
           ,[ItemGroupCode]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
    SELECT 
           GetDate()
		   ,ID
           ,ItemFormID
           ,ProductAttributeGroupCode
           ,ProductAttributeGroupDescription
           ,ProductAttributeType
           ,AttributeType
           ,AttributeCode
           ,AttributeDescription
           ,AttributeValueSequenceNumber
           ,AttributeValueDisplayText
           ,NewAttributeValue
           ,NewAttributeApprovalIndicator
           ,NewAttributeApprovedBy
           ,NewAttributeApprovedDate
           ,EffectiveDate
           ,TerminationDate
           ,ItemGroupType
           ,ItemGroupCode
           ,CreatedBy
           ,CreatedDate
           ,LastUpdatedBy
           ,getDate()
		   FROM [dbo].[ProductAttribute] where ItemFormID = @ItemFormID";

        private const string DeleteProductAttributesSQL = @"DELETE FROM [dbo].[ProductAttribute] WHERE 
                                        ItemFormID = @ItemFormID";


        private const string GetProductAttributesSQL = @" SELECT           
		    ID      
           ,ProductAttributeGroupCode
           ,ProductAttributeGroupDescription
           ,ProductAttributeType
           ,AttributeType
           ,AttributeCode
           ,AttributeDescription
           ,AttributeValueSequenceNumber
           ,AttributeValueDisplayText
           ,NewAttributeValue
           ,NewAttributeApprovalIndicator
           ,NewAttributeApprovedBy
           ,NewAttributeApprovedDate
           ,EffectiveDate
           ,TerminationDate
           ,ItemGroupType
           ,ItemGroupCode        
		   FROM [dbo].[ProductAttribute] where ItemFormID = @ItemFormID";

        private const string GetProductAttributesScopingSQL = @"SELECT  
             [ID]
            ,[ProductAttributeGroupCode]
            ,[ProductAttributeGroupDescription]
            ,[AttributeCode]
            ,[AttributeDescription]
            ,[TableName]
            ,[ColumnName]
            ,[ReadOnly]
            ,[Visible]
            ,[CreatedBy]
            ,[CreatedDate]
            ,[LastUpdatedBy]  
            ,[LastUpdatedDate]
        FROM [S0VPITEM].[dbo].[ProductAttributeScoping]";

    }
}
