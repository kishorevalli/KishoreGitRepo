﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Dapper;

using Publix.S0VPITEM.ItemFormsEntities;
using System.Data.SqlClient;
using System.Runtime.Caching;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public abstract class BaseDac
    {

        /// <summary>
        /// return application server environment
        /// </summary>
        public static string PublixEnvironment
        {
            get
            {
                return Environment.GetEnvironmentVariable("PublixEnvironment");
            }
        }

        /// <summary>
        /// get the DbConnection for the S0VPITEM database
        /// </summary>
        public IDbConnection S0VPITEM_Connection
        {
            get
            {
                var cs = ConfigurationManager.ConnectionStrings[PublixEnvironment + "-S0VPITEM"];
                var cf = DbProviderFactories.GetFactory(cs.ProviderName);
                var cn = cf.CreateConnection();
                cn.ConnectionString = cs.ConnectionString;
                return cn;
            }
        }

        /// <summary>
        /// get the DbConnection for the FLEX_CURRENT database
        /// </summary>
        public IDbConnection FLEX_Connection
        {
            get
            {
                var cs = ConfigurationManager.ConnectionStrings[PublixEnvironment + "-FLEX"];
                var cf = DbProviderFactories.GetFactory(cs.ProviderName);
                var cn = cf.CreateConnection();
                cn.ConnectionString = cs.ConnectionString;
                return cn;
            }
        }
        /// <summary>
        /// get the DbConnection for the S0PPMSXX database
        /// </summary>
        public IDbConnection PPMS_Connection
        {
            get
            {
                var cs = ConfigurationManager.ConnectionStrings[PublixEnvironment + "-PPMS"];
                var cf = DbProviderFactories.GetFactory(cs.ProviderName);
                var cn = cf.CreateConnection();
                cn.ConnectionString = cs.ConnectionString;
                return cn;
            }
        }
        public async Task<IEnumerable<ErrorDTO>> GetErrorMessages()
        {
            //TODO:  Disable the cache during development..Need to comment the below 2 line after DEVELOPMENT
            using (var conn = (SqlConnection)S0VPITEM_Connection)
            { return conn.QueryAsync<ErrorDTO>(GetErrorMessagesSQL).Result; }

            var CacheKey = "ItemForm_ErrorMessages";

            var itemFormErrorMessages = (List<ErrorDTO>)MemoryCache.Default[CacheKey];

            if (itemFormErrorMessages == null)
            {


                 using (var conn = (SqlConnection)S0VPITEM_Connection)
                {
                    await conn.OpenAsync();
                    itemFormErrorMessages = (List<ErrorDTO>)conn.QueryAsync<ErrorDTO>(GetErrorMessagesSQL).Result;
                    MemoryCache.Default.Add(CacheKey, itemFormErrorMessages, DateTime.Now.AddDays(1));
                }
            }
            return itemFormErrorMessages;
        }
       

        // TODO it should be moved  to new controller Common Controller
        public Boolean RemoveItemFormCache(String CacheKey)
        {
            if (MemoryCache.Default.Contains(CacheKey))
            { 
                MemoryCache.Default.Remove(CacheKey);
                return true;
            }
            return false;
        }

        private const string GetErrorMessagesSQL = @"SELECT ErrorCode,ErrorDescription,TabName,ControlName,SeverityLevel FROM ErrorMessage";

    }
}
