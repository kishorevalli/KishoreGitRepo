﻿using Publix.S0VPITEM.ItemFormsDac.Contracts;
using Publix.S0VPITEM.ItemFormsEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;

namespace Publix.S0VPITEM.ItemFormsDac
{


    public class ShipperItemCompositionDac : BaseDac, IShipperItemCompositionDac
    {       
        public async Task<bool> SaveShipperCompositionItems(ShipperItemCompositionDto ShipperItemComposition)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(SaveShipperCompositionItemsSQL, ShipperItemComposition);
            }

            bSuccess = true;
            return bSuccess;
        }


        public async Task<bool> InsertShipperCompositionItem(ShipperItemCompositionDto ShipperItemComposition)
        {
            bool bSuccess = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                //await conn.OpenAsync();
                conn.Open();                
                conn.Execute(InsertShipperCompositionItemSQL, ShipperItemComposition);                
            }           

            bSuccess = true;
            return bSuccess;
        }

        public async Task<bool> DeleteShipperCompositionItem(ShipperItemCompositionDto ShipperItemComposition)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(DeleteShipperCompositionItemSQL, ShipperItemComposition);
            }

            bSuccess = true;
            return bSuccess;
        }

        public async Task<bool> DeleteAllShipperCompositionItems(int ItemFormID)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(DeleteAllShipperCompositionItemsSQL, new { @ItemFormID = ItemFormID });
            }

            bSuccess = true;
            return bSuccess;
        }

        //

        public async Task<IEnumerable<ShipperItemCompositionDto>> GetShipperCompositionItems(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                //conn.OpenAsync();
                conn.Open();
                IEnumerable<ShipperItemCompositionDto> ShipperItemCompositions = conn.Query<ShipperItemCompositionDto>(GetShipperCompositionItemsSQL, new { @ItemFormID = ItemFormID });
                return ShipperItemCompositions;
            }
        }

        public async Task<int> GetCaseType(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();   
                return await conn.QueryFirstOrDefaultAsync<int>(GetCaseTypeSQL, new { @ItemFormID = ItemFormID });
            }
        }

        public async Task<int> GetShipperSubDepartmentCode(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryFirstOrDefaultAsync<int>(GetShipperSubDepartmentCodeSQL, new { @ItemFormID = ItemFormID });
            }
        }

        public async Task<int> GetProductGroupingSubDepartmentCode(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryFirstOrDefaultAsync<int>(GetProductGroupingSubDepartmentCodeSQL, new { @ItemFormID = ItemFormID });
            }
        }

        public async Task<int> DeleteShipperItemCompositionList(int ItemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryFirstOrDefaultAsync<int>(DeleteShipperItemCompositionListSQL, new { @ItemFormID = ItemFormID });
            }
        } 

        public async Task<IEnumerable<ShipperItemCompositionDto>> CheckShipperItemCompositionGTINExistInItemForm(decimal CompositionGTIN)
        {  
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {    
                     //conn.OpenAsync();
                    conn.Open();
                IEnumerable<ShipperItemCompositionDto> ShipperItemCompositions =  conn.Query<ShipperItemCompositionDto>(CheckShipperItemCompositionGTINExistInItemFormSQL, new { @CompositionGTIN = CompositionGTIN });
                    return ShipperItemCompositions;                
               
            }
            
        }


        #region Queries 


        private const string GetShipperCompositionItemsSQL = @"SELECT            
[ItemFormID]
,[CompositionItemCode]
,[CompositionItemDescription]
,CompositionItemTypeCode
,[CompositionGTIN]
,[CompositionGTINCheckDigit]
,[Quantity]
,[CompositionUOM]
,[CompositionUOMDescription]
,ItemForm.CreatedBy
,ItemForm.CreatedDate
,ItemForm.LastUpdatedBy
,ItemForm.LastUpdatedDate
,SubDepartmentID
,SubDepartment
FROM ShipperItemComposition
INNER JOIN ItemForm ON ItemForm.ID = ShipperItemComposition.ItemFormID
INNER JOIN FormStatus ON FormStatus.ID = ItemForm.FormStatusID
WHERE ItemForm.FormStatusID <> 2 AND ItemFormID = @ItemFormID";


        private const string DeleteAllShipperCompositionItemsSQL = @"INSERT INTO [dbo].[ShipperItemCompositionAudit]
           ([Version]
           ,[ItemFormID]
            ,[CompositionItemCode]
		   ,[CompositionItemDescription]
            ,CompositionItemTypeCode
		   ,[CompositionGTIN]
		   ,[CompositionGTINCheckDigit]
		   ,[Quantity]
		   ,[CompositionUOM]
		   ,[CompositionUOMDescription]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     SELECT 
            GETDATE()           
		   ,[ItemFormID]
		   ,[CompositionItemCode]
		   ,[CompositionItemDescription]
            ,CompositionItemTypeCode
		   ,[CompositionGTIN]
		   ,[CompositionGTINCheckDigit]
		   ,[Quantity]
		   ,[CompositionUOM]
		   ,[CompositionUOMDescription]
		   ,[CreatedBy]
		   ,[CreatedDate]
		   ,[LastUpdatedBy]
		   ,[LastUpdatedDate]
		   FROM ShipperItemComposition
			WHERE ItemFormID = @ItemFormID 

            DELETE ShipperItemComposition WHERE ItemFormID = @ItemFormID ";

        private const string InsertShipperCompositionItemSQL = @"INSERT INTO [dbo].[ShipperItemComposition]
           ([ItemFormID]
            ,[CompositionItemCode]
		   ,[CompositionItemDescription]
            ,CompositionItemTypeCode
		   ,[CompositionGTIN]
		   ,[CompositionGTINCheckDigit]
		   ,[Quantity]
		   ,[CompositionUOM]
		   ,[CompositionUOMDescription]
            ,SubDepartmentID
            ,SubDepartment
           ,[CreatedBy]
           ,[CreatedDate]

           )
           VALUES(@ItemFormID
                    , @CompositionItemCode
                    , @CompositionItemDescription
                    , @CompositionItemTypeCode
                    , @CompositionGTIN
                    , @CompositionGTINCheckDigit
                    , @Quantity
                    , @CompositionUOM
                    , @CompositionUOMDescription
                    , @SubDepartmentID
                    , @SubDepartment
                    , @CreatedBy
                    , @CreatedDate)";  

        private const string DeleteShipperCompositionItemSQL = @"INSERT INTO [dbo].[ShipperItemCompositionAudit]
           ([Version]
           ,[ItemFormID]
            ,[CompositionItemCode]
		   ,[CompositionItemDescription]
            ,CompositionItemTypeCode
		   ,[CompositionGTIN]
		   ,[CompositionGTINCheckDigit]
		   ,[Quantity]
		   ,[CompositionUOM]
		   ,[CompositionUOMDescription]
            ,SubDepartmentID
            ,SubDepartment
           ,[CreatedBy]
           ,[CreatedDate]
           ,[LastUpdatedBy]
           ,[LastUpdatedDate])
     SELECT
            GETDATE()
		   ,[ItemFormID]
		    ,[CompositionItemCode]
		   ,[CompositionItemDescription]
            ,CompositionItemTypeCode
		   ,[CompositionGTIN]
		   ,[CompositionGTINCheckDigit]
		   ,[Quantity]
		   ,[CompositionUOM]
		   ,[CompositionUOMDescription]
           , SubDepartmentID
           , SubDepartment
		   ,[CreatedBy]
		   ,[CreatedDate]
		   ,[LastUpdatedBy]
		   ,[LastUpdatedDate]
        FROM ShipperItemComposition
        WHERE ItemFormID = @ItemFormID AND CompositionGTIN = @CompositionGTIN

         DELETE ShipperItemComposition
         FROM ShipperItemComposition
         WHERE ItemFormID = @ItemFormID AND CompositionGTIN = @CompositionGTIN ";


        private const string CheckShipperItemCompositionGTINExistInItemFormSQL = @"SELECT 
			BID.GTIN as CompositionGTIN
			,BID.GTINCheckDigit as CompositionGTINCheckDigit
            ,BID.ItemTypeCode as CompositionItemTypeCode            
			,BID.CreatedBy
			,BID.CreatedDate
            , 11 as SubDepartmentID
            , 'DRY GROCERY' as SubDepartment
			from BasicItemDefinition BID
			INNER JOIN ItemForm ON ItemForm.ID = BID.ItemFormID
			INNER JOIN FormStatus ON FormStatus.ID = ItemForm.FormStatusID
			 WHERE ItemForm.FormStatusID NOT IN (1,2,8,18,19) AND BID.GTIN = @CompositionGTIN
			--status Draft ,Deleted ,Rejected ,Cancellation Requested ,Cancellation Approved "; 


        private const string SaveShipperCompositionItemsSQL = @"
            INSERT INTO [dbo].[ShipperItemCompositionAudit]
                       ([Version]
                       ,[ItemFormID]
                        ,[CompositionItemCode]
		               ,[CompositionItemDescription]
                        ,CompositionItemTypeCode
		               ,[CompositionGTIN]
		               ,[CompositionGTINCheckDigit]
		               ,[Quantity]
		               ,[CompositionUOM]
		               ,[CompositionUOMDescription]
                        , SubDepartmentID
                        , SubDepartment
                       ,[CreatedBy]
                       ,[CreatedDate]
                       ,[LastUpdatedBy]
                       ,[LastUpdatedDate])
                 SELECT 
                        GETDATE()           
		               ,[ItemFormID]
		                ,[CompositionItemCode]
		               ,[CompositionItemDescription]
                        ,CompositionItemTypeCode
		               ,[CompositionGTIN]
		               ,[CompositionGTINCheckDigit]
		               ,[Quantity]
		               ,[CompositionUOM]
		               ,[CompositionUOMDescription]
                        , SubDepartmentID
                        , SubDepartment
		               ,[CreatedBy]
		               ,[CreatedDate]
		               ,[LastUpdatedBy]
		               ,[LastUpdatedDate]
		               FROM ShipperItemComposition
			            WHERE ItemFormID = @ItemFormID AND CompositionGTIN = @CompositionGTIN ;


            UPDATE ShipperItemComposition 
            SET
            ItemFormID = @ItemFormID
            ,CompositionItemCode  = @CompositionItemCode
            ,CompositionItemDescription  = @CompositionItemDescription
            ,CompositionItemTypeCode = @,CompositionItemTypeCode
            ,CompositionGTIN  = @CompositionGTIN
            ,CompositionGTINCheckDigit  = @CompositionGTINCheckDigit
            ,Quantity  = @Quantity
            ,CompositionUOM  = @CompositionUOM
            ,CompositionUOMDescription  = @CompositionUOMDescription
            , SubDepartmentID = @SubDepartmentID
            , SubDepartment = @SubDepartment
            ,LastUpdatedBy  = @LastUpdatedBy
            ,LastUpdatedDate  = @LastUpdatedDate
             FROM ShipperItemComposition
             WHERE ItemFormID = @ItemFormID AND CompositionGTIN = @CompositionGTIN;";

        private const string GetCaseTypeSQL = @"SELECT ItemCaseTypeID as CaseTypeCode FROM BasicItemDefinition WHERE ItemFormID = @ItemFormID";

        private const string GetShipperSubDepartmentCodeSQL = @"SELECT TOP 1 SubDepartmentID FROM ShipperItemComposition where ItemFormID = @ItemFormID";

        private const string GetProductGroupingSubDepartmentCodeSQL = @"SELECT TOP 1 SUBSTRING(CONVERT(varchar(10), ChildProductGroupCode) ,1,2) as ProductGroupingSubDeptCode FROM ProductGrouping WHERE ItemFormID = @ItemFormID";

        private const string DeleteShipperItemCompositionListSQL = @"DELETE ShipperItemComposition where ItemFormID = @ItemFormID";       



        #endregion

    }

}
