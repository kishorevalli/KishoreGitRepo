﻿using Publix.S0VPITEM.ItemFormsDac.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Publix.S0VPITEM.ItemFormsEntities;
using System.Data.SqlClient;
using Dapper;
using FastMember;

namespace Publix.S0VPITEM.ItemFormsDac
{
    public class DsdAuthorizationRequestDac : BaseDac, IDsdAuthorizationRequestDac
    {
        public async Task<bool> SaveDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList)
        {
            bool bSuccess = false;
                       

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                int itemFromId = dsdAuthRequestStoreDtoList.Select(x => x.ItemFormID).FirstOrDefault();

                await conn.ExecuteAsync(SaveDsdVendorStoreAuthorizationAuditSQL, new { ItemFormID = itemFromId });

                await conn.ExecuteAsync(SaveDsdVendorStoreAuthorizationSQL, dsdAuthRequestStoreDtoList);

            }

            bSuccess = true;

            return bSuccess;
        }

        public async Task SaveDsdVendorStoreAuthorization(DsdAuthRequestStoreDto dsdAuthRequestStoreDto)
        {        
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
               

                await conn.ExecuteAsync(SaveDsdVendorStoreAuthorizationAuditSQL, new { ItemFormID = dsdAuthRequestStoreDto.ItemFormID });

                await conn.ExecuteAsync(SaveDsdVendorStoreAuthorizationSQL, dsdAuthRequestStoreDto);

            }
          
        }
        public async Task<IEnumerable<DsdVendorAuthorizationDto>> GetDsdVendorAuthorizations(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<DsdVendorAuthorizationDto>(GetDsdVendorAuthorizationSQL, new { ItemFormID = itemFormID }));
            }
        }

        public async Task<bool> DeleteDsdVendorAuthorizationsByItemForm(int itemFormID)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(SaveDsdVendorStoreAuthorizationAuditSQL, new { ItemFormID = itemFormID });
                await conn.ExecuteAsync(DeleteDsdVendorAuthorizationsByItemFormSQL, new { ItemFormID = itemFormID });
                bSuccess = true;
            }

            return bSuccess;
        }

        public async Task<bool> DeleteDsdVendorAuthorizationsByItemFormAndVendors(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            bool bSuccess = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                await conn.ExecuteAsync(SaveDsdVendorStoreAuthorizationAuditSQL, dsdVendorStoreAuthorizationDto);
                await conn.ExecuteAsync(DeleteDsdVendorAuthorizationsByItemFormAndVendorsSQL, dsdVendorStoreAuthorizationDto);
                bSuccess = true;
            }

            return bSuccess;
        }

        public async Task<bool> BulkInsertDsdVendorStoreAuthorization(IEnumerable<DsdAuthRequestStoreDto> dsdAuthRequestStoreDtoList)
        {
            bool bSuccess = false;
            string tableName = "[dbo].[DSDAuthRequestStore]";
            
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                int itemFromId = dsdAuthRequestStoreDtoList.Select(x => x.ItemFormID).FirstOrDefault();

                await conn.ExecuteAsync(SaveDsdVendorStoreAuthorizationAuditSQL, new { ItemFormID = itemFromId });
                
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                {
                    using (var reader = ObjectReader.Create(dsdAuthRequestStoreDtoList, new DsdAuthRequestStoreDto().GetType().GetProperties().Where(x => x.Name != "IsDirty" && x.Name != "ItemFormDisplayID").Select(p => p.Name).ToArray()))
                    {
                        bulkCopy.BatchSize = 5000;
                        bulkCopy.DestinationTableName = tableName;
                        await bulkCopy.WriteToServerAsync(reader);
                    }
                }
                bSuccess = true;
            }
            return bSuccess;
        }

        public async Task<bool> DeleteDsdVendorsNotInPackagingHierarchy(int itemFormID)
        {

            bool retValue = false;
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    await conn.ExecuteAsync(DeleteDsdVendorsAuditSql, new { ItemFormID = itemFormID });
                    await conn.ExecuteAsync(DeleteDsdVendorsSql, new { ItemFormID = itemFormID });
                    retValue = true;
                }
                catch (Exception ex)
                {
                    throw ex;
                }


            }
            return retValue;
        }
        public async Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdVendorsByItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<DsdVendorAuthorizationDto>(GetAuthorizedDsdVendorsByItemFormSQL, new { ItemFormID = itemFormID }));
            }
        }

        public async Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdStatesByItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<DsdVendorAuthorizationDto>(GetAuthorizedDsdStatesByItemFormSQL, new { ItemFormID = itemFormID }));
            }
        }

        public async Task<IEnumerable<DsdVendorAuthorizationDto>> GetAuthorizedDsdCountiesByItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<DsdVendorAuthorizationDto>(GetAuthorizedDsdCountiesByItemFormSQL, new { ItemFormID = itemFormID }));
            }
        }

        public async Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdVendorStoreAuthorizationsByItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return (await conn.QueryAsync<DsdAuthRequestStoreDto>(GetDsdVendorStoreAuthorizationsByItemFormSQL, new { ItemFormID = itemFormID }));
            }
        }


        public async Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdVendorStoreAuthorizationsBySearchCriteria(VendorServiceDto vendorServiceDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                string filterSQL = string.Empty;

                string searchSQL = string.Empty;

                if (vendorServiceDto.VendorNumber.HasValue)
                {
                    filterSQL += " AND VendorNumber = @VendorNumber";
                }
                if (vendorServiceDto.StoreNumber.HasValue)
                {
                    filterSQL += " AND StoreNumber = @StoreNumber";
                }
                if (!string.IsNullOrEmpty(vendorServiceDto.StateCode))
                {
                    filterSQL += " AND StateCode = @StateCode";
                }
                if (!string.IsNullOrEmpty(vendorServiceDto.CountyCode))
                {
                    filterSQL += " AND CountyCode = @CountyCode";
                }
                if (!string.IsNullOrEmpty(vendorServiceDto.IsActive))
                {
                    filterSQL += " AND IsActive = @IsActive";
                }
                if (vendorServiceDto.IsOnlyOverlappedAuth)
                {
                    filterSQL += " AND EXISTS ( SELECT [StoreNumber] FROM [dbo].[DSDAuthRequestStore] t2 WHERE t2.ItemFormID = t1.ItemFormID AND t2.StoreNumber = t1.StoreNumber AND t2.IsActive = 'Y' GROUP BY [StoreNumber],[IsActive] HAVING COUNT(*) > 1 )";                    
                }

                searchSQL = GetDsdVendorStoreAuthorizationsBySearchCriteriaSQL + filterSQL + " ORDER BY [StoreNumber], [VendorNumber] ";
                return (await conn.QueryAsync<DsdAuthRequestStoreDto>(searchSQL, vendorServiceDto));
            }
        }


        public async Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdOverlappedVendorStoreAuthorizationsByItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                
                return (await conn.QueryAsync<DsdAuthRequestStoreDto>(GetDsdOverlappedVendorStoreAuthorizationsByItemFormSQL, new { ItemFormID = itemFormID }));
            }
        }

        public async Task<bool> IsOverlappedVendorStoreAuthExistsByItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                int rowCount = await conn.ExecuteScalarAsync<int>(IsOverlappedVendorStoreAuthExistsByItemFormSQL, new { ItemFormID = itemFormID });

                return (rowCount > 0 ? true : false);
            }
        }


        public async Task<bool> IsMultipleDsdVendorsSubmittingSameGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                int rowCount = await conn.ExecuteScalarAsync<int>(IsMultipleDsdVendorSubmittingSameGtinSQL, dsdVendorStoreAuthorizationDto);

                return (rowCount > 0 ? true : false);
            }
        }

        public async Task<bool> IsOverlappedVendorStoreAuthExistsByGtin(DsdVendorStoreAuthorizationDto dsdVendorStoreAuthorizationDto)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                int rowCount = await conn.ExecuteScalarAsync<int>(IsOverlappedVendorStoreAuthExistsByGtinSQL, dsdVendorStoreAuthorizationDto);

                return (rowCount > 0 ? true : false);
            }
        }

        public async Task<IEnumerable<DsdAuthRequestStoreDto>> GetDsdOverlappedVendorStoreAuthorizationsByGtin(decimal gtin)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();

                return (await conn.QueryAsync<DsdAuthRequestStoreDto>(GetDsdOverlappedVendorStoreAuthorizationsByGtinSQL, new { GTIN = gtin }));
            }
        }

        public async Task<bool> SaveBasicItemDefinition(BasicItemDefinitionDto basicItemDefinitionDto)
        {
            bool retValue = false;

            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                try
                {
                    //TODO implement Transaction scope                    
                    
                    //TODO : update item form should be called from common
                    //await conn.ExecuteAsync(UpdateItemFormSQL, basicItemDefinitionDto);
                    await conn.ExecuteAsync(AuditBasicItemFormDefnitionSQL, basicItemDefinitionDto);
                    await conn.ExecuteAsync(MergeBasicItemFormDefnitionSQL, basicItemDefinitionDto);


                    retValue = true;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return retValue;
        }

        public async Task<BasicItemDefinitionDto> GetBasicItemDefinitionData(long itemFormDisplayID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {

                await conn.OpenAsync();
                BasicItemDefinitionDto basicItemDefinitionDto = await conn.QueryFirstOrDefaultAsync<BasicItemDefinitionDto>(GetBasicItemDefinitionDataSQL, new { @ItemFormDisplayID = itemFormDisplayID });
               
                return basicItemDefinitionDto;
            }
        }
        public async Task<IEnumerable<VendorDomainDto>> GetDsdVendorsExistForItemForm(int itemFormID)
        {
            using (var conn = (SqlConnection)base.S0VPITEM_Connection)
            {
                await conn.OpenAsync();
                return await conn.QueryAsync<VendorDomainDto>(GetDsdVendorsExistForItemFormSQL, new { ItemFormID = itemFormID });
            }
        }
        #region Queries

        private const string SaveDsdVendorStoreAuthorizationSQL = @"MERGE [dbo].[DSDAuthRequestStore] AS target
	        USING(
	        SELECT
	          @ItemFormID AS ItemFormID
	        , @VendorNumber AS VendorNumber
	        , @VendorName AS VendorName
	        , @StoreNumber AS StoreNumber
            , @StateCode AS StateCode
            , @StateName AS StateName
            , @CountyCode AS CountyCode
            , @CountyName AS CountyName
	        , @IsActive As IsActive
	        , @CreatedBy AS CreatedBy
	        , getdate() AS CreatedDate
	        , @LastUpdatedBy AS LastUpdatedBy
	        , getdate() AS LastUpdatedDate)
	        AS source
              ON  1=1 AND target.[ItemFormID] = source.[ItemFormID]  AND target.[VendorNumber] = source.[VendorNumber]  AND target.[StoreNumber] = source.[StoreNumber]                                         
            WHEN MATCHED THEN
	            UPDATE
	            SET 
	            [IsActive] = source.IsActive
	            ,[LastUpdatedBy] = source.LastUpdatedBy
	            ,[LastUpdatedDate] = source.LastUpdatedDate
            WHEN NOT MATCHED BY TARGET THEN
            INSERT 
                ([ItemFormID]
                ,[VendorNumber]
                ,[VendorName]
                ,[StoreNumber]
                ,[StateCode]
                ,[StateName]
                ,[CountyCode]
                ,[CountyName]
                ,[IsActive]
                ,[CreatedBy]
                ,[CreatedDate])
            VALUES
                (source.ItemFormID
                , source.VendorNumber
                , source.VendorName
                , source.StoreNumber
                , source.StateCode
                , source.StateName
                , source.CountyCode
                , source.CountyName
                , source.IsActive
                , source.CreatedBy
                , source.CreatedDate);";

        private const string SaveDsdVendorStoreAuthorizationAuditSQL = @"
                            INSERT INTO [dbo].[DSDAuthRequestStoreAudit]
                                ([Version]
                                ,[ItemFormID]
                                ,[VendorNumber]
                                ,[VendorName]
                                ,[StoreNumber]
                                ,[StateCode]
                                ,[StateName]
                                ,[CountyCode]
                                ,[CountyName]
                                ,[IsActive]
                                ,[CreatedBy]
                                ,[CreatedDate]
                                ,[LastUpdatedBy]
                                ,[LastUpdatedDate])
                        SELECT 
                                getdate()
                                ,[ItemFormID]
                                ,[VendorNumber]
                                ,[VendorName]
                                ,[StoreNumber]
                                ,[StateCode]
                                ,[StateName]
                                ,[CountyCode]
                                ,[CountyName]
                                ,[IsActive]
                                ,[CreatedBy]
                                ,[CreatedDate]
                                ,[LastUpdatedBy]
                                ,[LastUpdatedDate]
                        FROM [dbo].[DSDAuthRequestStore]
                        WHERE [ItemFormID] = @ItemFormID";

        private const string GetDsdVendorAuthorizationSQL = @"
                    SELECT  ItemFormID, VendorNumber, VendorName, COUNT(*) AS NoOfStores FROM [dbo].[DSDAuthRequestStore] 
                    WHERE ItemFormID = @ItemFormID AND IsActive='Y'
                    GROUP BY  ItemFormID, VendorNumber, VendorName
                    ORDER BY VendorNumber
            ";

        private const string GetAuthorizedDsdVendorsByItemFormSQL = @"
                     SELECT DISTINCT [VendorNumber], [VendorName]
                        FROM [dbo].[DSDAuthRequestStore] 
                     WHERE ItemFormID = @ItemFormID ORDER BY [VendorNumber]
            ";

        private const string GetAuthorizedDsdStatesByItemFormSQL = @"
                        SELECT DISTINCT [StateCode] , [StateName]
                        FROM [dbo].[DSDAuthRequestStore] 
                        WHERE ItemFormID = @ItemFormID 
                        ORDER BY [StateName]
            ";

        private const string GetAuthorizedDsdCountiesByItemFormSQL = @"
                     SELECT DISTINCT [CountyCode], [CountyName]
                        FROM [dbo].[DSDAuthRequestStore]
                     WHERE ItemFormID = @ItemFormID 
                    ORDER BY [CountyName]
            ";

        private const string GetDsdVendorStoreAuthorizationsByItemFormSQL = @"
                    SELECT
                    [ItemFormID]
                    ,[VendorNumber]
                    ,[VendorName]
                    ,[StoreNumber]
                    ,[StateCode]
                    ,[StateName]
                    ,[CountyCode]
                    ,[CountyName]
                    ,[IsActive]
                    FROM [dbo].[DSDAuthRequestStore] 
                    WHERE ItemFormID = @ItemFormID
                    ORDER BY [StoreNumber], [VendorNumber] ";

        private const string GetDsdVendorStoreAuthorizationsBySearchCriteriaSQL = @"
                   SELECT
                        [ItemFormID]
                        ,[VendorNumber]
                        ,[VendorName]
                        ,[StoreNumber]
                        ,[StateCode]
                        ,[StateName]
                        ,[CountyCode]
                        ,[CountyName]
                        ,[IsActive]
                    FROM [dbo].[DSDAuthRequestStore] t1
                    WHERE ItemFormID = @ItemFormID	";

        private const string GetDsdOverlappedVendorStoreAuthorizationsByItemFormSQL = @"
                   SELECT
                        [ItemFormID]
                        ,[VendorNumber]
                        ,[VendorName]
                        ,[StoreNumber]
                        ,[StateCode]
                        ,[StateName]
                        ,[CountyCode]
                        ,[CountyName]
                        ,[IsActive]
                    FROM [dbo].[DSDAuthRequestStore] t1
                    WHERE ItemFormID = @ItemFormID
                    AND EXISTS ( SELECT [StoreNumber] FROM [dbo].[DSDAuthRequestStore] t2 WHERE t2.ItemFormID = t1.ItemFormID
                    AND t2.StoreNumber = t1.StoreNumber AND t2.IsActive = 'Y' GROUP BY [StoreNumber],[IsActive] HAVING COUNT(*) > 1 )
                    ORDER BY [StoreNumber], [VendorNumber] 	";

        private const string IsOverlappedVendorStoreAuthExistsByItemFormSQL = @"
                   SELECT
                       COUNT(*)
                    FROM [dbo].[DSDAuthRequestStore] t1
                    WHERE ItemFormID = @ItemFormID
                    AND EXISTS ( SELECT [StoreNumber] FROM [dbo].[DSDAuthRequestStore] t2 WHERE t2.ItemFormID = t1.ItemFormID
                    AND t2.StoreNumber = t1.StoreNumber AND t2.IsActive = 'Y' GROUP BY [StoreNumber],[IsActive] HAVING COUNT(*) > 1 ) ";

        private const string IsMultipleDsdVendorSubmittingSameGtinSQL = @"
                    SELECT COUNT(*) FROM [dbo].[ItemForm] IFM
                    INNER JOIN [dbo].[BasicItemDefinition] BID ON IFM.ID = BID.ItemFormID
                    WHERE BID.GTIN = @GTIN AND IFM.ID != @ItemFormID AND IFM.FormStatusID = 4
                        AND EXISTS(     SELECT [ItemFormID]  FROM [dbo].[DSDAuthRequestStore] DSD WHERE DSD.ItemFormID = IFM.ID) ";

        private const string IsOverlappedVendorStoreAuthExistsByGtinSQL = @"
                SELECT COUNT(*) FROM [dbo].[ItemForm] IFM
                INNER JOIN [dbo].[BasicItemDefinition] BID1 ON IFM.ID = BID1.ItemFormID
                WHERE BID1.GTIN = @GTIN AND BID1.ItemFormID != @ItemFormID AND IFM.FormStatusID = 4
                AND EXISTS( 
                    SELECT 1  FROM [dbo].[DSDAuthRequestStore] DSD
                    INNER JOIN [dbo].[BasicItemDefinition] BID2 ON DSD.ItemFormID = BID2.ItemFormID
                    INNER JOIN [dbo].[ItemForm] IFM ON BID1.ItemFormID = IFM.ID	
                    WHERE BID2.GTIN = BID1.GTIN AND IFM.FormStatusID NOT IN(2,8)
                    AND DSD.IsActive = 'Y' GROUP BY [StoreNumber],[IsActive] HAVING COUNT(*) > 1 
                )";
        private const string GetDsdOverlappedVendorStoreAuthorizationsByGtinSQL = @"
                   SELECT  DSD1.[ItemFormID]
                ,IFM.ItemFormDisplayID 
                ,[VendorNumber]
                ,[VendorName]
                ,[StoreNumber]
                ,[StateCode]
                ,[StateName]
                ,[CountyCode]
                ,[CountyName]
                ,[IsActive]
                FROM [dbo].[DSDAuthRequestStore] DSD1					
                INNER JOIN [dbo].[BasicItemDefinition] BID1 ON DSD1.ItemFormID = BID1.ItemFormID					
               INNER JOIN [dbo].[ItemForm] IFM ON BID1.ItemFormID = IFM.ID					
                WHERE BID1.GTIN = @GTIN AND IFM.FormStatusID NOT IN(2,8)
                AND EXISTS( 
	                SELECT 1  FROM [dbo].[DSDAuthRequestStore] DSD2
	                INNER JOIN [dbo].[BasicItemDefinition] BID2 ON DSD2.ItemFormID = BID2.ItemFormID
	                WHERE BID2.GTIN = BID1.GTIN AND DSD2.StoreNumber = DSD1.StoreNumber
	                AND DSD2.IsActive = 'Y' GROUP BY [StoreNumber],[IsActive] HAVING COUNT(*) > 1 
                ) 
                ORDER BY [StoreNumber], [VendorNumber]";



        private const string MergeBasicItemFormDefnitionSQL = @"
        MERGE [BasicItemDefinition] AS target
USING (SELECT @ItemFormID  AS ItemFormID ,	@ItemTypeCode  AS ItemTypeCode ,	@ItemTypeDescription  AS ItemTypeDescription ,	@AutoGenerateType4GTIN AS AutoGenerateType4GTIN, @GTIN  AS GTIN ,	@GTINCheckDigit AS GTINCheckDigit,
@ExistingGTINIndicator AS ExistingGTINIndicator,	@CompressedUPC  AS CompressedUPC ,	@PriceLookupCode AS PriceLookupCode,	@ReUseItemCode  AS ReUseItemCode ,	
@ReUseItemDescription AS ReUseItemDescription,	@SubmissionReasonID AS SubmissionReasonID,	@ItemCaseTypeID  AS ItemCaseTypeID ,	@RecipeRequired AS RecipeRequired,	
@IngredientItemRequired AS IngredientItemRequired,	@ModelProductItemCode  AS ModelProductItemCode ,	@ModelProductItemDescription  AS ModelProductItemDescription ,@ModelProductItemTypeCode AS ModelProductItemTypeCode,	
@ModelPackagingItemCode AS ModelPackagingItemCode,	@ModelPackagingItemDescription AS ModelPackagingItemDescription, @ModelPackagingItemTypeCode AS ModelPackagingItemTypeCode,	@VendorItemCode  AS VendorItemCode ,	
@VendorItemDescription  AS VendorItemDescription ,	@ItemDescription  AS ItemDescription ,	@Brand  AS Brand ,	@Manufacturer  AS Manufacturer ,	
@RetailPackagedItem AS RetailPackagedItem,	@RetailPackType  AS RetailPackType ,	@RetailPackTypeDescription  AS RetailPackTypeDescription ,	
@RetailPackSize  AS RetailPackSize ,	@Size  AS Size ,	@SizeUOM  AS SizeUOM ,	@SizeUOMDescription  AS SizeUOMDescription ,	
@MinorityManufacturer AS MinorityManufacturer,	@PackageDescription AS PackageDescription,	@ContainerType  AS ContainerType ,	
@LabelAmount  AS LabelAmount ,	@PerpetualInventoryFlag  AS PerpetualInventoryFlag ,	@ReceiptDescription  AS ReceiptDescription ,	
@AdDescription  AS AdDescription ,	@ProductCatalogShortDescription1 AS ProductCatalogShortDescription1,	 @ProductCatalogShortDescription2   AS ProductCatalogShortDescription2 ,
@NonDiscountable  AS NonDiscountable ,	@AdditionalGTINPresent  AS AdditionalGTINPresent ,	@CreatedBy  AS CreatedBy ,	
@LastUpdatedBy  AS LastUpdatedBy ,	@LastScanDate AS LastScanDate
) AS source
ON		1=1 AND target.[ItemFormID] = source.[ItemFormID]
WHEN MATCHED THEN
    UPDATE 
   SET [ItemTypeCode] = source.ItemTypeCode
      , [ItemTypeDescription] = source.ItemTypeDescription
      , [AutoGenerateType4GTIN] = source.AutoGenerateType4GTIN
      , [GTIN] = source.GTIN
      , [GTINCheckDigit] = source.GTINCheckDigit
      , [ExistingGTINIndicator] = source.ExistingGTINIndicator
      , [CompressedUPC] = source.CompressedUPC
      , [PriceLookupCode] = source.PriceLookupCode
      , [ReUseItemCode] = source.ReUseItemCode
      , [ReUseItemDescription] = source.ReUseItemDescription
      , [SubmissionReasonID] = source.SubmissionReasonID
      , [ItemCaseTypeID] = source.ItemCaseTypeID
      , [RecipeRequired] = source.RecipeRequired
      , [IngredientItemRequired] = source.IngredientItemRequired
      , [ModelProductItemCode] = source.ModelProductItemCode
      , [ModelProductItemDescription] = source.ModelProductItemDescription
       , [ModelProductItemTypeCode]  = source.ModelProductItemTypeCode
      , [ModelPackagingItemCode] = source.ModelPackagingItemCode
      , [ModelPackagingItemDescription] = source.ModelPackagingItemDescription
        ,[ModelPackagingItemTypeCode] = source.ModelPackagingItemTypeCode
      , [VendorItemCode] = source.VendorItemCode
      , [VendorItemDescription] = source.VendorItemDescription
      , [ItemDescription] = source.ItemDescription
      , [Brand] = source.Brand
      , [Manufacturer] = source.Manufacturer
      , [RetailPackagedItem] = source.RetailPackagedItem
      , [RetailPackType] = source.RetailPackType
      , [RetailPackTypeDescription] = source.RetailPackTypeDescription
      , [RetailPackSize] = source.RetailPackSize
      , [Size] = source.Size
      , [SizeUOM] = source.SizeUOM
      , [SizeUOMDescription] = source.SizeUOMDescription
      , [MinorityManufacturer] = source.MinorityManufacturer
      , [PackageDescription] = source.PackageDescription
      , [ContainerType] = source.ContainerType
      , [LabelAmount] = source.LabelAmount
      , [PerpetualInventoryFlag] = source.PerpetualInventoryFlag
      , [ReceiptDescription] = source.ReceiptDescription
      , [AdDescription] = source.AdDescription
      , [ProductCatalogShortDescription1] = source.ProductCatalogShortDescription1
      , [ProductCatalogShortDescription2] = source.ProductCatalogShortDescription2
      , [NonDiscountable] = source.NonDiscountable
      , [AdditionalGTINPresent] = source.AdditionalGTINPresent
      , [LastUpdatedBy] = source.LastUpdatedBy
      , [LastUpdatedDate] = getdate()
      , [LastScanDate] = source.LastScanDate
WHEN NOT MATCHED BY TARGET THEN
    INSERT 
           (
            [ItemFormID]
           , [ItemTypeCode]
           , [ItemTypeDescription]
           , [AutoGenerateType4GTIN]
           , [GTIN]
           , [GTINCheckDigit]
           , [ExistingGTINIndicator]
           , [CompressedUPC]
           , [PriceLookupCode]
           , [ReUseItemCode]
           , [ReUseItemDescription]
           , [SubmissionReasonID]
           , [ItemCaseTypeID]
           , [RecipeRequired]
           , [IngredientItemRequired]
           , [ModelProductItemCode]
           , [ModelProductItemDescription]
           , [ModelProductItemTypeCode]
           , [ModelPackagingItemCode]
           , [ModelPackagingItemDescription]
           , [ModelPackagingItemTypeCode]
           , [VendorItemCode]
           , [VendorItemDescription]
           , [ItemDescription]
           , [Brand]
           , [Manufacturer]
           , [RetailPackagedItem]
           , [RetailPackType]
           , [RetailPackTypeDescription]
           , [RetailPackSize]
           , [Size]
           , [SizeUOM]
           , [SizeUOMDescription]
           , [MinorityManufacturer]
           , [PackageDescription]
           , [ContainerType]
           , [LabelAmount]
           , [PerpetualInventoryFlag]
           , [ReceiptDescription]
           , [AdDescription]
           , [ProductCatalogShortDescription1]
           , [ProductCatalogShortDescription2]
           , [NonDiscountable]
           , [AdditionalGTINPresent]
           , [CreatedBy]
           , [CreatedDate]
            , LastScanDate)
     VALUES
           (
             source.ItemFormID
            , source.ItemTypeCode
           , source.ItemTypeDescription
           , source.AutoGenerateType4GTIN
           , source.GTIN
           , source.GTINCheckDigit
           , source.ExistingGTINIndicator
           , source.CompressedUPC
           , source.PriceLookupCode
           , source.ReUseItemCode
           , source.ReUseItemDescription
           , source.SubmissionReasonID
           , source.ItemCaseTypeID
           , source.RecipeRequired
           , source.IngredientItemRequired
           , source.ModelProductItemCode
           , source.ModelProductItemDescription
           , source.ModelProductItemTypeCode
           , source.ModelPackagingItemCode
           , source.ModelPackagingItemDescription
           , source.ModelPackagingItemTypeCode
           , source.VendorItemCode
           , source.VendorItemDescription
           , source.ItemDescription
           , source.Brand
           , source.Manufacturer
           , source.RetailPackagedItem
           , source.RetailPackType
           , source.RetailPackTypeDescription
           , source.RetailPackSize
           , source.Size
           , source.SizeUOM
           , source.SizeUOMDescription
           , source.MinorityManufacturer
           , source.PackageDescription
           , source.ContainerType
           , source.LabelAmount
           , source.PerpetualInventoryFlag
           , source.ReceiptDescription
           , source.AdDescription
           , source.ProductCatalogShortDescription1
           , source.ProductCatalogShortDescription2
           , source.NonDiscountable
           , source.AdditionalGTINPresent
           , source.CreatedBy
           , getDate()
           ,source.LastScanDate );";

        private const string AuditBasicItemFormDefnitionSQL = @"INSERT INTO [dbo].[BasicItemDefinitionAudit]
                                                                   ([Version]
                                                                   ,[ItemFormID]
                                                                   ,[ItemTypeCode]
                                                                   ,[ItemTypeDescription]
                                                                   ,[AutoGenerateType4GTIN]
                                                                   ,[GTIN]
                                                                   ,[GTINCheckDigit]
                                                                   ,[ExistingGTINIndicator]
                                                                   ,[CompressedUPC]
                                                                   ,[PriceLookupCode]
                                                                   ,[ReUseItemCode]
                                                                   ,[ReUseItemDescription]
                                                                   ,[SubmissionReasonID]
                                                                   ,[ItemCaseTypeID]
                                                                   ,[RecipeRequired]
                                                                   ,[IngredientItemRequired]
                                                                   ,[ModelProductItemCode]
                                                                   ,[ModelProductItemDescription]
                                                                   ,[ModelPackagingItemCode]
                                                                   ,[ModelPackagingItemDescription]
                                                                   ,[VendorItemCode]
                                                                   ,[VendorItemDescription]
                                                                   ,[ItemDescription]
                                                                   ,[Brand]
                                                                   ,[Manufacturer]
                                                                   ,[RetailPackagedItem]
                                                                   ,[RetailPackType]
                                                                   ,[RetailPackTypeDescription]
                                                                   ,[RetailPackSize]
                                                                   ,[Size]
                                                                   ,[SizeUOM]
                                                                   ,[SizeUOMDescription]
                                                                   ,[MinorityManufacturer]
                                                                   ,[PackageDescription]
                                                                   ,[ContainerType]
                                                                   ,[LabelAmount]
                                                                   ,[PerpetualInventoryFlag]
                                                                   ,[ReceiptDescription]
                                                                   ,[AdDescription]
                                                                   ,[ProductCatalogShortDescription1]
                                                                   ,[ProductCatalogShortDescription2]
                                                                   ,[NonDiscountable]
                                                                   ,[AdditionalGTINPresent]
                                                                   ,[CreatedBy]
                                                                   ,[CreatedDate]
                                                                   ,[LastUpdatedBy]
                                                                   ,[LastUpdatedDate]
                                                                   ,[LastScanDate])
                                                            SELECT  getDate(),
	                                                               [ItemFormID]
                                                                  ,[ItemTypeCode]
                                                                  ,[ItemTypeDescription]
                                                                  ,[AutoGenerateType4GTIN]
                                                                  ,[GTIN]
                                                                  ,[GTINCheckDigit]
                                                                  ,[ExistingGTINIndicator]
                                                                  ,[CompressedUPC]
                                                                  ,[PriceLookupCode]
                                                                  ,[ReUseItemCode]
                                                                  ,[ReUseItemDescription]
                                                                  ,[SubmissionReasonID]
                                                                  ,[ItemCaseTypeID]
                                                                  ,[RecipeRequired]
                                                                  ,[IngredientItemRequired]
                                                                  ,[ModelProductItemCode]
                                                                  ,[ModelProductItemDescription]
                                                                  ,[ModelPackagingItemCode]
                                                                  ,[ModelPackagingItemDescription]
                                                                  ,[VendorItemCode]
                                                                  ,[VendorItemDescription]
                                                                  ,[ItemDescription]
                                                                  ,[Brand]
                                                                  ,[Manufacturer]
                                                                  ,[RetailPackagedItem]
                                                                  ,[RetailPackType]
                                                                  ,[RetailPackTypeDescription]
                                                                  ,[RetailPackSize]
                                                                  ,[Size]
                                                                  ,[SizeUOM]
                                                                  ,[SizeUOMDescription]
                                                                  ,[MinorityManufacturer]
                                                                  ,[PackageDescription]
                                                                  ,[ContainerType]
                                                                  ,[LabelAmount]
                                                                  ,[PerpetualInventoryFlag]
                                                                  ,[ReceiptDescription]
                                                                  ,[AdDescription]
                                                                  ,[ProductCatalogShortDescription1]
                                                                  ,[ProductCatalogShortDescription2]
                                                                  ,[NonDiscountable]
                                                                  ,[AdditionalGTINPresent]
                                                                  ,[CreatedBy]
                                                                  ,[CreatedDate]
                                                                  ,[LastUpdatedBy]
                                                                  ,[LastUpdatedDate]
                                                                  ,[LastScanDate]
                                                          FROM [dbo].[BasicItemDefinition] WHERE [ItemFormID] = @ItemFormID";

        private const string GetBasicItemDefinitionDataSQL = @"SELECT
                                                                    IFM.ItemFormDisplayID  
                                                                    ,BID.ItemFormID
		                                                            ,BID.[ItemTypeCode]
		                                                            ,BID.[ItemTypeDescription]
                                                                    ,BID.[AutoGenerateType4GTIN]
		                                                            ,BID.[GTIN]
		                                                            ,BID.[GTINCheckDigit]
		                                                            ,BID.[ExistingGTINIndicator]
		                                                            ,BID.[CompressedUPC]
		                                                            ,BID.[PriceLookupCode]
		                                                            ,BID.[ReUseItemCode]
		                                                            ,BID.[ReUseItemDescription]
		                                                            ,BID.[SubmissionReasonID]
		                                                            ,BID.[ItemCaseTypeID]
		                                                            ,BID.[RecipeRequired]
		                                                            ,BID.[IngredientItemRequired]
		                                                            ,BID.[ModelProductItemCode]
		                                                            ,BID.[ModelProductItemDescription]
                                                                    ,BID.[ModelProductItemTypeCode]
		                                                            ,BID.[ModelPackagingItemCode]
		                                                            ,BID.[ModelPackagingItemDescription]
                                                                    ,BID.[ModelPackagingItemTypeCode]
		                                                            ,BID.[VendorItemCode]
		                                                            ,BID.[VendorItemDescription]
		                                                            ,BID.[ItemDescription]
		                                                            ,BID.[Brand]
		                                                            ,BID.[Manufacturer]
		                                                            ,BID.[RetailPackagedItem]
		                                                            ,BID.[RetailPackType]
		                                                            ,BID.[RetailPackTypeDescription]
		                                                            ,BID.[RetailPackSize]
		                                                            ,BID.[Size]
		                                                            ,BID.[SizeUOM]
		                                                            ,BID.[SizeUOMDescription]
		                                                            ,BID.[MinorityManufacturer]
		                                                            ,BID.[PackageDescription]
		                                                            ,BID.[ContainerType]
		                                                            ,BID.[LabelAmount]
		                                                            ,BID.[PerpetualInventoryFlag]
		                                                            ,BID.[ReceiptDescription]
		                                                            ,BID.[AdDescription]
		                                                            ,BID.[ProductCatalogShortDescription1]
		                                                            ,BID.[ProductCatalogShortDescription2]
		                                                            ,BID.[NonDiscountable]
		                                                            ,BID.[AdditionalGTINPresent]
		                                                            ,BID.LastScanDate
		                                                            ,SI.BackroomScaleIndicator
		                                                            ,SI.ScaleDescription1
		                                                            ,SI.ScaleDescription2
		                                                            ,IIF((MI.Brand IS NOT NULL AND ISNULL(BID.Brand,'') != ISNULL(MI.Brand,'')),1, 0 ) AS IsBrandChanged
		                                                            ,IIF((MI.Manufacturer IS NOT NULL AND ISNULL(BID.Manufacturer,'') != ISNULL(MI.Manufacturer,'')),1, 0 ) AS IsManufacturerChanged
		                                                            ,IFM.SubmittedUserTypeID
		                                                            ,IFM.FormStatusID
		                                                            ,IFM.FormTypeID
		                                                            ,IFM.FormActionID
                                                                    ,IFM.ItemCode
                                                                    ,IFM.VendorContactID
                                                            FROM [dbo].[BasicItemDefinition] BID
                                                            INNER JOIN ItemForm IFM ON IFM.ID = BID.ItemFormID
                                                            LEFT OUTER JOIN [dbo].[ScaleInfo] SI ON BID.ItemFormID = SI.ItemFormID
                                                            LEFT OUTER JOIN [dbo].[ModelProductItemValue] MI ON BID.ItemFormID = MI.ItemFormID
                                                            WHERE IFM.ItemFormDisplayID = @ItemFormDisplayID AND IFM.FormStatusID != 2";

        private const string DeleteDsdVendorAuthorizationsByItemFormSQL = @"
                    DELETE  FROM [dbo].[DSDAuthRequestStore] 
                    WHERE ItemFormID = @ItemFormID 
            ";

        private const string DeleteDsdVendorAuthorizationsByItemFormAndVendorsSQL = @"
                    DELETE  FROM [dbo].[DSDAuthRequestStore] 
                    WHERE ItemFormID = @ItemFormID AND VendorNumber IN @VendorNumbers;
            ";
        private const string GetDsdVendorsExistForItemFormSQL = @"SELECT VendorNumber, [VendorDescription] AS VendorName FROM [dbo].[PackagingHierarchy] 
                                                INNER JOIN [dbo].[OrderablePackLevel] ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
                                                WHERE PackagingHierarchy.ItemFormID = @ItemFormID AND OrderablePackLevel.VendorType = 'DSD'";

        private const string DeleteDsdVendorsSql = @"DELETE FROM DSDAuthRequestStore WHERE ItemFormID = @ItemFormID AND VendorNumber NOT IN 
												(SELECT VendorNumber FROM [dbo].[PackagingHierarchy] 
                                                INNER JOIN [dbo].[OrderablePackLevel] ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
                                                WHERE PackagingHierarchy.ItemFormID = @ItemFormID AND OrderablePackLevel.VendorType = 'DSD')";
        private const string DeleteDsdVendorsAuditSql = @"
                            INSERT INTO [dbo].[DSDAuthRequestStoreAudit]
                                ([Version]
                                ,[ItemFormID]
                                ,[VendorNumber]
                                ,[VendorName]
                                ,[StoreNumber]
                                ,[StateCode]
                                ,[StateName]
                                ,[CountyCode]
                                ,[CountyName]
                                ,[IsActive]
                                ,[CreatedBy]
                                ,[CreatedDate]
                                ,[LastUpdatedBy]
                                ,[LastUpdatedDate])
                        SELECT 
                                getdate()
                                ,[ItemFormID]
                                ,[VendorNumber]
                                ,[VendorName]
                                ,[StoreNumber]
                                ,[StateCode]
                                ,[StateName]
                                ,[CountyCode]
                                ,[CountyName]
                                ,[IsActive]
                                ,[CreatedBy]
                                ,[CreatedDate]
                                ,[LastUpdatedBy]
                                ,[LastUpdatedDate]
                        FROM [dbo].[DSDAuthRequestStore]
                        WHERE ItemFormID = @ItemFormID AND VendorNumber NOT IN 
												(SELECT VendorNumber FROM [dbo].[PackagingHierarchy] 
                                                INNER JOIN [dbo].[OrderablePackLevel] ON OrderablePackLevel.PackagingHierarchyID = PackagingHierarchy.ID
                                                WHERE PackagingHierarchy.ItemFormID = @ItemFormID AND OrderablePackLevel.VendorType = 'DSD')";
        #endregion

    }

}
