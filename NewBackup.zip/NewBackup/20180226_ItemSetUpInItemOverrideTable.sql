USE S0OMNIXX
GO

	if OBJECT_ID('tempdb..#itemoverride') is not null drop table #itemoverride
	create table #itemoverride (itemid int, ItemName varchar(500))

insert into #itemoverride (itemid) values (391)
insert into #itemoverride (itemid) values (402)
insert into #itemoverride (itemid) values (407)
insert into #itemoverride (itemid) values (419)
insert into #itemoverride (itemid) values (424)
insert into #itemoverride (itemid) values (426)
insert into #itemoverride (itemid) values (427)
insert into #itemoverride (itemid) values (431)
insert into #itemoverride (itemid) values (453)
insert into #itemoverride (itemid) values (455)
insert into #itemoverride (itemid) values (456)
insert into #itemoverride (itemid) values (457)
insert into #itemoverride (itemid) values (526)
insert into #itemoverride (itemid) values (529)
insert into #itemoverride (itemid) values (546)
insert into #itemoverride (itemid) values (559)
insert into #itemoverride (itemid) values (581)
insert into #itemoverride (itemid) values (707)
insert into #itemoverride (itemid) values (913)
insert into #itemoverride (itemid) values (1019)
insert into #itemoverride (itemid) values (1214)
insert into #itemoverride (itemid) values (1436)
insert into #itemoverride (itemid) values (1519)
insert into #itemoverride (itemid) values (1520)
insert into #itemoverride (itemid) values (1521)
insert into #itemoverride (itemid) values (1522)
insert into #itemoverride (itemid) values (5062)
insert into #itemoverride (itemid) values (5604)
insert into #itemoverride (itemid) values (128947)
insert into #itemoverride (itemid) values (181317)
insert into #itemoverride (itemid) values (181321)
insert into #itemoverride (itemid) values (193570)
insert into #itemoverride (itemid) values (210991)
insert into #itemoverride (itemid) values (210994)
insert into #itemoverride (itemid) values (211118)
insert into #itemoverride (itemid) values (221830)
insert into #itemoverride (itemid) values (237027)
insert into #itemoverride (itemid) values (237911)
insert into #itemoverride (itemid) values (237914)
insert into #itemoverride (itemid) values (238371)
insert into #itemoverride (itemid) values (870775)
insert into #itemoverride (itemid) values (886253)


update tmpItm
set tmpItm.ItemName = it.ItemName
from #itemoverride tmpItm
inner join Item it on tmpitm.itemid = it.itemid


	select * from #itemoverride
	



	Insert into ItemOverride(ItemId, ItemName, IsFDAMenuLabel, EffectiveDate, TerminationDate, IsExcludeItem, LastUpdatedBy, LastUpdatedDate)

	select itemid
	, ItemName
	, 0 as IsFDAMenuLabel
	, cast(GETDATE() as DATE) as EffectiveDate 
	, '2018-02-26 00:00:00.000' as TerminationDate
	, 1 as IsExcludeItem
	, 'CE008DG' as LastUpdatedBy
	, GETDATE() as LastUpdatedDate
	FROM #itemoverride
	where not exists ( select top 1 1 from ItemOverride where itemid = #itemoverride.itemid)


	select * from ItemOverride where itemid in (select itemid from #itemoverride)