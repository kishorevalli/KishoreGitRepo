Use S0OMNIXX

Go

ALTER TABLE dbo.INST_TLOG
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstCRLog
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.Inst_OLog
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstOutOfStockDetails
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstOutOfStockProduct
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstServiceFees
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstSearchPerformance
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstShopperPerformance
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstDeliveryAvailability
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstOutOfStockData
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstConsumerFeedback
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstBenchmarkDeliveryAvailability
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstBenchmarkOutOfStock
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstBenchmarkSearchPerformance
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstBenchmarkConsumerFeedback
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstBenchmarkShopperPerformance
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstBenchmarkFees
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstCreditReturns
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

ALTER TABLE dbo.InstHappinessCalls
ADD FileVersionIndicator CHAR(2),
B2BPartner varchar(30)
Go

