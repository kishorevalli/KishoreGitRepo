begin tran tran1

use s0omnisg
GO
update EmailNotification set id=1 where Description='PaymentStatus'
GO
update EmailNotification set id=2 where Description='PosResponse'
GO
update EmailNotification set EnableAttachments=1 where id=1
GO
INSERT [dbo].[SupportChecks] ([Name], [Query], [Active], [EmailNotificationId], [Type], [FilePath], [Interval], [IsIntervalActive]) VALUES (N'Pblx_BypassCheckout_Daily_Settlement_Details_', N'SELECT                  
pbct.FacilityID AS Store 
,CAST(pbct.TransactionDate AS DATE) AS [Transaction Date]
,SUM(pbct.TenderAmount) AS [POS Total]   
    ,SUM(CASE WHEN pbct.NonAlcoholSales + ISNULL(CouponValue, 0) - ISNULL(pbct.BottleDeposit, 0) > 0 THEN 
        pbct.NonAlcoholSales + ISNULL(CouponValue, 0) - ISNULL(pbct.BottleDeposit, 0)
ELSE 
        pbct.NonAlcoholSales 
END) AS [POS Non Alcohol Pretax Total]
,SUM(CASE WHEN pbct.NonAlcoholSales + ISNULL(CouponValue, 0) - ISNULL(pbct.BottleDeposit, 0) < 0 THEN 
    CASE WHEN pbct.AlcoholSales  + ISNULL(CouponValue, 0) - ISNULL(pbct.BottleDeposit, 0) > 0 THEN 
    pbct.AlcoholSales  + ISNULL(CouponValue, 0) - ISNULL(pbct.BottleDeposit, 0)
    ELSE 
    pbct.AlcoholSales  
    END
ELSE
pbct.AlcoholSales  
END) AS [POS Alcohol Pretax Total]            
,SUM(pbct.TotalTax) AS [POS Sales Tax Total]
,SUM(pbct.BottleDeposit) AS [POS Bottle Deposit] 
FROM PosBypassCheckoutTransaction pbct
INNER JOIN InstOrder iord ON pbct.MaskedAccountString = iord.OrderId
WHERE LineNumber = 0
AND TenderTypeId IN (83)  
AND CAST(pbct.TransactionDate AS DATE) =  CAST(getdate()-1 AS DATE)
GROUP BY pbct.FacilityID, CAST(pbct.TransactionDate AS DATE)', 1, 1, N'Database', N'', N'10', 0)
GO

commit tran tran1

