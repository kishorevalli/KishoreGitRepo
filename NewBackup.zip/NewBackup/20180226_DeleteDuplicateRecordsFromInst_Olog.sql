Begin tran instOlog

select distinct * into #temp from Inst_OLog where orderid = 257217488
 
delete from Inst_OLog WHERE ORDERID = 257217488
 
insert into Inst_OLog
select * from #temp

-- rollback tran instOlog
-- commit tran instOlog

select * from Inst_OLog (nolock) where orderid = 257217488

drop table #temp