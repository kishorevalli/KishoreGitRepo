Use S0OMNIXX
Go

update SystemValues_t set KeyName='SpecialtyFileTag', value = 'Specialty' where ID=53
GO

update FileVersion set fileversionType='Specialty' where Id=5
GO

sp_rename 'item.IsGreenWiseFileVersionEnabled', 'IsSpecialtyFileVersionEnabled', 'COLUMN';
GO

sp_rename 'Stores_t.IsGreenWiseEnabled', 'IsSpecialtyEnabled', 'COLUMN';
GO