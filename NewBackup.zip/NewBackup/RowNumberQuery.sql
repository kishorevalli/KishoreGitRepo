declare @date as datetime
set @date = GETDATE()

INSERT INTO Inst_Tlog_Exception (
	 OrderID
	,DeliveryID
	,OrderedDate
	,DeliveryDate
	,ItemID
	,GTIN
	,Item
	,Brand
	,OriginalRetailPrice
	,Unit
	,Qty
	,EstimatedRetailRevenue
	,InstacartOnlinePrice
	,InstacartOnlineRevenue
	,SalesTax
	,BottleDeposit
	,BagFees
	,GMV
	,Aisle
	,Department
	,LoyaltyNumber
	,ZipCode
	,StoreLocation
	,IsDelivery
	,IsPickup
	,IsAlcoholic
	,UserAddedNotes
	,ReplacementNotes
	,LoyaltyPrice
	,PriceSource
	,ReferenceCode
	,RetailerReceiptNumber
	,AlcoholExciseTax
	,StoreLocationZipCode
	,IsFromWhiteLabel
	,IsSpecialRequest
	,UserID
	,UserZipCode
	,RunDateId
	,LastUpdatedDate
	,LastUpdatedBy
	,FileRowReference
	,ExceptionReason
  ,BagTax
	,SodaTax
	,FulfilledItemType
	,IsRedlivered
	,[Platform]
	,IsExpressCustomer
	,ShopperPickingType)

	SELECT
	 OrderID
	,DeliveryID
	,OrderedDate
	,DeliveryDate
	,ItemID
	,GTIN
	,Item
	,Brand
	,OriginalRetailPrice
	,Unit
	,Qty
	,EstimatedRetailRevenue
	,InstacartOnlinePrice
	,InstacartOnlineRevenue
	,SalesTax
	,BottleDeposit
	,BagFees
	,GMV
	,Aisle
	,Department
	,LoyaltyNumber
	,ZipCode
	,StoreLocation
	,IsDelivery
	,IsPickup
	,IsAlcoholic
	,UserAddedNotes
	,ReplacementNotes
	,LoyaltyPrice
	,PriceSource
	,ReferenceCode
	,RetailerReceiptNumber
	,AlcoholExciseTax
	,StoreLocationZipCode
	,IsFromWhiteLabel
	,IsSpecialRequest
	,UserID
	,UserZipCode
	,RunDateId
	,@date
	,LastUpdatedBy
	,FileRowReference
	,ExceptionRule
  ,BagTax
	,SodaTax
	,FulfilledItemType
	,IsRedlivered
	,[Platform]
	,IsExpressCustomer
	,ShopperPickingType
	FROM #Inst_TLog_Staging WHERE ExceptionFlag = 1;

	

	INSERT INTO Inst_Tlog (
	 OrderID
	,OrderLineNumber
	,DeliveryID
	,OrderedDate
	,DeliveryDate
	,ItemID
	,GTIN
	,Item
	,Brand
	,OriginalRetailPrice
	,Unit
	,Qty
	,EstimatedRetailRevenue
	,InstacartOnlinePrice
	,InstacartOnlineRevenue
	,SalesTax
	,BottleDeposit
	,BagFees
	,GMV
	,Aisle
	,Department
	,LoyaltyNumber
	,ZipCode
	,StoreLocation
	,IsDelivery
	,IsPickup
	,IsAlcoholic
	,UserAddedNotes
	,ReplacementNotes
	,LoyaltyPrice
	,PriceSource
	,ReferenceCode
	,RetailerReceiptNumber
	,AlcoholExciseTax
	,StoreLocationZipCode
	,IsFromWhiteLabel
	,IsSpecialRequest
	,UserID
	,UserZipCode
	,RunDateId
	,LastUpdatedDate
	,LastUpdatedBy
	,FileRowReference
	,BagTax
	,SodaTax
	,FulfilledItemType
	,IsRedlivered
	,[Platform]
	,IsExpressCustomer
	,ShopperPickingType)
	SELECT
	 its.OrderID
	,row_number() over(PARTITION BY its.OrderID order by its.OrderID, FileRowReference ) + ISNULL(inst.maxOrderLineNumber,0)
	,DeliveryID
	,OrderedDate
	,DeliveryDate
	,ItemID
	,GTIN
	,Item
	,Brand
	,OriginalRetailPrice
	,Unit
	,Qty
	,EstimatedRetailRevenue
	,InstacartOnlinePrice
	,InstacartOnlineRevenue
	,SalesTax
	,BottleDeposit
	,BagFees
	,GMV
	,Aisle
	,Department
	,LoyaltyNumber
	,ZipCode
	,StoreLocation
	,IsDelivery
	,IsPickup
	,IsAlcoholic
	,UserAddedNotes
	,ReplacementNotes
	,LoyaltyPrice
	,PriceSource
	,ReferenceCode
	,RetailerReceiptNumber
	,AlcoholExciseTax
	,StoreLocationZipCode
	,IsFromWhiteLabel
	,IsSpecialRequest
	,UserID
	,UserZipCode
	,RunDateId
	,@date
	,LastUpdatedBy
	,FileRowReference
	,BagTax
	,SodaTax
	,FulfilledItemType
	,IsRedlivered
	,[Platform]
	,IsExpressCustomer
	,ShopperPickingType
	FROM #Inst_TLog_Staging its
	left outer join(select max(tlog.OrderLineNumber) as maxOrderLineNumber, tlog.OrderID from Inst_TLog tlog group by tlog.OrderID) inst on inst.OrderID=its.OrderID
	where (ExceptionFlag IS NULL OR ExceptionFlag = 0);

	                
	Update tLOG set tlog.Liquor = 'Y'
		FROM�Inst_Tlog tLOG
��������INNER�JOIN�FileType_Rundates ftr�ON�tLOG.RundateId�=�ftr.Id�
��������INNER�JOIN�FileVersion fv�ON�fv.Id�=�ftr.FileVersionId�
��������where�ftr.Id�=�@RundateId	
		AND fv.TypeName  = 'Liquor'
	                 
	    
    UPDATE tLOG
    Set tLOG.Specialty = 'Y'
    	FROM�Inst_Tlog tLOG
��������INNER�JOIN�FileType_Rundates ftr�ON�tLOG.RundateId�=�ftr.Id�
��������INNER�JOIN�FileVersion fv�ON�fv.Id�=�ftr.FileVersionId�
��������where�ftr.Id�=�@RundateId	
		AND fv.TypeName  = 'Specialty'

	 Update tLOG set FileVersionIndicator = fv.Indicator
	�FROM�Inst_Tlog tLOG
��������INNER�JOIN�FileType_Rundates ftr�ON�tLOG.RundateId�=�ftr.Id�
��������INNER�JOIN�FileVersion fv�ON�fv.Id�=�ftr.FileVersionId�
��������where�ftr.Id�=�@RundateId