Use S0OMNIXX
 GO
 insert into SystemValues_t values('GreenWiseFileTag', 'GreenWise', 'Name of the GreenWise File Tag')
 GO
