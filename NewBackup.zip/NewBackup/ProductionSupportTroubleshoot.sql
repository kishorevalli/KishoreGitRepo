use s0omnixx

select top 100 * from SystemLog order by 1 desc

System.AggregateException: One or more errors occurred. ---> System.Data.SqlClient.SqlException: Arithmetic overflow error converting expression to data type bigint.  Arithmetic overflow error converting expression to data type bigint.  The statement has been terminated.  The statement has been terminated.     at System.Data.SqlClient.SqlConnection.OnError(SqlException exception, Boolean breakConnection, Action`1 wrapCloseInAction)     at System.Data.SqlClient.SqlInternalConnection.OnError(SqlException exception, Boolean breakConnection, Action`1 wrapCloseInAction)     at System.Data.SqlClient.TdsParser.ThrowExceptionAndWarning(TdsParserStateObject stateObj, Boolean callerHasConnectionLock, Boolean asyncClose)     at System.Data.SqlClient.TdsParser.TryRun(RunBehavior runBehavior, SqlCommand cmdHandler, SqlDataReader dataStream, BulkCopySimpleResultSet bulkCopyHandler, TdsParserStateObject stateObj, Boolean& dataReady)     at System.Data.SqlClient.SqlCommand.FinishExecuteReader(SqlDataReader ds, RunBehavior runBehavior, String resetOptionsString)     at System.Data.SqlClient.SqlCommand.RunExecuteReaderTds(CommandBehavior cmdBehavior, RunBehavior runBehavior, Boolean returnStream, Boolean async, Int32 timeout, Task& task, Boolean asyncWrite, SqlDataReader ds)     at System.Data.SqlClient.SqlCommand.RunExecuteReader(CommandBehavior cmdBehavior, RunBehavior runBehavior, Boolean returnStream, String method, TaskCompletionSource`1 completion, Int32 timeout, Task& task, Boolean asyncWrite)     at System.Data.SqlClient.SqlCommand.InternalExecuteNonQuery(TaskCompletionSource`1 completion, String methodName, Boolean sendToPipe, Int32 timeout, Boolean asyncWrite)     at System.Data.SqlClient.SqlCommand.ExecuteNonQuery()     at Dapper.SqlMapper.ExecuteCommand(IDbConnection cnn, CommandDefinition& command, Action`2 paramReader) in d:\Dev\dapper-dot-net\Dapper NET40\SqlMapper.cs:line 3321     at Dapper.SqlMapper.ExecuteImpl(IDbConnection cnn, CommandDefinition& command) in d:\Dev

select * from FileType_RunDates order by 1 desc where ID in (16584
,16583
,16582
,16581) where order by 1 desc

delete from Inst_TLog_History

select * from Inst_TLog_History where rundateId in (16584
,16583
,16582
,16581) and len(GTIN)>15

update Inst_TLog_History set GTIN=null 

select * from inst_tlog_history(nolock) where RunDateId in (16588
,16587
,16586
,16585) and len(GTIN)>15 and ItemID in (1006568854
,1006566545
,1006566552
,1006570197
,1006565235
,1006563741
,1006571426
,1006570503
,1006566131
,1006564256)

select top 100000 * from SystemLog where LogMessage like '%OMNIP30%' order by  1 desc

OMSGP30- OmniScanGoReceiveResponse - End

select top 100 * from systemlog where LogMessage like '%OMNIP03%' order by  1 desc

select * from  InstOutOfStockDataHistory(nolock) where  DeliveredGTIN='http://hmk.ag/' and OrderedGTIN=94050
where DeliveredGTIN='http://hmk.ag/'
OrderedRRC = 23539  order by OrderedGTIN desc
update InstOutOfStockDataHistory set  DeliveredGTIN =4376 where   DeliveredGTIN='http://hmk.ag/' and OrderedGTIN=4376

 DeliveredRRC = 23539 and DeliveredGTIN='http://hmk.ag/' and OrderedGTIN=94050
select * from Inst_TLog where referencecode=23539
where OrderedGTIN
where --RetailerLocationCodeBatched='DTO3'
 --RetailerLocationCodeOrdered ='DTO3' order by RetailerLocationCodeBatched desc
 StoreLocation='DTO3'
1424 desc
397 order by 1 desc where 

356, 1270

update InstOutOfStockDataHistory set RetailerLocationCodeOrdered =356 where RetailerLocationCodeOrdered ='DTO3' and RetailerLocationCodeBatched=356
update InstOutOfStockDataHistory set RetailerLocationCodeOrdered =1270 where RetailerLocationCodeOrdered ='DTO3' and RetailerLocationCodeBatched=1270

select * from  InstOutOfStockDataHistory(nolock) where RetailerLocationCodeOrdered ='DTO3' and RetailerLocationCodeBatched=356

RetailerLocationCodeBatched
RetailerLocationCodeOrdered
1424
397

System.AggregateException: One or more errors occurred. ---> System.Data.SqlClient.SqlException: Error converting data type varchar to bigint.     at System.Data.SqlClient.SqlConnection.OnError(SqlException exception, Boolean breakConnection, Action`1 wrapCloseInAction)     at System.Data.SqlClient.SqlInternalConnection.OnError(SqlException exception, Boolean breakConnection, Action`1 wrapCloseInAction)     at System.Data.SqlClient.TdsParser.ThrowExceptionAndWarning(TdsParserStateObject stateObj, Boolean callerHasConnectionLock, Boolean asyncClose)     at System.Data.SqlClient.TdsParser.TryRun(RunBehavior runBehavior, SqlCommand cmdHandler, SqlDataReader dataStream, BulkCopySimpleResultSet bulkCopyHandler, TdsParserStateObject stateObj, Boolean& dataReady)     at System.Data.SqlClient.SqlCommand.FinishExecuteReader(SqlDataReader ds, RunBehavior runBehavior, String resetOptionsString)     at System.Data.SqlClient.SqlCommand.RunExecuteReaderTds(CommandBehavior cmdBehavior, RunBehavior runBehavior, Boolean returnStream, Boolean async, Int32 timeout, Task& task, Boolean asyncWrite, SqlDataReader ds)     at System.Data.SqlClient.SqlCommand.RunExecuteReader(CommandBehavior cmdBehavior, RunBehavior runBehavior, Boolean returnStream, String method, TaskCompletionSource`1 completion, Int32 timeout, Task& task, Boolean asyncWrite)     at System.Data.SqlClient.SqlCommand.InternalExecuteNonQuery(TaskCompletionSource`1 completion, String methodName, Boolean sendToPipe, Int32 timeout, Boolean asyncWrite)     at System.Data.SqlClient.SqlCommand.ExecuteNonQuery()     at Dapper.SqlMapper.ExecuteCommand(IDbConnection cnn, CommandDefinition& command, Action`2 paramReader) in d:\Dev\dapper-dot-net\Dapper NET40\SqlMapper.cs:line 3321     at Dapper.SqlMapper.ExecuteImpl(IDbConnection cnn, CommandDefinition& command) in d:\Dev\dapper-dot-net\Dapper NET40\SqlMapper.cs:line 1319     at Dapper.SqlMapper.Execute(IDbConnection cnn, String sql, Object param, IDbTransaction transaction, Nullable

select * from ITEM_DATA_EXPORT

select * from fileType


use s0omnixx

begin tran tran1

update InstOutOfStockDataHistory set RetailerLocationCodeOrdered =1270 where RetailerLocationCodeOrdered ='DTO3' and RetailerLocationCodeBatched=1270

 update InstOutOfStockDataHistory set RetailerLocationCodeOrdered =1171 where RetailerLocationCodeOrdered ='DTO3' and RetailerLocationCodeBatched=1171

 update InstOutOfStockDataHistory set RetailerLocationCodeOrdered =356 where RetailerLocationCodeOrdered ='DTO3' and RetailerLocationCodeBatched=356

update InstOutOfStockDataHistory set OrderedGTIN=850806002339, DeliveredGTIN=850806002339  where OrderedGTIN='http://hmk.ag/'
and deliveredGTIN='http://hmk.ag/' and storelocation in (750,669, 1397, 454, 812,1397,1509,1569, 1466, 812, 1406, 84, 1305, 615, 1499, 669,721) 

update InstOutOfStockDataHistory set OrderedGTIN=4050, DeliveredGTIN=4050  where OrderedGTIN='http://hmk.ag/'
and deliveredGTIN='http://hmk.ag/' --and storelocation in (750,669, 1397, 454, 812,1397,1509,1569, 1466, 812, 1406, 84, 1305, 615, 1499, 669,721) 

update InstOutOfStockDataHistory set OrderedGTIN=NULL where OrderedGTIN='http://hmk.ag/' and StoreLocation=1009

update InstOutOfStockDataHistory set OrderedGTIN=94050 where OrderedGTIN='http://hmk.ag/' and StoreLocation=1453

update InstOutOfStockDataHistory set OrderedGTIN=null where OrderedGTIN='http://hmk.ag/' and StoreLocation=1286

update InstOutOfStockDataHistory set OrderedGTIN=00284807000009 where OrderedGTIN='http://hmk.ag/' and StoreLocation=632

update InstOutOfStockDataHistory set OrderedGTIN=4376 where OrderedGTIN='http://hmk.ag/' and StoreLocation=0073

update InstOutOfStockDataHistory set DeliveredGTIN=94050 where OrderedGTIN=94050 and DeliveredGTIN='http://hmk.ag/' and StoreLocation=1020


commit tran tran1